package com.hcentive.billing.core.commons.record.util.annotation;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class RecordIdAnnotationParser<T> implements RecordIdParser<T> {

	private final static Logger logger = LoggerFactory
			.getLogger(RecordIdAnnotationParser.class);

	@Override
	public String getRecordId(T type) {
		logger.debug("Starting annotation parser");
		String recordIdValue = null;
		// Field[] fields = type.getClass().getSuperclass().getDeclaredFields();
		Field[] fields = getDeclaredFields(type.getClass(), true);

		for (int i = 0; i < fields.length; i++) {
			fields[i].setAccessible(true); // Make private fields accessible.
			RecordId recordId = (RecordId) fields[i]
					.getAnnotation(RecordId.class);
			if (recordId == null) {
				continue;
			} else {
				Field field = fields[i];
				try {
					Object value = field.get(type);
					if (null == value) {
						recordIdValue = UUID.randomUUID().toString();
					} else {
						recordIdValue = value.toString();
					}
				} catch (IllegalArgumentException | IllegalAccessException e) {
					logger.error("Errror while parsing recordId annotation", e);

				}
				break;
			}
		}
		if (recordIdValue != null) {
			return recordIdValue;
		} else {
			List<Method> methods = getMethodsAnnotatedWith(type.getClass(),
					RecordId.class);
			if (null != methods && methods.size() == 1)
				recordIdValue = findRecrodValueFromMethod(methods.get(0), type);

			logger.debug("Ending annotation parser:: Field value::"
					+ recordIdValue);
			return recordIdValue;
		}
	}

	private String findRecrodValueFromMethod(Method method, final T type) {
		Object recordIdValue = null;
		try {
			method.setAccessible(true);
			recordIdValue = method.invoke(type, null);
		} catch (IllegalAccessException e) {
			logger.error(e.getMessage(), e);
		} catch (IllegalArgumentException e) {
			logger.error(e.getMessage(), e);
		} catch (InvocationTargetException e) {
			logger.error(e.getMessage(), e);
		}
		return (recordIdValue != null) ? recordIdValue.toString() : null;

	}

	public static Field[] getDeclaredFields(Class clazz, boolean recursively) {
		List<Field> fields = new LinkedList<Field>();
		Field[] declaredFields = clazz.getDeclaredFields();
		Collections.addAll(fields, declaredFields);

		Class superClass = clazz.getSuperclass();

		if (superClass != null && recursively) {
			Field[] declaredFieldsOfSuper = getDeclaredFields(superClass,
					recursively);
			if (declaredFieldsOfSuper.length > 0)
				Collections.addAll(fields, declaredFieldsOfSuper);
		}

		return fields.toArray(new Field[fields.size()]);
	}

	public List<Method> getMethodsAnnotatedWith(final Class<?> type,
			final Class<? extends Annotation> annotation) {
		final List<Method> methods = new ArrayList<Method>();
		Class<?> clazz = type;
		while (clazz != Object.class) { // need to iterated thought hierarchy in
										// order to retrieve methods from above
										// the current instance
			// iterate though the list of methods declared in the class
			// represented by clazz variable, and add those annotated with the
			// specified annotation
			final List<Method> allMethods = new ArrayList<Method>(
					Arrays.asList(clazz.getDeclaredMethods()));
			for (final Method method : allMethods) {
				if ((annotation == null || method
						.isAnnotationPresent(annotation))
						&& !method.getReturnType().equals(Void.TYPE)) {
					Annotation annotInstance = method.getAnnotation(annotation);
					// method.invoke(type, null);
					// TODO process annotInstance
					methods.add(method);
				}
			}
			// move to the upper class in the hierarchy in search for more
			// methods
			clazz = clazz.getSuperclass();
		}
		return methods;
	}

}
