package com.hcentive.billing.core.commons.record.util.annotation;

public interface RecordIdParser<T> {

	public String getRecordId(T type);

}
