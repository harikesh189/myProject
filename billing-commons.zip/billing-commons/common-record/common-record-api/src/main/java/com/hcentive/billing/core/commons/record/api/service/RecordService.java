package com.hcentive.billing.core.commons.record.api.service;

import java.util.Collection;

import com.hcentive.billing.core.commons.record.api.exception.RecordException;

public interface RecordService<T> {

	public Collection<T> findAll();

	public Collection<T> findByPayload(final T type);

	public T findbyRecordId(String recordId) throws RecordException;

	public Collection<T> findByStatus(final Collection<String> status);

	public boolean remove(final String id);

	public String save(T type) throws RecordException;

	// public Collection<T> findByReasons(final Collection<Reason> reasons);

	public Collection<T> fetchAllByRecordId(final String recordId);

	public T update(T t);

}
