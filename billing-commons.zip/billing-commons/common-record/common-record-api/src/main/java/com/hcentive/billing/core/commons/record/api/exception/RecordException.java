package com.hcentive.billing.core.commons.record.api.exception;

public class RecordException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RecordException() {
		super();
	}

	public RecordException(String message) {
		super(message);
	}

	public RecordException(String message, Throwable cause) {
		super(message, cause);
	}

}
