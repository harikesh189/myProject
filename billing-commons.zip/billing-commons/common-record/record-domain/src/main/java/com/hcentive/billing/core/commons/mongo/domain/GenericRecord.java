package com.hcentive.billing.core.commons.mongo.domain;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.vo.DateTime;

public class GenericRecord<T> implements Serializable, Record<T> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 546030625996954702L;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	protected String userName;

	protected String tenantId;

	protected DateTime timeStamp;

	protected T payload;

	protected String status;

	protected Integer version = 1;

	protected String recordId;

	protected String recordStatus = "NEW";

	/**
	 * 
	 */
	public GenericRecord() {
		super();
		User loggedinUser = Utils.getUser();
		if (null != loggedinUser) {
			this.tenantId = loggedinUser.getTenantId();
			this.userName = loggedinUser.getProfile().getDisplayName();
			this.timeStamp = DateTime.getCurrentTime();
		}
	}

	public GenericRecord(String recordId) {
		this.recordId = recordId;
	}

	public GenericRecord(String recordId, Integer version) {
		this.recordId = recordId;
		this.version = version;
	}

	public GenericRecord(T type) {
		this.payload = type;
	}

	public GenericRecord(T payload, String status) {
		this.payload = payload;
		this.status = status;
	}

	@Override
	public Map<String, Object> getMetaInfo() {
		return new HashMap<String, Object>();
	}

	@Override
	public T getPayload() {
		return this.payload;
	}

	@Override
	public String getRecordId() {
		return recordId;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public String getStatus() {
		return status;
	}

	public String getTenantId() {
		return tenantId;
	}

	public DateTime getTimeStamp() {
		return timeStamp;
	}

	public String getUserName() {
		return userName;
	}

	@Override
	public Integer getVersion() {
		return version;
	}

	public void setPayload(T payload) {
		this.payload = payload;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public void setTimeStamp(DateTime timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

}
