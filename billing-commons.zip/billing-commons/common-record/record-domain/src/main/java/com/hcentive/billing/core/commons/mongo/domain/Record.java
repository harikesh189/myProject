package com.hcentive.billing.core.commons.mongo.domain;

import java.util.Map;

public interface Record<T> {

	Map<String, Object> getMetaInfo();

	T getPayload();

	String getRecordId();

	Integer getVersion();

	// void updateRecordStatus(final String status);

}