package com.hcentive.billing.core.commons.mongo.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;

public class MongoRecord<T> extends GenericRecord<T> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	protected String id;

	private final List<T> payloads = new ArrayList<T>(1);

	public MongoRecord() {
		super();

	}

	public MongoRecord(T payload) {

		payloads.add(payload);
	}

	/**
	 * @param payloads
	 * @param recordId
	 */
	public MongoRecord(T payload, String recordId) {
		super(recordId);
		payloads.add(payload);
	}

	public MongoRecord(T type, String recordId, Integer version) {
		super(recordId, version);
		payloads.clear();
		payloads.add(type);

		// TODO Auto-generated constructor stub
	}

	@Override
	public T getPayload() {
		return payloads.get(0);
	}

}
