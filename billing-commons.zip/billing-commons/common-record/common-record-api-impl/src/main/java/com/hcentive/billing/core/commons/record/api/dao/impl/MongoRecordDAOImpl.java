package com.hcentive.billing.core.commons.record.api.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.hcentive.billing.core.commons.domain.VersionableEntity;
import com.hcentive.billing.core.commons.mongo.domain.MongoRecord;
import com.hcentive.billing.core.commons.mongo.domain.Record;
import com.hcentive.billing.core.commons.record.api.dao.RecordDao;
import com.hcentive.billing.core.commons.record.api.exception.RecordException;
import com.hcentive.billing.core.commons.record.api.service.impl.constants.RecordApiConstants;
import com.hcentive.billing.core.commons.record.util.annotation.RecordIdParser;

@Component
public class MongoRecordDAOImpl<T> implements RecordDao<T> {

	private static final Logger LOGGER = org.slf4j.LoggerFactory
			.getLogger(MongoRecordDAOImpl.class);

	@Value(value = "${spring.data.mongodb.database}")
	private String collectionName;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private RecordIdParser parser;

	private BasicQuery createCustomQueryForType(final T type) {
		final Gson g = new Gson();
		final String jsonObject = g.toJson(type);
		final BasicQuery basicQuery = new BasicQuery("{payloads:{$elemMatch:"
				+ jsonObject + "}}");
		return basicQuery;
	}

	/**
	 * @param type
	 * @param recordId
	 * @param record
	 * @return
	 */
	private Record<T> createRecordWithUpdatedVersion(final T type,
			final String recordId, final Record<T> record) {
		Integer newVersion = record.getVersion().intValue();
		final Record<T> updatedRecord = new MongoRecord<T>(type, recordId,
				newVersion + 1);
		mongoTemplate.save(updatedRecord, collectionName);
		LOGGER.debug("Record Updated  Successfully with the version"
				+ newVersion);
		return updatedRecord;
	}

	private MongoRecord fetchByRecordId(final String recordId) {
		LOGGER.debug("Fetching the record with record status NEW and recordId"
				+ recordId);
		return mongoTemplate.findOne(Query.query(Criteria
				.where(RecordApiConstants.RECORD_ID)
				.is(recordId)
				.andOperator(
						Criteria.where(RecordApiConstants.RECORD_STATUS).is(
								"NEW"))), MongoRecord.class, collectionName);
	}

	@Override
	public Collection<T> fetchAllByRecordId(final String recordId) {
		LOGGER.debug("Fetching all the records with recordId" + recordId);
		final Collection<MongoRecord> mongoRecrods = mongoTemplate.find(
				fetchQueryForRecordId(recordId), MongoRecord.class,
				collectionName);
		final List<T> types = new ArrayList<T>();
		for (MongoRecord mongoRecrod : mongoRecrods) {
			types.add((T) mongoRecrod.getPayload());
		}
		final Collection<T> typeCollections = Collections
				.unmodifiableList(types);
		LOGGER.debug("Returning the collection of type object successfully");
		return typeCollections;
	}

	private Query fetchQueryForRecordId(final String recordId) {
		LOGGER.debug("Fetching the record with recordId" + recordId);
		final Query query = Query.query(Criteria.where(
				RecordApiConstants.RECORD_ID).is(recordId));
		return query;
	}

	/*
	 * @Override public Collection<T> findByReasons(final Collection<Reason>
	 * reasons) { // TODO Auto-generated method stub return null; }
	 */

	@Override
	public Collection<T> findAll() {
		LOGGER.debug("finding all the records from database");
		Collection<MongoRecord> mongoRecrods = mongoTemplate.findAll(
				MongoRecord.class, collectionName);
		final List<T> types = new ArrayList<T>();
		for (MongoRecord mongoRecrod : mongoRecrods) {
			types.add((T) mongoRecrod.getPayload());
		}
		final Collection<T> typeCollections = Collections
				.unmodifiableList(types);
		LOGGER.debug("Returning the collection of type object successfully");
		return typeCollections;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Collection<T> findByPayload(final T type) {
		LOGGER.debug("Inside findByPayload:::");
		final BasicQuery basicQuery = createCustomQueryForType(type);
		final Collection<MongoRecord> mongoRecrods = mongoTemplate.find(
				basicQuery, MongoRecord.class, collectionName);
		final List<T> types = new ArrayList<T>();
		for (MongoRecord mongoRecrod : mongoRecrods) {
			types.add((T) mongoRecrod.getPayload());
		}
		final Collection<T> typeCollections = Collections
				.unmodifiableList(types);
		LOGGER.debug("Returning the collection of type object successfully");
		return typeCollections;
	}

	@Override
	public T findByRecordId(final String recordId) throws RecordException {
		// @SuppressWarnings("unchecked")
		if (recordId != null) {
			final Record<T> record = fetchByRecordId(recordId);
			if (record != null) {
				return record.getPayload();
			}
		} else {
			throw new RecordException("Record not found!!!");
		}
		return null;
	}

	@Override
	public Collection<T> findByStatus(final Collection<String> status) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param recordId
	 * @param record
	 */
	private void markCurrentRecordOld(final String recordId,
			final Record<T> record) {
		final Update update = new Update();
		update.set(RecordApiConstants.RECORD_STATUS, "OLD");
		LOGGER.debug("Updating the record with status OLD");
		mongoTemplate.updateFirst(fetchQueryForRecordId(recordId), update,
				MongoRecord.class, collectionName);
	}

	@Override
	public boolean remove(final String recordId) {
		if (recordId != null) {
			LOGGER.debug("Removing All the record with the recordId" + recordId);
			final Query query = fetchQueryForRecordId(recordId);
			mongoTemplate.remove(query, MongoRecord.class, collectionName);
			LOGGER.debug("Record removed  Successfully");
			return true;

		} else {
			return false;
		}
	}

	@Override
	public String save(T type) throws RecordException {
		LOGGER.debug("SAving the record in the db" + type);
		return saveOrUpdate(type);
	}

	private String saveOrUpdate(T type) throws RecordException {
		final String recordId = parser.getRecordId(type);
		if (null == recordId)
			throw new RecordException("No recordId found!!!");

		@SuppressWarnings("unchecked")
		final Record<T> record = fetchByRecordId(recordId);
		if (record != null) {
			if (record.getPayload() instanceof VersionableEntity) {
				LOGGER.debug("Record being updatable with new version");
				updateWithNewVersion(type, recordId, record);

			} else {
				LOGGER.debug("Record being updatable without version");
				updateWithoutVersion(type, recordId);

			}
		} else {
			final Record<T> newRecord = new MongoRecord<T>(type, recordId);
			mongoTemplate.save(newRecord, collectionName);
		}
		return recordId;
	}

	@PostConstruct
	public void saveCollection() throws Exception {
		boolean exists = mongoTemplate.collectionExists(collectionName);
		if (exists) {
			LOGGER.debug("Collection already exists with name" + collectionName);
		} else {

			LOGGER.debug(" Creating the new Collection  with name"
					+ collectionName);
			mongoTemplate.createCollection(collectionName);
		}

	}

	@Override
	public T update(T type) {
		final String recordId = parser.getRecordId(type);
		@SuppressWarnings("unchecked")
		final Record<T> record = fetchByRecordId(recordId);
		if (record != null) {
			if (record.getPayload() instanceof VersionableEntity) {
				LOGGER.debug("Record being updatable with new version");
				return updateWithNewVersion(type, recordId, record);

			} else {
				LOGGER.debug("Record being updatable without version");
				return updateWithoutVersion(type, recordId);

			}
		} else {
			final Record<T> newRecord = new MongoRecord<T>(type, recordId);
			mongoTemplate.save(newRecord, collectionName);
			return type;

		}
	}

	/**
	 * @param type
	 * @param recordId
	 * @param record
	 * @return
	 */
	private T updateWithNewVersion(T type, final String recordId,
			final Record<T> record) {
		LOGGER.debug("Updating the record in the db" + record.getRecordId());
		markCurrentRecordOld(recordId, record);
		Record<T> updatedRecord = createRecordWithUpdatedVersion(type,
				recordId, record);
		return updatedRecord.getPayload();
	}

	/**
	 * @param type
	 * @param recordId
	 * @return
	 */
	private T updateWithoutVersion(T type, final String recordId) {
		final Update update = new Update();
		final List<T> types = new ArrayList<T>(1);
		types.add(type);
		update.set("payloads", types);
		mongoTemplate.updateFirst(fetchQueryForRecordId(recordId), update,
				MongoRecord.class, collectionName);
		return type;
	}

}
