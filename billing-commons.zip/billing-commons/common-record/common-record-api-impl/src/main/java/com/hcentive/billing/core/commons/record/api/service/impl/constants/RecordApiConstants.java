package com.hcentive.billing.core.commons.record.api.service.impl.constants;

public interface RecordApiConstants {

	public static final String RECORD_ID = "recordId";
	public static final String RECORD_STATUS = "recordStatus";

}
