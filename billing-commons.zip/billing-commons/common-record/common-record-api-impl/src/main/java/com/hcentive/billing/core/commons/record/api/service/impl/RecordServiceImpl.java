package com.hcentive.billing.core.commons.record.api.service.impl;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.record.api.dao.RecordDao;
import com.hcentive.billing.core.commons.record.api.exception.RecordException;
import com.hcentive.billing.core.commons.record.api.service.RecordService;

@Component
public class RecordServiceImpl<T> implements RecordService<T> {

	@Autowired
	private RecordDao<T> recordDao;

	@Override
	public Collection<T> findAll() {
		return recordDao.findAll();
	}

	@Override
	public Collection<T> findByPayload(final T type) {
		return recordDao.findByPayload(type);
	}

	@Override
	public T findbyRecordId(String recordId) throws RecordException {
		return recordDao.findByRecordId(recordId);
	}

	@Override
	public Collection<T> findByStatus(Collection<String> status) {
		return recordDao.findByStatus(status);
	}

	@Override
	public boolean remove(String id) {
		return recordDao.remove(id);
	}

	@Override
	public String save(T type) throws RecordException {
		return recordDao.save(type);
	}

	/*
	 * @Override public Collection<T> findByReasons(Collection<Reason> reasons)
	 * { return recordDao.findByReasons(reasons); }
	 */

	@Override
	public T update(T t) {
		return recordDao.update(t);
	}

	@Override
	public Collection<T> fetchAllByRecordId(String recordId) {
		return recordDao.fetchAllByRecordId(recordId);
	}
}
