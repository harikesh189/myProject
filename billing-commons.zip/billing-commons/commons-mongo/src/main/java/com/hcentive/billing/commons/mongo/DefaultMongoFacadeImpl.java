/**
 *
 */
package com.hcentive.billing.commons.mongo;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.authentication.UserCredentials;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.CustomConversions;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.DocumentEntity;
import com.hcentive.billing.core.commons.domain.converter.ClassTypeReadConverter;
import com.hcentive.billing.core.commons.domain.converter.ClassTypeWriteConverter;
import com.hcentive.billing.core.commons.domain.converter.MongoFacade;
import com.hcentive.billing.core.commons.domain.converter.MongoFacadeFactory;
import com.mongodb.Mongo;

@Component
public class DefaultMongoFacadeImpl implements MongoFacade {

	private static Logger logger = LoggerFactory.getLogger(DefaultMongoFacadeImpl.class);

	@Autowired
	private Mongo mongo;

	private MongoTemplate mongoTemplate;

	@Value("${spring.data.mongodb.database}")
	private String dbname;

	@Value("${spring.data.mongodb.password:}")
	private String password;

	@Value("${spring.data.mongodb.username:}")
	private String username;

	public DefaultMongoFacadeImpl() {
		logger.trace("Creating MongoTemplateUtil");
	}

	@PostConstruct
	public void init() {
		try {
			logger.trace("Creating Mongo Client ");

			final UserCredentials userCredentials = new UserCredentials(this.username, this.password);
			final MongoDbFactory mongoDbFactory = new SimpleMongoDbFactory(this.mongo, this.dbname, userCredentials);

			final MappingMongoConverter mappingMongoConverter = new MappingMongoConverter(new DefaultDbRefResolver(mongoDbFactory), new MongoMappingContext());
			mappingMongoConverter.setCustomConversions(new CustomConversions(asList(new ClassTypeWriteConverter(), new ClassTypeReadConverter())));
			mappingMongoConverter.afterPropertiesSet();

			this.mongoTemplate = new MongoTemplate(mongoDbFactory, mappingMongoConverter);

			MongoFacadeFactory.registerMongoFacade(this);

			logger.trace("Mongo Client Created");
		} catch (final Exception e) {
			logger.error("Unable to create mongo client", ExceptionUtils.getFullStackTrace(e));
		}
	}

	@Override
	public <T extends DocumentEntity> T findByIdentity(final String identity, final Class<T> type) {
		final T t = this.mongoTemplate.findById(identity, type);
		return t;
	}

	@Override
	public Object saveObject(final Object object) {
		this.mongoTemplate.save(object);
		return object;
	}

	@Override
	public MongoTemplate getMongoTemmplate() {

		return this.mongoTemplate;
	}

}