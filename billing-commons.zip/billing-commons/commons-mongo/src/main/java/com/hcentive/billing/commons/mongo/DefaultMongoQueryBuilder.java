package com.hcentive.billing.commons.mongo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.core.commons.vo.ProjectedField;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteriaOnColumns;

@Component
public class DefaultMongoQueryBuilder implements QueryBuilder {

	@Value("${mongo.array.field.identifier:$}")
	private String mongoArrayFieldIdentifier;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DefaultMongoQueryBuilder.class);

	@SuppressWarnings("deprecation")
	@Override
	public Query buildQuery(SearchCriteria searchCriteria) {

		LOGGER.debug("starting buid searchcriteria");

		if (null == searchCriteria || null == searchCriteria.getCriteria()
				|| searchCriteria.getCriteria().isEmpty())
			return new Query();

		final Map<String, SearchCriteriaOnColumns> criteria = searchCriteria
				.getCriteria();
		Criteria mongoCriteria = null;
		List<Criteria> criteriaList = new ArrayList<>();
		for (Entry<String, SearchCriteriaOnColumns> mapEntry : criteria
				.entrySet()) {
			if (null == mongoCriteria) {
				mongoCriteria = buildCriteria(mapEntry);
			} else {
				criteriaList.add(buildCriteria(mapEntry));
			}
		}
		if (criteriaList.size() > 0) {
			mongoCriteria.andOperator(criteriaList
					.toArray(new Criteria[criteriaList.size()]));
		}
		
		/**
		 * Set projected fields on query object.
		 */
		Query query = new Query(mongoCriteria);
		
		final Set<ProjectedField> projectedFields = searchCriteria
				.getProjectedFields();
		for (final ProjectedField projectedField : projectedFields) {
			query.fields().include(projectedField.getEntityField());
		}
		

		LOGGER.debug("Mongo query:::" + query.toString());
		return query;
	}

	private Criteria buildCriteria(Entry<String, SearchCriteriaOnColumns> entry) {
		if (isNonCollectionField(entry.getKey())) {
			return buildNonCollectionCriteria(entry);
		} else {
			return buildCollectionCriteria(entry);
		}
	}

	private Criteria buildCollectionCriteria(
			Entry<String, SearchCriteriaOnColumns> entry) {
		final String fetchColumKey = entry.getKey();
		final List<String> tokens = createCriteriaList(fetchColumKey);
		LOGGER.debug("tokens :" + tokens.toString());
		return createCriteriaFromToken(tokens, entry);
	}

	private List<String> createCriteriaList(final String fetchColumKey) {
		StringTokenizer stringTokenizer = new StringTokenizer(fetchColumKey,
				"$");
		List<String> tokens = new ArrayList<>();

		while (stringTokenizer.hasMoreTokens()) {
			tokens.add(stringTokenizer.nextElement().toString());

		}
		return tokens;
	}

	private Criteria createCriteriaFromToken(List<String> tokens,
			Entry<String, SearchCriteriaOnColumns> entry) {

		if (tokens.size() > 1) {
			final String key = tokens.get(0);
			tokens.remove(0);
			return Criteria.where(key).elemMatch(
					createCriteriaFromToken(tokens, entry));
		} else {
			final Criteria criteria = Criteria.where(tokens.get(0));
			appendMongoOperator(criteria, entry.getValue());
			return criteria;

		}

	}

	private Criteria buildNonCollectionCriteria(
			Entry<String, SearchCriteriaOnColumns> entry) {
		LOGGER.debug("building criteria for non collection .");
		final Criteria criteria = Criteria.where(entry.getKey());
		appendMongoOperator(criteria, entry.getValue());
		return criteria;

	}

	private void appendMongoOperator(Criteria criteria,
			SearchCriteriaOnColumns searchCriteriaOnColumns) {
		LOGGER.debug("resolve operator for mongo .");
		switch (searchCriteriaOnColumns.getOperator().toUpperCase()) {
		case "LIKE":
			if(!isSpecialSymbol(searchCriteriaOnColumns.getColumnValueObject()
					.toString())){
				criteria.regex(searchCriteriaOnColumns.getColumnValueObject() !=null ? "\\"+searchCriteriaOnColumns.getColumnValueObject()
						.toString():"", "i");
			}else
			criteria.regex(searchCriteriaOnColumns.getColumnValueObject() !=null ? searchCriteriaOnColumns.getColumnValueObject()
					.toString():"", "i");
			break;
		case "=":
			criteria.is(searchCriteriaOnColumns.getColumnValueObject());
			break;
		case "IN":
			criteria.in(searchCriteriaOnColumns.getColumnValueObject() !=null ? searchCriteriaOnColumns.getColumnValue().split(","):"".split(","));
			break;
		case "NOT IN":
			criteria.nin(searchCriteriaOnColumns.getColumnValueObject() !=null ? searchCriteriaOnColumns.getColumnValue().split(",") :"".split(","));
			break;
		case "BETWEEN":
			buildDateRangeCriteria(criteria, searchCriteriaOnColumns);
			break;
		case "<=":
			criteria.lte(searchCriteriaOnColumns.getColumnValueObject()!=null ? searchCriteriaOnColumns.getColumnValue(): "");
			break;
		case ">=":
			criteria.gte(searchCriteriaOnColumns.getColumnValueObject()!=null ? searchCriteriaOnColumns.getColumnValue(): "");
			break;
		case "GTE_DATE":
			if(searchCriteriaOnColumns.getColumnValueObject() !=null){
				Date inputDate = null ;
				try {
					inputDate = fromatDateForMongo(searchCriteriaOnColumns.getColumnValueObject().toString());
					criteria.gte(inputDate);
				} catch (Exception e) {
					criteria.gte("");
				}
				
			}
			else{
				criteria.gte("");
			}
			break;
			
		case "LTE_DATE":
			if(searchCriteriaOnColumns.getColumnValueObject() !=null){
				Date inputDate =null;
				try {
					inputDate = fromatDateForMongo(searchCriteriaOnColumns.getColumnValueObject().toString());
					criteria.lte(inputDate);
				} catch (Exception e) {
					criteria.lte("");
				}
				
			}
			else{
				criteria.lte("");
			}
			break;
		case "BETWEEN_NUMBER":
			
			buildNumberRangeCriteria(criteria, searchCriteriaOnColumns);
			break;
		default:
			break;
		}

	}

	private void buildNumberRangeCriteria(Criteria criteria,
			SearchCriteriaOnColumns searchCriteriaOnColumns) {
		final String rangeValue = searchCriteriaOnColumns.getColumnValue();
		final String[] rangeValues = rangeValue.split("AND");
		final Long[] numberRangeValues = new Long[2];
		for (int i = 0; i < rangeValues.length; ++i) {
			numberRangeValues[i] = Long.parseLong(rangeValues[i].trim());
		}
		if (null != rangeValues && rangeValues.length > 1) {
			criteria.gte(numberRangeValues[0]).lte(numberRangeValues[1]);

		}
	}
	private void buildDateRangeCriteria(Criteria criteria,
			SearchCriteriaOnColumns searchCriteriaOnColumns) {
		final String rangeValue = searchCriteriaOnColumns.getColumnValue();
		final String[] rangeValues = rangeValue.split("AND");
		
		for(int i=0;i<rangeValues.length;++i){
			rangeValues[i] = rangeValues[i].trim();
		}
		
		if (null != rangeValues && rangeValues.length > 1) {
			final SimpleDateFormat sdf = DateUtility.defaultDateFormat();
			Date startdate = null;
			Date enddate = null;
			try {
				startdate = sdf.parse(rangeValues[0]);
				enddate = sdf.parse(rangeValues[1]);
				criteria.gte(startdate).lte(enddate);
			} catch (Exception e) {
				LOGGER.error("error while parsing input as dates", e);
				LOGGER.error("Assuming input values are not for dates. Treating inputs {}, {} as normal long values. ",rangeValues[0],rangeValues[1]);
				criteria.gte(Long.parseLong(rangeValues[0])).lte(Long.parseLong(rangeValues[1]));
			}
		}else{
			LOGGER.debug("No of paramerters are not valid for between query");
		}
	}

	private boolean isNonCollectionField(String field) {
		LOGGER.debug("isNonCollectionField::");
		if (null == field || field.isEmpty())
			throw new IllegalArgumentException("Invalid criterian.");
		return field.contains(mongoArrayFieldIdentifier) ? false : true;
	}

	private boolean isSpecialSymbol(String str){
		
		return !str.matches("[^a-z0-9]");
	}



private Date fromatDateForMongo(String dateInput ) {
	final SimpleDateFormat sdf = DateUtility.defaultDateFormat();
	 
	 try {
		 return sdf.parse(dateInput);
		} catch (Exception e) {
			LOGGER.error("error while parsing input as dates", e);
			LOGGER.error("Assuming input value is not for date. Given input is : " + dateInput );
			return null;
		}
}
}