/**
 *
 */
package com.hcentive.billing.commons.mongo.listener;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.stereotype.Component;

@Component
public class MongoDocumentValidator<T> extends AbstractMongoEventListener<T> {

	private static final Logger log = LoggerFactory
			.getLogger(MongoDocumentValidator.class);

	@Autowired
	@Qualifier(value = "localValidatorFactoryBean")
	private Validator validator;

	@Override
	public void onBeforeConvert(final T source) {

		log.trace("onBeforeConvert Java validator for {} start", source
				.getClass().getName());
		final Set<ConstraintViolation<T>> validationResult = this.validator
				.validate(source);
		if (validationResult.size() > 0) {
			final ConstraintViolationException constraintViolationException = new ConstraintViolationException(
					validationResult);
			final Set<ConstraintViolation<?>> constraintViolations = constraintViolationException
					.getConstraintViolations();
			for (final ConstraintViolation<?> v : constraintViolations) {
				log.error(
						"\nConstraintViolation for object {}.Error - {}, Error Object(s) - {} ",
						source, v.getMessage(), v.getInvalidValue());
			}
			throw constraintViolationException;
		}
		log.trace("onBeforeConvert Java validator for {} end", source
				.getClass().getName());
	}
}
