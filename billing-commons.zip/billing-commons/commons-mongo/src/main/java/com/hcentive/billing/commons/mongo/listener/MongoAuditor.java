/**
 * 
 */
package com.hcentive.billing.commons.mongo.listener;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * Return user id from process context to be used while auditing a mongo
 * document.
 * 
 * @author Kumar Sambhav Jain
 */
@Component
public class MongoAuditor implements AuditorAware<String> {

	@Override
	public String getCurrentAuditor() {
		return ProcessContext.get() != null ? ProcessContext.get().getUserId()
				: null;
	}

}
