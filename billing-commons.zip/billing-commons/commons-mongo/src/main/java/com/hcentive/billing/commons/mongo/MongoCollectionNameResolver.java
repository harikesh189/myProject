package com.hcentive.billing.commons.mongo;

public interface MongoCollectionNameResolver {

	public <T> String resolveCollectionName(Class<T> clazz);

}
