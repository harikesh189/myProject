package com.hcentive.billing.commons.mongo;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;

import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mapping.context.MappingContext;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.CustomConversions;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;

public final class MongoTemplateBuilder {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(MongoTemplateBuilder.class);

	private MongoTemplateBuilder() {
	}

	public static class Builder {

		private String dbName;
		private List<Converter> converters;
		private List<ServerAddress> servers;

		public Builder withDBName(final String dbName) {
			if (null == dbName || dbName.isEmpty()) {
				throw new IllegalArgumentException(
						"Db name cannot be null or empty");
			}
			this.dbName = dbName;
			return this;
		}

		public Builder withConverters(final Converter... converters) {
			return this.withConverters(asList(converters));
		}

		public Builder withConverters(final List<Converter> converters) {
			this.converters = Collections.unmodifiableList(converters);
			return this;
		}

		public Builder withServerList(final ServerAddress... addresses) {
			this.servers = Arrays.asList(addresses);
			return this;
		}

		public MongoTemplate build() throws Exception {

			MongoClient client = null;
			if (null != this.servers && !this.servers.isEmpty()) {
				LOGGER.debug("creating mongo client with  servers {}",
						this.servers);
				client = new MongoClient(this.servers);
			} else {
				LOGGER.debug("creating mongo clinet with default localhost");
				client = new MongoClient();
			}

			if (null != this.dbName && null != this.converters) {
				LOGGER.debug("Building mongo template with db and converters");
				return this.buildWithDbAndConverters(client);
			} else if (null != this.dbName) {
				LOGGER.debug("Building mongo template with db only");
				return this.buildWithDB(client);
			}
			throw new IllegalArgumentException("Cannot create mongoTemplate");

		}

		private MongoTemplate buildWithDB(final MongoClient client)
				throws UnknownHostException {
			final MongoDbFactory factory = new SimpleMongoDbFactory(client,
					this.dbName);
			final MongoTemplate template = new MongoTemplate(factory);
			LOGGER.debug("Mongo template Created buildWithDB");
			return template;
		}

		private MongoTemplate buildWithDbAndConverters(final MongoClient client)
				throws UnknownHostException {
			final MongoDbFactory factory = new SimpleMongoDbFactory(client,
					this.dbName);
			final DbRefResolver dbRefResolver = new DefaultDbRefResolver(
					factory);
			final MappingContext mappingContext = new MongoMappingContext();
			final MappingMongoConverter converter = new MappingMongoConverter(
					dbRefResolver, mappingContext);
			converter.setCustomConversions(new CustomConversions(
					this.converters));
			converter.afterPropertiesSet();
			final MongoTemplate template = new MongoTemplate(factory, converter);
			LOGGER.debug("Mongo template Created buildWithDbAndConverters");
			return template;
		}
	}

	public static Builder builder() {
		return new Builder();
	}

}
