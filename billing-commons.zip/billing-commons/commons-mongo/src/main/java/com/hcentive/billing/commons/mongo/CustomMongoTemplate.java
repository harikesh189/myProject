package com.hcentive.billing.commons.mongo;

import java.lang.reflect.Method;
import java.util.List;

import org.springframework.data.authentication.UserCredentials;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.MongoConverter;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.util.ReflectionUtils;

import com.mongodb.Mongo;

public class CustomMongoTemplate extends MongoTemplate {

	/**
	 * Constructor used for a basic template configuration
	 *
	 * @param mongo
	 *            must not be {@literal null}.
	 * @param databaseName
	 *            must not be {@literal null} or empty.
	 */
	public CustomMongoTemplate(final Mongo mongo, final String databaseName) {
		super(mongo, databaseName);
	}

	/**
	 * Constructor used for a template configuration with user credentials in
	 * the form of
	 * {@link org.springframework.data.authentication.UserCredentials}
	 *
	 * @param mongo
	 *            must not be {@literal null}.
	 * @param databaseName
	 *            must not be {@literal null} or empty.
	 * @param userCredentials
	 */
	public CustomMongoTemplate(final Mongo mongo, final String databaseName, final UserCredentials userCredentials) {
		super(mongo, databaseName, userCredentials);
	}

	/**
	 * Constructor used for a basic template configuration.
	 *
	 * @param mongoDbFactory
	 *            must not be {@literal null}.
	 */
	public CustomMongoTemplate(final MongoDbFactory mongoDbFactory) {
		super(mongoDbFactory);
	}

	/**
	 * Constructor used for a basic template configuration.
	 *
	 * @param mongoDbFactory
	 *            must not be {@literal null}.
	 * @param mongoConverter
	 */
	public CustomMongoTemplate(final MongoDbFactory mongoDbFactory, final MongoConverter mongoConverter) {
		super(mongoDbFactory, mongoConverter);
	}

	@Override
	public <T> List<T> find(final Query query, final Class<T> entityClass, String collectionName) {
		try {
			final Method determineCollectionNameMethod = ReflectionUtils.findMethod(MongoTemplate.class,
					"determineCollectionName", null);
			ReflectionUtils.makeAccessible(determineCollectionNameMethod);
			if(collectionName == null){
				collectionName = (String) determineCollectionNameMethod.invoke(this, entityClass);
			}
		} catch (final Exception e) {
			throw new RuntimeException("Unable to determine collection name for " + entityClass, e);
		}
		return super.find(query, entityClass, collectionName);
	}
}
