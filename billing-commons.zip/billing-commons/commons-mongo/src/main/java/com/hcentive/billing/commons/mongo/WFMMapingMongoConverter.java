package com.hcentive.billing.commons.mongo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mapping.context.MappingContext;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoPersistentEntity;
import org.springframework.data.mongodb.core.mapping.MongoPersistentProperty;

import com.hcentive.billing.commons.mongo.repository.MongoSearchContext;
import com.mongodb.DBObject;

public class WFMMapingMongoConverter extends MappingMongoConverter {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(WFMMapingMongoConverter.class);

	public WFMMapingMongoConverter(
			DbRefResolver dbRefResolver,
			MappingContext<? extends MongoPersistentEntity<?>, MongoPersistentProperty> mappingContext) {
		super(dbRefResolver, mappingContext);
		LOGGER.debug("WFM Mapping mongo converter initialized");
	}

	public <S extends Object> S read(Class<S> clazz, DBObject dbo) {
		LOGGER.debug("Starting to read DBOject");
		final MongoSearchContext mongoSearchContext = MongoSearchContext.get();
		if (isSubDocumentSearch(mongoSearchContext)) {
			LOGGER.debug("Its a sub document search");
			final String subDocTag = mongoSearchContext.getSubDocumentTag();
			LOGGER.debug("Sub item tag is {} ",subDocTag);
			if (null != dbo.get(subDocTag)) {
				dbo = (DBObject) dbo.get(subDocTag);
			}
		}
		LOGGER.debug("Reading DBObject finish. Calling super");
		return super.read(clazz, dbo);
	}

	private boolean isSubDocumentSearch(final MongoSearchContext mongoSearchContext) {
		return null != mongoSearchContext
				&& null != mongoSearchContext.getSubDocumentTag()
				&& !mongoSearchContext.getSubDocumentTag().isEmpty();
	}
}
