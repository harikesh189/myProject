package com.hcentive.billing.commons.mongo.repository;

import static com.hcentive.billing.core.commons.util.StringValidator.isNotBlank;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.hcentive.billing.commons.mongo.MongoCollectionNameResolver;
import com.hcentive.billing.commons.mongo.QueryBuilder;
import com.hcentive.billing.core.commons.domain.converter.PageableTransformer;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

@Component
public class MongoFilterSupportRepositoryImpl implements
		MongoFilterSupportRepository {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(MongoFilterSupportRepositoryImpl.class);

	@Autowired
	private MongoCollectionNameResolver collectionResolver;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private QueryBuilder queryBuilder;

	@Override
	public <T> List<T> executeQuery(final Class<T> clazz, final Query query, final String collectionName) {
		return mongoTemplate.find(query, clazz, collectionName);
	}

	@Override
	public <T> Page<T> findByFilterCriteria(final Class<T> domain,
			final SearchCriteria criteria) {
		return this.findByFilterCriteria(domain, criteria, null);
	}

	@Override
	public <T> Page<T> findByFilterCriteria(final Class<T> domain,
			final SearchCriteria criteria, String collectionName) {

		LOGGER.debug("Find the domain" + domain
				+ "on basis of search criteria {}", criteria);
		final Query mongoQuery = this.queryBuilder.buildQuery(criteria);
		collectionName = this.resolveCollectionName(collectionName, domain);
		// collectionName = TenantUtil.getMongoSpecificTeanant()+
		// collectionName;
		LOGGER.debug("collection name :: {},tenant id :: {}", collectionName,
				TenantUtil.getTenantId());

		final long totalCount = mongoTemplate.count(mongoQuery, collectionName);
		LOGGER.debug("total no of element for the query {} is {}",
				mongoQuery.toString(), totalCount);
		final Pageable pageable = PageableTransformer.INSTANCE
				.transform(criteria.getPageRequestCriteria());
		mongoQuery.with(pageable);
		final List<T> list = this.mongoTemplate.find(mongoQuery, domain,
				collectionName);
		// final List<T> list = this.mongoTemplate.findAll(domain,
		// collectionName);
		LOGGER.debug("No of records in mongodb for the given criteia {}",
				list.size());
		final Page<T> pageResult = new PageImpl<>(list, pageable, totalCount);
		LOGGER.debug("Creating the pageresult {}", pageResult.getSize());
		return pageResult;

	}

	private String resolveCollectionName(final String collectionName,
			final Class clazz) {
		if (isNotBlank(collectionName)) {
			LOGGER.debug("returning collection name");
			return collectionName;
		}
		if (isNotBlank(this.collectionResolver.resolveCollectionName(clazz))) {
			LOGGER.debug("returning collection name from resolver");
			return this.collectionResolver.resolveCollectionName(clazz);
		}
		LOGGER.debug("returning default collection name");
		return this.mongoTemplate.getCollectionName(clazz);

	}

	@Override
	public <T> void save(T t, Class<T> domain) {
		LOGGER.debug("saving domain with colelction");
		final String collectionName = this.resolveCollectionName(null, domain);
		LOGGER.debug("Resloved collection name is {}", collectionName);
		saveDomain(t, collectionName);
	}

	@Override
	public <T> void save(T t, String colletionName) {
		LOGGER.debug("saving domain with colelction");
		saveDomain(t, colletionName);
	}

	private <T> void saveDomain(T t, final String collectionName) {
		mongoTemplate.save(t, collectionName);
	}

	@Override
	public <T, M> Page<T> findSubDocument(SearchCriteria criteria,
			String collectionName, Class<T> subDoc, String subDocTag) {
		MongoSearchContext.initialize(subDocTag);
		Page<T> result =  findByFilterCriteria(subDoc, criteria, collectionName);
		MongoSearchContext.clear();
		return result;

	}

}
