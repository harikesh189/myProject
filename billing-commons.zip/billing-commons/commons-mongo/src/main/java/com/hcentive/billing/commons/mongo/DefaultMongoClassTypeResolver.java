package com.hcentive.billing.commons.mongo;

public class DefaultMongoClassTypeResolver implements MongoClassTypeResolver {

	@Override
	public Class getCollectionClassType(final Class clazz) {
		return clazz;
	}

}
