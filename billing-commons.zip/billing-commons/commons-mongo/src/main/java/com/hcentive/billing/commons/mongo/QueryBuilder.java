package com.hcentive.billing.commons.mongo;

import org.springframework.data.mongodb.core.query.Query;

import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface QueryBuilder {

	public Query buildQuery(SearchCriteria searchCriteria);

}
