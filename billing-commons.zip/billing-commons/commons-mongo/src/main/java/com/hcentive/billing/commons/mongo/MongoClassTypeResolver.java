package com.hcentive.billing.commons.mongo;

public interface MongoClassTypeResolver<D, T> {

	public Class getCollectionClassType(Class clazz);

}
