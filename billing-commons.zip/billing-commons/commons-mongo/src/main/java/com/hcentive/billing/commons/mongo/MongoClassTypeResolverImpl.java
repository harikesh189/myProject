package com.hcentive.billing.commons.mongo;

public class MongoClassTypeResolverImpl implements MongoClassTypeResolver {

	@Override
	public Class getCollectionClassType(final Class clazz) {
		return clazz;

	}

}
