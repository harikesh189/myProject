package com.hcentive.billing.commons.mongo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.mongodb.core.query.Query;

import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface MongoFilterSupportRepository {

	public <T> List<T> executeQuery(Class<T> clazz, Query query, String collectionName);

	public <T> Page<T> findByFilterCriteria(Class<T> domain,
			SearchCriteria criteria);

	public <T> Page<T> findByFilterCriteria(Class<T> domain,
			SearchCriteria criteria, String collectionName);
	
	public <T> void  save(T t,Class<T> domain);
	
	public <T> void  save(T t,String colletionName);
	
	public <T, M> Page<T> findSubDocument(SearchCriteria criteria, String collectionName, Class<T> subDoc , String subDocTag);

}
