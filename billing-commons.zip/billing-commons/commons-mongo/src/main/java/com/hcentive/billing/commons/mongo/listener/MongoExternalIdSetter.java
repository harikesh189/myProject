package com.hcentive.billing.commons.mongo.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.ExternalIdAware;
import com.hcentive.billing.core.commons.id.ExternalIdGenerator;
import com.hcentive.billing.core.commons.util.StringValidator;
import com.mongodb.DBObject;

@Component
public class MongoExternalIdSetter extends AbstractMongoEventListener<ExternalIdAware> {

	@Autowired
	private ExternalIdGenerator idGenerator;
	
	public void onBeforeSave(ExternalIdAware source, DBObject dbo) {
		
		if (StringValidator.isBlank(source.getExternalId())) {
			String externalId = idGenerator.generateID(source);
			source.setExternalId(externalId);
			dbo.put("externalId",externalId);
		}
	
	}
	
}
