package com.hcentive.billing.commons.mongo;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CommonMongoConfig {

	@Bean
	@ConditionalOnMissingBean
	public QueryBuilder defaultMongoQueryBuilder() {
		return new DefaultMongoQueryBuilder();
	}

	@Bean
	@ConditionalOnMissingBean
	public MongoCollectionNameResolver defaultMongoCollectionNameResolver() {
		return new DefaultMongoCollectionResolver();
	}

}
