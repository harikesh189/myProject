package com.hcentive.billing.commons.mongo.repository;

public class MongoSearchContext {
	
	private String subDocumentTag;

	public static final ThreadLocal<MongoSearchContext> THREAD_LOCAL_MONGO_SEARCH_CONTEXT = new ThreadLocal<MongoSearchContext>();
	
	public MongoSearchContext(String subDocumentTag) {
		this.subDocumentTag = subDocumentTag;
	}

	public static void initialize(final String subDocumentTag){
		final MongoSearchContext mongoSearchContext = new MongoSearchContext(subDocumentTag);
		THREAD_LOCAL_MONGO_SEARCH_CONTEXT.set(mongoSearchContext);
	}
	
	public static MongoSearchContext get(){
		return THREAD_LOCAL_MONGO_SEARCH_CONTEXT.get();
	}
	
	public static void clear(){
		THREAD_LOCAL_MONGO_SEARCH_CONTEXT.remove();
	}

	public String getSubDocumentTag() {
		return subDocumentTag;
	}

	public void setSubDocumentTag(String subDocumentTag) {
		this.subDocumentTag = subDocumentTag;
	}

}
