package com.hcentive.billing.commons.mongo;

import java.util.HashMap;

public class DefaultMongoCollectionResolver implements
		MongoCollectionNameResolver {

	private static final HashMap<Class, String> collections = new HashMap<>();

	@Override
	public <T> String resolveCollectionName(final Class<T> clazz) {
		if (null != clazz && !collections.isEmpty()) {
			return collections.get(clazz);
		}
		return null;
	}

}
