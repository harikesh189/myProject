package com.hcentive.billing.core.dms.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.condition.ConditionalOnBeanNameAbsent;
import com.hcentive.billing.core.dms.api.impl.DefaultTenantBucketResolver;
import com.hcentive.billing.service.ebill.dms.resolver.TenantBucketResolver;

@Configuration
public class TenantBucketConfig {

	@Bean
	@ConditionalOnBeanNameAbsent
	public TenantBucketResolver tenantBucketResolver() {
		return new DefaultTenantBucketResolver();
	}

}
