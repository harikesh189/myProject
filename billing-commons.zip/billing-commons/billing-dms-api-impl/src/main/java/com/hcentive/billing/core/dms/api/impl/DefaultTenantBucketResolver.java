package com.hcentive.billing.core.dms.api.impl;

import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.service.ebill.dms.resolver.TenantBucketResolver;

public class DefaultTenantBucketResolver implements TenantBucketResolver {

	public String getTenantBucket() {
		final ProcessContext processContext = ProcessContext.get();
		if (processContext == null) {
			throw new IllegalArgumentException("No process Context found");
		} else {
			final String tenantId = processContext.getTenantId();
			if (tenantId != null) {
				return tenantId.toUpperCase();
			}

		}
		return null;
	}

}
