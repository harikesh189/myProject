package com.hcentive.billing.core.commons.service.ebill.audit.dto;

import java.io.Serializable;
import java.util.Map;

public class AuditRecordData implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String referenceId;
	
	private String failureReason;
	
	private String beIdentity;
	
	private Map<String, String> arguments;
	
	private String contractId;
	
	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

	public String getBeIdentity() {
		return beIdentity;
	}

	public void setBeIdentity(String beIdentity) {
		this.beIdentity = beIdentity;
	}

	public Map<String, String> getArguments() {
		return arguments;
	}

	public void setArguments(Map<String, String> arguments) {
		this.arguments = arguments;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

}
