package com.hcentive.billing.core.commons.service.ebill.audit.handler;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.audit.ActivityLog;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditMessage;
import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.domain.audit.MessageReference;
import com.hcentive.billing.core.commons.domain.audit.SimpleActivityLog;
import com.hcentive.billing.core.commons.domain.audit.SimpleObjectChangeLog;
import com.hcentive.billing.core.commons.domain.audit.StringMessage;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.service.ebill.audit.dto.AuditRecord;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * @author Ankit.Garg
 * 
 *         Audit Util Class for auditing the data
 * 
 */
public class AuditUtil {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AuditUtil.class);

	public static final String ACTIVITY = "_activity_";

	/**
	 * @param auditEventType
	 * 
	 *            AuditEventType.EventType is the type of event for which you
	 *            want to log. These events are created by the audit project and
	 *            currently available event types are PAYMENT,USER,OTHER.
	 * 
	 * @param msgKey
	 * 
	 *            msgKey is the key which is saved in auditmsg table of audit
	 *            db. This is key against which audit message will be fetched
	 *            from auditmsg from msg column.
	 * 
	 *            One has to create insert scripts for his audit message.
	 *            Message could be of two type: Fixed message: Audit message
	 *            which is fixed for particular audit event. Placeholder message
	 *            : An audit message could have placeholders, for which input
	 *            should be provided by the user. key , values provided by users
	 *            will replaced placeholders before logging the audit message in
	 *            db. placeholder format used here is ${placeholder}. e.g. :
	 *            Payment for transaction id ${transactionId} has been
	 *            completed.
	 * @param args
	 * 
	 *            String... args : multiple String (key, value) pair. Odd
	 *            strings should be key and even strings their values. These
	 *            key, value pair will be used to replace placeholders (if any)
	 *            from the audit message fetched from auditMsg table.
	 */
	public static void audit(final AuditEventType auditEventType,
			final AuditWorkStatus workStatus, final String referenceId,
			final String beIdentity, final String contractId,
			final String failureReason, final String msg) {
		
		audit(auditEventType, workStatus, referenceId, beIdentity, contractId, 
				failureReason, new StringMessage(msg));
		
	}
	
	public static void audit(final AuditEventType auditEventType,
			final AuditWorkStatus workStatus, final String referenceId,
			final String beIdentity, final String contractId, final String failureReason, 
			final AuditMessageDefinition msg, String... args) {
		
		MessageReference<AuditMessageDefinition> message = createAuditMessage(
				msg, args);
		
		audit(auditEventType, workStatus, referenceId, beIdentity, contractId, 
				failureReason, message);
		
	}

	public static MessageReference<AuditMessageDefinition> createAuditMessage(
			final AuditMessageDefinition msg, String... args) {
		MessageReference<AuditMessageDefinition> message = new MessageReference<AuditMessageDefinition>(msg);
		
		Map<String, String> argsMap = buildArgsMap(args);
		addProcessContextArgs(argsMap);
		
		message.setArguments(argsMap);
		return message;
	}
	
	private static void addProcessContextArgs(Map<String, String> argsMap) {
		final ProcessContext loggedInUserPC = ProcessContext.get();
		
		if (loggedInUserPC != null) {
			
			String userName = loggedInUserPC.getUserName();
			String userId = loggedInUserPC.getUserId();
			
			if(!argsMap.containsKey("username")){
				argsMap.put("username", userName);
			}
			if(!argsMap.containsKey("userId")){
				argsMap.put("userId", userId);
			}
		}
	}
	
	private static Map<String, String> buildArgsMap(String[] args) {
		
		final Map<String, String> arguments = new HashMap<String, String>(
				args.length);

		boolean value = false;
		String key = null;
		for (String auditKeyValue : args) {
			if (!value) {
				key = auditKeyValue;
				value = true;
			} else {
				arguments.put(key, auditKeyValue);
				value = false;
			}
		}
		
		return arguments;
	}
	
	public static void audit(final AuditEventType auditEventType,
			final AuditWorkStatus workStatus, final String referenceId,
			final String beIdentity, final String contractId,
			final String failureReason, final AuditMessage message) {

		LOGGER.debug("doing audit.");

		final ProcessContext loggedInUserPC = ProcessContext.get();

		if (null == loggedInUserPC || null == loggedInUserPC.getTenantId()
				|| loggedInUserPC.getTenantId().isEmpty()) {
			throw new IllegalArgumentException(
					"Tenant id not found for logged in user.");
		}

		final AuditRecord auditRecord = new AuditRecord();
		if (null != loggedInUserPC) {
			auditRecord.setTenant(loggedInUserPC.getTenantId());
			auditRecord.setUserId(loggedInUserPC.getUserId());
		}
		auditRecord.setMessage(message);
		auditRecord.setType(auditEventType);
		auditRecord.setAuditTime(DateTime.getCurrentTime());
		auditRecord.setWorkStatus(workStatus);
		auditRecord.setReferenceId(referenceId);
		auditRecord.setFailureReason(failureReason);
		auditRecord.setBeIdentity(beIdentity);
		auditRecord.setContractId(contractId);
		auditRecord.setProcessContext(loggedInUserPC);

		EventUtils.publish(new Event<AuditRecord>(EventType.EBILL_AUDIT_EVENT,
				auditRecord));

	}
	
	public static <T extends Serializable> void auditActivity(ActivityLog<T> log) {
		EventUtils.publish(new Event<ActivityLog<T>>(EventType.ACTIVITY_LOG_EVENT, log));
	}

	public static <T extends Serializable> ActivityLog<T> 
		auditActivity(String message, String category, 
			String objectIdentity, String objectExternalId, long objectVersion, T activityData) {
		
		SimpleObjectChangeLog<T> log = new SimpleObjectChangeLog<T>(category);
		log.setMessage(message);
		log.setObjectIdentity(objectIdentity);
		log.setObjectExternalId(objectExternalId);
		log.setObjectVersion(objectVersion);
		log.setActivityTime(DateTime.getCurrentTime());
		log.setActivityData(activityData);
		
		ProcessContext pc = ProcessContext.get();
		if (pc != null) {
			log.setUserId(pc.getUserId());
			log.setUserName(pc.getUserName());
			log.setProcessId(pc.id());
		}
		
		auditActivity(log);
		
		return log;
	}
	
	public static <T extends Serializable> ActivityLog<T> auditActivity(String message, String category, 
			String objectIdentity, String objectExternalId, long objectVersion) {
		return auditActivity(message, category, objectIdentity, objectExternalId, objectVersion, null);
	}
	
	public static <T extends Serializable> ActivityLog<T> auditActivity(String message, String category) {
		
		SimpleActivityLog<T> log = new SimpleActivityLog<T>(category);
		log.setMessage(message);
		log.setActivityTime(DateTime.getCurrentTime());
		
		ProcessContext pc = ProcessContext.get();
		if (pc != null) {
			log.setUserId(pc.getUserId());
			log.setUserName(pc.getUserName());
			log.setProcessId(pc.id());
		}
		
		auditActivity(log);
		
		return log;
	}
	
	public static String resolveActivityCollectionName(final String category){
		String tenantId = TenantUtil.getTenantId();
		return tenantId  + ACTIVITY + category;		
	}
	
}