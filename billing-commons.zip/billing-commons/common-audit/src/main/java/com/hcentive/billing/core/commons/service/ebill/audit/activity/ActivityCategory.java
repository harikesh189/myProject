package com.hcentive.billing.core.commons.service.ebill.audit.activity;

public interface ActivityCategory {
	public static final String BILLING_POLICY_ENTITY_LINK = "BILLING_POLICY_ENTITY_LINK";
}
