package com.hcentive.billing.core.commons.service.ebill.audit.activity;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

public class LifeCycleActivity implements Serializable {

	private static final long serialVersionUID = 8946957190640939755L;

	private DateTime eventDate;

	private String eventCategory;

	private String stateName;

	private Amount amount;

	public LifeCycleActivity() {
		super();
	}

	public LifeCycleActivity(String eventCategory, String stateName,
			Amount amount) {

		super();
		this.eventDate = DateTime.getCurrentTime();
		this.eventCategory = eventCategory;
		this.stateName = stateName;
		this.amount = amount;

	}

	public DateTime getEventDate() {
		return eventDate;
	}

	public void setEventDate(DateTime eventDate) {
		this.eventDate = eventDate;
	}

	public String getEventCategory() {
		return eventCategory;
	}

	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "LifeCycleActivity [eventDate=" + eventDate + ", eventCategory="
				+ eventCategory + ", stateName=" + stateName + ", amount="
				+ amount + "]";
	}
}
