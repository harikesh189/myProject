package com.hcentive.billing.core.commons.service.ebill.audit.activity;

public interface LifeCycleEventCategory {
	
	public static final String STATE_CHANGE = "State change";
	public static final String EXCEPTION_START = "Exception start";
	public static final String EXCEPTION_END = "Exception end";
	public static final String EXIT_PAYMENT = "Exit by payment";
	public static final String MANUAL_EXIT = "Manual exit";

}
