package com.hcentive.billing.core.commons.service.ebill.audit.dto;

import java.util.Map;

import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditLog;
import com.hcentive.billing.core.commons.domain.audit.AuditMessage;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * @author Ankit.Garg
 * 
 */
public class AuditRecord implements AuditLog<AuditRecordData> {

	private static final long serialVersionUID = -1112375280652061049L;
	
	private String tenant;
	private String userId;
	private AuditEventType type;
	private AuditMessage message;
	private DateTime auditTime;
	private AuditWorkStatus workStatus;
	private ProcessContext processContext;
	
	private AuditRecordData data;

	public AuditRecord() {
		data = new AuditRecordData();
	}
	
	public ProcessContext getProcessContext() {
		return processContext;
	}

	public void setProcessContext(ProcessContext processContext) {
		this.processContext = processContext;
	}

	public String getContractId() {
		return data.getContractId();
	}

	public void setContractId(String contractId) {
		data.setContractId(contractId);
	}

	public String getUserId() {
		return userId;
	}

	public Map<String, String> getArguments() {
		return data.getArguments();
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setArguments(Map<String, String> arguments) {
		data.setArguments(arguments);
	}

	public String getTenant() {
		return tenant;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	public DateTime getAuditTime() {
		return new DateTime(this.auditTime.getDate());
	}

	public void setAuditTime(DateTime auditTime) {
		this.auditTime = auditTime;
	}

	public AuditEventType getType() {
		return type;
	}

	public void setType(AuditEventType type) {
		this.type = type;
	}

	public AuditWorkStatus getWorkStatus() {
		return workStatus;
	}

	public void setWorkStatus(AuditWorkStatus workStatus) {
		this.workStatus = workStatus;
	}

	public String getReferenceId() {
		return data.getReferenceId();
	}

	public void setReferenceId(String referenceId) {
		data.setReferenceId(referenceId);
	}

	public String getBeIdentity() {
		return data.getBeIdentity();
	}

	public void setBeIdentity(String beIdentity) {
		data.setBeIdentity(beIdentity);
	}

	public String getFailureReason() {
		return data.getFailureReason();
	}

	public AuditMessage getMessage() {
		return message;
	}

	public void setMessage(AuditMessage message) {
		this.message = message;
	}

	public void setFailureReason(String failureReason) {
		data.setFailureReason(failureReason);
	}

	@Override
	public AuditMessage message() {
		return getMessage();
	}

	@Override
	public String processId() {
		return getProcessContext().id();
	}

	@Override
	public DateTime activityTime() {
		return getAuditTime();
	}

	@Override
	public String userId() {
		return getUserId();
	}

	@Override
	public String userName() {
		return getProcessContext().getUserName();
	}

	@Override
	public AuditEventType type() {
		return getType();
	}

	@Override
	public AuditRecordData auditData() {
		return data;
	}

	@Override
	public AuditWorkStatus status() {
		return getWorkStatus();
	}

}