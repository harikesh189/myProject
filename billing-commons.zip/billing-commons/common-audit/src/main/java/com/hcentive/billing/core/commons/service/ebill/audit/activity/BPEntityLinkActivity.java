package com.hcentive.billing.core.commons.service.ebill.audit.activity;

import java.io.Serializable;
import java.util.List;

public class BPEntityLinkActivity implements Serializable {

	private static final long serialVersionUID = 2458572418579973431L;

	private String beIdentity;

	private String bpEntityLinkIdentity;


	public String getBeIdentity() {
		return beIdentity;
	}

	public void setBeIdentity(String beIdentity) {
		this.beIdentity = beIdentity;
	}

	public String getBpEntityLinkIdentity() {
		return bpEntityLinkIdentity;
	}

	public void setBpEntityLinkIdentity(String bpEntityLinkIdentity) {
		this.bpEntityLinkIdentity = bpEntityLinkIdentity;
	}

	public BPEntityLinkActivity(String beIdentity, String bpEntityLinkIdentity) {
		super();
		this.beIdentity = beIdentity;
		this.bpEntityLinkIdentity = bpEntityLinkIdentity;
	}

	@Override
	public String toString() {
		return "BPEntityLinkActivity [beIdentity=" + beIdentity
				+ ", bpEntityLinkIdentity=" + bpEntityLinkIdentity + "]";
	}

	public BPEntityLinkActivity() {
		super();
	}

}
