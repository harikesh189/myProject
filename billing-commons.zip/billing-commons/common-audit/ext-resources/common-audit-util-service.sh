#!/bin/bash
clear
echo "Launching Common Audit Util Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/home/ubuntu/wfm/outOfMemoryLogs/common-audit-util-service -Xloggc:/home/monitoring/log/common-audit-util-service/GC_`date '+%y%m%d_%H%M%S'`.log -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar common-audit-util-service-1.0.RELEASE.jar --server.port=$1