package com.hcentive.billing.core.commons.util.converter;

import org.springframework.core.convert.converter.Converter;

import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.hcentive.billing.core.commons.exception.StandardErrorCodes;
import com.hcentive.billing.core.commons.util.exception.BusinessErrorCodes;
import com.mongodb.DBObject;

public class ErrorCodeReadConverter implements Converter<DBObject, ErrorCode> {
	@Override
	public ErrorCode convert(DBObject source) {

		final String errorCodeStr = (String) source.get(ErrorCodeWriteConverter.ERROR_CODE);
		if (errorCodeStr != null) {
			final BusinessErrorCodes errorCode = BusinessErrorCodes.fromString(errorCodeStr);
			return errorCode != null ? errorCode : StandardErrorCodes.fromString(errorCodeStr);
		}
		return null;
	}
}