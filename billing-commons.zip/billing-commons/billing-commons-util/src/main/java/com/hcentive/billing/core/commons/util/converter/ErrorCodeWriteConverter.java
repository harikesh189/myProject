package com.hcentive.billing.core.commons.util.converter;

import org.springframework.core.convert.converter.Converter;

import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.mongodb.BasicDBObject;

public class ErrorCodeWriteConverter implements Converter<ErrorCode, BasicDBObject> {
	public static final String ERROR_CODE = "error_code";

	@Override
	public BasicDBObject convert(ErrorCode errorCode) {

		if (errorCode != null) {
			final BasicDBObject dbo = new BasicDBObject();
			dbo.put(ERROR_CODE, errorCode.name());
			return dbo;
		}
		return null;
	}
}