package com.hcentive.billing.core.commons.util.converter;

import org.springframework.core.convert.converter.Converter;

import com.hcentive.billing.core.commons.util.exception.BusinessErrorCodes;

public class BusinessErrorCodeConverter implements Converter<String, BusinessErrorCodes> {
	@Override
	public BusinessErrorCodes convert(String source) {
		final BusinessErrorCodes errorCode = BusinessErrorCodes.valueOf(source);
		return errorCode;
	}
}