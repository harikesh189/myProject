package com.hcentive.billing.core.commons.util.exception;

import com.hcentive.billing.core.commons.exception.ErrorCode;

public enum BusinessErrorCodes implements ErrorCode {
	DATA_INVALID, DATA_MISSING, DATA_PARSE_FAILURE, GENERIC_BUSINESS_ERROR, SECURITY_AUTHENTICATION_FAILURE, SECURITY_INVALID_ACCESS, TENANT_MISSING;

	public static BusinessErrorCodes fromString(String value) {
		if (value != null) {
			for (final BusinessErrorCodes errorCode : values()) {
				if (errorCode.name().endsWith(value)) {
					return errorCode;
				}
			}
		}
		return null;
	}

}
