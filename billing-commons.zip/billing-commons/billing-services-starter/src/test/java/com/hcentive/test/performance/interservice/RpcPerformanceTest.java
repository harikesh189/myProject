package com.hcentive.test.performance.interservice;

import java.util.concurrent.CountDownLatch;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallbackAdapter;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { SampleInterServiceConfiguration.class })
public class RpcPerformanceTest {

	private static final int count = 100 * 100 * 100 * 10;

	@Autowired
	private DummyInterServiceClient client;

	@Autowired
	public AmqpTemplate amqpTemplate;

	@Before
	public void init() {
		Assert.notNull(client);
		Assert.notNull(amqpTemplate);
	}

	@Test
	public void test() throws InterruptedException {
		final long startTime = System.currentTimeMillis();
		final CountDownLatch latch = new CountDownLatch(count);
		for (int i = 1; i <= count; ++i) {
			final IOU<String, AsyncCallback<String>> reply = client.getReply("sambhav: " + i);
			reply.set(new AsyncCallbackAdapter<String>() {
				@Override
				public void onSuccess(String o) {
					System.out.println("Reply: " + o);
					latch.countDown();
				}
			});
		}
		System.out.println("Sit back and relax, asll have been published.");
		latch.await();
		System.out.println("Total time elapse:  " + (System.currentTimeMillis() - startTime) + " milliseconds");
	}

}
