/**
 *
 */
package com.hcentive.test.performance.trace;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.hcentive.billing.core.commons.service.init.MongoConfiguration;
import com.hcentive.billing.core.commons.service.init.PerformanceConfiguration;

/**
 * @author sambhav.jain
 *
 */
@Configuration
@PropertySources({ @PropertySource({ "classpath:mongodb.properties" })})
@Import({MongoConfiguration.class, PerformanceConfiguration.class })
public class PerformanceTraceTestConfiguration {

	@Bean
	public static final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
	@Bean
	public DummyComponent dummyComponent() {
		return new DummyComponent();
	}
}
