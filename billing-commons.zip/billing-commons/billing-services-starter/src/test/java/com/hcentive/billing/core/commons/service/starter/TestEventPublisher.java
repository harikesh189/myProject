package com.hcentive.billing.core.commons.service.starter;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventListener;
import com.hcentive.billing.core.commons.event.EventUtils;

public class TestEventPublisher implements Runnable,EventListener{

	private final int priority = 1;
	private final String name = "EVENT";
	
	
	public TestEventPublisher(){
		EventUtils.register(name, this);
	}
	@Override
	public void run() {
		for(int i = 0 ; i<100;++i){
			EventUtils.publish(new Event<String>(name, "name: "+priority+", "+i));
			LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(10));
		}
	}


	@Override
	public String handlerId() {
		return name+"handler";
	}


	@Override
	public void handle(Object eventPayload) {
		LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(10000));
		System.out.println(eventPayload);
	}
	@Override
	public boolean recieveOfflineEvents() {
		// TODO Auto-generated method stub
		return false;
	}
}
