package com.hcentive.billing.core.commons.service.starter;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

import com.hcentive.billing.core.commons.service.comm.InterServiceUtil;

public class TestInterServiceRequestMaker implements Runnable {

	private final int priority = 5;
	private final String name = "ServiceRequest";
	
	@Override
	public void run() {
		for(int i = 0 ; i<50;++i){
			InterServiceUtil.serviceClient().submit(name, "name :"+priority+", "+i);
			LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(100));
		}
	}

}
