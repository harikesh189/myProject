/**
 *
 */
package com.hcentive.test.performance.interservice;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.hcentive.billing.core.commons.init.EventConfiguration;
import com.hcentive.billing.core.commons.service.init.AutoConfigurationInterService;
import com.hcentive.common.inter.service.annotation.EnableInterServiceCall;

/**
 * @author sambhav.jain
 *
 */
@Configuration
@PropertySources({ @PropertySource({ "classpath:amqp.properties" }), @PropertySource({ "classpath:app.properties" }) })
@EnableInterServiceCall(basePackagesToScan = { "com.hcentive.test.performance.interservice" })
@Import({ EventConfiguration.class, AutoConfigurationInterService.class })
public class SampleInterServiceConfiguration {

	@Bean
	public static final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	public DummyInterServiceListner listner() {
		return new DummyInterServiceListner();
	}
}
