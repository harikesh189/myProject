package com.hcentive.common.mongo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.hcentive.billing.core.commons.service.init.MongoConfiguration;

@Configuration
@PropertySources({ @PropertySource("classpath:mongodb.properties") })
@Import({MongoConfiguration.class})
public class MongoTestConfiguration {
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
}
