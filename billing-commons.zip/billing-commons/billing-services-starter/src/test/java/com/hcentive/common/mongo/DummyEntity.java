package com.hcentive.common.mongo;

import java.util.Map;

import org.springframework.data.annotation.Id;


public class DummyEntity{

	@Id
	protected String id;

	protected String identity;
	
	protected Map<String, String> mapData;
	
	

	public DummyEntity() {
		super();
	}

	public String getId() {
		return id;
	}

	public String getIdentity() {
		return identity;
	}

	public Map<String, String> getMapData() {
		return mapData;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public void setMapData(Map<String, String> mapData) {
		this.mapData = mapData;
	}
	
}
