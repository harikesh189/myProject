package com.hcentive.test.performance.trace;

import java.util.concurrent.locks.LockSupport;

import com.hcentive.billing.core.commons.annotation.PerformanceTrace;

@PerformanceTrace
public class DummyComponent {
	
	public void testMethod() {
		LockSupport.parkNanos(5 * 1000* 1000 * 1000);
	}
	
}
