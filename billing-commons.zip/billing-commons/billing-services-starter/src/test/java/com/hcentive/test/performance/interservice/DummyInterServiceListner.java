/**
 *
 */
package com.hcentive.test.performance.interservice;

import com.hcentive.billing.core.commons.service.comm.support.ServiceRequestHandler;

/**
 * @author sambhav.jain
 *
 */
public class DummyInterServiceListner {

	@ServiceRequestHandler(serviceName = "TEST_EVENT")
	public String handleEvent(String input) {
		return "Hi " + input;
	}
}
