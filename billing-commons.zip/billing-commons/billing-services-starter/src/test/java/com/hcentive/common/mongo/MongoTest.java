package com.hcentive.common.mongo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MongoTestConfiguration.class })
public class MongoTest {

	private static final String MONGO_TEST_COLLECTION = "mongo_test";
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Test
	public void testForMapPersistance() {
		DummyEntity dummyEntity = new DummyEntity();
		Map<String, String> mapData = new HashMap<>();
		String valueString = "NITIN.SINGLA";
		String keyString = "firstName.surname";
		mapData.put(keyString, valueString);
		mapData.put("a.b.c", "test.data1");
		dummyEntity.setMapData(mapData);
		mongoTemplate.save(dummyEntity,MONGO_TEST_COLLECTION);
		assertNotNull(dummyEntity.getId());
		
		String id = dummyEntity.getId();
		Query query = Query.query(Criteria.where("id").is(id));
		DummyEntity persitedDummyEntity = mongoTemplate.findOne(query, DummyEntity.class, MONGO_TEST_COLLECTION);
		assertNotNull(persitedDummyEntity);
		assertNotNull(persitedDummyEntity.getId());
		assertNotNull(persitedDummyEntity.getMapData());
		assertEquals(valueString, persitedDummyEntity.getMapData().get(keyString));
	}
}
