/**
 * 
 */
package com.hcentive.test.performance.interservice;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.common.inter.service.annotation.InterService;
import com.hcentive.common.inter.service.annotation.InterServiceCall;

/**
 * @author sambhav.jain
 *
 */
@InterService
public interface DummyInterServiceClient {

	@InterServiceCall(service = "TEST_EVENT")
	public IOU<String, AsyncCallback<String>> getReply(String input);
}
