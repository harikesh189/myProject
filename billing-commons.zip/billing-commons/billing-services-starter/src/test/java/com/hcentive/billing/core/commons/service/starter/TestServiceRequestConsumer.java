package com.hcentive.billing.core.commons.service.starter;

public class TestServiceRequestConsumer {

	
}
