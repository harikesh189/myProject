package com.hcentive.billing.core.commons.service.event;


public class EventPayloadContext{
	private static final ThreadLocal<EventPayloadContext> EVENT_PAYLOAD_CONTEXT = new ThreadLocal<>();
	
	private final String routeKey;
	
	
	
	private EventPayloadContext(String routeKey) {
		this.routeKey = routeKey;
	}

	public static EventPayloadContext context(){
		return EVENT_PAYLOAD_CONTEXT.get();
	}
	
	public static String routeKey(){
		return EVENT_PAYLOAD_CONTEXT.get().routeKey;
	}
	public static EventPayloadContext newContext(String routeKey){
		final EventPayloadContext context = new EventPayloadContext(routeKey);
		EVENT_PAYLOAD_CONTEXT.set(context);
		return context;
	}
	
	public static void clear(){
		EVENT_PAYLOAD_CONTEXT.remove();
	}
}