package com.hcentive.billing.core.commons.service.init;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.util.Assert;

import com.hcentive.billing.core.commons.mongo.repository.ProcessContextRepository;
import com.hcentive.billing.core.commons.mongo.repository.ProcessContextRepositoryImpl;
import com.hcentive.billing.core.commons.vo.ProcessContextPersister;

@Configuration
@EnableMongoRepositories(basePackageClasses = { ProcessContextRepository.class })
public class ProcessContextPersisterConfiguration {

	@Autowired
	private ProcessContextRepository processContextRepository;
	
	@PostConstruct
	public void postInit() {
		Assert.notNull(processContextRepository, "Process context repository is not created");
		ProcessContextPersister.configure(processContextRepository);
	}

	@Bean
	@ConditionalOnMissingBean
	public ProcessContextRepository processContextRepository() {
		return new ProcessContextRepositoryImpl();
	}
}
