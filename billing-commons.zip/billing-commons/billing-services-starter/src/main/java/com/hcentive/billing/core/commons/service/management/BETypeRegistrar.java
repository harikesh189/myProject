package com.hcentive.billing.core.commons.service.management;

import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;

public class BETypeRegistrar {

	public static void init() {
		BusinessEntityTypes.register(BusinessEntityTypes.INDIVIDUAL_CUSTOMER);
		BusinessEntityTypes.register(BusinessEntityTypes.GROUP_CUSTOMER);
		BusinessEntityTypes.register(BusinessEntityTypes.OPERATOR);
		BusinessEntityTypes.register(BusinessEntityTypes.BROKER);
		// BusinessEntityTypes.register(BusinessEntityTypes.WFM_OPERATOR);
	}
}
