/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.service.cluster.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.factory.IsForTask;
import com.hcentive.billing.core.commons.factory.TaskAwareFactory;
import com.hcentive.billing.core.commons.zookeeper.PathResolver;

@Configuration
public class PathResolverConfig {

	@Bean
	public PathResolver identityBasedPathResolver() {
		return new IdentityBasedPathResolver();
	}
	@Bean
	public PathResolver stringPathResolver() {
		return new StringPathResolver();
	}
	@Bean
	public PathResolver numberPathResolver() {
		return new NumberPathResolver();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public TaskAwareFactory<IsForTask> pathResolverFactory() {
		TaskAwareFactory<IsForTask> pathResolverFactory = new TaskAwareFactory(
				PathResolver.class);
		Factories.INSTANCE.registerBean(pathResolverFactory);
		return pathResolverFactory;
	}
}
