/**
 * 
 */
package com.hcentive.billing.core.commons.service.init;

import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.interceptor.CustomizableTraceInterceptor;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Profile;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.MongoTemplate;

/**
 * @author sambhav.jain
 *
 */
@Configuration
@Aspect
@EnableAspectJAutoProxy
@Profile("perf")
public class PerformanceConfiguration {

	public static class MethodPerformance {
		String className;
		String methodName;
		long time;
		String processName;

		/**
		 * @return the processName
		 */
		public String getProcessName() {
			return processName;
		}

		/**
		 * @param processName
		 *            the processName to set
		 */
		public void setProcessName(String processName) {
			this.processName = processName;
		}

		@Id
		String id;

		public MethodPerformance(String className, String methodName,
				long time, String processName) {
			super();
			this.className = className;
			this.methodName = methodName;
			this.time = time;
			this.processName = processName;
		}

		public MethodPerformance() {
		}
		

		/**
		 * @return the className
		 */
		public String getClassName() {
			return className;
		}

		/**
		 * @param className
		 *            the className to set
		 */
		public void setClassName(String className) {
			this.className = className;
		}

		/**
		 * @return the methodName
		 */
		public String getMethodName() {
			return methodName;
		}

		/**
		 * @param methodName
		 *            the methodName to set
		 */
		public void setMethodName(String methodName) {
			this.methodName = methodName;
		}

		/**
		 * @return the time
		 */
		public long getTime() {
			return time;
		}

		/**
		 * @param time
		 *            the time to set
		 */
		public void setTime(long time) {
			this.time = time;
		}

		/**
		 * @return the id
		 */
		public String getId() {
			return id;
		}

		/**
		 * @param id
		 *            the id to set
		 */
		public void setId(String id) {
			this.id = id;
		}

	}

	public static final class PerformanceTraceInterceptor extends
			CustomizableTraceInterceptor {

		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 463406554308187046L;

		private static final String processName = ManagementFactory
				.getRuntimeMXBean().getName();

		protected MongoTemplate montMongoTemplate;

		public PerformanceTraceInterceptor(MongoTemplate montMongoTemplate) {
			super();
			this.montMongoTemplate = montMongoTemplate;
		}

		@Override
		protected void writeToLog(Log logger, String message) {
			super.writeToLog(logger, message);
		}

		@Override
		protected boolean isLogEnabled(Log logger) {
			return true;
		}

		@Override
		protected String replacePlaceholders(String message,
				MethodInvocation methodInvocation, Object returnValue,
				Throwable throwable, long invocationTime) {
			String replacePlaceholders = super.replacePlaceholders(message,
					methodInvocation, returnValue, throwable, invocationTime);
			Method method = methodInvocation.getMethod();
			String methodName = method.getDeclaringClass().getName()+"#"+method.getName();
			String name = method.getDeclaringClass().getName();

			if (invocationTime > 0) {
				montMongoTemplate.save(new MethodPerformance(name, methodName,
						invocationTime, processName));
			}
			return replacePlaceholders;
		}

	}

	@Bean
	public PerformanceTraceInterceptor customizableTraceInterceptor(
			MongoTemplate montMongoTemplate) {
		PerformanceTraceInterceptor interceptor = new PerformanceTraceInterceptor(
				montMongoTemplate);
		interceptor.setUseDynamicLogger(false);
		interceptor
				.setEnterMessage("Entering $[targetClassShortName].$[methodName]");
		interceptor
				.setExitMessage("$[targetClassShortName].$[methodName] took $[invocationTime] ms");
		return interceptor;
	}

	@Bean
	public Advisor commonLoggingInterceptor(
			PerformanceTraceInterceptor customizableTraceInterceptor) {
		AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
		pointcut.setExpression("com.hcentive.billing.core.commons.service.init.PerformanceConfiguration.serviceAnnotation()");
		return new DefaultPointcutAdvisor(pointcut,
				customizableTraceInterceptor);
	}

	@Pointcut("within(@com.hcentive.billing.core.commons.annotation.PerformanceTrace *) && execution(public * *(..))")
	public void serviceAnnotation() {
	}

}
