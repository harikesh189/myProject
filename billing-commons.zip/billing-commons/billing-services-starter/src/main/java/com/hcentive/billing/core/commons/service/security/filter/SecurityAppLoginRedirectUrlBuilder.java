package com.hcentive.billing.core.commons.service.security.filter;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.web.WebUtils;

@Component
public class SecurityAppLoginRedirectUrlBuilder implements SecurityRedirectUrlBuilder{
	
	static final Logger LOGGER = LoggerFactory
			.getLogger(SecurityAppLoginRedirectUrlBuilder.class);
	
	@Value(value = "${security.login.page.url:security/{enterpriseName}/oAuth2/initiate}")
	private String securityLoginPageUrl;
	@Override
	public boolean canHandle(final String clientId) {
		return "security-ui".equalsIgnoreCase(clientId);
	}

	@Override
	public String createLoginUrl(HttpServletRequest request,
			String enterpriseName) {
		String redirectUrl = securityLoginPageUrl;
		redirectUrl = WebUtils.replaceEnterprise(enterpriseName, redirectUrl);
		final String clientId = parseClientId(request);
		redirectUrl = WebUtils.getBaseUrl(request)+"/"+redirectUrl+"?client_id="+clientId+"&response_type=token";
		LOGGER.debug("Login URL: {}",redirectUrl);
		return redirectUrl;
	}

	private String parseClientId(HttpServletRequest request) {
		return request.getParameter("client_id");
	}

	
}