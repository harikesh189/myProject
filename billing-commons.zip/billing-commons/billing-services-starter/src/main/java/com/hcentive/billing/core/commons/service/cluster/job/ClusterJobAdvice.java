package com.hcentive.billing.core.commons.service.cluster.job;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.UUID;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.service.cluster.job.manager.ClusteredJobManager;
import com.hcentive.billing.core.commons.vo.DateTime;

/***
 *
 * @author neeraj.aggarwal Provide clustered environment for running jobs
 *
 */
@Aspect
@Component
// @Order(Ordered.HIGHEST_PRECEDENCE)
public class ClusterJobAdvice {
	private static final Logger LOGGER = LoggerFactory.getLogger(ClusterJobAdvice.class);

	@Autowired
	ClusteredJobManager clusteredJobManager;

	@Value("${cluster.job.expiration.duration:1000}")
	Integer expirationDateDuration;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Around("@annotation(clusteredJob)")
	public void manageJobExecution(final ProceedingJoinPoint pjp, final ClusteredJob clusteredJob) throws Throwable {

		LOGGER.trace("Check before starting a job");

		String jobName;
		final String jobId = UUID.randomUUID().toString();

		DateTime expirationDate = new DateTime();
		expirationDate = expirationDate.plusSeconds(expirationDateDuration);

		if (!clusteredJob.jobName().equals("")) {
			jobName = clusteredJob.jobName();
		} else {
			jobName = pjp.getSignature().getDeclaringTypeName() + "." + pjp.getSignature().getName();
		}

		final boolean isJobExecutable = clusteredJobManager.isJobExecutableAndMark(jobName, clusteredJob.noOfinstances(), expirationDate, jobId,
				getMacAddress());

		if (isJobExecutable) {

			boolean asyncJob = false;

			try {

				final Object returnValue = pjp.proceed();

				if (returnValue != null && returnValue instanceof IOU) {
					asyncJob = true;

					final IOU iou = (IOU) returnValue;
					iou.set(new AsyncCallback() {

						@Override
						public void onError(final Throwable t) {
							clusteredJobManager.updateJobExcecution(jobId);
						}

						@Override
						public void onSuccess(final Object o) {
							clusteredJobManager.updateJobExcecution(jobId);
						}
					});
				}

			} catch (final Throwable e) {
				LOGGER.error("Error running job", e);
			}

			if (!asyncJob) {
				clusteredJobManager.updateJobExcecution(jobId);
			}

		} else {
			LOGGER.info("Job: {} already running", jobName);
		}
	}

	private String getMacAddress() {
		final StringBuilder sb = new StringBuilder();
		try {
			InetAddress ip;
			ip = InetAddress.getLocalHost();
			final NetworkInterface network = NetworkInterface.getByInetAddress(ip);
			final byte[] mac = network.getHardwareAddress();
			if (mac != null) {
				for (int i = 0; i < mac.length; i++) {
					sb.append(String.format("%02X%s", mac[i], i < mac.length - 1 ? "-" : ""));
				}
			} else {
				sb.append(ip.getHostAddress());
			}
		} catch (final UnknownHostException e) {
			e.printStackTrace();
		} catch (final SocketException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
}
