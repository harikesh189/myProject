package com.hcentive.billing.core.commons.service.web;

import java.util.Date;

public interface DateResolver {

	Date getDate();
}
