package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.util.ClientAppToCookieNameMapping;
import com.hcentive.billing.core.commons.web.WebUtils;

public abstract class AbstractFilter implements Filter{
	
	@Value(value = "${security.cookie.secure:true}")
	private boolean isCookieSecure;

	private final PathMatcher pathMatcher = new AntPathMatcher();
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(AbstractFilter.class);
	
	private static final String[] GLOBAL_IGNORE_PATHS = {"/**/metrics/**","/**/jolokia/**","/remote/**"};

	protected boolean ignoreCurrentRequest(final ServletRequest request) {
		final String path = ((HttpServletRequest) request).getRequestURI();
		final String[] ignorePathPattern = getIgnorePathPattern();
		if(ignorePathPattern==null || ignorePathPattern.length == 0){
			return false;
		}
		return matchedFoundAgainstPattern(path, ignorePathPattern);
	}

	protected abstract String[] getIgnorePathPattern();

	protected String resolveBeId(final ServletRequest request) {
		return WebUtils.resolve(request, BillingConstant.BE_ID_POSITION);
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException{
		final String path = ((HttpServletRequest)request).getRequestURI();
		for (String globalpath : GLOBAL_IGNORE_PATHS) {
			if(pathMatcher.isPattern(globalpath) && pathMatcher.match(globalpath, path)){
				chain.doFilter(request, response);
				return;
			}
		}
		doInternalFilter(request, response, chain);
	}
	
	protected abstract void doInternalFilter(ServletRequest request,
			ServletResponse response,FilterChain chain) throws IOException, ServletException;

	protected String resolveBeType(final ServletRequest request) {
		final String type = WebUtils.resolve(request, BillingConstant.BE_TYPE_POSITION);
		return "admin".equalsIgnoreCase(type) ? null : type;
	}

	public final void validateRequest(final String appKey,
			final ServletRequest request, final ServletResponse response)
			throws ServletException, IOException {
		LOGGER.debug("Validating Request");
		if (appKey == null || appKey.trim().equals("")) {
			
				LOGGER.debug("AppKey is blank");
				throw new InvalidAppException(appKey);
			
		}

	}
	public Boolean matchedFoundAgainstPattern(final String requestPath, final String[] pattern){
		for(final String customResourcePattern : pattern){
			LOGGER.debug("Checking for requestPath: {} against pattern: {} ",requestPath,customResourcePattern);
			if(pathMatcher.isPattern(customResourcePattern) && pathMatcher.match(customResourcePattern, requestPath)){
					return true;
			}else{
				if(requestPath.equalsIgnoreCase(customResourcePattern)){
					return true;
				}
			}
		}
		return false;
	}
	
	protected void populateCookieForRequestParamToken(HttpServletRequest request,HttpServletResponse response,
			final String tokenId,final String clientId) {
		final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
		final String requestParamCookieId = BillingConstant.COOKIE_SID+cookieIdentifier;
		Cookie cookie = new Cookie(requestParamCookieId,  tokenId);
		cookie.setHttpOnly(true);
		cookie.setSecure(isCookieSecure);
		cookie.setPath("/");
		cookie.setDomain("." + request.getServerName());
		cookie.setMaxAge(60);
		response.addCookie(cookie);
	}



}
