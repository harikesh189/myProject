package com.hcentive.billing.core.commons.service.event;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventInterceptorAdaptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.shiro.Application;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.comm.Service;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;

@Component
public class NormalEventSecurityContextInitializer extends EventInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(NormalEventSecurityContextInitializer.class);

	@Override
	public void beforeProcessing(Event<?> event) {
		if (event.getHeader(Service.SERVICE_EVENT) == null) {
			LOGGER.debug("Processing normal event {}.", event.name());
			// seems things should work through system user.
			SecurityUtil.securityContextManager().loginSystemUser();
			// create new process conext
			final String tenant = (String) event.getHeader(EventHeaderConstant.TENANT_IDENTITY_KEY);
			final Application application = Utils.getUser(true);
			LOGGER.trace("Application found , intializing process context ");
			final String endUserId = (String) event.getHeader(EventHeaderConstant.EVENT_INITIATED_BY_USER_ID_KEY);
			final String endUserName = (String) event.getHeader(EventHeaderConstant.EVENT_INITIATED_BY_USER_NAME_KEY);
			if ((null != endUserId && !endUserId.isEmpty()) && (null != endUserName && !endUserName.isEmpty())) {
				LOGGER.debug("building processcontext with enduser {}", endUserId);
				ProcessContextUtil.buildProcessContext(endUserId, null, tenant, null, endUserName);
			} else {
				LOGGER.debug("building processcontext with system");
				ProcessContextUtil.buildProcessContext(application.getIdentity(), null, tenant, null,
						application.getIdentity());
			}
			LOGGER.debug("Process context in initialized successfully tenant :: {}", tenant);
		}
	}

	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
	}

	@Override
	public int priority() {
		return 1;
	}
}
