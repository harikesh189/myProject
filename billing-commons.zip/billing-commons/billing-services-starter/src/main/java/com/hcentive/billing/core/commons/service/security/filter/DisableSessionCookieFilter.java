package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;

/**
 * @author uttam.tiwari
 **/

// @Component
@Order(2)
public class DisableSessionCookieFilter extends AbstractFilter  {

	@Value("${billing.http.filter.cookies:true}")
	private boolean enabled;

	private static final Logger logger = LoggerFactory
			.getLogger(DisableSessionCookieFilter.class);

	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		logger.debug("Filter called for disablling session and cookie");

		if (!enabled || !(request instanceof HttpServletRequest)) {
			logger.debug("moving ahead in chain filter");
			chain.doFilter(request, response);
			logger.debug("return back from filter chain");
			return;
		}
		logger.debug("sessioncookie filter is enabled");
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		// clear session if session id in URL
		if (httpRequest.isRequestedSessionIdFromURL()) {
			HttpSession session = httpRequest.getSession();
			if (session != null) {
				logger.debug("found session and invalidating session");
				session.invalidate();
			}
		}
		// wrap response to remove URL encoding
		try {
			HttpServletResponseWrapper wrappedResponse = new HttpServletResponseWrapper(
					httpResponse) {
				@Override
				public String encodeRedirectUrl(String url) {
					return url;
				}

				@Override
				public String encodeRedirectURL(String url) {
					return url;
				}

				@Override
				public String encodeUrl(String url) {
					return url;
				}

				@Override
				public String encodeURL(String url) {
					return url;
				}
			};

			// process next request in chain
			logger.debug("Filer completed");
			chain.doFilter(request, wrappedResponse);
		} finally {
			logger.debug("disabling cookie");
			httpResponse.setHeader("Set-Cookie", null);
		}
	}

	/*
	 * unused (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	/*
	 * unused (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	protected String[] getIgnorePathPattern() {
		// TODO Auto-generated method stub
		return null;
	}

}
