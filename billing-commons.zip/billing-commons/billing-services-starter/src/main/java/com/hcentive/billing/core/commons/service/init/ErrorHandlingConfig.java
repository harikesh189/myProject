package com.hcentive.billing.core.commons.service.init;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.View;

@Configuration
public class ErrorHandlingConfig {

	private final View defaultErrorView = new ErrorView();

	@Bean(name = "error")
	public View defaultErrorView() {
		return this.defaultErrorView;
	}

	private static class ErrorView implements View {
		private String errorTemplate = "<html><head><title>A Problem has Occurred</title></head><body>"
					+ "<div  style='width:700px; margin: auto; padding: 120px 0 0 0; box-sizing:border-box; font-family: Verdana, Geneva, sans-serif; text-align: center;'>"
					+ "<h1 style='font-weight:normal; color: #333; margin-bottom: 15px; line-height: 1.25em; font-size:1.9em;'>Some problem has occurred on this page.</h1>"
					+ "<p style='margin: 20px 0 0 0; font-size: 1em; color: #868686;'>Your request could not be processed. Please try again. </p></div>"
				+ "</body></html>";

		@Override
		public String getContentType() {
			return "text/html";
		}

		@Override
		public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
				throws Exception {
			if (response.getContentType() == null) {
				response.setContentType(getContentType());
			}
			response.getWriter().append(errorTemplate);
		}

	}
}
