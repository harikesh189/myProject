package com.hcentive.billing.core.commons.service.event;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventInterceptorAdaptor;
import com.hcentive.billing.core.commons.event.EventUtils;

@Component
public class PreProcessingServiceInfoProcessor extends EventInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(PreProcessingServiceInfoProcessor.class);
	
	@Override
	public int priority() {
		// TODO Auto-generated method stub
		return 6;
	}
	
	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
	}
	
	@Override
	public void beforeProcessing(Event<?> event) {
		String callerSvc = event.getHeader(EventHeaderConstant.ORIGIN_SERVICE_NAME);
		String callerInstance = event.getHeader(EventHeaderConstant.ORIGIN_INSTANCE_ID);
		LOGGER.info("Event {} received from service {} at instance id {}", event.getName(), callerSvc, callerInstance);
	}
}
