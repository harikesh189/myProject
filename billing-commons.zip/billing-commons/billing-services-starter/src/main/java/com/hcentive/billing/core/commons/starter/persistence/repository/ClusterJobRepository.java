package com.hcentive.billing.core.commons.starter.persistence.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hcentive.billing.core.commons.domain.ClusterJob;

public interface ClusterJobRepository extends JpaRepository<ClusterJob, Long> {

	public List<ClusterJob> findByJobNameAndExpirationDateDateGreaterThanAndStatus(String jobName, Date currentDate,
			String status);

	public ClusterJob findByIdentity(String identity);

	@Modifying
	@Query("delete from ClusterJob job where job.auditInfo.createdAt.date < :beforeThisDate and job.status = :status")
	public void deleteOldJobs(@Param("beforeThisDate") Date beforeThisDate, @Param("status") String status);

}