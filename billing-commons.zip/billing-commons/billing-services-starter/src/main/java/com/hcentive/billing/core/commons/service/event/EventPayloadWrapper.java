package com.hcentive.billing.core.commons.service.event;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

import com.hcentive.billing.core.commons.io.SerializationUtil;
import com.hcentive.billing.core.commons.util.RandomGenerator;

@SuppressWarnings("rawtypes")
public class EventPayloadWrapper implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String FIELD_IDENTITY="identity";
	@Id
	private String identity;
	private byte[] payload;
	private Class payloadClass;
	
	protected EventPayloadWrapper(){	
	}

	protected EventPayloadWrapper(Object payload) {
		payloadClass = payload.getClass();
		this.payload = SerializationUtil.serialize((Serializable) payload);
		this.identity = RandomGenerator.randomString();
	}
	
	public String identity(){
		return this.identity;
	}

	public Object payload() {
		return SerializationUtil.deSerialize(payload, payloadClass);
	}
}