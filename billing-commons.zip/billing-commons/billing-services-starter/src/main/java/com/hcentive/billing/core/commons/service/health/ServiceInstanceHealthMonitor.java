package com.hcentive.billing.core.commons.service.health;

import static com.hcentive.billing.commons.health.api.HealthMonitor.SEPARATOR;

import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;

import org.apache.curator.framework.CuratorFramework;
import org.apache.zookeeper.CreateMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.endpoint.PublicMetrics;
import org.springframework.boot.actuate.metrics.Metric;
import org.springframework.boot.context.embedded.EmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedWebApplicationContext;
import org.springframework.boot.context.embedded.jetty.JettyEmbeddedServletContainer;

import com.hcentive.billing.commons.health.api.HealthMonitor.HealthStatus;
import com.hcentive.billing.commons.health.mgmt.HealthStatisticsRegistry;
import com.hcentive.billing.core.commons.service.comm.ServiceConfig;
import com.hcentive.billing.core.commons.service.comm.ServiceConfigurer;
import com.hcentive.billing.core.commons.zookeeper.WFMCuratoreClient;

public class ServiceInstanceHealthMonitor implements PublicMetrics{

	
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceInstanceHealthMonitor.class);
	
	@Value("${zookeeper.health.rootPath:/wfm/health/}")
	private final String healthRootPath = "/wfm/health/";
	
	@Autowired
	private WFMCuratoreClient wfmCuratorClient;
	
	@Autowired
	private HealthStatisticsRegistry serviceHealthStatisticsRegistry;
	
	@Autowired
	private EmbeddedWebApplicationContext context;
	
	@PostConstruct
	public void init(){
		initializeServiceInstanceId();
		final CuratorFramework client = wfmCuratorClient.getClient();
		final ServiceConfig serviceConfig = ServiceConfigurer.serviceConfig();
		final String path = addServiceInstanceNode(client, serviceConfig);
		final EmbeddedServletContainer embeddedServletContainer = (JettyEmbeddedServletContainer) context.getEmbeddedServletContainer();
		try {
			final String serverAddress = Inet4Address.getLocalHost().getHostAddress()+":"+embeddedServletContainer.getPort();
			LOGGER.info("ServiceInstance {} - ServerAddress {}",this.serviceInstanceId,serverAddress);
			addServerAddress(client, path, serverAddress);
		} catch (UnknownHostException e) {
			LOGGER.error("Error while figuring out IP of :{}",this.serviceInstanceId,e);
		}
	}

	private void addServerAddress(final CuratorFramework client,
			final String path, final String serverAddress) {
		try {
			client.setData().forPath(path, serverAddress.getBytes());
		} catch (Exception e) {
			LOGGER.error("Error while informing serverAddress for serviceInstance {}",this.serviceInstanceId,e);
		}
	}

	private String addServiceInstanceNode(final CuratorFramework client,
			final ServiceConfig serviceConfig) {
		final String path = healthRootPath + serviceConfig.serviceName()+"/"+serviceConfig.instanceId();
		try {
			client.create().creatingParentsIfNeeded().withMode(CreateMode.EPHEMERAL).forPath(path);
			LOGGER.info("Registered {} for healthMonitoring.",this.serviceInstanceId);
		} catch (Exception e) {
			LOGGER.error("Error while registering health instance on zookeper.",e);
		}
		return path;
	}
	
	public String initializeServiceInstanceId() {
		if(null == serviceInstanceId){
			this.serviceInstanceId = ServiceConfigurer.serviceConfig().identity();
		}
		return this.serviceInstanceId;
	}
	
	private String serviceInstanceId;

	@Override
	public Collection<Metric<?>> metrics() {
		
		LOGGER.debug("Retreiving metrics for {}",this.serviceInstanceId);
		
		final Collection<Metric<?>> metrics = new ArrayList<>();
		final Map<String, HealthStatus> healthStatuses = serviceHealthStatisticsRegistry.healthStatuses();
		metrics.add(new Metric<Number>(this.serviceInstanceId, 1));
		
		if(null!=healthStatuses){
			for(final Entry<String, HealthStatus> entry: healthStatuses.entrySet()){
				final String entryId = entry.getKey();
				final HealthStatus status = entry.getValue();
				final String healthMonitorInstanceId = this.serviceInstanceId+SEPARATOR+entryId;
				final Metric<?> healthMonitorInstanceMetric = new Metric<Number>(healthMonitorInstanceId, status.isFine()?1:0);
				metrics.add(healthMonitorInstanceMetric);
				for(final Entry<String,Number> healthParameterEntry : status.healthParameters.entrySet()){
					final String healthParameterEntryId = healthMonitorInstanceId+SEPARATOR+entry.getKey();
					metrics.add(new Metric<Number>(healthParameterEntryId,healthParameterEntry.getValue()));
				}
			}
		}
		LOGGER.debug("Returning metrics for {}. Size: {}",this.serviceInstanceId,metrics.size());
		return metrics;
	}
}
