package com.hcentive.billing.core.commons.service.security.filter;

import javax.servlet.http.HttpServletRequest;

import com.hcentive.billing.core.commons.factory.IsForTask;

public interface SecurityRedirectUrlBuilder extends IsForTask<String>{
	public boolean canHandle(String clientId);
	public String createLoginUrl(final HttpServletRequest request,final String enterpriseName);
}