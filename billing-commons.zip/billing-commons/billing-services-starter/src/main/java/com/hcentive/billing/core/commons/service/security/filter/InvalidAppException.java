package com.hcentive.billing.core.commons.service.security.filter;

public class InvalidAppException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final String tenant;

	public InvalidAppException(String tenant) {
		super("Please provide apps for tenant : " + tenant);
		this.tenant = tenant;
	}

	public String getTenant() {
		return tenant;
	}

}
