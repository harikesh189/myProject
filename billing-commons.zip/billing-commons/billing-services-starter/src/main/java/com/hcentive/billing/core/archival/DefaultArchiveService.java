/**
 *
 */
package com.hcentive.billing.core.archival;

import java.io.Serializable;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.enumtype.AuditableOperation;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.archive.ArchiveService;
import com.hcentive.billing.core.commons.persistence.dto.AuditableEntityWrapper;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Primary
@Component
public class DefaultArchiveService implements ArchiveService {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void archive(final Serializable olderEntity,
			AuditableOperation operation) {
		final AuditableEntityWrapper wrapper = new AuditableEntityWrapper();
		wrapper.setEntity(olderEntity);
		wrapper.setProcessContextId(ProcessContext.get().id());
		wrapper.setOperation(operation);
		EventUtils.publish(new Event(EventType.ARCHIVING, wrapper));
	}
}
