package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.domain.Administrator;
import com.hcentive.billing.core.commons.domain.ClientUser;
import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * 
 * Filter to match if beId is valid.
 * 
 * @author ajay.saxena
 * 
 */
// @Component
public class BEMatcherFilter extends AbstractFilter {

	private static final Logger logger = LoggerFactory
			.getLogger(BEMatcherFilter.class);

	private final Map<Class, Checker> checkerRegistry = new HashMap<Class, BEMatcherFilter.Checker>();

	@Value("${billing.http.filter.beMatch:true}")
	private boolean enabled;

	@Value("${beMatch.ignore.pattern:}")
	private String[] ignorePattern = new String[0];

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		checkerRegistry.put(Manager.class, new BEManagerChecker());
		checkerRegistry.put(Administrator.class, new AdminstratorChecker());
		checkerRegistry.put(ClientUser.class, new ClientUserChecker());
		checkerRegistry.put(AnonymousUser.class, new AnonymousUserChecker());
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if (enabled && !ignoreCurrentRequest(request)) {
			logger.debug("Inside filer");
			boolean isValid = false;
			final User loggedInUser = Utils.getUser();
			if (null != loggedInUser) {
				final Checker checker = checkerRegistry.get(loggedInUser
						.getClass());
				if (checker != null) {
					isValid = checker.check(loggedInUser);
				}
				if (!isValid) {
					throw new SecurityException("Access Denied.");
				}
			}
			logger.debug("Filter completed.");
		}
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {

	}

	protected static interface Checker<U extends User> {
		public boolean check(U user);
	}

	/**
	 * Class to check if user is Manager.
	 * 
	 * @author ajay.saxena
	 * 
	 */
	private static class BEManagerChecker implements Checker<Manager> {
		@Override
		public boolean check(Manager user) {
			final ProcessContext pc = ProcessContext.get();
			final String beId = pc.getBeId();
			// return true;
			return user.manages(beId);
		}

	}

	/**
	 * Class to check if user is Admin.
	 * 
	 * @author ajay.saxena
	 * 
	 */
	private static class AdminstratorChecker implements Checker<Administrator> {
		@Override
		public boolean check(Administrator user) {
			return Utils.getUser() instanceof Administrator;
		}

	}
	
	private static class ClientUserChecker implements Checker<ClientUser> {
		@Override
		public boolean check(ClientUser user) {
			return Utils.getUser() instanceof ClientUser;
		}

	}
	
	private static class AnonymousUserChecker implements Checker<AnonymousUser>{

		@Override
		public boolean check(AnonymousUser user) {
			return Utils.getUser() instanceof AnonymousUser;
		}
		
	}

	@Override
	protected String[] getIgnorePathPattern() {
		return this.ignorePattern ;
	}
}
