package com.hcentive.billing.core.commons.service.security;

import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang.StringUtils;

import com.hcentive.billing.core.commons.security.SecuredAccessContext;
import com.hcentive.billing.core.commons.security.matcher.MD5NonceMatcher;
import com.hcentive.billing.core.commons.service.security.filter.HttpSecuredAccessDataExtractor.ChecksumAwareSecuredAccessContext;

public class ChecksumSupportMd5NonceMatcher extends MD5NonceMatcher {

	public ChecksumSupportMd5NonceMatcher() throws NoSuchAlgorithmException {
		super();
	}
	
	@Override
	protected String getEncryptedKey(String securityKey,
			SecuredAccessContext context) {
		if(context instanceof ChecksumAwareSecuredAccessContext){
			final String checksum = ((ChecksumAwareSecuredAccessContext)context).checksum();
			if(!StringUtils.isEmpty(checksum)){
				return getEncryptedKey(securityKey+context.nonce()+checksum);
			}
		}
		return super.getEncryptedKey(securityKey,context);
		
	}
}
