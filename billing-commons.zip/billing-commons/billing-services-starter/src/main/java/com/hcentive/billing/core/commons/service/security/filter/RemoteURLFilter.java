package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.service.comm.api.SpringHttpRMIInterceptor;
import com.hcentive.billing.core.commons.service.rmi.DefaultSpringHttpRMIInterceptorRegistry;

public class RemoteURLFilter implements Filter {
	
	
	private static final Logger logger = LoggerFactory
			.getLogger(RemoteURLFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		final String path = httpServletRequest.getRequestURI();
		if(null != path && path.contains("remote")){
			logger.debug("Parsing interceptors");
			Set<SpringHttpRMIInterceptor> interceptors = DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.getInterceptors();
			if( null != interceptors){
				try{
					for (SpringHttpRMIInterceptor interceptor : interceptors) {
						interceptor.beforeConsuming(httpServletRequest);
					}
					chain.doFilter(request, response);
				}finally{
					for (SpringHttpRMIInterceptor interceptor : interceptors) {
						interceptor.afterConsuming(httpServletRequest);
					}
				}
				return;
			}
		}
		chain.doFilter(request, response);

	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}
