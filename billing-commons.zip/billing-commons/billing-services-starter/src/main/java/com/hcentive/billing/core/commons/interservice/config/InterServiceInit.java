package com.hcentive.billing.core.commons.interservice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.common.inter.service.annotation.EnableInterServiceCall;

@Configuration
@EnableInterServiceCall(basePackagesToScan = { "com.hcentive.billing.core.commons.interservice.config" })
@EnableJpaRepositories(basePackages = { "com.hcentive.billing.core.commons.starter.persistence.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
public class InterServiceInit {

}
