package com.hcentive.billing.core.commons.service.util;

import java.util.Calendar;

import com.hcentive.billing.core.commons.vo.DateTime;

public class SystemConfig {

	public static SystemConfig INSTANCE = new SystemConfig();

	protected SystemConfig() {
	}

	public DateTime currentDate() {
		return new DateTime(Calendar.getInstance().getTime());
	}

}
