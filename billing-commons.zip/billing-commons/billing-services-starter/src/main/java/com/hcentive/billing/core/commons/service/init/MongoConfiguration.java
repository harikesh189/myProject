/**
 *
 */
package com.hcentive.billing.core.commons.service.init;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.CustomConversions;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import com.hcentive.billing.commons.mongo.CustomMongoTemplate;
import com.hcentive.billing.commons.mongo.WFMMapingMongoConverter;
import com.hcentive.billing.core.commons.domain.converter.AmountReadConverter;
import com.hcentive.billing.core.commons.domain.converter.AmountWriteConverter;
import com.hcentive.billing.core.commons.domain.converter.ClassTypeReadConverter;
import com.hcentive.billing.core.commons.domain.converter.ClassTypeWriteConverter;
import com.hcentive.billing.core.commons.util.converter.ErrorCodeReadConverter;
import com.hcentive.billing.core.commons.util.converter.ErrorCodeWriteConverter;
import com.mongodb.AuthenticationMechanism;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/**
 * @author Kumar Sambhav Jain
 */
@Configuration
@EnableMongoAuditing
@ComponentScan(basePackages = { "com.hcentive.billing.commons.mongo" })
@Import(MongoAutoConfiguration.class)
public class MongoConfiguration extends AbstractMongoConfiguration {

	@Autowired
	protected MongoProperties mongoProperties;

	@Value(value = "${spring.data.mongodb.authMode:SCRAM_SHA_1}")
	protected AuthenticationMechanism authMode;

	@Value(value = "${spring.data.mongodb.connectionsPerHost:25}")
	protected int connectionsPerHost;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public CustomConversions customConversions() {
		final List converters = new ArrayList<>();
		converters.add(new ClassTypeReadConverter());
		converters.add(new ClassTypeWriteConverter());
		converters.add(new AmountReadConverter());
		converters.add(new AmountWriteConverter());
		converters.add(new ErrorCodeReadConverter());
		converters.add(new ErrorCodeWriteConverter());
		final CustomConversions customConversions = new CustomConversions(converters);
		return customConversions;
	}

	@Bean
	public LocalValidatorFactoryBean localValidatorFactoryBean() {
		return new LocalValidatorFactoryBean();
	}

	@Override
	@Bean
	public MappingMongoConverter mappingMongoConverter() throws Exception {
		final DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDbFactory());
		final MappingMongoConverter converter = new WFMMapingMongoConverter(dbRefResolver, mongoMappingContext());
		converter.setCustomConversions(customConversions());
		converter.setMapKeyDotReplacement("_____");
		return converter;
	}

	@Override
	@Bean
	public Mongo mongo() {
		final MongoCredential credential = buildMongoCredentials();
		final ServerAddress serverAddress = new ServerAddress(mongoProperties.getHost(), mongoProperties.getPort());
		final MongoClientOptions options = MongoClientOptions.builder().connectionsPerHost(connectionsPerHost).build();
		final MongoClient mongoClient = new MongoClient(serverAddress, Arrays.asList(credential), options);
		return mongoClient;
	}

	@Override
	@Bean
	public MongoDbFactory mongoDbFactory() throws Exception {

		final MongoClient mongoClient = (MongoClient) mongo();
		final SimpleMongoDbFactory simpleMongoDbFactory = new SimpleMongoDbFactory(mongoClient, mongoProperties.getDatabase());
		return simpleMongoDbFactory;
	}

	@Override
	@Bean
	@ConditionalOnMissingBean
	public MongoTemplate mongoTemplate() throws Exception {
		return new CustomMongoTemplate(mongoDbFactory(), this.mappingMongoConverter());
	}

	@Bean
	public MongoMappingContext springMongoMappingContext() {
		return new MongoMappingContext();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.data.mongodb.config.AbstractMongoConfiguration# getDatabaseName()
	 */
	@Override
	protected String getDatabaseName() {
		return mongoProperties.getDatabase();
	}

	private MongoCredential buildMongoCredentials() {
		switch (authMode) {
		case GSSAPI:
			return MongoCredential.createGSSAPICredential(mongoProperties.getUsername());
		case MONGODB_CR:
			return MongoCredential.createMongoCRCredential(mongoProperties.getUsername(), mongoProperties.getAuthenticationDatabase(),
					mongoProperties.getPassword());
		case MONGODB_X509:
			return MongoCredential.createMongoX509Credential(mongoProperties.getUsername());
		case PLAIN:
			return MongoCredential.createPlainCredential(mongoProperties.getUsername(), mongoProperties.getAuthenticationDatabase(),
					mongoProperties.getPassword());
		case SCRAM_SHA_1:
			return MongoCredential.createScramSha1Credential(mongoProperties.getUsername(), mongoProperties.getAuthenticationDatabase(),
					mongoProperties.getPassword());
		default:
			return MongoCredential.createCredential(mongoProperties.getUsername(), mongoProperties.getAuthenticationDatabase(), mongoProperties.getPassword());

		}
	}
}
