package com.hcentive.billing.core.commons.service.rmi;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import com.hcentive.billing.core.commons.service.comm.api.SpringHttpRMIInterceptor;
import com.hcentive.billing.core.commons.service.comm.api.SpringHttpRMIInterceptorRegistry;

public class DefaultSpringHttpRMIInterceptorRegistry implements
		SpringHttpRMIInterceptorRegistry {
	
	private static final SpringHttpRMIInterceptorComparator interceptorComparator = new SpringHttpRMIInterceptorComparator();
	
	public static final DefaultSpringHttpRMIInterceptorRegistry INSTANCE = new DefaultSpringHttpRMIInterceptorRegistry();
	
	private DefaultSpringHttpRMIInterceptorRegistry(){
	}

	private static class SpringHttpRMIInterceptorComparator implements Comparator<SpringHttpRMIInterceptor> {
		@Override
		public int compare(SpringHttpRMIInterceptor o1, SpringHttpRMIInterceptor o2) {
			int priority = o1.priority() - o2.priority();
			return priority != 0 ? priority : o1.getClass().getName().compareToIgnoreCase(o2.getClass().getName());
		}
	}
	
	private final Set<SpringHttpRMIInterceptor> interceptors = new TreeSet<SpringHttpRMIInterceptor>(interceptorComparator);

	@Override
	public void addInterceptors(SpringHttpRMIInterceptor interceptor) {
		this.interceptors.add(interceptor);
	}

	@Override
	public Set<SpringHttpRMIInterceptor> getInterceptors() {
		return this.interceptors;
	}

}
