package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.security.SecurityUtil;

/**
 * Filter to set process context for the thread and login as SYSTEM USER for URL match against pattern.
 *However, need to initialize the bean in required service
 * @author ajay.saxena
 *
 */
// @Component
public class CreateSystemUserContextFilter extends AbstractFilter {

	private static final Logger logger = LoggerFactory.getLogger(CreateSystemUserContextFilter.class);

	@Value(value = "${system.user.pattern:/**/initiate}")
	private  String[] systemUserPatternArr;
	private final Map<String, Boolean> isCustomResourceRegistry = new HashMap<String, Boolean>();
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}
	
	public CreateSystemUserContextFilter() {
	}


	protected boolean isSystemUserChecker(String path) {

		Boolean matchFoundInRegistry = isCustomResourceRegistry.get(path);
		if(null == matchFoundInRegistry){
			matchFoundInRegistry = matchedFoundAgainstPattern(path, systemUserPatternArr);
			isCustomResourceRegistry.put(path, matchFoundInRegistry);
		}
		return matchFoundInRegistry;
	}
	
	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		if (!ignoreCurrentRequest(request)) {
			logger.trace("Inside doFilter");
			final String pathInvoked = resolvePathInvoked(request);// filled
			                                                       // this up.

			logger.trace("pathinvoked is {}", pathInvoked);
			if (isSystemUserChecker(pathInvoked)) {
				logger.trace("Creating system User");
				try {
					logger.debug("Creating systemuser for path:{}", pathInvoked);
					SecurityUtil.securityContextManager().loginSystemUser();
					chain.doFilter(request, response);
					SecurityUtil.securityContextManager().logoutSystemUser();
					logger.debug("filter processing completed");
				} catch (final Throwable t) {
					logger.error("Error during system user creation", t);
					throw t;
				}
				return;
			}
		}
		logger.trace("Filter completed going to next filter");
		chain.doFilter(request, response);
	}

	private String resolvePathInvoked(ServletRequest request) {
		final HttpServletRequest httpRequest = (HttpServletRequest) request;
		logger.trace("resolving request Path");
		final String uri = httpRequest.getRequestURI();
		logger.trace("resolving request Path :::: {}", uri);
		return uri;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	protected String[] getIgnorePathPattern() {
		return null;
	}

}
