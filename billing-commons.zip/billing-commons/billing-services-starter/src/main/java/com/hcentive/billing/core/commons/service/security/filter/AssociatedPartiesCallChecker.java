package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.Partner;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.Reference.ReferenceType;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.web.WebUtils;

/**
 * 
 * Filter to ensure that all calls with to /admin are made by an adminstrator
 * only.
 * 
 * 
 */
// @Component
public class AssociatedPartiesCallChecker extends AbstractFilter  {

	@Value(value = "${associated.parties.ignore.pattern:default}")
	private String[] ignorePattern = new String[0];
	
	private static final Logger logger = LoggerFactory
			.getLogger(AssociatedPartiesCallChecker.class);

	@SuppressWarnings("rawtypes")
	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if (!ignoreCurrentRequest(request)
				&& "associatedParties".equalsIgnoreCase(WebUtils.resolve(
						request, 3))) {
			// this is call for associatedParties.
			logger.debug("Inside AssociatedPartiesCallChecker");
			boolean isValid = false;
			final User loggedInUser = Utils.getUser();
			if (null != loggedInUser && loggedInUser instanceof Manager) {
				// check whether the BE invoking call for associatedParties is
				// of type Partner.
				final String beId = resolveBeId(request);
				final Reference r = ((Manager) loggedInUser)
						.managedEntity(beId);
				if (r != null && r.getRefType().equals(ReferenceType.INTERNAL)
						&& Partner.class.isAssignableFrom(r.getType())) {
					isValid = true;
				}
				if (!isValid) {
					throw new SecurityException("Access Denied.");
				}
			}
			logger.debug("AssociatedPartiesCallChecker completed.");
		}
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {

	}

	protected static interface Checker<U extends User> {
		public boolean check(U user);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	protected String[] getIgnorePathPattern() {
		return this.ignorePattern;
	}
}
