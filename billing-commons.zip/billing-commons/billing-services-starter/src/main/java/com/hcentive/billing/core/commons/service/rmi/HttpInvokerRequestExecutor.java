package com.hcentive.billing.core.commons.service.rmi;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Set;

import org.springframework.remoting.httpinvoker.SimpleHttpInvokerRequestExecutor;

import com.hcentive.billing.core.commons.service.comm.api.SpringHttpRMIInterceptor;

public class HttpInvokerRequestExecutor extends SimpleHttpInvokerRequestExecutor {

	@Override
	protected void prepareConnection(final HttpURLConnection con, final int contentLength) throws IOException {
		final Set<SpringHttpRMIInterceptor> interceptors = DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.getInterceptors();

		for (final SpringHttpRMIInterceptor interceptor : interceptors) {
			interceptor.beforeDispatch(con);
		}
		super.prepareConnection(con, contentLength);
	}

}
