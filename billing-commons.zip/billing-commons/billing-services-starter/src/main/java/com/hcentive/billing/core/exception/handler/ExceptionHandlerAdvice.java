/**
 * 
 */
package com.hcentive.billing.core.exception.handler;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.hcentive.billing.core.commons.exception.BillingException;
import com.hcentive.billing.core.exception.InvalidParamtersException;
import com.hcentive.billing.core.exception.ResourceNotFoundException;

/**
 * 
 * Controller Advice to handle common exception thrown while accessing RESTful
 * end points. This also sets appropriate response code.
 * 
 * @author Kumar Sambhav Jain
 * 
 */
@ControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE)
public class ExceptionHandlerAdvice {

	private static final Logger log = LoggerFactory
			.getLogger(ExceptionHandlerAdvice.class);

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	@ExceptionHandler(value = InvalidParamtersException.class)
	public Map<String, String> invalidParamtersException(
			InvalidParamtersException exception) {
		Map<String, String> defaultErrorMessages = exception
				.getDefaultErrorMessages();
		log.error("Invalid Inputs !! \n{}", exception);
//		log.debug(exception.getBindingResult().toString());
		return defaultErrorMessages;
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ResponseBody
	@ExceptionHandler(value = ResourceNotFoundException.class)
	public String resourceNotFound(ResourceNotFoundException exception) {
		return exception.getMessage();
	}

	@ExceptionHandler(Throwable.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Map<String, String> handleIOException(final Throwable th) {
		log.error("IO Exception caught in controller", th);
		th.printStackTrace();
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", "Error");
//		log.debug(ExceptionUtils.getFullStackTrace(th));
		return hashMap;
	}
	
	@ExceptionHandler(BillingException.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Map<String, String> handleBillingExceptionException(final BillingException billingException) {
		log.error("Billing Exception caught in controller", billingException);
//		billingException.printStackTrace();
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", billingException.getMessage());
//		log.debug(ExceptionUtils.getFullStackTrace(billingException));
		return hashMap;
	}
	
	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(value = HttpStatus.CONFLICT)
	@ResponseBody
	public Map<String, String> handleContraintViolationException(
			ConstraintViolationException constraintViolationException) {

		Set<ConstraintViolation<?>> constraintViolations = constraintViolationException
				.getConstraintViolations();
		Map<String, String> map = new HashMap<>(constraintViolations.size());
		for (final ConstraintViolation<?> v : constraintViolations) {
			map.put(v.getPropertyPath().toString(), v.getMessage());
		}
		return map;
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseBody
	public Map<String, String> handleConflict(MethodArgumentNotValidException ex) {
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", "Error");
		hashMap.put("Error", "Error");
		return hashMap;

	}
}
