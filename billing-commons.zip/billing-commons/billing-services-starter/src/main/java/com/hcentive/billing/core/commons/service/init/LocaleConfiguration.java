package com.hcentive.billing.core.commons.service.init;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LocaleConfiguration {

	@Value("${application.timezone:UTC}")
	private String timezone;

	@PostConstruct
	public void init() {
		TimeZone.setDefault(TimeZone.getTimeZone(timezone));
	}
	
	public static TimeZone getTimeZone() {
		return TimeZone.getDefault();
	}

}
