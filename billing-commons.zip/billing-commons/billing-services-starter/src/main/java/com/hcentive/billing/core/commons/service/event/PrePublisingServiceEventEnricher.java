package com.hcentive.billing.core.commons.service.event;

import java.net.HttpURLConnection;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.service.comm.Service;
import com.hcentive.billing.core.commons.service.rmi.DefaultSpringHttpRMIInterceptorRegistry;
import com.hcentive.billing.core.commons.service.rmi.SpringHttpRMIInterceptorAdaptor;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
public class PrePublisingServiceEventEnricher extends SpringHttpRMIInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(PrePublisingServiceEventEnricher.class);
	
	final private ObjectMapper mapper = new ObjectMapper();

	@Override
	public void beforePublishing(Event event) {
		if (event.getHeader(Service.SERVICE_EVENT) != null) {
			LOGGER.trace("Adding process context in header :: {}", ProcessContext.get());
			// add processcontext info in header.
			event.addHeader(EventHeaderConstant.PROCESS_CONTEXT, ProcessContext.get());
			// add user's securityInformation i.e, accessTokenId.
			final AccessToken token = SecurityUtil.accessTokenManager().currentToken();
			if (null != token) {
				LOGGER.trace("Adding access token in header, TOKEN :: {}", token.getIdentity());
				event.addHeader(EventHeaderConstant.ACCESS_TOKEN_ID, token.getIdentity());
			} else {
				// check if running as system.
				if (SecurityUtil.securityContextManager().currentUserIsSystem()) {
					event.addHeader(EventHeaderConstant.ACCESS_TOKEN_ID, EventHeaderConstant.SYSTEM_USER_ACCESS_TOKEN);
				} else {
					LOGGER.trace("No access token found");
				}
			}
		}
	}

	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
		DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.addInterceptors(this);
	}

	@Override
	public int priority() {
		return 2;
	}
	
	@Override
	public void beforeDispatch(HttpURLConnection con) {
		try {
			con.addRequestProperty(EventHeaderConstant.PROCESS_CONTEXT, mapper.writeValueAsString(ProcessContext.get()));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final AccessToken token = SecurityUtil.accessTokenManager().currentToken();
		if (null != token) {
			LOGGER.trace("Adding access token in header, TOKEN :: {}", token.getIdentity());
			con.addRequestProperty(EventHeaderConstant.ACCESS_TOKEN_ID, token.getIdentity());
		} else {
			// check if running as system.
			if (SecurityUtil.securityContextManager().currentUserIsSystem()) {
				con.addRequestProperty(EventHeaderConstant.ACCESS_TOKEN_ID, EventHeaderConstant.SYSTEM_USER_ACCESS_TOKEN);
			} else {
				LOGGER.trace("No access token found");
			}
		}
	}
}
