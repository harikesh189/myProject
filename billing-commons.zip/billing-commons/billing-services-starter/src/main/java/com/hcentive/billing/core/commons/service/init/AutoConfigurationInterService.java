package com.hcentive.billing.core.commons.service.init;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import com.hcentive.billing.core.commons.condition.ConditionalOnBeanEnabled;
import com.hcentive.billing.core.commons.interservice.MQBasedInterServiceChannelManager;
import com.hcentive.billing.core.commons.mq.AMQPClient;
import com.hcentive.billing.core.commons.mq.AMQPConfigurer;
import com.hcentive.billing.core.commons.mq.MQAwareEventBus;
import com.hcentive.billing.core.commons.service.comm.InterServiceUtil;
import com.hcentive.billing.core.commons.service.comm.ServiceClient;
import com.hcentive.billing.core.commons.service.comm.ServiceCommManager.ChannelManager;
import com.hcentive.billing.core.commons.service.comm.ServiceConfig;
import com.hcentive.billing.core.commons.service.comm.ServiceConfigurer;
import com.hcentive.billing.core.commons.service.comm.support.ServiceRequestHandlerAutoRegistrar;
import com.hcentive.billing.core.commons.service.event.EventMessageProrityManager;

@Configuration
@SuppressWarnings("rawtypes")
@ConditionalOnBeanEnabled(key = "service.communication.enabled", matchOnMissing = true)
public class AutoConfigurationInterService {

	@Autowired
	private MQAwareEventBus mqEventBus;
	@Autowired
	private AMQPClient mqClient;

	@Value("${service.name}")
	private String serviceName;

	@Value("${service.instance:NA}")
	private final String serviceInstance = UUID.randomUUID().toString();

	@Value("${service.request.handling.enabled:true}")
	private boolean serviceRequestHandlingEnabled;

	@Value("${service.communication.enabled:true}")
	private final boolean interServiceEnabled = true;
	
	@Bean
	public ServiceConfig serviceConfig() {
		ServiceConfig serviceConfig;
		if (serviceInstance.equalsIgnoreCase("NA")) {
			serviceConfig = new ServiceConfig(this.serviceName, UUID.randomUUID().toString());
		} else {
			serviceConfig = new ServiceConfig(this.serviceName, this.serviceInstance);
		}
		ServiceConfigurer.setServiceConfig(serviceConfig);
		return serviceConfig;
	}

	@Bean
	public ChannelManager channelManager(@Value("${service.name.request.minNumberOfWorkers:1}") final Integer minNumberOfWorkersRequest,
	        @Value("${service.name.request.maxNumberOfWorkers:1}") final Integer maxNumberOfWorkersRequest,
	        @Value("${service.name.reply.minNumberOfWorkers:1}") final Integer minNumberOfWorkersReply,
	        @Value("${service.name.reply.maxNumberOfWorkers:1}") final Integer maxNumberOfWorkersReply) {
		final MQBasedInterServiceChannelManager mqBasedInterServiceChannelManager = new MQBasedInterServiceChannelManager(this.mqEventBus,
		        this.serviceConfig(), minNumberOfWorkersRequest, maxNumberOfWorkersRequest, minNumberOfWorkersReply, maxNumberOfWorkersReply);
		mqBasedInterServiceChannelManager.setInterServiceEnabled(interServiceEnabled);
		mqBasedInterServiceChannelManager.setServiceRequestHandlingEnabled(serviceRequestHandlingEnabled);
		mqBasedInterServiceChannelManager.initialize();
		ServiceConfigurer.setChannelManager(mqBasedInterServiceChannelManager);
		return mqBasedInterServiceChannelManager;
	}

	@Bean
	@DependsOn(value = "channelManager")
	public ServiceClient serviceClient() {
		final ServiceClient serviceClient = new ServiceClient(this.serviceConfig());
		InterServiceUtil.registerServiceClient(serviceClient);
		return serviceClient;
	}

	@Bean
	public MethodInvokingFactoryBean configureEventMessagePriorityManager() {
		final MethodInvokingFactoryBean factory = new MethodInvokingFactoryBean();
		factory.setTargetClass(AMQPConfigurer.class);
		factory.setStaticMethod("com.hcentive.billing.core.commons.mq.AMQPConfigurer.add");
		final Object[] args = { new EventMessageProrityManager() };
		factory.setArguments(args);
		return factory;
	}

	@Bean
	@DependsOn({ "channelManager", "serviceConfig" })
	@ConditionalOnBeanEnabled(key = "service.request.handling.enabled", matchOnMissing = true)
	public ServiceRequestHandlerAutoRegistrar serviceRequestHandlerRegistrar() {
		return new ServiceRequestHandlerAutoRegistrar();
	}
}
