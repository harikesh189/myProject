package com.hcentive.billing.core.commons.service.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ApplicationContextEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
public class ApplicationContextMonitor<E extends ApplicationContextEvent> implements ApplicationListener<E>, BeanFactoryPostProcessor {

	private static final Logger logger = LoggerFactory.getLogger(ApplicationContextMonitor.class);

	@Override
	public void onApplicationEvent(E event) {
		logger.trace("Recieved Event : {}", event);
		if (event instanceof ContextRefreshedEvent) {
			logger.trace("Acknowledge Tenant");
			ProcessContext.get().acknowledgeTenantDuringProcessing();
			ProcessContext.get().clear();
		}
	}

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
		final ProcessContext pc = ProcessContext.initializer().initialize();
		logger.trace("Ignoring Tenant");
		pc.ignoreTenantDuringProcessing();
	}

}
