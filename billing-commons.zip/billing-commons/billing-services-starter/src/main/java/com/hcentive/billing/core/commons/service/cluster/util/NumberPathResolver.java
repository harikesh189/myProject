package com.hcentive.billing.core.commons.service.cluster.util;

import com.hcentive.billing.core.commons.zookeeper.PathResolver;

public class NumberPathResolver implements PathResolver {

	@Override
	public String resolve(Object obj) {
		return "/primitive/number/"+obj.toString();
	}

	@Override
	public boolean canHandle(Object obj) {
		return Number.class.isAssignableFrom(obj.getClass());
	}

}
