package com.hcentive.billing.core.commons.service.init;

import java.io.File;
import java.security.NoSuchAlgorithmException;

import javax.annotation.PostConstruct;

import org.eclipse.jetty.server.HttpConnectionFactory;
import org.eclipse.jetty.server.ConnectionFactory;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.util.thread.QueuedThreadPool;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration.WebMvcAutoConfigurationAdapter;
import org.springframework.boot.context.embedded.jetty.JettyEmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.jetty.JettyServerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.Import;

import com.hcentive.billing.core.commons.concurrent.DefaultLockProvider;
import com.hcentive.billing.core.commons.concurrent.LockProvider;
import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.factory.IsForTask;
import com.hcentive.billing.core.commons.factory.TaskAwareFactory;
import com.hcentive.billing.core.commons.service.health.ServiceInstanceHealthMonitor;
import com.hcentive.billing.core.commons.service.management.BETypeRegistrar;
import com.hcentive.billing.core.commons.service.security.ChecksumSupportMd5NonceMatcher;
import com.hcentive.billing.core.commons.service.security.filter.SecurityRedirectUrlBuilder;
import com.hcentive.billing.core.commons.service.web.CurrentDateResolver;
import com.hcentive.billing.core.commons.service.web.CustomDateResolver;
import com.hcentive.billing.core.commons.service.web.DateResolver;
import com.hcentive.billing.core.commons.starter.tenant.identifier.WFMTenantIdentityProvider;
import com.hcentive.commons.cache.redis.RedisCacheConfiguration;

@Configuration
@EnableMBeanExport
@Import({ ProcessContextPersisterConfiguration.class, RedisCacheConfiguration.class, LocaleConfiguration.class })
public class BillingAutoConfiguration extends WebMvcAutoConfigurationAdapter {

	@Value("${service.name}")
	private String serviceName;

	@Value("${baseDir}")
	private String baseDir;

	@Value("${server.port}")
	private int serverPort;

	@PostConstruct
	public void beTypeRegistrar() {
		BETypeRegistrar.init();
	}

	@Bean
	public ChecksumSupportMd5NonceMatcher checksumSupportMd5NonceMatcher() {
		try {
			return new ChecksumSupportMd5NonceMatcher();
		} catch (final NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

	@Bean
	@ConditionalOnMissingBean
	public LockProvider defaultLockProvider() {
		return new DefaultLockProvider();
	}

	@Bean
	public JettyEmbeddedServletContainerFactory jettyServletContainer(@Value("${serverx.threadPool.minSize:8}") final Integer minPoolSize,
			@Value("${serverx.threadPool.maxSize:200}") final Integer maxPoolSize, @Value("${serverx.threadPool.idleTime:5000}") final Integer threadIdleTime,
			@Value("${serverx.acceptor.count:1}") final Integer numberOfAcceptors) {

		final JettyEmbeddedServletContainerFactory jettyEmbeddedServletContainerFactory = new JettyEmbeddedServletContainerFactory(serverPort);
		jettyEmbeddedServletContainerFactory.setDocumentRoot(new File(baseDir));
		jettyEmbeddedServletContainerFactory.addServerCustomizers(new JettyServerCustomizer() {

			@Override
			public void customize(final Server server) {
				for(Connector y : server.getConnectors()) {
				    for(ConnectionFactory x  : y.getConnectionFactories()) {
				        if(x instanceof HttpConnectionFactory) {
				            ((HttpConnectionFactory)x).getHttpConfiguration().setSendServerVersion(false);
				        }
				    }
				}
				final QueuedThreadPool threadPool = server.getBean(QueuedThreadPool.class);
				threadPool.setMinThreads(minPoolSize);
				threadPool.setMaxThreads(maxPoolSize);
				threadPool.setIdleTimeout(threadIdleTime);
			}
		});
		return jettyEmbeddedServletContainerFactory;

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public TaskAwareFactory<IsForTask> securityRedirectUrlBuilderFactory() {
		final TaskAwareFactory<IsForTask> securityRedirectUrlBuilderFactory = new TaskAwareFactory(SecurityRedirectUrlBuilder.class);
		Factories.INSTANCE.registerBean(securityRedirectUrlBuilderFactory);
		return securityRedirectUrlBuilderFactory;
	}

	@Bean
	public ServiceInstanceHealthMonitor serviceInstanceHealthMonitor() {
		return new ServiceInstanceHealthMonitor();
	}

	/*
	 * @Bean
	 * 
	 * @ConditionalOnMissingBean public CacheClient<String, Object> cacheClient() { return new MemCachedClient<>(); }
	 */

	@Bean
	public WFMTenantIdentityProvider wfmTenantIdentityProvider() {
		return new WFMTenantIdentityProvider();
	}
	
	@Bean
	@ConditionalOnProperty(prefix = "custom.date", name = "filter",havingValue="true")
	public DateResolver customDateResolver(){
		return new CustomDateResolver();
	}
	
	@Bean
	@ConditionalOnMissingBean
	public DateResolver currentDateResolver(){
		return new CurrentDateResolver();
	}
}
