package com.hcentive.billing.core.commons.interservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.hcentive.billing.core.commons.domain.EventMasterData;
import com.hcentive.billing.core.commons.event.EventListener;
import com.hcentive.billing.core.commons.mq.AMQPConfigurer;
import com.hcentive.billing.core.commons.mq.MQAwareEventBus;
import com.hcentive.billing.core.commons.service.comm.ServiceCommManager.ChannelManager;
import com.hcentive.billing.core.commons.service.comm.ServiceConfig;
@ManagedResource(objectName = "billing:name=interService.channel.manager", 
description = "Manages consumer associated with event processing on interService queues", log = true, logFile = "jmx.log", currencyTimeLimit = 15)
public class MQBasedInterServiceChannelManager implements ChannelManager{
	
	private static Logger LOGGER = LoggerFactory.getLogger(MQBasedInterServiceChannelManager.class);
	
	private final MQAwareEventBus mqEventBus;
	private final ServiceConfig serviceConfig;
	private Integer minNumberOfWorkersRequest;
	private Integer maxNumberOfWorkersRequest;
	private Integer minNumberOfWorkersReply;
	private Integer maxNumberOfWorkersReply;
	
	
	private boolean serviceRequestHandlingEnabled = true;
	
	private boolean interServiceEnabled = true;
	
	public MQBasedInterServiceChannelManager(MQAwareEventBus mqEventBus,
			ServiceConfig serviceConfig, Integer minNumberOfWorkersRequest,
			Integer maxNumberOfWorkersRequest, Integer minNumberOfWorkersReply,
			Integer maxNumberOfWorkersReply) {
		this.mqEventBus = mqEventBus;
		this.serviceConfig = serviceConfig;
		this.minNumberOfWorkersRequest = minNumberOfWorkersRequest;
		this.maxNumberOfWorkersRequest = maxNumberOfWorkersRequest;
		this.minNumberOfWorkersReply = minNumberOfWorkersReply;
		this.maxNumberOfWorkersReply = maxNumberOfWorkersReply;
	}
	@Override
	public void registerForRequest(final String requestName,EventListener listener){
		if(interServiceEnabled && serviceRequestHandlingEnabled){
			mqEventBus.register(requestName, requestQueueName(), listener,true);
		}
	}
	@Override
	public void registerForReply(final String replyName,EventListener listener){
		if(interServiceEnabled){
			mqEventBus.register(replyName, replyQueueName(), listener,false);
		}
	}
	
	public void setServiceRequestHandlingEnabled(
			boolean serviceRequestHandlingEnabled) {
		this.serviceRequestHandlingEnabled = serviceRequestHandlingEnabled;
	}
	public void setInterServiceEnabled(boolean interServiceEnabled) {
		this.interServiceEnabled = interServiceEnabled;
	}
	public void initialize(){
		if(interServiceEnabled){
			//register replyQueue.
			AMQPConfigurer.registerQueue(replyQueueName(), false, false, 10,minNumberOfWorkersReply,maxNumberOfWorkersReply);
			if(serviceRequestHandlingEnabled){
				//register requestQueue.
				AMQPConfigurer.registerQueue(requestQueueName(), true, false, 7,minNumberOfWorkersRequest,maxNumberOfWorkersRequest);
			}
		}
	}
	private String requestQueueName() {
		return serviceConfig.serviceName()+"_Request";
	}
	private String replyQueueName() {
		return serviceConfig.identity()+"_Reply";
	}
	
	@ManagedOperation(description = "Sets the processingPriority, minNumberOfWorkers and maxNumberOfWorkers for the consumer associated with the ServiceRequest queue.")
	@ManagedOperationParameters(value = { @ManagedOperationParameter(description = "Sets the processingPriority of the consumer.", name = "processingPriority"),
			@ManagedOperationParameter(description = "Sets the minNumberOfWorkers threads of the consumer.", name = "minNumberOfWorkers"),
			@ManagedOperationParameter(description = "Sets the maxNumberOfWorkers threads of the consumer.", name = "maxNumberOfWorkers")})
	public String setServiceRequestProcessingParameters(final int processingPriority, Integer minNumberOfWorkers,
			Integer maxNumberOfWorkers) {
		this.minNumberOfWorkersRequest = minNumberOfWorkers;
		this.maxNumberOfWorkersRequest = maxNumberOfWorkers;
		AMQPConfigurer.modifyQueue(requestQueueName(), processingPriority,
				minNumberOfWorkers, maxNumberOfWorkers);
		return "Done";
	}
	
	@ManagedOperation(description = "Sets the processingPriority, minNumberOfWorkers and maxNumberOfWorkers for the consumer associated with the ServiceReply queue.")
	@ManagedOperationParameters(value = { @ManagedOperationParameter(description = "Sets the processingPriority of the consumer.", name = "processingPriority"),
			@ManagedOperationParameter(description = "Sets the minNumberOfWorkers threads of the consumer.", name = "minNumberOfWorkers"),
			@ManagedOperationParameter(description = "Sets the maxNumberOfWorkers threads of the consumer.", name = "maxNumberOfWorkers")})
	public String setServiceReplyProcessingParameters(final int processingPriority, Integer minNumberOfWorkers,
			Integer maxNumberOfWorkers) {
		this.minNumberOfWorkersReply = minNumberOfWorkers;
		this.maxNumberOfWorkersReply = maxNumberOfWorkers;
		AMQPConfigurer.modifyQueue(replyQueueName(), processingPriority,
				minNumberOfWorkers, maxNumberOfWorkers);
		return "Done";
	}
}
