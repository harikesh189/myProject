package com.hcentive.billing.core.commons.service.init;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;

import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.hcentive.billing.core.commons.exception.StandardErrorCodes;
import com.hcentive.billing.core.commons.io.DefaultSerializer;
import com.hcentive.billing.core.commons.io.SerializationUtil;
import com.hcentive.billing.core.commons.mq.AMQPConfigurer.EventMessagePostProcessor;
import com.hcentive.billing.core.commons.mq.MQEventConsumer;
import com.hcentive.billing.core.commons.service.event.EventMessageDurabilityManager;
import com.hcentive.billing.core.commons.service.event.EventPayloadMongoStore;
import com.hcentive.billing.core.commons.service.event.EventPayloadRedisStore;
import com.hcentive.billing.core.commons.service.event.PublishToDeadLetterEventExceptionHandler;

@Configuration
public class EventAutoConfiguration {

	@Bean
	public PublishToDeadLetterEventExceptionHandler eventExceptionHandler() {
		final Map<String, ErrorCode> errorCodes = new HashMap<>();
		errorCodes.put(DataAccessException.class.getName(), StandardErrorCodes.DATABASE_CONTRAINT_VOILATION);
		return new PublishToDeadLetterEventExceptionHandler(errorCodes);
	}

	@Bean
	public EventMessagePostProcessor eventMessageDurabilityManager() {
		return new EventMessageDurabilityManager();
	}

	// @Bean
	@ConditionalOnProperty(name = "mongo.event.handling")
	public EventPayloadMongoStore eventPayloadMongoStore() {
		return new EventPayloadMongoStore();
	}

	// @Bean
	@ConditionalOnMissingBean
	public EventPayloadRedisStore eventPayloadRedisStore() {
		return new EventPayloadRedisStore();
	}

	// DeadLetterQueueConfiguration has customized implementation of MQEventConsumer. Rest all services use this bean only
	@Bean(name = "mqEventConsumer")
	@Scope("prototype")
	@ConditionalOnMissingBean
	public MQEventConsumer mqEventConsumer() {
		final MQEventConsumer eventListener = new MQEventConsumer();
		return eventListener;
	}

	@Bean
	public DefaultSerializer serializer() {
		final DefaultSerializer serializer = new DefaultSerializer();
		SerializationUtil.configure(serializer);
		return serializer;
	}
}
