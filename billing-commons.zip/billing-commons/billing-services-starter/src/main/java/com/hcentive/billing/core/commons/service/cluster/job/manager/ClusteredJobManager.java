package com.hcentive.billing.core.commons.service.cluster.job.manager;

import com.hcentive.billing.core.commons.vo.DateTime;

public interface ClusteredJobManager {

	void updateJobExcecution(String jobId);

	boolean isJobExecutableAndMark(String jobName, int noOfinstances,
			DateTime expirationDate, String jobId, String macAddress);

	void removeOldJobs();
}
