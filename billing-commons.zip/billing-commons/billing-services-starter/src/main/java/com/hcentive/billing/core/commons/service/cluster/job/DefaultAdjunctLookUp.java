/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.service.cluster.job;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.id.AdjunctLookUp;

@Component
public class DefaultAdjunctLookUp implements AdjunctLookUp {

	private static Logger logger = LoggerFactory.getLogger(DefaultAdjunctLookUp.class);
	@Override
	public List<String> lookup(String key) {
		if(key == null || key.isEmpty()){
			logger.debug("trying to fetch prefix for external Id while key is either null or emty");
			return null;
		}
		
		return ConfigurationUtil.get(key);
	}

}


