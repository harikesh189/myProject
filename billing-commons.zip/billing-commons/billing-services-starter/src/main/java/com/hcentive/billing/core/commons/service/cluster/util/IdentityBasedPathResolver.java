/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.service.cluster.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.zookeeper.PathResolver;

public class IdentityBasedPathResolver implements PathResolver {

	private Logger logger = LoggerFactory
			.getLogger(IdentityBasedPathResolver.class);

	public synchronized String resolve(Object obj) {
		String type;
		String identity;
		String tenant;
		if (obj instanceof IdentityAware) {
			IdentityAware identityAware = (IdentityAware) obj;
			type = obj.getClass().getSimpleName();
			identity = identityAware.getIdentity();
			tenant = TenantUtil.getTenantId();
		} else {
			logger.error("znode path can not be created for non entity object",
					obj);
			throw new RuntimeException("not supported for non entity Objects");
		}
		logger.debug("returning znode Path: " + "/" + type + "/" + identity);
		if(tenant != null && !tenant.isEmpty()){
			return "/" +tenant + "/" + type + "/" + identity;
		}
		return "/" + type + "/" + identity;
	}

	@Override
	public boolean canHandle(Object obj) {
		if (obj instanceof IdentityAware)
			return true;
		return false;
	}

}
