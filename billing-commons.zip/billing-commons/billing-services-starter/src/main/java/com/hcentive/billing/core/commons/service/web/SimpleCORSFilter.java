package com.hcentive.billing.core.commons.service.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;

/**
 * @author Prateek.Bansal Filter to decorate response headers.
 */

public class SimpleCORSFilter implements Filter {

	private static final String ALLOWED_HEADERS = "X-Requested-With,auditinfo,Authorization,Content-Type,Content-Encoding,identity,lastnonce,nonce,roles,securitykey,tenantid,useridentity,App-Requested-With,user-credential,checksum";

	private static final Logger logger = LoggerFactory.getLogger(SimpleCORSFilter.class);

	@Autowired
	private WFMCache<String, Long> blackListedClientIPCache;

	@Autowired
	Environment env;

	@Value("${http.header.csp:default-src 'self' 'unsafe-eval';style-src 'self' https://fonts.googleapis.com/ 'unsafe-inline';font-src 'self'  https://fonts.gstatic.com;script-src 'self' https://www.google-analytics.com/ 'unsafe-eval' 'unsafe-inline'; img-src 'self' https://www.google-analytics.com/}")
	private String contentSecurityPolicy = "";

	@Override
	public void doFilter(final ServletRequest req, final ServletResponse res, final FilterChain chain)
			throws IOException, ServletException {
		logger.trace("In CORS Filter");
		try {
			ProcessContext.clear();
			final HttpServletRequest httpReq = (HttpServletRequest) req;
			final String browserName = httpReq.getHeader("User-Agent");
			final String httpMethod = httpReq.getMethod().toUpperCase();
			final String userAgent = httpReq.getHeader("User-Agent");
			logger.debug("Browser Name {}, User-Agent {}, httpMethod {}", browserName, userAgent, httpMethod);
			final HttpServletResponse httpResponse = (HttpServletResponse) res;

			// validateClientIP(httpReq, httpResponse);

			final String path = ((HttpServletRequest) req).getRequestURI();

			switch (httpMethod) {
			case "OPTIONS": {
				if (!this.verifyOrigin(httpReq, httpResponse)) {
					return;
				}
				this.addCorsHeaders(httpReq, res);
				return;
			}
			case "POST": {

			}

			case "GET": {
				if (this.verifyReferer(httpReq, httpResponse)) {
					this.addCorsHeaders(httpReq, res);
					try {
						chain.doFilter(req, res);
					} catch (Throwable t) {
						logger.error("Error while processing.", t);
						((HttpServletResponse) res).sendError(HttpServletResponse.SC_BAD_REQUEST);
					}
					return;
				}
				return;
			}
			default: {
				logger.error("Method not allowed");
				this.sendError(httpReq, httpResponse, HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			}
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			((HttpServletResponse) res).sendError(HttpServletResponse.SC_BAD_REQUEST);
		} finally {
			ProcessContext.clear();
			SecurityUtil.securityContextManager().clearSecurityContextFromThread();
		}

	}

	private boolean verifyOrigin(final HttpServletRequest httpReq, final HttpServletResponse response)
			throws IOException {
		return true;
	}

	private boolean verifyReferer(final HttpServletRequest request, final HttpServletResponse response)
			throws IOException {
		return true;
	}

	private void sendError(final HttpServletRequest request, final HttpServletResponse response, final int errorCode)
			throws IOException {
		ProcessContextUtil.initiateProcessContextWithIgnoreTenant();
		this.blackListedClientIPCache.put(request.getRemoteAddr(), System.currentTimeMillis());
		ProcessContextUtil.invoilateProcessContext();
		response.sendError(errorCode);
	}

	private void addCorsHeaders(final HttpServletRequest httpReq, final ServletResponse res) {
		final HttpServletResponse response = (HttpServletResponse) res;
		if (httpReq.getHeader("Origin") != null) {
			response.setHeader("Access-Control-Allow-Origin", httpReq.getHeader("Origin"));
		}
		if (null != env && ArrayUtils.contains(env.getActiveProfiles(), "dev")) {
			logger.info("\n\n\nCORS IS ENABLED !!!!! \n");
			response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
			response.setHeader("Access-Control-Max-Age", "3600");
			response.setHeader("Access-Control-Allow-Credential", "true");

		} else {
			logger.info("\n\n\nCORS IS NOT ENABLED !!!!! \n");
		}
		response.setHeader("Access-Control-Allow-Headers", ALLOWED_HEADERS);
		response.setHeader("Access-Control-Allow-Credentials", "true");
		response.setHeader("Cache-Control", "no-store, no-cache=set-cookie");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubdomains");
		response.setHeader("X-Content-Type-Options", "nosniff");
		response.setHeader("X-Frame-Options", "SAMEORIGIN");

		response.setHeader("Content-Security-Policy", contentSecurityPolicy);
		response.setHeader("X-XSS-Protection", "1; mode=block");
	}

	@Override
	public void init(final FilterConfig filterConfig) {
	}

	@Override
	public void destroy() {
	}

}
