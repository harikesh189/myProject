package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousAccessToken;
import com.hcentive.billing.core.commons.security.SecuredAccessContext;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.exception.AuthenticationFailed;
import com.hcentive.billing.core.commons.security.exception.AuthorizationDenied;
import com.hcentive.billing.core.commons.security.exception.SessionTimedOut;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.util.ClientAppToCookieNameMapping;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;
import com.hcentive.billing.core.commons.web.WebUtils;

public class CookieBasedSecuredAccessDataExtractor extends AbstractFilter {
	
	static final Logger LOGGER = LoggerFactory
			.getLogger(CookieBasedSecuredAccessDataExtractor.class);
	
	@Autowired
	private WFMCache<String, Set<String>> cache;
	
	@Value(value = "${security.login.page.url:{enterpriseName}/security/oAuth2/initiate}")
	private String securityLoginPageUrl;
	
	@Value(value = "${security.error.page.url:{enterpriseName}/security/error/{errorCode}}")
	private String securityErrorPageUrl;
	
	@Value(value = "${api.enterprise.location}")
	private int enterpiseLocationInURL;
	
	@Value(value = "${api.appKey.location:2}")
	private int appKeyLocationInURL;
	
	@Value(value = "${security.token.from.param:true}")
	private boolean retrieveTokenFromRequestParam;
	
	@Value(value = "${security.cookie.secure:true}")
	private boolean isCookieSecure;
	
	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;
	
	@Value(value = "${error.pattern:/error/}")
	private String errorPattern;
	
	@Autowired
	private FilterErrorHandler filterErrorHandler;
	
	private final SecurityRedirectUrlBuilder defaultBuilder = new DefaultLoginRedirectUrlBuilder();

	@Value(value = "${cookie.ignore.pattern:/**/*.html,/**/*.png,/**/*.gif,/**/*.jpg,/**/*.jpeg,/**/*.bmp,/**/*.js,/**/*.ico,/**/*.svg,/**/*.less,/**/*.map,/**/*.css,/**/*.woff,/**/*.ttf,/**/*.json,/configuration/**,/configurations/**}")
	private String[] ignorePattern = new String[0];
	
	@SuppressWarnings("static-access")
	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		LOGGER.debug("Inside filter");
		final HttpServletRequest httpRequest = ((HttpServletRequest) request);
		final HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		final String path = httpRequest.getRequestURI();
		
		LOGGER.debug("Request from path: {}",path);
		if(ignoreCurrentRequest(request)){
			LOGGER.debug("By passing cookie filter");
			chain.doFilter(request, response);
			return;
		}
		LOGGER.debug("Cookies Populate ");
		final String clientId = identifyClientId(httpRequest);
		final String accessTokenId = reterieveTokenId(httpRequest,httpServletResponse,clientId);
		final String enterpriseName = WebUtils.resolve(request, enterpiseLocationInURL);
		LOGGER.debug("Enterprise Resolved : {}",enterpriseName);
		if(accessTokenId == null && clientId != null){
			redirectToLogin(httpRequest, httpServletResponse, clientId,
					enterpriseName);
			return;
		}else if (accessTokenId != null) {
			LOGGER.debug("Associating user with identity {}", accessTokenId);
			try {
				LOGGER.debug("Creating Secured Access Context");
				SecuredAccessContext.createNew(accessTokenId);
				if(null!=clientId && !path.contains(errorPattern)){
					try{
							LOGGER.debug("Checking permission for clientId {}, against token ", clientId);
							SecurityUtil.securityContextManager().checkPermission(clientId);
							LOGGER.debug("Token Have Permission {}, against token ", clientId);
							final String pathArray[] = httpRequest.getRequestURI().split(clientId+"/");
							if(pathArray != null && pathArray.length > 1){
								sendRedirectWithAngularContext(httpRequest,
										httpServletResponse, clientId,
										pathArray);
							}
					}catch(AuthorizationDenied ad){
						handleAuthorizationDenied(httpRequest,
								httpServletResponse, clientId, enterpriseName,
								ad);
						return;
					}
				}
			}catch(SessionTimedOut e){ 
				LOGGER.error("Session Timed Out for token: {}",accessTokenId);
				final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
				WebUtils.clearCookie(httpRequest, httpServletResponse,"/",isCookieSecure,BillingConstant.COOKIE_SID+cookieIdentifier);
				handleErrorInCaseOfSecurityUI(request, httpServletResponse,
						clientId, accessTokenId, cookieIdentifier,HttpServletResponse.SC_GATEWAY_TIMEOUT);
				
				final String errorUrl= createErrorUrl(clientId, httpRequest, enterpriseName, e.ERROR_CODE);
				filterErrorHandler.handleSessionTimeOut(httpRequest, httpServletResponse, errorUrl);
				LOGGER.debug("Returning from Secured Filter");
				return;
			}catch (AuthenticationFailed e) {
				LOGGER.error("Authentication Exception Occured");
				final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
				WebUtils.clearCookie(httpRequest, httpServletResponse,"/",isCookieSecure,BillingConstant.COOKIE_SID+cookieIdentifier);
				handleErrorInCaseOfSecurityUI(request, httpServletResponse,
						clientId, accessTokenId, cookieIdentifier,HttpServletResponse.SC_UNAUTHORIZED);
				final String errorUrl= createErrorUrl(clientId, httpRequest, enterpriseName, e.ERROR_CODE);
				filterErrorHandler.handleAuthenticationFailed(httpRequest, httpServletResponse, errorUrl);
				LOGGER.debug("Returning from Secured Filter");
				return;
			}

		} else{
			LOGGER.info("Access Token is null and client id is also null");
		}
		chain.doFilter(request, response);
		LOGGER.debug("End filter");
	}




	protected void sendRedirectWithAngularContext(
			final HttpServletRequest httpRequest,
			final HttpServletResponse httpServletResponse,
			final String clientId, final String[] pathArray) throws IOException {
		LOGGER.debug("Building URL with angular context");
		final StringBuilder urlWithAngularContext = new StringBuilder(WebUtils.getBaseUrl(httpRequest));
		urlWithAngularContext.append(pathArray[0]).append(clientId).append("/").append("#").append(pathArray[1]);
		if(httpRequest.getQueryString() != null){
			urlWithAngularContext.append("?").append(httpRequest.getQueryString());
		}
		LOGGER.debug("Redirecting to URL: {}",urlWithAngularContext);
		httpServletResponse.sendRedirect(urlWithAngularContext.toString());
	}




	private void handleErrorInCaseOfSecurityUI(ServletRequest request,
			final HttpServletResponse httpServletResponse,
			final String clientId, final String accessTokenId,
			final String cookieIdentifier, final int errorCode) throws IOException,
			IllegalAccessError {
		if(null != clientId && clientId.equals("security-ui")){
			LOGGER.error("Token is for one time use only.");
			resetCookie(request, httpServletResponse, accessTokenId,
					cookieIdentifier);
			httpServletResponse.sendError(errorCode);
			throw new IllegalAccessError("Token is for one time use only.");
		}
	}




	private void resetCookie(ServletRequest request,
			final HttpServletResponse httpServletResponse,
			final String accessTokenId, final String cookieIdentifier) {
		Cookie cookie = new Cookie(BillingConstant.COOKIE_SID+cookieIdentifier,  accessTokenId);
		cookie.setHttpOnly(true);
		cookie.setSecure(isCookieSecure);
		cookie.setPath("/");
		cookie.setDomain("." + request.getServerName());
		cookie.setMaxAge(0);
		httpServletResponse.addCookie(cookie);
	}




	@SuppressWarnings("static-access")
	private void handleAuthorizationDenied(
			final HttpServletRequest httpRequest,
			final HttpServletResponse httpServletResponse,
			final String clientId, final String enterpriseName,
			AuthorizationDenied ad) throws IOException {
		LOGGER.error("Illegal Access, User doesnot have permission for the particular client : {}",clientId);
		final AccessToken accessToken = Utils.getAccessToken();
		if(accessToken instanceof AnonymousAccessToken){
			redirectToLogin(httpRequest, httpServletResponse, clientId,
					enterpriseName);
			LOGGER.error("Redirecting to Login");
			return;
		}
		LOGGER.error("Access Denied");
		httpServletResponse.sendRedirect(createErrorUrl(clientId, httpRequest, enterpriseName, ad.ERROR_CODE));
	}




	private void redirectToLogin(final HttpServletRequest httpRequest,
			final HttpServletResponse httpServletResponse,
			final String clientId, final String enterpriseName)
			throws IOException {
		LOGGER.debug("Access Token is null");
		String redirectUrl = createLoginUrl(clientId,httpRequest,enterpriseName);
		redirectUrl = buildAngularContext(httpRequest, clientId, redirectUrl);
		LOGGER.debug("Redirected URL is {}",redirectUrl);
		httpServletResponse.sendRedirect(redirectUrl);
	}




	private String buildAngularContext(final HttpServletRequest httpRequest,
			final String clientId, String redirectUrl) {
		final StringBuilder redirectUrlBuilder = new StringBuilder(redirectUrl);
		final String pathArray[] = httpRequest.getRequestURI().split(clientId+"/");
		if(pathArray != null && pathArray.length > 1){
			final String queryString = httpRequest.getQueryString();
			redirectUrlBuilder.append("&redirect_uri=").append(pathArray[1]);
			if(null != queryString){
				redirectUrlBuilder.append("?").append(queryString);
			}
			redirectUrl = redirectUrlBuilder.toString();
		}
		return redirectUrl;
	}




	private String reterieveTokenId(final HttpServletRequest httpRequest,final HttpServletResponse httpResponse,final String clientId) {
		final Map<String, String> sessionParams = WebUtils.getCookiesFromRequest(httpRequest);
		LOGGER.debug("session Params:: size :: {}", sessionParams.keySet()
				.toString());
		String encryptedTokenId = null;
		if(retrieveTokenFromRequestParam){
			encryptedTokenId = httpRequest.getParameter("tokenId");
			LOGGER.debug("Token Retrieved from Request Param: {}",encryptedTokenId);
			if(null != encryptedTokenId){
				LOGGER.debug("Decrypting token recieved from request param: {}",encryptedTokenId);
				populateCookieForRequestParamToken(httpRequest, httpResponse, encryptedTokenId,securityUIAppKey);
				return  WebUtils.decryptTokenId(encryptedTokenId);
			}
		}
		final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
		encryptedTokenId = sessionParams.get(BillingConstant.COOKIE_SID+cookieIdentifier);
		LOGGER.debug("Encrypted Token ID from cookie sid : {}",encryptedTokenId);
		String accessTokenId = encryptedTokenId != null ? WebUtils.decryptTokenId(encryptedTokenId) : null;
		LOGGER.debug("Access Token Found : {}",accessTokenId);
		return accessTokenId;
	}




	private String createLoginUrl(final String clientId,final HttpServletRequest request,final String enterpriseName) {
		final String redirectUrl = getBuilder(clientId).createLoginUrl(request, enterpriseName);
		LOGGER.debug("Login URL: {}",redirectUrl);
		return redirectUrl;
	}
	
	private String createErrorUrl(final String clientId,final HttpServletRequest request,final String enterpriseName,int errorCode) {
		String redirectUrl = securityErrorPageUrl;
		redirectUrl = WebUtils.replaceEnterprise(enterpriseName, redirectUrl);
		redirectUrl = redirectUrl.replaceAll("\\{errorCode\\}", errorCode+"");
		redirectUrl = WebUtils.getBaseUrl(request)+"/"+redirectUrl+"?client_id="+clientId+"&response_type=token";
		LOGGER.debug("Error Redirect URL: {}",redirectUrl);
		return redirectUrl;
	}


	private String identifyClientId(final HttpServletRequest request) {
		ProcessContextUtil.initiateProcessContextWithIgnoreTenant();
		LOGGER.debug("Getting Registered Client Apps from cache");
		final Set<String> registeredClientApps = cache.get(BillingConstant.REGISTERED_CLIENT_APPS);
		LOGGER.debug("Client Apps Found : {}",registeredClientApps);
		ProcessContextUtil.invoilateProcessContext();
		String clientId = null;
		if(appKeyLocationInURL > 0)
			clientId = WebUtils.parseClientId(request, registeredClientApps,appKeyLocationInURL,appKeyLocationInURL+1);
		LOGGER.debug("Client Id found : {}",clientId);
		return clientId;
	}
	
	private class DefaultLoginRedirectUrlBuilder implements SecurityRedirectUrlBuilder{

		@Override
		public boolean canHandle(final String clientId) {
			return true;
		}

		@Override
		public String createLoginUrl(HttpServletRequest request,
				String enterpriseName) {
			String redirectUrl = securityLoginPageUrl;
			redirectUrl = WebUtils.replaceEnterprise(enterpriseName, redirectUrl);
			redirectUrl = WebUtils.getBaseUrl(request)+"/"+redirectUrl+"?client_id="+identifyClientId(request)+"&response_type=token";
			LOGGER.debug("Login URL: {}",redirectUrl);
			return redirectUrl;
		}
		
	}
	
	@SuppressWarnings("unchecked")
	private SecurityRedirectUrlBuilder getBuilder(final String clientId){
		SecurityRedirectUrlBuilder urlBuilder = null;
		try{
			urlBuilder = (SecurityRedirectUrlBuilder) Factories.INSTANCE.factory(SecurityRedirectUrlBuilder.class).get(clientId);
		}catch(IllegalStateException e){
			return defaultBuilder;
		}
		return urlBuilder;
	}



	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected String[] getIgnorePathPattern() {
		return this.ignorePattern;
	}
}
