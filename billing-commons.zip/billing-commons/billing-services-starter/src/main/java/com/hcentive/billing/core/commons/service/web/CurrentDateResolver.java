package com.hcentive.billing.core.commons.service.web;

import java.util.Date;

import com.hcentive.billing.core.commons.vo.DateTime;


public class CurrentDateResolver implements DateResolver {

	@Override
	public Date getDate() {		
		return new DateTime().getDate();
	}

}
