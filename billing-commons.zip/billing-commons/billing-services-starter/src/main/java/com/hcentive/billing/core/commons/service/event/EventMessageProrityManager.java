package com.hcentive.billing.core.commons.service.event;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.mq.AMQPConfigurer.EventMessagePostProcessor;
import com.hcentive.billing.core.commons.service.comm.Service;
import com.hcentive.billing.core.commons.service.comm.ServiceResponse;

public class EventMessageProrityManager implements EventMessagePostProcessor {
	
	@Override
	public Message postProcessMessage(final Event event,final Message message) {
		final MessageProperties messageProperties = message.getMessageProperties();
		if (event.getHeader(Service.SERVICE_EVENT) != null) {
			setPriorityForServiceEvent(event, messageProperties);
		}else{
			messageProperties.setPriority(1);
		}
		return message;
	}

	private void setPriorityForServiceEvent(final Event event,
			final MessageProperties messageProperties) {
			final Object payload = event.payload();
			if(payload instanceof ServiceResponse){
				messageProperties.setPriority(6);
			}else{
				messageProperties.setPriority(5);
			}
	}

	

}
