package com.hcentive.billing.core.commons.service.web;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class CustomDateResolver implements DateResolver {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomDateResolver.class);

	@Value(value = "${custom.date.query:select d.custom_date from system_date d where d.tenant_id=? }")
	private String dateQuery;

	@Autowired
	EntityManager entityManager;

	@Override
	public Date getDate() {
		try {
			final Query query = entityManager.createNativeQuery(dateQuery);
			query.setParameter(1, ProcessContext.get().getTenantId());
			query.setMaxResults(1);
			final List<?> dates = query.getResultList();
			if (dates != null && !dates.isEmpty()) {
				return new Date(((Date) dates.iterator().next()).getTime());

			}
		} catch (final Exception e) {
			LOGGER.error("Failed to retrieve custom date from database.", e);
		}

		return new DateTime().getDate();
	}

}
