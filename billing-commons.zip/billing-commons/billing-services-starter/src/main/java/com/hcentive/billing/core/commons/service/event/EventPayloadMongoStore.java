package com.hcentive.billing.core.commons.service.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.hcentive.billing.core.commons.mq.support.EventPayloadStore;

public class EventPayloadMongoStore implements EventPayloadStore {

	private static final String EVENT_PAYLOAD_COLLECTION_PREFIX = "EVENT_PAYLOAD_";
	private static final Logger LOGGER = LoggerFactory
			.getLogger(EventPayloadMongoStore.class);
	@Autowired
	private MongoOperations mongo;

	public String store(final String routeKey, Object payload) {
		final EventPayloadContext context = EventPayloadContext
				.newContext(routeKey);
		try {
			final EventPayloadWrapper wrapper = new EventPayloadWrapper(payload);
			LOGGER.debug("Saving payload for routeKey: {}", routeKey);
			mongo.save(wrapper, resolveCollectionName(routeKey));
			final String refId = wrapper.identity();
			LOGGER.debug("Saved payload for routeKey: {}. ReferenceId : {}",
					routeKey, refId);
			return refId;
		} finally {
			context.clear();
		}
	}

	private String resolveCollectionName(final String routeKey) {
		return EVENT_PAYLOAD_COLLECTION_PREFIX+routeKey.toUpperCase();
	}

	public Object find(final String routeKey, String payloadRefId) {
		final EventPayloadContext context = EventPayloadContext
				.newContext(routeKey);
		try {
			LOGGER.debug(
					"Fetching payload for routeKey: {} && referenceId: {}",
					routeKey, payloadRefId);
			final Query query =Query.query(Criteria.where(EventPayloadWrapper.FIELD_IDENTITY).is(payloadRefId));
			final EventPayloadWrapper wrapper = mongo.findOne(query, EventPayloadWrapper.class, resolveCollectionName(routeKey));
			if (null != wrapper) {
				LOGGER.debug(
						"Found payload for routeKey: {} && referenceId: {}",
						routeKey, payloadRefId);
				return wrapper.payload();
			}else{
				LOGGER.warn(
						"Could not find payload for routeKey: {} && referenceId: {}",
						routeKey, payloadRefId);
				return null;
			}
		} finally {
			context.clear();
		}
	}

	public Object remove(final String routeKey, String payloadRefId) {
		final EventPayloadContext context = EventPayloadContext
				.newContext(routeKey);
		try {
			LOGGER.debug(
					"Removing payload for routeKey: {} && referenceId: {}",
					routeKey, payloadRefId);
			final EventPayloadWrapper wrapper = (EventPayloadWrapper)find(routeKey,payloadRefId);
			if (null != wrapper) {
				LOGGER.debug(
						"Found payload for routeKey: {} && referenceId: {}",
						routeKey, payloadRefId);
				mongo.remove(wrapper,resolveCollectionName(routeKey));
				LOGGER.debug(
						"Removed payload for routeKey: {} && referenceId: {}",
						routeKey, payloadRefId);
				return wrapper.payload();
			}else{
				LOGGER.warn(
						"Could not find payload for routeKey: {} && referenceId: {}",
						routeKey, payloadRefId);
				return null;
			}
		} finally {
			context.clear();
		}
	}
}
