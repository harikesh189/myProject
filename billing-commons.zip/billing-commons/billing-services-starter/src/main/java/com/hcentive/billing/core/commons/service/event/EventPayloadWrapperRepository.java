package com.hcentive.billing.core.commons.service.event;

import org.springframework.data.mongodb.repository.MongoRepository;


public interface EventPayloadWrapperRepository extends MongoRepository<EventPayloadWrapper, String>{

}
