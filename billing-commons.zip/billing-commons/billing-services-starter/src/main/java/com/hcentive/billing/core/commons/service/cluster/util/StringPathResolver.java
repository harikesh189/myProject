package com.hcentive.billing.core.commons.service.cluster.util;

import com.hcentive.billing.core.commons.zookeeper.PathResolver;

public class StringPathResolver implements PathResolver {

	@Override
	public String resolve(Object obj) {
		return "/primitive/string/"+obj.toString();
	}

	@Override
	public boolean canHandle(Object obj) {
		return String.class.isAssignableFrom(obj.getClass());
	}

}
