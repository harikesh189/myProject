package com.hcentive.billing.core.commons.service.event;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.EventHistory;
import com.hcentive.billing.core.commons.domain.EventMasterData;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventInterceptorAdaptor;
import com.hcentive.billing.core.commons.event.EventListener;
import com.hcentive.billing.core.commons.service.comm.ServiceConfig;
import com.hcentive.billing.core.commons.starter.persistence.repository.EventHistoryRepository;
import com.hcentive.billing.core.commons.starter.persistence.repository.EventMasterDataRepository;

public class EventHistoryLoggerInterceptor extends EventInterceptorAdaptor {

	//@Autowired
	//private EventHistoryRepository eventHistoryRepository;
	
	//@Autowired
	//private EventMasterDataRepository eventMasterDataRepository;

	@Autowired
	private ServiceConfig serviceConfig;
	
	private static Logger LOGGER = LoggerFactory.getLogger(EventHistoryLoggerInterceptor.class);

	@Override
	public void beforeProcessing(Event<?> event) {
		/*LOGGER.debug("Intrecepted Event {} before Proccesing", event.getName());
		eventHistoryRepository
				.save(new EventHistory(event.getName(), serviceConfig.serviceName(),serviceConfig.instanceId(),
						event.getHeader(EventHeaderConstant.ORIGIN_SERVICE_NAME).toString(),
						event.getHeader(EventHeaderConstant.ORIGIN_INSTANCE_ID).toString()));*/
	}

	@Override
	public void beforeRegister(String eventName,EventListener eventListener) {
	//	LOGGER.debug("Intrecepted Event {} before registration", eventName);
	//	eventMasterDataRepository.save(new EventMasterData(eventName,serviceConfig.serviceName(),serviceConfig.instanceId()));
	}
	
	@Override
	public int priority() {
		return 5;
	}

}
