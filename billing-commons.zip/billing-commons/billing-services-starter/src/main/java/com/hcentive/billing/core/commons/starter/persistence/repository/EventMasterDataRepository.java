package com.hcentive.billing.core.commons.starter.persistence.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hcentive.billing.core.commons.domain.EventMasterData;

public interface EventMasterDataRepository extends MongoRepository<EventMasterData, String> {

}
