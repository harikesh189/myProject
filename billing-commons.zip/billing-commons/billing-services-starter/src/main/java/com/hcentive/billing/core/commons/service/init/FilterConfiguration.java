package com.hcentive.billing.core.commons.service.init;

import java.net.InetSocketAddress;
import java.net.Proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;

import com.hcentive.billing.core.commons.condition.ConditionalOnBeanNameAbsent;
import com.hcentive.billing.core.commons.service.security.filter.AdminUrlCallChecker;
import com.hcentive.billing.core.commons.service.security.filter.AssociatedPartiesCallChecker;
import com.hcentive.billing.core.commons.service.security.filter.BEMatcherFilter;
import com.hcentive.billing.core.commons.service.security.filter.CreateSystemUserContextFilter;
import com.hcentive.billing.core.commons.service.security.filter.DefaultFilterErrorHandler;
import com.hcentive.billing.core.commons.service.security.filter.FilterErrorHandler;
import com.hcentive.billing.core.commons.service.security.filter.HttpCreateProcessContextFilter;
import com.hcentive.billing.core.commons.service.security.filter.HttpSecuredAccessDataExtractor;
import com.hcentive.billing.core.commons.service.security.filter.RemoteURLFilter;
import com.hcentive.billing.core.commons.service.util.FilterRegistrationUtil;
import com.hcentive.billing.core.commons.service.web.SimpleCORSFilter;

@Configuration
public class FilterConfiguration {

	/**
	 * {@link Logger} Logger
	 */
	private static final Logger log = LoggerFactory
			.getLogger(FilterConfiguration.class);

	@Value(value = "${http.proxyHost:null}")
	private String httpProxyHost;

	@Value(value = "${http.proxyPort:-1}")
	private int httpProxyPort;

	@Value(value = "${https.proxyHost:null}")
	private String httpsProxyHost;

	@Value(value = "${https.proxyPort:-1}")
	private int httpsProxyPort;

	@Value(value = "${secured.access.token.based.filter.path:/*}")
	private String securedAccessTokenBasedFilterPath;

	@Bean
	@ConditionalOnProperty(prefix = "system.user.access", name = "filter", havingValue = "true")
	public CreateSystemUserContextFilter createSystemUserContextFilter() {
		return new CreateSystemUserContextFilter();
	}

	@Bean
	@ConditionalOnProperty(prefix = "system.user.access", name = "filter", havingValue = "true")
	public FilterRegistrationBean createSystemUserContextFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(createSystemUserContextFilter(), "/*");
		filterRegistrationBean.setOrder(2);
		return filterRegistrationBean;
	}

	
	/**
	 * CORS fileter to be registered only in dev environment.
	 * @return
	 */
	@Bean
	public SimpleCORSFilter simpleCORSFilter() {
		return new SimpleCORSFilter();
	}

	@Bean
	public FilterRegistrationBean createSimpleCORSFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(simpleCORSFilter(), null);
		filterRegistrationBean.setOrder(1);
		return filterRegistrationBean;
	}

	@Bean
	@ConditionalOnBeanNameAbsent
	public HttpCreateProcessContextFilter httpCreateProcessContextFilter() {

		return new HttpCreateProcessContextFilter();
	}

	@Bean
	@ConditionalOnBeanNameAbsent
	public FilterRegistrationBean createProcessContextFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(httpCreateProcessContextFilter(), null);
		filterRegistrationBean.setOrder(6);
		return filterRegistrationBean;
	}

	@Bean
	@ConditionalOnProperty(prefix = "http.secured.access", name = "filter", matchIfMissing = true)
	public HttpSecuredAccessDataExtractor httpSecuredAccessDataExtractor() {
		return new HttpSecuredAccessDataExtractor();
	}

	@Bean
	@ConditionalOnProperty(prefix = "http.secured.access", name = "filter", matchIfMissing = true)
	public FilterRegistrationBean createHttpSecuredDataAccessFilterRegistration() {
		String[] securedAccessPaths = splitFilterPathByComma(securedAccessTokenBasedFilterPath);
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(httpSecuredAccessDataExtractor(),
						securedAccessPaths);
		filterRegistrationBean.setOrder(5);
		return filterRegistrationBean;
	}

	private String[] splitFilterPathByComma(
			final String securedAccessTokenBasedFilterPath) {
		final String[] filterPaths = securedAccessTokenBasedFilterPath
				.split(",");
		return filterPaths;
	}

	@Bean
	public AdminUrlCallChecker adminUrlCallChecker() {
		return new AdminUrlCallChecker();
	}

	@Bean
	public FilterRegistrationBean createAdminUrlCheckerFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(adminUrlCallChecker(), null);
		filterRegistrationBean.setOrder(10);
		return filterRegistrationBean;
	}

	@Bean
	public AssociatedPartiesCallChecker associatedPartiesCallChecker() {
		return new AssociatedPartiesCallChecker();
	}

	@Bean
	public FilterRegistrationBean createAssociatePartiesFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(associatedPartiesCallChecker(), null);
		filterRegistrationBean.setOrder(11);
		return filterRegistrationBean;
	}

	@Bean
	public BEMatcherFilter beMatcherFilter() {
		return new BEMatcherFilter();
	}

	@Bean
	public FilterRegistrationBean createBEMatcherFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(beMatcherFilter(), null);
		filterRegistrationBean.setOrder(9);
		return filterRegistrationBean;
	}
	
	
	@Bean
	public RemoteURLFilter remoteUrlFilter() {
		return new RemoteURLFilter();
	}
	
	@Bean
	public FilterRegistrationBean createRemoteUrlFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(remoteUrlFilter(), null);
		filterRegistrationBean.setOrder(12);
		return filterRegistrationBean;
	}

	@Bean
	public RestTemplate restTemplate() {
		final RestTemplate restTemplate = new RestTemplate();
		final SimpleClientHttpRequestFactory requestFactory = getClientHttpRequestFactory();
		if (null != requestFactory) {
			restTemplate.setRequestFactory(requestFactory);
		}
		return restTemplate;
	}

	@Bean
	public SimpleClientHttpRequestFactory getClientHttpRequestFactory() {
		log.trace(
				"Creating SimpleClientHttpRequestFactory - httpsProxyHost={},httpsProxyPort={},httpProxyHost={},httpProxyPort={}",
				httpsProxyHost, httpsProxyPort, httpProxyHost, httpProxyPort);
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		if (null != httpsProxyHost && httpsProxyPort > 0) {
			// https proxy settings present
			final Proxy proxy = new Proxy(Proxy.Type.HTTP,
					new InetSocketAddress(httpsProxyHost, httpsProxyPort));
			requestFactory.setProxy(proxy);
			requestFactory = getClientHttpRequestFactory();
		} else if (null != httpProxyHost && httpProxyPort > 0) {
			// http proxy settings present
			final Proxy proxy = new Proxy(Proxy.Type.HTTP,
					new InetSocketAddress(httpsProxyHost, httpProxyPort));
			requestFactory.setProxy(proxy);
		}
		return requestFactory;
	}

	@Bean
	public AsyncRestTemplate asyncRestTemplate() {
		final AsyncRestTemplate asyncRestTemplate = new AsyncRestTemplate(
				getClientHttpRequestFactory(), restTemplate());
		return asyncRestTemplate;
	}

	@Bean
	@ConditionalOnBeanNameAbsent
	public FilterErrorHandler filterErrorHandler() {
		return new DefaultFilterErrorHandler();
	}
}
