/**
 * 
 */
package com.hcentive.billing.core.exception;

/**
 * 
 * Exception when a resource cannot be found cannot be found for given identity.
 * 
 * @author Kumar Sambhav Jain
 * 
 */
public class ResourceNotFoundException extends Exception {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1784246254625560167L;

	private String identity;

	private String entityName;

	/**
	 * @param identity
	 * @param entityName
	 */
	public ResourceNotFoundException(String identity, String entityName) {
		super();
		this.identity = identity;
		this.entityName = entityName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return entityName + " not found for" + identity;
	}
}
