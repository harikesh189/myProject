package com.hcentive.billing.core.commons.service.event;

import java.net.HttpURLConnection;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.security.shiro.Application;
import com.hcentive.billing.core.commons.service.rmi.DefaultSpringHttpRMIInterceptorRegistry;
import com.hcentive.billing.core.commons.service.rmi.SpringHttpRMIInterceptorAdaptor;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
public class PrePublishTenantIdEnricher extends SpringHttpRMIInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(PrePublishTenantIdEnricher.class);

	@Override
	public void beforePublishing(Event event) {
		final ProcessContext processContext = ProcessContext.get();

		Assert.notNull(processContext, "Process context is missing");
		
		if (processContext != null && !processContext.shouldIgnoreTenant()) {
			final String tenantId = TenantUtil.getTenantId();
			Assert.notNull(tenantId, "Tenant is missing in process context (" + processContext.id() + " )");
			LOGGER.debug("Adding tenant in header, TENANT_IDENTITY_KEY :: {}", tenantId);
			event.addHeader(EventHeaderConstant.TENANT_IDENTITY_KEY, tenantId);
			final String loggedInUserId = processContext.getUserId();
			final String loggedInUserName = processContext.getUserName();
			if ((null != loggedInUserId && !loggedInUserId.equals(Application.INSTANCE.getIdentity()))
					&& (null != loggedInUserName && !loggedInUserName.equals(Application.INSTANCE.getIdentity()))) {
				LOGGER.debug("logged in user id is {} and username {}", loggedInUserId, loggedInUserName);
				event.addHeader(EventHeaderConstant.EVENT_INITIATED_BY_USER_ID_KEY, loggedInUserId);
				event.addHeader(EventHeaderConstant.EVENT_INITIATED_BY_USER_NAME_KEY, loggedInUserName);
			}
		} 
	}

	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
		DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.addInterceptors(this);
	}

	@Override
	public int priority() {
		return 0;
	}
	
	@Override
	public void beforeDispatch(HttpURLConnection con){
		final ProcessContext processContext = ProcessContext.get();
		Assert.notNull(processContext, "Process context is missing");
		if(processContext!=null && !processContext.shouldIgnoreTenant()){
			final String tenantId = TenantUtil.getTenantId();
			Assert.notNull(tenantId, "Tenant is missing in process context (" + processContext.id() + " )");
			LOGGER.debug("Adding tenant in header, TENANT_IDENTITY_KEY :: {}", tenantId);
			con.addRequestProperty(EventHeaderConstant.TENANT_IDENTITY_KEY, tenantId);
		} 
	}
}
