package com.hcentive.billing.core.commons.service.cluster.job.manager;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.concurrent.LockProvider;
import com.hcentive.billing.core.commons.domain.ClusterJob;
import com.hcentive.billing.core.commons.domain.ClusterJob.Status;
import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.starter.persistence.repository.ClusterJobRepository;
import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.core.commons.vo.DateTime;

@Component
public class DBClusteredJobManager implements ClusteredJobManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(DBClusteredJobManager.class);

	@Autowired
	ClusterJobRepository clusterJobRepository;
	@Value("${cluster.job.delete.after.days:1}")
	private Integer daysOld;
	
	@Value("${cluster.job.wait.timeout:5000}")
	private long timeOut;

	@Autowired
	LockProvider lockProvider;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateJobExcecution(String jobId) {
		ClusterJob clusterJob = clusterJobRepository.findByIdentity(jobId);
		clusterJob.setStatus(ClusterJob.Status.INACTIVE.toString());
		clusterJobRepository.save(clusterJob);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public boolean isJobExecutableAndMark(String jobName, int noOfinstances,
			DateTime expirationDate, String jobId, String macAddress) {
		Lock lock = null;
		try {
			lock = this.lockProvider.getLock(jobName);
			if (lock != null) {
				boolean acquired = lock.tryLock(timeOut, TimeUnit.MILLISECONDS);
				if (!acquired) {
					return false;
				}
			}
			List<ClusterJob> clusterJobList = clusterJobRepository
					.findByJobNameAndExpirationDateDateGreaterThanAndStatus(
							jobName, new DateTime().getDate(),
							ClusterJob.Status.ACTIVE.toString());
			if (clusterJobList != null
					&& (clusterJobList.size() < noOfinstances)) {
				ClusterJob clusterJob = new ClusterJob(jobId, jobName,
						expirationDate, macAddress);
				clusterJobRepository.save(clusterJob);
				return true;
			}
			return false;

		} catch (InterruptedException e) {
			LOGGER.error(e.getMessage());
			return false;
		} finally {
			if (lock != null) {
				this.lockProvider.release(lock);
			}
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void removeOldJobs() {
		LOGGER.debug("removing old clustered job");
		final Calendar instance = Calendar.getInstance();
		final Date today = DateUtility.clearTime(instance.getTime());
		final Date beforeThisDate = DateUtils.addDays(today, -daysOld);
		clusterJobRepository.deleteOldJobs(beforeThisDate, Status.INACTIVE.toString());
		LOGGER.debug("removed old clustered job");
	}
	
}
