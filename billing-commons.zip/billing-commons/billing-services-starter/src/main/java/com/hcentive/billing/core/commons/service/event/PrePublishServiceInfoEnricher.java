package com.hcentive.billing.core.commons.service.event;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventInterceptorAdaptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.service.comm.ServiceConfigurer;

@Component
public class PrePublishServiceInfoEnricher extends EventInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrePublishServiceInfoEnricher.class);

	@Override
	public void beforePublishing(Event<?> event) {
		LOGGER.info("Populating service name and instance id for event {}",
				event.getName());
		event.addHeader(EventHeaderConstant.ORIGIN_SERVICE_NAME,
				ServiceConfigurer.serviceConfig().serviceName());
		event.addHeader(EventHeaderConstant.ORIGIN_INSTANCE_ID,
				ServiceConfigurer.serviceConfig().instanceId());
	}

	@Override
	public int priority() {
		return 6;
	}
	
	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
	}

}
