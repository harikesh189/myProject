package com.hcentive.billing.core.commons.service.init;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.web.HttpMessageConverters;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.util.ClassUtils;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.hcentive.billing.core.commons.service.web.ChecksumCheckJSONConverter;

@Configuration
public class CustomConvertersConfiguration {
	@Autowired
	private ApplicationContext context;
	
	
	@Bean
	@ConditionalOnMissingBean
	public HttpMessageConverters messageConverters(){
		List<HttpMessageConverter<?>> converters = new ArrayList<>();
		converters.add(new Jaxb2RootElementHttpMessageConverter());
		converters.add(new ChecksumCheckJSONConverter(context));
		HttpMessageConverters messageConverters = new HttpMessageConverters(true, converters);
		return messageConverters;
	}
}
