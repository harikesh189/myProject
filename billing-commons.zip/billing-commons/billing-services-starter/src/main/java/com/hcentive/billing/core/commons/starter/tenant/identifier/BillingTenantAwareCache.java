/**
 * 
 */
package com.hcentive.billing.core.commons.starter.tenant.identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.cache.TenantAwareCache;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
public class BillingTenantAwareCache<V> extends TenantAwareCache<V> {

	private static final Logger logger = LoggerFactory.getLogger(BillingTenantAwareCache.class);

	@Override
	protected String getTenantAwareCacheKey(String key, V target) {
		if (null == key) {
			logger.debug("Memcached key cannot be null");
			throw new IllegalArgumentException("Memcached key cannot be null");
		}
		final ProcessContext pc = ProcessContext.get();
		if (pc != null && pc.shouldIgnoreTenant()) {
			logger.debug("get ProcessContext :" + pc);
			logger.debug("get key : {}", key);
			return key;
		}
		String tenant = TenantUtil.getTenantId();
		logger.debug("get tenant :" + tenant);
		if (null == tenant) {
			if (null != target && target instanceof TenantAware) {
				tenant = ((TenantAware) target).getTenantId();
			}
		}
		logger.debug("get tenant :" + tenant);
		if (null == tenant || tenant.isEmpty()) {
			throw new IllegalStateException("System could not resolve the tenant.");
		}
		logger.debug("get key : {}", tenant + "_" + key);
		return tenant + "_" + key;
	}

}
