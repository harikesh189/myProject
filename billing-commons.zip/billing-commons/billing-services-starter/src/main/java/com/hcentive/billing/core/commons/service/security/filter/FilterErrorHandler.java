package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface FilterErrorHandler {
	
	public void handleSessionTimeOut(final HttpServletRequest request, final HttpServletResponse response, final String errorUrl) throws IOException;
	
	public void handleAuthenticationFailed(final HttpServletRequest request, final HttpServletResponse response, final String errorUrl) throws IOException;

}
