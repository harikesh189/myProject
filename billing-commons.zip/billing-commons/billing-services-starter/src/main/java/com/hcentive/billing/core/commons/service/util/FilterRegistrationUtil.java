package com.hcentive.billing.core.commons.service.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;

import org.springframework.boot.context.embedded.FilterRegistrationBean;

public final class FilterRegistrationUtil {

	public static FilterRegistrationBean createRegistrationBean(Filter filter,
			String... urlPatterns) {
		
		final FilterRegistrationBean filterRegistration = new FilterRegistrationBean();
		// final CreateSystemUserContextFilter filter = new
		// CreateSystemUserContextFilter();
		filterRegistration.setFilter(filter);
		final Collection urlPatternList = new ArrayList<>();
		if (urlPatterns != null) {
			urlPatternList.addAll(Arrays.asList(urlPatterns));
		} else {
			urlPatternList.add("/*");
		}
		filterRegistration.setUrlPatterns(urlPatternList);
		Class clazz = FilterRegistrationBean.class;
		try {
			Field field = clazz.getDeclaredField("dispatcherTypes");
			field.setAccessible(true);
			EnumSet<DispatcherType> dispatcherTypes = EnumSet
					.of(DispatcherType.REQUEST);
			field.set(filterRegistration, dispatcherTypes);
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return filterRegistration;
	}

}
