/**
 * 
 */
package com.hcentive.billing.core.exception;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

/**
 * 
 * Exception to be thrown when input for a restful end point is not valid. Uses
 * {@link BindingResult} for managing error message for a field / object.
 * 
 * @author Kumar Sambhav Jain
 * 
 */
public class InvalidParamtersException extends IllegalArgumentException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3135196912135000851L;

	/**
	 * {@link BindingResult} object.
	 */
	private final BindingResult bindingResult;

	/**
	 * @param bindingResult
	 */
	public InvalidParamtersException(BindingResult bindingResult) {
		super();
		this.bindingResult = bindingResult;
	}

	/**
	 * @return the bindingResult
	 */
	public BindingResult getBindingResult() {
		return bindingResult;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		List<ObjectError> allErrors = bindingResult.getAllErrors();
		List<String> errors = new ArrayList<>(allErrors.size());
		for (ObjectError objectError : allErrors) {
			errors.add(objectError.getDefaultMessage());
		}
		return errors.toString();
	}

	public Map<String, String> getDefaultErrorMessages() {

		List<FieldError> fieldErrors = bindingResult.getFieldErrors();
		final Map<String, String> errorMessages = new HashMap<>(
				fieldErrors.size());
		for (FieldError fieldError : fieldErrors) {
			errorMessages.put(fieldError.getField(),
					fieldError.getDefaultMessage());
		}

		return errorMessages;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Throwable#toString()
	 */
	@Override
	public String toString() {

		return getMessage();
	}

}
