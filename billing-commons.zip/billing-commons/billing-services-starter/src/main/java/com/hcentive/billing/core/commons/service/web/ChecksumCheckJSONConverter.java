package com.hcentive.billing.core.commons.service.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.service.security.filter.HttpSecuredAccessDataExtractor;
import com.hcentive.billing.core.commons.util.EncryptionUtil;

public class ChecksumCheckJSONConverter extends MappingJackson2HttpMessageConverter implements ChecksumGenerator<String, String>{

	private static final Logger LOGGER = LoggerFactory.getLogger(ChecksumCheckJSONConverter.class);
	
	private ChecksumGenerator<String, String> checksumGenerator;
	
	public ChecksumCheckJSONConverter(final ObjectMapper objectMapper) {
		super(objectMapper);
		this.checksumGenerator = this;
	}
	
	public void set(ChecksumGenerator<String , String> checksumGenerator){
		this.checksumGenerator = checksumGenerator;
	}
	public ChecksumCheckJSONConverter(final ApplicationContext applicationContext){
		this(Jackson2ObjectMapperBuilder.json().applicationContext(applicationContext).build());
	}

	@Override
	public Object read(Type type, Class<?> contextClass,
			HttpInputMessage inputMessage) throws IOException,
			HttpMessageNotReadableException {
		LOGGER.debug("Reading for type: {}",contextClass);
		final String dataStr = doRead(inputMessage.getBody()).toString();
		validateDataStr(dataStr,inputMessage);
		final JavaType javaType = getJavaType(type, contextClass);
		return this.objectMapper.readValue(dataStr, javaType);
	}
	
	protected void validateDataStr(String dataStr, HttpInputMessage inputMessage) {
		final String checksum = inputMessage.getHeaders().getFirst(HttpSecuredAccessDataExtractor.CHECKSUM_HEADER);
		if(null != checksum && !StringUtils.isEmpty(checksum)){
			LOGGER.debug("Validating checksum for "+dataStr);
			if(null == dataStr){
				dataStr = "";
			}
			final String checksumGenerated = this.checksumGenerator.generateChecksum(dataStr);
			if(!checksum.equals(checksumGenerated)){
				LOGGER.error("Checksum validation failed");
				throw new IllegalArgumentException("Data provided in request is illegal.");
			}
			LOGGER.debug("checksum validated");
		}
		LOGGER.debug("checksum is blank");
	}

	@Override
	protected Object readInternal(Class<?> clazz,
			HttpInputMessage inputMessage) throws IOException,
			HttpMessageNotReadableException {
		LOGGER.debug("Reading for type: {}",clazz);
		final String dataStr = doRead(inputMessage.getBody()).toString();
		validateDataStr(dataStr, inputMessage);
		return this.objectMapper.readValue(dataStr, clazz);
	}
	
	private StringBuilder doRead(
			final InputStream inputStream) throws IOException {
		final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
		reader.mark(1024);
		String sCurrentLine;
		final StringBuilder builder = new StringBuilder();
		while((sCurrentLine = reader.readLine()) != null){
			builder.append(sCurrentLine);
		}
		return builder;
	}

	@Override
	public String generateChecksum(final String input) {
		return EncryptionUtil.sha256(input);
	}
	
	public static void main (String args[]){
		 System.out.println(EncryptionUtil.sha256(""));
		 
	}
	
}
