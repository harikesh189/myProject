package com.hcentive.billing.core.commons.starter.tenant.identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.tenant.identity.provider.TenantIdentityProvider;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class WFMTenantIdentityProvider implements TenantIdentityProvider {

	private static Logger logger = LoggerFactory.getLogger(WFMTenantIdentityProvider.class);

	@Override
	public String getTenantId() {
		if (null != ProcessContext.get()) {
			logger.trace("Process context found , tenant id {}", ProcessContext.get().getTenantId());
			if (null != ProcessContext.get().getTenantId() && ProcessContext.get().getTenantId().trim().length() > 0) {
				return ProcessContext.get().getTenantId();
			}
		}
		logger.trace("Process context not found");
		return "";
	}
}
