/**
 * 
 */
package com.hcentive.billing.core.advice;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.cluster.job.manager.ClusteredJobManager;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;

/**
 * @author Dikshit.Vaid
 *
 */
@Component
@Aspect
public class ScheduledJobAdvice {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledJobAdvice.class);
	
	@Autowired
	private ClusteredJobManager clusteredJobManager;


	@After("@annotation(org.springframework.scheduling.annotation.Scheduled)")
	public void handleScheduleAfterAdvice() throws Throwable {
		LOGGER.debug("running after advice for scheduled job");
		ProcessContextUtil.clearProcessContext();
//		clusteredJobManager.removeOldJobs();
		LOGGER.debug("ran after advice for scheduled job");
	}

}
