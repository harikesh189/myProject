package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.ProcessContextMetaDataCreator;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;

/**
 * Filter to set process context for the thread.
 *
 * @author ajay.saxena
 *
 */
// @Component

public class HttpCreateProcessContextFilter extends ClientAppIdentifierFilter {

	private static final Logger logger = LoggerFactory.getLogger(HttpCreateProcessContextFilter.class);

	@Override
	public void doInternalFilter(final ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		if (!ignoreCurrentRequest(request)) {
			createContext(request,response,chain);
		}
	}

	protected void createContext(ServletRequest request,
			ServletResponse response, FilterChain chain) throws IOException, ServletException {
		logger.debug("Inside doFilter");
		createProcessContextFromLoggedInUser(request);
		logger.debug("filter processing completed");
	try {
		chain.doFilter(request, response);
	} finally {
		ProcessContext.clear();
	}
	}

	protected void createProcessContextFromLoggedInUser(final ServletRequest request) {
		final User loggedInUser = Utils.getUser();
		logger.debug("Logged In User: {}", loggedInUser);
		if (null != loggedInUser) {
			logger.debug("Building Process Context with metadata for tenant {}", loggedInUser.getTenantId());
			final Map<String, String> metaData = ProcessContextMetaDataCreator.create((HttpServletRequest) request);
			String userName = null;
			if(null != loggedInUser && null != loggedInUser.getProfile()){
				userName = loggedInUser.getProfile().getDisplayName();
			}
			ProcessContextUtil.buildProcessContextWithMetaData(loggedInUser.getIdentity(), null, loggedInUser.getTenantId(), null, metaData,userName);

			// BE TYPE and BE ID is not for Admin
			if (loggedInUser instanceof Manager) {
				logger.debug("Logged in user is instance of Manager");
				final String beType = resolveBeType(request);
				final String beId = beType != null ? resolveBeId(request) : null;
				ProcessContext.get().setBeId(beId);
				ProcessContext.get().setBeType(beType);
			}

		} else {
			// If someone delete cookie then there will be no logged in user on login page so creating blank process context
			ProcessContext.initializer().initialize();
		}
		logger.debug("Returning from createProcessContextFromLoggedInUser");
	}

	@Override
	protected String[] getIgnorePathPattern() {
		// TODO Auto-generated method stub
		return null;
	}
}
