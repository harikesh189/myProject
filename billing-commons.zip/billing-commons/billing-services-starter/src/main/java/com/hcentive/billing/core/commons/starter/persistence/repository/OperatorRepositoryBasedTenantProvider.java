/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.starter.persistence.repository;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isEmpty;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Operator;
import com.hcentive.commons.batch.process.TenantProvider;

@Component
public class OperatorRepositoryBasedTenantProvider implements TenantProvider {

	Logger logger = LoggerFactory.getLogger(OperatorRepositoryBasedTenantProvider.class);

	@Autowired
	private BatchOperatorRepository operatorRepository;

	private List<String> tenantList;

	@Override
	public List<String> findAllTenant() {
		logger.debug("prepatration of tenant list is started");
		final List<Operator> list = operatorRepository.findAll();
		if (isEmpty(list)) {
			logger.error("Could not fetch operators");
			return null;
		}
		logger.debug("returning Tenant list");
		tenantList = new CopyOnWriteArrayList<String>();
		for (final Operator operator : list) {
			tenantList.add(operator.getExternalId());
		}
		return tenantList;
	}

	@Override
	public String findTenant(final String tenantId) {
		logger.debug("Getting Operator based on tenant : {}", tenantId);
		final Operator operator = operatorRepository.findByExternalId(tenantId);
		logger.debug("Operator Found : {}", operator);
		return operator != null ? operator.getExternalId() : null;
	}

}
