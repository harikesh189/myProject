package com.hcentive.billing.core.commons.service.security;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.DefaultIOU;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.RemoteLoginManager;
import com.hcentive.billing.core.commons.util.ClientAppToCookieNameMapping;

public class AnonymousTokenUtil {
	
	public static final AnonymousTokenUtil INSTANCE = new AnonymousTokenUtil();
	
	private AnonymousTokenUtil() {
	}
	
	@Autowired
	private  RemoteLoginManager remoteLoginManager;
	
	private IOU<Void, AsyncCallback<Void>> doIssueAccessToken(AnonymousUserIdentity identity,final HttpServletRequest request,final HttpServletResponse response, final String clientId,final int timeout){
		final DefaultIOU<Void, AsyncCallback<Void>> defaultIou = new DefaultIOU<Void, AsyncCallback<Void>>();
		final AccessToken token = remoteLoginManager.doRemoteLoginForTrustedEntities(identity);
		
		final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
		Cookie cookie = new Cookie(BillingConstant.COOKIE_SID+cookieIdentifier,  token.getIdentity());
		cookie.setHttpOnly(true);
		cookie.setSecure(true);
		cookie.setPath("/");
		if(timeout>0){
		cookie.setMaxAge(timeout);
		}
		cookie.setDomain("."+request.getServerName());
		response.addCookie(cookie);
		defaultIou.setResult(null);
		return defaultIou;
	}
	
	private IOU<Void, AsyncCallback<Void>> doIssueAccessToken(AnonymousUserIdentity identity,final HttpServletRequest request,final HttpServletResponse response,final String xpgApp){
		return issueAccessToken(identity,request,response,xpgApp,-1);
	}
	
	public static IOU<Void, AsyncCallback<Void>> issueAccessToken(AnonymousUserIdentity identity,final HttpServletRequest request,final HttpServletResponse response, final String clientId,final int timeout){
		return INSTANCE.doIssueAccessToken(identity, request, response, clientId, timeout);
	}
	
	public static IOU<Void, AsyncCallback<Void>> issueAccessToken(AnonymousUserIdentity identity,final HttpServletRequest request,final HttpServletResponse response,final String xpgApp){
		return INSTANCE.doIssueAccessToken(identity, request, response, xpgApp);
	}
	
}
