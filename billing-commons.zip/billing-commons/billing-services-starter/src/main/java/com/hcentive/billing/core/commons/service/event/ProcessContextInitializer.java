package com.hcentive.billing.core.commons.service.event;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.constants.AppConstant;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.service.comm.Service;
import com.hcentive.billing.core.commons.service.rmi.DefaultSpringHttpRMIInterceptorRegistry;
import com.hcentive.billing.core.commons.service.rmi.SpringHttpRMIInterceptorAdaptor;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
public class ProcessContextInitializer extends SpringHttpRMIInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessContextInitializer.class);
	
	final private ObjectMapper mapper = new ObjectMapper();

	@Value("${service.name}")
	private String serviceName;

	@Override
	public void beforeProcessing(Event<?> event) {
		MDC.put(AppConstant.KEY_FOR_SERVICE_NAME, serviceName);
		if (event.getHeader(Service.SERVICE_EVENT) != null) {
			LOGGER.debug("processing service event {}", event.name());
			final ProcessContext processContext = (ProcessContext) event.getHeader(EventHeaderConstant.PROCESS_CONTEXT);
			handleProcessContext(processContext,event.name());
		} else {
			LOGGER.debug("In case of normal event, process context will be initialized while Initializing security context.");
		}
	}

	private void handleProcessContext(final ProcessContext processContext,final String name) {
		if (processContext != null) {
			LOGGER.debug("Process context found, intializing process context");
			ProcessContext.initialize(processContext);
			LOGGER.debug("Process context in initialized successfully :: {} ,   tenant :: {}", ProcessContext.get(), ProcessContext.get().getTenantId());
		} else {
			LOGGER.error("Process context information is misssing for service event {}", name);
		}
	}
	
	@Override
	public void beforeConsuming(HttpServletRequest request){
		try {
			ProcessContext.clear();
			final ProcessContext processContext = mapper.readValue(request.getHeader(EventHeaderConstant.PROCESS_CONTEXT), ProcessContext.class);
			handleProcessContext(processContext, "RMI");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
		DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.addInterceptors(this);
	}

	@Override
	public int priority() {
		return 0;
	}
}
