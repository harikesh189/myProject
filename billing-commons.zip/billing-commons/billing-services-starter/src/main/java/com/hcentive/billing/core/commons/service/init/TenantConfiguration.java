package com.hcentive.billing.core.commons.service.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.service.util.WebBasedTenantManager;
import com.hcentive.billing.core.commons.tenant.util.TenantManager;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

@Configuration
public class TenantConfiguration {

	@Bean
	@ConditionalOnMissingBean
	public TenantManager createTenantManager() {
		return new WebBasedTenantManager();
	}
	
	@Bean
	public TenantManagerConfiguration tenantManagerConfiguration(){
		return new TenantManagerConfiguration();
	}
	
	@Configuration
	public static class TenantManagerConfiguration{
		@Autowired
		private TenantManager configuredTenantManager;
		
		@Bean
		public MethodInvokingFactoryBean configureTenantManager() {
			final MethodInvokingFactoryBean factory = new MethodInvokingFactoryBean();
			factory.setTargetClass(TenantUtil.class);
			factory.setStaticMethod(TenantUtil.class.getName() + ".configure");
			final Object[] args = { configuredTenantManager };
			factory.setArguments(args);
			return factory;
		}
	}

}
