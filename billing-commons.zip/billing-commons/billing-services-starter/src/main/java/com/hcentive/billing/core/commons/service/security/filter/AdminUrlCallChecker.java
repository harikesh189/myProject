package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.domain.Administrator;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * 
 * Filter to ensure that all calls with to /admin are made by an adminstrator
 * only.
 * 
 * 
 */
// @Component
public class AdminUrlCallChecker extends AbstractFilter  {

	private static final Logger logger = LoggerFactory
			.getLogger(AdminUrlCallChecker.class);
	
	@Value(value = "${admin.checker.ignore.pattern:/**/*.html,/**/*.png,/**/*.gif,/**/*.bmp,/**/*.js,/**/*.ico,/**/*.svg,/**/*.less,/**/*.map,/**/*.css}")
	private String[] adminCheckerIgnorePattern = new String[0];

	@SuppressWarnings("rawtypes")
	@Override
	protected void doInternalFilter(ServletRequest request, ServletResponse response,
			FilterChain chain)  throws IOException, ServletException{
		final String path = ((HttpServletRequest) request).getRequestURI();
		final User loggedInUser = Utils.getUser();
		logger.debug("Logged in User: {}",loggedInUser);
		if(loggedInUser != null && loggedInUser instanceof AnonymousUser){
			logger.debug("Logged in User is instance of Anonymous User");
			chain.doFilter(request, response);
			return;
		}
		if(loggedInUser != null && loggedInUser instanceof Administrator && !ignoreCurrentRequest(request) && !path.contains("/admin")  
				&& !path.contains("/security")){
			ProcessContext.clear();
			logger.error("Logged In User is instance of Administrator and it should contain admin keyword in its url");
			throw new SecurityException("Access Denied.");
		}else if (!ignoreCurrentRequest(request) && path.contains("/admin")) {
			logger.debug("Inside AdminUrlCallChecker");
			boolean isValid = false;
			
			if (null != loggedInUser) {

				if (loggedInUser instanceof Administrator) {
					isValid = true;
				}
				if (!isValid) {
					logger.error("Access Denied. Should be instance of administrator");
					throw new SecurityException("Access Denied.");
				}
			}
			logger.debug("AdminUrlCallChecker completed.");
		}
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {

	}

	protected static interface Checker<U extends User> {
		public boolean check(U user);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	protected String[] getIgnorePathPattern() {
		return adminCheckerIgnorePattern ;
	}
}
