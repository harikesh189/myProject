package com.hcentive.billing.core.commons.service.web;

public interface ChecksumGenerator<C,I> {
	public C generateChecksum(I input);
}
