package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authc.AuthenticationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.security.SecuredAccessContext;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.exception.AuthenticationFailed;
import com.hcentive.billing.core.commons.security.exception.AuthorizationDenied;
import com.hcentive.billing.core.commons.security.exception.SecurityException;
import com.hcentive.billing.core.commons.security.exception.SessionTimedOut;
import com.hcentive.billing.core.commons.web.WebUtils;

public class HttpSecuredAccessDataExtractor extends AbstractFilter {

	public static final String NONCE_HEADER = "nonce";

	public static final String SECURITY_KEY_HEADER = "securityKey";
	public static final String CHECKSUM_HEADER = "checkSum";

	private static final Logger LOGGER = LoggerFactory.getLogger(HttpSecuredAccessDataExtractor.class);
	
	@Autowired
	private FilterErrorHandler filterErrorHandler;

	@Value(value = "${security.cookie.secure:true}")
	private boolean isCookieSecure;

	@Value(value = "${security.after.login.pattern:/security/user/current**,/**/view/current/context**}")
	private String[] afterLoginPattern;
	
	@Value(value = "${security.data.extractor.pattern:/security/**,/dms/**,/issueAccessToken**}")
	private String[] ignorePattern;
	
	@Value(value = "${security.retrieve.token.from.param.pattern:/user-management/*/register**}")
	private String[] retrieveTokenFromParamPattern;
	
	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		LOGGER.trace("Inside filter");
		final HttpServletRequest httpRequest = (HttpServletRequest) request;
		final String path = httpRequest.getRequestURI();
		if(ignoreCurrentRequest(httpRequest) && !matchedFoundAgainstPattern(path, this.afterLoginPattern)){
			LOGGER.debug("By passing filter");
			chain.doFilter(request, response);
			return;
		}
		String accessTokenId = null;
		if(matchedFoundAgainstPattern(path, this.retrieveTokenFromParamPattern)){
			String encryptedTokenId = httpRequest.getParameter("tokenId");
			LOGGER.debug("Token Retrieved from Request Param: {}",encryptedTokenId);
			if(null != encryptedTokenId){
				LOGGER.debug("Decrypting token recieved from request param: {}",encryptedTokenId);
				accessTokenId = WebUtils.decryptTokenId(encryptedTokenId);
				LOGGER.debug("Creating Secured Access Context");
				SecuredAccessContext.createNew(accessTokenId);
				populateCookieForRequestParamToken(httpRequest, (HttpServletResponse)response, encryptedTokenId,securityUIAppKey);
				chain.doFilter(request, response);
				return;
			}
			
		}else{
			accessTokenId = WebUtils.getAuthorizationHeader((HttpServletRequest) request);
		}
		
		LOGGER.debug("Request made for token : {}", accessTokenId);
		final String encryptedPasskey = httpRequest.getHeader(SECURITY_KEY_HEADER);
		String nonce = httpRequest.getHeader(NONCE_HEADER);
		final String checksum = httpRequest.getHeader(CHECKSUM_HEADER);
		
		final HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		if (accessTokenId != null && !isSystemUser()) {
			LOGGER.debug("Associating user with identity {}", accessTokenId);
			try {
				LOGGER.trace("Creating Secured Access Context");
				//SecuredAccessContext.createNew(accessTokenId, encryptedPasskey, nonce);
				ChecksumAwareSecuredAccessContext.createNew(accessTokenId, encryptedPasskey, nonce, checksum);
			} catch(SessionTimedOut e){ 
				LOGGER.error("Session Timed Out for token: {}",accessTokenId);
				//WebUtils.clearCookie(httpRequest, httpServletResponse,"/",isCookieSecure);
				filterErrorHandler.handleSessionTimeOut(httpRequest, httpServletResponse,null);
				LOGGER.debug("Returning from Secured Filter");
				return;
			}catch (final AuthenticationException  | AuthenticationFailed | AuthorizationDenied e) {
				LOGGER.error("Authentication Exception Occured");
				//WebUtils.clearCookie(httpRequest, httpServletResponse,"/",isCookieSecure);
				filterErrorHandler.handleAuthenticationFailed(httpRequest, httpServletResponse,null);
				LOGGER.error("Returning from Secured Filter");
				return;
			}

		} else if (!isSystemUser()) {
			LOGGER.error("Requested Resource did'nt work on system user so please come with token for the same");
			httpServletResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
			return;
		}
		chain.doFilter(request, response);
		if (!isSystemUser()) {
			SecurityUtil.securityContextManager().clearSecurityContextFromThread();
		}
		LOGGER.trace("End filter");
	}

	protected boolean isSystemUser() {
		return SecurityUtil.securityContextManager().currentUserIsSystem();
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {

	}

	@Override
	protected String[] getIgnorePathPattern() {
		return this.ignorePattern;
	}

	public static class ChecksumAwareSecuredAccessContext extends SecuredAccessContext{
		private final String checksum;
		
		private ChecksumAwareSecuredAccessContext(String accessTokenId,
				String encryptedPasskey, String nonce, String checksum) {
			super(accessTokenId, encryptedPasskey, nonce);
			this.checksum = checksum;
		}
		
		public static void createNew(String accessTokenId,
				String encryptedPasskey, String nonce, String checksum){
			ChecksumAwareSecuredAccessContext context = new ChecksumAwareSecuredAccessContext(accessTokenId, encryptedPasskey, nonce, checksum);
			validateAndAssociate(context);
		}
		
		public String checksum(){
			return this.checksum;
		}
		
	}
}
