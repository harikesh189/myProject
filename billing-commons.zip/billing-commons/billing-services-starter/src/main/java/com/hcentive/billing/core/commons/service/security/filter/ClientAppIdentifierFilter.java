package com.hcentive.billing.core.commons.service.security.filter;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.web.WebUtils;

public abstract class ClientAppIdentifierFilter extends AbstractFilter
		implements Filter {

	private static final Logger logger = LoggerFactory
			.getLogger(ClientAppIdentifierFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	public String resolveClientId(final ServletRequest request) {
		logger.debug("Resolving ClientId");
		String clientId = request.getParameter("client_id");
		final String path = ((HttpServletRequest) request).getRequestURI();
		if (clientId == null && !path.contains("initiate")) {
			// check in path.
			logger.debug("Resolving clientId from path");
			String[] pathItems = WebUtils.pathItems(request);
			clientId = pathItems[pathItems.length - 2];
			logger.debug("Client Id Found : {}",clientId);
		}
		return clientId;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
	
	public String resolveIdpKey(final ServletRequest request) {
		logger.debug("Resolving IdpKey");
		String idpKey = request.getParameter("idpKey");
		final String path = ((HttpServletRequest) request).getRequestURI();
		if (idpKey == null && path.contains("saml")) {
			// check in path.
			logger.debug("Resolving idpKey from path");
			String[] pathItems = WebUtils.pathItems(request);
			idpKey = pathItems[pathItems.length - 1];
			logger.debug("IDP Key Found : {}",idpKey);
		}
		if( idpKey == null){
			final AccessToken accessToken = Utils.getAccessToken();
			if( null != accessToken){
				idpKey = accessToken.getIssuedForIdp();
			}
		}
		return idpKey;
	}

}
