package com.hcentive.billing.core.commons.service.event;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventBusConfigurer;
import com.hcentive.billing.core.commons.event.EventInterceptorAdaptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.exception.BillingException;
import com.hcentive.billing.core.commons.exception.BillingRecoverableException;
import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.hcentive.billing.core.commons.exception.StandardErrorCodes;
import com.hcentive.billing.core.commons.init.EventConfiguration;
import com.hcentive.billing.core.commons.mq.EventExceptionHandler;
import com.hcentive.billing.core.commons.mq.support.MQConstants;

public class PublishToDeadLetterEventExceptionHandler extends EventInterceptorAdaptor implements
		EventExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(PublishToDeadLetterEventExceptionHandler.class);
	
	private final Map<String, ErrorCode> errorCodes;
	
	
	
	public PublishToDeadLetterEventExceptionHandler(
			Map<String, ErrorCode> errorCodes) {
		this.errorCodes = errorCodes;
		EventUtils.eventBus().addInterceptors(this);
	}



	@Override
	public void handle(Throwable error, Event event) {
		final Event errorEvent = new Event<Event>(MQConstants.ERROR_DEAD_LETTER_ROUTING_KEY, event, false);
		event.addHeader(MQConstants.ERROR_CODE, getErrorCode(error));
		if(error instanceof BillingRecoverableException){
			event.addHeader(MQConstants.AUTO_RECOVERABLE, true);
		}
		EventUtils.publish(errorEvent);
	}



	private ErrorCode getErrorCode(final Throwable error) {
		ErrorCode errorCode = null;
		if(error instanceof BillingException){
			errorCode = ((BillingException)error).errorCode();
		}
		if(errorCode == null){
			errorCode = errorCodes.get(error.getClass().getName());
		}
		return errorCode!=null?errorCode:StandardErrorCodes.GENERIC_ERROR;
	}

	@Override
	public void onProcessingError(Event<?> event, Throwable t) {
		handle(t, event);
	}

	@Override
	public int priority() {
		return -5;
	}
}
