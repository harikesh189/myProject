package com.hcentive.billing.core.commons.service.event;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHeaderConstant;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.service.comm.Service;
import com.hcentive.billing.core.commons.service.rmi.DefaultSpringHttpRMIInterceptorRegistry;
import com.hcentive.billing.core.commons.service.rmi.SpringHttpRMIInterceptorAdaptor;

@Component
public class ServiceEventSecurityContextInitializer extends SpringHttpRMIInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceEventSecurityContextInitializer.class);

	@Override
	public void beforeProcessing(Event<?> event) {
		if (event.getHeader(Service.SERVICE_EVENT) != null) {
			LOGGER.debug("processing service event {}", event.name());
			final String accessTokenId = (String) event.getHeader(EventHeaderConstant.ACCESS_TOKEN_ID);
			handleAccessToken(accessTokenId);
		}
	}

	private void handleAccessToken(final String accessTokenId) {
		if (accessTokenId != null) {
			// check is it is for system.
			if (EventHeaderConstant.SYSTEM_USER_ACCESS_TOKEN.equals(accessTokenId)) {
				// this is system
				SecurityUtil.securityContextManager().loginSystemUser();
			} else {
				// initialize security for this accessToken.
				LOGGER.debug("Access token found");
				SecurityUtil.tokenAssociator().associateToken(accessTokenId);
			}
		}
	}
	
	@Override
	public void beforeConsuming(HttpServletRequest request){
		final String accessTokenId = request.getHeader(EventHeaderConstant.ACCESS_TOKEN_ID);
		handleAccessToken(accessTokenId);
	}

	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
		DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.addInterceptors(this);
	}

	@Override
	public int priority() {
		return 1;
	}
}
