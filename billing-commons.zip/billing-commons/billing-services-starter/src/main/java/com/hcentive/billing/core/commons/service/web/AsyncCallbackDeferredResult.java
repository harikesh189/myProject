package com.hcentive.billing.core.commons.service.web;

import org.springframework.web.context.request.async.DeferredResult;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;

public class AsyncCallbackDeferredResult<T> extends DeferredResult<T> implements AsyncCallback<T>{
	
	/**
	 * Create a AsyncCallbackDeferredResult.
	 */
	public AsyncCallbackDeferredResult(){
		super();
	}

	/**
	 * Create a AsyncCallbackDeferredResult with a timeout value.
	 * @param timeout timeout value in milliseconds
	 */
	public AsyncCallbackDeferredResult(long timeout) {
		super(timeout);
	}
	
	@Override
	public void onSuccess(T o) {
		this.setResult(o);
	}

	@Override
	public void onError(Throwable t) {
		this.setErrorResult(t);
	}

}
