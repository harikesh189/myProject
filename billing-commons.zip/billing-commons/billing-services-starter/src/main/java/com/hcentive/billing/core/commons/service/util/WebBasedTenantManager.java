package com.hcentive.billing.core.commons.service.util;

import com.hcentive.billing.core.commons.tenant.util.TenantManager;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class WebBasedTenantManager implements TenantManager {

	@Override
	public String getTenantId() {
		final ProcessContext processContext = ProcessContext.get();
		return processContext != null ? processContext.getTenantId() : null;
	}

}
