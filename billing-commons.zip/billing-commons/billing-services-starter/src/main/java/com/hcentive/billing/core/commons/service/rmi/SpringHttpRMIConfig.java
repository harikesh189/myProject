package com.hcentive.billing.core.commons.service.rmi;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;

import com.hcentive.billing.core.commons.security.RemoteLoginManager;
import com.hcentive.billing.core.commons.service.security.AnonymousTokenUtil;

@Configuration
public class SpringHttpRMIConfig {
	

	@Value("${issue.token.url:http://localhost:8001/}")
	private String issueTokenUrl;
	
	@Bean
	public HttpInvokerProxyFactoryBean httpInvokerProxy(){
		HttpInvokerProxyFactoryBean httpInvokerProxyFactoryBean = new HttpInvokerProxyFactoryBean();
		httpInvokerProxyFactoryBean.setServiceUrl(issueTokenUrl+"remote/issueAccessToken");
		httpInvokerProxyFactoryBean.setServiceInterface(RemoteLoginManager.class);
		return httpInvokerProxyFactoryBean;
	}
	
	@Bean
	@DependsOn(value="httpInvokerProxy")
	public AnonymousTokenUtil anonymousTokenUtil(){
		return AnonymousTokenUtil.INSTANCE;
	}
	
	@Bean
	public HttpInvokerRequestExecutor httpInvokerRequestExecutor(){
		return new HttpInvokerRequestExecutor();
	}
	
}
