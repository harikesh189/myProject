package com.hcentive.billing.core.commons.service.cluster.job;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.constants.AppConstant;

@Aspect
@Component
public class LoggingAdvice {

	@Value("${service.name}")
	private String serviceName;

	@Before("@annotation(org.springframework.scheduling.annotation.Scheduled)")
	public void addLoggingInformation(JoinPoint jp) throws Throwable {
		MDC.put(AppConstant.KEY_FOR_SERVICE_NAME, serviceName);
	}
}
