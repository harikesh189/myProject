/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.starter.persistence.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.Operator;


public interface BatchOperatorRepository extends JpaRepository<Operator, Long>{
	public List<Operator> findAll();
	
	public Operator findByExternalId(final String externalId);
}


