package com.hcentive.billing.core.commons.service.event;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.mq.AMQPConfigurer;
import com.hcentive.billing.core.commons.mq.AMQPConfigurer.EventMessagePostProcessor;
import com.hcentive.billing.core.commons.service.comm.Service;
import com.hcentive.billing.core.commons.service.comm.ServiceResponse;

public class EventMessageDurabilityManager implements EventMessagePostProcessor {
	
	@Override
	public Message postProcessMessage(final Event event,final Message message) {
		if(event.durable()){
			final MessageProperties messageProperties = message.getMessageProperties();
			messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
		}
		return message;
	}
	
	public EventMessageDurabilityManager(){
		AMQPConfigurer.add(this);
	}
}
