package com.hcentive.billing.core.commons.service.rmi;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;
import org.springframework.stereotype.Component;

@Component
public class SpringHttpRMIConfigPostProcessor implements BeanPostProcessor{
	
	@Autowired
	private HttpInvokerRequestExecutor httpInvokerRequestExecutor;

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		if(bean instanceof HttpInvokerProxyFactoryBean){
			((HttpInvokerProxyFactoryBean) bean).setHttpInvokerRequestExecutor(httpInvokerRequestExecutor);
		}
		return bean;
	}

}
