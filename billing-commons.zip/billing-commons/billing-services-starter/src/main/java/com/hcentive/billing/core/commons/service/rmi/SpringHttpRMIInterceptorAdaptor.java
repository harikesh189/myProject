package com.hcentive.billing.core.commons.service.rmi;

import java.net.HttpURLConnection;

import javax.servlet.http.HttpServletRequest;

import com.hcentive.billing.core.commons.event.EventInterceptorAdaptor;
import com.hcentive.billing.core.commons.service.comm.api.SpringHttpRMIInterceptor;

public abstract class SpringHttpRMIInterceptorAdaptor extends EventInterceptorAdaptor implements
		SpringHttpRMIInterceptor {

	@Override
	public void beforeDispatch(HttpURLConnection con) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterDispatch(HttpURLConnection con) {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void beforeConsuming(HttpServletRequest request){
		
	}
	
	@Override
	public void afterConsuming(HttpServletRequest request){
		
	}

}
