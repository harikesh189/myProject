package com.hcentive.billing.core.commons.service.security.filter;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.web.WebUtils;

public class DefaultFilterErrorHandler implements FilterErrorHandler {
	
	@Value(value = "${security.cookie.secure:true}")
	protected boolean isCookieSecure;
	
	@Value(value = "${security.login.page.url:security/{enterpriseName}/oAuth2/initiate}")
	private String securityLoginPageUrl;
	
	@Value(value = "${api.enterprise.location:2}")
	private int enterpiseLocationInURL;

	@Override
	public void handleSessionTimeOut(HttpServletRequest request,
			HttpServletResponse response,  final String errorUrl) throws IOException {
		final String requestPath = request.getRequestURI();
		if(requestPath.contains("logout")){
			final String enterpriseName = WebUtils.resolve(request, enterpiseLocationInURL);
			response.sendRedirect(createLoginUrl(request, enterpriseName));
		}
		response.sendError(HttpServletResponse.SC_GATEWAY_TIMEOUT);
	}
	
	public String createLoginUrl(HttpServletRequest request,
			String enterpriseName) {
		String redirectUrl = securityLoginPageUrl;
		redirectUrl = WebUtils.replaceEnterprise(enterpriseName, redirectUrl);
		redirectUrl = WebUtils.getBaseUrl(request)+"/"+redirectUrl+"?client_id="+request.getParameter("client_id")+"&response_type=token";
		return redirectUrl;
	}
	
	@Override
	public void handleAuthenticationFailed(HttpServletRequest request,
			HttpServletResponse response,  final String errorUrl) throws IOException {
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
	}


}
