package com.hcentive.billing.core.commons.service.event;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.service.rmi.DefaultSpringHttpRMIInterceptorRegistry;
import com.hcentive.billing.core.commons.service.rmi.SpringHttpRMIInterceptorAdaptor;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
public class ProcessContextDestroyer extends SpringHttpRMIInterceptorAdaptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessContextDestroyer.class);

	@Override
	public void onProcessingCompletion(Event event) {
		clearContext();
	}

	private void clearContext() {
		ProcessContext.clear();
		MDC.clear();
		LOGGER.debug("Process context cleared successfully");
	}

	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
		DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.addInterceptors(this);
	}

	@Override
	public int priority() {
		return 1;
	}
	
	@Override
	public void afterConsuming(HttpServletRequest request) {
		clearContext();
	}
}
