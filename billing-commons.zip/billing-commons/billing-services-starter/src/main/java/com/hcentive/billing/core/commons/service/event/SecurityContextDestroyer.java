package com.hcentive.billing.core.commons.service.event;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.service.rmi.DefaultSpringHttpRMIInterceptorRegistry;
import com.hcentive.billing.core.commons.service.rmi.SpringHttpRMIInterceptorAdaptor;

@Component
public class SecurityContextDestroyer extends SpringHttpRMIInterceptorAdaptor {

	@Override
	public void onProcessingCompletion(Event event) {
		clearSecurityContext();
	}

	private void clearSecurityContext() {
		final boolean isCurrentUserSystem = SecurityUtil
				.securityContextManager().currentUserIsSystem();
		if (isCurrentUserSystem) {
			SecurityUtil.securityContextManager().logoutSystemUser();
		} else {
			SecurityUtil.securityContextManager()
					.clearSecurityContextFromThread();
		}
	}

	@PostConstruct
	public void init() {
		EventUtils.eventBus().addInterceptors(this);
		DefaultSpringHttpRMIInterceptorRegistry.INSTANCE.addInterceptors(this);
	}

	@Override
	public int priority() {
		return 0;
	}
	
	@Override
	public void afterConsuming(HttpServletRequest request) {
		clearSecurityContext();
	}
}
