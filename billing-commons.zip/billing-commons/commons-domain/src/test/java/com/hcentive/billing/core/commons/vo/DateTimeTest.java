package com.hcentive.billing.core.commons.vo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

public class DateTimeTest {

	private static DateTime getDate(final int year, final int month, final int date) {
		final Calendar calendar = Calendar.getInstance();
		calendar.set(year, month, date, 0, 0, 0);

		return new DateTime(calendar.getTime());
	}

	private static DateTime getDate(int year, int month, int date, int hourOfDay, int minute, int second) {
		final Calendar calendar = Calendar.getInstance();
		calendar.set(year, month, date, hourOfDay, minute, second);
		return new DateTime(calendar.getTime());
	}

	private static int getValueof(final Date date, final int unit) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(unit);
	}

	@Test
	public void testAdd() {
		assertEquals(20, getValueof(getDate(2014, 5, 19).add(1, Calendar.DATE).getDate(), Calendar.DATE));
		assertEquals(18, getValueof(getDate(2014, 5, 19).add(-1, Calendar.DATE).getDate(), Calendar.DATE));

		assertEquals(4, getValueof(getDate(2014, 5, 19).add(-1, Calendar.MONTH).getDate(), Calendar.MONTH));
		assertEquals(6, getValueof(getDate(2014, 5, 19).add(1, Calendar.MONTH).getDate(), Calendar.MONTH));
	}

	@Test(expected = RuntimeException.class)
	public void testExceptionInBetween() {
		assertTrue(getDate(2014, 5, 20).isInBetween(getDate(2014, 5, 29), getDate(2014, 5, 21)));

	}

	@Test
	public void testGetDatePart() {
		final DateTime testDate = getDate(2014, 1, 15, 13, 12, 50);
		Calendar cal = Calendar.getInstance();
		cal.setTime(testDate.getDate());
		assertEquals(2014, cal.get(Calendar.YEAR));
		assertEquals(1, cal.get(Calendar.MONTH));
		assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
		assertEquals(12, cal.get(Calendar.MINUTE));
		assertEquals(50, cal.get(Calendar.SECOND));

		final DateTime datePartWithoutTimeStamp = testDate.getDatePart();

		cal = Calendar.getInstance();
		cal.setTime(datePartWithoutTimeStamp.getDate());
		assertEquals(2014, cal.get(Calendar.YEAR));
		assertEquals(1, cal.get(Calendar.MONTH));
		assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
		assertEquals(0, cal.get(Calendar.MINUTE));
		assertEquals(0, cal.get(Calendar.SECOND));
	}

	@Test
	public void testInBetween() {
		assertTrue(getDate(2014, 5, 20).isInBetween(getDate(2014, 5, 19), getDate(2014, 5, 21)));
		assertTrue(getDate(2014, 5, 19).isInBetween(getDate(2014, 5, 19), getDate(2014, 5, 21)));
		assertTrue(getDate(2014, 5, 21).isInBetween(getDate(2014, 5, 19), getDate(2014, 5, 21)));
		assertFalse(getDate(2014, 5, 18).isInBetween(getDate(2014, 5, 19), getDate(2014, 5, 25)));
		assertFalse(getDate(2014, 5, 26).isInBetween(getDate(2014, 5, 19), getDate(2014, 5, 25)));

		assertTrue(getDate(2014, 5, 20).isInBetween(null, getDate(2014, 5, 21)));
		assertTrue(getDate(2014, 5, 20).isInBetween(getDate(2014, 5, 19), null));
		assertTrue(getDate(2014, 5, 20).isInBetween(null, null));
	}
}
