package com.hcentive.billing.core.commons.domain;

import java.util.Calendar;

import static com.hcentive.billing.core.commons.domain.Period.getIntersection;
import static com.hcentive.billing.core.commons.domain.Period.hasIntersection;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.hcentive.billing.core.commons.vo.DateTime;

public class PeriodTest {

	@Test
	public void testGetIntersection() {
		DateTime d1 = getDate(2014, 5, 10);
		DateTime d2 = getDate(2014, 5, 10);
		DateTime d3 = getDate(2014, 5, 10);
		DateTime d4 = getDate(2014, 5, 10);

		assertTrue(d3.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getBeginsOn()) == 0);
		assertTrue(d2.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getEndsOn()) == 0);

		// |-------------------------------|
		//
		// ------------------------------------------|-------------------------------|
		d1 = getDate(2014, 5, 20);
		d2 = getDate(2014, 6, 20);
		d3 = getDate(2014, 6, 25);
		d4 = getDate(2014, 7, 20);

		assertTrue(getIntersection(new Period(d1, d2), new Period(d3, d4)) == null);

		// |-------------------------------|
		//
		// --------------------------------|-------------------------------|
		d1 = getDate(2014, 5, 20);
		d2 = getDate(2014, 6, 1);
		d3 = getDate(2014, 6, 1);
		d4 = getDate(2014, 7, 20);
		final Period intersection = getIntersection(new Period(d1, d2), new Period(d3, d4));
		assertTrue(intersection.getBeginsOn().equals(d3));
		assertTrue(intersection.getEndsOn().equals(d3));

		// |--------------------------|
		// -------|---------------------------|
		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 6, 15);
		d3 = getDate(2014, 5, 15);
		d4 = getDate(2014, 6, 20);

		assertTrue(d3.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getBeginsOn()) == 0);
		assertTrue(d2.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getEndsOn()) == 0);

		// ------|-------------------------------|
		// |------------------------------------------|
		d1 = getDate(2014, 5, 20);
		d2 = getDate(2014, 6, 15);
		d3 = getDate(2014, 5, 15);
		d4 = getDate(2014, 6, 20);

		assertTrue(d1.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getBeginsOn()) == 0);
		assertTrue(d2.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getEndsOn()) == 0);

		// -----------------|-------------------------------|
		// |------------------------------------------|
		d1 = getDate(2014, 5, 20);
		d2 = getDate(2014, 8, 15);
		d3 = getDate(2014, 5, 10);
		d4 = getDate(2014, 7, 20);

		assertTrue(d1.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getBeginsOn()) == 0);
		assertTrue(d4.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getEndsOn()) == 0);

		//
		// -------------------------------------------------|-------------------------------|
		// |------------------------------------------|
		d1 = getDate(2014, 7, 10);
		d2 = getDate(2014, 8, 10);
		d3 = getDate(2014, 6, 15);
		d4 = getDate(2014, 6, 20);

		assertTrue(getIntersection(new Period(d1, d2), new Period(d3, d4)) == null);

		// |------------------------------------------|
		// ------|--------------------------|
		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 8, 10);
		d3 = getDate(2014, 6, 15);
		d4 = getDate(2014, 6, 20);

		assertTrue(d3.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getBeginsOn()) == 0);
		assertTrue(d4.compareTo(getIntersection(new Period(d1, d2), new Period(d3, d4)).getEndsOn()) == 0);

	}

	@Test
	public void testHasIntersection() {

		DateTime d1 = getDate(2014, 5, 10);
		DateTime d2 = getDate(2014, 5, 25);
		DateTime d3 = getDate(2014, 5, 19);
		DateTime d4 = getDate(2014, 6, 19);

		assertTrue(hasIntersection(new Period(d1, d2), new Period(d3, d4)));

		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 7, 10);
		d3 = getDate(2014, 6, 15);
		d4 = getDate(2014, 6, 20);

		assertTrue(hasIntersection(new Period(d1, d2), new Period(d3, d4)));

		assertTrue(hasIntersection(new Period(getDate(2014, 6, 10), getDate(2014, 07, 25)), new Period(getDate(2014, 5, 19), getDate(2014, 6, 19))));

		assertTrue(hasIntersection(new Period(null, getDate(2014, 5, 25)), new Period(getDate(2014, 5, 19), getDate(2014, 6, 19))));

		assertTrue(hasIntersection(new Period(getDate(2014, 6, 10), null), new Period(getDate(2014, 5, 19), getDate(2014, 6, 19))));

		assertTrue(hasIntersection(new Period(new DateTime(null), new DateTime(null)), new Period(getDate(2014, 5, 19), getDate(2014, 6, 19))));

		assertTrue(hasIntersection(new Period(getDate(2014, 5, 10), getDate(2014, 5, 25)), new Period(null, getDate(2014, 6, 19))));

		assertTrue(hasIntersection(new Period(getDate(2014, 5, 10), getDate(2014, 5, 25)), new Period(getDate(2014, 5, 19), null)));

		assertTrue(hasIntersection(new Period(new DateTime(null), new DateTime(null)), new Period(new DateTime(null), new DateTime(null))));

		assertTrue(hasIntersection(new Period(getDate(2014, 5, 10), getDate(2014, 5, 25)), new Period(getDate(2014, 5, 25), getDate(2014, 6, 19))));

		assertTrue(hasIntersection(new Period(getDate(2014, 6, 19), getDate(2014, 9, 25)), new Period(getDate(2014, 5, 26), getDate(2014, 6, 19))));

		assertFalse(hasIntersection(new Period(getDate(2014, 6, 20), getDate(2014, 9, 25)), new Period(getDate(2014, 5, 26), getDate(2014, 6, 19))));

		assertFalse(hasIntersection(new Period(getDate(2014, 5, 10), getDate(2014, 5, 25)), new Period(getDate(2014, 5, 26), getDate(2014, 6, 19))));

	}

	@Test
	public void testIsBetween() {

		DateTime d1 = getDate(2014, 5, 10);
		DateTime d2 = getDate(2014, 5, 25);
		DateTime d3 = getDate(2014, 6, 19);
		DateTime d4 = getDate(2014, 7, 19);

		// |------------------------|
		// ------------------------------------|------------------|
		assertFalse(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 6, 19);
		d3 = d2;
		d4 = getDate(2014, 7, 20);

		// |------------------------|
		// -------------------------|------------------|
		assertFalse(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 6, 19);
		d3 = getDate(2014, 5, 19);
		d4 = getDate(2014, 7, 20);

		// |------------------------|
		// -------------|--------------------------|
		assertFalse(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 6, 19);
		d3 = getDate(2014, 5, 19);
		d4 = d2;

		// |---------------------------|
		// -----|----------------------|
		assertFalse(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 6, 19);
		d3 = getDate(2014, 5, 19);
		d4 = getDate(2014, 6, 10);

		// |---------------------------|
		// -----|------------------|-------
		assertFalse(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 6, 19);
		d3 = d1;
		d4 = d2;

		// |---------------------------|
		// |---------------------------|-------
		assertTrue(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 10);
		d2 = getDate(2014, 6, 19);
		d3 = d1;
		d4 = getDate(2014, 6, 10);

		// |---------------------------|
		// |----------------------|-------
		assertFalse(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 19);
		d2 = getDate(2014, 6, 10);
		d3 = getDate(2014, 5, 10);
		d4 = getDate(2014, 6, 19);

		// ------|---------------------------|
		// |---------------------------------------|-------
		assertTrue(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = null;
		d2 = getDate(2014, 6, 10);
		d3 = getDate(2014, 5, 10);
		d4 = getDate(2014, 6, 19);

		// --------------------------------|
		// |---------------------------------------|-------
		assertFalse(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = getDate(2014, 5, 19);
		d2 = getDate(2014, 6, 10);
		d3 = null;
		d4 = getDate(2014, 6, 19);

		// -----|---------------------------|
		// ---------------------------------------|-------
		assertTrue(new Period(d1, d2).isInBetween(new Period(d3, d4)));

		d1 = null;
		d2 = null;
		d3 = null;
		d4 = null;

		// ---------------------------------------------
		// ----------------------------------------------
		assertTrue(new Period(d1, d2).isInBetween(new Period(d3, d4)));

	}

	private static DateTime getDate(final int year, final int month, final int date) {
		final Calendar calendar = Calendar.getInstance();
		calendar.set(year, month, date, 0, 0, 0);

		return new DateTime(calendar.getTime());
	}

}
