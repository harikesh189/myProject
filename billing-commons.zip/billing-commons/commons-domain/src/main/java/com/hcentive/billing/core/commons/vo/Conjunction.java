package com.hcentive.billing.core.commons.vo;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;
import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.util.Collection;

public enum Conjunction {

	AND, OR;

	public boolean in(final Conjunction... conjunctions) {
		return isNotEmpty(conjunctions) && asList(conjunctions).contains(this);
	}

	public boolean in(final Collection<String> conjunctions) {
		if (isNotEmpty(conjunctions)) {
			for (final String operationStr : conjunctions) {
				final Conjunction operator = valueOf(operationStr);
				if (operator != null && operator.equals(this)) {
					return true;
				}
			}
		}
		return false;
	}

}
