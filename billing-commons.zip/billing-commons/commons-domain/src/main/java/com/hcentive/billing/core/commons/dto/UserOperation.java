package com.hcentive.billing.core.commons.dto;

public enum UserOperation {
	AddUser, AddUserCredentials, AssociateBusinessEntities, DeAssociateBusinessEntities, UpdateUserProfile, UpdateUserRoles, UpdateBusinessEntitiesAssociation, UpdatePassword, ForgotPassword, UpdateUserSecurityInfo, ActivateUser, DeActivateUser, UpdateUserStatus
}
