package com.hcentive.billing.core.commons.exception;

public class BillingException extends RuntimeException {
	
	private ErrorCode errorCode;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BillingException(String message) {
		super(message);
	}

	public BillingException(String message, Throwable t) {
		super(message, t);
	}

	public BillingException(final ErrorCode errorCode, final String message) {
		this(message);
		this.errorCode = errorCode;
	}
	
	public ErrorCode errorCode(){
		return this.errorCode;
	}
	
}
