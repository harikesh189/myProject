package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

public class Period implements Serializable {

	private final DateTime beginsOn;
	private final DateTime endsOn;

	protected Period(DateTime beginsOn, DateTime endsOn) {
		super();
		this.beginsOn = beginsOn;
		this.endsOn = endsOn;
	}

	public DateTime getBeginsOn() {
		return beginsOn;
	}

	public DateTime getEndsOn() {
		return endsOn;
	}

	public static Period newInstance(final DateTime start, final DateTime end) {
		if (start != null && end != null) {
			return new Period(start, end);
		}
		throw new IllegalArgumentException(
				"Both start and end dates are mandatory. Start:" + start
						+ "  End: " + end);
	}
}
