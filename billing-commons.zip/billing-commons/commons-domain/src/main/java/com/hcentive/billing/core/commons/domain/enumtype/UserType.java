package com.hcentive.billing.core.commons.domain.enumtype;


public enum UserType {
	Manager("Manager"), Administrator("Administrator");
	
	private String type;
	
	private UserType(final String type){
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

	public static UserType parse(final String val) {
		if (val != null && !val.trim().equals("")) {
			for (UserType userType : UserType.values()) {
				if (userType.type.equalsIgnoreCase(val)) {
					return userType;
				}
			}
		}
		return null;
	}
}
