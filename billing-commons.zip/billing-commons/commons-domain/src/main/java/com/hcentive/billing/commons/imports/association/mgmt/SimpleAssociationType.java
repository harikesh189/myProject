package com.hcentive.billing.commons.imports.association.mgmt;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

public class SimpleAssociationType<RDE extends ReferenceableDomainEntity>
		implements AssociationType<RDE> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6320098479107435072L;
	private final String associatedObjectEvent;
	private final String associationType;
	private final Class associationObjectType;

	public SimpleAssociationType(String associatedObjectEvent,
			String associationType, Class<RDE> associationObjectType) {
		super();
		this.associatedObjectEvent = associatedObjectEvent;
		this.associationType = associationType;
		this.associationObjectType = associationObjectType;
	}

	@Override
	public String getAssociatedObjectEvent() {
		return this.associatedObjectEvent;
	}

	@Override
	public Class<RDE> getAssociatedObjectType() {
		return this.associationObjectType;
	}

	@Override
	public String getAssociationType() {
		return this.associationType;
	}

}
