package com.hcentive.billing.core.commons.domain;

public enum RoleType {
SYSTEM,USER
}
