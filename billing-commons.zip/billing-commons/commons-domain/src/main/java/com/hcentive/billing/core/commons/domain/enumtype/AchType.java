package com.hcentive.billing.core.commons.domain.enumtype;

public enum AchType {
	CHECKING("C", "CHECKING"), SAVINGS("S", "SAVINGS");
	private final String value;
	private final String name;

	private AchType(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public static AchType parse(final String val) {
		for (AchType type : AchType.values()) {
			if (type.name.equalsIgnoreCase(val)
					|| val.equalsIgnoreCase("" + type.value)) {
				return type;
			}
		}
		return null;
	}

	public String getValue() {
		return value;
	}

	public String getName() {
		return name;
	}
}
