package com.hcentive.billing.core.commons.event;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.DocumentRef;

public class TenantAwareDocRefPayLoad implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 543148898174719089L;
	private DocumentRef docRef;
	private String tenantId;

	public TenantAwareDocRefPayLoad(DocumentRef docRef, String tenantId) {
		super();
		this.docRef = docRef;
		this.tenantId = tenantId;
	}

	public DocumentRef getDocRef() {
		return docRef;
	}

	public void setDocRef(DocumentRef docRef) {
		this.docRef = docRef;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

}
