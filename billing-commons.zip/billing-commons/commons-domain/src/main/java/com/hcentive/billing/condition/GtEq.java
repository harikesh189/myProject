package com.hcentive.billing.condition;
import com.hcentive.billing.core.commons.vo.Amount;

public class GtEq extends SimpleCondition<Amount> {

	private static final long serialVersionUID = 1L;
	
	public GtEq(){
		super();
	}
	
	public GtEq(final String name, final Amount value) {
		super(name, value);
	}
	
	
	@Override
	protected boolean eval(final Amount input) {
		if (input == null && this.getValue() == null) {
			return true;
		}

		if (input != null) {
			if (this.getValue() != null) {
				return input.greaterThanEqualTo(this.getValue());
			}
			return true;
		}
		return false;
	}

}
