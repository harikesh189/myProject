package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.MappedSuperclass;

import com.hcentive.billing.core.commons.api.Effectivity;

/**
 * It represent the configuration details for a billing policy.
 * 
 * @author nitin.singla
 * 
 */
@MappedSuperclass
public abstract class TimePeriodBoundEntity<T extends TimePeriodBoundEntity<T>>
		extends ReferenceableDomainEntity<T, String> implements
		VersionableEntity, Effectivity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period period;

	public Period getPeriod() {
		return this.period;
	}

	public boolean hasIntersction(final TimePeriodBoundEntity<T> entityToCheck) {
		return Period.hasIntersection(this.getPeriod(),
				entityToCheck.getPeriod());
	}

	public void setPeriod(final Period period) {
		this.period = period;
	}

	@Override
	public Period effectivePeriod() {
		return getPeriod();
	}
}
