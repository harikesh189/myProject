package com.hcentive.billing.core.commons.domain.audit;

import static com.hcentive.billing.core.commons.util.StringValidator.isBlank;

import javax.persistence.PrePersist;

import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.util.RandomGenerator;

/**
 * Its a listener for domain entity persistence life cycle.
 * 
 * @author nitin.singla
 */
public class IdentityAwareListener {
	/**
	 * Sets identity of the entity at the time of entity creation.
	 * 
	 * @param entity
	 *            The entity being persisted.
	 */
	@PrePersist
	public void beforeSave(final IdentityAware entity) {
		if (isBlank(entity.getIdentity())) {
			entity.setIdentity(RandomGenerator.randomString());
		}
	}
}
