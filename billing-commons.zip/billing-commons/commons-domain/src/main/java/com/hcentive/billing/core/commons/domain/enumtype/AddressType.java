package com.hcentive.billing.core.commons.domain.enumtype;

public enum AddressType {
	BILLING, MAILING;
}