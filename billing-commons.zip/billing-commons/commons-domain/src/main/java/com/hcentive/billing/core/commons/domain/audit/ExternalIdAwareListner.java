/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.domain.audit;

import static com.hcentive.billing.core.commons.util.StringValidator.isBlank;

import javax.persistence.PrePersist;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;

import com.hcentive.billing.core.commons.domain.ExternalIdAware;
import com.hcentive.billing.core.commons.util.IDGenerator;
import com.hcentive.billing.core.commons.util.RandomGenerator;

public class ExternalIdAwareListner {

	public static BeanFactory CONTEXT;
	private final Logger logger = LoggerFactory.getLogger(ExternalIdAwareListner.class);
	private static IDGenerator<String> generator;

	public static void registerIDGenerator(IDGenerator<String> generator) {
		ExternalIdAwareListner.generator = generator;
	}

	@PrePersist
	public void beforeSave(final ExternalIdAware entity) {
		if (isBlank(entity.getExternalId())) {
			logger.trace("Listner called before save to set external ID");
			String externalId = null;
			try {
				externalId = generator.generateID(entity);
				entity.setExternalId(externalId);
			} catch (final Exception e) {
				logger.error("Failed to generate external id for entity : {}", entity.getClass().getName());
				externalId = RandomGenerator.randomString();
			}
		}
	}

}
