package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.Status;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "import_data_audit")
public class ImportDataAudit extends BaseEntity {

	private static final long serialVersionUID = 1072320440007830593L;

	@Column(name = "input_mode")
	@Access(AccessType.FIELD)
	private String inputMode;

	@Column(name = "description")
	@Access(AccessType.FIELD)
	private String description;

	@Column(name = "total_item_count")
	@Access(AccessType.FIELD)
	private Long totalItemCount;

	@Column(name = "success_item_count")
	@Access(AccessType.FIELD)
	private Long successItemCount;

	@Column(name = "failed_item_count")
	@Access(AccessType.FIELD)
	private Long failedCount;

	@Column(name = "xsd_failed_item_count")
	@Access(AccessType.FIELD)
	private Long xsdFailedCount;

	@Column(name = "validation_failed_item_count")
	@Access(AccessType.FIELD)
	private Long validationFailedCount;

	@Column(name = "association_failed_item_count")
	@Access(AccessType.FIELD)
	private Long associationFailedCount;

	public Long getFailedCount() {
		return failedCount;
	}

	public void setFailedCount(Long failedCount) {
		this.failedCount = failedCount;
	}

	public Long getXsdFailedCount() {
		return xsdFailedCount;
	}

	public void setXsdFailedCount(Long xsdFailedCount) {
		this.xsdFailedCount = xsdFailedCount;
	}

	public Long getValidationFailedCount() {
		return validationFailedCount;
	}

	public void setValidationFailedCount(Long validationFailedCount) {
		this.validationFailedCount = validationFailedCount;
	}

	public Long getAssociationFailedCount() {
		return associationFailedCount;
	}

	public void setAssociationFailedCount(Long associationFailedCount) {
		this.associationFailedCount = associationFailedCount;
	}

	@Column(name = "imported_item")
	@Access(AccessType.FIELD)
	private String importedItemType;

	@Column(name = "status", nullable = false)
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private Status status;

	@Column(name = "process_id")
	@Access(AccessType.FIELD)
	private String processId;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "import_initiated_on")) })
	@Access(AccessType.FIELD)
	private DateTime importInitiatedOn;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "import_completed_on")) })
	@Access(AccessType.FIELD)
	private DateTime importCompletedOn;

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Long getTotalItemCount() {
		return totalItemCount;
	}

	public void setTotalItemCount(Long totalItemCount) {
		this.totalItemCount = totalItemCount;
	}

	public Long getSuccessItemCount() {
		return successItemCount;
	}

	public void setSuccessItemCount(Long successItemCount) {
		this.successItemCount = successItemCount;
	}

	public String getImportedItemType() {
		return importedItemType;
	}

	public void setImportedItemType(String importedItemType) {
		this.importedItemType = importedItemType;
	}

	public String getInputMode() {
		return inputMode;
	}

	public void setInputMode(String inputMode) {
		this.inputMode = inputMode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getTotalInvoiceCount() {
		return totalItemCount;
	}

	public void setTotalInvoiceCount(Long totalInvoiceCount) {
		this.totalItemCount = totalInvoiceCount;
	}

	public Long getSuccessInvoice() {
		return successItemCount;
	}

	public void setSuccessInvoice(Long successInvoice) {
		this.successItemCount = successInvoice;
	}

	public DateTime getImportInitiatedOn() {
		return importInitiatedOn;
	}

	public void setImportInitiatedOn(DateTime importInitiatedOn) {
		this.importInitiatedOn = importInitiatedOn;
	}

	public DateTime getImportCompletedOn() {
		return importCompletedOn;
	}

	public void setImportCompletedOn(DateTime importCompletedOn) {
		this.importCompletedOn = importCompletedOn;
	}

}
