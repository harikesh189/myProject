/**
 * 
 */
package com.hcentive.billing.commons.imports.association.mgmt;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import com.hcentive.billing.core.commons.domain.Reference;

/**
 * @author Dikshit.Vaid
 * 
 */
public interface AssociationDefinition<O> extends Serializable {

	public static class MatchCriteria implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5397123232907001569L;
		private final Collection<Reference> matchingReferences = new ArrayList<>();
		private final Map<String, String> addnMatchingProperties = new LinkedHashMap<>();
		private String externalIdentity;

		public void add(Reference reference) {
			matchingReferences.add(reference);
		}

		public String getExternalIdentity() {
			return externalIdentity;
		}

		public Collection<Reference> getMatchingReferences() {
			return this.matchingReferences;
		}

		public Map<String, String> getAddnMatchingProperties() {
			return addnMatchingProperties;
		}
		
		public void addMatchingProperty(String key, String value) {
			addnMatchingProperties.put(key, value);
		}
		
		public void addAllMatchingProperties(Map<String, String> keyValues) {
			addnMatchingProperties.putAll(keyValues);
		}
		
		public void setExternalIdentity(String externalIdentity) {
			this.externalIdentity = externalIdentity;
		}

		public void addAll(Collection<? extends Reference> references) {
			this.matchingReferences.addAll(references);
			
		}

	}

	O getIdentityOfResolvedObject();

	Boolean resolved();

	Boolean isMandatory();

	MatchCriteria matchCriteria();

	void setIdentityOfResolvedObject(O identity);

	AssociationType getAssociationType();
}
