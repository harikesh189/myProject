package com.hcentive.billing.core.commons.dto;

import java.io.Serializable;
import java.util.Map;

import com.hcentive.billing.core.commons.domain.PaymentMethod;



public class OutboundPaymentDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String remitId;
	private String partnerId;
	private String payerId;
	private ACHPaymentDetails achPaymentDetails;
	private Map<String, String> additonalInfo;
	

	public String getRemitId() {
		return remitId;
	}

	public void setRemitId(String remitId) {
		this.remitId = remitId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public Map<String, String> getAdditonalInfo() {
		return additonalInfo;
	}

	public void setAdditonalInfo(Map<String, String> additonalInfo) {
		this.additonalInfo = additonalInfo;
	}

	public String getPayerId() {
		return payerId;
	}

	public void setPayerId(String payerId) {
		this.payerId = payerId;
	}

	public ACHPaymentDetails getAchPaymentDetails() {
		return achPaymentDetails;
	}

	public void setAchPaymentDetails(ACHPaymentDetails achPAymentDetails) {
		this.achPaymentDetails = achPAymentDetails;
	}
}
