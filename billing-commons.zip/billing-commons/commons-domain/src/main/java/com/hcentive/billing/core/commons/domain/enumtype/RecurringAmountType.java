package com.hcentive.billing.core.commons.domain.enumtype;

public enum RecurringAmountType {
	INVOICE_AMOUNT, FLAT_AMOUNT, MINIMUM_AMOUNT_DUE, CURRENT_OUTSTANDING;
}