package com.hcentive.billing.core.commons.domain.type;

import java.sql.Types;

import org.eclipse.persistence.mappings.DatabaseMapping;
import org.eclipse.persistence.mappings.converters.Converter;
import org.eclipse.persistence.sessions.Session;

public class EnumTypeConverter implements Converter {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Object convertObjectValueToDataValue(final Object objectValue,
			final Session session) {
		if (objectValue instanceof Enum<?>) {
			return ((Enum) objectValue).name();
		}
		return null;
	}

	@Override
	public Object convertDataValueToObjectValue(final Object dataValue,
			final Session session) {
		if (dataValue instanceof String) {
			// return (Enum.valueOf(enumType, name) dataValue)
			return null;
		}
		return null;
	}

	@Override
	public boolean isMutable() {
		return true;
	}

	@Override
	public void initialize(final DatabaseMapping mapping, final Session session) {
		mapping.getField().setSqlType(Types.VARCHAR);
	}
}
