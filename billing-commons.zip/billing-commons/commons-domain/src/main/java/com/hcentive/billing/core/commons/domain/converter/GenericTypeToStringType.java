package com.hcentive.billing.core.commons.domain.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class GenericTypeToStringType<X> implements
		AttributeConverter<X, String> {

	private static final long serialVersionUID = 7667545502697191071L;

	@Override
	public String convertToDatabaseColumn(X x) {
		if(x==null)
			return "";
		return x.toString();
	}

	@Override
	public X convertToEntityAttribute(String dbValue) {
		return (X) dbValue;
	}

	/*
	 * @Override public Object nullSafeGet(ResultSet rs, String[] names,
	 * SessionImplementor session, Object owner) throws HibernateException,
	 * SQLException { if (rs.wasNull()) { return null; } return
	 * rs.getString(names[0]); }
	 * 
	 * @Override public void nullSafeSet(PreparedStatement st, Object value, int
	 * index, SessionImplementor session) throws HibernateException,
	 * SQLException { if (value == null) { st.setNull(index, Types.VARCHAR); }
	 * else { st.setString(index, value.toString()); }
	 * 
	 * }
	 */

}
