package com.hcentive.billing.core.commons.domain.enumtype;

public enum ContactPersonType {
	ADMIN, GENERAL_CONTACT
}