package com.hcentive.billing.core.commons.constant;

public class BillingConstant {

	public static final String ORG_PROFILE = "OrgProfile";
	public static final String PERSONAL_PROFILE = "PersonalProfile";

	public static final String SUBSCRIBER_ID = "subscriberId";
	public static final String GROUP_ID = "groupId";
	public static final String ACTIVE = "Active";
	public static final String IN_ACTIVE = "InActive";
	public static final String EXTERNAL_ID = "externalId";
	public static final String BE_TYPE_INDIVIDUAL = "Individual";
	public static final String BE_TYPE_GROUP = "Group";
	public static final String WHITE_LABEL_DOMAINS = "WhiteLabelDomains";
	public static final String REGISTERED_CLIENT_APPS = "RegisteredClientApps";
	public static final String REGISTERED_ENTERPRISES = "RegisteredEnterprises";

	public static final String SLIDING_TOKEN = "SlidingToken";
	public static final String FIXED_TOKEN = "FixedToken";
	public static final String ANONYMOUS_FIXED_TOKEN = "AnonymousFixedToken";
	public static final String BillingAccount="billingAccountId";
	public static final String SUBSCRIPION_ID = "SUBSCRIPION_ID";
	
	// URL format should be {SERVICE_NAME}/{TENANT_ID}/{BE_TYPE}/{BE_ID}
	public static final int ENTERPRISE_POSITION=1;
	public static final int BE_TYPE_POSITION=2;
	public static final int BE_ID_POSITION=3;
	
	public static final String COOKIE_SID = "sid";
	public static final String DEFAULT = "DEFAULT";
	public static final String AUTHENTICATION_STATE_CACHE_KEY = "AuthenticationState_";
	public static final String DNS_CACHING = "DNS_";
	public static final String BE_TO_CLIENT_APP_CACHING = "beToClientAppCache_";
	public static final String DRAFT_USER_REFERENCE = "draftUserReference";
	public static final String API_DOMAINS = "API_Domains";
	public static final Object PREVIOUS_PAYMENT_RECORD_STATUS = "PREVIOUS_PAYMENT_RECORD_STATUS";
	
	public static final String SLIDING_ACCESS_TOKEN_PREFIX = "SLIDING_ACCESS_TOKEN_PREFIX";
	public static final String XPG_APP="xpgApp";
	public static final String OVERDUE = "Overdue";
	public static final String REINSTATE = "TerminatedWithReins";
	public static final String TERMINATED = "Terminated";
	public static final String REINSTATEMENT_FUTURE_PERIOD = "REINSTATEMENT_FUTURE_PERIOD";
	public static final String UN_APPLIED_CASH_KEY = "is.unapplied.payment.process";
	public static final String UNKNOWN = "UNKNOWN";
	public static final String COVERAGE_DATE = "proposedCoverageEffectiveDate";
	public static final String ELIGIBILITY = "ELIGIBILITY";
	/**# Possible Strategies are BILLING_ACCOUNT, GROUP_SETUP , ELIGIBILITY,INVOICE;**/
	public static final String SUBSCRIPTION_STRATEGY_BILLING_ACCOUNT = "BILLING_ACCOUNT";
	public static final String SUBSCRIPTION_STRATEGY_ELIGIBILITY = "ELIGIBILITY";
	public static final String SUBSCRIPTION_STRATEGY_GROUP_SETUP = "GROUP_SETUP";
	public static final String SUBSCRIPTION_STRATEGY_INVOICE = "INVOICE";
	public static final String AMOUNT_PAID = "AMOUNT_PAID";
}
