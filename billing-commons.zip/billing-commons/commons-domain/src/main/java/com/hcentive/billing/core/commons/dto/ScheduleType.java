package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.domain.enumtype.SchedulerType;

public class ScheduleType {

	private SchedulerType schedulerType;

	private String value;

	public SchedulerType getSchedulerType() {
		return schedulerType;
	}

	public void setSchedulerType(SchedulerType schedulerType) {
		this.schedulerType = schedulerType;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
