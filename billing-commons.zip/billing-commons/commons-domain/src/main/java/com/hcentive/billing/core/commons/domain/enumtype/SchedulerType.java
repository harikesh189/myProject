package com.hcentive.billing.core.commons.domain.enumtype;

public enum SchedulerType {
	DAYOFMONTH("DAYOFMONTH", "dayOfMonth"), LASTDAYOFMONTH("LASTDAYOFMONTH",
			"lastDayOfMonth"), FIXEDDATE("FIXEDDATE", "fixedDate"), DAYOFWEEK(
			"DAYOFWEEK", "dayOfWeek"), DAYOFCYCLE("DAYOFCYCLE", "dayOfCycle"), DAYOFFORTNIGHT(
			"DAYOFFORTNIGHT", "dayOfFortnight"), DAYOFQUARTER("DAYOFQUARTER",
			"dayOfQuarter"), DAYOFSEMIANNUAL("DAYOFSEMIANNUAL",
			"dayOfSemiAnnual"), DAYBEFOREDUEDATE("DAYBEFOREDUEDATE",
			"dayBeforeDueDate"), ONDUEDATE("ONDUEDATE", "onDueDate"), PAYNOW("PAYNOW", "payNow"), 
			ONRECEIPT("ONRECEIPT", "onReceipt");

	private final String value;
	private final String name;

	private SchedulerType(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public static SchedulerType parse(final String val) {
		if (val != null) {
			for (SchedulerType type : SchedulerType.values()) {
				if (type.name.equalsIgnoreCase(val)
						|| val.equalsIgnoreCase(type.value)) {
					return type;
				}
			}
		}
		return null;
	}

	public String getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

	// DAYOFMONTH,DAYOFWEEK,DAYOFCYCLE,DAYOFFORTNIGHT,DAYOFQUARTER,DAYOFSEMIANNUAL,
	// DAYBEFOREDUEDATE,ONDUEDATE,ONRECEIPT;
}
