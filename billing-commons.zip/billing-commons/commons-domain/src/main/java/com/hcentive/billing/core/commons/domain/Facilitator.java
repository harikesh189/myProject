package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "business_entity")
@DiscriminatorValue("Facilitator")
public class Facilitator extends FinancialPartner {

	private static final long serialVersionUID = -5573790865857754395L;

	public Facilitator() {
	}

	public Facilitator(final String identity) {
		this(identity, "facilitator");
	}

	public Facilitator(final String identity, final String type) {
		super(identity);
	}

	public Facilitator(final String identity, final String externalId,
			final String type) {
		super(identity, externalId, type);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String typeName() {
		return "Facilitator";
	}
}
