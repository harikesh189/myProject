package com.hcentive.billing.core.commons.domain;

public interface ManagedEntity<I, V, R extends Referenceable<I, V, R>> {
	Reference<I, R, V> toReference();

	String getType();
}
