package com.hcentive.billing.core.commons.domain.enumtype;

public enum MarketIndicator {
	INDIVIDUAL(0, "Individual"), GROUP(1, "Group");
	private final int value;
	private final String name;

	private MarketIndicator(int value, String name) {
		this.name = name;
		this.value = value;
	}

	public static MarketIndicator parse(final int value) {
		switch (value) {
		case 0:
			return INDIVIDUAL;
		case 1:
			return GROUP;
		default:
			return INDIVIDUAL;
		}
	}

	public static MarketIndicator parse(final String val) {
		for (MarketIndicator mi : MarketIndicator.values()) {
			if (mi.name.equalsIgnoreCase(val) || val.equals("" + mi.value)) {
				return mi;
			}
		}
		return null;
	}

	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

}