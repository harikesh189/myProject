package com.hcentive.billing.commons.imports.association.mgmt;

public abstract class Association<O> {

	protected AssociationDefinition definition;
	protected O associatedObject;

	protected Association() {

	}

	public Association(AssociationDefinition definition, O associatedObject) {
		this.definition = definition;
		this.associatedObject = associatedObject;
	}

	public AssociationDefinition associationDefinition() {
		return definition;
	}

	public O associatedObject() {
		return associatedObject;
	}
}