package com.hcentive.billing.core.commons.constant;

/**
 * Enum for Payment Initiator source - Whether auto or manual (UI).
 * 
 */

public enum PaymentInitiator {

	AUTO, MANUAL

}
