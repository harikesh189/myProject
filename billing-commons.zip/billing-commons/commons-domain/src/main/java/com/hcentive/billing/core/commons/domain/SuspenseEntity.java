package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "business_entity")
@DiscriminatorValue("SuspenseEntity")
public class SuspenseEntity extends BusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected SuspenseEntity() {
		super();
	}
	
	public SuspenseEntity(final String identity) {
		super(identity);
	}

	@Override
	public String typeName() {
		return "SuspenseEntity";
	}

}
