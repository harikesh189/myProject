package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

public interface DocumentEntity extends Serializable {

	public String getId();
}
