package com.hcentive.billing.core.commons.domain.mongo;

import java.io.Serializable;

public class BusinessReason implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8701580066353642224L;

	private String expression;
	
	private String field;
	
	private String description;
	
	private DeliveryTimeType deliveryTimeType;

	public String getExpression() {
		return expression;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public DeliveryTimeType getDeliveryTimeType() {
		return deliveryTimeType;
	}

	public void setDeliveryTimeType(DeliveryTimeType deliveryTimeType) {
		this.deliveryTimeType = deliveryTimeType;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}	
}
