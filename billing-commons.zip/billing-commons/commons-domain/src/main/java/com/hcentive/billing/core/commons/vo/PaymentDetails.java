package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;

import com.hcentive.billing.core.commons.domain.EbillPaymentMethod;
import com.hcentive.billing.core.commons.domain.Invoice;

public class PaymentDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5717463351369992080L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "balance_value")),
			@AttributeOverride(name = "name", column = @Column(name = "balance_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "balance_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "balance_short_name")) })
	private final Amount amount;
	private final String customerRefId;
	private Invoice invoice;
	private String contractId;
	private EbillPaymentMethod paymentMethod;

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public PaymentDetails(Amount amount, String customerRefId,
			String contractId, EbillPaymentMethod paymentMethod) {
		this.amount = amount;
		this.customerRefId = customerRefId;
		this.contractId = contractId;
		this.paymentMethod = paymentMethod;
	}

	public Amount getAmount() {
		return amount;
	}

	public String getCustomerRefId() {
		return customerRefId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public EbillPaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(EbillPaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
}
