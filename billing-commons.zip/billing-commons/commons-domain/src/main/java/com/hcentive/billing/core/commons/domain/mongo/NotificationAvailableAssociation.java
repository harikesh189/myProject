/**
 * 
 */
package com.hcentive.billing.core.commons.domain.mongo;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.condition.Condition;
import com.hcentive.billing.trigger.Trigger;

/**
 * @author Dikshit.Vaid
 *
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_notification_available_association")
public class NotificationAvailableAssociation extends AbstractMongoEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3605701166411890563L;

	public NotificationAvailableAssociation(){
		super();
	}
	@NotNull
	private NotificationEvent notificationEvent;
	
	private List<NotificationTemplate> notificationTemplates;

	private List<Trigger> availableTriggers;

	private List<BusinessReason> availableBusinessReasons;
	
	private Condition availableConditions;

	public NotificationEvent getNotificationEvent() {
		return notificationEvent;
	}

	public List<Trigger> getAvailableTriggers() {
		return availableTriggers;
	}

	public Condition getAvailableConditions() {
		return availableConditions;
	}

	public void setNotificationEventAssociation(
			NotificationEvent notificationEvent) {
		this.notificationEvent = notificationEvent;
	}

	public List<BusinessReason> getAvailableBusinessReasons() {
		return availableBusinessReasons;
	}
	
	public List<NotificationTemplate> getNotificationTemplates() {
		return notificationTemplates;
	}

	public static NotificationAvailableAssociation createNotificationAvailableAssociation(
			NotificationEvent notificationEvent) {
		NotificationAvailableAssociation notificationAvailableAssociation = new NotificationAvailableAssociation();
		notificationAvailableAssociation.notificationEvent = notificationEvent;
		return notificationAvailableAssociation;
	}

}
