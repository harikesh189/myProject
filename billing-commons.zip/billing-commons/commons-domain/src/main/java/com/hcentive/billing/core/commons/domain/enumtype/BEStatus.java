package com.hcentive.billing.core.commons.domain.enumtype;

public enum BEStatus {
	ACTIVE, INACTIVE
}