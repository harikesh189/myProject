package com.hcentive.billing.core.commons.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

@Entity
@Table(name = "identifier_code")
public class IdentifierCode extends BaseEntity {
	
	@Column(name = "identifier")
	private String identifier;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	private Type type;
	
	protected IdentifierCode() {}
	
	public IdentifierCode(String identifier, Type type) {
		this.identifier = identifier; 
		this.type = type;
	}
	
	public IdentifierCode(String identifier, String type) {
		this(identifier, Type.parse(type));
	}
	
	public enum Type {
		EIN, SSN, TIN, PAYER_ID;
		
		public static Type parse(final String val) {
			for (Type type : Type.values()) {
				if (type.name().equalsIgnoreCase(val)) {
					return type;
				}
			}
			return null;
		}
	}
	
	public String getIdentifier() {
		return identifier; 
	}
	
	public Type getType() {
		return type; 
	}
	
}
