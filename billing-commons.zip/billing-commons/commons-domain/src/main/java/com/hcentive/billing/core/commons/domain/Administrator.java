/**
 * 
 */
package com.hcentive.billing.core.commons.domain;

import java.util.Set;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.util.RandomGenerator;

/**
 * @author Dikshit.Vaid
 * 
 */
@Entity
@DiscriminatorValue("Administrator")
public class Administrator extends User {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6387144347159895515L;

	public static Administrator createNewAdministrator(String identity,String externalId,
			final PersonalProfile profile, final Set<Role> roles, final UserStatus status) {
		if (profile == null || roles == null || roles.size() == 0) {
			throw new IllegalArgumentException(
					"Profile and Role are mandatory.");
		}
		if (identity == null) {
			identity = RandomGenerator.randomString();
		}
		
		// this piece of code is to set name inside profile when adding operator user.
		if(profile !=null    ){
			String name="";
			String firstName= profile.getFirstName();
			String middleName= profile.getMiddleName();
			String lastName= profile.getLastName();
			name =(null != firstName ? firstName + " " : "")
			+ (null != middleName ? middleName + " " : "")
			+ (null != lastName ? lastName : "");
			profile.setName(name);
		}
		return new Administrator(identity, externalId ,profile, roles,status);
	}

	protected Administrator() {

	}

	protected Administrator(final String identity, final String externalId,
			final PersonalProfile profile, final Set<Role> roles,final UserStatus status) {
		super(identity,externalId, profile, roles,status);
	}
}
