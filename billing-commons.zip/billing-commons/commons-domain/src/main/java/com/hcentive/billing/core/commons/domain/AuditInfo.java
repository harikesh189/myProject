package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author nitin.singla
 */

@Embeddable
public class AuditInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -267940718659130720L;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "created_at", updatable = false)) })
	private DateTime createdAt;

	@Column(name = "created_by", updatable = false)
	private String createdBy;
	
	@Column(name = "created_by_name", updatable = false)
	private String createdByName;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "modified_at")) })
	private DateTime modifiedAt;

	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_by_name", updatable = true)
	private String modifiedByName;

	public DateTime getCreatedAt() {
		return this.createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public DateTime getModifiedAt() {
		return this.modifiedAt;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setCreatedAt(final DateTime createdAt) {
		this.createdAt = createdAt;
	}

	public void setCreatedBy(final String createBy) {
		this.createdBy = createBy;
	}

	public void setModifiedAt(final DateTime modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	public void setModifiedBy(final String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public String getModifiedByName() {
		return modifiedByName;
	}

	public void setModifiedByName(String modifiedByName) {
		this.modifiedByName = modifiedByName;
	}

	@Override
	public String toString() {
		return "AuditInfo [createdAt=" + createdAt + ", createdBy=" + createdBy
				+ ", createdByName="  + ", modifiedAt="
				+ modifiedAt + ", modifiedBy=" + modifiedBy
				+ ", modifiedByName="  + "]";
	}

}
