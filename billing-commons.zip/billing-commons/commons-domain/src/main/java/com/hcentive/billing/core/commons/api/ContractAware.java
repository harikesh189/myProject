package com.hcentive.billing.core.commons.api;

public interface ContractAware<T> {

}
