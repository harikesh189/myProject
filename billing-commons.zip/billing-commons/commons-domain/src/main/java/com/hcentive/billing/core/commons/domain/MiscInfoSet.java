package com.hcentive.billing.core.commons.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "misc_info_set")
public class MiscInfoSet extends BaseEntity {

	private static final long serialVersionUID = 2236220336894113258L;

	@Access(AccessType.FIELD)
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "misc_info_set_item", joinColumns = @JoinColumn(name = "misc_info_set_id", referencedColumnName = "ID"), inverseJoinColumns = @JoinColumn(name = "misc_info_id", referencedColumnName = "ID"))
	private Set<MiscInfo> items = new HashSet<MiscInfo>();

	public Set<MiscInfo> getItems() {
		return items;
	}

	public void add(MiscInfo info) {
		items.add(info);
	}

	public boolean remove(MiscInfo info) {
		return items.remove(info);
	}
}
