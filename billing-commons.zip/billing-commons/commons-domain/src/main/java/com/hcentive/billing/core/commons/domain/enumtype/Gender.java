package com.hcentive.billing.core.commons.domain.enumtype;

public enum Gender {

	MALE, FEMALE;
}
