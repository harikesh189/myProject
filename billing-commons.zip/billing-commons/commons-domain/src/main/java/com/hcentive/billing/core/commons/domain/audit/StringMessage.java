package com.hcentive.billing.core.commons.domain.audit;

public class StringMessage implements AuditMessage {

	private static final long serialVersionUID = 1L;

	private String message;
	
	public StringMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
