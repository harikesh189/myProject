package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.converter.BigDecimalConverter;

@Embeddable
public class Amount implements Serializable {
	public final static RoundingMode ROUNDING_MODE = RoundingMode.HALF_DOWN;
	public final static int roundingScale = 2;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1496835723353890245L;

	@Embedded
	private Currency currency;

	@Column(name = "value")
	@Convert(converter = BigDecimalConverter.class)
	private BigDecimal value;

	public Amount() {
		super();
		this.currency = new Currency();
		setValue(BigDecimal.ZERO);
	}

	public Amount(final BigDecimal value) {
		this(value, new Currency());
	}

	public Amount(final BigDecimal value, final Currency currency) {
		super();
		setValue(value);
		this.currency = currency;
	}

	public Amount(final int value) {
		this(new BigDecimal(value));
	}
	
	public Amount(final String value) {
		this(new BigDecimal(value));
	}

	public Amount add(final Amount currentCreditAmount) {
		BigDecimal bigDecimal = currentCreditAmount.getValue();
		if (this.getValue() != null) {
			bigDecimal = this.getValue().add(currentCreditAmount.getValue());
		}
		return new Amount(bigDecimal, this.getCurrency());
	}

	public Amount multiply(final double multiplicand) {
		final BigDecimal bdMultiplier = new BigDecimal(multiplicand);
		return new Amount(this.getValue().multiply(bdMultiplier),
				this.getCurrency());
	}

	@JsonIgnore
	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final Amount other = (Amount) obj;
		if (this.currency == null) {
			if (other.currency != null) {
				return false;
			}
		} else if (!this.currency.equals(other.currency)) {
			return false;
		}
		if (this.value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!(this.value.compareTo(other.value) == 0)) {
			return false;
		}
		return true;
	}
	
	@JsonIgnore
	public boolean greaterThan(final Object obj) {
		if (this == obj) {
			return false;
		}
		if (obj == null) {
			return true;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final Amount other = (Amount) obj;
		if (this.value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!(this.value.compareTo(other.value) > 0)) {
			return false;
		}
		return true;
	}
	
	@JsonIgnore
	public boolean greaterThanEqualTo(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return true;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final Amount other = (Amount) obj;
		if (this.value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!(this.value.compareTo(other.value) >= 0)) {
			return false;
		}
		return true;
	}

	@JsonIgnore
	public boolean lessThan(final Object obj) {
		if (this == obj) {
			return false;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final Amount other = (Amount) obj;
		if (this.value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!(this.value.compareTo(other.value) < 0)) {
			return false;
		}
		return true;
	}
	
	@JsonIgnore
	public boolean lessThanEqualTo(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final Amount other = (Amount) obj;
		if (this.value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!(this.value.compareTo(other.value) <= 0)) {
			return false;
		}
		return true;
	}
	
	public Currency getCurrency() {
		return this.currency;
	}

	public BigDecimal getValue() {
		return this.value;
	}

	@Override
	@JsonIgnore
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ (this.currency == null ? 0 : this.currency.hashCode());
		result = prime * result
				+ (this.value == null ? 0 : this.value.hashCode());
		return result;
	}

	@JsonIgnore
	public boolean isNegative() {
		if (null == this.value) {
			return true;
		}

		return this.value.signum() == -1;

	}

	@JsonIgnore
	public boolean isNegativeOrZero() {
		if (null == this.value) {
			return true;
		}

		return this.value.signum() != 1;

	}
	
	@JsonIgnore
	public boolean isZero() {
		if (null == this.value) {
			return true;
		}

		return this.value.signum() ==0;
	}

	public void setValue(final BigDecimal value) {
		this.value = value.setScale(roundingScale, ROUNDING_MODE);
	}

	public Amount subtract(final Amount currentCreditAmount) {
		final BigDecimal bigDecimal = this.getValue().subtract(
				currentCreditAmount.getValue());
		return new Amount(bigDecimal, this.getCurrency());
	}

	protected void set(final BigDecimal value) {
		setValue(value);
	}

	protected void set(final Currency currency) {
		this.currency = currency;
	}

	public static Amount newAmount(final BigDecimal value) {
		final BigDecimal roundedValue = value.setScale(roundingScale,
				ROUNDING_MODE);
		return new Amount(roundedValue, Currency.DEFAULT_CURRENCY);
	}

	@Override
	public String toString() {
		return this.currency.getSymbol()
				+ NumberFormat.getInstance(Locale.US).format(this.getValue());
	}

}
