package com.hcentive.billing.core.commons.api;

import java.util.Collection;

import com.hcentive.billing.core.commons.domain.Reference;

public interface ManagesEntity {

	public Collection<Reference> getManagedEntities();

}
