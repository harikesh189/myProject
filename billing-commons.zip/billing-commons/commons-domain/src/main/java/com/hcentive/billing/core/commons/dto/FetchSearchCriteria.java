package com.hcentive.billing.core.commons.dto;

import java.util.List;

import com.hcentive.billing.core.commons.criteria.FilterCriteria;

public class FetchSearchCriteria {
	private List<FilterCriteria> filterCriteriaList;

	private PageRequestCriteria pageRequestCriteria;

	public PageRequestCriteria getPageRequestCriteria() {
		return this.pageRequestCriteria;
	}

	public void setPageRequestCriteria(final PageRequestCriteria pageRequestCriteria) {
		this.pageRequestCriteria = pageRequestCriteria;
	}

	public List<FilterCriteria> getFilterCriteriaList() {
		return this.filterCriteriaList;
	}

	public void setFilterCriteriaList(final List<FilterCriteria> filterCriteriaList) {
		this.filterCriteriaList = filterCriteriaList;
	}

}
