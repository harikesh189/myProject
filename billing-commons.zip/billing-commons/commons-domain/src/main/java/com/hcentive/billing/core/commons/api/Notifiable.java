package com.hcentive.billing.core.commons.api;

public interface Notifiable<A> {

	public A getAddress();

}