package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "line_item")
public class LineItem extends ReferenceableDomainEntity<LineItem, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3550049530573278830L;

	@Column(name = "item_type")
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private ItemType itemType;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "associated_date")) })
	@Access(AccessType.FIELD)
	private DateTime associatedDate;
	
	@Column(name = "description")
	@Access(AccessType.FIELD)
	private String description;
	
	@Column(name = "qualifier")
	@Access(AccessType.FIELD)
	private String qualifier;
	
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;
	

	
	public LineItem(String identity) {
		this.identity=identity;
	}
	public LineItem(){}

	public ItemType getItemType() {
		return itemType;
	}

	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}

	public DateTime getAssociatedDate() {
		return associatedDate;
	}

	public void setAssociatedDate(DateTime associatedDate) {
		this.associatedDate = associatedDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQualifier() {
		return qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	@Override
	public String typeName() {
		return "lineItem";
	}

	@Override
	public String refValue() {
		return getExternalId();
	}

}
