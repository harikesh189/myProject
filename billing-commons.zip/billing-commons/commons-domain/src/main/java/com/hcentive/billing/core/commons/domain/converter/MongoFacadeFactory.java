/**
 * 
 */
package com.hcentive.billing.core.commons.domain.converter;

import org.springframework.data.mongodb.core.MongoTemplate;

public class MongoFacadeFactory {

	private static MongoFacade mongoFacade;

	public static void registerMongoFacade(final MongoFacade facade) {
		mongoFacade = facade;
	}

	public static MongoFacade getMongoFacade() {
		return mongoFacade;
	}

	public static MongoTemplate getMongoTemplate() {
		return mongoFacade.getMongoTemmplate();
	}

}