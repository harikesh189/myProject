/**
 * 
 */
package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.dto.PageRequestCriteria;

@Deprecated
public class SearchCriteria implements Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger LOGGER = LoggerFactory.getLogger(SearchCriteria.class);

	private Map<String, SearchCriteriaOnColumns> criteria = new HashMap<>();

	private PageRequestCriteria pageRequestCriteria = new PageRequestCriteria();

	private Set<ProjectedField> projectedFields = new HashSet<>();

	private String referenceId;

	private Set<Reference> references;

	public SearchCriteria addMultiValueCriteria(final String columnName, final CriteriaOperator operator, final List<String> values) {
		if (values == null || values.isEmpty()) {
			return this;
		}
		final StringBuilder value = new StringBuilder().append("(");
		for (final String string : values) {
			value.append("'").append(string).append("',");
		}
		value.deleteCharAt(value.length() - 1).append(")");
		return this.createColumnCriteria(columnName, operator, value.toString());
	}

	public SearchCriteria addMultiValueCriteriaForMongo(final String columnName, final CriteriaOperator operator, final List<String> values) {
		if (values == null || values.isEmpty()) {
			return this;
		}
		final StringBuilder value = new StringBuilder().append("");
		for (final String string : values) {
			value.append("").append(string).append(",");
		}
		value.deleteCharAt(value.length() - 1).append("");

		return this.createColumnCriteria(columnName, operator, value);
	}

	public SearchCriteria addSingleValueCriteria(final String columnName, final CriteriaOperator operator, Object value) {
		if (value instanceof String) {
			value = "'" + value + "'";
		}
		return this.createColumnCriteria(columnName, operator, value);
	}

	public SearchCriteria addSingleValueCriteriaForMongo(final String columnName, final CriteriaOperator operator, final String value) {
		return this.createColumnCriteria(columnName, operator, value);
	}

	public Map<String, SearchCriteriaOnColumns> getCriteria() {
		return this.criteria;
	}

	public PageRequestCriteria getPageRequestCriteria() {
		return this.pageRequestCriteria;
	}

	public Set<ProjectedField> getProjectedFields() {
		return this.projectedFields;
	}

	public String getReferenceId() {
		return this.referenceId;
	}

	public Set<Reference> getReferences() {
		return this.references;
	}

	public String populateProjectedFields() {
		final StringBuilder builder = new StringBuilder();
		LOGGER.debug("Projected Fields ::::", this.projectedFields);
		for (final ProjectedField projectedFields : this.projectedFields) {
			if (null == projectedFields.getEntityField() || projectedFields.getEntityField().isEmpty()) {
				throw new IllegalArgumentException("Entity field is Mandatory and can't be null");
			}

			if (null != projectedFields.getMappedField()) {
				builder.append(projectedFields.getEntityField()).append(" as ").append(projectedFields.getMappedField()).append(",");
			} else {
				builder.append(projectedFields.getEntityField()).append("");
			}

		}
		if (builder.charAt(builder.length() - 1) == ',') {
			builder.delete(builder.length() - 1, builder.length());
		}
		LOGGER.debug("Query String", builder.toString());
		return builder.toString();
	}

	public void setCriteria(final Map<String, SearchCriteriaOnColumns> criteria) {
		this.criteria = criteria;
	}

	public void setPageRequestCriteria(final PageRequestCriteria pageRequestCriteria) {
		this.pageRequestCriteria = pageRequestCriteria;
	}

	public void setProjectedFields(final Set<ProjectedField> projectedFields) {
		this.projectedFields = projectedFields;
	}

	public void setReferenceId(final String referenceId) {
		this.referenceId = referenceId;
	}

	public void setReferences(final Set<Reference> references) {
		this.references = references;
	}

	public SearchCriteria createColumnCriteria(final String columnName, final CriteriaOperator operator, final Object value) {
		if (value == null) {
			return this;
		}
		final SearchCriteriaOnColumns searchCriteriaOnColumns = new SearchCriteriaOnColumns();
		searchCriteriaOnColumns.setColumnValue(value.toString());
		searchCriteriaOnColumns.setCaseSensitiveSearch(false);
		searchCriteriaOnColumns.setOperator(operator.getValue());
		this.criteria.put(columnName, searchCriteriaOnColumns);
		return this;
	}

	public static SearchCriteria createColumnSearchCriteria() {
		return new SearchCriteria();
	}

}
