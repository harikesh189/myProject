/**
 * 
 */
package com.hcentive.billing.commons.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.commons.imports.association.mgmt.Association;
import com.hcentive.billing.commons.imports.association.mgmt.AssociationDefinition;
import com.hcentive.billing.commons.imports.association.mgmt.AssociationType;
import com.hcentive.billing.commons.imports.association.mgmt.DomainAssociation;
import com.hcentive.billing.commons.imports.association.mgmt.SimpleAssociation;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 * 
 */
public class ItemMetaInfo<T> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4980231927196175407L;

	public static enum ItemImportStatus {
		ASSOCIATIONS_PENDING, MANDATORY_ASSOCIATIONS_DONE, ALL_ASSOCIATIONS_DONE, DOMAIN_VALIDATION_FAILED,ARCHIVED;
	}
	
	public static enum ItemReleaseStatus {
		PENDING, CONFIRMED;
	}

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ItemMetaInfo.class);
	private String processId;
	private String tenant;
	private T referenceRecord;

	private DateTime importedAt;
	public DateTime getModifiedAt() {
		return modifiedAt;
	}

	public void setModifiedAt(DateTime modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	private DateTime modifiedAt;
	private final Collection<AssociationDefinition> associationDefinitions = new HashSet<>();

	private ItemImportStatus status = ItemImportStatus.ASSOCIATIONS_PENDING;
	private ItemReleaseStatus releaseStatus = ItemReleaseStatus.PENDING;
	
	public ItemMetaInfo(String processId, String tenant, T deltaRecord) {
		this.processId = processId;
		this.tenant = tenant;
		this.referenceRecord = deltaRecord;
		importedAt = new DateTime();
	}

	public ItemMetaInfo(final String processId, final String tenant) {
		this(processId, tenant, null);
	}

	protected ItemMetaInfo() {

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void add(final Association association) {
		if (association != null && association instanceof DomainAssociation) {
			final AssociationDefinition definition = association
					.associationDefinition();
			definition
					.setIdentityOfResolvedObject(((DomainAssociation<ReferenceableDomainEntity>) association)
							.associatedObject().getIdentity());
		} else if (association instanceof SimpleAssociation) {
			final AssociationDefinition definition = association
					.associationDefinition();
			definition
					.setIdentityOfResolvedObject(((SimpleAssociation) association)
							.associatedObject());

		}
	}

	public void add(AssociationDefinition definition) {
		if (definition != null) {
			associationDefinitions.add(definition);
		}
	}

	public void addAssociations(Collection<Association> associations) {
		if (associations != null) {
			for (final Association association : associations) {
				add(association);
			}

		}
	}

	public void addDefinitions(
			Collection<AssociationDefinition> associationDefinitions) {
		if (associationDefinitions != null) {
			for (final AssociationDefinition definition : associationDefinitions) {
				add(definition);
			}

		}
	}

	public Collection<AssociationDefinition> allAssociationDefinitions() {
		return associationDefinitions;
	}

	public Map<AssociationType, Set<AssociationDefinition>> allAssociationDefinitionsByType() {
		LOGGER.debug("Fetching the all association dedefinitions by type inside the ItemMetaInfo:::allAssociationDefinitionsByType()");
		final Map<AssociationType, Set<AssociationDefinition>> definitionsByType = new HashMap<AssociationType, Set<AssociationDefinition>>();
		for (final AssociationDefinition definition : associationDefinitions) {
			final AssociationType type = definition.getAssociationType();
			Set<AssociationDefinition> definitionsOfThisType = definitionsByType
					.get(type);
			if (definitionsOfThisType == null) {
				definitionsOfThisType = new HashSet<AssociationDefinition>();
				definitionsByType.put(type, definitionsOfThisType);
			}
			definitionsOfThisType.add(definition);

		}
		LOGGER.debug("returning the association definition by type");
		return definitionsByType;
	}

	public boolean allAssociationsDone() {
		for (final AssociationDefinition definition : associationDefinitions) {
			if (!definition.resolved()) {
				return false;
			}
		}
		return true;
	}

	public T getReferenceRecord() {
		return referenceRecord;
	}

	public void setReferenceRecord(T referenceRecord) {
		this.referenceRecord = referenceRecord;
	}

	public String getProcessId() {
		return processId;
	}

	public String getTenant() {
		return tenant;
	}

	public DateTime getImportedAt() {
		return importedAt;
	}

	public Collection<AssociationDefinition> getAssociationDefinitions() {
		return associationDefinitions;
	}

	public ItemImportStatus getStatus() {
		return status;
	}
	
	public ItemReleaseStatus getReleaseStatus() {
		return releaseStatus;
	}

	public boolean allMandatoryAssociationsDone() {
		for (final AssociationDefinition definition : associationDefinitions) {
			if (definition.isMandatory() && !definition.resolved()) {
				return false;
			}
		}
		return true;
	}
	
	public boolean releasable() {
		return ItemReleaseStatus.CONFIRMED.equals(releaseStatus);
	}

	public AssociationDefinition find(AssociationDefinition matchingDef) {
		for (AssociationDefinition def : associationDefinitions) {
			if (def.equals(matchingDef)) {
				return def;
			}
		}
		return null;
	}

	public DateTime importedAt() {
		return importedAt;
	}

	public String processId() {
		return processId;
	}

	public void setImportedAt(DateTime importedAt) {
		this.importedAt = importedAt;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public void setStatus(ItemImportStatus status) {
		this.status = status;
	}
	
	public void setReleaseStatus(ItemReleaseStatus releaseStatus) {
		this.releaseStatus = releaseStatus;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	public ItemImportStatus status() {
		return status;
	}

	public String tenant() {
		return tenant;
	}

	public Map<AssociationType, Set<AssociationDefinition>> unresolvedAssociationDefinitions() {
		final Map<AssociationType, Set<AssociationDefinition>> definitionsByType = new HashMap<AssociationType, Set<AssociationDefinition>>();
		LOGGER.debug("inside the unresolvedAssociationDefinitions():::start");
		final boolean mandatoryAssociationsDone = allMandatoryAssociationsDone();
		LOGGER.debug("Checking the mandatory associations done or not"
				+ mandatoryAssociationsDone);
		for (final AssociationDefinition definition : associationDefinitions) {
			if (!mandatoryAssociationsDone || !definition.resolved()) {
				final AssociationType type = definition.getAssociationType();
				LOGGER.debug("Creating the association defs from association type"
						+ type);
				Set<AssociationDefinition> definitionsOfThisType = definitionsByType
						.get(type);
				if (definitionsOfThisType == null) {
					definitionsOfThisType = new HashSet<AssociationDefinition>();
					definitionsByType.put(type, definitionsOfThisType);
				}
				definitionsOfThisType.add(definition);
			}
		}
		return definitionsByType;
	}
}
