package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_credential")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "user_credentials_type")
public abstract class UserCredentials extends DomainEntity {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 9177563818706387309L;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	@Access(AccessType.FIELD)
	private UserTenantInfo userTenantInfo;
	
	@Column(name = "idp_key")
	@Access(AccessType.FIELD)
	private String idpKey; 
	
	@Column(name = "enterprise_name")
	@Access(AccessType.FIELD)
	private String enterpriseName; 
	
	public UserCredentials(String identity, String externalId) {
		super(identity, externalId);
	}

	protected UserCredentials() {
	}
	
	public UserCredentials(String identity,String externalId,String enterpriseName,String idpKey){
		super(identity, externalId);
		this.enterpriseName = enterpriseName;
		this.idpKey = idpKey;
	}
	
	public String getEnterpriseName(){
		return this.enterpriseName;
	}
	
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}
	
	public String getIdpKey(){
		return idpKey;
	}
	
	protected void setIdpKey(final String idpKey){
		this.idpKey= idpKey;
	}

	public UserTenantInfo getUserTenantInfo() {
		return userTenantInfo;
	}

	public void setUserTenantInfo(UserTenantInfo userTenantInfo) {
		this.userTenantInfo = userTenantInfo;
	}

	public abstract Object getAuthKey();

}
