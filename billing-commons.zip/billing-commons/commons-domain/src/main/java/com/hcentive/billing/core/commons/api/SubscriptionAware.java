package com.hcentive.billing.core.commons.api;

import com.hcentive.billing.core.commons.domain.EbillSubscription;

public interface SubscriptionAware {
	
	void setSubscription(EbillSubscription subscription);

}
