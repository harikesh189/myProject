package com.hcentive.billing.core.commons.domain;

import javax.persistence.Entity;

@Entity
public class Subscription extends
		ReferenceableDomainEntity<Subscription, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Subscription(Long id, String identity, String externalId) {
		super(id, identity, externalId);
		// TODO Auto-generated constructor stub
	}

	protected Subscription() {
	}

	public Subscription(Long id, String identity) {
		super(id, identity);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String typeName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String refValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
