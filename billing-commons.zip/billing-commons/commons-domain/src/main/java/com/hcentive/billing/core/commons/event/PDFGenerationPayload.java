package com.hcentive.billing.core.commons.event;

import java.io.Serializable;
import java.util.Map;

import com.hcentive.billing.core.commons.dto.DocumentGenerationParametersDTO;

public class PDFGenerationPayload implements Serializable {

	private Map<String,String> objectMap;

	private DocumentGenerationParametersDTO documentGenerationParametersDTO;

	public DocumentGenerationParametersDTO getDocumentGenerationParametersDTO() {
		return documentGenerationParametersDTO;
	}

	public void setDocumentGenerationParametersDTO(
			DocumentGenerationParametersDTO documentGenerationParametersDTO) {
		this.documentGenerationParametersDTO = documentGenerationParametersDTO;
	}

	public Map<String, String> getObjectMap() {
		return objectMap;
	}

	public void setObjectMap(Map<String, String> objectMap) {
		this.objectMap = objectMap;
	}
}
