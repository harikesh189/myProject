package com.hcentive.billing.core.commons.domain.converter;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.hcentive.billing.core.commons.dto.PageRequestCriteria;
import com.hcentive.billing.core.commons.dto.PageableRequest;
import com.hcentive.billing.core.commons.exception.BillingException;
import com.hcentive.billing.core.commons.util.ITransformer;

public class PageableTransformer implements ITransformer<PageRequestCriteria, PageableRequest> {

	public static PageableTransformer INSTANCE = new PageableTransformer();

	private PageableRequest constructPageSpecification(final PageRequestCriteria pageRequestCriteria) {
		if (pageRequestCriteria != null) {
			try {
				final Direction sortDirection = this.getSortDirection(pageRequestCriteria);
				final int page = pageRequestCriteria.getPageIndex();
				final int size = pageRequestCriteria.getSize();
				if (isNotEmpty(pageRequestCriteria.getSortOrders())) {
					return new PageableRequest(page, size, new Sort(pageRequestCriteria.getSortOrders()));
				}

				final PageableRequest pageSpecification = new PageableRequest(page, size, new Sort(sortDirection, pageRequestCriteria.getSortedColumn() != null
						&& !pageRequestCriteria.getSortedColumn().isEmpty() ? pageRequestCriteria.getSortedColumn() : "identity"));
				return pageSpecification;
			} catch (final NumberFormatException e) {
				throw new BillingException(e.getMessage());
			}
		}
		return null;
	}

	private Direction getSortDirection(final PageRequestCriteria pageRequestCriteria) {
		return pageRequestCriteria.getSortDirection() != null ? pageRequestCriteria.getSortDirection() : Direction.ASC;
	}

	@Override
	public PageableRequest transform(final PageRequestCriteria pageRequestCriteria) {
		return this.constructPageSpecification(pageRequestCriteria);
	}

}
