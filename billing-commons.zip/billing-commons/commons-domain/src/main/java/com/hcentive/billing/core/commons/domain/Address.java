package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.AddressType;
import com.hcentive.billing.core.commons.domain.enumtype.Category;

@Entity
@Table(name = "contact")
@DiscriminatorValue("Address")
public class Address extends Contact {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected Address(Category category) {
		super(category);
	}

	@Column(name = "address_line1")
	@Access(AccessType.FIELD)
	private String addressLine1;

	@Column(name = "address_line2")
	@Access(AccessType.FIELD)
	private String addressLine2;

	@Column(name = "address_line3")
	@Access(AccessType.FIELD)
	private String addressLine3;

	@Column(name = "county")
	@Access(AccessType.FIELD)
	private String county;

	@Column(name = "city")
	@Access(AccessType.FIELD)
	private String city;

	@Column(name = "state")
	@Access(AccessType.FIELD)
	private String state;

	@Column(name = "country")
	@Access(AccessType.FIELD)
	private String country;

	@Column(name = "zipcode")
	@Access(AccessType.FIELD)
	private String zipcode;

	@Column(name = "address_type")
	@Enumerated(EnumType.STRING)
	private AddressType addressType;

	public Address() {
		super(Category.HOME);// Default Category
	}

	private Address(final Category category, final String addressLine1,
			final String state, final String zipCode) {
		this(category);
		this.addressLine1 = addressLine1;
		this.state = state;
		this.zipcode = zipCode;
	}

	public static Address newAddress(final String category,
			final String addressLine1, final String state, final String zipCode) {
		Address addr = null;

		switch (category.toUpperCase()) {
		case "HOME":
			addr = new Address(Category.HOME, addressLine1, state, zipCode);
			break;
		case "WORK":
			addr = new Address(Category.WORK, addressLine1, state, zipCode);
			break;
		case "REMIT_TO":
			addr = new Address(Category.REMIT_TO, addressLine1, state, zipCode);
			break;
		default:
			addr = new Address(Category.OTHER, addressLine1, state, zipCode);
			break;
		}
		return addr;
	}

	public void setAddressline2(String addressLine2) {
		this.addressLine2 = addressLine2;

	}

	public void setAddressline3(String addressLine3) {
		this.addressLine3 = addressLine3;

	}

	public void setCity(String city) {
		this.city = city;

	}

	public void setCountry(String country) {
		this.country = country;

	}

	public void setCounty(String county) {
		this.county = county;

	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1
	 *            the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2
	 *            the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}

	/**
	 * @param addressLine3
	 *            the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the zipcode
	 */
	public String getZipcode() {
		return zipcode;
	}

	/**
	 * @param zipcode
	 *            the zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	/**
	 * @return the county
	 */
	public String getCounty() {
		return county;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	public AddressType getAddressType() {
		return addressType;
	}

	public void setAddressType(AddressType addressType) {
		this.addressType = addressType;
	}

}
