/**
 * 
 */
package com.hcentive.billing.core.commons.domain.mongo;

/**
 * @author Dikshit.Vaid
 *
 */
public enum DeliveryType {
	EMAIL,SMS,ALL,PAPER,MBOX;

}
