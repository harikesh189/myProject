package com.hcentive.billing.core.commons.domain;

import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.hcentive.billing.core.commons.domain.enumtype.BEStatus;


@Entity
@Table(name = "contract_party")
public class Party<P extends BusinessEntity<Profile>> extends
		ReferenceableDomainEntity<Party<BusinessEntity<Profile>>, String> {

	@OneToOne(fetch = FetchType.EAGER, targetEntity = BusinessEntity.class)
	@JoinColumn(name = "entity_id")
	@Access(AccessType.FIELD)
	private final P party;

	
	@Enumerated(EnumType.STRING)
	@Column(name = "qualifier")
	private  PartyQualifier qualifier;

	@Transient
	private Map<String, Object> additionalInfo;

	public Party(P party) {
		this.party = party;
	}
	protected Party(){
		this.party=null;
	}

	public Party(P party, String type) {
		if(type==null || !type.equalsIgnoreCase(party.getType())){
			throw new IllegalAccessError("Illegal Party Add type and party tyoe are not same");
		}
		this.party=party;
		PartyQualifier partyQualifier = PartyQualifier.getQualifier(type);
		if(null==partyQualifier){
			this.qualifier=PartyQualifier.OTHER;
		}
		else{
			this.qualifier=partyQualifier;
		}
	}

	public Party(P party, PartyQualifier qualifier) {
		this.party=party;
		this.qualifier=qualifier;
	}

	public PartyQualifier getQualifier() {
		return qualifier;
	}

	public void setQualifier(PartyQualifier qualifier) {
		this.qualifier = qualifier;
	}

	public Map<String, Object> getAdditionalInfo() {
		return additionalInfo;
	}

	public P getParty() {
		return party;
	}

	public String getType() {
		return this.party.getType();
	}

	@Override
	public String refValue() {
		return identity;
	}

	public void setAdditionalInfo(Map<String, Object> additionalInfo) {
		this.additionalInfo = additionalInfo;
	}


	@Override
	public String typeName() {
		return "Party";
	}

}
