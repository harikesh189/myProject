package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.domain.Ach;
import com.hcentive.billing.core.commons.vo.Amount;

public class ACHPaymentDetails extends BasicPaymentDetails<Ach> {

	public ACHPaymentDetails() {

	}

	public ACHPaymentDetails(Amount amount, Ach ach) {
		super(amount);
		this.setPaymentInstrument(ach);
	}

	public Ach getAch() {
		return getPaymentInstrument();
	}

	public void setAch(final Ach ach) {
		setPaymentInstrument(ach);
	}
}
