package com.hcentive.billing.condition;

import static com.hcentive.billing.core.commons.util.ObjectUtil.areEqual;

public class Eq<T> extends SimpleCondition<T> {

	private static final long serialVersionUID = 1L;

	
	public Eq() {
		super();
	}
	
	public Eq(final String name, final T value) {
		super(name, value);
	}

	@Override
	protected boolean eval(final T input) {
		if (input == null && this.getValue() == null) {
			return true;
		}
		return areEqual(this.getValue(), input);
	}

}
