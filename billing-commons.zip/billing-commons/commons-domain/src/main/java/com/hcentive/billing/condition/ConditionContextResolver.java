package com.hcentive.billing.condition;

public interface ConditionContextResolver {
	Object getValue(final String propName);
}
