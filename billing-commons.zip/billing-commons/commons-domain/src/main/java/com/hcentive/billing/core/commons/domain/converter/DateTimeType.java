package com.hcentive.billing.core.commons.domain.converter;

import java.util.Date;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.hcentive.billing.core.commons.vo.DateTime;

@Converter
public class DateTimeType implements AttributeConverter<DateTime, Date> {

	@Override
	public Date convertToDatabaseColumn(final DateTime dateTime) {
		if (!DateTime.isNull(dateTime)) {
			return dateTime.getDate();
		}
		return null;
	}

	@Override
	public DateTime convertToEntityAttribute(final Date date) {
		return date == null ? null : new DateTime(date);
	}

}
