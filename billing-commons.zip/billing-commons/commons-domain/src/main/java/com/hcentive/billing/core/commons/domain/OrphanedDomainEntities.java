package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ORPHANED_DOMAIN_ENTITIES")
public class OrphanedDomainEntities extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 277248662152629107L;

	@Column(name = "DATA_STR")
	@Access(AccessType.FIELD)
	private String dataStr;

	@Column(name = "TYPE")
	@Access(AccessType.FIELD)
	private String type;

	@Column(name = "ref_identity")
	@Access(AccessType.FIELD)
	private String refIdentity;

	public String getRefIdentity() {
		return refIdentity;
	}

	public void setRefIdentity(String refIdentity) {
		this.refIdentity = refIdentity;
	}

	@Column(name = "STATUS")
	@Access(AccessType.FIELD)
	private String status;

	public String getDataStr() {
		return dataStr;
	}

	public void setDataStr(String dataStr) {
		this.dataStr = dataStr;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
