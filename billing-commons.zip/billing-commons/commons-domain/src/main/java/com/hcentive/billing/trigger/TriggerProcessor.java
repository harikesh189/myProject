package com.hcentive.billing.trigger;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

public interface TriggerProcessor extends Serializable {

	<T> DateTime process(TriggerContext<T> triggerContext) throws Exception;
}
