package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

import com.hcentive.billing.core.commons.domain.enumtype.Category;

@Entity
@Table(name = "contact")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "contact_type")
public abstract class Contact extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9150560139801273848L;

	@Column(name = "category", nullable = false)
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private Category category;

	@Access(AccessType.FIELD)
	@Column(name = "is_primary")
	private boolean isPrimary;

	@Transient
	protected transient ContactSet contacts;

	protected Contact(final Category category) {
		if (null == category)
			throw new IllegalArgumentException();
		this.category = category;
	}

	void setPrimary(boolean primaryStatus) {
		this.isPrimary = primaryStatus;
	}

	public void markAsPrimary() {
		this.isPrimary = true;
		if (this.contacts != null) {
			this.contacts.markedAsPrimary(this);
		}
	}

	public Category getCategory() {
		return category;
	}

	public boolean isPrimary() {
		return isPrimary;
	}

	protected void removePrimaryStatus() {
		this.isPrimary = false;
	}

	void set(ContactSet contacts) {
		this.contacts = contacts;
	}

	protected Contact() {
	}
}
