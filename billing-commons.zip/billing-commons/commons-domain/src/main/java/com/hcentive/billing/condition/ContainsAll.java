package com.hcentive.billing.condition;

import java.util.Collection;

import static com.hcentive.billing.core.commons.util.CollectionUtil.nullSafe;

public class ContainsAll<T> extends SimpleCondition<Collection<T>> {

	private static final long serialVersionUID = 1L;

	public ContainsAll() {
		super();
	}

	public ContainsAll(final String name, final Collection<T> values) {
		super(name, nullSafe(values));
	}

	@Override
	protected boolean eval(final Collection<T> input) {
		return !(nullSafe(input)).isEmpty() && nullSafe(this.getValue()).containsAll(nullSafe(input));
	}
}
