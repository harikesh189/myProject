package com.hcentive.billing.core.commons.domain.converter;

import org.springframework.core.convert.converter.Converter;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

@SuppressWarnings("rawtypes")
public class ClassTypeWriteConverter implements Converter<Class, BasicDBObject> {

	@Override
	public BasicDBObject convert(final Class source) {
		final BasicDBObject dbo = new BasicDBObject();
		dbo.put("className", source.getName());
		return dbo;
	}

}
