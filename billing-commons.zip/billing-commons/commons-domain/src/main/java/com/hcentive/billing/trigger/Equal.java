/**
 * 
 */
package com.hcentive.billing.trigger;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
public class Equal extends AbstractTrigger {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6988141069723297545L;

	public Equal() {
		super();
	}
	
	@Override
	public String name() {
		return "EQUAL";
	}

	@Override
	public DateTime operate(DateTime applyOnValue) {
		return applyOnValue;
	}

}
