package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "payment_receipt")
public class PaymentReceipt extends
		ReferenceableDomainEntity<PaymentReceipt, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4871671796998560984L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "value")),
			@AttributeOverride(name = "name", column = @Column(name = "name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	@ManyToOne(targetEntity = Customer.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "business_id")
	@Access(AccessType.FIELD)
	private BusinessEntity<Profile> customer;

	@Column(name = "payment_receipt_xml")
	@Access(AccessType.FIELD)
	private byte[] paymentReceiptXML;

	@Column(name = "payment_source")
	@Access(AccessType.FIELD)
	private String paymentSource;

	@Column(name = "payment_token_id")
	@Access(AccessType.FIELD)
	private String paymentTokenId;

	@Column(name = "payment_type")
	@Access(AccessType.FIELD)
	private String paymentType;

	@Column(name = "preferred_payment_instrument")
	@Access(AccessType.FIELD)
	private boolean preferredPaymentInstrument;

	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status;

	@Access(AccessType.FIELD)
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "transaction_date")) })
	private DateTime transactionDate;

	public PaymentReceipt() {
		super();
	}

	public PaymentReceipt(final String identity) {
		super(identity);
	}

	public Amount getAmount() {
		return this.amount;
	}

	public BusinessEntity<Profile> getCustomer() {
		return this.customer;
	}

	public byte[] getPaymentReceiptXML() {
		return this.paymentReceiptXML;
	}

	public String getPaymentSource() {
		return this.paymentSource;
	}

	public String getPaymentTokenId() {
		return this.paymentTokenId;
	}

	public String getPaymentType() {
		return this.paymentType;
	}

	public String getStatus() {
		return this.status;
	}

	public DateTime getTransactionDate() {
		return this.transactionDate;
	}

	public boolean isPreferredPaymentInstrument() {
		return this.preferredPaymentInstrument;
	}

	@Override
	public String refValue() {
		// TODO Auto-generated method stub
		return this.identity;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	public void setCustomer(final BusinessEntity<Profile> customer) {
		this.customer = customer;
	}

	public void setPaymentReceiptXML(final byte[] paymentReceiptXML) {
		if (paymentReceiptXML != null) {
			this.paymentReceiptXML = paymentReceiptXML.clone();
		} else {
			this.paymentReceiptXML = null;
		}
	}

	public void setPaymentSource(final String paymentSource) {
		this.paymentSource = paymentSource;
	}

	public void setPaymentTokenId(final String paymentTokenId) {
		this.paymentTokenId = paymentTokenId;
	}

	public void setPaymentType(final String paymentType) {
		this.paymentType = paymentType;
	}

	public void setPreferredPaymentInstrument(
			final boolean preferredPaymentInstrument) {
		this.preferredPaymentInstrument = preferredPaymentInstrument;
	}

	public void setStatus(final String status) {
		this.status = status;
	}

	public void setTransactionDate(final DateTime transactionDate) {
		this.transactionDate = transactionDate;
	}

	@Override
	public String typeName() {
		// TODO Auto-generated method stub
		return "PaymentReceipt";
	}

}
