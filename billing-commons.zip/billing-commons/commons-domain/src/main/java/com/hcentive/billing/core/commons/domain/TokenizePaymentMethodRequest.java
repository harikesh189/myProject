package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "tokenize_payment_method_request")
public class TokenizePaymentMethodRequest extends
		ReferenceableDomainEntity<TokenizePaymentMethodRequest, String> {

	public static final String STATUS_NEW = "TOKENIZE_PAYMENT_METHOD_REQUEST_INITIATED";
	public static final String STATUS_FAILED = "TOKENIZE_PAYMENT_METHOD_REQUEST_FAILED";
	public static final String STATUS_SUCCESS = "TOKENIZE_PAYMENT_METHOD_REQUEST_SUCCESSFULL";

	private static final long serialVersionUID = -4668604309065460574L;

	protected TokenizePaymentMethodRequest() {
		this.status = STATUS_NEW;
	}

	public TokenizePaymentMethodRequest(String identity) {
		super(identity);
		this.status = STATUS_NEW;
	}

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "transaction_date")) })
	@Access(AccessType.FIELD)
	private DateTime transactionDate;

	@ManyToOne(targetEntity = Customer.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "business_id")
	@Access(AccessType.FIELD)
	private BusinessEntity<Profile> savedFor;

	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status;

	@Override
	public String typeName() {
		return "Tokenize Payment Method Request";
	}

	@Override
	public String refValue() {
		return identity;
	}

	public DateTime getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(DateTime transactionDate) {
		this.transactionDate = transactionDate;
	}

	public BusinessEntity<Profile> getSavedFor() {
		return savedFor;
	}

	public void setSavedFor(BusinessEntity<Profile> savedFor) {
		this.savedFor = savedFor;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
