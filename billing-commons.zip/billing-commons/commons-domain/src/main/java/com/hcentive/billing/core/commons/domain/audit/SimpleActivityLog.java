package com.hcentive.billing.core.commons.domain.audit;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.ExternalIdAware;
import com.hcentive.billing.core.commons.vo.DateTime;

public class SimpleActivityLog<T extends Serializable> implements ActivityLog<T>, ExternalIdAware {

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String externalId;
	
	private String message;
	private String category;
	private String userId;
	private String userName;
	private String processId;
	private DateTime activityTime;
	
	private T activityData;

	protected SimpleActivityLog() {
		super();
	}
	
	public SimpleActivityLog(String category) {
		this.category = category;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public DateTime getActivityTime() {
		return activityTime;
	}

	public void setActivityTime(DateTime activityTime) {
		this.activityTime = activityTime;
	}

	@Override
	public String message() {
		return getMessage();
	}

	@Override
	public String category() {
		return getCategory();
	}

	@Override
	public String processId() {
		return getProcessId();
	}

	@Override
	public DateTime activityTime() {
		return getActivityTime();
	}

	@Override
	public String userId() {
		return getUserId();
	}

	@Override
	public String userName() {
		return getUserName();
	}

	@Override
	public String getExternalId() {
		return externalId;
	}

	@Override
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public T getActivityData() {
		return activityData;
	}

	public void setActivityData(T activityData) {
		this.activityData = activityData;
	}

	@Override
	public T activityData() {
		return getActivityData();
	}

}