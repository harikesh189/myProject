package com.hcentive.billing.core.commons.domain.enumtype;

public enum FinancialTrxnStatus {
	NEW,PARTIAL_SETTLED,SETTLED
}
