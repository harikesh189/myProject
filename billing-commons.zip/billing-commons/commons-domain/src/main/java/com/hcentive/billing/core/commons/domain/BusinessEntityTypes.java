package com.hcentive.billing.core.commons.domain;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class BusinessEntityTypes {

	public static final String INDIVIDUAL_CUSTOMER = "Individual";
	public static final String GROUP_CUSTOMER = "Group";
	public static final String OPERATOR = "Operator";
	public static final String BROKER = "Broker";
	public static final String CMS = "CMS";
	public static final String FFM = "FFM";
	public static final String EXCHANGE = "Exchange";
	public static final String CARRIER = "CARRIER";
	public static final String CLIENT = "Client";
	public static final String OTHER = "OtherRegulatoryBody";
	public static final String HEALTH_PLAN_PROVIDER = "HealthPlanProvider";
	public static final String WFM_OPERATOR = "WfmOperator";
	public static final String SUBSIDY_PROVIDER = "SubsidyProvider";
	public static final String INDIVIDUAL_CUSTOMER_MOBILE = "IndividualMobile";
	public static final String SUSPNSE_ENTITY = "SuspenseEntity";
	public static final String BENEFIT_VENDOR = "BenefitVendor";

	// public static final String SUBSIDY_PROVIDER = "SUBSIDY_PROVIDER";
	private static final Set<String> BE_TYPES = new HashSet<>();

	public static void register(String beType) {
		BE_TYPES.add(beType);
	}

	public static Collection<String> beTypesInApplication() {
		return Collections.unmodifiableCollection(BE_TYPES);
	}
}
