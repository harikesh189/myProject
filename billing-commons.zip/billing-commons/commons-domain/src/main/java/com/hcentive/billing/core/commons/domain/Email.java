package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.Category;

@Entity
@Table(name = "contact")
@DiscriminatorValue("Email")
public class Email extends Contact {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2411497874836751618L;
	@Access(AccessType.FIELD)
	@Column(name = "email_id")
	private String emailId;

	public String getEmailId() {
		return emailId;
	}

	protected Email(final Category category, final String emailId) {
		super(category);
		this.emailId = emailId;
	}

	protected Email() {
	}

	public static Email newDefaultEmail(final String emailId) {
		if (emailId == null || emailId.isEmpty()) {
			throw new IllegalArgumentException("EmailId is mandatory");
		}
		return new Email(Category.OTHER, emailId);
	}
	public static Email newEmail(final Category category ,final String emailId) {
		if (emailId == null || emailId.isEmpty()) {
			throw new IllegalArgumentException("EmailId is mandatory");
		}
		return new Email(category, emailId);
	}


	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj == this) {
				return true;
			}
			if (obj instanceof Email) {
				Email that = (Email) obj;
				if (this.getId() != null && that.getId() != null) {
					return this.getId().equals(that.getId());
				} else {
					return this.emailId.equals(that.emailId)
							&& this.getCategory().equals(that.getCategory());
				}
			}
		}
		return false;
	}

	@Override
	public int hashCode() {
		if (null == this.emailId)
			return super.hashCode();
		return super.hashCode() + this.getEmailId().hashCode();
	}
}
