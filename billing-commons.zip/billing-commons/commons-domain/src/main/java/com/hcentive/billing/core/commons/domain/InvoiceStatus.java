package com.hcentive.billing.core.commons.domain;

public enum InvoiceStatus {

	OPEN("OPEN"), CLOSED("CLOSED"), CANCELLED("CANCELLED");
	private String status;

	private InvoiceStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public static InvoiceStatus parse(final String val) {
		if (val != null && !val.trim().equals("")) {
			for (InvoiceStatus invoiceStatus : InvoiceStatus.values()) {
				if (invoiceStatus.status.equalsIgnoreCase(val)) {
					return invoiceStatus;
				}
			}
		}
		return null;
	}
}
