package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "businessEntity")
@DiscriminatorValue("Observer")
public class Observer extends Partner<OrgProfile> {

	private static final long serialVersionUID = 3392695505523687690L;

	@Override
	public OrgProfile getProfile() {
		return super.getProfile();
	}

	@Override
	public void setProfile(OrgProfile orgProfile) {
		super.setProfile(orgProfile);
	}

	@Override
	public String typeName() {
		return "Observer";
	}

}
