package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Currency implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8925951831809725115L;

	@Column(name = "name")
	private final String name;

	@Column(name = "symbol")
	private final String symbol;

	@Column(name = "short_name")
	private final String shortName;

	public Currency() {
		this(DEFAULT_CURRENCY.name, DEFAULT_CURRENCY.symbol,
				DEFAULT_CURRENCY.shortName);

	}

	public Currency(final String name, final String symbol,
			final String shortName) {
		super();
		this.name = name;
		this.symbol = symbol;
		this.shortName = shortName;
	}

	public String getName() {
		return this.name;
	}

	public String getSymbol() {
		return this.symbol;
	}

	public String getShortName() {
		return this.shortName;
	}
	
	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		
		final Currency other = (Currency) obj;
		
		if(other.getName().equals(this.getName()) && other.getShortName().equals(this.getShortName()) && other.getSymbol().equals(this.getSymbol())){
			return true;
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((shortName == null) ? 0 : shortName.hashCode());
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		return result;
	}

	public static final Currency US_DOLLAR = new Currency("US Dollar", "$",
			"USD");
	public static final Currency DEFAULT_CURRENCY = US_DOLLAR;
}
