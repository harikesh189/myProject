package com.hcentive.billing.core.commons.domain.audit;

import java.io.Serializable;

public interface AuditMessage extends Serializable {
	
}
