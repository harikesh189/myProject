package com.hcentive.billing.core.commons.domain.audit;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

public interface ActivityLog<T extends Serializable> extends Serializable {

	String message();

	String category();
	
	String processId();
	
	DateTime activityTime();
	
	String userId();
	
	String userName();
	
	T activityData();
	
}
