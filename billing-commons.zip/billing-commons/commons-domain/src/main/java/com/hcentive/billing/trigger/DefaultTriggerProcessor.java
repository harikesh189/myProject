/**
 * 
 */
package com.hcentive.billing.trigger;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
@Component
public class DefaultTriggerProcessor implements TriggerProcessor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2360810638172243432L;

	@Override
	public <T> DateTime process(TriggerContext<T> triggerContext) throws Exception {
		
		return triggerContext.eval();
	}

}
