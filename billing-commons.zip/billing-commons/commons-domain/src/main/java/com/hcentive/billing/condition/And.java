package com.hcentive.billing.condition;

import java.util.Collection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class And extends ComplexCondition {

	private static Logger logger = LoggerFactory.getLogger(And.class);

	private static final long serialVersionUID = 1L;

	public And() {
		super("AND");
	}

	public And(final Collection<? extends Condition> conds) {
		super("AND", conds);
	}

	public And(final Condition... conds) {
		super("AND", conds);
	}

	@Override
	public boolean evaluate(
			final ConditionContextResolver conditionValueResolver) {
		logger.debug("Evaluating {} condition start", this.toString());
		for (final Condition cond : this.getConds()) {
			final boolean result = cond.evaluate(conditionValueResolver);
			if (!result) {
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean evaluate(final Map<String, ?> inputValueMap) {
		logger.debug("Evaluating {} condition start", this.toString());
		for (final Condition cond : this.getConds()) {
			final boolean result = cond.evaluate(inputValueMap);
			if (!result) {
				return false;
			}
		}
		return true;
	}
}
