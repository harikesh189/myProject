/**
 * 
 */
package com.hcentive.billing.core.commons.domain.mongo;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author Dikshit.Vaid
 *
 */
public class NotificationTemplate extends AbstractMongoEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -565932741968887776L;

	private String name;
	private String description;
	private DeliveryType deliveryType;
	private String path;
	private String category;
	private Object _id;

	@JsonIgnore
	public Object get_id() {
		return _id;
	}

	@JsonIgnore
	public void set_id(Object _id) {
		this._id = _id;
	}

	public NotificationTemplate(){
		
	}
	
	public NotificationTemplate(String name, String description, DeliveryType deliveryType,
			String path) {
		super();
		this.name = name;
		this.description = description;
		this.deliveryType = deliveryType;
		this.path = path;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public DeliveryType getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(DeliveryType deliveryType) {
		this.deliveryType = deliveryType;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}
