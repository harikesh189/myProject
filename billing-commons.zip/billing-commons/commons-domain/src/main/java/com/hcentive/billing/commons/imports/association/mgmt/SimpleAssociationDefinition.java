package com.hcentive.billing.commons.imports.association.mgmt;

public class SimpleAssociationDefinition<O> extends
		AbstractAssociationDefinition<O> {

	private O matchedValue;
	private MatchCriteria matchCriteria = null;

	protected SimpleAssociationDefinition() {

	}

	public SimpleAssociationDefinition(final AssociationType associationType,
			final Boolean isMandatory, final O value) {
		super(associationType, isMandatory);
		this.matchedValue = value;
	}

	public static <O> SimpleAssociationDefinition mandatoryDefinition(
			final AssociationType associationType, final O value) {
		return new SimpleAssociationDefinition(associationType, true, value);
	}

	public static <O> SimpleAssociationDefinition nonMandatoryDefinition(
			final AssociationType associationType, final O value) {
		return new SimpleAssociationDefinition(associationType, false, value);
	}

	@Override
	public O getIdentityOfResolvedObject() {
		return this.matchedValue;
	}

	@Override
	public Boolean resolved() {
		return this.matchedValue != null;
	}

	@Override
	public MatchCriteria matchCriteria() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void setIdentityOfResolvedObject(O identity) {
		this.matchedValue = identity;
	}
}
