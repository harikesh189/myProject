package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class ItemRecordAwareEntity<R extends ReferenceableDomainEntity<R, V>, V>
		extends ReferenceableDomainEntity<R, V> implements ItemRecordAware {

	private static final long serialVersionUID = 4952034420317809333L;

	protected ItemRecordAwareEntity(String identity) {
		super(identity);

	}

	protected ItemRecordAwareEntity() {
	}

	protected ItemRecordAwareEntity(String identity, String externald) {
		super(identity, externald);
	}

	public ItemRecordAwareEntity(Long id, String identity, String externalId) {
		super(id, identity, externalId);

	}

	public ItemRecordAwareEntity(Long id, String identity) {
		super(id, identity);
	}

	@Override
	public String getItemRecordId() {
		return itemRecordId;
	}

	@Column(name = "item_record_id")
	@Access(AccessType.FIELD)
	private String itemRecordId;

	@Override
	public void setItemRecordId(String itemRecordId) {
		this.itemRecordId = itemRecordId;
	}
}
