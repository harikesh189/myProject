package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

public interface Persistable extends Serializable {

}
