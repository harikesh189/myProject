package com.hcentive.billing.core.commons.domain;

import java.math.BigDecimal;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.SheduleAmountType;
import com.hcentive.billing.core.commons.vo.Amount;

@Entity
@Table(name = "recurring_amount")
public class RecurringAmount extends BaseEntity {

	private static final long serialVersionUID = -5667737959281635106L;

	@Column(name = "recurring_amount_type")
	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	private SheduleAmountType type;

	/*
	 * @Type(type = "amount")
	 * 
	 * @Columns(columns = { @Column(name = "recurring_amount_value"),
	 * @Column(name = "recurring_amount_name"),
	 * 
	 * @Column(name = "recurring_amount_symbol"), @Column(name =
	 * "recurring_amount_short_name") })
	 */
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "recurring_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "recurring_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "recurring_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "recurring_amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	public Amount getAmount() {
		return amount;
	}

	protected RecurringAmount() {

	}

	public RecurringAmount(final SheduleAmountType type) {
		this.type = type;
	}

	public SheduleAmountType getType() {
		return type;
	}

	public void setType(SheduleAmountType type) {
		this.type = type;
	}

	public void setAmount(Amount amount) {
		if (amount == null || amount.isNegativeOrZero()) {
			throw new IllegalAccessError(
					"Rcurring setup amunt can not be ngative");
		}
		this.amount = amount;
	}

	public Amount getAmount(InvoiceSummary invoiceSummary) {
		Amount payableAmount = invoiceSummary.getInvoice().getPayableAmount();
		switch (this.type) {
		case INVOICE_AMOUNT:
			return payableAmount;
		case FLAT_AMOUNT:
			return this.getAmount();
		case MINIMUM_AMOUNT_DUE:
			return invoiceSummary.getInvoice().getMinimumPayableAmount();
		case CURRENT_OUTSTANDING: {
			Amount amountPaid = invoiceSummary.getAmountPaid().add(
					invoiceSummary.getDiscount());
			BigDecimal balance = payableAmount.getValue().subtract(
					amountPaid.getValue());

			return balance.compareTo(BigDecimal.ZERO) <= 0 ? new Amount(0)
					: new Amount(balance);
		}

		default:
			return new Amount(0);
		}
	}

}
