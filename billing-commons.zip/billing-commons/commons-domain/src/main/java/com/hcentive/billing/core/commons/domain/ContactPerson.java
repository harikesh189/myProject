package com.hcentive.billing.core.commons.domain;

import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.domain.enumtype.Category;
import com.hcentive.billing.core.commons.domain.enumtype.ContactPersonType;

@Entity
@DiscriminatorValue("ContactEntity")
public class ContactPerson extends Contact {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4127566345644412868L;

	@OneToOne(cascade = CascadeType.ALL, targetEntity = Profile.class)
	@JoinColumn(name = "profile_id")
	@Access(AccessType.FIELD)
	private PersonalProfile profile;

	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	private ContactPersonType type;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "contact_entity_additional_info", joinColumns = @JoinColumn(name = "id"))
	@Column(name = "add_info_value")
	@MapKeyColumn(name = "add_info_key")
	@Access(AccessType.FIELD)
	private Map<String, String> additionalInfo;

	/*
	 * protected ContactPerson(PersonalProfile profile, Type type, cate) {
	 * super(Ca); this.profile = profile; this.type = type;
	 * 
	 * }
	 */

	protected ContactPerson(PersonalProfile profile, ContactPersonType type) {
		super(Category.OTHER);
		this.profile = profile;
		this.type = type;
	}

	public ContactPerson() {
		// TODO Auto-generated constructor stub
	}

	public PersonalProfile getProfile() {
		return profile;
	}

	public void setProfile(PersonalProfile profile) {
		this.profile = profile;
	}

	public ContactPersonType getType() {
		return type;
	}

	public void setType(ContactPersonType type) {
		this.type = type;
	}

	public Map<String, String> getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(Map<String, String> additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public static ContactPerson createInstance(final PersonalProfile profile,
			final ContactPersonType type) {
		return new ContactPerson(profile, type);
	}

	public static ContactPerson createInstance(final PersonalProfile profile) {

		return new ContactPerson(profile, ContactPersonType.GENERAL_CONTACT);
	}

}
