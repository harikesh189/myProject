package com.hcentive.billing.core.commons.event;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.dto.UserOperation;
import com.hcentive.billing.core.commons.vo.DateTime;

public class UserUpdatePayLoad implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8046414225100014078L;
	String userIdentity;
	com.hcentive.billing.core.commons.dto.UserOperation userOperation;
	Object oldEntity;
	Object newEntity;
	private final DateTime dateTime = new DateTime();
	private final User user;

	public User getUser() {
		return user;
	}

	public UserUpdatePayLoad(User user) {
		this.user = user;
	}

	public String getUserIdentity() {
		return userIdentity;
	}

	public void setUserIdentity(String userIdentity) {
		this.userIdentity = userIdentity;
	}

	public UserOperation getUserOperation() {
		return userOperation;
	}

	public void setUserOperation(UserOperation userOperation) {
		this.userOperation = userOperation;
	}

	public Object getOldEntity() {
		return oldEntity;
	}

	public void setOldEntity(Object oldEntity) {
		this.oldEntity = oldEntity;
	}

	public Object getNewEntity() {
		return newEntity;
	}

	public void setNewEntity(Object newEntity) {
		this.newEntity = newEntity;
	}

	public DateTime getDateTime() {
		return dateTime;
	}
}
