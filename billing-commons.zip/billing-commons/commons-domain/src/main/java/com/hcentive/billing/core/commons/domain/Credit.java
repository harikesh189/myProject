package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.InvoiceItemType;
import com.hcentive.billing.core.commons.vo.Amount;

/**
 * 
 * @author Gaurav.Agarwal1
 * 
 */
@Entity
@Table(name = "invoice_item")
@DiscriminatorValue("Credit")
public class Credit extends InvoiceItem {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5516037078856467146L;

	protected Credit(Amount amount, boolean isDebt, String description,
			String label, String reference, InvoiceItemType type) {
		super(amount, isDebt, description, label, reference, type);
	}

	protected Credit() {
	}

}
