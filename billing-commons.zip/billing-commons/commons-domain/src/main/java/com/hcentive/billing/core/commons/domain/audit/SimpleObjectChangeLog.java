package com.hcentive.billing.core.commons.domain.audit;

import java.io.Serializable;


public class SimpleObjectChangeLog<T extends Serializable> extends SimpleActivityLog<T> implements ObjectChangeLog<T> {

	private static final long serialVersionUID = 1L;

	private String objectIdentity;
	
	private String objectExternalId;
	
	private long objectVersion;
	
	@SuppressWarnings("unused")
	private SimpleObjectChangeLog() {
		// For ORMs
	}
	
	public SimpleObjectChangeLog(String category) {
		super(category);
	}
	
	public String getObjectIdentity() {
		return objectIdentity;
	}

	public void setObjectIdentity(String objectIdentity) {
		this.objectIdentity = objectIdentity;
	}

	public String getObjectExternalId() {
		return objectExternalId;
	}

	public void setObjectExternalId(String objectExternalId) {
		this.objectExternalId = objectExternalId;
	}

	public long getObjectVersion() {
		return objectVersion;
	}

	public void setObjectVersion(long objectVersion) {
		this.objectVersion = objectVersion;
	}

	@Override
	public String objectIdentity() {
		return getObjectIdentity();
	}

	@Override
	public String objectExternalId() {
		return getObjectExternalId();
	}

	@Override
	public long objectVersion() {
		return getObjectVersion();
	}
	
}
