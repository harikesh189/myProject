package com.hcentive.billing.core.commons.domain;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;

@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_event_history")
public class EventHistory extends AbstractMongoEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3335792663746266170L;
	private String eventName;
	private String serviceName;
	private String serviceInstanceId;
	private String originServiceName;
	private String originServiceInstanceId;
	
	
	public EventHistory(String eventName, String serviceName, String serviceInstanceId, String originServiceName, String originServiceInstanceId) {
		this.eventName = eventName;
		this.serviceName = serviceName;
		this.serviceInstanceId = serviceInstanceId;
		this.originServiceName = originServiceName;
		this.originServiceInstanceId = originServiceInstanceId;
	}


	public String getEventName() {
		return eventName;
	}


	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	public String getServiceName() {
		return serviceName;
	}


	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


	public String getServiceInstanceId() {
		return serviceInstanceId;
	}


	public void setServiceInstanceId(String serviceInstanceId) {
		this.serviceInstanceId = serviceInstanceId;
	}


	public String getOriginServiceName() {
		return originServiceName;
	}


	public void setOriginServiceName(String originServiceName) {
		this.originServiceName = originServiceName;
	}


	public String getOriginServiceInstanceId() {
		return originServiceInstanceId;
	}


	public void setOriginServiceInstanceId(String originServiceInstanceId) {
		this.originServiceInstanceId = originServiceInstanceId;
	}
	

}
