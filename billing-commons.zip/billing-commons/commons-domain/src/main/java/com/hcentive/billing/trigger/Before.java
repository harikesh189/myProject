/**
 * 
 */
package com.hcentive.billing.trigger;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
public class Before extends AbstractTrigger {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 339313149262495326L;

	public Before(){
		super();
	}

	@Override
	public String name() {
		return "BEFORE";
	}

	@Override
	public DateTime operate(DateTime applyOnValue) {
		return applyOnValue.minusDays(getNoOfDays());
	}

}
