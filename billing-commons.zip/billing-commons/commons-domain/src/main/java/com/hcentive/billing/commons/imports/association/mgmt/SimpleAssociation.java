package com.hcentive.billing.commons.imports.association.mgmt;

public class SimpleAssociation<O> extends Association<O> {
	protected SimpleAssociation() {

	}

	public SimpleAssociation(final O associatedItemIdentity,
			final AssociationDefinition definition) {
		super(definition, associatedItemIdentity);
	}
}
