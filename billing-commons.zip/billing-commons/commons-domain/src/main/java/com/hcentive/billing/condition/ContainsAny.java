package com.hcentive.billing.condition;

import static com.hcentive.billing.core.commons.util.CollectionUtil.nullSafe;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class ContainsAny<T> extends SimpleCondition<T> {

	private static final long serialVersionUID = 1L;

	public ContainsAny() {
		super();
	}

	public ContainsAny(final String name, final T value) {
		super(name, value);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected boolean eval(final T input) {

		Collection<T> valueCollection = null;
		Collection<T> inputCollection = null;
		if (Collection.class.isAssignableFrom(this.getValue().getClass())) {
			valueCollection = (Collection<T>) this.getValue();
		} else {
			valueCollection = new ArrayList<T>();
			valueCollection.add(this.getValue());
		}
		if (Collection.class.isAssignableFrom(input.getClass())) {
			inputCollection = (Collection<T>) input;
			return !(nullSafe(inputCollection)).isEmpty()
					&& !Collections.disjoint(nullSafe(valueCollection), nullSafe(inputCollection));
		} else {
			inputCollection = new ArrayList<T>();
			inputCollection.add(input);
			return !(nullSafe(inputCollection)).isEmpty()
					&& !Collections.disjoint(nullSafe(valueCollection), nullSafe(inputCollection));
		}
	}

}
