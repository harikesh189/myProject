package com.hcentive.billing.core.commons.domain;

public class BusinessTransaction extends BaseEntity {

	public BusinessTransaction(Long id) {
		// TODO Auto-generated constructor stub
	}

}
