package com.hcentive.billing.core.commons.domain.converter;

import org.springframework.data.mongodb.core.MongoTemplate;

import com.hcentive.billing.core.commons.domain.DocumentEntity;

public interface MongoFacade {
	public Object saveObject(final Object object);

	public <T extends DocumentEntity> T findByIdentity(final String identity,
			final Class<T> type);

	public MongoTemplate getMongoTemmplate();
}
