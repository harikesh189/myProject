package com.hcentive.billing.commons.imports.association.mgmt;

import java.io.Serializable;

import com.hcentive.billing.core.commons.util.RandomGenerator;

public abstract class AbstractAssociationDefinition<O> implements
		AssociationDefinition<O>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3027724518841574755L;
	public AssociationType associationType;
	
	public void setAssociationType(AssociationType associationType) {
		this.associationType = associationType;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	private Boolean mandatory = false;

	private String id;

	public AbstractAssociationDefinition(AssociationType associationType,
			final Boolean mandatory) {
		super();
		this.associationType = associationType;
		this.mandatory = mandatory;
		this.id = RandomGenerator.randomString();
	}

	protected AbstractAssociationDefinition() {

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj instanceof AbstractAssociationDefinition) {
			final AbstractAssociationDefinition that = (AbstractAssociationDefinition) obj;
			if (this.id != null && that.id != null) {
				return this.id.equals(that.id);
			}
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.id == null ? super.hashCode() : this.id.hashCode();
	}

	public String id() {
		return this.id;
	}

	@Override
	public Boolean isMandatory() {
		return this.mandatory;
	}

	@Override
	public AssociationType getAssociationType() {
		return this.associationType;
	}
}
