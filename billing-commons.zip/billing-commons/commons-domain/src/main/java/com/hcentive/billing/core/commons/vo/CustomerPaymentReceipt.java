package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Profile;

public class CustomerPaymentReceipt implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5482160508594857522L;

	private String paymentReceiptIdentity;
	private BusinessEntity<Profile> customer;
	private Amount amount;
	private String status;
	private String transectionID;

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransectionID() {
		return transectionID;
	}

	public void setTransectionID(String transectionID) {
		this.transectionID = transectionID;
	}

	public CustomerPaymentReceipt() {

	}

	public String getPaymentReceiptIdentity() {
		return paymentReceiptIdentity;
	}

	public void setPaymentReceiptIdentity(String paymentReceiptIdentity) {
		this.paymentReceiptIdentity = paymentReceiptIdentity;
	}

	public BusinessEntity<Profile> getCustomer() {
		return customer;
	}

	public void setCustomer(BusinessEntity<Profile> customer) {
		this.customer = customer;
	}
}
