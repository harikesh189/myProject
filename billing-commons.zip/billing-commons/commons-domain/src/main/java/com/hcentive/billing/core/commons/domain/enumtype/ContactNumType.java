package com.hcentive.billing.core.commons.domain.enumtype;

public enum ContactNumType {
	LANDLINE, MOBILE, FAX;
}