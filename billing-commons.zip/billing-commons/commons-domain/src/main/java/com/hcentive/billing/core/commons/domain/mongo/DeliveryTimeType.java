package com.hcentive.billing.core.commons.domain.mongo;


public enum DeliveryTimeType{

	REALTIME,BATCH;
}
