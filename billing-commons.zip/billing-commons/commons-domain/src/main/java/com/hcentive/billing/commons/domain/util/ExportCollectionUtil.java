package com.hcentive.billing.commons.domain.util;

import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class ExportCollectionUtil {
	
	public static final String EXPORT_COLLECTION_NAME = "EXPORT_COLLECTION_NAME";
	public static final String DELIMITER = "_";

	public static enum ExportCollections {
	
		REMITPAYMENTRECEIPT("EXPORT_REMIT_PAYMENT_RECEIPT"), EXPORT_REMIT_PAYMENT_RECEIPT("REMITPAYMENTRECEIPT"),
		ONETIMEPAYMENT("EXPORT_ONE_TIME_PAYMENT"),
		INVOICE("EXPORT_INVOICE"), 
		DELINQUENCYCHECKPOINT("EXPORT_DELINQUENCY_CHECKPOINT"),
		FINANCIALSUMMARY("EXPORT_FINANCIAL_SUMMARY");
		
		private String collectionName;
		
		private ExportCollections(String collectionName) {
			this.collectionName = collectionName;
		}
		
		public String getCollectionName() {
			ProcessContext.get().getMetaData().put(EXPORT_COLLECTION_NAME, collectionName);
			return collectionName;
		}
	}
	
	public static String getCollectionNameForItem() {
		StringBuilder builder = new StringBuilder(TenantUtil.getTenantId());
		builder.append(DELIMITER).append(ProcessContext.get().getMetaData().get(EXPORT_COLLECTION_NAME));
		return builder.toString();
	}

	/*public static void main(String[] args) {
		System.out.println(ExportCollections.valueOf("REMITPAYMENTRECEIPT").getCollectionName());
		System.out.println(ExportCollections.valueOf("REMITPAYMENTRECEIPT").getCollectionName());
		System.out.println(ExportCollections.valueOf("ONETIMEPAYMENT").getCollectionName());
		System.out.println(ExportCollections.valueOf("INVOICE").getCollectionName());
		System.out.println(ExportCollections.valueOf("DELINQUENCYCHECKPOINT").getCollectionName());
		System.out.println(ExportCollections.valueOf("FINANCIALSUMMARY").getCollectionName());
	}*/
}
