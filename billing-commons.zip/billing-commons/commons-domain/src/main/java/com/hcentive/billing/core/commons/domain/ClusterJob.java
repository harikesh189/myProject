package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "cluster_job_execution")
public class ClusterJob extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9087659816263140967L;

	public static enum Status {
		ACTIVE, INACTIVE
	}

	public ClusterJob() {

	}

	public ClusterJob(String identity, String jobName, DateTime expirationTime,
			String macAddress) {
		this.expirationDate = expirationTime;
		this.jobName = jobName;
		this.identity = identity;
		this.macAddress = macAddress;
		this.status = Status.ACTIVE.toString();
	}

	@Column(name = "identity")
	@Access(AccessType.FIELD)
	private String identity;

	@Column(name = "job_name")
	@Access(AccessType.FIELD)
	private String jobName;

	@Column(name = "mac_address")
	@Access(AccessType.FIELD)
	private String macAddress;

	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "expiration_date", updatable = false)) })
	private DateTime expirationDate;

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public DateTime getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(DateTime expirationDate) {
		this.expirationDate = expirationDate;
	}

}
