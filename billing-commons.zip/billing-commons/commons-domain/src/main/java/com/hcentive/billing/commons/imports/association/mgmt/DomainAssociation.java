/**
 * 
 */
package com.hcentive.billing.commons.imports.association.mgmt;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

/**
 * @author Dikshit.Vaid
 * @param <RDE>
 * 
 */
public class DomainAssociation<RDE extends ReferenceableDomainEntity> extends
		Association<RDE> {

	protected DomainAssociation() {

	}

	public DomainAssociation(RDE associatedObject,
			AssociationDefinition definition) {
		super(definition, associatedObject);
		init();
	}

	protected void init() {
		if (associatedObject != null) {
			associationDefinition().setIdentityOfResolvedObject(
					this.associatedObject.getIdentity());
		}
	}

}
