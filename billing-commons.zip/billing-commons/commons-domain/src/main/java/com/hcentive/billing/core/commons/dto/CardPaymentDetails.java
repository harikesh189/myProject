package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.domain.CardDetail;
import com.hcentive.billing.core.commons.vo.Amount;

public class CardPaymentDetails extends BasicPaymentDetails<CardDetail> {

	public CardPaymentDetails(Amount amount, String cutomerId, CardDetail card) {
		super(amount);
		this.setPaymentInstrument(card);
	}

	public CardPaymentDetails() {

	}

	public CardDetail getCard() {
		return getPaymentInstrument();
	}

	public void setCard(final CardDetail card) {
		setPaymentInstrument(card);
	}
}
