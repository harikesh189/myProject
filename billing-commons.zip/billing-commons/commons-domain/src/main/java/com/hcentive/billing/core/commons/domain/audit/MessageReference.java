package com.hcentive.billing.core.commons.domain.audit;

import java.util.HashMap;
import java.util.Map;

public class MessageReference<T> implements AuditMessage {

	private static final long serialVersionUID = 1L;

	private T messageId;
	
	private Map<String, String> arguments;

	public MessageReference(T messageId) {
		this.messageId = messageId;
		this.arguments = new HashMap<String, String>();
	}
	
	public T getMessageId() {
		return messageId;
	}

	public void setMessageId(T messageId) {
		this.messageId = messageId;
	}

	public Map<String, String> getArguments() {
		return arguments;
	}

	public void setArguments(Map<String, String> messageArguments) {
		this.arguments = messageArguments;
	}
	
}
