/**
 * 
 */
package com.hcentive.billing.trigger;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
public class After extends AbstractTrigger {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 688919328723148138L;

	public After(){
		super();
	}
	/*public After(String applyOn){
		super(applyOn);
	}

	public After(String applyOn, int noOfDays) {
		super(applyOn, noOfDays);
	}*/

	@Override
	public String name() {
		return "AFTER";
	}

	@Override
	public DateTime operate(DateTime applyOnValue) {
		return applyOnValue.plusDays(getNoOfDays());
	}

}
