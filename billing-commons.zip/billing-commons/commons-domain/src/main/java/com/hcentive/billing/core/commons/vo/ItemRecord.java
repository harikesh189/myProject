package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_autoPayment")
public class ItemRecord implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1089070836673998775L;

	private AutoPaymentDto item;
	private String id;

	public ItemRecord(AutoPaymentDto item, String id) {
		super();
		this.item = item;
		this.id = id;
	}

	public AutoPaymentDto getItem() {
		return item;
	}

	public void setItem(AutoPaymentDto item) {
		this.item = item;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
