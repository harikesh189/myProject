package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CardDetailExpirationDate implements Serializable {

	@Column(name = "expiration_year")
	@Access(AccessType.FIELD)
	private int expirationYear;

	@Column(name = "expiration_month")
	@Access(AccessType.FIELD)
	private int expirationMonth;

	public int getExpirationYear() {
		return expirationYear;
	}

	public void setExpirationYear(int expirationYear) {
		this.expirationYear = expirationYear;
	}

	public int getExpirationMonth() {
		return expirationMonth;
	}

	public void setExpirationMonth(int expirationMonth) {
		this.expirationMonth = expirationMonth;
	}
}
