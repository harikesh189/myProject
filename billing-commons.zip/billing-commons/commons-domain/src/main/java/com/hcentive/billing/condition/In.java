package com.hcentive.billing.condition;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;
import static com.hcentive.billing.core.commons.util.CollectionUtil.nullSafe;

import java.util.Collection;

public class In<T> extends SimpleCondition<Collection<T>> {

	private static final long serialVersionUID = 1L;

	public In() {
		super();
	}

	public In(final String name, final Collection<T> values) {
		super(name, nullSafe(values));
	}

	public In(final String name, final T... values) {
		super(name, asList(values));
	}

	@Override
	protected boolean eval(final Collection<T> input) {
		
		return !(nullSafe(input)).isEmpty() && nullSafe(this.getValue()).containsAll(nullSafe(input));
	}
}

