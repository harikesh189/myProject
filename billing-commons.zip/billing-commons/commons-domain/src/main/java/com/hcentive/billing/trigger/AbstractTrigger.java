/**
 * 
 */
package com.hcentive.billing.trigger;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
public abstract class AbstractTrigger implements Trigger, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2048336088355075965L;
	private String applyOn;
	private int noOfDays;
	private String displayDesc;
	
	public AbstractTrigger() {
	}
	
	public abstract DateTime operate(DateTime applyOnValue);

	public abstract String name();

	public String getApplyOn() {
		return applyOn;
	}

	public void setApplyOn(String applyOn) {
		this.applyOn = applyOn;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public String getDisplayDesc() {
		return displayDesc;
	}

	public void setDisplayDesc(String displayDesc) {
		this.displayDesc = displayDesc;
	}

}
