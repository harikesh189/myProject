/**
 * 
 */
package com.hcentive.billing.core.commons.domain.mongo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.condition.And;
import com.hcentive.billing.condition.Condition;
import com.hcentive.billing.condition.Eq;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.trigger.Trigger;

/**
 * @author Dikshit.Vaid
 *
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_notification_rule")
public class NotificationRule extends AbstractMongoEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -65767573489306388L;

	@NotNull
	@Size(min = 1)
	protected String description;

	@NotNull
	protected String name;

	// @NotNull
	protected Period period;

	private Condition matchingCondition;

	@NotNull
	private NotificationEvent notificationEvent;

	private List<BusinessReason> businessReasons;

	private List<NotificationTemplate> notificationTemplates;

	private Trigger notificationTrigger;

	public NotificationRule() {
		if (this.identity == null || this.identity.trim().length() == 0) {
			this.identity = RandomGenerator.randomString();
		}
	}

	public NotificationRule(String identity, String name, String description, Period period,
			Condition matchingCondition, NotificationEvent notificationEvent, List<BusinessReason> businessReasons,
			List<NotificationTemplate> notificationTemplates) {
		this.identity = identity;
		this.name = name;
		this.description = description;
		this.period = period;
		this.matchingCondition = matchingCondition;
		this.notificationEvent = notificationEvent;
		this.businessReasons = businessReasons;
		this.notificationTemplates = notificationTemplates;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Period getPeriod() {
		return period;
	}

	public void setPeriod(Period period) {
		this.period = period;
	}

	public Condition getMatchingCondition() {
		return matchingCondition;
	}

	public void setMatchingCondition(Condition matchingCondition) {
		this.matchingCondition = matchingCondition;
	}

	public void setNotificationTrigger(Trigger notificationTrigger) {
		this.notificationTrigger = notificationTrigger;
	}

	public Trigger getNotificationTrigger() {
		return notificationTrigger;
	}

	public NotificationEvent getNotificationEvent() {
		return notificationEvent;
	}

	public void setNotificationEvent(NotificationEvent notificationEvent) {
		this.notificationEvent = notificationEvent;
	}

	public List<BusinessReason> getBusinessReasons() {
		return null == businessReasons ? new ArrayList<BusinessReason>() : businessReasons;
	}

	public void setBusinessReasons(List<BusinessReason> businessReasons) {
		this.businessReasons = businessReasons;
	}

	public List<NotificationTemplate> getNotificationTemplates() {
		return notificationTemplates;
	}

	public void setNotificationTemplates(List<NotificationTemplate> notificationTemplates) {
		this.notificationTemplates = notificationTemplates;
	}

	public static void main(String... args) throws JsonGenerationException, JsonMappingException, IOException {
		Period period = new Period(new Date(), new Date());
		Condition matchingCondition = new And(Arrays.asList(new Eq<String>("asdf", "asdf"),
				new Eq<String>("asdf", "asdf"), new Eq<String>("asdf", "asdf"), new Eq<String>("asdf", "asdf")));
		List<NotificationTemplate> notificationTemplates = new ArrayList<NotificationTemplate>(2);
		NotificationTemplate template1 = new NotificationTemplate("asdf", "asdfasdf", DeliveryType.EMAIL, "asdfasdf");
		notificationTemplates.add(template1);

		NotificationTemplate template2 = new NotificationTemplate("asdf", "asdfasdf", DeliveryType.EMAIL, "asdfasdf");
		notificationTemplates.add(template2);
		NotificationEvent notificationEvent = new NotificationEvent("association",
				NotificationEventCategory.DELINQUENCY, "ass description");

		NotificationRule rule = new NotificationRule("asdf", "name", "description", period, matchingCondition,
				notificationEvent, null, notificationTemplates);

		ObjectMapper mapper = new ObjectMapper();

		mapper.writerWithDefaultPrettyPrinter().writeValue(System.out, rule);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("NotificationRule [description=");
		builder.append(description);
		builder.append(", name=");
		builder.append(name);
		builder.append(", period=");
		builder.append(period);
		builder.append(", matchingCondition=");
		builder.append(matchingCondition);
		builder.append(", notificationEvent=");
		builder.append(notificationEvent);
		builder.append(", businessReasons=");
		builder.append(businessReasons);
		builder.append(", notificationTemplates=");
		builder.append(notificationTemplates);
		builder.append(", notificationTrigger=");
		builder.append(notificationTrigger);
		builder.append(", dateCreated=");
		builder.append(dateCreated);
		builder.append(", id=");
		builder.append(id);
		builder.append(", identity=");
		builder.append(identity);
		builder.append(", externalId=");
		builder.append(externalId);
		builder.append(", lastModified=");
		builder.append(lastModified);
		builder.append(", lastModifiedBy=");
		builder.append(lastModifiedBy);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append("]");
		return builder.toString();
	}

}
