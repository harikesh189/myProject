/**
 * 
 */
package com.hcentive.billing.trigger;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({ @Type(value = Equal.class, name = "EQUAL"),
		@Type(value = After.class, name = "AFTER"),
		@Type(value = Before.class, name = "BEFORE") })
public interface Trigger {

	DateTime operate(DateTime applyOnValue);

	String name();
	
	String getDisplayDesc();
}
