package com.hcentive.billing.core.commons.domain;

public class UserProfile extends BaseEntity {

	public UserProfile(Long id) {
		// TODO Auto-generated constructor stub
	}

}
