package com.hcentive.billing.core.commons.domain.enumtype;

/**
 * 
 * @author Gaurav.Agarwal1
 * 
 */
public enum Status {

	SUCCESS, FAILED, INITIATED,ACTIVE,INACTIVE;

}
