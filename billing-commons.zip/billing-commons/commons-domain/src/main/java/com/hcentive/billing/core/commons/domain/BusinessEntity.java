package com.hcentive.billing.core.commons.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.hcentive.billing.core.commons.api.Notifiable;
import com.hcentive.billing.core.commons.domain.Profile.ProfileChangeListener;
import com.hcentive.billing.core.commons.domain.enumtype.BEStatus;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "business_entity")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "business_entity_type")
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "business_entity_type")
@JsonSubTypes({ @JsonSubTypes.Type(value = Customer.class, name = "Customer"), @JsonSubTypes.Type(value = Broker.class, name = "Broker"),
        @JsonSubTypes.Type(value = Exchange.class, name = "Exchange"), @JsonSubTypes.Type(value = HealthPlanProvider.class, name = "HealthPlanProvider"),
        @JsonSubTypes.Type(value = BenefitVendor.class, name = "BenefitVendor"),
        @JsonSubTypes.Type(value = Observer.class, name = "Observer"), @JsonSubTypes.Type(value = SubsidyProvider.class, name = "SubsidyProvider"),
        @JsonSubTypes.Type(value = SuspenseEntity.class, name = "SuspenseEntity	") ,
        @JsonSubTypes.Type(value = Facilitator.class, name = "Facilitator"),
        @JsonSubTypes.Type(value = GenericFinancialPartner.class, name = "GenericFinancialPartner"), })
public abstract class BusinessEntity<P extends Profile> extends ItemRecordAwareEntity<BusinessEntity<P>, String> implements Notifiable,
		ManagedEntity<String, String, BusinessEntity<P>>, ProfileChangeListener {

	private static final long serialVersionUID = -6077806895368859629L;
	
	public static final String COLUMN_BE_TYPE = "type";
	public static final String FIELD_BE_TYPE = "type";
	
	public static final String COLUMN_PROFILE_ID = "profile_id";
	public static final String FIELD_PROFILE_ID = "profileId";

	public static final String COLUMN_BE_DISCRIMATOR = "business_entity_type";
	
	public static final String FIELD_BILLABLE="billable";
	public static final String COLUMN_BILLABLE="billable";
	
	public static final String FIELD_PROFILE_DISPLAY_NAME = "profileDisplayName";
	public static final String COLUMN_PROFILE_DISPLAY_NAME = "profile_display_name";

	public static final String PAPER_ONLY = "01";
	public static final String PAPER_LESS_ONLY="10";
	public static final String PAPER_AND_PAPER_LESS="11";

	@Transient
	private Long profileId;
	
	@Transient
	public Long profileId(){
		return this.profileId;
	}

	@Access(AccessType.FIELD)
	@Column(name = "profile_display_name")
	private String profileDisplayName;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "misc_info_set_id")
	private MiscInfoSet additionalInfoSet;

	@Access(AccessType.FIELD)
	private boolean billable = false;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "effective_date")) })
	private DateTime effectiveDate;

	@Access(AccessType.FIELD)
	@Column(name = "external_id_qualifier")
	private String externalIdQualifier;

	@Access(AccessType.FIELD)
	private boolean invoiceable = false;

	/*
	 * 01 - paper only 10 - ebill only 11 - ebill and paper both
	 */

	@Column(name = "billing_preferences")
	@Access(AccessType.FIELD)
	private String billingPreferences;

	@OneToOne(cascade = CascadeType.ALL, targetEntity = Profile.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "profile_id")
	private P profile;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private BEStatus status;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "termination_date")) })
	private DateTime terminationDate;

	@Column(nullable = false, name = "type")
	private String type;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "business_entity_identifier", joinColumns = @JoinColumn(name = "be_id"), inverseJoinColumns = @JoinColumn(name = "identifier_id"))
	private List<IdentifierCode> identifiers = new ArrayList<>();
	

	public void setIdentifiers(List<IdentifierCode> identifiers) {
		this.identifiers = identifiers;
	}

	protected BusinessEntity() {
	}

	protected BusinessEntity(final Long id, final String identity) {
		super(id, identity);
	}

	protected BusinessEntity(final Long id, final String identity, final String externalId) {
		super(id, identity, externalId);
	}

	protected BusinessEntity(final String identity) {
		super(identity);
	}

	protected BusinessEntity(final String identity, final String externalId) {
		super(identity, externalId);
	}

	public BusinessEntity(final String identity, final String externalId, final String type) {
		super(identity, externalId);
		this.type = type;
	}

	public MiscInfoSet getAdditionalInfoSet() {
		return this.additionalInfoSet;
	}

	@Override
	public Address getAddress() {
		Address address = null;

		if (this.getProfile() != null) {
			final ContactSet<Address> addresses = this.getProfile().getAddressess();
			/*
			 * Ajay: Introduced null pointer check, because it was failing in JSON deserialization in case addresses was null.
			 */
			if (null == addresses) {
				return null;
			}
			address = addresses.primaryContact();
			if (address == null && addresses.contacts() != null && addresses.contacts().size() > 0) {
				return addresses.contacts().iterator().next();
			}
		}
		return address;
	}

	public String getBusinessEntityType() {

		return this.getClass().getSimpleName();
	}

	public DateTime getEffectiveDate() {
		return this.effectiveDate;
	}

	public String getExternalIdQualifier() {
		return this.externalIdQualifier;
	}

	@Access(AccessType.PROPERTY)
	public P getProfile() {
		return this.profile;
	}

	public BEStatus getStatus() {
		return this.status;
	}

	public DateTime getTerminationDate() {
		return this.terminationDate;
	}

	@Override
	public String getType() {
		return this.type;
	}
	
	public boolean isExpired(){
		if(this.terminationDate==null || new DateTime().isBefore(this.terminationDate)){
			return false;
		}
		return true;
	}

	public boolean isBillable() {
		return this.billable;
	}

	public boolean isInvoiceable() {
		return this.invoiceable;
	}

	@Override
	public String refValue() {
		return this.getExternalId();
	}

	public void setAdditionalInfoSet(final MiscInfoSet additionalInfoSet) {
		this.additionalInfoSet = additionalInfoSet;
	}

	public void setBillable(final boolean billable) {
		this.billable = billable;
	}

	public void setEffectiveDate(final DateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public void setExternalIdQualifier(final String externalIdQualifier) {
		this.externalIdQualifier = externalIdQualifier;
	}

	public void setInvoiceable(final boolean invoiceable) {
		this.invoiceable = invoiceable;
	}

	public void setProfile(final P profile) {
		this.profile = profile;
		if (profile != null) {
			this.profile.addListener(this);
		}
	}

	public void setStatus(final BEStatus status) {
		this.status = status;
	}

	public void setTerminationDate(final DateTime terminationDate) {
		this.terminationDate = terminationDate;
	}

	public void setType(final String type) {
		this.type = type;
	}

	public String getBillingPreferences() {
		return billingPreferences;
	}

	public void setBillingPreferences(String billingPreferences) {
		this.billingPreferences = billingPreferences;
	}

	public void profileUpdated(final Profile profile) {
		this.profileDisplayName = profile.getDisplayName();
	}

	public String profileDisplayName() {
		return profileDisplayName;
	}

	public List<IdentifierCode> getIdentifiers() {
		return Collections.unmodifiableList(identifiers);
	}
	
	public IdentifierCode getIdentifier(IdentifierCode.Type type) {
		IdentifierCode identifierCodeResult = null;
		if(this.identifiers != null && !this.identifiers.isEmpty()) {
			for (IdentifierCode identifierCode : identifiers) {
				if (type.name().equalsIgnoreCase(identifierCode.getType().name())) {
					identifierCodeResult = identifierCode;
					break;
				}
			}
		}
		return identifierCodeResult;
	}

	public void addIdentifier(IdentifierCode identifier) {
		this.identifiers.add(identifier);
	}
	
	/*public void addAllIdentifiers(List<IdentifierCode> identifiers) {
		this.identifiers.addAll(identifiers);
	}*/
}