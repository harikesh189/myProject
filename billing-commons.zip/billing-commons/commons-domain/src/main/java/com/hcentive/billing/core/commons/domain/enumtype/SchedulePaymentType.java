package com.hcentive.billing.core.commons.domain.enumtype;

public enum SchedulePaymentType {
	ONETIMEPAYMENTSETUP("oneTimePaymentSetup", "ONETIMEPAYMENTSETUP"), RECURRINGSETUP(
			"recurringSetup", "RECURRINGSETUP");

	private String name;

	private String value;

	private SchedulePaymentType(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}

}
