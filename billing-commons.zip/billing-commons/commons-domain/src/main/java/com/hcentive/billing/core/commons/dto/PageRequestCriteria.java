package com.hcentive.billing.core.commons.dto;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

public class PageRequestCriteria implements Serializable {

	private static final long serialVersionUID = 8173573141399225067L;

	private int pageIndex;
	private int size;
	@Deprecated
	private Direction sortDirection;
	@Deprecated
	private String sortedColumn;

	@Deprecated
	private String sortingOrder;

	private List<Order> sortOrders = new LinkedList<>();

	public PageRequestCriteria() {
		this.pageIndex = 0;
		this.size = 10;
	}

	public void addSortOrders(final Direction direction, final String property) {
		this.sortOrders.add(new Order(direction, property));
	}

	public void addSortOrders(final Order sortOrder) {
		this.sortOrders.add(sortOrder);
	}

	public void addSortOrders(final String property) {
		this.sortOrders.add(new Order(property));
	}

	public int getPageIndex() {
		return this.pageIndex;
	}

	public int getSize() {
		return this.size;
	}

	@Deprecated
	public Direction getSortDirection() {
		return this.sortDirection;
	}

	@Deprecated
	public String getSortedColumn() {
		return this.sortedColumn;
	}

	@Deprecated
	public String getSortingOrder() {
		return this.sortingOrder;
	}

	public List<Order> getSortOrders() {
		return this.sortOrders;
	}

	public void setPageIndex(final int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public void setSize(final int size) {
		this.size = size;
	}

	@Deprecated
	public void setSortDirection(final Direction sortDirection) {
		this.sortDirection = sortDirection;
	}

	@Deprecated
	public void setSortedColumn(final String sortedColumn) {
		this.sortedColumn = sortedColumn;
	}

	@Deprecated
	public void setSortingDirection(final Direction sortingOrder) {
		this.sortDirection = sortingOrder != null ? sortingOrder : Direction.ASC;
		this.sortingOrder = this.sortDirection.name();
	}

	@Deprecated
	public void setSortingOrder(final String sortingOrder) {
		this.sortingOrder = sortingOrder;
		final Direction defaultSortDirection = (null != sortingOrder && sortingOrder.trim().length() > 0) ? Direction.valueOf(sortingOrder.toUpperCase()) : Direction.ASC;
		this.sortDirection = defaultSortDirection != null ? defaultSortDirection : Direction.ASC;
	}

	public void setSortOrders(final List<Order> sortOrders) {
		if (sortOrders != null) {
			this.sortOrders = sortOrders;
		}
	}

}
