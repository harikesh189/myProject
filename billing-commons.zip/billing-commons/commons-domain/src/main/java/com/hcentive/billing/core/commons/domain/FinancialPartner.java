package com.hcentive.billing.core.commons.domain;

import javax.persistence.Entity;

@Entity
public abstract class FinancialPartner<P extends Profile> extends Partner<P> {

	private static final long serialVersionUID = -1757160084870374764L;

	@Override
	public String typeName() {
		return "FinancialPartner";
	}

	public FinancialPartner(String identity) {
		super(identity);
	}

	protected FinancialPartner() {
	}

	public FinancialPartner(String identity, String externalId, String type) {
		super(identity, externalId, type);
	}

}
