package com.hcentive.billing.core.commons.dto;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.enumtype.SchedulePaymentType;

public class SchedulePayment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private TokenPaymentDetails tokenPaymentDetails;

	private ScheduleType scheduleType;

	private AmountSetUp amountType;

	private SchedulePaymentType schedulePaymentType;

	private Map<String, String> additonalInfo;

	private String startDate;

	private String endDate;

	public static String SUBSCRIPTIONID = "subscriptionId";

	@JsonIgnore
	public String getSubscriptionId() {
		return this.getAdditonalInfo()!=null? this.getAdditonalInfo().get(SUBSCRIPTIONID):null;
	}

	public TokenPaymentDetails getTokenPaymentDetails() {
		return tokenPaymentDetails;
	}

	public void setTokenPaymentDetails(TokenPaymentDetails tokenPaymentDetails) {
		this.tokenPaymentDetails = tokenPaymentDetails;
	}

	public ScheduleType getScheduleType() {
		return scheduleType;
	}

	public void setScheduleType(ScheduleType scheduleType) {
		this.scheduleType = scheduleType;
	}

	public AmountSetUp getAmountType() {
		return amountType;
	}

	public void setAmountType(AmountSetUp amountType) {
		this.amountType = amountType;
	}

	public SchedulePaymentType getSchedulePaymentType() {
		return schedulePaymentType;
	}

	public void setSchedulePaymentType(SchedulePaymentType schedulePaymentType) {
		this.schedulePaymentType = schedulePaymentType;
	}

	public Map<String, String> getAdditonalInfo() {
		return additonalInfo;
	}

	public void setAdditonalInfo(Map<String, String> additonalInfo) {
		this.additonalInfo = additonalInfo;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/*
	 * public static void main(String[] args) throws JsonGenerationException,
	 * JsonMappingException, IOException {
	 * 
	 * SchedulePayment user = new SchedulePayment();
	 * 
	 * TokenPaymentDetails token = new TokenPaymentDetails();
	 * token.setTokenId("1234"); user.setTokenPaymentDetails(token);
	 * 
	 * ScheduleType scheduleType = new ScheduleType();
	 * scheduleType.setSchedulerType(SchedulerType.LASTDAYOFMONTH);
	 * 
	 * user.setScheduleType(scheduleType);
	 * 
	 * user.setEndDate(new Date()); user.setStartDate(new Date());
	 * 
	 * user.setSubscriptionId("1");
	 * 
	 * user.setSchedulePaymentType(SchedulePaymentType.ONETIMEPAYMENTSETUP);
	 * 
	 * AmountSetUp amountSetUp = new AmountSetUp();
	 * amountSetUp.setRecurringAmountType(SheduleAmountType.FLAT_AMOUNT);
	 * amountSetUp.setFlatAmount(new Amount(45));
	 * 
	 * user.setAmountType(amountSetUp);
	 * 
	 * Map<String,String> map = new HashMap<String,String>();
	 * 
	 * map.put("SUBSCRIPTIONID", "1");
	 * 
	 * user.setAdditonalInfo(map);
	 * 
	 * List arr = new ArrayList();
	 * 
	 * arr.add(user);
	 * 
	 * 
	 * ObjectMapper mapper = new ObjectMapper(); mapper.writeValue(new
	 * File("C:\\Billing\\user.json"), arr);
	 * 
	 * 
	 * 
	 * 
	 * }
	 */

}
