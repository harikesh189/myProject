package com.hcentive.billing.core.commons.domain;

public interface ItemRecordAware {

	String getItemRecordId();

	void setItemRecordId(String id);

}
