package com.hcentive.billing.core.commons.domain.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.vo.Amount;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

public class AmountWriteConverter implements Converter<Amount, DBObject>{

	Logger LOGGER = LoggerFactory.getLogger(AmountWriteConverter.class);
	
	@Override
	public DBObject convert(Amount source) {
		DBObject dbo = null;
		if(source != null) { 
			ObjectMapper objectMapper =new ObjectMapper();
			try {
				dbo = (DBObject) JSON.parse(objectMapper.writeValueAsString(source));
				if( dbo !=null ){
					if(dbo.get("value") !=null && source.getValue() != null){
						dbo.put("value", source.getValue().doubleValue());
					}else{
						dbo.put("amount", null);
					}
					dbo.put("_class", Amount.class.getName());
				}
				return dbo;
			} catch (Exception e) {
				LOGGER.error("Error while converting amount before saving it to mongo, ", e);
			}
		}
		return null;
	}

}
