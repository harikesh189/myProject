package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "pay_check")
@DiscriminatorValue("Check")
public class PayCheck extends PaymentMethod implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 89693842445765798L;

	@Column(name = "bank_name")
	@Access(AccessType.FIELD)
	private String bankName;

	@Transient
	private String routingNumber;

	@Column(name = "account_number")
	@Access(AccessType.FIELD)
	private String accountNumber;

	@Column(name = "check_number")
	@Access(AccessType.FIELD)
	private String checkNumber;

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getRoutingNumber() {
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public PayCheck() {
		setIdentifier("Check");
	}

	public static PayCheck newPayCheck() {
		return new PayCheck();
	}

	@Override
	public String getReferenceNumber() {
		return getAccountNumber();
	}

}
