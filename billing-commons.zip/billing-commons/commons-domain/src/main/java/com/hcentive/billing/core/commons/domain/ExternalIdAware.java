package com.hcentive.billing.core.commons.domain;

public interface ExternalIdAware {
	String getExternalId();

	void setExternalId(String externalId);
}
