package com.hcentive.billing.core.commons.domain;

import org.springframework.data.repository.query.parser.Part;

public enum PartyQualifier {
SUBSCRIBER("Subscriber"), RESPONSIBLE_ENTITY("ResponsibleEntity"),USER_ACCOUNT("UserAccount"),BROKER("BROKER"),OTHER("Other"),
GROUP("Group"), INDIVIDUAL("Individual"),CUSTOMER("Customer"), HEALTH_PLAN_PROVIDER("HealthPlanProvider"), EXCHANGE("Exchange"),SUBSIDY_PROVIDER("SubsidyProvider");

private PartyQualifier(String val) {
	this.value=val;
}
private final String value;
public String getValue() {
	return this.value;
}
public static PartyQualifier getQualifier(String qualifier) {
	for (PartyQualifier qualifier2 : PartyQualifier.values()) {
		if(qualifier2.getValue().equalsIgnoreCase(qualifier)){
			return qualifier2;
		}
		
	}
	return null;
}


}
