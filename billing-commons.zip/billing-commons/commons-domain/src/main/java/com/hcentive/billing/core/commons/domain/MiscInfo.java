package com.hcentive.billing.core.commons.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "misc_info")
public class MiscInfo extends BaseEntity {

	private static final long serialVersionUID = -3282489234166307658L;

	private String name;

	private String value;

	private String qualifier;

	private String description;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getQualifier() {
		return qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
