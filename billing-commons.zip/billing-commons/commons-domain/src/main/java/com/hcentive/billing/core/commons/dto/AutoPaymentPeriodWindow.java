package com.hcentive.billing.core.commons.dto;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

public class AutoPaymentPeriodWindow implements Serializable {

	public void setRecurringSetupId(String paymentScheduleId) {
		this.paymentScheduleId = paymentScheduleId;
	}

	public void setBeginsOn(DateTime beginsOn) {
		this.beginsOn = beginsOn;
	}

	public void setEndsOn(DateTime endsOn) {
		this.endsOn = endsOn;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String paymentScheduleId;

	private DateTime beginsOn;
	private DateTime endsOn;
	private String paymentRefId;

	public String getPaymentRefId() {
		return paymentRefId;
	}

	public void setPaymentRefId(String paymentRefId) {
		this.paymentRefId = paymentRefId;
	}

	public AutoPaymentPeriodWindow(String recurringSetupId, DateTime beginsOn,
			DateTime endsOn) {
		super();
		this.paymentScheduleId = recurringSetupId;
		this.beginsOn = beginsOn;
		this.endsOn = endsOn;
	}

	public AutoPaymentPeriodWindow() {

	}

	public String getPaymentScheduleId() {
		return paymentScheduleId;
	}

	public DateTime getBeginsOn() {
		return beginsOn;
	}

	public DateTime getEndsOn() {
		return endsOn;
	}
}
