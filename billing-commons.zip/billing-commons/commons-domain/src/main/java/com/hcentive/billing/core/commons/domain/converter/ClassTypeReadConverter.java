package com.hcentive.billing.core.commons.domain.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

import com.mongodb.BasicDBObject;

@SuppressWarnings("rawtypes")
public class ClassTypeReadConverter implements Converter<BasicDBObject, Class> {

	private static final Logger logger = LoggerFactory.getLogger(ClassTypeReadConverter.class);

	@Override
	public Class convert(final BasicDBObject source) {
		logger.trace("Inside ClassTypeReadConverter start");
		final String className = (String) source.get("className");
		try {
			return Class.forName(className);
		} catch (final Throwable e) {
			logger.error("Error while converting::", e);
		}
		return null;
	}

}
