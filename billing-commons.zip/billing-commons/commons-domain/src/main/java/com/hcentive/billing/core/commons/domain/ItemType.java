package com.hcentive.billing.core.commons.domain;

public enum ItemType {

	APTC("APTC"), PRIOR_DUE("PRIOR-DUE"), FEE("FEE"), ADJUSTMENT("ADJUSTMENT"), CREDIT(
			"CREDIT"), DISCOUNT("DISCOUNT"), OTHER("OTHER"), PREMIUM("PREMIUM"), TAX(
			"TAX"), OUTSTANDING_ACCOUNT_BALANCE("OUTSTANDING-ACCOUNT-BALANCE"), RETRO(
			"RETRO"), PAYMENT("PAYMENT");
	private final String value;

	ItemType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static ItemType fromValue(String v) {
		for (ItemType c : ItemType.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

}
