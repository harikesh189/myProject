package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.converter.ClassToStringType;
import com.hcentive.billing.core.commons.domain.converter.GenericTypeToStringType;
import com.hcentive.billing.core.commons.domain.enumtype.ReferenceCategory;

/**
 * @param <I> type of the referenceId
 * @param <R> type of the object being referenced
 * @param <V> type of the value if, any that the object being referenced wants to provide as additional information.
 */
@Entity(name = "Reference")
@Table
public final class Reference<I, R extends Referenceable, V> extends BaseEntity implements Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1719610491783682932L;

	@Column(name = "ref_category")
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private ReferenceCategory category;

	@Column(name = "reference_id")
	@Access(AccessType.FIELD)
	@Convert(converter = GenericTypeToStringType.class)
	private I referenceId;

	@Column(name = "ref_type")
	@Access(AccessType.FIELD)
	private ReferenceType refType;

	@Access(AccessType.FIELD)
	@Column(name = "ref_value")
	@Convert(converter = GenericTypeToStringType.class)
	private V refValue;

	@Column(name = "source")
	@Access(AccessType.FIELD)
	private String source;

	@Column(name = "type")
	@Access(AccessType.FIELD)
	@Convert(converter = ClassToStringType.class)
	private Class type;

	@Column(name = "type_name")
	@Access(AccessType.FIELD)
	private String typeName;

	@Column(name = "version")
	@Access(AccessType.FIELD)
	private final long version;

	public Reference() {
		this.version = 1;
		this.category = ReferenceCategory.ALIAS;
	}

	private Reference(final I referenceId, final Class<R> type, final String typeName, final ReferenceType refType, final V refValue, final long version,
			final String source, final ReferenceCategory referenceCategory) {
		super();
		this.referenceId = referenceId;
		this.type = type;
		this.typeName = typeName;
		this.refType = refType;
		this.refValue = refValue;
		this.version = version;
		this.source = source;
		this.category = referenceCategory;
	}

	@Override
	public Reference clone() {
		final Reference reference = new Reference(this.referenceId, this.type, this.typeName, this.refType, this.refValue, this.version, this.source,
				ReferenceCategory.RELATED_ITEM);
		reference.setCategory(this.category);
		return reference;
	}

	@Override
	public boolean equals(final Object obj) {
		if (obj != null && obj instanceof Reference) {
			final Reference<I, R, V> that = (Reference<I, R, V>) obj;
			if (this.refType.equals(ReferenceType.EXTERNAL)) {
				return this.referenceId.equals(that.referenceId) && this.source.equals(that.source) && this.typeName.equals(that.typeName)
						&& this.category.equals(that.category);
			} else {
				return this.type.equals(that.type) && this.referenceId.equals(that.referenceId);
			}
		}
		return false;
	}

	public ReferenceCategory getCategory() {
		return this.category;
	}

	public I getReferenceId() {
		return this.referenceId;
	}

	public ReferenceType getRefType() {
		return this.refType;
	}

	public V getRefValue() {
		return this.refValue;
	}

	public String getSource() {
		return this.source;
	}

	public Class<R> getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}

	public long getVersion() {
		return this.version;
	}

	@Override
	public int hashCode() {
		return this.referenceId.hashCode();
	}

	public void setCategory(final ReferenceCategory category) {
		this.category = category;
	}

	public R toObject() {
		return ReferenceEntityProviderConfiguration.refEntityProvider.toObject(this);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <I, V> Reference newExternalReference(final I refId, final String typeName, final V refValue, final String source) {
		return new Reference(refId, null, typeName, ReferenceType.EXTERNAL, refValue, 1, source, ReferenceCategory.ALIAS);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <I, V, R extends Referenceable<I, V, R>> Reference<I, R, V> newInternalReference(final R referenceable) {
		return new Reference(referenceable.referenceId(), referenceable.getClass(), referenceable.typeName(), ReferenceType.INTERNAL, referenceable.refValue(),
				referenceable.version(), "SYSTEM", ReferenceCategory.RELATED_ITEM);
	}

	public static interface ReferenceEntityProvider {
		public <I, V, R extends Referenceable> ReferenceType getType(final R referenceable);

		public <I, V, R extends Referenceable> R toObject(Reference<I, R, V> reference);
	}

	public static final class ReferenceEntityProviderConfiguration {
		private static ReferenceEntityProvider refEntityProvider;

		public static void set(final ReferenceEntityProvider newRefEntityProvider) {
			refEntityProvider = newRefEntityProvider;
		}
	}

	public static enum ReferenceType {
		EXTERNAL, INTERNAL;
	}
}
