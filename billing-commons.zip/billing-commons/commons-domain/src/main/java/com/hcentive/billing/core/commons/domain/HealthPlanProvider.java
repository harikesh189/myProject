package com.hcentive.billing.core.commons.domain;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.MarketIndicator;

@Entity
@Table(name = "business_entity")
@DiscriminatorValue("HealthPlanProvider")
public class HealthPlanProvider extends FinancialPartner<OrgProfile> {

	private static final long serialVersionUID = 6854255479458395575L;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Access(AccessType.FIELD)
	@PrimaryKeyJoinColumn
	@JoinTable(name = "health_plan_provider_products", joinColumns = @JoinColumn(name = "business_entity_id"), inverseJoinColumns = @JoinColumn(name = "products_id"))
	private Set<HealthPlanProduct> products = new HashSet<HealthPlanProduct>();

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "be_supported_market_types", joinColumns = @JoinColumn(name = "be_id"))
	@Column(name = "supported_market_type")
	@Enumerated(value = EnumType.STRING)
	private List<MarketIndicator> supportedMarketTypes = new ArrayList<MarketIndicator>();

	@Access(AccessType.FIELD)
	@Column(name = "carrier_id")
	private String carrierId;
	
	public HealthPlanProvider(String identity) {
		super(identity);
	}

	protected HealthPlanProvider() {
		super();
	}

	public HealthPlanProvider(String identity, String externalID, String type) {
		super(identity, externalID, type);
	}

	@Override
	public OrgProfile getProfile() {
		return super.getProfile();
	}

	@Override
	public void setProfile(OrgProfile orgProfile) {
		super.setProfile(orgProfile);
	}

	@Override
	public String typeName() {
		return "HealthPlanProvider";
	}

	public Set<HealthPlanProduct> getProducts() {
		return products;
	}

	public void setProducts(Set<HealthPlanProduct> products) {
		this.products = products;
	}

	public List<MarketIndicator> getSupportedMarketTypes() {
		return supportedMarketTypes;
	}

	public void setSupportedMarketTypes(
			List<MarketIndicator> supportedMarketTypes) {
		this.supportedMarketTypes = supportedMarketTypes;
	}

	public String getCarrierId() {
		return carrierId;
	}
	
	public void setCarrierId(String carrierId) {
		this.carrierId = carrierId;
	}

	public boolean addSupportedMarketType(MarketIndicator marketType) {
		return this.supportedMarketTypes.add(marketType);
	}
}
