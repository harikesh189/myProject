package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.InvoiceItemType;
import com.hcentive.billing.core.commons.vo.Amount;


@Entity
@Table(name = "invoice_item")
@DiscriminatorValue("TAX")
public class Tax   extends InvoiceItem{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2048505496277286619L;
	
	public Tax() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected Tax(Amount amount, boolean isDebt, String description,
			String label, String reference, InvoiceItemType type) {
		super(amount, isDebt, description, label, reference, type);
	}

}
