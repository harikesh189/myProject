package com.hcentive.billing.condition;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("unchecked")
public abstract class SimpleCondition<T> extends BaseCondition implements Condition {
	private static Logger logger = LoggerFactory.getLogger(SimpleCondition.class);
	private static final long serialVersionUID = 1L;

	private T value;

	protected SimpleCondition() {
		super(null);
		this.setValue(null);
	}

	protected SimpleCondition(final String name, final T value) {
		super(name);
		this.setValue(value);
	}

	protected abstract boolean eval(T value);

	@Override
	public boolean evaluate(final ConditionContextResolver conditionValueResolver) {
		logger.trace("Evaluating {} condition start", this.toString());
		final Object valueToEval = this.getValueToEval(conditionValueResolver);
		final boolean result = this.eval((T) valueToEval);
		logger.debug("Evaluation result for condition {} with {} is {}", this.getName(), valueToEval, result);
		return result;
	}

	@Override
	public boolean evaluate(final Map<String, ?> inputValueMap) {
		logger.debug("Evaluating {} condition start", this.toString());
		final Object valueToEval = this.getValueToEval(inputValueMap);
		final boolean result = this.eval((T) valueToEval);
		logger.debug("Evaluation result for condition {}={} with {} is {}", this.getName(), this.getValue(), valueToEval, result);
		return result;
	}

	public T getValue() {
		return this.value;
	}

	public void setValue(final T value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "( " + this.getName() + " )";
	}
}
