package com.hcentive.billing.condition;

public interface ConditionContextResolverAware {
	ConditionContextResolver getConditionContextResolver();
}
