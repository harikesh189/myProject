package com.hcentive.billing.core.commons.domain.enumtype;

public enum TransactionType {
	Credit, Debit;
}