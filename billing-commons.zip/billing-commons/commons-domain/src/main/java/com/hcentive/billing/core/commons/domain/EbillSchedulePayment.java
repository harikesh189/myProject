package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.api.BusinessEntityAware;
import com.hcentive.billing.core.commons.api.SubscriptionAware;
import com.hcentive.billing.core.commons.domain.enumtype.SchedulePaymentType;

@Entity
@Table(name = "schedule_payment")
public class EbillSchedulePayment extends
		ReferenceableDomainEntity<EbillSchedulePayment, String> implements
		BusinessEntityAware<BusinessEntity>, SubscriptionAware {

	private static final long serialVersionUID = 6943681873477732105L;
	public static final String PAYMENT_TYPE="type";

	public EbillSchedulePayment() {

	}

	public EbillSchedulePayment(String identity) {
		super(identity);
	}

	// ///////////////////////////////////////////////////////////////////////////
	/*
	 * @Column(name = "dayBeforeDueDate")
	 * 
	 * @Access(AccessType.FIELD) private Integer dayBeforeDueDate;
	 * 
	 * 
	 * 
	 * public Integer getDayBeforeDueDate() { return dayBeforeDueDate; }
	 * 
	 * public void setDayBeforeDueDate(Integer dayBeforeDueDate) {
	 * this.dayBeforeDueDate = dayBeforeDueDate; }
	 */
	// //////////////////////////////////////////////////////////////////////////////////////
	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status;

	@ManyToOne(targetEntity = BusinessEntity.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "business_id")
	@Access(AccessType.FIELD)
	private BusinessEntity<Profile> savedFor;

	@OneToOne(targetEntity = EbillPaymentMethod.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "payment_method_id", updatable = false)
	@Access(AccessType.FIELD)
	private EbillPaymentMethod paymentInstrument;

	@OneToOne(targetEntity = SchedulePaymentAmount.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "schedule_payment_amount_id")
	@Access(AccessType.FIELD)
	private SchedulePaymentAmount schedulePaymentAmount;

	@Column(name = "frequency_type")
	@Access(AccessType.FIELD)
	private String frequencyType;

	@Column(name = "frequency_value")
	@Access(AccessType.FIELD)
	private String frequencyValue;

	@Column(name = "type")
	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	private SchedulePaymentType type;

	@Column(name = "payment_reference_id")
	@Access(AccessType.FIELD)
	private String paymentReferenceId;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period paymentWindowPeriod;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "startDate.date", column = @Column(name = "start_date")),
			@AttributeOverride(name = "endDate.date", column = @Column(name = "end_date")) })
	@Access(AccessType.FIELD)
	private SchedulePaymentWindowPeriod schedulePaymentWindowPeriod;

	@ManyToOne(targetEntity = EbillSubscription.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "subscription_id")
	@Access(AccessType.FIELD)
	private EbillSubscription subscription;
	
	public EbillSubscription getSubscription() {
		return subscription;
	}

	public void setSubscription(EbillSubscription subscription) {
		this.subscription = subscription;
	}

	
	public Period getPaymentWindowPeriod() {
		return paymentWindowPeriod;
	}

	public void setPaymentWindowPeriod(Period paymentWindowPeriod) {
		this.paymentWindowPeriod = paymentWindowPeriod;
	}

	public SchedulePaymentWindowPeriod getSchedulePaymentWindowPeriod() {
		return schedulePaymentWindowPeriod;
	}

	public void setSchedulePaymentWindowPeriod(
			SchedulePaymentWindowPeriod schedulePaymentWindowPeriod) {
		this.schedulePaymentWindowPeriod = schedulePaymentWindowPeriod;
	}

	public BusinessEntity<Profile> getSavedFor() {
		return savedFor;
	}

	public void setSavedFor(BusinessEntity<Profile> savedFor) {
		this.savedFor = savedFor;
		if (this.paymentInstrument != null)
			this.paymentInstrument.setSavedFor(savedFor);
	}

	public EbillPaymentMethod getPaymentInstrument() {
		return paymentInstrument;
	}

	public void setPaymentInstrument(EbillPaymentMethod paymentInstrument) {
		this.paymentInstrument = paymentInstrument;
	}

	@Override
	public String typeName() {
		return "Saved Recurring Setup";
	}

	@Override
	public void setOperator(final Operator operator) {
		super.setOperator(operator);
		if (this.getPaymentInstrument() != null) {
			this.getPaymentInstrument().setOperator(operator);
		}
	}

	@Override
	public String refValue() {
		return identity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public SchedulePaymentAmount getSchedulePaymentAmount() {
		return schedulePaymentAmount;
	}

	public void setSchedulePaymentAmount(
			SchedulePaymentAmount schedulePaymentAmount) {
		this.schedulePaymentAmount = schedulePaymentAmount;
	}

	public String getPaymentReferenceId() {
		return paymentReferenceId;
	}

	public void setPaymentReferenceId(String paymentReferenceId) {
		this.paymentReferenceId = paymentReferenceId;
	}

	public String getFrequencyType() {
		return frequencyType;
	}

	public void setFrequencyType(String frequencyType) {
		this.frequencyType = frequencyType;
	}

	public String getFrequencyValue() {
		return frequencyValue;
	}

	public void setFrequencyValue(String frequencyValue) {
		this.frequencyValue = frequencyValue;
	}

	public void setFrequencyValue(int frequencyValue) {
		this.frequencyValue = String.valueOf(frequencyValue);
	}

	/*
	 * @Override public void setBusinessEntity(BusinessEntity businessEntity) {
	 * // TODO Auto-generated method stub
	 * 
	 * }
	 */

	public SchedulePaymentType getType() {
		return type;
	}

	public void setType(SchedulePaymentType type) {
		this.type = type;
	}

	@Override
	public void setBusinessEntity(BusinessEntity businessEntity) {
		this.setSavedFor(businessEntity);

	}
}
