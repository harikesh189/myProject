package com.hcentive.billing.core.commons.domain;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "business_entity")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public abstract class Partner<P extends Profile> extends BusinessEntity<P> {

	private static final long serialVersionUID = 5787217769159554567L;

	// Used to store classification value of partner. Child of Partner class
	// can have different values for this classification e.g. Exchange (type of
	// Facilitator) can be classified as PRIVATE or PUBLIC.
	private String classification;

	public P getProfile() {
		return super.getProfile();
	}

	public void setProfile(P profile) {
		super.setProfile(profile);
	}

	public Partner(Long id, String identity) {
		super(id, identity);
	}

	public Partner(Long id, String identity, String externalId) {
		super(id, identity, externalId);
		// super(id, identity);
	}

	public Partner(String identity) {
		super(identity);
	}

	protected Partner() {
	}

	public Partner(String identity, String externalId, String type) {
		super(identity, externalId, type);
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	@Override
	public String refValue() {
		//if (null != getProfile()) {
		return super.refValue();
		/*} else {
			return null;
		}*/

	}

	// @Override
	// public String typeName() {
	// return "Partner";
	// }

}
