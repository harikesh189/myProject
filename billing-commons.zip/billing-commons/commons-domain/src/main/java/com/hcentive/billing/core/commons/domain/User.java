package com.hcentive.billing.core.commons.domain;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

@Entity
@Table(name = "wfm_user")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "User_type")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class User extends DomainEntity implements TenantAware {

	private static final long serialVersionUID = 6896752585738103954L;

	@Column(name = "activation_code")
	@Access(AccessType.FIELD)
	protected String activationCode;

	@Access(AccessType.FIELD)
	@ManyToMany(fetch = FetchType.EAGER)
	@PrimaryKeyJoinColumn
	@JoinTable(name = "wfm_user_roles", joinColumns = { @JoinColumn(name = "wfm_user_id") }, inverseJoinColumns = { @JoinColumn(name = "roles_id") })
	protected Set<Role> roles = new HashSet<Role>(0);

	@Column(name = "is_deleted")
	@Access(AccessType.FIELD)
	private boolean isDeleted = false;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "profile_id")
	@Access(AccessType.FIELD)
	private PersonalProfile profile;

	@Column(name = "status")
	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	private UserStatus status;

	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;
	
	@Column(name = "user_type", insertable = false, updatable = false , nullable = false)
	@Access(AccessType.FIELD)
	private String userType;
	
	
	
	public void setUserType(String userType) {
		this.userType = userType;
	}

	public User(final String identity, final PersonalProfile profile,
			final Role... roles) {
		this(identity, profile, Arrays.asList(roles));
	}

	public User(final String identity, final PersonalProfile profile,
			final Collection<Role> roles) {
		super(identity);
		this.profile = profile;
		this.roles = new HashSet<>();
		this.roles.addAll(roles);
		this.tenantId = TenantUtil.getTenantId();
	}

	public User(final String identity, final String externalId,
			final PersonalProfile profile, final Collection<Role> roles,
			final UserStatus status) {
		super(identity, externalId);
		this.profile = profile;
		this.roles = new HashSet<>();
		this.roles.addAll(roles);
		this.tenantId = TenantUtil.getTenantId();
		this.status = status;
	}

	public User() {

	}

	protected User(final Long id, final String identity) {
		this(identity, null);
	}

	protected User(final String identity) {
		this(identity, null);
	}

	public String getActivationCode() {
		return activationCode;
	}

	public PersonalProfile getProfile() {
		return profile;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public UserStatus getStatus() {
		return status;
	}

	@Override
	public String getTenantId() {
		return this.tenantId;
	}

	public boolean isActive() {
		if (UserStatus.ACTIVE.equals(status)) {
			return true;
		}
		return false;
	}

	public boolean isDeleted() {
		return this.isDeleted;
	}

	public void markDelete() {
		this.setDeleted(true);
	}

	public Collection<Permission> permissions() {
		final Collection<Permission> permissions = new HashSet<Permission>();
		for (final Role r : this.roles) {
			permissions.addAll(r.getPermissions());
		}
		return permissions;
	}

	public void setActivationCode(String activationcode) {
		this.activationCode = activationcode;
	}

	public void setDeleted(final boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public void setProfile(PersonalProfile profile) {
		this.profile = profile;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public String getUserType() {
		return this.userType;
	}

}
