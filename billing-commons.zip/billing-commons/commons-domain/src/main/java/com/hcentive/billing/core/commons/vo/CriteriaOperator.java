package com.hcentive.billing.core.commons.vo;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;
import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.util.Collection;

public enum CriteriaOperator {

	EQUALS("="), NOTEQUALS("<>"), IN("IN"), NOTIN("NOT IN"), LIKE("LIKE"), LESSTHENEQUAL("<="), LESSTHEN("<"), GREATERTHENEQUAL(">="), 
	GREATERTHEN(">"), NOTNULL("IS NOT NULL") ,NULL("IS  NULL"), BETWEEN("BETWEEN");
	private String value;

	private CriteriaOperator(final String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

	public static CriteriaOperator getOperator(final String value) {
		switch (value.toUpperCase()) {
		case "=":
			return EQUALS;
		case "<>":
			return NOTEQUALS;
		case "IN":
			return IN;
		case "NOT IN":
			return NOTIN;
		case "LIKE":
			return LIKE;
		case "LESSTHENEQUAL":
			return LESSTHENEQUAL;
		case "LESSTHEN":
			return LESSTHEN;
		case "GREATERTHENEQUAL":
			return GREATERTHENEQUAL;
		case "GREATERTHEN":
			return GREATERTHEN;
		case "BETWEEN":
			return BETWEEN;
			
		default:
			return null;
		}
	}

	public boolean in(final CriteriaOperator... operators) {
		return isNotEmpty(operators) && asList(operators).contains(this);
	}

	public boolean in(final Collection<String> operators) {
		if (isNotEmpty(operators)) {
			for (final String operationStr : operators) {
				final CriteriaOperator operator = getOperator(operationStr);
				if (operator != null && operator.equals(this)) {
					return true;
				}
			}
		}
		return false;
	}

}
