package com.hcentive.billing.core.commons.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

@Entity
@Table(name = "role")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class Role extends DomainEntity implements TenantAware {

	/**
	 *
	 */
	private static final long serialVersionUID = 840388914480195556L;

	public Role(String identity) {
		super(identity);
	}

	public Role() {

	}

	@Column(name = "role_type")
	@Access(AccessType.FIELD)
	 @Enumerated(EnumType.STRING)
	private RoleType roleType ;
	
	
	public void setStatus(RoleStatus status) {
		this.status = status;
	}

	@Column(name = "name")
	@Access(AccessType.FIELD)
	private String name;

	@Column(name = "description")
	@Access(AccessType.FIELD)
	private String description;

	@Column(name = "code")
	@Access(AccessType.FIELD)
	private String code;

	@Column(name = "tenant_id", insertable = false, updatable = false)
	@Access(AccessType.FIELD)
	private String tenantId;
	
	@Column(name = "status")
	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	private RoleStatus status;
	
	@Column(name = "is_default")
	@Access(AccessType.FIELD)
	private boolean isDefault = false;
	
	public boolean isDefault() {
		return this.isDefault;
	}
	
	
	public void setDefault(boolean isDefault){
		this.isDefault = isDefault;
	}
	
	public void markDefault() {
		this.setDefault(true);
	}
	
	public RoleStatus getStatus() {
		return status;
	}
	
	public boolean isActive() {
		if (RoleStatus.ACTIVE.equals(this.status)) {
			return true;
		}
		return false;
	}

	
	public enum RoleStatus {

		ACTIVE, INACTIVE

	}


	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	@Column(name = "user_type")
	@Access(AccessType.FIELD)
	private String userType;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "role_permissions", joinColumns = { @JoinColumn(name = "role_id") }, inverseJoinColumns = { @JoinColumn(name = "permissions_id") })
	private Set<Permission> permissions = new HashSet<Permission>(0);

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Set<Permission> getPermissions() {
		return permissions;
	}

	public void setPermissions(Set<Permission> permissions) {
		this.permissions = permissions;
	}

	@Override
	public String getTenantId() {
		return this.tenantId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public RoleType getRoleType() {
		return roleType;
	}

	public void setRoleType(RoleType roleType) {
		this.roleType = roleType;
	}

	public void load() {
		this.getTenantId();
	}
	
	
}
