package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "docref")
public class DocumentRef extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1072320440007830593L;

	@Column(name = "external_url")
	@Access(AccessType.FIELD)
	private String externalURL;

	@Column(name = "doc_ref_id")
	@Access(AccessType.FIELD)
	private String docRefId;

	@Column(name = "dms_key")
	@Access(AccessType.FIELD)
	private String dmsKey;

	public String getExternalURL() {
		return externalURL;
	}

	public void setExternalURL(String externalURL) {
		this.externalURL = externalURL;
	}

	public String getDocRefId() {
		return docRefId;
	}

	public void setDocRefId(String docRefId) {
		this.docRefId = docRefId;
	}

	public String getDmsKey() {
		return dmsKey;
	}

	public void setDmsKey(String dmsKey) {
		this.dmsKey = dmsKey;
	}

}
