package com.hcentive.billing.core.commons.dto;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;

public class PageableRequest implements Pageable {

	private int pageNumber;

	private int pageSize;

	private List<Order> sortOrders = new LinkedList<>();

	public PageableRequest() {

	}

	public PageableRequest(final int pageNumber, final int pageSize, final List<Order> sortOrders) {
		super();
		this.pageNumber = pageNumber;
		this.pageSize = pageSize;
		if (isNotEmpty(sortOrders)) {
			this.sortOrders = sortOrders;
		}
	}

	public PageableRequest(final int pageNumber, final int pageSize, final Sort sort) {
		super();
		this.pageNumber = pageNumber;
		this.pageSize = pageSize;
		this.sortOrders = this.getSortOrders(sort);
	}

	public void addSortOrder(final Order sortOrders) {
		this.sortOrders.add(sortOrders);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}

		if (!(obj instanceof PageRequest)) {
			return false;
		}

		final PageRequest that = (PageRequest) obj;

		final boolean sortEqual = this.getSort() == null ? that.getSort() == null : this.getSort().equals(that.getSort());

		return super.equals(that) && sortEqual;
	}

	@Override
	public Pageable first() {
		return new PageableRequest(0, this.getPageSize(), this.getSort());
	}

	@Override
	public int getOffset() {
		return this.getPageNumber() * this.getPageSize();
	}

	@Override
	public int getPageNumber() {
		return this.pageNumber;
	}

	@Override
	public int getPageSize() {
		return this.pageSize;
	}

	@Override
	public Sort getSort() {
		return isNotEmpty(this.getSortOrders()) ? new Sort(this.getSortOrders()) : null;
	}

	public List<Order> getSortOrders() {
		return this.sortOrders;
	}

	@Override
	public int hashCode() {
		return 31 * super.hashCode() + (null == this.getSort() ? 0 : this.getSort().hashCode());
	}

	@Override
	public boolean hasPrevious() {
		return this.getPageNumber() > 0;
	}

	@Override
	public Pageable next() {
		return new PageableRequest(this.getPageNumber() + 1, this.getPageSize(), this.getSortOrders());
	}

	public Pageable previous() {
		return this.getPageNumber() == 0 ? this : new PageableRequest(this.getPageNumber() - 1, this.getPageSize(), this.getSortOrders());
	}

	@Override
	public Pageable previousOrFirst() {
		return this.hasPrevious() ? this.previous() : this.first();
	}

	public void setPageNumber(final int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public void setPageSize(final int pageSize) {
		this.pageSize = pageSize;
	}

	public void setSortOrders(final List<Order> sortOrders) {
		this.sortOrders = sortOrders;
	}

	private List<Order> getSortOrders(final Sort sort) {
		final List<Order> result = new LinkedList<>();
		if (sort != null) {
			Iterator<Order> iterator = sort.iterator();
			while (iterator.hasNext()) {
				final Order element = iterator.next();
				result.add(element);
			}
		}
		return result;
	}

}
