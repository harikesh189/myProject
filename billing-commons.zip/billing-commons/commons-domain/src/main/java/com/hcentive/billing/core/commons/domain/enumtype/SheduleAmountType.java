package com.hcentive.billing.core.commons.domain.enumtype;

public enum SheduleAmountType {
	INVOICE_AMOUNT("INVOICE_AMOUNT"), FLAT_AMOUNT("FLAT_AMOUNT"), MINIMUM_AMOUNT_DUE("MINIMUM_AMOUNT_DUE"), CURRENT_OUTSTANDING("CURRENT_OUTSTANDING");
	
	private final String value;
	SheduleAmountType(String type){
		this.value=type;
	}
	
	public String value(){
		return this.value;
	}
	public String getValue() {
		return this.value;
	}
	
}