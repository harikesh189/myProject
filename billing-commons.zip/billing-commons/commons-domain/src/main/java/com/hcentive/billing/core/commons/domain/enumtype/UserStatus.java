package com.hcentive.billing.core.commons.domain.enumtype;

/**
 * Enum for User status.
 * 
 * @author ajay.saxena
 * 
 */
public enum UserStatus {
	
	

	ACTIVE("ACTIVE"), INACTIVE("INACTIVE");
	
	private String status;
	
	
	private UserStatus(String status){
		this.status = status;
	}

	
	public static UserStatus parse(String val){
		for (UserStatus userStatus : UserStatus.values()) {
			if(userStatus.status.equalsIgnoreCase(val)){
				return userStatus;
			}
		}
		return null;
	}
	
	public String getStatus(){
		return this.status;
	}
}

