package com.hcentive.billing.core.commons.api;

import com.hcentive.billing.core.commons.domain.Period;

public interface Effectivity {

	Period effectivePeriod();

}
