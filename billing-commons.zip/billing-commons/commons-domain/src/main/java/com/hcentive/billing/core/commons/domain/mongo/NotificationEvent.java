/**
 * 
 */
package com.hcentive.billing.core.commons.domain.mongo;

import java.io.Serializable;

/**
 * @author Dikshit.Vaid
 *
 */
public class NotificationEvent implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5283757319063527915L;

	private String name;
	private NotificationEventCategory category;
	private String description;
	private DeliveryTimeType deliveryTimeType;
	
	public NotificationEvent(){
		
	}
	
	public NotificationEvent(String name, NotificationEventCategory category, String description) {
		super();
		this.name = name;
		this.category = category;
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public NotificationEventCategory getCategory() {
		return category;
	}

	public void setCategory(NotificationEventCategory category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public DeliveryTimeType getDeliveryTimeType() {
		return deliveryTimeType;
	}

	public void setDeliveryTimeType(DeliveryTimeType deliveryTimeType) {
		this.deliveryTimeType = deliveryTimeType;
	}
}
