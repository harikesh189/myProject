package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;



public class UserRegistrationPayload implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1540730922739174463L;
	private String emailTo;
	private String tokenId;
	private String tenant;
	private String url;
	private String phoneNumber;
	private BusinessEntity be;
	
	public BusinessEntity getBe() {
		return be;
	}
	public void setBe(BusinessEntity be) {
		this.be = be;
	}
	public String getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	public String getTenant() {
		return tenant;
	}
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
