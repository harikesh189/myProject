package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

/**
 * @author Uttam Tiwari
 */
@Entity
@Table(name = "document_info")
public class DocumentInfo extends BaseEntity {

	private static final long serialVersionUID = 6477084316872133344L;

	@Column(name = "key", unique = true, nullable = false)
	@Access(AccessType.FIELD)
	private String key;

	@Column(name = "resolver_id")
	@Access(AccessType.FIELD)
	private String resloverId;

	@Column(name = "doc_type")
	@Access(AccessType.FIELD)
	private String docType;

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getKey() {
		return key;
	}

	public String getResloverId() {
		return resloverId;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setResloverId(String resloverId) {
		this.resloverId = resloverId;
	}
}
