package com.hcentive.billing.core.commons.domain.converter;

import java.math.BigDecimal;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.hcentive.billing.core.commons.vo.Amount;

@Converter
public class BigDecimalConverter implements AttributeConverter<Object, Double> {

	@Override
	public Double convertToDatabaseColumn(Object value) {
		if(value != null && value instanceof Number) {
			return ((Number)value).doubleValue();
		}
		return null;
	}
	
	@Override
	public BigDecimal convertToEntityAttribute(Double dbData) {
		BigDecimal result = null;
		if(dbData != null) {
			result = new BigDecimal(dbData).setScale(Amount.roundingScale, Amount.ROUNDING_MODE);
		}
		return result;
	}
	
}
