package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang.IllegalClassException;

@Entity
@Table(name = "token_payment_instrument")
@DiscriminatorValue("Token")
public class TokenPaymentMethod extends PaymentMethod {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1954365933995713997L;

	@Column
	@Access(AccessType.FIELD)
	private String token;

	@Access(value = AccessType.FIELD)
	@OneToOne(targetEntity = PaymentMethod.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "tokenized_method_id")
	private PaymentMethod tokenizedMethod;

	public TokenPaymentMethod(final String tokenId) {
		this.token = tokenId;
	}

	public TokenPaymentMethod() {
		setIdentifier("Token");
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public PaymentMethod getTokenizedMethod() {
		return tokenizedMethod;
	}

	public void setTokenizedMethod(PaymentMethod tokenizedMethod) {
		if (tokenizedMethod instanceof TokenPaymentMethod) {
			throw new IllegalClassException(
					"payment method is already tokenized");
		}
		this.tokenizedMethod = tokenizedMethod;
	}

	@Override
	public String getReferenceNumber() {
		return getToken();
	}

	/***
	 * Tokeinzed method can not be re-tokenized
	 * 
	 * @return
	 */
	@Override
	public String getIsTokenized() {
		return "0";
	}
}
