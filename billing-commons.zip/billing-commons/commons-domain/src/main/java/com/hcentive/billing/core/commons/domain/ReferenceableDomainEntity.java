package com.hcentive.billing.core.commons.domain;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.util.Collection;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.enumtype.ReferenceCategory;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

@MappedSuperclass
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public abstract class ReferenceableDomainEntity<R extends ReferenceableDomainEntity<R, V>, V> extends DomainEntity implements Referenceable<String, V, R>,
        ReferenceAware, TenantAware {

	public static final String COLUMN_TENANT_ID = "tenant_id";
	public static final String FIELD_TENANT_ID = "tenantId";
	
	private static final long serialVersionUID = 4952034420317809333L;

	@JoinColumn(name = "operator_id", nullable = true)
	@OneToOne(fetch = FetchType.EAGER)
	@Access(AccessType.FIELD)
	private Operator operator;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "reference_set_id")
	private ReferenceSet referenceSet;

	@Access(AccessType.FIELD)
	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;

	protected ReferenceableDomainEntity() {
		super();
	}

	protected ReferenceableDomainEntity(final Long id, final String identity) {
		this(id, identity, null);
	}

	protected ReferenceableDomainEntity(final Long id, final String identity, final String externalId) {
		super(id, identity, externalId);
	}

	protected ReferenceableDomainEntity(final String identity) {
		this(identity, null);
		this.tenantId = TenantUtil.getTenantId();
	}

	protected ReferenceableDomainEntity(final String identity, final String externald) {
		this(null, identity, externald);
		this.tenantId = TenantUtil.getTenantId();
	}

	public ReferenceableDomainEntity<R, V> addReference(final Reference ref) {
		this.getReferenceSet().add(ref);
		return this;
	}

	public ReferenceableDomainEntity<R, V> addReferences(final Collection<? extends Reference> refs) {
		if (isNotEmpty(refs)) {
			for (final Reference reference : refs) {
				this.getReferenceSet().add(reference.clone());
			}
		}
		return this;
	}

	@Override
	public boolean equals(final Object obj) {
		if (!(obj instanceof ReferenceableDomainEntity)) {
			return false;
		}
		final ReferenceableDomainEntity referenceableDomainEntity = (ReferenceableDomainEntity) obj;

		if (this.referenceId() != null && referenceableDomainEntity.referenceId() != null) {
			return this.referenceId().equals(referenceableDomainEntity.referenceId());
		}

		return false;
	}

	public final Reference extIdReference() {
		final Reference newExternalReference = Reference.newExternalReference(this.externalId, this.getClass().getSimpleName() + BillingConstant.EXTERNAL_ID,
		        this.externalId, this.getTenantId());
		newExternalReference.setCategory(ReferenceCategory.RELATED_ITEM);
		return newExternalReference;
	}

	public Operator getOperator() {
		return this.operator;
	}

	public ReferenceSet getReferenceSet() {
		return this.referenceSet == null ? (this.referenceSet = new ReferenceSet()) : this.referenceSet;
	}

	@Override
	public String getTenantId() {
		if (this.tenantId == null) {
			return "";
		}
		return this.tenantId;
	}

	@Override
	public int hashCode() {
		final int primeNumber = 31;
		int hashCode = 1;
		if (this.referenceId() != null) {
			hashCode = hashCode * primeNumber + this.referenceId().hashCode();
		}
		return hashCode;
	}

	@Override
	public final String referenceId() {
		return this.identity;
	}

	@Override
	public final Set<? extends Reference> references() {
		return this.getReferenceSet().getReferences();
	}

	@Override
	public final <I, T extends Referenceable, V, R extends Reference<I, T, V>> Set<R> referencesByType(final Class<T> type, final Class<I> identityType,
	        final Class<V> refValueType) {
		return this.getReferenceSet().referencesByType(type, identityType, refValueType);
	}

	@Override
	public final Set<Reference> referencesByTypeName(final String typeName) {
		return this.getReferenceSet().referencesByTypeName(typeName);
	}

	public ReferenceableDomainEntity<R, V> removeReference(final Reference ref) {
		this.getReferenceSet().remove(ref);
		return this;
	}

	public void setOperator(final Operator operator) {
		if (operator != null) {
			this.operator = operator;
		}
	}

	@Override
	public final Reference<String, R, V> toReference() {
		return Reference.newInternalReference((R) this);
	}

	public static void associate(final ReferenceableDomainEntity to, final ReferenceableDomainEntity from, final ReferenceCategory category) {
		if (to != null && from != null) {
			final Collection<Reference> referenceOfFrom = from.references();
			final Reference toSelfRef = to.toReference();
			if (referenceOfFrom != null) {
				for (final Reference r : referenceOfFrom) {
					if (r.getReferenceId().equals(toSelfRef)) {
						// skip self.
						continue;
					}
					final ReferenceCategory refCategory = r.getCategory();
					if (category != null && !category.equals(refCategory)) {
						// if category does not match skip.
						continue;
					}
					final Reference newRef = r.clone();
					if (ReferenceCategory.ALIAS.equals(newRef.getCategory())) {
						newRef.setCategory(ReferenceCategory.RELATED_ITEM);

					}
					to.addReference(newRef);

				}
			}
		}
	}

	public static void copyReferences(final ReferenceableDomainEntity to, final ReferenceableDomainEntity from, final ReferenceCategory category) {
		final Collection<Reference> fromCol = from.references();
		for (final Reference r : fromCol) {
			if (category == null || category.equals(r.getCategory())) {
				final Reference newR = r.clone();
				newR.setCategory(ReferenceCategory.RELATED_ITEM);
				to.addReference(newR);

			}
		}
	}

}
