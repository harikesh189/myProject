package com.hcentive.billing.condition;

import com.hcentive.billing.core.commons.vo.Amount;

public class LtEq extends SimpleCondition<Amount>{

	private static final long serialVersionUID = 1L;

	public LtEq() {
		super();
	}
	
	public LtEq(final String name, final Amount value) {
		super(name, value);
	}
	
	@Override
	protected boolean eval(final Amount input) {
		if (input == null && this.getValue() == null) {
			return true;
		}

		if (input != null) {
			if (this.getValue() != null) {
				return input.lessThanEqualTo(this.getValue());
			}
			return false;
		}
		return true;
	}

}
