package com.hcentive.billing.core.commons.domain;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "contact_set")
public class ContactSet<C extends Contact> extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2304728474832290682L;
	@OneToMany(targetEntity = Contact.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@Access(AccessType.FIELD)
	@PrimaryKeyJoinColumn
	@JoinTable(name = "contact_set_contacts", joinColumns = { @JoinColumn(name = "contact_set_id") }, inverseJoinColumns = { @JoinColumn(name = "contacts_id") })
	private Set<C> contacts = new HashSet<C>(0);

	ContactSet() {
	}

	public ContactSet(Collection<C> contacts) {
		addAll(contacts);
	}

	public void addAll(Collection<C> contacts) {
		if (contacts != null) {
			for (final C contact : contacts) {
				add(contact);
			}
		}
	}

	public Collection<C> contacts() {
		return Collections.unmodifiableCollection(this.contacts);
	}

	public void add(C contact) {
		if (contact != null) {
			if (this.contacts.isEmpty()) {
				contact.setPrimary(true);
			}
			this.contacts.add(contact);
			contact.set(this);
			if (contact.isPrimary()) {
				markedAsPrimary(contact);
			}
		}
	}

	void markedAsPrimary(final C contact) {
		for (final C c : this.contacts) {
			if (contact != c) {
				c.setPrimary(false);
			}
		}
	}

	public C primaryContact() {
		if (this.contacts.size() == 1) {
			return this.contacts.iterator().next();
		} else {
			for (final C contact : this.contacts) {
				if (contact.isPrimary()) {
					return contact;
				}
			}
		}
		return null;
	}

	public Set<C> getContacts() {
		return contacts;
	}

	public final void removeAll() {
		this.contacts.clear();
	}

	/**
	 * 
	 * @param contactToRemove
	 *            the contact to remove.
	 * @param newPrimaryContact
	 *            Optional. in case the contact being removed is primary, then
	 *            the contact which would be primary henceforth.
	 */
	public final void remove(final Contact contactToRemove,
			final Contact newPrimaryContact) {
		if (null != contactToRemove && contactToRemove.isPrimary()) {
			if (newPrimaryContact == null) {
				throw new IllegalArgumentException("Provide newPrimaryContact.");
			} else {
				newPrimaryContact.markAsPrimary();
			}
			this.contacts.remove(contactToRemove);
		}
	}
}
