package com.hcentive.billing.core.commons.domain;

/**
 * 
 * @author Bappaditya.Mallick
 * 
 * @param <I>
 *            type of the referenceId
 */
public interface Referenceable<I, V, R extends Referenceable<I, V, R>> {

	public I referenceId();

	public String typeName();

	public V refValue();

	public long version();

	public Reference<I, R, V> toReference();
}
