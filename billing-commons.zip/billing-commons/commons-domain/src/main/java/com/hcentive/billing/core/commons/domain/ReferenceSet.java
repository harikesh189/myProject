package com.hcentive.billing.core.commons.domain;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Reference.ReferenceType;

@Entity
@Table(name = "Reference_Set")
public class ReferenceSet extends BaseEntity implements ReferenceAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8054576677911192151L;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "reference_set_reference", joinColumns = @JoinColumn(name = "reference_set_id"), inverseJoinColumns = @JoinColumn(name = "reference_id"))
	private final Set<Reference> references = new HashSet<Reference>(0);

	public void add(final Reference ref) {
		this.references.add(ref);
	}

	public void add(final ReferenceSet refSet) {
		if (refSet != null && isNotEmpty(refSet.getReferences())) {
			for (final Reference ref : refSet.getReferences()) {
				this.add(ref);
			}
		}
	}

	public Set<Reference> getReferences() {
		return this.references;
	}

	void remove(final Reference ref) {
		this.references.remove(ref);
	}

	@Override
	public final Set<? extends Reference> references() {
		return this.getReferences();
	}

	@Override
	public final <I, T extends Referenceable, V, R extends Reference<I, T, V>> Set<R> referencesByType(
			final Class<T> type, final Class<I> identityType,
			final Class<V> refValueType) {
		final Set<R> matchedReferences = new HashSet<R>();
		if (type != null) {
			for (final Reference r : this.getReferences()) {
				if (ReferenceType.INTERNAL.equals(r.getRefType())
						&& type.isAssignableFrom(r.getType())) {
					matchedReferences.add((R) r);
				}
			}
		}
		return Collections.unmodifiableSet(matchedReferences);
	}

	@Override
	public final Set<Reference> referencesByTypeName(final String typeName) {
		final Set<Reference> matchedReferences = new HashSet<Reference>();
		if (typeName != null) {
			for (final Reference r : this.getReferences()) {
				if (typeName.equalsIgnoreCase(r.getTypeName())) {
					matchedReferences.add(r);
				}
			}
		}
		return Collections.unmodifiableSet(matchedReferences);
	}
}
