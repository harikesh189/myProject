package com.hcentive.billing.condition;

import java.util.Collection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Or extends ComplexCondition {

	private static Logger logger = LoggerFactory.getLogger(Or.class);

	private static final long serialVersionUID = 1L;

	public Or(final Collection<? extends Condition> conds) {
		super("OR", conds);
	}

	public Or(final Condition... conds) {
		super("OR", conds);
	}

	@Override
	public boolean evaluate(final Map<String, ?> inputValueMap) {
		logger.debug("Evaluating {} condition start", this.toString());
		for (final Condition cond : this.getConds()) {
			final boolean result = cond.evaluate(inputValueMap);
			if (result) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean evaluate(
			final ConditionContextResolver conditionValueResolver) {
		logger.debug("Evaluating {} condition start", this.toString());
		for (final Condition cond : this.getConds()) {
			final boolean result = cond.evaluate(conditionValueResolver);
			if (result) {
				return true;
			}
		}
		return false;
	}
}
