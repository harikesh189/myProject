package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.InvoiceItemType;
import com.hcentive.billing.core.commons.vo.Amount;

/**
 * 
 * @author Gaurav.Agarwal1
 * 
 */
@Entity
@Table(name = "invoice_item")
@DiscriminatorValue("GenericItem")
public class GenericItem extends InvoiceItem {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6553600940196487846L;

	public GenericItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected GenericItem(Amount amount, boolean isDebt, String description,
			String label, String reference, InvoiceItemType type) {
		super(amount, isDebt, description, label, reference, type);
	}

}
