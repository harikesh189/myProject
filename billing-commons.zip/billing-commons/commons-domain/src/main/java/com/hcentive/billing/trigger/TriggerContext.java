/**
 * 
 */
package com.hcentive.billing.trigger;

import java.util.Date;

import org.apache.commons.beanutils.PropertyUtilsBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
public class TriggerContext<T> {

	private T payload;
	private Trigger trigger;

	public TriggerContext(T payload, Trigger trigger) {
		super();
		this.payload = payload;
		this.trigger = trigger;
	}

	public T getPayload() {
		return payload;
	}

	public void setPayload(T payload) {
		this.payload = payload;
	}

	public Trigger getOperator() {
		return trigger;
	}

	public void setOperator(Trigger operator) {
		this.trigger = operator;
	}

	public DateTime eval() throws Exception {
		final DateTime applyOnValue = PayloadValueResolver.resolve(
				((AbstractTrigger) this.trigger).getApplyOn(), payload);
		return trigger.operate(applyOnValue);
	}

	private static class PayloadValueResolver {

		private static Logger LOGGER = LoggerFactory
				.getLogger(PayloadValueResolver.class);

		private static DateTime resolve(String applyOn, Object payload)
				throws Exception {
			try {
				final PropertyUtilsBean propertyUtils = new PropertyUtilsBean();
				final Object applyOnValue = propertyUtils.getNestedProperty(
						payload, applyOn);
				return new DateTime((Date)applyOnValue);
			} catch (SecurityException e) {
				LOGGER.debug("Property name, for payload {}, is not valid, {}",
						payload.getClass().toString(), applyOn);
				throw new Exception("Property name is not valid", e);
			}

		}
	}
}
