package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.domain.enumtype.SheduleAmountType;
import com.hcentive.billing.core.commons.vo.Amount;

public class AmountSetUp {

	private SheduleAmountType recurringAmountType;
	private Amount flatAmount;

	public SheduleAmountType getRecurringAmountType() {
		return recurringAmountType;
	}

	public void setRecurringAmountType(SheduleAmountType recurringAmountType) {
		this.recurringAmountType = recurringAmountType;
	}

	public Amount getFlatAmount() {
		return flatAmount;
	}

	public void setFlatAmount(Amount flatAmount) {
		this.flatAmount = flatAmount;
	}

}
