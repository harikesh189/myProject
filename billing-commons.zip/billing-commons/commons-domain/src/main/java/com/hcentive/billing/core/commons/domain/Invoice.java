package com.hcentive.billing.core.commons.domain;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.api.BusinessEntityAware;
import com.hcentive.billing.core.commons.api.SubscriptionAware;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Prateek.Bansal
 * 
 */
@Entity
@Table(name = "invoice")
public final class Invoice extends ItemRecordAwareEntity<Invoice, String>
		implements BusinessEntityAware<BusinessEntity>, SubscriptionAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7451947032405781732L;

	public static final String InvoiceSeriesId = "invoiceSeriesId";

	public static final String STATUS = "status";
	
	public static final String CURRENT ="isCurrent";

	public static final String BusinessEntity = "generatedFor.identity";

	protected Invoice() {
	}

	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status = InvoiceStatus.OPEN.getStatus();

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "generated_on")) })
	@Access(AccessType.FIELD)
	private DateTime generatedOn;

	// @Column(name = "due_date")
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "due_date")) })
	@Access(AccessType.FIELD)
	private DateTime dueDate;

	@Column(name = "invoice_series_id")
	@Access(AccessType.FIELD)
	private String invoiceSeriesId;

	@OneToOne(targetEntity = Customer.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "business_id")
	@Access(AccessType.FIELD)
	private BusinessEntity<Profile> generatedFor;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period invoicePeriod;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "payable_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "payable_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "payable_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "payable_amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount payableAmount;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "current_invoice_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "current_invoice_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "current_invoice_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "current_invoice_amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount currentInvoiceAmount;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "minimum_payable_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "minimum_payable_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "minimum_payable_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "minimum_payable_amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount minimumPayableAmount;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Access(AccessType.FIELD)
	@JoinTable(name = "invoice_items", joinColumns = @JoinColumn(name = "invoice_id"), inverseJoinColumns = @JoinColumn(name = "items_id"))
	private Set<InvoiceItem> items = new HashSet<InvoiceItem>(0);

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Access(AccessType.FIELD)
	@JoinTable(name = "invoice_members", joinColumns = @JoinColumn(name = "invoice_id"), inverseJoinColumns = @JoinColumn(name = "members_id"))
	private Set<Member> members = new HashSet<Member>(0);

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Access(AccessType.FIELD)
	@JoinTable(name = "invoice_doc_refs", joinColumns = @JoinColumn(name = "invoice_id"), inverseJoinColumns = @JoinColumn(name = "doc_refs_id"))
	private Set<DocumentRef> docRefs = new HashSet<DocumentRef>(0);

	@Column(name = "deleted")
	@Access(AccessType.FIELD)
	private boolean deleted = false;

	@Column(name = "approved")
	@Access(AccessType.FIELD)
	private boolean approved = true;
	
	@ManyToOne(targetEntity = EbillSubscription.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "subscription_id")
	@Access(AccessType.FIELD)
	private EbillSubscription subscription;
	
	
	@Column(name="is_current")
	@Access(AccessType.FIELD)
	private boolean isCurrent;
	
	@Column(name="runout")
	@Access(AccessType.FIELD)
	private Boolean runout;
	
	public Boolean isRunout() {
		return runout;
	}

	public void setRunout(Boolean runout) {
		this.runout = runout;
	}

	public EbillSubscription getSubscription() {
		
		return subscription;
	}

	public void setSubscription(EbillSubscription subscription) {
		this.subscription = subscription;
		this.addReference(subscription.toReference());
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public DateTime getGeneratedOn() {
		return new DateTime(this.generatedOn.getDate());
	}

	public <B extends BusinessEntity> B getGeneratedFor() {
		return (B) this.generatedFor;
	}

	public Period getInvoicePeriod() {
		return invoicePeriod;
	}

	public Set<InvoiceItem> getItems() {
		return items;
	}

	public Set<Member> getMembers() {
		return members;
	}

	@Override
	public String typeName() {
		return "Invoice";
	}

	@Override
	public String refValue() {
		return identity;
	}

	public void setGeneratedOn(DateTime generatedOn) {
		this.generatedOn = generatedOn;
	}

	public void setGeneratedFor(BusinessEntity<Profile> generatedFor) {
		this.generatedFor = generatedFor;
	}

	public DateTime getDueDate() {
		return dueDate;
	}

	public void setDueDate(DateTime dueDate) {
		this.dueDate = dueDate;
	}

	public void setInvoicePeriod(Period invoicePeriod) {
		this.invoicePeriod = invoicePeriod;
	}

	public void setItems(Set<InvoiceItem> items) {
		if(items!=null && items!=Collections.EMPTY_SET){
		this.items = items;
		}
	}

	public void setMembers(Set<Member> members) {
		this.members = members;
	}

	public Invoice(String identity) {
		super(identity);
	}

	public Invoice(String identity, String externald) {
		super(identity, externald);
	}

	public Amount getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(Amount payableAmount) {
		this.payableAmount = payableAmount;
	}

	public Set<DocumentRef> getDocRefs() {
		return docRefs;
	}

	public void setDocRefs(Set<DocumentRef> docRefs) {
		this.docRefs = docRefs;
	}

	public String getStatus() {
		return status;
	}

	void setStatus(String status) {
		this.status = status;
	}

	public String getInvoiceSeriesId() {
		return invoiceSeriesId;
	}

	public void setInvoiceSeriesId(String invoiceSeriesId) {
		this.invoiceSeriesId = invoiceSeriesId;
	}

	@Override
	public void setBusinessEntity(BusinessEntity businessEntity) {
		this.generatedFor = businessEntity;
	}

	public Amount getCurrentInvoiceAmount() {
		return currentInvoiceAmount;
	}

	public void setCurrentInvoiceAmount(Amount currentInvoiceAmount) {
		this.currentInvoiceAmount = currentInvoiceAmount;
	}

	public boolean isApproved() {
		return approved;
	}

	public void setApproved(boolean approved) {
		this.approved = approved;
	}

	public Amount getMinimumPayableAmount() {
		return minimumPayableAmount;
	}

	public void setMinimumPayableAmount(Amount minimumPayableAmount) {
		this.minimumPayableAmount = minimumPayableAmount;
	}

	public boolean updateInvoiceStatus(InvoiceStatus newStatus) {
		this.setStatus(newStatus.getStatus());
		return true;
	}

	public boolean isCurrent() {
		return isCurrent;
	}

	public void setCurrent(boolean isCurrent) {
		this.isCurrent = isCurrent;
	}
	
	

}
