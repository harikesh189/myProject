package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "permission")
public class Permission extends DomainEntity {

	@Column(name = "operation_name")
	@Access(AccessType.FIELD)
	private String operationName;

	@Column(name = "operation_code")
	@Access(AccessType.FIELD)
	private String operationCode;

	@Column(name = "app_id")
	@Access(AccessType.FIELD)
	private String appId;

	@Column(name = "permission_group")
	@Access(AccessType.FIELD)
	private String permissionGroup;

	@Column(name = "description")
	@Access(AccessType.FIELD)
	private String description;

	protected Permission(String identity, String externalId) {
		super(identity, externalId);
	}

	protected Permission() {

	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getPermissionGroup() {
		return permissionGroup;
	}

	public void setPermissionGroup(String permissionGroup) {
		this.permissionGroup = permissionGroup;
	}

	@Override
	public int hashCode() {
		return this.operationCode.hashCode();
	}

	@Override
	public boolean equals(final Object obj) {

		if (obj instanceof Permission) {

			final Permission that = (Permission) obj;

			return this.operationCode.equals(that.operationCode);
		}
		return false;
	}

}
