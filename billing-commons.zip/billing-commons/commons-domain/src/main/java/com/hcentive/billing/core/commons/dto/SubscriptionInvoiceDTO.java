package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

public class SubscriptionInvoiceDTO {

	private String subscriptionName;
	
	private String subscriptionId;
	
	private String subscriptionExternalId;
	
	private Amount totalOutstanding;
	
	private String status;

	public Amount getTotalOutstanding() {
		return totalOutstanding;
	}

	public void setTotalOutstanding(Amount totalOutstanding) {
		this.totalOutstanding = totalOutstanding;
	}

	public String getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}
	
	public String getSubscriptionExternalId() {
		return subscriptionExternalId;
	}

	public void setSubscriptionExternalId(String subscriptionExternalId) {
		this.subscriptionExternalId = subscriptionExternalId;
	}

	private DateTime nextScheduleDates;

	public String getSubscriptionName() {
		return subscriptionName;
	}

	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	public DateTime getNextScheduleDates() {
		return nextScheduleDates;
	}

	public void setNextScheduleDates(DateTime nextScheduleDates) {
		this.nextScheduleDates = nextScheduleDates;
	}

	public void addOutstanding(Amount amountPaid) {
	if(this.getTotalOutstanding()==null){
		this.totalOutstanding=new Amount();
	}
	setTotalOutstanding(this.totalOutstanding.add(amountPaid));
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
