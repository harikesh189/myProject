package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "user_credential")
@DiscriminatorValue(value = "IDP_USERCREDENTIAL")
public class IdpUserCredential extends UserCredentials {

	public IdpUserCredential(String identity, String externalId,
			String idpUserIdentity, String idpKey, String enterpriseName) {
		super(identity, externalId,enterpriseName,idpKey);
		this.idpUserIdentity = idpUserIdentity;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "idp_user_identity")
	@Access(AccessType.FIELD)
	private String idpUserIdentity;


	public String getIdpUserIdentity() {
		return idpUserIdentity;
	}

	public static IdpUserCredential createIdpUserCredentials(String identity,
			String externalId, String principal, String idpKey2,String enterpriseName) {
		return new IdpUserCredential(identity, externalId, principal, idpKey2,enterpriseName);
	}

	protected IdpUserCredential() {
	}

	@Override
	public Object getAuthKey() {
		return getIdpKey();
	}

}
