package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.Amount;

/**
 * 
 * @author Gaurav.Agarwal1
 * 
 */

@Entity
@Table(name = "invoice_summary")
public class InvoiceSummary extends DomainEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String STATUS = "invoice.status";

	public static final String BUSINESS_ENTITY = "invoice.generatedFor.identity";

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "discount_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "discount_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "discount_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "discount_amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount discount;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "amount_paid_value")),
			@AttributeOverride(name = "name", column = @Column(name = "amount_paid_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "amount_paid_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "amount_paid_short_name")) })
	@Access(AccessType.FIELD)
	private Amount amountPaid;

	@OneToOne(targetEntity = Invoice.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "invoice_id")
	@Access(AccessType.FIELD)
	private Invoice invoice;

	protected InvoiceSummary() {

	}

	public InvoiceSummary(Invoice invoice) {
		this.invoice = invoice;
		this.identity = invoice.identity;
		this.externalId = invoice.externalId;
	}

	public Amount getDiscount() {
		if (discount == null)
			this.discount = new Amount();
		return discount;
	}

	public void setDiscount(Amount discount) {
		this.discount = discount;
	}

	public Amount getAmountPaid() {
		return amountPaid;
	}

	public void updateAmount(final Amount amountPaid) {
		this.amountPaid = amountPaid;
		if (this.invoice != null && this.invoice.getPayableAmount() != null) {
			Amount invoiceAmount = this.invoice.getPayableAmount();
			Amount paidAmount = this.amountPaid.add(this.getDiscount());
			if (invoiceAmount.subtract(paidAmount).isNegativeOrZero()) {
				this.invoice.updateInvoiceStatus(InvoiceStatus.CLOSED);
			} else
				this.invoice.updateInvoiceStatus(InvoiceStatus.OPEN);

		}
	}

	public void setAmount(final Amount amountPaid) {
		this.amountPaid = amountPaid;
	}

	public Invoice getInvoice() {
		return invoice;
	}
	
	public Amount getTotalAmountPaid(){
		return this.getAmountPaid().add(this.getDiscount());
	}
	
	public Amount getTotalOutstanding(){
		return this.getInvoice().getPayableAmount().subtract(this.getTotalAmountPaid());
	}

}
