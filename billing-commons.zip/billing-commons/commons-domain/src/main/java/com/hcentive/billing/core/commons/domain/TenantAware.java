package com.hcentive.billing.core.commons.domain;


public interface TenantAware {
	public String getTenantId();
}
