package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@SuppressWarnings("hiding")
@Entity
@Table(name = "business_entity")
@DiscriminatorValue("Customer")
public class Customer<Profile> extends BusinessEntity {

	public final static String DUMMY_IDENTIY = "dummyIdentity";

	private static final long serialVersionUID = 1L;

	public Customer(Long id, String identity) {
		super(id, identity);
	}

	public Customer(String identity) {
		super(identity);
	}

	protected Customer() {
		super();
	}

	public Customer(String identity, String externalId) {
		super(identity, externalId);
	}

	public Customer(String identity, String externalId, String type) {
		super(identity, externalId, type);
	}

	@Override
	public String refValue() {
		//if (null != getProfile()) {
		return super.refValue();
		/*} else {
			return null;
		}*/

	}

	@Override
	public String typeName() {
		return "Customer";
	}

	@Override
	public Address getAddress() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Customer dummyCustomer() {
		return new Customer("", DUMMY_IDENTIY);
	}

}
