package com.hcentive.billing.core.commons.domain.enumtype;

public enum AuditableOperation {

	SAVE, UPDATE, DELETED;

}
