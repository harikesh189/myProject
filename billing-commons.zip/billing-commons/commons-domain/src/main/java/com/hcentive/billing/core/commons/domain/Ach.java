package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.hcentive.billing.core.commons.domain.enumtype.AchType;

@Entity
@Table(name = "bank_account")
@DiscriminatorValue("BankAccount")
public class Ach extends PaymentMethod {

	@Column(name = "account_type")
	@Enumerated(EnumType.STRING)
	private AchType accountType;
	@Column(name = "bank_name")
	@Access(AccessType.FIELD)
	private String bankName;
	@Transient
	private String routingNumber;
	@Column(name = "account_number")
	@Access(AccessType.FIELD)
	private String accountNumber;
	@Column(name = "account_holder_first_name")
	@Access(AccessType.FIELD)
	private String accountHolderFirstName;

	@Column(name = "account_holder_last_name")
	@Access(AccessType.FIELD)
	private String accountHolderLastName;

	public AchType getAccountType() {
		return accountType;
	}

	public void setAccountType(AchType accountType) {
		this.accountType = accountType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getRoutingNumber() {
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolderFirstName() {
		return accountHolderFirstName;
	}

	public void setAccountHolderFirstName(String accountHolderFirstName) {
		this.accountHolderFirstName = accountHolderFirstName;
	}

	public String getAccountHolderLastName() {
		return accountHolderLastName;
	}

	public void setAccountHolderLastName(String accountHolderLastName) {
		this.accountHolderLastName = accountHolderLastName;
	}

	protected Ach() {
		setIdentifier("BankAccount");
		setIsTokenized("0");
	}

	public static Ach newAch() {
		return new Ach();
	}

	@Override
	public String getReferenceNumber() {
		return getAccountNumber();
	}
}
