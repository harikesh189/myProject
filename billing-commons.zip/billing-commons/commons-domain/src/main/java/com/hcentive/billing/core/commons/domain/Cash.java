package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cash_payment")
@DiscriminatorValue("Cash")
public class Cash extends PaymentMethod implements Serializable {

	@Column(name = "source")
	@Access(AccessType.FIELD)
	private String source;

	protected Cash() {
		setIdentifier("Cash");
	}

	@Override
	public String getReferenceNumber() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public static Cash newCashPayment() {
		return new Cash();
	}

}
