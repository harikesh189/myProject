package com.hcentive.billing.condition;

import java.util.Map;

public abstract class BaseCondition implements Condition {
	private static final long serialVersionUID = 1L;

	private String name;

	protected BaseCondition(final String name) {
		this.setName(name);
	}

	@Override
	public String getName() {
		return this.name;
	}

	protected Object getValueToEval(
			final ConditionContextResolver conditionValueResolver) {
		return conditionValueResolver.getValue(this.getName());
	}

	protected Object getValueToEval(final Map<String, ?> inputValueMap) {
		return inputValueMap.get(this.getName());
	}

	public void setName(final String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return this.getName();
	}
}
