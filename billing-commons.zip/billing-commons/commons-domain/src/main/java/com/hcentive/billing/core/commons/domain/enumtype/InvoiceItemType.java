package com.hcentive.billing.core.commons.domain.enumtype;

public enum InvoiceItemType {
	CURRENT_PREMIUM, FEE, DISCOUNT, ADJUSTMENT, PRIOR_DUE, CREDIT, APTC, OTHER, OUTSTANDING_ACCOUNT_BALANCE, TAX;
}
