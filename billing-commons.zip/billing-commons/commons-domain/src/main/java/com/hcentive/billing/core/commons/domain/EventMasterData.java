package com.hcentive.billing.core.commons.domain;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;

@Document(collection = "event_master_data")
public class EventMasterData extends AbstractMongoEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 879604828123387753L;
	private String eventName;
	private String serviceName;
	private String handler;
	
	public EventMasterData(String eventName,String serviceName,String handler){
		this.eventName=eventName;
		this.serviceName=serviceName;
		this.handler=handler;
	}
	
	
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


	public String getHandler() {
		return handler;
	}


	public void setHandler(String handler) {
		this.handler = handler;
	}	
}
