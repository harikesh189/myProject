package com.hcentive.billing.condition;

import com.hcentive.billing.core.commons.api.Effectivity;

public interface PeriodAwareConditionContextResolver extends
		ConditionContextResolver, Effectivity {
}
