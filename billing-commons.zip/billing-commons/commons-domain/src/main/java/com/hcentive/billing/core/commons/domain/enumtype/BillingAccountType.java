package com.hcentive.billing.core.commons.domain.enumtype;

public enum BillingAccountType {

	INVOICE_ACCOUNT,

	INVOICE_ONLY_ACCOUNT,

	REMIT_ACCOUNT,

	REMIT_INVOICE_ACCOUNT,

	GENERIC_ACCOUNT

}
