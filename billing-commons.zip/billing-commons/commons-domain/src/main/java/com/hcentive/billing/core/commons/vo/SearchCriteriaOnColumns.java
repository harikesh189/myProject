package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

@Deprecated
public class SearchCriteriaOnColumns implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5638014803632793476L;

	// value of column
	private String columnValue;

	// attributes, i.e. what operator to be used
	private String operator;

	// defines data type of column
	private boolean caseSensitiveSearch;

	public SearchCriteriaOnColumns(final String columnValue,
			final String operator, final boolean caseSenssitiveSearch) {
		this.columnValue = columnValue;
		this.operator = operator;
		this.caseSensitiveSearch = caseSenssitiveSearch;
	}

	public SearchCriteriaOnColumns() {
		this.caseSensitiveSearch = true;
	}

	public boolean isCaseSensitiveSearch() {
		return this.caseSensitiveSearch;
	}

	public void setCaseSensitiveSearch(final boolean caseSensitiveSearch) {
		this.caseSensitiveSearch = caseSensitiveSearch;
	}

	public String getColumnValue() {
		return this.columnValue;
	}

	public Object getColumnValueObject() {
		if (StringUtils.isNotBlank(this.columnValue)) {
			if (this.columnValue.equalsIgnoreCase("true")
					|| this.columnValue.equalsIgnoreCase("false")) {

				return Boolean.parseBoolean(this.columnValue);
			}
		}
		return this.columnValue;
	}

	public void setColumnValue(final String columnValue) {
		this.columnValue = columnValue;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(final String operator) {
		this.operator = operator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("SearchCriteriaOnColumns [columnValue=");
		builder.append(this.columnValue);
		builder.append(", operator=");
		builder.append(this.operator);
		builder.append(", caseSensitiveSearch=");
		builder.append(this.caseSensitiveSearch);
		builder.append("]");
		return builder.toString();
	}

}
