package com.hcentive.billing.core.commons.domain.audit;

public enum AuditEventType {	
	INBOUND_PAYMENT("Inbound Payment"),OUTBOUND_PAYMENT("Outbound Payment"),PAYMENT("Payment"), USER("User"), OTHER("Other"), PREFERENCE("Preference"), INVOICE("Invoice"), PROCESSCONTEXT("Process Context"), ENTITY("Entity"), RULES("Rules"), MANUAL_ADJ("Manual Adjustment"), REMIT("Remit"), REFUND("Refund"), NOTIFICATION("Notification"), MONEY_TRANSFER("Money Transfer"), AUTO_MONEY_TRANSFER("Auto Money Transfer"),BILLING_ACCOUNT("Billing Account"),REINSTATEMENT("Reinstatement"),DELINQUENCY("Delinquency");
	private final String displayValue;
	public String getDisplayValue() {
		return displayValue;
	}
	private AuditEventType(String displayValue){
		this.displayValue = displayValue;
	}
}
