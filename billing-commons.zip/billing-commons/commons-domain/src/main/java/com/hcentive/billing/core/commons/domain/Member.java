package com.hcentive.billing.core.commons.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

@Entity
@Table(name = "member")
@DiscriminatorColumn(name = "member_type")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class Member extends BaseEntity implements TenantAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2235801521283112248L;

	@Column(name = "member_id")
	@Access(AccessType.FIELD)
	private String memberId;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "member_identifier", joinColumns = @JoinColumn(name = "member_id"), inverseJoinColumns = @JoinColumn(name = "identifier_id"))
	private List<IdentifierCode> identifiers = new ArrayList<>();
	
	

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "profile_id")
	@Access(AccessType.FIELD)
	private PersonalProfile personalProfile;

	@OneToOne(cascade = {CascadeType.PERSIST, CascadeType.REMOVE}, orphanRemoval = true)
	@JoinColumn(name = "reference_id")
	@Access(AccessType.FIELD)
	private Reference<String, Customer, String> associatedWith;

	@Column(name = "relationship")
	private String relationship;

	@Access(AccessType.FIELD)
	@Column(name = "student")
	private boolean student;

	@Access(AccessType.FIELD)
	@Column(name = "subscriber")
	private boolean subscriber;

	
	@Access(AccessType.FIELD)
	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;
	
	
	public Reference<String, Customer, String> getAssociatedWith() {
		return associatedWith;
	}

	public String getMemberId() {
		return memberId;
	}

	public PersonalProfile getPersonalProfile() {
		return personalProfile;
	}

	public String getRelationship() {
		return relationship;
	}

	public boolean isStudent() {
		return student;
	}

	public void setAssociatedWith(
			Reference<String, Customer, String> associatedWith) {
		this.associatedWith = associatedWith;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public void setPersonalProfile(PersonalProfile personalProfile) {
		this.personalProfile = personalProfile;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public void setStudent(boolean student) {
		this.student = student;
	}

	public boolean isSubscriber() {
		return subscriber;
	}

	public void setSubscriber(boolean subscriber) {
		this.subscriber = subscriber;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	public List<IdentifierCode> getIdentifiers() {
		return Collections.unmodifiableList(identifiers);
	}

	public void addIdentifier(IdentifierCode identifier) {
		this.identifiers.add(identifier);
	}
	public void setIdentifiers(List<IdentifierCode> identifiers) {
		this.identifiers = identifiers;
	}
	
	/*public void addAllIdentifiers(List<IdentifierCode> identifiers) {
		this.identifiers.addAll(identifiers);
	}*/
	
	public IdentifierCode getIdentifier(IdentifierCode.Type type) {
		IdentifierCode identifierCodeResult = null;
		if(this.identifiers != null && !this.identifiers.isEmpty()) {
			for (IdentifierCode identifierCode : identifiers) {
				if (type.name().equalsIgnoreCase(identifierCode.getType().name())) {
					identifierCodeResult = identifierCode;
					break;
				}
			}
		}
		return identifierCodeResult;
	}

}