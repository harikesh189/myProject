package com.hcentive.billing.core.commons.domain.audit;

public enum AuditWorkStatus {
	SUCCESS, FAILURE, CREATED, DESTROYED
}
