package com.hcentive.billing.condition;

import java.util.Collection;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;

import com.hcentive.billing.core.commons.util.JsonUtil;

public abstract class ComplexCondition extends BaseCondition implements Condition {

	private static final long serialVersionUID = 1L;

	private Collection<? extends Condition> conds;

	public ComplexCondition(final String name, final Collection<? extends Condition> conds) {
		super(name);
		this.setConds(conds);
	}

	public ComplexCondition(final String name, final Condition... conds) {
		super(name);
		this.setConds(asList(conds));
	}

	public Collection<? extends Condition> getConds() {
		return this.conds;
	}

	public void setConds(final Collection<? extends Condition> conds) {
		this.conds = conds;
	}

	@Override
	public String toString() {
		return JsonUtil.toJsonString(this);
	}
}
