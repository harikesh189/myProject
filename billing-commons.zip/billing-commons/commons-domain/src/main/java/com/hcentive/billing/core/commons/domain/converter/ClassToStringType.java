package com.hcentive.billing.core.commons.domain.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.hcentive.billing.core.commons.exception.BillingException;

@Converter(autoApply = true)
public class ClassToStringType implements AttributeConverter<Class, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8204739979756552930L;

	@Override
	public String convertToDatabaseColumn(
			@SuppressWarnings("rawtypes") Class clazz) {
		if (clazz != null) {
			return clazz.getName();
		} else
			return "";
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Class convertToEntityAttribute(String className) {
		try {
			if (null != className && !className.isEmpty())
				return Class.forName(className);
		} catch (ClassNotFoundException e) {
			throw new BillingException(
					"Could not load classtype: " + className, e);
		}
		return null;
	}

}
