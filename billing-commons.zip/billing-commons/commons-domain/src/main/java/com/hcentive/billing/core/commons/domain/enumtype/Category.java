package com.hcentive.billing.core.commons.domain.enumtype;

public enum Category {
	HOME, WORK, REMIT_TO, OTHER;
}