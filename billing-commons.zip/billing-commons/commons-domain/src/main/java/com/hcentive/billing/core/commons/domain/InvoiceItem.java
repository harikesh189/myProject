package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.InvoiceItemType;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * 
 * @author Gaurav.Agarwal1
 * 
 */
@Entity
@Table(name = "invoice_item")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "obj_type")
public abstract class InvoiceItem extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4223255779748072028L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "value")),
			@AttributeOverride(name = "name", column = @Column(name = "name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	@Column(name = "is_debt")
	@Access(AccessType.FIELD)
	private boolean isDebt;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "associated_date")) })
	@Access(AccessType.FIELD)
	private DateTime associatedDate;

	@Column(name = "type", nullable = false)
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private InvoiceItemType type;

	@Column(name = "description")
	@Access(AccessType.FIELD)
	private String description;

	@Column(name = "label")
	@Access(AccessType.FIELD)
	private String label;

	@Column(name = "reference")
	@Access(AccessType.FIELD)
	private String reference;

	public InvoiceItem() {

	}

	public InvoiceItem(Amount amount, boolean isDebt, String description,
			String label, String reference, InvoiceItemType type) {

		super();
		String defaultDescription = getDefalultDescrption();
		String defaultLabel = getDefaultLabel();

		setAmount(amount);
		setDebt(isDebt);
		if (null == description || description.isEmpty())
			setDescription(defaultDescription);
		else
			setDescription(description);
		if (null == label || label.isEmpty())
			setLabel(defaultLabel);
		else
			setLabel(label);
		setReference(reference);
		setType(type);

	}

	public String getDefaultLabel() {
		// TODO Auto-generated method stub
		/*
		 * ajay : fixed def 1637
		 */
		return getClass().getSimpleName();
	}

	public String getDefalultDescrption() {
		// TODO Auto-generated method stub
		return getClass().getName();
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public void setDebt(boolean isDebt) {
		this.isDebt = isDebt;
	}

	public void setType(InvoiceItemType type) {
		this.type = type;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Amount getAmount() {
		return amount;
	}

	public boolean isDebt() {
		return isDebt;
	}

	public InvoiceItemType getType() {
		return type;
	}

	public String getDescription() {
		return description;
	}

	public String getLabel() {
		return label;
	}

	public static InvoiceItem createAndGetGenericInvoiceItem(Amount amount,
			boolean isDebt, String description, String label, String reference) {
		return new GenericItem(amount, isDebt, description, label, reference,
				InvoiceItemType.OTHER);
	}

	public static InvoiceItem createAndGetCurrentPremium(Amount amount,
			boolean isDebt, String description, String label, String reference) {

		return new CurrentPremium(amount, isDebt, description, label,
				reference, InvoiceItemType.CURRENT_PREMIUM);
	}

	public static InvoiceItem createAndGetAdjustment(Amount amount,
			boolean isDebt, String description, String label, String reference) {

		return new Adjustment(amount, isDebt, description, label, reference,
				InvoiceItemType.ADJUSTMENT);
	}

	public static InvoiceItem createAndGetFee(Amount amount, boolean isDebt,
			String description, String label, String reference) {
		return new Fee(amount, isDebt, description, label, reference,
				InvoiceItemType.FEE);
	}

	public static InvoiceItem createAndGetPriorDue(Amount amount,
			boolean isDebt, String description, String label, String reference) {
		return new PriorDue(amount, isDebt, description, label, reference,
				InvoiceItemType.PRIOR_DUE);
	}

	public static InvoiceItem createAndGetCredit(Amount amount, boolean isDebt,
			String description, String label, String reference) {
		return new Credit(amount, isDebt, description, label, reference,
				InvoiceItemType.CREDIT);
	}

	public static InvoiceItem createAndGetOutstandinBalance(Amount amount,
			boolean isDebt, String description, String label, String reference) {
		return new OutstandingBalance(amount, isDebt, description, label,
				reference, InvoiceItemType.OUTSTANDING_ACCOUNT_BALANCE);
	}

	public static InvoiceItem createAndGetPercentageDiscount(Amount amount,
			boolean isDebt, String description, String label, String reference) {
		return new PercentageDiscount(amount, isDebt, description, label,
				reference, InvoiceItemType.DISCOUNT);
	}

	public static InvoiceItem createAndGetAbsoluteDiscount(Amount amount,
			boolean isDebt, String description, String label, String reference) {
		return new AbsoluteDiscount(amount, isDebt, description, label,
				reference, InvoiceItemType.DISCOUNT);
	}

	public static InvoiceItem createAndGetAPTC(Amount amount, boolean isDebt,
			String description, String label, String reference) {
		return new APTC(amount, isDebt, description, label, reference,
				InvoiceItemType.APTC);
	}
	
	public static InvoiceItem createAndGetTax(Amount amount, boolean isDebt,
			String description, String label, String reference) {
		return new Tax(amount, isDebt, description, label, reference,
				InvoiceItemType.TAX);
	}

	public DateTime getAssociatedDate() {
		return associatedDate;
	}

	public void setAssociatedDate(DateTime associatedDate) {
		this.associatedDate = associatedDate;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	
}
