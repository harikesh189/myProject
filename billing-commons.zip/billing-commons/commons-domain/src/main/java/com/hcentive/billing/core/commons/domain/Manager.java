/**
 * 
 */
package com.hcentive.billing.core.commons.domain;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.api.ManagesEntity;
import com.hcentive.billing.core.commons.util.RandomGenerator;

/**
 * @author Dikshit.Vaid
 * 
 */
@Entity
@DiscriminatorValue("Manager")
public class Manager extends User implements ManagesEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6387144347159895515L;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "reference_set_id")
	@Access(AccessType.FIELD)
	private ReferenceSet manages = new ReferenceSet();

	@ElementCollection(fetch = FetchType.EAGER)
	@Column(name = "managesbeof_types")
	@CollectionTable(name = "manager_managesbeof_types", joinColumns = @JoinColumn(name = "manager_id"))
	private Set<String> managesBEofTypes = new HashSet<>();
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "manager_managed_entities", joinColumns = @JoinColumn(name = "manager_id"), inverseJoinColumns = @JoinColumn(name = "be_id"))
	private final Set<BusinessEntity> managedEntities = new HashSet<BusinessEntity>(0);

	public void setManagesBEofTypes(Set<String> managesBEofTypes) {
		this.managesBEofTypes = managesBEofTypes;
	}

	public Set<String> getManagesBEofTypes() {
		return managesBEofTypes;
	}

	public boolean associate(final ManagedEntity entity) {
		if (entity != null && managesBEofTypes.contains(entity.getType())) {
			manages.add(entity.toReference());
			if(entity instanceof BusinessEntity){
				managedEntities.add((BusinessEntity) entity);
			}
			return true;
		}
		return false;
	}

	public Collection<Reference> getManagedEntities() {
		return Collections.unmodifiableSet(manages.getReferences());
	}

	public void disassociate(final ManagedEntity entity) {
		if (entity != null){
			manages.remove(entity.toReference());
			if(entity instanceof BusinessEntity){
				managedEntities.remove(entity);
			}
		}
			
	}

	public void addManagedEntities(Collection<ManagedEntity> entities) {

		if (entities != null) {
			for (final ManagedEntity entity : entities) {
				associate(entity);
			}
		}
	}

	public boolean manages(final Object entityId) {
		if (entityId != null) {
			for (final Reference r : manages.getReferences()) {
				final Object refId = r.getReferenceId();
				if (refId.equals(entityId)) {
					return true;
				}
			}
		}
		return false;
	}

	public Reference managedEntity(final Object entityId) {
		if (entityId != null) {
			for (final Reference r : manages.getReferences()) {
				final Object refId = r.getReferenceId();
				if (refId.equals(entityId)) {
					return r;
				}
			}
		}
		return null;
	}

	public static Manager createNewManager(String identity,
			final PersonalProfile profile, final Set<Role> roles) {
		if (profile == null || roles == null || roles.size() == 0) {
			throw new IllegalArgumentException(
					"Profile and Role are mandatory.");
		}
		if (identity == null) {
			identity = RandomGenerator.randomString();
		}
		// this piece of code is to set name inside profile when adding operator user.
		if(profile !=null    ){
			String name="";
			String firstName= profile.getFirstName();
			String middleName= profile.getMiddleName();
			String lastName= profile.getLastName();
			name =(null != firstName ? firstName + " " : "")
			+ (null != middleName ? middleName + " " : "")
			+ (null != lastName ? lastName : "");
			profile.setName(name);
		}
		return new Manager(identity, profile, roles);
	}

	protected Manager() {

	}

	protected Manager(final String identity, final PersonalProfile profile,
			final Set<Role> roles) {
		super(identity, profile, roles);
	}
}
