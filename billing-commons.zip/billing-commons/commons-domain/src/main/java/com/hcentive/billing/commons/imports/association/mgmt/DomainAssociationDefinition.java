package com.hcentive.billing.commons.imports.association.mgmt;

public class DomainAssociationDefinition extends
		AbstractAssociationDefinition<String> {

	public MatchCriteria getMatchCriteria() {
		return matchCriteria;
	}

	public void setMatchCriteria(MatchCriteria matchCriteria) {
		this.matchCriteria = matchCriteria;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -5913707826528497408L;
	private String identityOfResolvedObject;
	private MatchCriteria matchCriteria;

	public DomainAssociationDefinition(final AssociationType associationType,
			final MatchCriteria criteria, final Boolean isMandatory) {
		super(associationType, isMandatory);
		matchCriteria = criteria;
	}

	protected DomainAssociationDefinition() {
	}

	@Override
	public String getIdentityOfResolvedObject() {
		return identityOfResolvedObject;
	}

	@Override
	public Boolean resolved() {
		return identityOfResolvedObject != null;
	}

	@Override
	public MatchCriteria matchCriteria() {
		return matchCriteria;
	}

	@Override
	public void setIdentityOfResolvedObject(String identity) {
		identityOfResolvedObject = identity;
	}

	public static DomainAssociationDefinition mandatoryDefinition(
			final AssociationType associationType, final MatchCriteria criteria) {
		return new DomainAssociationDefinition(associationType, criteria, true);
	}

	public static DomainAssociationDefinition nonMandatoryDefinition(
			final AssociationType associationType, final MatchCriteria criteria) {
		return new DomainAssociationDefinition(associationType, criteria, false);
	}
	
}
