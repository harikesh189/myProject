package com.hcentive.billing.core.commons.domain;

import static com.hcentive.billing.core.commons.vo.DateTime.isNull;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Gaurav.Agarwal1
 */
@Embeddable
public class Period implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6689690873131635703L;

	@Embedded
	@AttributeOverride(name = "date", column = @Column(name = "begins_on"))
	private DateTime beginsOn;

	@Embedded
	@AttributeOverride(name = "date", column = @Column(name = "ends_on"))
	private DateTime endsOn;

	public Period() {

	}

	public Period(final DateTime beginsOn, final DateTime endsOn) {
		super();
		this.beginsOn = beginsOn;
		this.endsOn = endsOn;
	}

	public Period(final Date beginsOn, final Date endsOn) {
		this.beginsOn = DateTime.getDateTime(beginsOn);
		this.endsOn = DateTime.getDateTime(endsOn);
	}

	public DateTime getBeginsOn() {
		return this.beginsOn;
	}

	public DateTime getEndsOn() {
		return this.endsOn;
	}

	@JsonIgnore
	public boolean hasIntersection(final Period period2) {
		return hasIntersection(this, period2);
	}

	/**
	 * It checks if this period lies in between specified period range.
	 *
	 * @param period2
	 * @return
	 */
	@JsonIgnore
	public boolean isInBetween(final Period period2) {

		boolean beginsOnLiesInBetween = false;
		if (isNull(this.beginsOn) && isNull(period2.beginsOn)) {
			beginsOnLiesInBetween = true;
		} else if (!isNull(this.beginsOn) && isNull(period2.beginsOn)) {
			// if begins on date is null , it means period started very long
			// time ago. Any valid date will be considered
			// to happen after this only.
			beginsOnLiesInBetween = true;
		} else if (isNull(this.beginsOn) && !isNull(period2.beginsOn)) {
			// if begins on date is null , it means period started very long
			// time ago. Any valid date will be considered
			// to happen after this only.
			beginsOnLiesInBetween = false;
		} else if (!isNull(this.beginsOn)) {
			beginsOnLiesInBetween = this.beginsOn.isAfterOrEquals(period2.beginsOn);
		}

		boolean endsOnLiesInBetween = false;

		if (isNull(this.endsOn) && isNull(period2.endsOn)) {
			endsOnLiesInBetween = true;
		} else if (!isNull(this.endsOn) && isNull(period2.endsOn)) {
			// if endsOn on date is null , it means period will last for ever.
			// Any valid date will be considered
			// to happen before this only.
			endsOnLiesInBetween = true;
		} else if (isNull(this.endsOn) && !isNull(period2.endsOn)) {
			// if endsOn on date is null , it means period will last for ever.
			// Any valid date will be considered
			// to happen before this only.
			endsOnLiesInBetween = false;
		} else if (!isNull(this.endsOn)) {
			endsOnLiesInBetween = this.endsOn.isBeforeOrEquals(period2.endsOn);
		}

		return beginsOnLiesInBetween & endsOnLiesInBetween;
	}

	public void setBeginsOn(final DateTime beginsOn) {
		this.beginsOn = beginsOn;
	}

	public void setEndsOn(final DateTime endsOn) {
		this.endsOn = endsOn;
	}

	public boolean contains(final DateTime date) {
		return (this.beginsOn == null || this.beginsOn.isBeforeOrEquals(date)) && (this.endsOn == null || this.endsOn.isAfterOrEquals(date));

	}

	@Override
	public String toString() {
		return "[beginsOn = " + this.beginsOn + ", endsOn = " + this.endsOn + "]";
	}

	public static Period getIntersection(final Period period1, final Period period2) {

		if (period1 == null) {
			return period2;

		} else if (period2 == null) {
			return period1;

		} else {
			if (hasIntersection(period1, period2)) {

				// from amongst the period1 start date and period start date,
				// the date that is later
				// will be used as the applicable start date.
				final DateTime beginsOn = getLarger(period1.getBeginsOn(), period2.getBeginsOn());

				// from amongst the period1 end date and period end date, the
				// date that is earlier
				// will be used as the applicable start date
				final DateTime endsOn = getSmaller(period1.getEndsOn(), period2.getEndsOn());

				return new Period(beginsOn, endsOn);
			}

			return null;
		}
	}

	/**
	 * It compares if given two period has some intersection inclusive of both start and end date.
	 *
	 * @param period1 The period to be compared with. If start date of period is null, it is considered to be infinitely very far from start end. Any valid date
	 *            will be considered to occur after this.
	 * @param endDate The period to be compared with. If end date of period is null, it is considered to be infinitely very far date. Any valid date will be
	 *            considered to occur before this.
	 * @return true if there is any intersection between two periods.
	 */
	public static boolean hasIntersection(final Period period1, final Period period2) {
		if (!isNull(period1.getBeginsOn()) && period1.getBeginsOn().isInBetween(period2.getBeginsOn(), period2.getEndsOn())) {
			return true;
		}
		if (!isNull(period1.getEndsOn()) && period1.getEndsOn().isInBetween(period2.getBeginsOn(), period2.getEndsOn())) {
			return true;
		}
		if (!isNull(period2.getBeginsOn())) {
			return period2.getBeginsOn().isInBetween(period1.getBeginsOn(), period1.getEndsOn());
		}
		return true;
	}

	private static DateTime getLarger(final DateTime dateTime1, final DateTime dateTime2) {
		if (isNull(dateTime1) && isNull(dateTime2)) {
			return null;
		}
		if (!isNull(dateTime1) && !isNull(dateTime2)) {
			return dateTime1.compareTo(dateTime2) >= 0 ? dateTime1 : dateTime2;
		}
		if (!isNull(dateTime1)) {
			return dateTime1;
		}
		return dateTime2;
	}

	private static DateTime getSmaller(final DateTime dateTime1, final DateTime dateTime2) {
		if (isNull(dateTime1) && isNull(dateTime2)) {
			return null;
		}
		if (!isNull(dateTime1) && !isNull(dateTime2)) {
			return dateTime1.compareTo(dateTime2) <= 0 ? dateTime1 : dateTime2;
		}
		if (!isNull(dateTime1)) {
			return dateTime1;
		}
		return dateTime2;
	}

	public static Period getUnion(final Period period1, final Period period2) {

		if (period1 == null) {
			return period2;
		}

		if (period2 == null) {
			return period1;
		}

		final DateTime beginsOn = getSmaller(period1.getBeginsOn(), period2.getBeginsOn());
		final DateTime endsOn = getLarger(period1.getEndsOn(), period2.getEndsOn());

		return new Period(beginsOn, endsOn);

	}

	public void populateWithUnion(final Period period) {
		if (period != null) {
			this.setBeginsOn(getSmaller(this.getBeginsOn(), period.getBeginsOn()));
			this.setEndsOn(getLarger(this.getEndsOn(), period.getEndsOn()));
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (beginsOn == null ? 0 : beginsOn.hashCode());
		result = prime * result + (endsOn == null ? 0 : endsOn.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Period other = (Period) obj;
		if (beginsOn == null) {
			if (other.beginsOn != null) {
				return false;
			}
		} else if (!beginsOn.equals(other.beginsOn)) {
			return false;
		}
		if (endsOn == null) {
			if (other.endsOn != null) {
				return false;
			}
		} else if (!endsOn.equals(other.endsOn)) {
			return false;
		}
		return true;
	}

}
