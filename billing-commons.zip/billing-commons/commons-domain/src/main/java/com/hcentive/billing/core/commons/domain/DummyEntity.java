package com.hcentive.billing.core.commons.domain;

import javax.persistence.Transient;

public class DummyEntity extends BaseEntity implements VersionableEntity {

	private static final long serialVersionUID = 1909723053780775575L;
	
	@Transient
	private boolean archived = false;

	public DummyEntity() {
	}

	public DummyEntity(Long id) {
		super(id);
	}

	public boolean isArchived() {
		return archived;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}
}