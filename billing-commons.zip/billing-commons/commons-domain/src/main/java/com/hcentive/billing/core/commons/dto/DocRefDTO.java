package com.hcentive.billing.core.commons.dto;

import java.io.Serializable;

public class DocRefDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String identity;
	private String docRefId;
	private String tenantId;
	private String downloadURL;
	
	public String getDownloadURL() {
		return downloadURL;
	}

	public void setDownloadURL(String downloadURL) {
		this.downloadURL = downloadURL;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getDocRefId() {
		return docRefId;
	}

	public void setDocRefId(String docRefId) {
		this.docRefId = docRefId;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	private DocRefDTO(){
	}
	
	public DocRefDTO(final String identity, final String docRefId, String tenantId , final String downloadURL){
		this.identity = identity;
		this.docRefId = docRefId;
		this.tenantId = tenantId;
		this.downloadURL = downloadURL;
	}

	@Override
	public String toString() {
		return "DocRefDTO [identity=" + identity + ", docRefId=" + docRefId
				+ ", tenantId=" + tenantId + ", downloadURL=" + downloadURL
				+ "]";
	}

}
