package com.hcentive.billing.core.commons.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "group")
public class Group extends ReferenceableDomainEntity<Group, String> {

	/**
	 * 
	 */

	protected Group() {
	}

	private static final long serialVersionUID = 8147229578389409375L;

	@Access(AccessType.FIELD)
	@OneToMany(fetch = FetchType.EAGER)
	@PrimaryKeyJoinColumn
	private Set<Reference<String, Customer, String>> customers = new HashSet<Reference<String, Customer, String>>(
			0);

	@OneToOne(cascade = CascadeType.ALL, targetEntity = Profile.class)
	@JoinColumn(name = "profile_id")
	@Access(AccessType.FIELD)
	private Profile profile;

	public Set<Reference<String, Customer, String>> customers() {
		return customers;
	}

	public Group(Long id, String identity, String externalId) {
		super(id, identity, externalId);
	}

	public Group(Long id, String identity) {
		super(id, identity);
	}

	public Group(String identity) {
		super(identity);
	}

	public Group(String identity, String externalId) {
		super(identity, externalId);
	}

	@Override
	public String typeName() {
		return "Group";
	}

	@Override
	public String refValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

}
