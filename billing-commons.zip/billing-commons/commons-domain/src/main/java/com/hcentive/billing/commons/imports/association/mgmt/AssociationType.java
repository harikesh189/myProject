/**
 * 
 */
package com.hcentive.billing.commons.imports.association.mgmt;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

/**
 * @author Dikshit.Vaid
 * @param <RDE>
 * 
 */
public interface AssociationType<RDE extends ReferenceableDomainEntity> extends
		Serializable {

	String getAssociatedObjectEvent();

	Class getAssociatedObjectType();

	String getAssociationType();
}
