package com.hcentive.billing.core.commons.domain;

import java.util.Set;

public interface ReferenceAware {
	public Set<? extends Reference> references();

	public <I, T extends Referenceable, V, R extends Reference<I, T, V>> Set<R> referencesByType(
			Class<T> type, Class<I> identityType, Class<V> refValueType);

	public Set<Reference> referencesByTypeName(String typeName);
}
