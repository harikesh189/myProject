package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.Category;
import com.hcentive.billing.core.commons.domain.enumtype.ContactNumType;
import com.hcentive.billing.core.commons.util.CommonUtility;

@Entity
@Table(name = "contact")
@DiscriminatorValue("ContactNumber")
public class ContactNumber extends Contact {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3414363811476746859L;

	@Access(AccessType.FIELD)
	@Column(name = "number")
	private String number;

	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	@Access(AccessType.FIELD)
	private ContactNumType type;

	@Column(name = "sms_enabled")
	@Access(AccessType.FIELD)
	private boolean smsEnabled;

	private String extension;

	public ContactNumber() {
	}

	protected ContactNumber(final String number, final Category category,
			final ContactNumType type) {
		super(category);
		this.number = CommonUtility.convertToPlainNumber(number);
		this.type = type;
	}

	public String getExtension() {
		return extension;
	}

	public String getNumber() {
		return number;
	}

	public ContactNumType getType() {
		return type;
	}

	public boolean isSmsEnabled() {
		return smsEnabled;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public void setSmsEnabled(boolean smsEnabled) {
		this.smsEnabled = smsEnabled;
	}

	public static ContactNumber newContactNumber(final String number,
			final String category, final String type) {
		ContactNumber num = null;
		Category ctr = null;

		if (null == category) {
			ctr = Category.OTHER;
		} else {
			switch (category.toUpperCase()) {
			case "HOME":
				ctr = Category.HOME;
				break;
			case "WORK":
				ctr = Category.WORK;
				break;
			default:
				ctr = Category.OTHER;
				break;
			}
		}

		if (null == type) {
			num = newLandLineNumber(number, ctr);
		} else {
			switch (type.toUpperCase()) {
			case "MOBILE":
				num = newMobileNumber(number, ctr);
				break;
			case "LANDLINE":
				num = newLandLineNumber(number, ctr);
				break;
			case "FAX":
				num = newFaxNumber(number, ctr);
				break;
			default:
				num = newDefaultNumber(number);
				break;
			}
		}
		return num;
	}

	public static ContactNumber newDefaultNumber(final String number) {
		return newInstance(number, Category.OTHER, ContactNumType.LANDLINE);
	}

	public static ContactNumber newFaxNumber(final String number,
			final Category category) {
		return newInstance(number, category, ContactNumType.FAX);
	}

	public static ContactNumber newInstance(final String number,
			final Category category, final ContactNumType type) {
		return new ContactNumber(number, category, type);
	}

	public static ContactNumber newLandLineNumber(final String number,
			final Category category) {
		return newInstance(number, category, ContactNumType.LANDLINE);
	}

	public static ContactNumber newMobileNumber(final String number,
			final Category category) {
		return newInstance(number, category, ContactNumType.MOBILE);
	}

}
