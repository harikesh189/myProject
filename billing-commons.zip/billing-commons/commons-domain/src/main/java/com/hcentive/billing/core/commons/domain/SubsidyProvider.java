package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "business_entity")
@DiscriminatorValue("SubsidyProvider")
public class SubsidyProvider extends FinancialPartner<OrgProfile> {

	private static final long serialVersionUID = -2281007864015993359L;

	@Override
	public OrgProfile getProfile() {
		return super.getProfile();
	}

	@Override
	public void setProfile(OrgProfile orgProfile) {
		super.setProfile(orgProfile);
	}

	@Override
	public String typeName() {
		return "SubsidyProvider";
	}

	public SubsidyProvider(String identity) {
		super(identity);
		setType("subsidyProvider");
	}

	public SubsidyProvider() {
		super();
		setType("subsidyProvider");
	}

	public SubsidyProvider(String identity, String externalId, String type) {
		super(identity, externalId, type);
	}

}
