package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.hcentive.billing.core.commons.domain.enumtype.CardType;

@Entity
@Table(name = "card")
@DiscriminatorValue("Card")
public class CardDetail extends PaymentMethod {

	@Column(name = "card_vendor")
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private CardType cardVendor;
	@Column(name = "card_number")
	@Access(AccessType.FIELD)
	private String cardNumber;
	@Column(name = "name_on_card")
	@Access(AccessType.FIELD)
	private String nameOnCard;

	@Embedded
	private CardDetailExpirationDate cardExpirationDate;

	@Transient
	private String ccv;

	@Column(name = "card_type")
	@Access(AccessType.FIELD)
	private String cardType;

	public CardType getCardVendor() {
		return cardVendor;
	}

	public void setCardVendor(CardType cardVendor) {
		this.cardVendor = cardVendor;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getNameOnCard() {
		return nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}

	public String getCcv() {
		return ccv;
	}

	public void setCcv(String ccv) {
		this.ccv = ccv;
	}

	protected CardDetail() {
		setIdentifier("Card");
		setIsTokenized("0");
	}

	private CardDetail(final String cardType) {
		this();
		this.cardType = cardType;
	}

	public static CardDetail newDebitCard() {
		return new CardDetail("DEBITCARD");
	}

	public static CardDetail newCreditCard() {
		return new CardDetail("CREDITCARD");
	}

	public CardDetailExpirationDate getCardExpirationDate() {
		return cardExpirationDate;
	}

	public void setCardExpirationDate(
			CardDetailExpirationDate cardExpirationDate) {
		this.cardExpirationDate = cardExpirationDate;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	@Override
	public String getReferenceNumber() {
		return getCardNumber();
	}
}
