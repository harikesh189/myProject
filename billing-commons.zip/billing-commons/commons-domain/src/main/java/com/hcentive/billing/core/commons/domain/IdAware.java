package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

import com.hcentive.billing.core.commons.util.ITransformer;

public interface IdAware<I extends Serializable> {
	I getId();

	static class IdTransformer<I extends Serializable, T extends IdAware<I>> implements ITransformer<T, I> {

		@Override
		public I transform(final T input) {
			return input != null ? input.getId() : null;
		}

		public static final <I extends Serializable, E extends IdAware<I>> IdTransformer<I, E> getInstance() {
			return new IdTransformer<I, E>();
		}

	}
}
