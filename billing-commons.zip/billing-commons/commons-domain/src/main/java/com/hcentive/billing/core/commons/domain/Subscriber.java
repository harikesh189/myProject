package com.hcentive.billing.core.commons.domain;

import javax.persistence.Entity;

@Entity
public class Subscriber extends Member {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6559339238490942800L;

	public String getSubscriberId() {
		return getMemberId();
	}

	public void setSubscriberId(String subscriberId) {
		setMemberId(subscriberId);
	}
}
