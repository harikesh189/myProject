package com.hcentive.billing.core.commons.domain;

import static com.hcentive.billing.core.commons.constant.BillingConstant.PERSONAL_PROFILE;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.Gender;
import com.hcentive.billing.core.commons.domain.enumtype.Status;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "Profile")
@DiscriminatorValue(PERSONAL_PROFILE)
public class PersonalProfile extends Profile {

	/**
	 *
	 */
	private static final long serialVersionUID = 6400247999200376976L;

	public String getSpokenLanguage() {
		return spokenLanguage;
	}

	public void setSpokenLanguage(String spokenLanguage) {
		this.spokenLanguage = spokenLanguage;
	}

	public String getCommunicationLanguage() {
		return communicationLanguage;
	}

	public void setCommunicationLanguage(String communicationLanguage) {
		this.communicationLanguage = communicationLanguage;
	}

	@Column(name = "title")
	@Access(AccessType.FIELD)
	private String title;

	@Column(name = "middle_name")
	@Access(AccessType.FIELD)
	private String middleName;

	@Column(name = "first_name")
	@Access(AccessType.FIELD)
	private String firstName;

	@Column(name = "last_name")
	@Access(AccessType.FIELD)
	private String lastName;

	

	@Column(name = "gender")
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private Gender gender;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "date_of_birth")) })
	@Access(AccessType.FIELD)
	private DateTime dateOfBirth;

	@Column(name = "suffix")
	@Access(AccessType.FIELD)
	private String suffix;

	@Column(name = "prefix")
	@Access(AccessType.FIELD)
	private String prefix;

	@Column(name = "spoken_language")
	private String spokenLanguage;

	@Column(name = "communication_language")
	private String communicationLanguage;

	public PersonalProfile() {

	}

	protected PersonalProfile(String title, String middleName,
			String firstName, String lastName, Gender gender,
			DateTime dateOfBirth, String suffix, String prefix) {
		super.setStatus(Status.SUCCESS);
		this.title = title;
		this.middleName = middleName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.setName(getDisplayName());
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.suffix = suffix;
		this.prefix = prefix;
		
	}

	public String getFirstName() {
		return firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public String getLastName() {
		return lastName;
	}

	/*public String getName() {
		return name;
	}*/

	public String getSuffix() {
		return suffix;
	}

	public String getTitle() {
		return title;
	}

	public Gender getGender() {
		return gender;
	}

	public DateTime getDateOfBirth() {
		return dateOfBirth;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
		setName(getDisplayName());
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
		setName(getDisplayName());
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
		setName(getDisplayName());
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public void setDateOfBirth(DateTime dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	@Override
	public String getDisplayName() {
		return (null != firstName ? firstName + " " : "")
				+ (null != middleName ? middleName + " " : "")
				+ (null != lastName ? lastName : "");
	}

	public void setDisplayName(String displayName) {
		// This is just a hack for JSON deserialization.
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
}
