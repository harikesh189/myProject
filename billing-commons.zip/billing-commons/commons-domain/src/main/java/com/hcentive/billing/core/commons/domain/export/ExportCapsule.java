/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.domain.export;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.vo.DateTime;

@Document(collection = "#{T(com.hcentive.billing.commons.domain.util.ExportCollectionUtil).getCollectionNameForItem()}")
public class ExportCapsule implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3722114231559091762L;

	@Id
	private String id;
	
	private Object shipment;

	private long timestamp;
	private DateTime dateTime;

	public Object getShipment() {
		return shipment;
	}

	public void setShipment(Object shipment) {
		this.shipment = shipment;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(DateTime timestamp) {
		this.timestamp = timestamp.getDate().getTime();
		this.dateTime = timestamp;
	}


}
