package com.hcentive.billing.core.commons.domain;

public class UserActivity extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserActivity(Long id) {
		// TODO Auto-generated constructor stub
	}

}
