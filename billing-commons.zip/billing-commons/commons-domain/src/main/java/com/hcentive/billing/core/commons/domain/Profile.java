package com.hcentive.billing.core.commons.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.hcentive.billing.core.commons.domain.enumtype.Gender;
import com.hcentive.billing.core.commons.domain.enumtype.Status;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity(name = "com.hcentive.billing.core.commons.domain.Profile")
@Table(name = "profile")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "profile_type", discriminatorType = DiscriminatorType.STRING)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "profile_type")
@JsonSubTypes({
		@JsonSubTypes.Type(value = PersonalProfile.class, name = "PersonalProfile"),
		@JsonSubTypes.Type(value = OrgProfile.class, name = "OrgProfile") })
public abstract class Profile extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6660376889544934194L;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "address_id")
	@Access(AccessType.FIELD)
	private ContactSet<Address> addressess;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "contact_number_id")
	@Access(AccessType.FIELD)
	private ContactSet<ContactNumber> contactNumbers;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "email_id")
	@Access(AccessType.FIELD)
	private ContactSet<Email> emails;

	@Column(name = "status", nullable = false)
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private Status status;
	
	@Access(AccessType.FIELD)
	@Column(name = "name")
	private String name;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "contact_person_id")
	private ContactSet<ContactPerson> contactPersons;
	
	

	public ContactSet<Address> getAddressess() {
		return addressess;
	}

	public void setAddressess(ContactSet<Address> addressess) {
		this.addressess = addressess;
	}

	public ContactSet<ContactNumber> getContactNumbers() {
		return contactNumbers;
	}

	public void setContactNumbers(ContactSet<ContactNumber> contactNumbers) {
		this.contactNumbers = contactNumbers;
	}

	public ContactSet<Email> getEmails() {
		return emails;
	}

	public void setEmails(ContactSet<Email> emails) {
		this.emails = emails;
	}

	protected Profile() {

	}

	public abstract String getDisplayName();

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public ContactSet<ContactPerson> getContactPersons() {
		return contactPersons;
	}

	public void setContactPersons(ContactSet<ContactPerson> contactPersons) {
		this.contactPersons = contactPersons;
	}

	public static PersonalProfile createAndGetPersonalProfile(String title,
			String middleName, String firstName, String lastName,
			Gender gender, DateTime dateOfBirth, String suffix, String prefix) {
		return new PersonalProfile(title, middleName, firstName, lastName,
				gender, dateOfBirth, suffix, prefix);
	}
	
	protected void setName(final String name){
		this.name=name;
		informListeners();
	}
	

	public String getName(){
		return this.name;
	}

	public static OrgProfile createAndGetOrgProfile(String name) {
		return new OrgProfile(name);
	}
	
	@Transient
	@org.springframework.data.annotation.Transient
	private transient Set<ProfileChangeListener> listeners = new HashSet<>();

	public void addListener(ProfileChangeListener listener) {
		this.listeners.add(listener);
		informListeners();
	}

	private void informListeners() {
		for (ProfileChangeListener listener : this.listeners) {
			listener.profileUpdated(this);
		}
	}

	public static interface ProfileChangeListener {
		public void profileUpdated(Profile profile);
	}
}
