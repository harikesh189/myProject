package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Operator")
public class Operator extends DomainEntity implements Enterprise {

	private static final long serialVersionUID = 1L;

	@Access(AccessType.FIELD)
	@OneToOne(cascade = CascadeType.ALL, targetEntity = Profile.class)
	@JoinColumn(name = "profile_id")
	private OrgProfile profile;
	
	public Operator(String identity, String externalId) {
		super(identity);
		this.externalId = externalId;
	}

	public Operator(Long id, String identity) {
		super(id, identity, null);
	}

	public Operator() {
	}

	public Operator(OrgProfile profile) {
		this.profile = profile;
	}

	public OrgProfile getProfile() {
		return profile;
	}

	public void setProfile(OrgProfile profile) {
		this.profile = profile;
	}

	public String getTenant() {
		return this.externalId;
	}

	@Override
	public String getName() {
		return identity;
	}

}