package com.hcentive.billing.core.commons.dto;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.Address;
import com.hcentive.billing.core.commons.domain.PaymentMethod;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.domain.enumtype.ReferenceCategory;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.Amount;

public class BasicPaymentDetails<I extends PaymentMethod> {

	public BasicPaymentDetails() {

	}

	private Amount amount;

	private Amount discount;

	private I paymentInstrument;

	private Address address;

	private String invoiceId;

	private String subscriptionId;

	public String getSubscriptionId() {
		return this.subscriptionId;
	}

	public void setSubscriptionId(final String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	private final Set<Reference> paymentReferences = new HashSet<Reference>();;

	public String getInvoiceId() {
		return this.invoiceId;
	}

	public void setInvoiceId(final String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(final Address address) {
		this.address = address;
	}

	public Amount getAmount() {
		return this.amount;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	public BasicPaymentDetails(final Amount amount) {
		this.amount = amount;
	}

	public Set<Reference> getPaymentReferences() {
		return this.paymentReferences;
	}

	public I getPaymentInstrument() {
		return this.paymentInstrument;
	}

	public void setPaymentInstrument(final I paymentInstrument) {
		this.paymentInstrument = paymentInstrument;
	}

	public Amount getDiscount() {
		return this.discount;
	}

	public void setDiscount(final Amount discount) {
		this.discount = discount;
		if (null != this.discount && !this.discount.isNegative()) {
			final Reference newExternalReference = Reference.newExternalReference(RandomGenerator.randomString(), "DISCOUNT_GIVEN", this.discount.getValue()
					.toString(), "SYSTEM");
			newExternalReference.setCategory(ReferenceCategory.RELATED_ITEM);
			this.paymentReferences.add(newExternalReference);
		}
	}

	public void associateRDEReferences(final ReferenceableDomainEntity from) {
		if (null == from) {
			return;
		}
		this.paymentReferences.add(Reference.newInternalReference(from));
		final Collection<Reference> referenceOfFrom = from.getReferenceSet().getReferences();
		if (referenceOfFrom != null) {
			for (final Reference r : referenceOfFrom) {
				r.getCategory();
				final Reference newRef = r.clone();
				newRef.setCategory(ReferenceCategory.RELATED_ITEM);
				this.paymentReferences.add(newRef);
			}

		}

	}
}
