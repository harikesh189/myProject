/**
 * 
 */
package com.hcentive.billing.commons.model;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.ExternalIdAware;
import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.util.RandomGenerator;

/**
 * @author Dikshit.Vaid
 * 
 */
public class ItemRecord<T> implements IdentityAware, Serializable,ExternalIdAware {

	private T item;
	private ItemMetaInfo itemMetaInfo;
	private String id;
	private String externalId;

	public ItemRecord(T item, ItemMetaInfo itemMetaInfo) {
		this.item = item;
		this.itemMetaInfo = itemMetaInfo;
		this.id = RandomGenerator.randomString();
	}

	public T getItem() {
		return item;
	}
	public void setItemMetaInfo(ItemMetaInfo itemMetaInfo) {
		this.itemMetaInfo = itemMetaInfo;
	}
	public ItemMetaInfo getItemMetaInfo() {
		return itemMetaInfo;
	}

	public String getId() {
		return id;
	}

	@Override
	public String getIdentity() {
		return getId();
	}

	@Override
	public void setIdentity(String identity) {
		// this.id = identity;

	}

	@Override
	public String getExternalId() {
		return externalId;
	}

	@Override
	public void setExternalId(String externalId) {
		this.externalId = externalId;
		
	}

}
