package com.hcentive.billing.core.commons.domain.enumtype;

import java.util.HashMap;
import java.util.Map;

public enum CardType {
	MASTERCARD("M", "MasterCard"), VISA("V", "Visa"), DISCOVER("D", "Discover"), AMERICANEXPRESS(
			"AMEX", "AmericanExpress");
	private final String value;
	private final String name;

	private CardType(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public static CardType parse(final String val) {
		if (val != null) {
			for (CardType type : CardType.values()) {
				if (type.name.equalsIgnoreCase(val)
						|| val.equalsIgnoreCase("" + type.value)) {
					return type;
				}
			}
			return tryToMatch(val);
		}
		return null;
	}

	private static CardType tryToMatch(final String val) {
		return matchRegistry.get(val.toLowerCase());
	}

	public String getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

	private static Map<String, CardType> matchRegistry = new HashMap<String, CardType>();

	static {
		matchRegistry.put("mastercard", MASTERCARD);
		matchRegistry.put("visa", VISA);
		matchRegistry.put("discover", DISCOVER);
		matchRegistry.put("americanexpress", AMERICANEXPRESS);
		matchRegistry.put("m", MASTERCARD);
		matchRegistry.put("v", VISA);
		matchRegistry.put("d", DISCOVER);
		matchRegistry.put("amex", AMERICANEXPRESS);
		matchRegistry.put("american-express", AMERICANEXPRESS);
		matchRegistry.put("american express", AMERICANEXPRESS);
		matchRegistry.put("american_express", AMERICANEXPRESS);
	}
}
