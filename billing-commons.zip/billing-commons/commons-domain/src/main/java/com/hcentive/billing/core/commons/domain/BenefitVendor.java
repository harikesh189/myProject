package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author ajay.saxena
 * 
 *         New Financial Partner Benefit Vendor for Flex requirment.
 * 
 */
@Entity
@Table(name = "business_entity")
@DiscriminatorValue("BenefitVendor")
public class BenefitVendor extends FinancialPartner<OrgProfile> {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -8497395894386636160L;

	public BenefitVendor(String identity, String externalId, String type) {
		super(identity, externalId, type);
	}

	public BenefitVendor() {
		super();
	}

	public BenefitVendor(String identity) {
		super(identity);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String typeName() {
		return "BenefitVendor";
	}

}
