package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "wfm_user")
public class UserTenantInfo extends DomainEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Column(name = "tenant_id", insertable = false, updatable = false)
	@Access(AccessType.FIELD)
	private String tenantId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "profile_id")
	@Access(AccessType.FIELD)
	private PersonalProfile profile;
	
	public PersonalProfile getProfile() {
		return profile;
	}
	
	public String getTenantId(){
		return this.tenantId;
	}
	
	protected UserTenantInfo(){}
	
	public UserTenantInfo(final String tenantId,final String identity){
		super(identity);
		this.tenantId = tenantId;		
	}

}
