package com.hcentive.billing.core.commons.domain.converter;

import java.io.IOException;
import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.vo.Amount;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

public class AmountReadConverter implements Converter<DBObject, Amount> {
	Logger LOGGER = LoggerFactory.getLogger(AmountReadConverter.class);
	@Override
	public Amount convert(DBObject source) {
		ObjectMapper objectMapper= new ObjectMapper();
		if(source !=null && source.get("value") !=null){
			source.put("value", new BigDecimal(source.get("value").toString()));
			source.removeField("_class");
			try {
				return objectMapper.readValue(JSON.serialize(source), Amount.class);
			} catch (JsonParseException e) {
				LOGGER.error("Error while converting amount after retrieving it from mongo, ", e);
			} catch (JsonMappingException e) {
				LOGGER.error("Error while converting amount after retrieving it from mongo, ", e);
			} catch (IOException e) {
				LOGGER.error("Error while converting amount after retrieving it from mongo, ", e);
			}
		}
		return null;
	}

}
