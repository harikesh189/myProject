package com.hcentive.billing.core.commons.domain;

public interface IdentityAware {
	String getIdentity();

	void setIdentity(String identity);
}
