package com.hcentive.billing.core.commons.domain;

import javax.persistence.Entity;

@Entity
public class GenericFinancialPartner extends FinancialPartner<Profile> {

	private static final long serialVersionUID = -1970457602381049455L;

	public GenericFinancialPartner() {
		super();
	}

	@Override
	public String typeName() {
		return "FinancialPartner";
	}

	public GenericFinancialPartner(String identity) {
		this(identity, "GenericFinancialPartner");
	}

	public GenericFinancialPartner(String identity, String type) {
		super(identity);
	}

	public GenericFinancialPartner(String indentity, String externalId,
			String type) {
		super(indentity, externalId, type);
	}

}
