package com.hcentive.billing.core.commons.exception;

public class BillingRecoverableException extends BillingException {

	public BillingRecoverableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BillingRecoverableException(String message, Throwable t) {
		super(message, t);
		// TODO Auto-generated constructor stub
	}

	public BillingRecoverableException(ErrorCode errorCode, String message) {
		super(errorCode, message);
		// TODO Auto-generated constructor stub
	}

}
