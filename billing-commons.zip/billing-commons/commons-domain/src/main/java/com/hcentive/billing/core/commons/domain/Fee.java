package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.InvoiceItemType;
import com.hcentive.billing.core.commons.vo.Amount;

/**
 * 
 * @author Gaurav.Agarwal1
 * 
 */
@Entity
@Table(name = "invoice_item")
@DiscriminatorValue("Fee")
public class Fee extends InvoiceItem {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3622143377544507586L;

	public Fee() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected Fee(Amount amount, boolean isDebt, String description,
			String label, String reference, InvoiceItemType type) {
		super(amount, isDebt, description, label, reference, type);
	}

}
