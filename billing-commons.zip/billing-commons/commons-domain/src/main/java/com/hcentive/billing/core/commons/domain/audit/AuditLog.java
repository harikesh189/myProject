package com.hcentive.billing.core.commons.domain.audit;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

public interface AuditLog<T extends Serializable> extends Serializable {

	AuditMessage message();

	String processId();
	
	DateTime activityTime();
	
	String userId();
	
	String userName();

	AuditEventType type();
	
	AuditWorkStatus status();

	T auditData();
	
}
