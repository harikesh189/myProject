package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.domain.EbillSchedulePayment;

public class RecurringSetupInformation {

	private EbillSchedulePayment recurringSetup;

	private ACHPaymentDetails achPaymentDetails;

	private CardPaymentDetails cardPaymentDetails;

	private TokenPaymentDetails tokenPaymentDetails;

	private String contractId;

	public ACHPaymentDetails getAchPaymentDetails() {
		return achPaymentDetails;
	}

	public void setAchPaymentDetails(ACHPaymentDetails achPaymentDetails) {
		this.achPaymentDetails = achPaymentDetails;
	}

	public CardPaymentDetails getCardPaymentDetails() {
		return cardPaymentDetails;
	}

	public void setCardPaymentDetails(CardPaymentDetails cardPaymentDetails) {
		this.cardPaymentDetails = cardPaymentDetails;
	}

	public EbillSchedulePayment getRecurringSetup() {
		return recurringSetup;
	}

	public void setRecurringSetup(EbillSchedulePayment recurringSetup) {
		this.recurringSetup = recurringSetup;
	}

	public TokenPaymentDetails getTokenPaymentDetails() {
		return tokenPaymentDetails;
	}

	public void setTokenPaymentDetails(TokenPaymentDetails tokenPaymentDetails) {
		this.tokenPaymentDetails = tokenPaymentDetails;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
}
