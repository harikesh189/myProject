package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.api.BusinessEntityAware;

@Entity
@Table(name = "payment_method")
public class EbillPaymentMethod extends
		ReferenceableDomainEntity<EbillPaymentMethod, String> implements
		BusinessEntityAware<BusinessEntity> {

	private static final long serialVersionUID = -4668604309065460574L;

	protected EbillPaymentMethod() {

	}

	public EbillPaymentMethod(String identity) {
		super(identity);
	}

	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status;

	@Column(name = "authorize_for_autopay")
	@Access(AccessType.FIELD)
	private boolean authorizeForAutoPay;
	
	
	@Column(name = "save_payment_info")
	@Access(AccessType.FIELD)
	private boolean savePaymentInfo;
	

	@Column(name = "preferred_payment_method")
	@Access(AccessType.FIELD)
	private boolean preferredPaymentMethod;

	@ManyToOne(targetEntity = BusinessEntity.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "business_id")
	@Access(AccessType.FIELD)
	private BusinessEntity savedFor;

	@OneToOne(targetEntity = PaymentMethod.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "token_instrument_id")
	@Access(AccessType.FIELD)
	private PaymentMethod tokenInstrument;

	@Override
	public String typeName() {
		return "Saved Payment Method";
	}

	@Override
	public String refValue() {
		return identity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BusinessEntity getSavedFor() {
		return savedFor;
	}

	public void setSavedFor(BusinessEntity savedFor) {
		this.savedFor = savedFor;
	}

	public PaymentMethod getTokenInstrument() {
		return tokenInstrument;
	}

	public void setTokenInstrument(PaymentMethod tokenInstrument) {
		this.tokenInstrument = tokenInstrument;
	}

	public boolean isAuthorizeForAutoPay() {
		return authorizeForAutoPay;
	}

	public void setAuthorizeForAutoPay(boolean authorizeForAutoPay) {
		this.authorizeForAutoPay = authorizeForAutoPay;
	}

	public boolean isPreferredPaymentMethod() {
		return preferredPaymentMethod;
	}

	public void setPreferredPaymentMethod(boolean preferredPaymentMethod) {
		this.preferredPaymentMethod = preferredPaymentMethod;
	}

	public boolean isSavePaymentInfo() {
		return savePaymentInfo;
	}

	public void setSavePaymentInfo(boolean savePaymentInfo) {
		this.savePaymentInfo = savePaymentInfo;
	}

	public PaymentMethod getPaymentInstrument() {
		if (tokenInstrument instanceof TokenPaymentMethod) {
			return ((TokenPaymentMethod) tokenInstrument).getTokenizedMethod();
		}
		return null;
	}

	@Override
	public void setBusinessEntity(BusinessEntity businessEntity) {
		setSavedFor(businessEntity);

	}
}
