package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.vo.Amount;

public class SubscriptionAmountTransferDTO {
	String fromSubscriptionId;
	String toSubscriptionId;
	Amount transferAmount;
	
	public String getFromSubscriptionId() {
		return fromSubscriptionId;
	}
	public void setFromSubscriptionId(String fromSubscriptionId) {
		this.fromSubscriptionId = fromSubscriptionId;
	}
	public String getToSubscriptionId() {
		return toSubscriptionId;
	}
	public void setToSubscriptionId(String toSubscriptionId) {
		this.toSubscriptionId = toSubscriptionId;
	}
	public Amount getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(Amount transferAmount) {
		this.transferAmount = transferAmount;
	}
	
	
}
