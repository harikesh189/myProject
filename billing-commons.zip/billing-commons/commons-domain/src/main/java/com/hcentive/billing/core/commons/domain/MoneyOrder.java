package com.hcentive.billing.core.commons.domain;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "money_order")
@DiscriminatorValue("MoneyOrder")
public class MoneyOrder extends PaymentMethod implements Serializable {

	@Column(name = "money_order_number")
	@Access(AccessType.FIELD)
	private String moneyOrderNumber;

	protected MoneyOrder() {
		setIdentifier("MoneyOrder");
	}

	public String getMoneyOrderNumber() {
		return moneyOrderNumber;
	}

	@Override
	public String getReferenceNumber() {
		return getMoneyOrderNumber();
	}

	public void setMoneyOrderNumber(String moneyOrderNumber) {
		this.moneyOrderNumber = moneyOrderNumber;
	}

	public static MoneyOrder newMoneyOrder() {
		return new MoneyOrder();
	}
}
