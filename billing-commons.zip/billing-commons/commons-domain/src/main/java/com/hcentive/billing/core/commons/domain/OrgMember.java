package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "org_member")
public class OrgMember extends BaseEntity {

	@OneToOne
	private PersonalProfile profile;

	@Access(AccessType.FIELD)
	private String memberId;

	public PersonalProfile getProfile() {
		return profile;
	}

	public void setProfile(PersonalProfile profile) {
		this.profile = profile;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

}
