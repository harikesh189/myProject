package com.hcentive.billing.core.commons.dto;

import java.io.Serializable;

/****
 * 
 * @author Prateek.Bansal
 * 
 * @param <D>
 *            Domain object
 * @param <T>
 *            XSD POJO Object
 * @param <M>
 *            MetaInfo
 */
public class ImportPayload<D, T, M> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3769506954847609362L;

	private D domain;

	private final T xsdObject;
	private final M metanInfo;

	public ImportPayload(D d, T t, M m) {
		this.domain = d;
		this.xsdObject = t;
		this.metanInfo = m;
	}

	public void setDomain(D domain) {
		this.domain = domain;
	}

	public D getDomain() {
		return domain;
	}

	public T getXsdObject() {
		return xsdObject;
	}

	public M getMetaInfo() {
		return metanInfo;
	}

}
