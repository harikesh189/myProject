package com.hcentive.billing.core.commons.dto;

import java.math.BigDecimal;

import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.domain.InvoiceSummary;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.Currency;
import com.hcentive.billing.core.commons.vo.DateTime;

public class InvoiceDTO {

	private String invExternaId;
	private DateTime invPaidThrDate;
	private Amount invTotalAmountDue;
	private Amount invPremiumDue;
	private Amount invOutStandingDue;
	private DateTime invDueDate;
	private Amount invMinimumDue;
	private final String identity;
	private String itemRecordId;
	

	public String getItemRecordId() {
		return itemRecordId;
	}

	public void setItemRecordId(String itemRecordId) {
		this.itemRecordId = itemRecordId;
	}

	public InvoiceDTO(String identity) {
		this.identity = identity;
	}

	public String getInvExternaId() {
		return invExternaId;
	}

	public void setInvExternaId(String invExternaId) {
		this.invExternaId = invExternaId;
	}

	public DateTime getInvPaidThrDate() {
		return invPaidThrDate;
	}

	public void setInvPaidThrDate(DateTime invPaidThrDate) {
		this.invPaidThrDate = invPaidThrDate;
	}

	public Amount getInvTotalAmountDue() {
		return invTotalAmountDue;
	}

	public void setInvTotalAmountDue(Amount invTotalAmountDue) {
		this.invTotalAmountDue = invTotalAmountDue;
	}

	public Amount getInvPremiumDue() {
		return invPremiumDue;
	}

	public void setInvPremiumDue(Amount invPremiumDue) {
		this.invPremiumDue = invPremiumDue;
	}

	public DateTime getInvDueDate() {
		return invDueDate;
	}

	public void setInvDueDate(DateTime invDueDate) {
		this.invDueDate = invDueDate;
	}

	public String getIdentity() {
		return identity;
	}
	
	public static InvoiceDTO transformInvoiceToDto(InvoiceSummary next){

		InvoiceDTO invoiceDTO = new InvoiceDTO(next.getIdentity());
		
		invoiceDTO.setInvDueDate(next.getInvoice().getDueDate());
		invoiceDTO.setInvExternaId(next.getInvoice().externalId());
		invoiceDTO.setInvPremiumDue(next.getInvoice().getPayableAmount());
		invoiceDTO.setInvTotalAmountDue(next.getInvoice().getPayableAmount());
		invoiceDTO.setItemRecordId(next.getInvoice().getItemRecordId());
		invoiceDTO.setInvMinimumDue(next.getInvoice().getMinimumPayableAmount());
		
		Amount outstandingAmount = next.getInvoice().getPayableAmount().subtract(next.getAmountPaid()).subtract(next.getDiscount());
		
		if(outstandingAmount.isNegativeOrZero())
			outstandingAmount = new Amount();	
		
		invoiceDTO.setInvOutStandingDue(outstandingAmount);
		return invoiceDTO;
	}

	public Amount getInvMinimumDue() {
		return invMinimumDue;
	}

	public void setInvMinimumDue(Amount invMinimumDue) {
		this.invMinimumDue = invMinimumDue;
	}

	public Amount getInvOutStandingDue() {
		return invOutStandingDue;
	}

	public void setInvOutStandingDue(Amount invOutStandingDue) {
		this.invOutStandingDue = invOutStandingDue;
	}
	
}