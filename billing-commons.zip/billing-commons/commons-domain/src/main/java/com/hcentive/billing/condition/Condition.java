package com.hcentive.billing.condition;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({ @Type(value = Eq.class, name = "EQ"),
		@Type(value = In.class, name = "IN"),
		@Type(value = And.class, name = "AND"),
		@Type(value = Or.class, name = "OR"),
		@Type(value = ContainsAny.class, name = "CONTAINSANY"),
		@Type(value = ContainsAll.class, name = "CONTAINSALL"),
		@Type(value = Gt.class, name = "GT"),
		@Type(value = Lt.class, name = "LT"),
		@Type(value = GtEq.class, name = "GTEQ"),
		@Type(value = LtEq.class, name = "LTEQ")})
public interface Condition extends Serializable {

	boolean evaluate(ConditionContextResolver conditionValueResolver);

	boolean evaluate(Map<String, ?> inputValueMap);

	String getName();
}
