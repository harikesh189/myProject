/**
 * 
 */
package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author Dikshit.Vaid
 * 
 */
@Entity
@Table(name = "Individual")
public class Individual extends ReferenceableDomainEntity<Individual, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8240346721972356606L;

	@OneToOne(cascade = CascadeType.ALL, targetEntity = Profile.class)
	@JoinColumn(name = "profile_id")
	@Access(AccessType.FIELD)
	private Profile profile;

	/**
	 * 
	 */

	public Individual(Long id, String identity, String externalId) {
		super(id, identity, externalId);
	}

	public Individual(String identity, String externalId) {
		super(identity, externalId);
	}

	public Individual(Long id, String identity) {
		super(id, identity);
	}

	public Individual(String identity) {
		super(identity);
	}

	@Override
	public String typeName() {
		return "Individual";
	}

	protected Individual() {
	}

	@Override
	public String refValue() {
		return identity;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

}
