package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "health_plan_product")
public class HealthPlanProduct extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4571397404745703314L;

	@Access(AccessType.FIELD)
	@Column(name = "product_type")
	private String productType;

	@Access(AccessType.FIELD)
	@Column(name = "issuer_id")
	private String issuerId;

	@Access(AccessType.FIELD)
	@Column(name = "legal_entity_type")
	private String legalEntityType;

	@Access(AccessType.FIELD)
	@Column(name = "domicile_state")
	private String domicileState;

	@Access(AccessType.FIELD)
	@Column(name = "auth_cert_number")
	private String authCertNumber;

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getIssuerId() {
		return issuerId;
	}

	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}

	public String getLegalEntityType() {
		return legalEntityType;
	}

	public void setLegalEntityType(String legalEntityType) {
		this.legalEntityType = legalEntityType;
	}

	public String getDomicileState() {
		return domicileState;
	}

	public void setDomicileState(String domicileState) {
		this.domicileState = domicileState;
	}

	public String getAuthCertNumber() {
		return authCertNumber;
	}

	public void setAuthCertNumber(String authCertNumber) {
		this.authCertNumber = authCertNumber;
	}

}
