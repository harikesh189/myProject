package com.hcentive.billing.core.commons.domain;

public class Identifier {
	private String id; 
	private Type type;
	
	public Identifier(String id, Type type) {
		this.id = id; 
		this. type = type;
	}
	
	public enum Type {
		EIN, SSN, TIN
	}
	
	public String getId() {
		return id; 
	}
	
	public Type getType() {
		return type; 
	}
}
