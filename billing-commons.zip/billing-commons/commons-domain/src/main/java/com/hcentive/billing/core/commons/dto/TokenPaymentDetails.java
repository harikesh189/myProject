package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.domain.TokenPaymentMethod;
import com.hcentive.billing.core.commons.vo.Amount;

public class TokenPaymentDetails extends
		BasicPaymentDetails<TokenPaymentMethod> {

	public TokenPaymentDetails(Amount amount, String cutomerId, String tokenId) {
		super(amount);
		this.setPaymentInstrument(new TokenPaymentMethod(tokenId));
		;
	}

	public TokenPaymentDetails(Amount amount, Amount discount,
			String cutomerId, String tokenId) {
		super(amount);
		this.setDiscount(discount);
		this.setPaymentInstrument(new TokenPaymentMethod(tokenId));
		;
	}

	public TokenPaymentDetails() {

	}

	public String getTokenId() {
		return getPaymentInstrument().getToken();
	}

	public void setTokenId(String tokenId) {
		setPaymentInstrument(new TokenPaymentMethod(tokenId));
	}

	public TokenPaymentMethod getTokenPaymentInstrument() {
		return getPaymentInstrument();
	}

	public void setTokenPaymentInstrument(
			final TokenPaymentMethod tokenPaymentInstrument) {
		setPaymentInstrument(tokenPaymentInstrument);
	}
}
