package com.hcentive.billing.core.commons.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "business_entity")
@DiscriminatorValue("Broker")
public class Broker extends Facilitator {

	/**
	 * Purpose:As @JsonSubTypes.Type doesnt support mapping single class to two
	 * name Use case:Business Entity was not able to map entity with two
	 * different name
	 */
	public Broker(){
		super();
	}
	
	public Broker(final String identity) {
		this(identity, "Broker");
	}

	public Broker(final String identity, final String type) {
		super(identity);
	}

	public Broker(final String identity, final String externalId,
			final String type) {
		super(identity, externalId, type);
	}
	private static final long serialVersionUID = 1L;

}
