package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

public class AutoPaymentDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String ebillRecurringSetup;
	private String invoiceSummary;
	private String subscriptionId;
	private String customerId;
	private String status;
	private DateTime startTime;
	private DateTime endTime;
	private String paymentRefId;
	private int retryCount;

	public AutoPaymentDto(String ebillRecurringSetup, String invoiceSummary,
			String subscriptionId, String customerId, String status,
			DateTime startTime, String paymentRefId) {
		super();
		this.ebillRecurringSetup = ebillRecurringSetup;
		this.invoiceSummary = invoiceSummary;
		this.subscriptionId = subscriptionId;
		this.customerId = customerId;
		this.startTime = startTime;
		this.status = status;
		this.paymentRefId = paymentRefId;

	}

	public String getEbillRecurringSetup() {
		return ebillRecurringSetup;
	}

	public void setEbillRecurringSetup(String ebillRecurringSetup) {
		this.ebillRecurringSetup = ebillRecurringSetup;
	}

	public String getInvoiceSummary() {
		return invoiceSummary;
	}

	public void setInvoiceSummary(String invoiceSummary) {
		this.invoiceSummary = invoiceSummary;
	}

	public String getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public DateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}

	public DateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	public int getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	public String getPaymentRefId() {
		return paymentRefId;
	}

	public void setPaymentRefId(String paymentRefId) {
		this.paymentRefId = paymentRefId;
	}

}
