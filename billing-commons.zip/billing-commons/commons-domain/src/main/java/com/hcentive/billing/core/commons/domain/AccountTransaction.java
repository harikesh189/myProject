package com.hcentive.billing.core.commons.domain;

import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.enumtype.Status;
import com.hcentive.billing.core.commons.domain.enumtype.TransactionType;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 *
 * @author Gaurav.Agarwal1
 *
 */
@Entity
@Table(name = "Account_transaction")
public class AccountTransaction extends ReferenceableDomainEntity<AccountTransaction, String> {
	public static final String FIELD_BUSINESS_ENTITY = "businessEntity";

	private static final long serialVersionUID = 1L;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "date")) })
	@Access(AccessType.FIELD)
	private DateTime date;

	@Column(name = "transaction_type", nullable = false)
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private TransactionType transactionType;

	@Column(name = "description")
	@Access(AccessType.FIELD)
	private String description;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "amount_value")),
		@AttributeOverride(name = "name", column = @Column(name = "amount_name")),
		@AttributeOverride(name = "symbol", column = @Column(name = "amount_symbol")),
		@AttributeOverride(name = "shortName", column = @Column(name = "amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "fre_balance_value")),
		@AttributeOverride(name = "name", column = @Column(name = "fre_balance_name")),
		@AttributeOverride(name = "symbol", column = @Column(name = "fre_balance_symbol")),
		@AttributeOverride(name = "shortName", column = @Column(name = "fre_balance_short_name")) })
	@Access(AccessType.FIELD)
	private Amount fre_balance;

	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "subscription_balance_value")),
		@AttributeOverride(name = "name", column = @Column(name = "subscription_balance_name")),
		@AttributeOverride(name = "symbol", column = @Column(name = "subscription_balance_symbol")),
		@AttributeOverride(name = "shortName", column = @Column(name = "subscription_balance_short_name")) })
	@Access(AccessType.FIELD)
	private Amount subscription_balance;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "subscription_invoice_value")),
		@AttributeOverride(name = "name", column = @Column(name = "subscription_invoice_name")),
		@AttributeOverride(name = "symbol", column = @Column(name = "subscription_invoice_symbol")),
		@AttributeOverride(name = "shortName", column = @Column(name = "subscription_invoice_short_name")) })
	@Access(AccessType.FIELD)
	private Amount subscriptionInvoice;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "subscription_payments_value")),
		@AttributeOverride(name = "name", column = @Column(name = "subscription_payments_name")),
		@AttributeOverride(name = "symbol", column = @Column(name = "subscription_payments_symbol")),
		@AttributeOverride(name = "shortName", column = @Column(name = "subscription_payments_short_name")) })
	@Access(AccessType.FIELD)
	private Amount subscriptionPayments;

	@ManyToOne(targetEntity = Customer.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "financial_responsible_entity")
	@Access(AccessType.FIELD)
	private BusinessEntity businessEntity;

	@ManyToOne(targetEntity = EbillSubscription.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "subscription_id")
	@Access(AccessType.FIELD)
	private EbillSubscription subscription;

	@Column(name = "latest_fre_txn")
	@Access(AccessType.FIELD)
	private boolean latestFRETxn;

	@Column(name = "latest_subscription_txn")
	@Access(AccessType.FIELD)
	private boolean latestSubscriptionTxn;

	/***
	 * Insuspense amount related to subscription over payment
	 */
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "subscription_insuspense_value")),
		@AttributeOverride(name = "name", column = @Column(name = "subscription_insuspense_name")),
		@AttributeOverride(name = "symbol", column = @Column(name = "subscription_insuspense_symbol")),
		@AttributeOverride(name = "shortName", column = @Column(name = "subscription_insuspense_short_name")) })
	@Access(AccessType.FIELD)
	private Amount subscriptionInSuspense = new Amount();

	@Access(AccessType.FIELD)
	private String type;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private Status status;

	public AccountTransaction(final String identity) {
		super(identity);
		this.status = Status.SUCCESS;
	}

	protected AccountTransaction() {
		this.status = Status.SUCCESS;
	}

	private AccountTransaction(final String identity, final DateTime date, final TransactionType transactionType, final String description,
	        final Amount amount, final Amount subscription_balance, final Amount fre_balance, final BusinessEntity<Profile> businessEntity,
	        final EbillSubscription subscription, final String type) {
		this(identity);
		this.date = date;
		this.transactionType = transactionType;
		this.description = description;
		this.amount = amount;
		this.subscription_balance = subscription_balance;
		this.fre_balance = fre_balance;
		this.businessEntity = businessEntity;
		this.subscription = subscription;
		this.type = type;
		if (businessEntity != null) {
			this.setOperator(businessEntity.getOperator());
		}
	}

	public static AccountTransaction createAndGetCreditTransaction(final String identity, final DateTime dateTime, final String description,
	        final Amount amount, final Amount balance, final Amount fre_balance, final BusinessEntity<Profile> businessEntity,
	        final EbillSubscription subscription, final String type) {
		return new AccountTransaction(identity, dateTime, TransactionType.Credit, description, amount, balance, fre_balance, businessEntity, subscription, type);
	}

	public static AccountTransaction createAndGetDebitTransaction(final String identity, final DateTime dateTime, final String description,
	        final Amount amount, final Amount subscription_balance, final Amount fre_balance, final BusinessEntity<Profile> businessEntity,
	        final EbillSubscription subscription, final String type) {
		return new AccountTransaction(identity, dateTime, TransactionType.Debit, description, amount, subscription_balance, fre_balance, businessEntity,
				subscription, type);
	}

	public Amount getAmount() {
		return this.amount;
	}

	public BusinessEntity<Profile> getBusinessEntity() {
		return this.businessEntity;
	}

	public DateTime getDate() {
		return this.date;
	}

	public String getDescription() {
		return this.description;
	}

	public Amount getFre_balance() {
		return this.fre_balance;
	}

	public String getGroupId() {
		final Set<Reference> ref = this.referencesByTypeName("EligibilityContractExternalId");
		for (final Reference reference : ref) {
			return reference.getReferenceId().toString();

		}
		return null;
	}

	public Status getStatus() {
		return this.status;
	}

	public EbillSubscription getSubscription() {
		return this.subscription;
	}

	public Amount getSubscription_balance() {
		return this.subscription_balance;
	}

	public Amount getSubscriptionInSuspense() {
		if (this.subscriptionInSuspense == null) {
			this.subscriptionInSuspense = new Amount();
		}
		return this.subscriptionInSuspense;
	}

	public TransactionType getTransactionType() {
		return this.transactionType;
	}

	public String getType() {
		return this.type;
	}

	public boolean isLatestFRETxn() {
		return this.latestFRETxn;
	}

	public boolean isLatestSubscriptionTxn() {
		return this.latestSubscriptionTxn;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	public void setBusinessEntity(final BusinessEntity<Profile> businessEntity) {
		this.businessEntity = businessEntity;
	}

	public void setDate(final DateTime date) {
		this.date = date;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public void setFre_balance(final Amount fre_balance) {
		this.fre_balance = fre_balance;
	}

	public void setLatestFRETxn(final boolean latestFRETxn) {
		this.latestFRETxn = latestFRETxn;
	}

	public void setLatestSubscriptionTxn(final boolean latestSubscriptionTxn) {
		this.latestSubscriptionTxn = latestSubscriptionTxn;
	}

	public void setStatus(final Status status) {
		this.status = status;

	}

	public void setSubscription(final EbillSubscription subscription) {
		this.subscription = subscription;
	}

	public void setSubscription_balance(final Amount subscription_balance) {
		this.subscription_balance = subscription_balance;
	}

	public void setSubscriptionInSuspense(final Amount subscriptionInSuspense) {
		this.subscriptionInSuspense = subscriptionInSuspense;
	}

	public void setType(final String type) {
		this.type = type;
	}

	@Override
	public String typeName() {
		return "TransactionDetail";
	}

	public Amount getSubscriptionInvoice() {
		return subscriptionInvoice;
	}

	public void setSubscriptionInvoice(Amount subscriptionInvoice) {
		this.subscriptionInvoice = subscriptionInvoice;
	}

	public Amount getSubscriptionPayments() {
		return subscriptionPayments;
	}

	public void setSubscriptionPayments(Amount subscriptionPayments) {
		this.subscriptionPayments = subscriptionPayments;
	}



	
}
