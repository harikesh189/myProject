package com.hcentive.billing.core.commons.api;

import com.hcentive.billing.core.commons.domain.BusinessEntity;

public interface BusinessEntityAware<B extends BusinessEntity> {
	void setBusinessEntity(B businessEntity);
}
