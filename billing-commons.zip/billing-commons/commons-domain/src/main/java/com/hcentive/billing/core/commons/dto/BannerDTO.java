package com.hcentive.billing.core.commons.dto;

import com.hcentive.billing.core.commons.vo.Amount;

public class BannerDTO {
	
	
	private Amount totalDue;
	private Amount totalAmtPaid;
	private Amount balance;
	private Amount nextSchedulePayments;
	private Amount inSuspense;
	
	public BannerDTO(){
		// Initializing the default values
		this.totalDue=new Amount();
		this.totalAmtPaid=new Amount();
		this.balance=new Amount();
		this.nextSchedulePayments=new Amount();
		
	}
	public Amount getTotalDue() {
		return totalDue;
	}
	public void setTotalDue(Amount totalDue) {
		this.totalDue = totalDue;
	}
	public Amount getTotalAmtPaid() {
		return totalAmtPaid;
	}
	public void setTotalAmtPaid(Amount totalAmtPaid) {
		this.totalAmtPaid = totalAmtPaid;
	}
	public Amount getBalance() {
		return balance;
	}
	public void setBalance(Amount balance) {
		if(balance.isNegativeOrZero()){
			this.balance=new Amount();
			setInSuspense(balance);
		}
		else {
		this.balance = balance;
		}
	}
	public Amount getNextSchedulePayments() {
		return nextSchedulePayments;
	}
	public void setNextSchedulePayments(Amount nextSchedulePayments) {
		this.nextSchedulePayments = nextSchedulePayments;
	}
	public Amount getInSuspense() {
		return inSuspense;
	}
	public void setInSuspense(Amount inSuspense) {
		this.inSuspense = inSuspense;
	}
	

}
