package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
 * Non-Persisted Information
 * 
 */
@Entity
@Table(name = "payment_instrument")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING, name = "identifier")
public abstract class PaymentMethod extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3681153100159951628L;
	@Column(name = "identifier")
	@Access(AccessType.FIELD)
	private String identifier;

	public String getIdentifier() {
		if (this instanceof TokenPaymentMethod) {
			StringBuilder identifierBuilder = new StringBuilder();
			identifierBuilder.append(this.identifier);
			if (null != ((TokenPaymentMethod) this).getTokenizedMethod())
				identifierBuilder.append("-").append(
						((TokenPaymentMethod) this).getTokenizedMethod()
								.getIdentifier());
			return identifierBuilder.toString();
		}
		return identifier;
	}

	@Column(name = "IS_TOKENIZED")
	@Access(AccessType.FIELD)
	private String isTokenized = "0";

	public String getIsTokenized() {
		return isTokenized;
	}

	public void setIsTokenized(String isTokenized) {
		this.isTokenized = isTokenized;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public abstract String getReferenceNumber();

}
