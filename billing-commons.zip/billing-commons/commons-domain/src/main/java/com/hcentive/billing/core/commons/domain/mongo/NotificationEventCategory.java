/**
 * 
 */
package com.hcentive.billing.core.commons.domain.mongo;

/**
 * @author Dikshit.Vaid
 *
 */
public enum NotificationEventCategory {
	ACCOUNT,BILLING,DELINQUENCY,REINSTATEMENT,PAYMENT,OTHER;
}
