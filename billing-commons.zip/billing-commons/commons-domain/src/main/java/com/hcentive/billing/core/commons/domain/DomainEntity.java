package com.hcentive.billing.core.commons.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.audit.ExternalIdAwareListner;
import com.hcentive.billing.core.commons.domain.audit.IdentityAwareListener;

@MappedSuperclass
@EntityListeners({ IdentityAwareListener.class, ExternalIdAwareListner.class })
public abstract class DomainEntity extends BaseEntity implements IdentityAware, ExternalIdAware {

	public static final String Identity = "identity";
	public static final String ExternalId = "externalId";
	
	public static final String COLUMN_IDENTITY = "identity";
	public static final String FIELD_IDENTITY = "identity";
	public static final String COLUMN_EXTERNAL_IDENTITY = "external_id";
	public static final String FIELD_EXTERNAL_IDENTITY = "externalId";
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -8657264501368669735L;
	@Column(name = "external_id")
	@Access(AccessType.FIELD)
	protected String externalId;

	@Column(name = "identity", nullable = false, updatable = false)
	@Access(AccessType.FIELD)
	protected String identity;

	@Version
	@Column(name = "version")
	protected long version;

	public DomainEntity(final String identity) {
		this.setIdentity(identity);
	}

	protected DomainEntity() {

	}

	protected DomainEntity(final Long id) {
		super(id);
	}

	protected DomainEntity(final Long id, final String identity, final String externalId) {
		this(id);
		this.setIdentity(identity);
		this.setExternalId(externalId);
		this.version = 0;
	}

	protected DomainEntity(final String identity, final String externalId) {
		this.setIdentity(identity);
		this.setExternalId(externalId);
		this.version = 0;
	}

	// FIXME To be removed
	public final String externalId() {
		return this.getExternalId();
	}

	@Override
	public final String getExternalId() {
		return this.externalId;
	}

	@Override
	public final String getIdentity() {
		return this.identity;
	}

	/**
	 * Gets the version of an entity.
	 * @return The version of an entity.
	 */
	public long getVersion() {
		return this.version;
	}

	@Override
	public void setExternalId(final String externalId) {
		this.externalId = externalId;
	}

	@Override
	public void setIdentity(final String identity) {
		this.identity = identity;
	}

	public final long version() {
		return this.version;
	}

}