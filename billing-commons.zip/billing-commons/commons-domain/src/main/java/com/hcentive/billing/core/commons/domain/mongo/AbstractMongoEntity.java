/**
 *
 */
package com.hcentive.billing.core.commons.domain.mongo;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.ExternalIdAware;
import com.hcentive.billing.core.commons.domain.IdAware;
import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.domain.Persistable;

/**
 * @author Kumar Sambhav Jain
 */
@Document
public class AbstractMongoEntity implements Serializable, IdentityAware, IdAware<String>, ExternalIdAware, Persistable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@CreatedDate
	protected Date dateCreated;

	@Id
	protected String id;

	protected String identity;
	
	protected String externalId;

	@LastModifiedDate
	protected Date lastModified;

	@LastModifiedBy
	protected String lastModifiedBy;

	private transient Boolean newEntity;
	
	private long version;

	@CreatedBy
	protected String createdBy;

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final AbstractMongoEntity other = (AbstractMongoEntity) obj;
		if (this.id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!this.id.equals(other.id)) {
			return false;
		}
		return true;
	}

	/**
	 * @return the dateCreated
	 */
	public Date getDateCreated() {
		return this.dateCreated;
	}

	/**
	 * @return the id
	 */
	@Override
	public String getId() {
		return this.id;
	}

	/**
	 * @return the identity
	 */
	@Override
	public String getIdentity() {
		return this.identity;
	}

	/**
	 * @return the lastModified
	 */
	public Date getLastModified() {
		return this.lastModified;
	}

	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (this.id == null ? 0 : this.id.hashCode());
		return result;
	}

	@JsonIgnore
	public boolean isNew() {
		if (this.newEntity != null) {
			return this.newEntity;
		}
		this.newEntity = this.id == null;
		return this.newEntity;
	}

	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(final Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(final String id) {
		this.id = id;
	}

	/**
	 * @param identity the identity to set
	 */
	@Override
	public void setIdentity(final String identity) {
		this.identity = identity;
	}

	/**
	 * @param lastModified the lastModified to set
	 */
	public void setLastModified(final Date lastModified) {
		this.lastModified = lastModified;
	}

	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(final String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

}
