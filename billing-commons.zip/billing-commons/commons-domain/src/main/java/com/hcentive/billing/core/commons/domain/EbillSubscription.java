package com.hcentive.billing.core.commons.domain;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.enumtype.MarketIndicator;
import com.hcentive.billing.core.commons.domain.enumtype.ReferenceCategory;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.Amount;


@Entity
@Table(name = "subscription")
public class EbillSubscription
		extends ItemRecordAwareEntity<EbillSubscription, String> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5877099535553478764L;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = SubscriptionParty.class, orphanRemoval = true)
	@Access(AccessType.FIELD)
	@JoinTable(name = "subscription_parties", joinColumns = @JoinColumn(name = "subscription_id"), inverseJoinColumns = @JoinColumn(name = "parties_id"))
	private final Set<SubscriptionParty> parties = new HashSet<>();

	@ElementCollection(fetch = FetchType.EAGER)
	@MapKeyColumn(name = "key")
	@Column(name = "value")
	@CollectionTable(name = "subscription_additional_info", joinColumns = @JoinColumn(name = "subscription_additional_info_id"))
	private final Map<String, String> subscriptionAdditionalInfo = new HashMap<>();
	
	@Column(name = "subscription_name")
	private String subscriptionName;
	
	@Column(name = "subscriber_external_id")
	private String subscriberExternalId;
	
	@Column(name = "market_indicator")
	@Enumerated(EnumType.STRING)
	private MarketIndicator marketIndicator;
	
	@Column(name = "status")
	private String status;
	
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "reinstatement_start_date")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "reinstatement_end_date")) })
	@Access(AccessType.FIELD)
	private Period reinstatementWindowPeriod;
	
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "reinstatement_charge_value")),
			@AttributeOverride(name = "name", column = @Column(name = "reinstatement_charge_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "reinstatement_charge_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "reinstatement_charge_short_name")) })
	private Amount reinstatementCharge;
	
	@Embedded
	 @AttributeOverrides({
	   @AttributeOverride(name = "beginsOn.date", column = @Column(name = "start_date")),
	   @AttributeOverride(name = "endsOn.date", column = @Column(name = "end_date")) })
	 @Access(AccessType.FIELD)
	 private Period coveragePeriod;
	
	@Column(name = "is_primary")
	private Boolean isPrimary;
	
	
	public Period getCoveragePeriod() {
	  return coveragePeriod;
	 }
	 public void setCoveragePeriod(Period coveragePeriod) {
	  this.coveragePeriod = coveragePeriod;
	 }
	public Amount getReinstatementCharge() {
		return reinstatementCharge;
	}
	public void setReinstatementCharge(Amount reinstatementCharge) {
		this.reinstatementCharge = reinstatementCharge;
	}
	public Period getReinstatementWindowPeriod() {
		return reinstatementWindowPeriod;
	}
	public void setReinstatementWindowPeriod(Period reinstatementWindowPeriod) {
		this.reinstatementWindowPeriod = reinstatementWindowPeriod;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubscriptionName() {
		return subscriptionName;
	}
	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}
	
	public String getSubscriberExternalId() {
		return subscriberExternalId;
	}
	public void setSubscriberExternalId(String subscriberExternalId) {
		this.subscriberExternalId = subscriberExternalId;
	}
	public Boolean isPrimary() {
		return isPrimary == null || isPrimary == true?true:false;
	}
	public void setPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	}
	public  EbillSubscription( String identity, String externalId) { 
		super(identity, externalId);
	}
	protected EbillSubscription(String identity) {
		super(identity);
	}

	public EbillSubscription() {

	}

	public void add(final SubscriptionParty party) {
		this.parties.add(party);
		if (party != null && party.getParty() != null) {
			this.addReference(party.getParty().toReference());
			this.addReference(party.getParty().extIdReference());
		}
	}
	
	public Reference groupIdReference() {
		
		if(subscriptionAdditionalInfo != null && !subscriptionAdditionalInfo.isEmpty()) {
			
			String groupId = subscriptionAdditionalInfo.get(BillingConstant.GROUP_ID);
			
			if(groupId != null && !"".equals(groupId.trim())) {
				final Reference groupIdReference = Reference.newExternalReference(groupId, BillingConstant.GROUP_ID,
						groupId, this.getTenantId());
				groupIdReference.setCategory(ReferenceCategory.RELATED_ITEM);
				return groupIdReference;
			}
		}
		return null;
	}

	public void addAllParties(final Collection<SubscriptionParty> parties) {
		if (parties != null) {
			for (final SubscriptionParty party : parties) {
				this.add(party);
			}
		}
	}

	public void cleanParties() {
		if (this.parties == null || this.parties.isEmpty()) {
			return;
		}

		this.parties.clear();
	}

	public Set<SubscriptionParty> getParties() {
		return Collections.unmodifiableSet(this.parties);
	}
	@Override
	public String refValue() {
		return getSubscriptionName();
	}

	public Map<String, String> getSubscriptionAdditionalInfo() {
		return Collections.unmodifiableMap(this.subscriptionAdditionalInfo);
	}

	public void addAdditionalInfo(Map<String, String> m) {
		if (m != null) {
			this.subscriptionAdditionalInfo.putAll(m);
		}
	}
	public void addAdditionalInfo(String key, String value) {
		this.subscriptionAdditionalInfo.put(key, value);
	}
	@Override
	public String typeName() {
		return "Subscription";
	}
	public static EbillSubscription createSubscription(String identity, String key, Set<SubscriptionParty> parties){
		EbillSubscription subscription = new EbillSubscription(RandomGenerator.randomReadableString(),identity);
		subscription.addAdditionalInfo(key, identity);
		subscription.addAllParties(parties);
		return subscription;
	}
	
	
	public BusinessEntity getSubscriber(){
		if(this.getParties()==null){
			return null;
		}
		for(SubscriptionParty p : this.getParties()){
			if(p.getQualifier().getValue().equals(PartyQualifier.SUBSCRIBER.getValue())){
				return p.getParty();
			}
			
		}
		return null;
	}
	public MarketIndicator getMarketIndicator() {
		return marketIndicator;
	}
	public void setMarketIndicator(MarketIndicator marketIndicator) {
		this.marketIndicator = marketIndicator;
	}
	public boolean isBeAsParty(String customerId) {
		for(SubscriptionParty party : this.getParties()){
			if(party.getParty().getIdentity().equals(customerId) || party.getParty().getExternalId().equals(customerId)){
				return true;
			}
		}
		return false;
	}

	public Set<SubscriptionParty> getPartiesByQualifier(PartyQualifier partyQualifier){
		Set<SubscriptionParty> qualifiedParties =new HashSet<SubscriptionParty>();
		if(!this.parties.isEmpty()){			
			for (SubscriptionParty subscriptionParty : parties) {
				if(subscriptionParty.getQualifier().equals(partyQualifier)){
				qualifiedParties.add(subscriptionParty);
				}
			}
		}
		return Collections.unmodifiableSet(qualifiedParties);
	}
	
	/***
	 * Remove all Parties on the basis of Party Qualifier
	 * @param partyQualifier
	 */
	public void removePartiesByQualifier(PartyQualifier partyQualifier){	
		
		if(!this.parties.isEmpty()){			
			for (Iterator<SubscriptionParty> iterator = parties.iterator(); iterator.hasNext();) {
				SubscriptionParty subscriptionParty = iterator.next();
				if((subscriptionParty).getQualifier().equals(partyQualifier)){
					iterator.remove();
				}
			}
		}
	}

	
}
