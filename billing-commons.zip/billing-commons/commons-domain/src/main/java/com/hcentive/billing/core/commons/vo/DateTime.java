package com.hcentive.billing.core.commons.vo;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.Period;

@Embeddable
public class DateTime implements Serializable, Comparable<DateTime> {

	public static final String DAY_END_TIME = " 23:59:59";
	private static final List<Integer> TIME_UNIT = asList(Calendar.DATE,
			Calendar.MONTH, Calendar.HOUR, Calendar.MINUTE, Calendar.SECOND,
			Calendar.MILLISECOND, Calendar.YEAR, Calendar.DAY_OF_MONTH);
	private static final long serialVersionUID = -7840779525539645942l;

	@Temporal(TemporalType.TIMESTAMP)
	private final Date date;

	public static DateTime convertDateToDayEndingDate(final DateTime endDate) {
		endDate.getDate().setHours(23);
		endDate.getDate().setMinutes(59);
		endDate.getDate().setSeconds(59);
		return endDate;
	}

	public static DateTime getCurrentTime() {
		final Calendar calendar = Calendar.getInstance();
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public static DateTime getDateTime(final Date date) {
		return date == null ? null : new DateTime(date);
	}

	public static boolean isNull(final DateTime dateTime) {
		return dateTime == null || dateTime.getDate() == null;
	}

	public static DateTime parse(final String dateTime) throws ParseException {
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss Z");
		return new DateTime(sdf.parse(dateTime));
	}

	public static DateTime parseDate(final String dateTime) throws ParseException {
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return new DateTime(sdf.parse(dateTime));
	}

	public static String viewDateFormat(final DateTime dateTime) {

		if (dateTime == null || dateTime.getDate() == null) {
			return "";
		}

		final SimpleDateFormat viewDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		return viewDateFormat.format(dateTime.getDate());
	}

	public DateTime() {
		final Calendar calendar = Calendar.getInstance();
		this.date = calendar.getTime();
	}

	public DateTime(final Date date) {
		this.date = date;
	}

	public DateTime(final long date) {
		this(new Date(date));
	}

	/**
	 * Add the given offset value in specified unit of this date.
	 *
	 * @param offsetValue The value to be added.
	 * @param unit The time unit of the date in which offset value has to be added.
	 * @return
	 */
	public DateTime add(final int offsetValue, final int unit) {
		if (!this.isValidCalenderUnit(unit)) {
			throw new IllegalArgumentException("Invalid time unit.");
		}
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(unit, offsetValue);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public int compareTo(final Date date) {
		return this.getDate().compareTo(date);
	}

	@Override
	public int compareTo(final DateTime o) {
		return this.getDate().compareTo(o.getDate());
	}

	@Override
	public boolean equals(final Object otherObj) {
		if (otherObj instanceof DateTime) {
			final DateTime otherDT = (DateTime) otherObj;
			return this.date.equals(otherDT.date);
		}
		return false;
	}

	public String formatedDateTime() {
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss Z");
		return sdf.format(this.date);
	}

	public Date getDate() {
		return this.date;
	}

	/**
	 * Returns the dat as {@link Calendar} object.
	 *
	 * @return {@link Calendar} representation of the date.
	 */
	@JsonIgnore
	public Calendar getDateAsCalendar() {
		if (this.date != null) {
			final Calendar cal = Calendar.getInstance();
			cal.setTime(this.date);
			return cal;
		} else {
			return null;
		}
	}

	@JsonIgnore
	public DateTime getDatePart() {
		final Calendar cal = Calendar.getInstance();
		cal.setTime(this.getDate());
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return new DateTime(cal.getTime());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (date == null ? 0 : date.hashCode());
		return result;
	}

	public boolean isAfter(final DateTime d1) {
		return this.compareTo(d1) > 0;
	}

	public boolean isAfterOrEquals(final DateTime d1) {
		return this.compareTo(d1) >= 0;
	}

	public boolean isBefore(final DateTime d1) {
		return this.compareTo(d1) < 0;
	}

	public boolean isBeforeOrEquals(final Date d1) {
		return this.compareTo(d1) <= 0;
	}

	public boolean isBeforeOrEquals(final DateTime d1) {
		return this.compareTo(d1) <= 0;
	}

	/**
	 * It compares if this date lies between given start and end date inclusive of both give start date and end date.
	 *
	 * @param startDate The start date to be compared with. If start date is null, it is considered to be infinitely very far before date. Any valid date will
	 *            be considered to occur after this.
	 * @param endDate The end date to be compared with. If end date is null, it is considered to be infinitely very far date. Any valid date will be considered
	 *            to occur before this.
	 * @return true if this date lies between given start and end date or equal to given start or end date.
	 */
	public boolean isInBetween(final DateTime startDate, final DateTime endDate) {
		if (this.getDate() == null) {
			throw new RuntimeException("This date to be compared with is null.");
		}
		if (!isNull(startDate)) {
			if (!isNull(endDate) && startDate.compareTo(endDate) > 0) {
				throw new RuntimeException("Start date can not be after end date.");
			}
			return this.compareTo(startDate) >= 0 && (isNull(endDate) || this.compareTo(endDate) <= 0);
		} else {
			return isNull(endDate) || this.compareTo(endDate) <= 0;
		}
	}

	/**
	 * It compares if this date lies between given period inclusive of both start date and end date of given period.
	 *
	 * @param period The period with which this date has to be compared.
	 * @return true if this date lies between given period.
	 */
	public boolean isInBetween(final Period period) {
		return this.isInBetween(period.getBeginsOn(), period.getEndsOn());
	}

	public DateTime lastDayOfMonth() {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
		return new DateTime(calendar.getTime());
	}

	public DateTime minusDays(final int days) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.DATE, -days);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime minusHour(final int hour) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.HOUR, -hour);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime minusMinutes(final int minutes) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.MINUTE, -minutes);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime minusMonths(final int months) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.MONTH, -months);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime minusSeconds(final int seconds) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.SECOND, -seconds);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime plusDays(final int days) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.DATE, days);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime plusHour(final int hour) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.HOUR, hour);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime plusMinutes(final int minutes) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.MINUTE, minutes);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime plusMonths(final int months) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.MONTH, months);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	public DateTime plusSeconds(final int seconds) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.date);
		calendar.add(Calendar.SECOND, seconds);
		final Date date = calendar.getTime();
		return new DateTime(date);
	}

	@JsonIgnore
	public void setDateAsCalendar(final Object date) {
		// This is just a hack for JSON deserialization.
		throw new UnsupportedOperationException("DateAsCalendar can not be modified.");
	}

	public DateTime setDayOfMonth(final int day) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.getDate());

		calendar.set(this.getDate().getYear() + 1900, this.getDate().getMonth(), day);

		final Date date = calendar.getTime();

		return new DateTime(date);
	}

	@Override
	public String toString() {
		return this.date == null ? "" : this.date.toString();
	}

	private boolean isValidCalenderUnit(final int unit) {
		return TIME_UNIT.contains(unit);
	}
	
	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance();
		
		System.out.println(calendar.getActualMaximum(Calendar.DATE));
		System.out.println(calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		
		System.out.println(calendar.get(Calendar.YEAR));
		Date dt = calendar.getTime();
		System.out.println(dt.getYear());
		
		
		calendar.add(Calendar.MILLISECOND, -1);
		DateTime d1 = new DateTime(calendar.getTime());
		System.out.println(d1);
		
		final DateTime d2 = new DateTime();
		System.out.println(d2);
		System.out.println(d2.isAfter(d1));
		System.out.println(d1.isAfter(d2));
		System.out.println(d1.isAfter(d1));
		
	}

	public static int getLastDayOfMonth(DateTime temp) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(temp.getDate());
		return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
	}
}
