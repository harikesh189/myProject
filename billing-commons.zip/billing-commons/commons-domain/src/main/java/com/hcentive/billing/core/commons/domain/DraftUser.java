/**
 * 
 */
package com.hcentive.billing.core.commons.domain;

import java.util.Set;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.enumtype.UserType;
import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;

/**
 * @author rohit.bansal1
 *	Created for saving draft user information in MongoDb while user registration.
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_draft_user")
public class DraftUser extends AbstractMongoEntity {
	
	private static final long serialVersionUID = -7996374633284757428L;

	private Email email;
	
	private Set<Role> roles;
	
	private Set<String> managesBEofTypes;
	
	private Set<String> beExternalIds;
	
	private String clientAppId;
	
	private String identifier;
	
	private UserType userType;
	
	private PersonalProfile profile;
	

	public PersonalProfile getProfile() {
		return profile;
	}


	public void setProfile(PersonalProfile profile) {
		this.profile = profile;
	}


	public UserType getUserType() {
		return userType;
	}


	public void setUserType(UserType userType) {
		this.userType = userType;
	}


	public Email getEmail() {
		return email;
	}


	public void setEmail(Email email) {
		this.email = email;
	}


	public Set<Role> getRoles() {
		return roles;
	}


	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}


	public Set<String> getManagesBEofTypes() {
		return managesBEofTypes;
	}


	public void setManagesBEofTypes(Set<String> managesBEofTypes) {
		this.managesBEofTypes = managesBEofTypes;
	}


	public Set<String> getBeExternalIds() {
		return beExternalIds;
	}


	public void setBeExternalIds(Set<String> beExternalIds) {
		this.beExternalIds = beExternalIds;
	}


	public String getClientAppId() {
		return clientAppId;
	}


	public void setClientAppId(String clientAppId) {
		this.clientAppId = clientAppId;
	}
	
	public String getIdentifier() {
		return identifier;
	}


	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

}
