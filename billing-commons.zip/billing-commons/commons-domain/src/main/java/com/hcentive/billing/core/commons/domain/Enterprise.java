package com.hcentive.billing.core.commons.domain;

public interface Enterprise {

	public String getName();
}
