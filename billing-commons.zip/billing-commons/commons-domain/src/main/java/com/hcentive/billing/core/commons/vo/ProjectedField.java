package com.hcentive.billing.core.commons.vo;

import java.io.Serializable;

public class ProjectedField implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -945090078759301691L;
	private String mappedField;
	private String entityField;

	public String getMappedField() {
		return mappedField;
	}

	public void setMappedField(String mappedField) {
		this.mappedField = mappedField;
	}

	public String getEntityField() {
		return entityField;
	}

	public void setEntityField(String entityField) {
		this.entityField = entityField;
	}

}
