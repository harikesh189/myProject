package com.hcentive.billing.core.commons.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Role.RoleStatus;

@Entity
@Table(name = "role")
public class RoleInfo extends DomainEntity {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "role_permissions", joinColumns = { @JoinColumn(name = "role_id") }, inverseJoinColumns = { @JoinColumn(name = "permissions_id") })
	private Set<Permission> permissions = new HashSet<Permission>(0);
	
	@Column(name = "code")
	@Access(AccessType.FIELD)
	private String code;
	
	@Column(name = "tenant_id", insertable = false, updatable = false)
	@Access(AccessType.FIELD)
	private String tenantId;
	
	@Column(name = "status")
	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	private RoleStatus status;
	
	public boolean isActive() {
		if (RoleStatus.ACTIVE.equals(this.status)) {
			return true;
		}
		return false;
	}

	public RoleStatus getStatus() {
		return status;
	}
	
	protected RoleInfo(){}
	
	public RoleInfo(String identity) {
		super(identity);
	}
	
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	public String getTenantId() {
		return this.tenantId;
	}
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Set<Permission> getPermissions() {
		return permissions;
	}

	public void setPermissions(Set<Permission> permissions) {
		this.permissions = permissions;
	}

}
