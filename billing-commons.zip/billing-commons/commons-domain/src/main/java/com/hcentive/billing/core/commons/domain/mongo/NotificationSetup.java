/**
 * 
 */
package com.hcentive.billing.core.commons.domain.mongo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_notification_setup")
public class NotificationSetup<T> extends AbstractMongoEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5518912988863538330L;
	private long scheduledOn;
	private T payload;
	private NotificationTemplate notificationTemplate;
	private NotificationRule notificationRule;
	private NotificationSetupStatus notificationSetupStatus;
	private Map<String, String> attributeMap = new HashMap<>();
	private DateTime sentOn;
	private BusinessEntity businessEntity;
	private int count;
	private String messageSubject;
	private String messageBody;
	
	public NotificationSetup(){
		setIdentity();
	}
	public NotificationSetup(T payload) {
		this.payload = payload;
		this.notificationSetupStatus = NotificationSetupStatus.SCHEDULED;
		setIdentity();
	}

	public NotificationSetup(long scheduledOn, T payload,
			NotificationTemplate notificationTemplate) {
		super();
		this.scheduledOn = scheduledOn;
		this.payload = payload;
		this.notificationTemplate = notificationTemplate;
		this.notificationSetupStatus = NotificationSetupStatus.SCHEDULED;
		setIdentity();
	}

	public long getScheduledOn() {
		return scheduledOn;
	}

	public void setScheduledOn(long scheduledOn) {
		this.scheduledOn = scheduledOn;
	}

	public T getPayload() {
		return payload;
	}

	public void setPayload(T payload) {
		this.payload = payload;
	}

	public NotificationTemplate getNotificationTemplate() {
		return notificationTemplate;
	}

	public void setNotificationTemplate(
			NotificationTemplate notificationTemplate) {
		this.notificationTemplate = notificationTemplate;
	}

	public NotificationSetupStatus getNotificationSetupStatus() {
		return notificationSetupStatus;
	}

	public void setNotificationSetupStatus(
			NotificationSetupStatus notificationSetupStatus) {
		this.notificationSetupStatus = notificationSetupStatus;
	}

	public Map<String, String> getAttributeMap() {
		return attributeMap;
	}

	public void setAttributeMap(Map<String, String> attributeMap) {
		this.attributeMap = attributeMap;
	}
	public NotificationRule getNotificationRule() {
		return notificationRule;
	}
	public void setNotificationRule(NotificationRule notificationRule) {
		this.notificationRule = notificationRule;
	}
	public DateTime getSentOn() {
		return sentOn;
	}
	public void setSentOn(DateTime sentOn) {
		this.sentOn = sentOn;
	}
	public BusinessEntity getBusinessEntity() {
		return businessEntity;
	}
	public void setEntity(BusinessEntity businessEntity) {
		this.businessEntity = businessEntity;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getMessageSubject() {
		return messageSubject;
	}
	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}
	public String getMessageBody() {
		return messageBody;
	}
	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}
	
	private void setIdentity(){
		if(this.identity == null || this.identity.trim().length() == 0){
			this.identity = RandomGenerator.randomString();
		}
	}

}
