package com.hcentive.billing.core.commons.domain;

import static com.hcentive.billing.core.commons.constant.BillingConstant.ORG_PROFILE;

import java.util.Collections;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.enumtype.Status;

@Entity
@Table(name = "Profile")
@DiscriminatorValue(ORG_PROFILE)
public class OrgProfile extends Profile {

	private static final long serialVersionUID = -5042273104786065495L;

	@Access(AccessType.FIELD)
	@Column(name = "description")
	private String description;

	@Transient
	@JsonIgnore
	private Set<OrgMember> members;

	public Set<OrgMember> getMembers() {
		return Collections.unmodifiableSet(members);
	}

	public void setMembers(Set<OrgMember> members) {
		this.members = members;
	}


	@ManyToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "parent_id")
	private OrgProfile parentOrg;

	public OrgProfile() {
	}

	public OrgProfile(final String name) {
		super.setStatus(Status.SUCCESS);
		setName(name);
	}

	public OrgProfile(final String name, final String description,
			final OrgProfile parentOrg) {
		super.setStatus(Status.SUCCESS);
		setName(name);
		setDescription(description);
		setParentOrg(parentOrg);
	}

	public String getDescription() {
		return this.description;
	}

	@Override
	public String getDisplayName() {
		return this.getName();
	}

	public String getName() {
		if (null ==super.getName())
			return null;
		return super.getName().trim();
	}

	public OrgProfile getParentOrg() {
		return this.parentOrg;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public void setName(final String name) {
		if (name != null)
			super.setName(name.trim());
			//this.name = name.trim();
	}

	public void setParentOrg(final OrgProfile parentOrg) {
		this.parentOrg = parentOrg;
	}

}
