package com.hcentive.billing.core.commons.domain;

/**
 * It is just a marker interface.
 * 
 * @author nitin.singla
 */
public interface FinancialEventContext {

}
