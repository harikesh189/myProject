#!/bin/bash
clear
echo "Launching Configuration Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/common-configuration-service -Xloggc:/var/log/wfm/common-configuration-service/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar common-configuration-service-1.0.RELEASE.jar --server.port=8114