package com.hcentive.billing.core.commons.service.ebill.configuration.provider;

import java.util.Collection;
import java.util.Collections;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;

/**
 * 
 * @author uttam.tiwari
 * 
 */

@Component
public class SpringDataConfigurationProvider extends
		AbstractPropertyConfigurationParameterReader {

	@Override
	protected Collection<ConfigurationParameter> getAllProperties() {
		// TODO Auto-generated method stub
		return Collections.EMPTY_LIST;
	}

	/*
	 * 
	 * public static interface ConfigurationParameterRepository extends
	 * CrudRepository<StorableConfigurationParameter, Long>{
	 * 
	 * }
	 * 
	 * public static class StorableConfigurationParameter extends
	 * ConfigurationParameter{ private Long id;
	 * 
	 * public Long getId() { return id; }
	 * 
	 * public void setId(Long id) { this.id = id; }
	 * 
	 * }
	 * 
	 * @Override protected Collection<Properties> getProps() { // TODO
	 * Auto-generated method stub return null; }
	 */
}
