package com.hcentive.billing.core.commons.service.ebill.configuration.provider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;
import com.hcentive.billing.core.commons.service.ebill.configuration.util.ConfigurationUtil;

/**
 * 
 * @author uttam.tiwari
 * 
 */
@Component
public class PropertyFileConfigurationParameterReader extends
		AbstractPropertyConfigurationParameterReader {

	private static final String NOTSET = "NOTSET";

	private final Logger logger = LoggerFactory
			.getLogger(PropertyFileConfigurationParameterReader.class);

	@Value("${config.properties.names:NOTSET}")
	private String propertyFileLocationStr;

	private static final String baseDir = System.getProperty("baseDir", ".");
	private static final String propertyDir = File.separator + "config"
			+ File.separator + "properties" + File.separator;

	public PropertyFileConfigurationParameterReader() {
	}

	@Override
	protected Collection<ConfigurationParameter> getAllProperties() {
		logger.debug("base dir::" + baseDir);
		logger.debug("propertydir::" + propertyDir);
		return loadPropertiesFromFiles();
	}

	private Collection<ConfigurationParameter> loadPropertiesFromFiles() {

		if (null == propertyFileLocationStr
				|| propertyFileLocationStr.isEmpty()
				|| propertyFileLocationStr.equals(NOTSET))
			return null;

		String[] propertyFiles = this.propertyFileLocationStr.split(",");
		if (propertyFiles == null || propertyFiles.length == 0)
			return null;

		final Collection<ConfigurationParameter> allConfigParams = new ArrayList<>();
		for (int i = 0; i < propertyFiles.length; i++) {
			allConfigParams.addAll(loadPropertyFile(propertyFiles[i]));
			logger.debug("file ::" + propertyFiles[0] + "successfully loaded.");
		}
		return allConfigParams;
	}

	private List<ConfigurationParameter> loadPropertyFile(final String fileName) {
		/*
		 * check if file name is null or empty , return null.
		 */
		if (null == fileName || fileName.isEmpty()
				|| !fileName.contains(".properties"))
			return null;
		/*
		 * check if fileName complies to standard pattern.
		 */
		String[] fileTokens = fileName.replace(".properties", "").split("_");
		if (null == fileTokens || fileTokens.length < 4) {
			logger.error("Invalid property file name::" + fileName);
			throw new IllegalArgumentException(
					"property file name doesn't comply the standards::"
							+ fileName);
		}
		/*
		 * if validation set. load file
		 */
		final String tenantId = fileTokens[fileTokens.length - 1];
		final String role = fileTokens[fileTokens.length - 2];
		final String type = fileTokens[fileTokens.length - 3];

		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(baseDir + propertyDir + fileName);
		} catch (FileNotFoundException e1) {
			logger.error("erro loading file::" + fileName);
			return Collections.EMPTY_LIST;
		}

		final Properties prop = new Properties();
		List<ConfigurationParameter> configParams = null;
		try {
			prop.load(inputStream);
			configParams = ConfigurationUtil.convertPropToConfigParam(prop,
					tenantId, role, type);
		} catch (Exception e) {
			logger.error("Error reading property file:" + fileName, e);
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				logger.error("Error closing input stream.", e);
			}
		}
		return configParams;
	}

}
