package com.hcentive.billing.core.commons.service.ebill.configuration.repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.persistence.repository.BaseRepository;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;

/**
 * Spring data Repository class to handle operation of Domain Object
 * Configuration.
 * 
 * @author uttam.tiwari
 * 
 */

public interface ConfigurationRepository extends
		BaseRepository<Configuration, Long>, JpaRepository<Configuration, Long> {

	Collection<Configuration> findByTenantIdAndRoleAndType(String tenantid,
			String role, String type);

	Collection<Configuration> findByTenantIdAndRole(String tenantid, String role);

	Collection<Configuration> findByTenantIdAndRoleAndTypeAndKey(
			String tenantid, String role, String type, String key);

	Collection<Configuration> findByTenantId(String tenantid);
}
