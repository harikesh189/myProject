package com.hcentive.billing.core.commons.service.ebill.configuration.provider;

import java.util.Collection;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;

public interface ConfigProviderDBRepo {

	Collection<ConfigurationParameter> fetchConfiguration();

}
