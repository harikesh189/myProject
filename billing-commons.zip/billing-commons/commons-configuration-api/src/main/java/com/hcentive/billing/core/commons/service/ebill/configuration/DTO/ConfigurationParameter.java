package com.hcentive.billing.core.commons.service.ebill.configuration.DTO;

/**
 * @author Uttam Tiwari
 * 
 */
public class ConfigurationParameter {

	public String role;
	public String type;
	public String key;
	public String value;
	public String tenantId;

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getKey() {
		return key;
	}

	public String getRole() {
		return role;
	}

	public String getType() {
		return type;
	}
}
