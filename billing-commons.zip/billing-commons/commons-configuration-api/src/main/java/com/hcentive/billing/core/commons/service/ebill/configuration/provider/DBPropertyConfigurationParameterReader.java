package com.hcentive.billing.core.commons.service.ebill.configuration.provider;

import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;

/**
 * 
 * @author uttam.tiwari
 * 
 */
@Component
public class DBPropertyConfigurationParameterReader extends
		AbstractPropertyConfigurationParameterReader {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DBPropertyConfigurationParameterReader.class);

	@Autowired(required = false)
	private ConfigProviderDBRepo repo;

	@Override
	protected Collection<ConfigurationParameter> getAllProperties() {
		if (null == repo) {
			LOGGER.debug("Repository not initialized. Returning empty collection. This is default implementation.");
			return Collections.EMPTY_LIST;
		} else {
			LOGGER.debug("Repository configured. Will fetch data from the configured repository.");
			return repo.fetchConfiguration();
		}
	}
}
