package com.hcentive.billing.core.commons.service.ebill.configuration.provider;

import java.util.Collection;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;

/**
 * @author uttam.tiwari
 */

public interface ConfigurationParameterProvider {

	Collection<ConfigurationParameter> load();
}
