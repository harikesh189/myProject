package com.hcentive.billing.core.commons.service.ebill.configuration.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.service.ebill.configuration.repository.ConfigurationRepository;
import com.hcentive.billing.core.commons.service.ebill.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * @author Uttam Tiwari
 * 
 */
@Transactional
@Component
public class ConfigurationServiceImpl implements ConfigurationService {

	@Autowired
	private ConfigurationRepository configRepo;

	@Autowired
	private FilterSupportRepository filterSupportRepository;

	private static final Logger logger = LoggerFactory
			.getLogger(ConfigurationServiceImpl.class);

	public Collection<Configuration> fetchAllConfigurationProperties() {
		logger.info("$$$$ fetchAllConfigurationProperties has invoked in service implimentation..##");
		Iterable<Configuration> resultSet = configRepo.findAll();
		// convert iterator in a collection and return
		return ConfigurationUtil.makeCollection(resultSet);
	}

	public void loadConfiguration(List<Configuration> list) {
		logger.info("$$$$Start loadConiguration has invokd in service implimentation..###");
		Collection<Configuration> allConfigs = fetchAllConfigurationProperties();
		for (Configuration configuration : list) {
			if (!isUpdate(configuration, allConfigs)) {
				configRepo.save(configuration);
			}
		}
		logger.info("$$$$End loadConiguration has invokd in service implimentation..###");

	}

	private boolean isUpdate(Configuration configuration,
			Collection<Configuration> allConfigs) {
		for (Configuration config : allConfigs) {
			if (config.getRole().equals(configuration.getRole())
					&& config.getType().equals(configuration.getType())
					&& config.getKey().equals(configuration.getKey())) {
				Configuration updateConfig = configRepo.findOne(config.getId());
				updateConfig.setValue(configuration.getValue());
				configRepo.save(updateConfig);
				logger.debug("config has been updated for role "
						+ configuration.getRole() + "::type::"
						+ configuration.getType() + "::key::"
						+ configuration.getKey());
				return true;
			}
		}

		return false;
	}

	@RequiresPermissions(value = com.hcentive.billing.core.commons.util.Permission.CONFIG_MANAGEMENT)
	public Page<Configuration> fetchConfiguration(final String tenantId,
			SearchCriteria configurationCriteria) {
		logger.info("$$$$ fetchConfiguration has invokd..###");

		if (configurationCriteria != null) {

			return (Page<Configuration>) filterSupportRepository
					.findDomainByFilterCriteria(Configuration.class,
							configurationCriteria);

		} else {
			Collection<Configuration> configCollection = configRepo
					.findByTenantId(tenantId);
			List<Configuration> configList = new ArrayList<Configuration>(
					configCollection);

			return new PageImpl<Configuration>(configList);
		}
	}

	@Override
	public void removeConfig(List<ConfigurationParameter> configParametersList) {
		Collection<Configuration> allConfigs = fetchAllConfigurationProperties();
		logger.info("$$$$ removeConfig has invokd..###");
		for (ConfigurationParameter configuration : configParametersList) {
			final Long id = checkIfConfigurationParametersExists(configuration,
					allConfigs);
			logger.debug("id ::" + id);
			if (id != null) {
				logger.info("loading the confi	guration object to be deleted");
				Configuration config = configRepo.findOne(id);
				logger.info(
						"loaded the configuration object to be deleted with id{} ",
						config.getId());
				configRepo.delete(config);
				logger.info("config object with id {} deleted", config.getId());
			}

		}
		logger.info("$$$$ removeConfig has invokd..###");
		// TODO Auto-generated method stub

	}

	private Long checkIfConfigurationParametersExists(
			ConfigurationParameter configuration,
			Collection<Configuration> allConfigs) {
		logger.info("$$$$ checkIfConfigurationParametersExists has invokd..###");
		if (configuration.getKey() != null && configuration.getRole() != null
				&& configuration.getType() != null) {
			Long id = null;
			for (Configuration config : allConfigs) {
				if (config.getKey().equals(configuration.getKey())
						&& config.getRole().equals(configuration.getRole())
						&& config.getType().equals(configuration.getType())) {
					id = config.getId();
					return id;
				}
			}
		}
		return null;
	}

	@Override
	public Collection<Configuration> searchConfiguration(
			SearchCriteria configurationCriteria) {

		if (configurationCriteria != null) {
			Page<Configuration> result = filterSupportRepository
					.findDomainByFilterCriteria(Configuration.class,
							configurationCriteria);
			if (null != result && result.hasContent())
				return result.getContent();
			else {
				return Collections.EMPTY_LIST;
			}

		}
		return Collections.EMPTY_LIST;
	}
}
