package com.hcentive.billing.core.commons.service.ebill.configuration.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

/**
 * @author uttam.tiwari
 */

@Entity
@Table(name = "configuration")
public class Configuration extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String KEY = "key";

	public static final String TYPE = "type";

	@Column(name = "type")
	@Access(AccessType.FIELD)
	private String type;

	@Column(name = "role")
	@Access(AccessType.FIELD)
	private String role;

	@Column(name = "key")
	@Access(AccessType.FIELD)
	private String key;

	@Column(name = "value")
	@Access(AccessType.FIELD)
	private String value;

	@Column(name = "tenant_id")
	@Access(AccessType.FIELD)
	public String tenantId;

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getType() {
		return type;
	}

	public String getRole() {
		return role;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return key + ":" + value;
	}
}
