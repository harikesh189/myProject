package com.hcentive.billing.core.commons.service.ebill.configuration.domain;

public class ConfigurationConstant {

	public static final String AUTOPAYMENT_CUTOFF_HOUR = "AUTOPAYMENT.CUTOFHOUR";
	public static final String AUTOPAYMENT_RETRY_INTREVAL = "AUTOPAYMENT.RETRYINTREVAL";
	public static final String AUTOPAYMENT_MAX_RETRY = "AUTOPAYMENT.MAXRETRY";
	public static final String DISCOUNT = "DISCOUNT";
	public static final String DMS_CONNECTOR = "DMS.CONNECTOR";
	public static final String DMS_FTP_URL = "DMS.FTP.URL";
	public static final String DMS_FTP_USER = "DMS.FTP.USER";
	public static final String DMS_FTP_PASSWORD = "DMS.FTP.PASSWORD";
	public static final String DMS_FTP_PORT = "DMS.FTP.PORT";
	public static final String DMS_TENANT_FILE_EXTENSION = "DMS.TENANT.FILE.EXTENSION";

}
