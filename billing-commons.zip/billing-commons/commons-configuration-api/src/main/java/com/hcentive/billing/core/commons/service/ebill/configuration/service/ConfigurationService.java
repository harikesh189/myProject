package com.hcentive.billing.core.commons.service.ebill.configuration.service;

import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * @author uttam.tiwari
 */

public interface ConfigurationService {
	Collection<Configuration> fetchAllConfigurationProperties();

	void loadConfiguration(List<Configuration> list);

	Page<Configuration> fetchConfiguration(String tenantId,
			SearchCriteria criteria);

	void removeConfig(List<ConfigurationParameter> configParametersList);

	Collection<Configuration> searchConfiguration(SearchCriteria criteria);
}
