package com.hcentive.billing.core.commons.service.ebill.configuration.provider;

import java.util.Collection;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;

/**
 * 
 * @author uttam.tiwari
 * 
 */
public abstract class AbstractPropertyConfigurationParameterReader implements
		ConfigurationParameterProvider {

	public AbstractPropertyConfigurationParameterReader() {
		super();
	}

	@Override
	public Collection<ConfigurationParameter> load() {
		return getAllProperties();
	}

	protected abstract Collection<ConfigurationParameter> getAllProperties();

}