package com.hcentive.billing.core.commons.service.ebill.configuration.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;

/**
 * @author Uttam Tiwari
 */

/*
 * Its a utility class which converts configurationParameter POJO into a domain
 */
public class ConfigurationUtil {

	public static Configuration getConfigurationDomain(
			ConfigurationParameter configurationParameter) {
		Configuration configurationDomain = new Configuration();

		if (null != configurationParameter) {
			configurationDomain.setKey(configurationParameter.getKey());
			configurationDomain.setType(configurationParameter.getType());
			configurationDomain.setRole(configurationParameter.getRole());
			configurationDomain.setValue(configurationParameter.getValue());
			configurationDomain.setTenantId(configurationParameter
					.getTenantId());
		}
		return configurationDomain;
	}

	public static <E> Collection<E> makeCollection(Iterable<E> iter) {
		Collection<E> list = new ArrayList<E>();
		for (E item : iter) {
			list.add(item);
		}
		return list;
	}

	public static String getConfigValue(List<Configuration> configurations,
			String key) {
		if (configurations != null && key != null) {
			for (Iterator<Configuration> iterator = configurations.iterator(); iterator
					.hasNext();) {
				Configuration configuration = iterator.next();
				if (key.equals(configuration.getKey())) {
					return configuration.getValue();
				}
			}
		}
		return null;

	}

	public static List<ConfigurationParameter> convertPropToConfigParam(
			Properties prop, String tenantId, String role, String type) {
		final List<ConfigurationParameter> configParams = new ArrayList<>();
		final Enumeration enumeration = prop.keys();
		while (enumeration.hasMoreElements()) {
			ConfigurationParameter configParam = new ConfigurationParameter();
			String key = (String) enumeration.nextElement();
			configParam.setKey(key);
			configParam.setValue((String) prop.getProperty(key));
			configParam.setTenantId(tenantId);
			configParam.setRole(role);
			configParam.setType(type);
			configParams.add(configParam);
		}
		return configParams;
	}

}
