package com.hcentive.billing.core.commons.service.ebill.configuration.provider;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.service.ebill.configuration.service.ConfigurationService;
import com.hcentive.billing.core.commons.service.ebill.configuration.util.ConfigurationUtil;

/**
 * @author Uttam Tiwari
 * 
 */

@Component
public class ConfigurationLoader implements InitializingBean {

	private final Logger logger = LoggerFactory
			.getLogger(ConfigurationLoader.class);

	/*
	 * Loads all impls of configurationparameterProviders
	 */
	@Autowired
	private Collection<ConfigurationParameterProvider> providers;

	/*
	 * Service to load props in DB.
	 */
	@Autowired
	private ConfigurationService service;

	/*
	 * Add a new config provider at run time.
	 */
	public void add(ConfigurationParameterProvider provider) {
		providers.add(provider);
		provider.load();
	}

	public void setProviders(
			Collection<ConfigurationParameterProvider> providers) {
		this.providers = providers;
		loadAll();
	}

	public void refresh() {
		loadAll();
	}

	private void loadAll() {
		for (ConfigurationParameterProvider provider : providers) {
			logger.debug("Calling provider::" + provider.getClass());
			Collection<ConfigurationParameter> configParams = provider.load();
			if (null != configParams && !configParams.isEmpty()) {
				logger.debug("loading props into db for provider::"
						+ provider.getClass());
				service.loadConfiguration(convertPropsToDomainProps(configParams));
				logger.debug("Properties for provider::" + provider.getClass()
						+ "loaded into the db.");
			}
		}
	}

	private List<Configuration> convertPropsToDomainProps(
			Collection<ConfigurationParameter> props) {
		final List<Configuration> configEntities = new ArrayList<>();
		for (ConfigurationParameter configurationParameter : props) {
			configEntities.add(ConfigurationUtil
					.getConfigurationDomain(configurationParameter));
		}
		return configEntities;
	}

	/*
	 * private void load(final ConfigurationParameterProvider provider){
	 * logger.debug("Running providere for :"+provider.getClass());
	 * provider.load(); }
	 */
	public void afterPropertiesSet() throws Exception {
		logger.debug("Calling after property set method");
		loadAll();
	}
}
