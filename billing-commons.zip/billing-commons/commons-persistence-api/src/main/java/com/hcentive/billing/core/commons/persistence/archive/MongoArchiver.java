package com.hcentive.billing.core.commons.persistence.archive;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.VersionableEntity;
import com.hcentive.billing.core.commons.domain.enumtype.AuditableOperation;
import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;
import com.mongodb.DBObject;

@Component
public class MongoArchiver extends AbstractMongoEventListener<AbstractMongoEntity> {

	@Autowired
	private ArchiveService archiveService;
	
	@Override
	public void onAfterSave(AbstractMongoEntity source, DBObject dbo) {
		
		if (source instanceof VersionableEntity) {
		
			AuditableOperation operation = source.isNew() ? 
					AuditableOperation.SAVE : AuditableOperation.UPDATE;
			archiveService.archive(source, operation);
		}
	}
	
}
