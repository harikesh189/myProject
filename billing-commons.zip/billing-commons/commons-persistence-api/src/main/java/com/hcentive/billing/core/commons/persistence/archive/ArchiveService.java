/**
 *
 */
package com.hcentive.billing.core.commons.persistence.archive;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.enumtype.AuditableOperation;

/**
 * @author uttam.tiwari
 *
 */
public interface ArchiveService {

	void archive(Serializable olderEntity, AuditableOperation operation);

}
