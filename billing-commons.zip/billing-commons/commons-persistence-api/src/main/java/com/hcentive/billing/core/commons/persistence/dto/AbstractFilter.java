package com.hcentive.billing.core.commons.persistence.dto;


public abstract class AbstractFilter implements ISearchFilter {

	@Override
	public ISearchFilter and(final ISearchFilter searchFilter) {
		if (searchFilter != null) {
			return new And(this, searchFilter);
		}
		return this;
	}

	@Override
	public ISearchFilter or(final ISearchFilter searchFilter) {
		if (searchFilter != null) {
			return new Or(this, searchFilter);
		}
		return this;
	}

}
