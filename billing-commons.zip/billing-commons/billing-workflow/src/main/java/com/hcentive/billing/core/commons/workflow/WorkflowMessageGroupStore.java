package com.hcentive.billing.core.commons.workflow;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.integration.store.AbstractMessageGroupStore;
import org.springframework.integration.store.MessageGroup;
import org.springframework.messaging.Message;

import com.hcentive.billing.commons.workflow.si.WorkflowProcessingSnapshot;
import com.hcentive.billing.core.commons.concurrent.LockProvider;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.util.CollectionUtil;

public class WorkflowMessageGroupStore extends AbstractMessageGroupStore {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(WorkflowMessageGroupStore.class);

	private static final String _WORKFLOW_MESSAGE_GROUP = "_WORKFLOW_MESSAGE_GROUP";

	@Autowired
	private MongoOperations mongo;

	@Autowired
	private LockProvider lockProvider;

	@Override
	public MessageGroup addMessageToGroup(final Object groupId, Message<?> message) {
		LOGGER.debug("adding message to group: {}", groupId);
		final Lock lock = lockProvider.getLock(groupId);
		try {
			lock.lock();
			final String collectionName = resolveCollectionName();
			WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
			if (messageGroup == null) {
				messageGroup = new WorkflowMessageGroup(groupId);
			}	
			if (messageGroup.canAdd(message)) {
				messageGroup.add(message);
				messageGroup.setLastModified(System.currentTimeMillis());
			}
			mongo.save(messageGroup,collectionName);
			LOGGER.debug("Added message to group: {}", groupId);
			return messageGroup;
		} finally {
			lock.unlock();
		}
	}

	private WorkflowMessageGroup getMessageGroupFromMongo(final Object groupId) {
		return mongo.findOne(buildQueryOnIdentity((String)groupId), WorkflowMessageGroup.class, resolveCollectionName());
	}

	private String resolveCollectionName(){
		return TenantUtil.getTenantId()+_WORKFLOW_MESSAGE_GROUP;
	}
	

	private Query buildQueryOnIdentity(final String groupId) {
		final Query query = Query.query(Criteria.where(WorkflowMessageGroup.FIELD_GROUP_ID).is(groupId));
		return query;
	}
	
	@Override
	public MessageGroup getMessageGroup(Object groupId) {
		LOGGER.debug("Fetching messageGroup: {}", groupId);
		final String collectionName = resolveCollectionName();
		final Lock lock = lockProvider.getLock(groupId);
		try {
			lock.lock();
			WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
			if (messageGroup == null) {
				messageGroup = new WorkflowMessageGroup(groupId);
				mongo.save(messageGroup, collectionName);
			}	
			return  messageGroup;
		} finally {
			lock.unlock();
		}
	}

	@Override
	public int messageGroupSize(Object groupId) {
		LOGGER.debug("Checking messageGroup size for group: {}", groupId);
		final WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
		return messageGroup != null ? messageGroup.size() : 0;
	}

	@Override
	public Message<?> pollMessageFromGroup(final Object groupId) {
		LOGGER.debug("Polling messageGroup for group: {}", groupId);
		final Lock lock = lockProvider.getLock(groupId);
		try {
			lock.lock();
			final WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
			if(messageGroup!=null){
				final Collection<Message<?>> messages = messageGroup.getMessages();
				if(messages!=null && !messages.isEmpty()){
					final Message<?> message = messages.iterator().next();
					messageGroup.setLastModified(System.currentTimeMillis());
					mongo.save(messageGroup,resolveCollectionName());
					return message;
				}
			}
			return null;
		} finally {
			lock.unlock();
		}
	}

	@Override
	public void removeMessageGroup(Object groupId) {
		LOGGER.debug("Removing messageGroup : {}", groupId);
		final Lock lock = lockProvider.getLock(groupId);
		try {
			lock.lock();
			final WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
			if(messageGroup!=null){
				mongo.remove(messageGroup, resolveCollectionName());
			}
		} finally {
			lock.unlock();
		}
	}

	@Override
	public void completeGroup(Object groupId) {
		LOGGER.debug("Completing messageGroup : {}", groupId);
		final Lock lock = lockProvider.getLock(groupId);
		try {
			lock.lock();
			final WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
			if (messageGroup != null) {
				messageGroup.complete();
				messageGroup.setLastModified(System.currentTimeMillis());
				mongo.save(messageGroup,resolveCollectionName());
				LOGGER.debug("Completed messageGroup : {}", groupId);
			}
		} finally {
			lock.unlock();
		}
	}

	@Override
	public MessageGroup removeMessageFromGroup(Object groupId, Message<?> message) {
		LOGGER.debug("Removing message from messageGroup : {}", groupId);
		final Lock lock = lockProvider.getLock(groupId);
		try {
			lock.lock();
			final WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
			if (messageGroup != null) {
				final boolean messageRemoved = messageGroup.remove(message);
				if(messageRemoved){
					messageGroup.setLastModified(System.currentTimeMillis());
					mongo.save(messageGroup, resolveCollectionName());;
					LOGGER.debug("Removed message from messageGroup : {}", groupId);
				}
				return messageGroup;
			}
		} finally {
			lock.unlock();
		}
		return null;
	}

	@Override
	public void setLastReleasedSequenceNumberForGroup(Object groupId, int sequenceNumber) {
		LOGGER.debug("Setting LastReleasedSequenceNumberForGroup for messageGroup : {}", groupId);
		final Lock lock = lockProvider.getLock(groupId);
		try {
			lock.lock();
			final WorkflowMessageGroup messageGroup = getMessageGroupFromMongo(groupId);
			if (messageGroup != null) {
				messageGroup.setLastReleasedMessageSequence(sequenceNumber);
				mongo.save(messageGroup,resolveCollectionName());
			}
		} finally {
			lock.unlock();
		}
	}
	
	@Override
	public Iterator<MessageGroup> iterator() {
		return new MessageGroupIterator(this.mongo,this);
	}
	private class MessageGroupIterator implements Iterator<MessageGroup>{
		
		private static final int DEFAULT_PAGE_SIZE = 10;
		private Page<WorkflowMessageGroup> wrapperPage;
		private final MongoOperations mongo;
		private final WorkflowMessageGroupStore messageStore;
		private int currentPage= -1;
		private int currentItemInPage=-1;
		private String currentGroupId;
		
		private MessageGroupIterator(
				MongoOperations mongo,final WorkflowMessageGroupStore messageStore) {
			this.mongo = mongo;
			this.messageStore = messageStore;
			loadNextPage();
		}
		
		private void loadNextPage(){
			this.currentPage = this.currentPage+1;
			final Pageable pageable = new PageRequest(this.currentPage, DEFAULT_PAGE_SIZE);
			Query query = new Query();
			final String resolveCollectionName = resolveCollectionName();
			final long count = mongo.count(query, resolveCollectionName);
			query.with(pageable);
			List<WorkflowMessageGroup> results = mongo.find(query, WorkflowMessageGroup.class, resolveCollectionName);//this.repository.findAll();
			this.wrapperPage = new PageImpl<>(results, pageable, count);
			this.currentItemInPage = -1;
		}

		@Override
		public boolean hasNext() {
			final int totalPages = this.wrapperPage.getTotalPages();
			if(totalPages>this.currentPage){
				return true;
			}else{
				final long totalElementsInThisPage = this.wrapperPage.getNumberOfElements();
				return currentItemInPage<totalElementsInThisPage;
			}
		}

		@Override
		public MessageGroup next() {
			++currentItemInPage;
			final List<WorkflowMessageGroup> content = this.wrapperPage.getContent();
			if(content.size()>currentItemInPage){
				final WorkflowMessageGroup messageGroup = content.get(currentItemInPage);
				this.currentGroupId = (String)messageGroup.groupId;
				return messageGroup;
			}else{
				if(this.wrapperPage.getTotalPages()>this.currentPage){
					loadNextPage();
					return next();
				}
				return null;
			}
		}

		@Override
		public void remove() {
			if(this.currentGroupId!=null){
				this.messageStore.removeMessageGroup(this.currentGroupId);
			}
		}
		
	}

	
	@Document(collection = "WorkflowMessageGroup")
	public static class WorkflowMessageGroup implements MessageGroup{
		public static final String FIELD_GROUP_ID = "groupId";
		@Id
		private Object groupId;
		
		private final List<WorkflowProcessingSnapshot> messages = new LinkedList<>();

		private long createTimeInMillis;
		
		private volatile long lastModified;
		
		private volatile int lastReleasedMessageSequence;
		
		private volatile boolean complete;

		protected WorkflowMessageGroup() {

		}
		
		protected WorkflowMessageGroup(Object groupId) {
			this(Collections.<WorkflowProcessingSnapshot> emptyList(), groupId, System.currentTimeMillis(), false);
		}
		
		public WorkflowMessageGroup(Collection<WorkflowProcessingSnapshot> messages, Object groupId) {
			this(messages, groupId, System.currentTimeMillis(), false);
		}
		
		public WorkflowMessageGroup(Collection<WorkflowProcessingSnapshot> messages, Object groupId, long timestamp, boolean complete) {
			this.groupId = groupId;
			this.createTimeInMillis = timestamp;
			this.complete = complete;
			for (WorkflowProcessingSnapshot message : messages) {
				if (message != null){
					addMessage(message);
				}
			}
		}

		@Override
		public boolean canAdd(Message<?> message) {
			return true;
		}

		@Override
		public Collection<Message<?>> getMessages() {
			List<Message<?>> result = new LinkedList<>();
			if(CollectionUtil.isNotEmpty(messages)) {
				for (WorkflowProcessingSnapshot message : messages) {
					result.add(message.toMessage());
				}
			}				
			return result;
		}

		@Override
		public Object getGroupId() {
			return groupId;
		}

		@Override
		public int getLastReleasedMessageSequenceNumber() {
			return lastReleasedMessageSequence;
		}

		@Override
		public boolean isComplete() {
			return this.complete;
		}

		@Override
		public void complete() {
			setComplete(true);
		}

		@Override
		public int getSequenceSize() {
			if (size() == 0) {
				return 0;
			}
			return new IntegrationMessageHeaderAccessor(getOne()).getSequenceSize();
		}

		@Override
		public int size() {
			return this.messages.size();
		}

		@Override
		public Message<?> getOne() {
			Message<?> one = messages.get(0).toMessage();
			return one;
		}

		@Override
		public long getTimestamp() {
			return createTimeInMillis;
		}

		@Override
		public long getLastModified() {
			return lastModified;
		}

		public void add(Message<?> message) {
			addMessage(message);
		}
		
		private boolean addMessage(Message<?> message) {
			return this.messages.add(new WorkflowProcessingSnapshot(message));
		}
		
		public boolean remove(Message<?> message) {
			return this.messages.remove(new WorkflowProcessingSnapshot(message));
		}
		
		private boolean addMessage(WorkflowProcessingSnapshot message) {
			return this.messages.add(message);
		}
		
		public boolean remove(WorkflowProcessingSnapshot message) {
			return this.messages.remove(message);
		}
		
		public void setLastModified(long lastModified){
			this.lastModified = lastModified;
		}

		public long getCreateTimeInMillis() {
			return createTimeInMillis;
		}

		public void setCreateTimeInMillis(long createTimeInMillis) {
			this.createTimeInMillis = createTimeInMillis;
		}

		public int getLastReleasedMessageSequence() {
			return lastReleasedMessageSequence;
		}

		public void setLastReleasedMessageSequence(int lastReleasedMessageSequence) {
			this.lastReleasedMessageSequence = lastReleasedMessageSequence;
		}

		public void setGroupId(String groupId) {
			this.groupId = groupId;
		}

		public void setComplete(boolean complete) {
			this.complete = complete;
		}

	}

}
