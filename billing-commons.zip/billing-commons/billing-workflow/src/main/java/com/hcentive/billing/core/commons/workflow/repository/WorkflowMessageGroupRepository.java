package com.hcentive.billing.core.commons.workflow.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hcentive.billing.core.commons.workflow.WorkflowMessageGroupStore.WorkflowMessageGroup;

public interface WorkflowMessageGroupRepository extends MongoRepository<WorkflowMessageGroup, String>{
	
	
}
