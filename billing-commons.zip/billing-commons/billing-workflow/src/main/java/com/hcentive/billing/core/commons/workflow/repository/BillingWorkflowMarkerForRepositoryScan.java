package com.hcentive.billing.core.commons.workflow.repository;

public interface BillingWorkflowMarkerForRepositoryScan {

}
