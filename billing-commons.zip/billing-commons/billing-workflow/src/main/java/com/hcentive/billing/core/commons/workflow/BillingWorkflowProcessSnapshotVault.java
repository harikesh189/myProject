package com.hcentive.billing.core.commons.workflow;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.hcentive.billing.commons.workflow.si.BaseSIWorkflowManager;
import com.hcentive.billing.commons.workflow.si.WorkflowProcessingSnapshot;
import com.hcentive.billing.commons.workflow.si.WorkflowProcessingSnapshotVault;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

public class BillingWorkflowProcessSnapshotVault implements WorkflowProcessingSnapshotVault {

	private static final String _WORKFLOW_PROCESSING_SNAPSHOT = "_WORKFLOW_PROCESSING_SNAPSHOT";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(BaseSIWorkflowManager.class);
	
	@Autowired
	private MongoOperations mongo;
	
	@Override
	public WorkflowProcessingSnapshot extract(final String processId) {
		if(processId !=null){
			LOGGER.debug("Extracting snapshot for processId: {}",processId);
			final String collectionName = resolveCollectionName();
			final WorkflowProcessingSnapshotWrapper snapshotWrapper = get(
					processId, collectionName);
			//if(snapshotWrapper!=null){
				//remove the snaphot
				mongo.remove(snapshotWrapper, collectionName);
				LOGGER.debug("Removed snapshot post extraction for processId: {}",processId);
			//}
			LOGGER.debug("Extracted snapshot {} for processId: {}",snapshotWrapper,processId);
			return snapshotWrapper.snapshot;
		}else{
			LOGGER.warn("No processId provided for fetching.Returning null.");
			return null;
		}
		
	}

	private WorkflowProcessingSnapshotWrapper get(final String processId,
			final String collectionName) {
		final Query query = buildQueryOnIdentity(processId);
		
		final WorkflowProcessingSnapshotWrapper snapshotWrapper = mongo.findOne(query, WorkflowProcessingSnapshotWrapper.class, collectionName);
		return snapshotWrapper;
	}

	private Query buildQueryOnIdentity(final String processId) {
		final Query query = Query.query(Criteria.where(WorkflowProcessingSnapshotWrapper.FIELD_IDENTITY).is(processId));
		return query;
	}

	private String resolveCollectionName(){
		return TenantUtil.getTenantId()+_WORKFLOW_PROCESSING_SNAPSHOT;
	}
	
	@Override
	public void store(WorkflowProcessingSnapshot snapshot) {
		try {
			mongo.save(new WorkflowProcessingSnapshotWrapper(snapshot),resolveCollectionName());
			LOGGER.debug("saved snapshot for processId: {}",snapshot.processId());
		} catch (Throwable t) {
			LOGGER.error("Error saving workflow snapshot", t);
			throw t;
		}
	}

	@Override
	public boolean exists(final String processId) {
		if(processId !=null){
			LOGGER.debug("Checking snapshot for processId: {}",processId);
			final WorkflowProcessingSnapshotWrapper snapshotWrapper = get(processId, resolveCollectionName());
			return snapshotWrapper!=null;
		}else{
			LOGGER.warn("No processId provided for checking.Returning null.");
			return false;
		}
	}


	public static class WorkflowProcessingSnapshotWrapper {
		
		private static final String  FIELD_IDENTITY = "identity";
		private static final String  FIELD_STATUS = "snapshot.process.status";
		private static final String  FIELD_PROCESS_ID = "snapshot.process.workflowProcessId";
		
		private WorkflowProcessingSnapshot snapshot;
		
		@Id
		private String identity;
		
		private WorkflowProcessingSnapshotWrapper(
				WorkflowProcessingSnapshot snapshot) {
			this.snapshot = snapshot;
			this.identity = snapshot.processId();
		}
		
		protected WorkflowProcessingSnapshotWrapper(){
			
		}
		
	}


	@Override
	public void delete(final String processId) {
		if(processId !=null){
			LOGGER.debug("Deleting snapshot for processId: {}",processId);
			extract(processId);
			LOGGER.debug("Deleted snapshot for processId: {}",processId);
		}
		
	}

	@Override
	public WorkflowProcessingSnapshot get(final String processId) {
		if(processId !=null){
			LOGGER.debug("fetching snapshot for processId: {}",processId);
			final WorkflowProcessingSnapshotWrapper snapshotWrapper = get(processId,resolveCollectionName());
			return snapshotWrapper!=null?snapshotWrapper.snapshot:null;
		}
		return null;
	}

	@Override
	public List<String> findByStatus(String status, Pageable pageable) {
		Query query = new Query();
		query.fields().include(WorkflowProcessingSnapshotWrapper.FIELD_PROCESS_ID);
		query.addCriteria(Criteria.where(WorkflowProcessingSnapshotWrapper.FIELD_STATUS).is(status));
		query.with(pageable);
		
		
		List<WorkflowProcessingSnapshotWrapper> snapshotWrappers = mongo.find(query, WorkflowProcessingSnapshotWrapper.class, resolveCollectionName());
		List<String> snapshots = new ArrayList<String>();
		if (snapshotWrappers != null) {
			for (WorkflowProcessingSnapshotWrapper wrapper : snapshotWrappers) {
				if (wrapper != null && wrapper.snapshot != null) {
					snapshots.add(wrapper.snapshot.processId());
				}
			}
		}
		return snapshots;
	}
}
