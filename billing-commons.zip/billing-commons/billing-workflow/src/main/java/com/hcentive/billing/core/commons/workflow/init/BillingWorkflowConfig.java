package com.hcentive.billing.core.commons.workflow.init;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.hcentive.billing.commons.workflow.si.init.SIWorkflowConfig;
import com.hcentive.billing.commons.workflow.si.support.SIWorkflowUtil;
import com.hcentive.billing.core.commons.workflow.BillingWorkflowProcessSnapshotVault;
import com.hcentive.billing.core.commons.workflow.WorkflowMessageGroupStore;

@Configuration
@Import(SIWorkflowConfig.class)
@EnableMongoRepositories(basePackages={"com.hcentive.billing.core.commons.workflow.repository"})
public class BillingWorkflowConfig {

	
	@Bean
	public BillingWorkflowProcessSnapshotVault billingWorkflowProcessSnapshotVault(){
		return new BillingWorkflowProcessSnapshotVault();
	}
	
	@Bean
	public WorkflowMessageGroupStore workflowMessageGroupStore(){
		WorkflowMessageGroupStore workflowMessageGroupStore = new WorkflowMessageGroupStore();
		SIWorkflowUtil.configureMessageGroupStore(workflowMessageGroupStore);
		return workflowMessageGroupStore;
	}
	
	
	/*
	@Bean
	public DefaultWorkflowProcessingSnapshotVault billingWorkflowProcessSnapshotVault(){
		return new DefaultWorkflowProcessingSnapshotVault();
	}
	
	@Bean
	public SimpleMessageStore workflowMessageGroupStore(){
		SimpleMessageStore workflowMessageGroupStore = new SimpleMessageStore();
		SIWorkflowUtil.configureMessageGroupStore(workflowMessageGroupStore);
		return workflowMessageGroupStore;
	}
	@Bean
	public MethodInvokingFactoryBean registerWorkflowMessageGroupStore(WorkflowMessageGroupStore workflowMessageGroupStore){
		final MethodInvokingFactoryBean factory = new MethodInvokingFactoryBean();
		factory.setTargetClass(SIWorkflowUtil.class);;
		final Object[] arguments = {workflowMessageGroupStore};
		factory.setTargetMethod("configureMessageGroupStore");
		factory.setArguments(arguments);
		return factory;
	}
	
	*/
}
