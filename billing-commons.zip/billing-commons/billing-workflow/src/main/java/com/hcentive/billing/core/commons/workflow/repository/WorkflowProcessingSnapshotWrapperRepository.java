package com.hcentive.billing.core.commons.workflow.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hcentive.billing.core.commons.workflow.BillingWorkflowProcessSnapshotVault;
import com.hcentive.billing.core.commons.workflow.BillingWorkflowProcessSnapshotVault.WorkflowProcessingSnapshotWrapper;

public interface WorkflowProcessingSnapshotWrapperRepository extends MongoRepository<WorkflowProcessingSnapshotWrapper, String>{

}
