package com.hcentive.billing.core.commons.domain.util;

import java.util.Calendar;

import org.springframework.util.Assert;

import com.hcentive.billing.core.commons.enumeration.RoundingMode;
import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.core.commons.vo.DateTime;

public class DateTimeUtils {

	public static DateTime round(DateTime date, RoundingMode roundingMode) {
		Assert.notNull(date, "Invalild date");
		Assert.notNull(roundingMode, "Rounding not specified");
		if (roundingMode == RoundingMode.DAY_END) {
			return roundAtDayEnd(date);
		}
		return roundAtDayStart(date);
	}

	public static DateTime roundAtDayEnd(DateTime date) {
		Assert.notNull(date, "Invalild date");
		return new DateTime(DateUtility.roundAtDayEnd(date.getDate()));
	}

	public static DateTime roundAtDayStart(DateTime date) {
		Assert.notNull(date, "Invalild date");
		return new DateTime(DateUtility.roundAtDayStart(date.getDate()));
	}
	
	public static int getLastDayOfMonth(DateTime dateTime) {
		return DateUtility.getLastDayOfMonth(dateTime.getDate());
	}
	
	public static DateTime setDayOfMonthBoundByMonthEnd(DateTime in, int day) {
		return DateTime.getDateTime(DateUtility.setDayOfMonthBoundByMonthEnd(
				in.getDate(), day));
	}
}
