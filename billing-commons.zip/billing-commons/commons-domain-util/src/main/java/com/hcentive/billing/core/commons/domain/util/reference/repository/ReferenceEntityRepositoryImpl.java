package com.hcentive.billing.core.commons.domain.util.reference.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.domain.util.EntityManagerProvider;

//@Component("referenceEntityRepositoryConc")
public class ReferenceEntityRepositoryImpl implements ReferenceEntityRepository {

	@Override
	public long count() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void delete(
			final Iterable<? extends ReferenceableDomainEntity> entities) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void delete(final Long id) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void delete(final ReferenceableDomainEntity entity) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void deleteAll() {
		throw new UnsupportedOperationException();

	}

	private EntityManager entityManager() {
		return EntityManagerProvider.entityManager();
	}

	@Override
	public boolean exists(final Long id) {
		throw new UnsupportedOperationException();
	}

	@Override
	public Iterable<ReferenceableDomainEntity> findAll() {
		throw new UnsupportedOperationException();
	}

	@Override
	public Iterable<ReferenceableDomainEntity> findAll(final Iterable<Long> ids) {
		throw new UnsupportedOperationException();
	}

	@Override
	public Page<ReferenceableDomainEntity> findAll(final Pageable pageable) {
		throw new UnsupportedOperationException();
	}

	@Override
	public Iterable<ReferenceableDomainEntity> findAll(final Sort sort) {
		throw new UnsupportedOperationException();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <RD extends ReferenceableDomainEntity> RD findDomainByIdentity(
			final Class<RD> domain, final String identity) {

		final StringBuffer queryString = new StringBuffer("SELECT domain from ");

		queryString.append(domain.getSimpleName()).append(" domain ");
		queryString.append(" where lower(domain.identity) = '")
				.append(identity.toLowerCase()).append("'");

		final Query query = this.entityManager().createQuery(
				queryString.toString());
		try {
			return (RD) query.getSingleResult();
		} catch (final Exception e) {
			return null;
		}
	}

	@Override
	public ReferenceableDomainEntity findOne(final Long id) {
		throw new UnsupportedOperationException();
	}

	@Override
	public <S extends ReferenceableDomainEntity> Iterable<S> save(
			final Iterable<S> entities) {
		throw new UnsupportedOperationException();
	}

	@Override
	public <S extends ReferenceableDomainEntity> S save(final S entity) {
		throw new UnsupportedOperationException();
	}
}