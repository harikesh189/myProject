/**
 * 
 */
package com.hcentive.billing.core.commons.domain.util.reference.repository;

import java.io.Serializable;

import org.springframework.data.repository.core.EntityInformation;
import org.springframework.data.repository.core.RepositoryMetadata;
import org.springframework.data.repository.core.support.PersistableEntityInformation;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;
import org.springframework.stereotype.Component;

/**
 * @author Dikshit.Vaid
 * 
 */
@Component
public class ReferenceEntityRepositoryFactory extends RepositoryFactorySupport {

	/*
	 * @Autowired private ApplicationContext appContext;
	 * 
	 * private ReferenceEntityRepository refernceEntityRepository;
	 */

	public ReferenceEntityRepositoryFactory() {
		// this.em = entityManager;
	}

	@Override
	public <T, ID extends Serializable> EntityInformation<T, ID> getEntityInformation(
			Class<T> domainClass) {
		EntityInformation entityInfo = new PersistableEntityInformation(
				domainClass);
		return entityInfo;
	}

	@Override
	protected ReferenceEntityRepository getTargetRepository(
			RepositoryMetadata metadata) {
		return new ReferenceEntityRepositoryImpl();
	}

	@Override
	protected Class<?> getRepositoryBaseClass(RepositoryMetadata metadata) {
		// TODO Auto-generated method stub
		return ReferenceEntityRepositoryImpl.class;
	}
	/*
	 * @Override public void setApplicationContext(ApplicationContext
	 * applicationContext) throws BeansException { this.appContext =
	 * applicationContext; refernceEntityRepository =
	 * (ReferenceEntityRepository) this.appContext
	 * .getBean("referenceEntityRepositoryConc"); }
	 */

}
