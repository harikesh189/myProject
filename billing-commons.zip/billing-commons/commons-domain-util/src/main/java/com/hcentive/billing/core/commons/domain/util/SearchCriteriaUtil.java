package com.hcentive.billing.core.commons.domain.util;

import java.util.ArrayList;
import java.util.List;

import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.domain.InvoiceStatus;
import com.hcentive.billing.core.commons.domain.InvoiceSummary;
import com.hcentive.billing.core.commons.vo.CriteriaOperator;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.xsdtopojo.RequestType;
@SuppressWarnings("deprecation")
public class SearchCriteriaUtil {

	public static SearchCriteria getCurrentInvoiceCriteriaForBE(
			String businessIdentity) {
		SearchCriteria searchCriteria = SearchCriteria
				.createColumnSearchCriteria();
		return getOpenInvoiceCriteriaForBE(businessIdentity, searchCriteria);
	}

	
	public static SearchCriteria getOpenInvoiceCriteriaForBE(
			String businessIdentity, SearchCriteria searchCriteria) {

		if (searchCriteria == null)
			return getCurrentInvoiceCriteriaForBE(businessIdentity);

		if(businessIdentity != null){
			searchCriteria.addSingleValueCriteria(Invoice.BusinessEntity,
				CriteriaOperator.EQUALS, businessIdentity);
		}
		List<String> status = new ArrayList<>();
		status.add(InvoiceStatus.OPEN.getStatus());
		searchCriteria.addMultiValueCriteria(Invoice.STATUS,
				CriteriaOperator.IN, status);
		return searchCriteria;
	}
	
	public static SearchCriteria getLatestInvocieCriteriaForBE(
			String businessIdentity, SearchCriteria searchCriteria) {

		if (searchCriteria == null)
			return getCurrentInvoiceCriteriaForBE(businessIdentity);

		if(businessIdentity != null){
			searchCriteria.addSingleValueCriteria(Invoice.BusinessEntity,
				CriteriaOperator.EQUALS, businessIdentity);
		}
		
		searchCriteria.addSingleValueCriteria(Invoice.CURRENT, CriteriaOperator.EQUALS,true);
		return searchCriteria;
	}

	public static SearchCriteria getCurrentInvoiceSummaryCriteriaForBE(
			String businessIdentity) {
		SearchCriteria searchCriteria = SearchCriteria
				.createColumnSearchCriteria();
		return getCurrentInvoiceSummaryCriteriaForBE(businessIdentity,
				searchCriteria);
	}

	public static SearchCriteria getCurrentInvoiceSummaryCriteriaForBE(
			String businessIdentity, SearchCriteria searchCriteria) {

		if (searchCriteria == null)
			return getCurrentInvoiceSummaryCriteriaForBE(businessIdentity);

		searchCriteria.addSingleValueCriteria(InvoiceSummary.BUSINESS_ENTITY,
				CriteriaOperator.EQUALS, businessIdentity);
		List<String> status = new ArrayList<>();
		status.add(InvoiceStatus.OPEN.getStatus());
		searchCriteria.addMultiValueCriteria(InvoiceSummary.STATUS,
				CriteriaOperator.IN, status);

		return searchCriteria;
	}

	public static SearchCriteria getSearchCriteriaForRequestType(RequestType requestType, int pageSize){
		return null;
	}
}
