package com.hcentive.billing.core.commons.domain.util;

import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.util.ITransformer;

/**
 * Extracts the {@link String} identity from an {@link IdentityAware}.
 */
public class IdentityTransformer<T extends IdentityAware> implements
		ITransformer<T, String> {

	@Override
	public String transform(final T input) {
		return input != null ? input.getIdentity() : null;
	}

	public static final <E extends IdentityAware> IdentityTransformer<E> getInstance() {
		return new IdentityTransformer<E>();
	}
}
