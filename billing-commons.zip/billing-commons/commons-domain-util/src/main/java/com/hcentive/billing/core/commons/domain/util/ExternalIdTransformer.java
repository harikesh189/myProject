package com.hcentive.billing.core.commons.domain.util;

import com.hcentive.billing.core.commons.domain.ExternalIdAware;
import com.hcentive.billing.core.commons.util.ITransformer;

/**
 * Extracts the {@link String} external id from an {@link ExternalIdAware}.
 */
public class ExternalIdTransformer<T extends ExternalIdAware> implements
		ITransformer<T, String> {

	@Override
	public String transform(final T input) {
		return input != null ? input.getExternalId() : null;
	}

	public static final <E extends ExternalIdAware> ExternalIdTransformer<E> getInstance() {
		return new ExternalIdTransformer<E>();
	}
}
