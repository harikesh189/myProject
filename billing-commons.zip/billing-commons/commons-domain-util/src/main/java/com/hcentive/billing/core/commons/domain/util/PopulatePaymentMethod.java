package com.hcentive.billing.core.commons.domain.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Ach;
import com.hcentive.billing.core.commons.domain.CardDetail;
import com.hcentive.billing.core.commons.domain.CardDetailExpirationDate;
import com.hcentive.billing.core.commons.domain.Cash;
import com.hcentive.billing.core.commons.domain.MoneyOrder;
import com.hcentive.billing.core.commons.domain.PayCheck;
import com.hcentive.billing.core.commons.domain.PaymentMethod;
import com.hcentive.billing.core.commons.domain.TokenPaymentMethod;
import com.hcentive.billing.core.commons.xsdtopojo.AchType;
import com.hcentive.billing.core.commons.xsdtopojo.CardType;
import com.hcentive.billing.core.commons.xsdtopojo.CardTypeType;
import com.hcentive.billing.core.commons.xsdtopojo.CashType;
import com.hcentive.billing.core.commons.xsdtopojo.ElectronicPaymentInstrumentType;
import com.hcentive.billing.core.commons.xsdtopojo.MoneyOrderType;
import com.hcentive.billing.core.commons.xsdtopojo.PcType;

public class PopulatePaymentMethod {
	private static final Logger logger = LoggerFactory
			.getLogger(PopulatePaymentMethod.class);

	public static PaymentMethod createPaymentMethodFromCash(CashType cashType) {

		if (cashType != null) {
			Cash cash = Cash.newCashPayment();
			cash.setSource(cashType.getSource());
			return cash;
		}

		logger.debug("No Money Order Insrument received.");
		return null;
	}

	public static PaymentMethod createPaymentMethodFromEI(
			ElectronicPaymentInstrumentType ei) {
		logger.debug("Going to create Payment Methid from EPI");
		if (ei == null) {
			logger.debug("NO electronic Instrument ::");
			return null;
		}
		if (null != ei.getAch()) {
			return populateAch(ei.getAch());
		} else if (null != ei.getCard()) {
			return populateCardDetail(ei.getCard());
		} else if (ei.getToken() != null) {
			TokenPaymentMethod token = new TokenPaymentMethod(ei.getToken()
					.getTokenId());
			
			if(ei.getToken().getTokenOf().getAch() != null){
				token.setIdentifier("BankAccount");
			}else if(ei.getToken().getTokenOf().getCard() != null){
				token.setIdentifier("Card");
			}
				
			return token;
		}

		return null;
	}

	public static PaymentMethod createPaymentMethodFromMoneyOrder(
			MoneyOrderType moneyOrderType) {

		if (moneyOrderType != null) {
			MoneyOrder moneyOrder = MoneyOrder.newMoneyOrder();
			moneyOrder
					.setMoneyOrderNumber(moneyOrderType.getMoneyOrderNumber());
			return moneyOrder;
		}

		logger.debug("No Money Order Insrument received.");
		return null;
	}

	public static PaymentMethod createPaymentMethodFromPayCheck(PcType pcType) {
		if (pcType != null) {
			PayCheck payCheck = PayCheck.newPayCheck();
			payCheck.setBankName(pcType.getBankName());
			payCheck.setAccountNumber(pcType.getAccountNumber());
			payCheck.setCheckNumber(pcType.getCheckNumber());
			payCheck.setRoutingNumber(pcType.getRoutingNumber());
			return payCheck;

		}
		return null;
	}

	public static Ach populateAch(AchType achType) {
		Ach ach = Ach.newAch();

		String firstName = achType.getName() != null ? achType.getName()
				.getFirstName() : null;
		String lastName = achType.getName() != null ? achType.getName()
				.getLastName() : null;
		ach.setAccountHolderFirstName(firstName);
		ach.setAccountHolderLastName(lastName);
		ach.setAccountNumber(achType.getAccountNumber());
		ach.setAccountType(com.hcentive.billing.core.commons.domain.enumtype.AchType
				.parse(achType.getAccountType()));
		ach.setBankName(achType.getBankName());
		return ach;
	}

	public static CardDetail populateCardDetail(CardType cardType) {
		CardDetail cardDetail = null;
		
		if(cardType.getCardType().equals(CardTypeType.DEBITCARD)){
			cardDetail = CardDetail.newDebitCard();
		}else{
			cardDetail = CardDetail.newCreditCard();
		}

		cardDetail.setCardNumber(cardType.getNumber());
		cardDetail
				.setCardVendor(com.hcentive.billing.core.commons.domain.enumtype.CardType
						.parse(cardType.getCardVendor().value()));
		cardDetail.setNameOnCard(cardType.getNameOnCard());
		CardDetailExpirationDate cardExpirationDate = new CardDetailExpirationDate();
		cardExpirationDate.setExpirationMonth(cardType.getExpirationMonth()
				.getMonth());
		cardExpirationDate.setExpirationYear(cardType.getExpirationYear()
				.getYear());
		cardDetail.setCardExpirationDate(cardExpirationDate);
		return cardDetail;
	}

}
