/**
 * 
 */
package com.hcentive.billing.core.commons.domain.util.reference.repository;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.data.repository.core.support.RepositoryFactoryBeanSupport;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;
import org.springframework.stereotype.Repository;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

/**
 * @author Dikshit.Vaid
 * 
 */
@Repository("referenceEntityFactoryBean")
public class ReferenceEntityRepositoryFactoryBean
		extends
		RepositoryFactoryBeanSupport<ReferenceEntityRepository, ReferenceableDomainEntity, Long>
		implements BeanFactoryPostProcessor {

	public ReferenceEntityRepositoryFactoryBean() {
		setRepositoryInterface(ReferenceEntityRepository.class);
	}

	@Override
	public void postProcessBeanFactory(
			ConfigurableListableBeanFactory beanFactory) throws BeansException {
		BeanDefinition beanDef = beanFactory
				.getBeanDefinition("referenceEntityFactoryBean");
		beanDef.getPropertyValues().addPropertyValue(
				new PropertyValue("repositoryInterface",
						ReferenceEntityRepository.class));
	}

	@Override
	protected RepositoryFactorySupport createRepositoryFactory() {
		return new ReferenceEntityRepositoryFactory();
	}

}