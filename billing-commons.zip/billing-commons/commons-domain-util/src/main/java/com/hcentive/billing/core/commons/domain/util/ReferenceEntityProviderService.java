package com.hcentive.billing.core.commons.domain.util;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.Reference.ReferenceEntityProvider;
import com.hcentive.billing.core.commons.domain.Reference.ReferenceType;
import com.hcentive.billing.core.commons.domain.Referenceable;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.domain.util.reference.repository.ReferenceEntityRepository;

@Component
public class ReferenceEntityProviderService<T> implements
		ReferenceEntityProvider, InitializingBean {

	@Autowired
	@Qualifier(value = "referenceEntityFactoryBean")
	ReferenceEntityRepository referenceEntityRepositoryImpl;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public <I, V, R extends Referenceable> R toObject(
			Reference<I, R, V> reference) {

		return (R) referenceEntityRepositoryImpl.findDomainByIdentity(
				(Class<? extends ReferenceableDomainEntity>) reference
						.getType(), (String) reference.getReferenceId());
	}

	@SuppressWarnings("rawtypes")
	@Override
	public <I, V, R extends Referenceable> ReferenceType getType(R referenceable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Reference.ReferenceEntityProviderConfiguration.set(this);
	}

}