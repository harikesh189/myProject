/**
 * 
 */
package com.hcentive.billing.core.commons.domain.util;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

/**
 * @author Dikshit.Vaid
 * 
 */
@Component
public class EntityManagerProvider {

	public static EntityManager entityManager() {
		EntityManager entityManager = EntityManagerHolder.get();
		addTenant(entityManager);
		return entityManager;
	}

	private static void addTenant(EntityManager target) {
		final String tenantId = TenantUtil.getTenantId();
		target.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, tenantId);
	}
	
	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		EntityManagerHolder.set(entityManager);
	}

	private static class EntityManagerHolder {
		private static EntityManager ENTITY_MANAGER;

		public static void set(EntityManager entityManager) {
			ENTITY_MANAGER = entityManager;
		}

		public static EntityManager get() {
			return ENTITY_MANAGER;
		}
	}
}
