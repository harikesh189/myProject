package com.hcentive.billing.core.commons.domain.util.criteria.builder;

import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface MatchingItemFilterCriteriaBuilder<T> {

	SearchCriteria getCriteria(T object);

}
