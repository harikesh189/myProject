package com.hcentive.billing.core.commons.domain.util;

import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.DateUtility;

public class EffectivityUtil {

	
	public static boolean isCoverageEffective(Effectivity effectiveObj, Period inPeriod) {

		if (effectiveObj == null) {
			return false;
		}

		if (inPeriod == null) {
			return false;
		}

		final Period objEffPeriod = effectiveObj.effectivePeriod();

		return !(objEffPeriod.getBeginsOn().isAfter(objEffPeriod.getEndsOn())) 
				&& isEffective(effectiveObj, inPeriod);
	}

	/**
	 * Returns true if there is any intersection between period of effectivity object and given period.
	 * @param effectiveObj The effectivity object whose period has to be checked for intersection.
	 * @param inPeriod The second period that has to be checked for intersection.
	 * @return true if there is any intersection between period of effectivity object and given period. <br>
	 *         false if either effectiveObj or inPeriod is null.
	 */
	public static boolean isEffective(Effectivity effectiveObj, Period inPeriod) {

		if (effectiveObj == null) {
			return false;
		}

		if (inPeriod == null) {
			return false;
		}

		return inPeriod.hasIntersection(effectiveObj.effectivePeriod());
	}

}
