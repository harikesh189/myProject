package com.hcentive.billing.core.commons.domain.util;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Address;
import com.hcentive.billing.core.commons.domain.ContactNumber;
import com.hcentive.billing.core.commons.domain.ContactPerson;
import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.EbillSubscription;
import com.hcentive.billing.core.commons.domain.Email;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * Util class for domain specific tasks.
 * 
 * @author ajay.saxena
 * 
 */
public class DomainEntityUtils {

	private static final String EXTERNAL_ID = "externalId";
	private static final Logger LOGGER = LoggerFactory.getLogger(DomainEntityUtils.class);
	// Regex allowing email addresses permitted by RFC 5322
	private static final String EMAIL_REGEX = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
	private static Pattern EMAIL_PATTERN;
	// Regex for north american phone numbers
	private static final String PHONE_NO_REGEX = "^\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})$";
	private static Pattern PHONE_NO_PATTERN;

	static {
		EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);
		PHONE_NO_PATTERN = Pattern.compile(PHONE_NO_REGEX);
	}

	public static void updateExternalId(final DomainEntity domain, String externalId) {
		LOGGER.debug("modifying externalId of the entity using reflection");
		if (null == externalId)
			return;

		try {
			final Field externalIdField = DomainEntity.class.getDeclaredField(EXTERNAL_ID);
			externalIdField.setAccessible(true);
			externalIdField.set(domain, externalId);
		} catch (Exception e) {
			LOGGER.error("Error while modifying external id for bean with external id::" + domain.externalId());
		}
	}

	public static XMLGregorianCalendar convertDateTimeToXMLGregorianCal(DateTime dateTime)
			throws DatatypeConfigurationException {

		LOGGER.debug("converting date time to xml gregorian calendar.");

		XMLGregorianCalendar xmlCalendar = null;

		if (dateTime != null && dateTime.getDate() != null) {

			GregorianCalendar gCalendar = new GregorianCalendar();
			gCalendar.setTime(dateTime.getDate());

			xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCalendar);
		}

		return xmlCalendar;
	}

	public static String fetchSubscriptionRefIdFromRef(ReferenceableDomainEntity referenceableDomainEntity) {
		Collection<Reference<String, EbillSubscription, String>> subsReferences = referenceableDomainEntity
				.referencesByType(EbillSubscription.class, String.class, String.class);
		for (Reference<String, EbillSubscription, String> reference : subsReferences) {
			if (reference != null && reference.getReferenceId() != null) {
				return reference.getReferenceId();
			}
		}

		return null;
	}

	public static boolean validAddress(Set<Address> addresses) {
		for (final Address address : addresses) {
			if (address.getAddressLine1() == null || address.getAddressLine1().isEmpty() || address.getZipcode() == null
					|| address.getZipcode().isEmpty() || address.getState() == null || address.getState().isEmpty()) {
				return false;
			}
			return true;
		}
		return false;
	}

	public static boolean validEmail(Set<Email> emails) {
		for (Email email : emails) {
			if (email.isPrimary()) {
				final Matcher matcher = EMAIL_PATTERN.matcher(email.getEmailId());
				return matcher.matches();
			}
		}
		return false;
	}

	public static boolean validContactPerson(Set<ContactPerson> contactPersons) {
		for (ContactPerson contactPerson : contactPersons) {
			if (contactPerson.isPrimary()) {
				return true;
			}
		}
		return false;
	}

	public static boolean validContactNumber(Set<ContactNumber> contactNumbers) {
		for (ContactNumber contactNumber : contactNumbers) {
			if (contactNumber.isPrimary()) {
				final Matcher matcher = PHONE_NO_PATTERN.matcher(contactNumber.getNumber());
				return matcher.matches();
			}
		}
		return false;
	}
}
