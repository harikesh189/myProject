package com.hcentive.billing.core.commons.domain.util.reference.repository;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface SearchCriteriaSupportRepository {
	<T> Page<T> findBy(SearchCriteria criteria, Class<T> resultType);
}
