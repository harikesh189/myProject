package com.hcentive.billing.core.commons.domain.util.reference.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.beanutils.BeanUtils;
import org.eclipse.persistence.config.QueryHints;
import org.eclipse.persistence.config.ResultType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.hcentive.billing.core.commons.domain.converter.PageableTransformer;
import com.hcentive.billing.core.commons.domain.util.EntityManagerProvider;
import com.hcentive.billing.core.commons.dto.PageRequestCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public abstract class AbstractSearchCriteriaSupportRepositoryImpl implements SearchCriteriaSupportRepository {

	@Autowired
	EntityManager entityManager;

	private static Logger LOGGER = LoggerFactory.getLogger(AbstractSearchCriteriaSupportRepositoryImpl.class);

	private final Set<QueryDecorator> queryDecorators = new TreeSet<QueryDecorator>();

	public void init() {
		this.register(new SortingDecorator());
	}

	@Override
	public <T> Page<T> findBy(final SearchCriteria criteria, final Class<T> resultType) {
		LOGGER.debug("Find By Search Criteria for result type {}", resultType);
		final Map<Integer, Object> queryParams = new HashMap<Integer, Object>();
		final StringBuilder baseQuery = this.buildQueryStr(criteria, queryParams);
		LOGGER.debug("baseQuery = {}", baseQuery);
		final StringBuilder countQuery = this.totalRecordsCountQueryStr(criteria, queryParams);
		final long totalRecords = this.getTotalRecordsCount(countQuery, queryParams);
		LOGGER.debug("totalRecords = {}", totalRecords);
		final StringBuilder queryString = this.decorate(baseQuery, criteria, queryParams);
		LOGGER.debug("queryString = {}", queryString);
		final Query query = this.transform(queryString, resultType, queryParams);
		final PageRequestCriteria pageRequestCriteria = criteria.getPageRequestCriteria();
		if (pageRequestCriteria != null) {
			final int pageNumber = pageRequestCriteria.getPageIndex();
			final int pageSize = pageRequestCriteria.getSize();
			query.setMaxResults(pageSize);
			query.setFirstResult(pageNumber * pageSize);
		}
		LOGGER.debug("query = {}", query);
		return this.executeQuery(query, criteria, totalRecords, resultType);
	}

	protected abstract StringBuilder totalRecordsCountQueryStr(SearchCriteria criteria,
			Map<Integer, Object> queryParams);

	@SuppressWarnings({ "unchecked" })
	private <T> Page<T> executeQuery(final Query query, final SearchCriteria criteria, final long totalRecords, final Class<T> resultType) {
		try {
		query.setHint(QueryHints.RESULT_TYPE, ResultType.Map);
			final List<Map> results = query.getResultList();
			final List<T> entityList = new ArrayList<T>();
			if(null != resultType){
				for (final Map result : results) {
					transformToPojoAndAddToResult(result, resultType, entityList);
				}
			}
			
			Pageable pageable = null;
			final PageRequestCriteria pageRequestCriteria = criteria.getPageRequestCriteria();
			if (pageRequestCriteria != null) {
				pageable = PageableTransformer.INSTANCE.transform(pageRequestCriteria);
			}
			if(null == resultType){
				return (Page<T>) this.pageableToPage(results, pageable, totalRecords);
			}
			return  this.pageableToPage(entityList, pageable, totalRecords);
		} catch (final Exception e) {
			// e.printStackTrace();
			LOGGER.debug("Exception occurred while executing query {}", e.getMessage());
			throw e;
		}

	}

	protected <T> void transformToPojoAndAddToResult(final Map result, final Class<T> resultType,List<T> resultList){
		final T t= this.transformToPojo(result, resultType);
	     resultList.add(t);
	}
	@SuppressWarnings("finally")
	private <T> T transformToPojo(final Map result, final Class<T> resultType) {
		LOGGER.debug("Transformation of POJO");
		T bean = null;
		try {
			final Set<?> keySet = result.keySet();
			LOGGER.debug("Creating instance of class :: {}", resultType);
			bean = resultType.newInstance();
			for (final Object key : keySet) {
				if (result.get(key) != null) {
					BeanUtils.setProperty(bean, key.toString(), result.get(key));
				}
			}
		} catch (final Exception e) {
			LOGGER.error(e.getMessage());
		} finally {
			return bean;
		}
	}

	private long getTotalRecordsCount(final StringBuilder queryString, final Map<Integer, Object> queryParams) {
		final Query countQuery = this.createQuery(queryString);
		this.enrichQueryWithQueryParams(queryParams, countQuery);
		List<Long> list = countQuery.getResultList();
		long totalRecords = 0;
		for (Long value : list) {
			totalRecords += value;
		}
		//final long totalRecords = list.size();
		return totalRecords;
	}

	private Query transform(final StringBuilder queryString, @SuppressWarnings("rawtypes") final Class resultType, final Map<Integer, Object> queryParams) {
		final Query query = this.createQuery(queryString);
		this.enrichQueryWithQueryParams(queryParams, query);
		//if (!BaseEntity.class.isAssignableFrom(resultType)) {
			// query.setResultTransformer(Transformers.aliasToBean(resultType));
			// query.setParameter(name, value)
		//}
		return query;
	}

	protected void enrichQueryWithQueryParams(final Map<Integer, Object> queryParams, final Query query) {
		if (queryParams != null) {
			for (final Map.Entry<Integer, Object> entry : queryParams.entrySet()) {
				query.setParameter(entry.getKey(), entry.getValue());
			}
		}
	}

	protected Query createQuery(final StringBuilder queryString) {
		final Query query = this.entityManager.createQuery(queryString.toString());
		return query;
	}

	protected abstract StringBuilder buildQueryStr(SearchCriteria criteria, Map<Integer, Object> queryParams);

	private StringBuilder decorate(final StringBuilder query, final SearchCriteria criteria, final Map<Integer, Object> queryParams) {
		for (final QueryDecorator queryDecorator : this.queryDecorators) {
			queryDecorator.decorate(query, criteria, queryParams);
		}
		return query;
	}

	protected interface QueryDecorator extends Comparable<QueryDecorator> {
		public StringBuilder decorate(StringBuilder query, SearchCriteria criteria, Map<Integer, Object> queryParams);

		public int order();
	}

	protected abstract class AbstractDecorator implements QueryDecorator {

		private final int order;

		protected AbstractDecorator(final int order) {
			this.order = order;
		}

		@Override
		public final int compareTo(final QueryDecorator o) {
			return this.order - o.order();
		}

		@Override
		public int order() {
			return this.order;
		}
	}

	protected class SortingDecorator extends AbstractDecorator {

		protected SortingDecorator() {
			super(Integer.MAX_VALUE - 1);
		}

		@Override
		public StringBuilder decorate(final StringBuilder query, final SearchCriteria criteria, final Map<Integer, Object> queryParams) {
			final PageRequestCriteria pageRequestCriteria = criteria.getPageRequestCriteria();
			if (pageRequestCriteria != null
					&& pageRequestCriteria.getSortedColumn() != null) {
				String sortedColumnArr[] = pageRequestCriteria
						.getSortedColumn().split(",");
				if (sortedColumnArr != null && sortedColumnArr.length > 1) {
					query.append(" ORDER BY ");
					for (String sortedColumn : sortedColumnArr) {
						query.append(sortedColumn);
						query.append(" "
								+ pageRequestCriteria.getSortDirection() + " ,");
					}
					query.deleteCharAt(query.length()-1);
				} else {
					query.append(" ORDER BY "
							+ pageRequestCriteria.getSortedColumn());
					query.append(" " + pageRequestCriteria.getSortDirection()
							+ " ");
				}
			}
			return query;
		}

	}

	protected void register(final QueryDecorator decorator) {
		this.queryDecorators.add(decorator);
	}

	protected EntityManager entityManager() {
		return EntityManagerProvider.entityManager();
	}

	private <T> Page<T> pageableToPage(final List<T> entityList, final Pageable pageable, final long total) {
		final PageImpl<T> page = new PageImpl<T>(entityList, pageable, total);
		return page;
	}
}
