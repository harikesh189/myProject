package com.hcentive.billing.core.commons.domain.util.reference.repository;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

@NoRepositoryBean
public interface ReferenceEntityRepository extends
		PagingAndSortingRepository<ReferenceableDomainEntity, Long> {

	public <RD extends ReferenceableDomainEntity> RD findDomainByIdentity(
			Class<RD> domain, String identity);
}