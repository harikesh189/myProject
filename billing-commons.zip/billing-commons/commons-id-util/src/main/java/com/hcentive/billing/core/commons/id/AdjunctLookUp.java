/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id;

import java.util.List;

public interface AdjunctLookUp {

	public List<String> lookup(String key); 
}


