/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.id;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.zookeeper.IDPrefixPojo;
import com.hcentive.billing.core.commons.zookeeper.PatternDiscriptor;

@Component
public class PatternResolver implements PatternDiscriptor {
	Logger logger = LoggerFactory.getLogger(PatternResolver.class);

	@Autowired
	PatternFetcher patternFetcher;

	@Override
	public IDPrefixPojo resolve(Object obj) {

		logger.trace("prepration of result is started");
		final PrefixAndDatePattern pojo = patternFetcher.fetchPattern(obj);

		if (pojo == null || pojo.isDummy) {
			logger.debug("picking default IDPrefixPojo pattern for {}", obj);
			final IDPrefixPojo dummy = new IDPrefixPojo();
			dummy.setDummy(true);
			return dummy;
		}

		return buildIDPrefixPojo(pojo);
	}

	private IDPrefixPojo buildIDPrefixPojo(PrefixAndDatePattern pojo) {
		final StringBuilder builder = new StringBuilder();
		final IDPrefixPojo result = new IDPrefixPojo();
		if (pojo != null) {
			builder.append(pojo.prefixPattern);
			result.setType(pojo.prefixPattern);
			final String datePattern = pojo.getDatePattern();
			if (null != datePattern && !datePattern.isEmpty()) {
				final Date date = new Date();
				final SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
				builder.append(sdf.format(date));
			}
			result.setMinPatternlen(pojo.getMinPatternlen());
			result.setOutput(builder);

		}
		return result;
	}
}
