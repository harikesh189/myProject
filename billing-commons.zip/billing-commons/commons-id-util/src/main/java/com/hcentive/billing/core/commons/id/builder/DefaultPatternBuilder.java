/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id.builder;

import com.hcentive.billing.core.commons.id.AdjunctLookUp;
import com.hcentive.billing.core.commons.id.PrefixAndDatePattern;

public class DefaultPatternBuilder extends AbstractPatternBuilder<Object> {

	
	protected DefaultPatternBuilder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DefaultPatternBuilder(AdjunctLookUp adjunctLookUp) {
		super(adjunctLookUp);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean canHandle(Object type) {
		return true;
	}
	
	@Override
	public PrefixAndDatePattern buildPattern(Object obj){
		PrefixAndDatePattern pattern = super.buildPattern(obj);
		if(pattern == null){
			pattern = new PrefixAndDatePattern();
			pattern.setDummy(true);
		}
		return pattern;
	}

}


