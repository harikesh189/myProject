/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.id.builder;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.id.AdjunctLookUp;
import com.hcentive.billing.core.commons.id.PrefixAndDatePattern;

public abstract class AbstractPatternBuilder<T> implements  PatternBuilder<T> {

	@Autowired
	protected AdjunctLookUp adjunctLookUp;
	
	private static Logger logger = LoggerFactory
			.getLogger(AbstractPatternBuilder.class);

	protected AbstractPatternBuilder() {
		
	}
	
	
	
	protected AbstractPatternBuilder(AdjunctLookUp adjunctLookUp) {
		super();
		this.adjunctLookUp = adjunctLookUp;
	}



	@Override
	public PrefixAndDatePattern buildPattern(T obj) {
		final String key = buildKeyForConfiguration(obj);
		logger.debug("prepared key is {}", key);
	final List<String> list = getPatternList(key);

		if (null == list || list.isEmpty())
			return null;

		PrefixAndDatePattern pojo = new PrefixAndDatePattern();
		for (String s : list) {
			if (s.startsWith("firstPrefix")) {
				pojo.setPrefixPattern(s.split("_")[1]);
			} else if (s.startsWith("sample")) {
				pojo.setMinPatternlen(s.split("_")[1].length());
			} else if (s.startsWith("date")) {
				pojo.setDatePattern(s.split("_")[1]);
			}
		}
		return pojo;
	}

	private List<String> getPatternList(final String key) {
		return adjunctLookUp.lookup(key);
	}

	private String buildKeyForConfiguration(T obj) {
		logger.debug("generating key to read pattern from config for {}", obj);
		return "EXTERNALID_GENERATION_" + giveKeyValue(obj);
	}

	protected String giveKeyValue(T obj) {
		if (obj != null) {
			return obj.getClass().getSimpleName().toUpperCase();
		}
		return null;
	}
}
