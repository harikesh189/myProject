/**
 * @author uttam.tiwari
 *
 */
package com.hcentive.billing.core.commons.id;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.id.builder.DefaultPatternBuilder;
import com.hcentive.billing.core.commons.id.builder.PatternBuilder;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class PatternFetcher {

	private static Logger logger = LoggerFactory.getLogger(PatternFetcher.class);

	@Autowired
	private WFMCache cache;

	@Autowired
	private AdjunctLookUp adjunctLookUp;

	public PrefixAndDatePattern fetchPattern(Object key) {
		logger.trace("fetching pattern for {}", key);
		final String objType = key.getClass().getName();
		PrefixAndDatePattern pattern = (PrefixAndDatePattern) cache.get(objType);
		if (null == pattern) {
			pattern = buildPattern(key);
			if (pattern != null) {
				cache.put(objType, pattern);
			}
		}
		return pattern;
	}

	private PrefixAndDatePattern buildPattern(Object key) {
		PatternBuilder builder = null;
		try {
			builder = (PatternBuilder) Factories.INSTANCE.factory(PatternBuilder.class).get(key);
		} catch (final Exception e) {
			// TODO Ajay/Ankit : Fixed so that Deault pattern builder is also configured in
			logger.warn("No configured class for key {} from factory", key);
		}
		if (builder == null) {
			builder = new DefaultPatternBuilder(this.adjunctLookUp);
		}
		return builder.buildPattern(key);
	}
}
