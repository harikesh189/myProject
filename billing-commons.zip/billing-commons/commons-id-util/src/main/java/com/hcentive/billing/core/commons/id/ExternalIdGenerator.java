/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.audit.ExternalIdAwareListner;
import com.hcentive.billing.core.commons.util.IDGenerator;
import com.hcentive.billing.core.commons.zookeeper.ZookeeperBasedIdGenerator;
@Component
public class ExternalIdGenerator implements IDGenerator<String> {

	@Autowired
	private ZookeeperBasedIdGenerator ZookeeperIdGenerator;
	
	@PostConstruct
	public void doRegister() {
		ExternalIdAwareListner.registerIDGenerator(this);
	}

	@Override
	public String generateID(Object obj) {
		return ZookeeperIdGenerator.generateID(obj);
	}
}


