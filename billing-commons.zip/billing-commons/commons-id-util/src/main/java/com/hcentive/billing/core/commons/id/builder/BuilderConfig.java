/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id.builder;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.factory.IsForTask;
import com.hcentive.billing.core.commons.factory.TaskAwareFactory;

@Configuration
public class BuilderConfig {

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public TaskAwareFactory<IsForTask> patternBuilderFactory() {
		TaskAwareFactory<IsForTask> patternBuilderFactory = new TaskAwareFactory(
				PatternBuilder.class);
		Factories.INSTANCE.registerBean(patternBuilderFactory);
		return patternBuilderFactory;
	}	
}


