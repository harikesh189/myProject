/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id.builder;

import com.hcentive.billing.core.commons.factory.IsForTask;
import com.hcentive.billing.core.commons.id.PrefixAndDatePattern;

@SuppressWarnings("rawtypes")
public interface PatternBuilder<T> extends IsForTask {
	public PrefixAndDatePattern buildPattern(T obj);
}


