/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id;

import java.io.Serializable;

public class PrefixAndDatePattern implements Serializable{
	
	private static final long serialVersionUID = 7312444887921730854L;
	public String prefixPattern;
	String datePattern;
	int minPatternlen;
	boolean isDummy;

	public boolean isDummy() {
		return isDummy;
	}
	public void setDummy(boolean isDummy) {
		this.isDummy = isDummy;
	}
	public String getPrefixPattern() {
		return prefixPattern;
	}
	public void setPrefixPattern(String prefixPattern) {
		this.prefixPattern = prefixPattern;
	}
	public String getDatePattern() {
		return datePattern;
	}
	public void setDatePattern(String datePattern) {
		this.datePattern = datePattern;
	}
	public int getMinPatternlen() {
		return minPatternlen;
	}
	
	public void setMinPatternlen(int minPatternlen) {
		this.minPatternlen = minPatternlen;
	}
}


