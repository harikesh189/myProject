/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Invoice;

@Component
public class InvoicePatternBuilder extends AbstractPatternBuilder<Invoice>{

	private static final Logger logger  = LoggerFactory.getLogger(InvoicePatternBuilder.class);
	
	@Override
	public boolean canHandle(Object type) {
		return (type instanceof Invoice);
	}

	@Override
	protected String giveKeyValue(Invoice invoice) {
		logger.debug("preparing key to read pattern from config for {}",invoice);
		return invoice.getClass().getSimpleName().toUpperCase();
	}
	
}


