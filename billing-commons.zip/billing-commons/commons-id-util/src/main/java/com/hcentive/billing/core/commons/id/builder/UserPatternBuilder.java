/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.id.PrefixAndDatePattern;


@Component
public class UserPatternBuilder extends AbstractPatternBuilder<User>{

	private static Logger logger = LoggerFactory.getLogger(UserPatternBuilder.class);
	
	@Override
	public boolean canHandle(Object type) {
		return (type instanceof User);
	}

	@Override
	protected String giveKeyValue(User user) {
		logger.debug("preparing key to read data from config for {}",user);
		return user.getClass().getSimpleName().toUpperCase();
	}
	
	@Override
	public PrefixAndDatePattern buildPattern(User user) {
		PrefixAndDatePattern pojo = super.buildPattern(user);
		if (null == pojo) {
			return null;
		} else if (user.getProfile() == null
				|| user.getProfile().getFirstName() == null
				|| user.getProfile().getLastName() == null) {
			return super.buildPattern(user);
		}

		logger.debug("pattern building triggered for {}", user);
		char f = user.getProfile().getFirstName().charAt(0);
		char l = user.getProfile().getLastName().charAt(0);
		pojo.setPrefixPattern((String.valueOf(f) + String.valueOf(l))
				.toUpperCase());
		return pojo;
	}
	
}


