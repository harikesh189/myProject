/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.BusinessEntity;

@SuppressWarnings("rawtypes")
@Component
public class BEPatternBuilder extends AbstractPatternBuilder<BusinessEntity>{

	private static Logger logger = LoggerFactory.getLogger(BEPatternBuilder.class);
	
	@Override
	public boolean canHandle(Object type) {
		return (type instanceof BusinessEntity);
	}
	
	@Override
	protected String giveKeyValue(BusinessEntity obj) {
		logger.debug("preparing key to read pattern from config for {}",obj);
		return obj.getType().toUpperCase();
	}
}


