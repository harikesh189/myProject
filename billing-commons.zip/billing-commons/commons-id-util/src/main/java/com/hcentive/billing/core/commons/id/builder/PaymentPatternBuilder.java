/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.id.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Payment;

@Component
public class PaymentPatternBuilder extends AbstractPatternBuilder<Payment> {

	
	private final Logger logger = LoggerFactory.getLogger(PaymentPatternBuilder.class);
	
	@Override
	public boolean canHandle(Object type) {
		return (type instanceof Payment);
	}

	@Override
	protected String giveKeyValue(Payment payment) {
		logger.debug("preparing key to read pattern from config for {}",payment);
		return payment.getClass().getSimpleName().toUpperCase();
	}
}


