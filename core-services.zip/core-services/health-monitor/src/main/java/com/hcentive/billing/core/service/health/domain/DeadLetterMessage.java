package com.hcentive.billing.core.service.health.domain;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.hcentive.billing.core.commons.vo.DateTime;

@Document(collection = "dead_letter_message")
public class DeadLetterMessage extends AbstractMongoEntity {

	private static final long serialVersionUID = 1L;

	public static final String FIELD_EXPIRED_ON = "expiredOn.date";
	public static final String FIELD_LAST_WORK_TIME = "lastWorkTime.date";

	private ErrorCode errorCode;

	private DateTime expiredOn;

	private Event originalMessage;

	private String originalQueueName;

	private String originalRoutingKey;

	private String reason;

	private DateTime lastWorkTime;

	private Boolean autoRecoverableExplicitlyMentioned;

	public DeadLetterMessage(final ErrorCode errorCode, final DateTime expiredOn, final Event originalMessage, final String originalQueueName,
			final String originalRoutingKey, final String reason) {
		super();
		this.errorCode = errorCode;
		this.expiredOn = expiredOn;
		this.originalMessage = originalMessage;
		this.originalQueueName = originalQueueName;
		this.originalRoutingKey = originalRoutingKey;
		this.reason = reason;
		this.lastWorkTime = expiredOn;
	}

	protected DeadLetterMessage() {

	}

	public ErrorCode getErrorCode() {
		return errorCode;
	}

	public DateTime getExpiredOn() {
		return expiredOn;
	}

	public DateTime getLastWorkTime() {
		return lastWorkTime;
	}

	public Event getOriginalMessage() {
		return originalMessage;
	}

	public String getOriginalQueueName() {
		return originalQueueName;
	}

	public String getOriginalRoutingKey() {
		return originalRoutingKey;
	}

	public String getReason() {
		return reason;
	}

	public boolean isMarkedExplicitlyForAutoRecovery() {
		return this.autoRecoverableExplicitlyMentioned == null ? false : this.autoRecoverableExplicitlyMentioned;
	}

	public void markForAutoRecovery() {
		this.autoRecoverableExplicitlyMentioned = true;
	}

	public void setLastWorkTime(final DateTime lastWorkTime) {
		this.lastWorkTime = lastWorkTime;
	}

}
