package com.hcentive.billing.core.service.health.monitor;

import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.curator.framework.api.GetChildrenBuilder;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.commons.health.api.HealthMonitor;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.zookeeper.WFMCuratoreClient;

public class ServiceInstanceAvailabilityMonitor {

	private static final String SEPARATOR = "/";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ServiceInstanceAvailabilityMonitor.class);

	@Autowired
	private WFMCuratoreClient wfmCuratorClient;

	@Value("${zookeeper.health.rootPath:/wfm/health}")
	private String healthRootPath = "/wfm/health";

	@PostConstruct
	private void initialize() {
		try {
			LOGGER.info("Loading all Services Instances information for health monitoring.");
			final List<String> allServicesName = getChildren(healthRootPath,
					new ServiceInstanceWatcher());
			if (!CollectionUtil.isEmpty(allServicesName)) {
				for (final String serviceName : allServicesName) {
					parseServiceInformation(serviceName);
				}
			}

		} catch (Exception e) {
			LOGGER.error("Error while loading all Services Instances information for health monitoring.",e);
		}
	}

	private List<String> getChildren(final String path, final Watcher watcher)
			throws Exception {
		final GetChildrenBuilder getChildrenBuilder = wfmCuratorClient
				.getClient().getChildren();
		if (null != watcher) {
			getChildrenBuilder.usingWatcher(new ServiceInstanceWatcher());
		}
		return getChildrenBuilder.forPath(path);
	}

	private class ServiceInstanceWatcher implements Watcher {

		@Override
		public void process(final WatchedEvent event) {

			final EventType eventType = event.getType();
			final String nodePath = event.getPath();
			if (!nodePath.equals(healthRootPath)) {
				switch (eventType) {
				case NodeCreated:
					processNodeAddedEvent(nodePath);
					break;
				case NodeDeleted:
					processNodeDeletedEvent(nodePath);
					break;
				default:
					break;
				}
			}
		}

	}

	private void processNodeDeletedEvent(final String nodePath) {
		LOGGER.debug("Node removed: {}", nodePath);
		final String[] nodeInformation = parseNodeInformation(nodePath);
		if (null != nodeInformation && nodeInformation.length>0) {
			final String serviceName = nodeInformation[0];
			if (nodeInformation.length == 1 ) {
				// this means the serviceNode itself has been removed. ==> All
				// instances of the Service are down.
				doProcessServiceDown(serviceName);
				;
				return;
			}
			{
				// this means the serviceInstanceNode has been removed.
				final String instanceId = nodeInformation[1];
				doProcessServiceInstanceDown(serviceName, instanceId);
			}
		}
	}

	private void doProcessServiceInstanceDown(final String serviceName,
			final String instanceId) {
		final ServiceInformation serviceInformation = ServiceRegistry.INSTANCE
				.get(serviceName);
		final ServiceInstanceInformation serviceInstanceInformation = serviceInformation
				.removeInstance(instanceId);
		if (serviceInstanceInformation != null) {
			LOGGER.error(" Instance: {} of Service:{} is down.", instanceId,
					serviceName);
			EventUtils.publish(new Event<ServiceInstanceInformation>(
					"SERVICE_INSTANCE_DOWN", serviceInstanceInformation));
		}
	}

	private void doProcessServiceDown(final String serviceName) {
		ServiceInformation serviceInformation = null;
		serviceInformation = ServiceRegistry.INSTANCE.remove(serviceName);
		if (serviceInformation != null) {
			LOGGER.error("All instance of Service:{} are down.", serviceName);
			EventUtils.publish(new Event<ServiceInformation>("SERVICE_DOWN",
					serviceInformation));
		}
	}

	private String[] parseNodeInformation(final String nodePath) {
		if (null != nodePath) {
			return nodePath.replaceAll(healthRootPath+SEPARATOR, "").split(
					HealthMonitor.SPLIT_SEPARATOR);
		}
		return null;
	}

	private void processNodeAddedEvent(final String nodePath) {
		LOGGER.debug("Node removed: {}", nodePath);
		final String[] nodeInformation = parseNodeInformation(nodePath);
		if (null != nodeInformation && nodeInformation.length>0) {
			final String serviceName = nodeInformation[0];
			if (nodeInformation.length == 1) {
				doProcessServiceUp(serviceName);
				return;
			}
			{
				// this means the serviceInstanceNode has been added.
				final String instanceId = nodeInformation[1];
				doProcessServiceInstanceUp(serviceName,healthRootPath+SEPARATOR+serviceName,instanceId);
			}
		}
	}

	private ServiceInformation doProcessServiceUp(final String serviceName) {
		final ServiceInformation serviceInfo = ServiceRegistry.INSTANCE.createIfRequiredAndGet(serviceName);
		EventUtils.publish(new Event<ServiceInformation>("SERVICE_UP",
				serviceInfo));
		return serviceInfo;
	}

	private void doProcessServiceInstanceUp(final String serviceName,final String servicePath,
			final String instanceId) {
		
		try {
			final ServiceInstanceInformation serviceInstanceInformation = parseServiceInstanceInformation(
					serviceName,servicePath, instanceId);
			EventUtils.publish(new Event<ServiceInstanceInformation>(
					"SERVICE_INSTANCE_UP", serviceInstanceInformation));
		} catch (Exception e) {
			LOGGER.error(
					"Error while processInstance add event for serviceName:{} and instanceId: {}",
					serviceName, instanceId);
		}
	}

	private void parseServiceInformation(final String serviceName)
			throws Exception {
		LOGGER.debug("Parsing information for serviceName:{}", serviceName);
		final String servicePath = healthRootPath+SEPARATOR + serviceName;
		final ServiceInformation serviceInfo = doProcessServiceUp(serviceName);

		// get all serviceInstances
		final List<String> allServiceInstanceIds = getChildren(servicePath,
				null);
		if (!CollectionUtil.isEmpty(allServiceInstanceIds)) {
			LOGGER.debug("Got instanceIds for service: {}, size:{}",
					serviceName, allServiceInstanceIds.size());
			for (final String instanceId : allServiceInstanceIds) {
				doProcessServiceInstanceUp(serviceName,servicePath, instanceId);
			}
		} else {
			LOGGER.debug("Got instanceIds for service: {}, size:0", serviceName);
		}
		LOGGER.debug("Parsed information for serviceName:{}", serviceName);
	}

	private ServiceInstanceInformation parseServiceInstanceInformation(
			final String serviceName,final String servicePath, final String instanceId) throws Exception {
		LOGGER.debug(
				"Parsing instance information for serviceName:{}, instanceId:{}",
				serviceName, instanceId);
		final String serviceInstancePath = servicePath
				+ HealthMonitor.SEPARATOR + instanceId;

		final byte[] data = wfmCuratorClient.getClient().getData()
				.forPath(serviceInstancePath);
		if (null != data) {
			final String instanceAddress = new String(data);
			LOGGER.debug("Instance Address: {}", instanceAddress);
			final ServiceInstanceInformation serviceInformation = ServiceRegistry.INSTANCE.createIfRequiredAndGet(
					serviceName).addInstance(instanceId, instanceAddress);
			return serviceInformation;
		}
		LOGGER.debug(
				"Parsed instance information for serviceName:{}, instanceId:{}",
				serviceName, instanceId);
		return null;
	}

}
