package com.hcentive.billing.core.service.health.monitor;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ServiceInformation {

	private final String serviceName;
	private final Set<ServiceInstanceInformation> serviceInstances = new HashSet<>();

	ServiceInformation(String serviceName) {
		this.serviceName = serviceName;
	}

	public String serviceName() {
		return serviceName;
	}

	public long instanceCount() {
		return this.serviceInstances.size();
	}

	public Iterator<ServiceInstanceInformation> iterator() {
		return this.serviceInstances.iterator();
	}

	public ServiceInstanceInformation addInstance(final String instanceId,
			final String serverAddress) {
		final ServiceInstanceInformation instanceInfo = new ServiceInstanceInformation(
				serviceName, instanceId, serverAddress);
		serviceInstances.add(instanceInfo);
		return instanceInfo;
	}

	public ServiceInstanceInformation removeInstance(final String instanceId) {
		ServiceInstanceInformation instanceToRemove = null;
		for (final ServiceInstanceInformation instanceInfo : this.serviceInstances) {
			if (instanceInfo.instanceId().equals(instanceId)) {
				instanceToRemove = instanceInfo;
				break;
			}
		}
		this.serviceInstances.remove(instanceToRemove);
		return instanceToRemove;
	}

	@Override
	public int hashCode() {
		return null != this.serviceName ? this.serviceName.hashCode() : 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (null != obj
				&& !ServiceInformation.class.isAssignableFrom(obj.getClass())) {
			final ServiceInformation that = (ServiceInformation) obj;
			return this.serviceName.equals(that.serviceName);
		}
		return false;
	}
}