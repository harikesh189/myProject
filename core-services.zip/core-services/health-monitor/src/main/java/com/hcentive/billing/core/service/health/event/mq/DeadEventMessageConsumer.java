package com.hcentive.billing.core.service.health.event.mq;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.utils.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.hcentive.billing.core.commons.mq.MQEventConsumer;
import com.hcentive.billing.core.commons.mq.support.MQConstants;
import com.hcentive.billing.core.commons.service.event.NormalEventSecurityContextInitializer;
import com.hcentive.billing.core.commons.service.event.ProcessContextDestroyer;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;
import com.hcentive.billing.core.service.health.repository.mongo.DeadLetterMessagePersistor;

public class DeadEventMessageConsumer extends MQEventConsumer {

	private static final String LAST_QUEUE = "queue";

	private static final Logger LOGGER = LoggerFactory.getLogger(DeadEventMessageConsumer.class);

	private static final String ORIGINAL_EXPIRATION = "original-expiration";
	private static final String REASON = "reason";
	private static final String ROUTING_KEYS = "routing-keys";

	@Autowired
	private DeadLetterMessagePersistor deadLetterMessagePersistor;

	@Autowired
	private NormalEventSecurityContextInitializer eventSecurityContextInitializer;

	@Autowired
	private ProcessContextDestroyer processContextDestroyer;

	public void onErrorEventMessage(final DeadLetterMessage event) {

	}

	public void onExpiredEventMessage(final DeadLetterMessage event) {

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void onMessage(final Message message, final com.rabbitmq.client.Channel channel) throws Exception {
		final long deliveryTag = message.getMessageProperties().getDeliveryTag();
		final Map<String, Object> headers = message.getMessageProperties().getHeaders();
		final ArrayList<HashMap> deathParamsList = (ArrayList<HashMap>) headers.get("x-death");
		Event event = null;
		if (CollectionUtil.isNotEmpty(deathParamsList)) {

			final HashMap lastDeathParams = deathParamsList.get(deathParamsList.size() - 1);
			final String originalQueueName = (String) lastDeathParams.get(LAST_QUEUE);

			final Date expirationTime = (Date) lastDeathParams.get(ORIGINAL_EXPIRATION);
			final DateTime expiredOn = new DateTime(expirationTime != null ? expirationTime : new Date());

			final String reason = (String) lastDeathParams.get(REASON);

			final List<String> originalRoutingKeys = (List<String>) lastDeathParams.get(ROUTING_KEYS);
			final String originalRoutingKey = originalRoutingKeys.get(originalRoutingKeys.size() - 1);

			ErrorCode errorCode = null;
			DeadLetterMessage deadLetterMessage = null;
			try {
				event = (Event) SerializationUtils.deserialize(message.getBody());
				eventSecurityContextInitializer.beforeProcessing(event);
				final Map eventHeaders = event.headers();
				errorCode = (ErrorCode) eventHeaders.get(MQConstants.ERROR_CODE);
				deadLetterMessage = new DeadLetterMessage(errorCode, expiredOn, event, originalQueueName, originalRoutingKey,
						errorCode != null ? String.valueOf(errorCode) : reason);
				deadLetterMessage.markForAutoRecovery();
				deadLetterMessage = deadLetterMessagePersistor.save(deadLetterMessage);
				channel.basicAck(deliveryTag, false);
			} catch (final Throwable th) {
				channel.basicAck(deliveryTag, false);
				LOGGER.error("Failed to deserialize event payload", th);
				return;
			} finally {
				processContextDestroyer.onProcessingCompletion(event);
			}

			if (errorCode != null) {
				onErrorEventMessage(deadLetterMessage);
			} else {
				onExpiredEventMessage(deadLetterMessage);
			}
		} else {
			super.onMessage(message, channel);
		}
	}
}
