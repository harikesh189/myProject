package com.hcentive.billing.core.service.health.event.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventListener;
import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.hcentive.billing.core.commons.mq.support.MQConstants;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;
import com.hcentive.billing.core.service.health.repository.mongo.DeadLetterMessagePersistor;

public class ErrorMessageListener implements EventListener {

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorMessageListener.class);
	
	@Autowired
	private DeadLetterMessagePersistor persistor;
	
	@Override
	public String handlerId() {
		return "errorMessageListener";
	}

	@Override
	public void handle(Object originalEvent) {
		final Event event = (Event)originalEvent;
		final ErrorCode errorCode = (ErrorCode)event.getHeader(MQConstants.ERROR_CODE);
		final String originalQueueName = (String)event.getHeader(MQConstants.QUEUE_NAME);
		final Boolean autoRecoverable = (Boolean)event.getHeader(MQConstants.AUTO_RECOVERABLE);
		final DeadLetterMessage deadLetterMessage = new DeadLetterMessage(errorCode, new DateTime(), event, originalQueueName, event.getName(), errorCode.toString());
		if(autoRecoverable!=null && autoRecoverable){
			deadLetterMessage.markForAutoRecovery();
		}
		LOGGER.debug("Saving deadLetter message for errorCode {} from queue {}",errorCode,originalQueueName);
		persistor.save(deadLetterMessage);
		LOGGER.debug("Saved deadLetter message for errorCode {} from queue {}",errorCode,originalQueueName);
		
	}

	@Override
	public boolean recieveOfflineEvents() {
		return true;
	}

}
