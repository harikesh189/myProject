package com.hcentive.billing.core.service.health.monitor;

import static com.hcentive.billing.core.commons.concurrent.Executors.newScheduledThreadPoolExecutor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

public class ServiceHealthMetricMonitor implements Runnable {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceHealthMetricMonitor.class);

	@Value("${health.status.checkScheduleInMin:15}")
	private final int statusCheckScheduleInMins = 15;

	private static final String healthMetricPath = "/metrics";

	private final ScheduledExecutorService scheduler = newScheduledThreadPoolExecutor("HealthMonitorThreadPool", 1);

	@Autowired
	private ServiceMetricsAnalyser analyser;

	@Autowired
	private RestTemplate restTemplate;

	@PostConstruct
	private void init() {
		createScheduledTask();
	}

	private void createScheduledTask() {
		scheduler.scheduleAtFixedRate(this, statusCheckScheduleInMins, statusCheckScheduleInMins, TimeUnit.MINUTES);
		LOGGER.info("Scheduled HealthMetric Check of Services every {} mins", statusCheckScheduleInMins);
	}

	@Override
	public void run() {
		checkAllStatus();
	}

	private void checkAllStatus() {
		final Iterator<ServiceInformation> serviceInfoIter = ServiceRegistry.INSTANCE.iterator();
		if (null != serviceInfoIter) {
			while (serviceInfoIter.hasNext()) {
				final ServiceInformation serviceInfo = serviceInfoIter.next();
				checkServiceStatus(serviceInfo);
			}
		}

	}

	private void checkServiceStatus(final ServiceInformation serviceInfo) {
		LOGGER.debug("Checking HealthMetric of {} instances of Service :{}", serviceInfo.instanceCount(), serviceInfo.serviceName());
		checkAllServiceInstanceStatus(serviceInfo);
	}

	private void checkAllServiceInstanceStatus(final ServiceInformation serviceInfo) {
		// TODO Auto-generated method stub
		final Iterator<ServiceInstanceInformation> instanceIter = serviceInfo.iterator();
		if (null != instanceIter) {
			while (instanceIter.hasNext()) {
				final ServiceInstanceInformation serviceInstanceInfo = instanceIter.next();
				checkServiceInstanceStatus(serviceInstanceInfo);
			}
		}
	}

	private void checkServiceInstanceStatus(final ServiceInstanceInformation serviceInstanceInfo) {
		final String instanceAddress = serviceInstanceInfo.serverAddress();
		final String instanceId = serviceInstanceInfo.instanceId();
		final String serviceName = serviceInstanceInfo.serviceName();
		LOGGER.debug("Checking HealthMetric of {} instance of Service :{}", instanceId, serviceName);
		try {
			final Map<String, Number> metrics = restTemplate.getForObject("http://" + instanceAddress + healthMetricPath, Map.class, new HashMap<>());
			analyser.analyze(serviceName, instanceId, metrics);
		} catch (final Exception e) {
			LOGGER.error("Error while checking HealthMetric of " + instanceId + " instance of Service :" + serviceName, e);
		}
	}

}
