package com.hcentive.billing.core.service.health.event.service.helper;

import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;

public interface RecoverableMessageFindingStrategy {

	/**
	 * It check if given dead letter message is recoverable.
	 *
	 * @param deadLetterMessage The dead letter message to check.
	 * @return <code>true</code> if dead letter message is recoverable.
	 */
	boolean apply(DeadLetterMessage deadLetterMessage);
}
