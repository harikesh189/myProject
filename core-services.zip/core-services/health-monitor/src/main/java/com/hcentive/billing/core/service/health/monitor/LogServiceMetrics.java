package com.hcentive.billing.core.service.health.monitor;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LogServiceMetrics implements ServiceMetricsAnalyser {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(LogServiceMetrics.class);
	
	private final ObjectMapper mapper = new ObjectMapper();
	@Override
	public void analyze(final String serviceName,final String instanceId,
		final Map<String, Number> metrics) {
		try {
			LOGGER.info("Metrics --- ServiceName: {}, InstanceId: {}, metricsMap: {}",serviceName,instanceId,mapper.writerWithDefaultPrettyPrinter().writeValueAsString(metrics));
		} catch (JsonProcessingException e) {
			LOGGER.error("Error loggins metrics for ServiceName: {}, InstanceId: {}",serviceName,instanceId);
		}
	}

}
