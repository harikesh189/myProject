package com.hcentive.billing.core.service.health.repository.mongo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;
import com.hcentive.billing.core.service.health.event.service.helper.RecoverableMessageFindingStrategy;

public class DeadLetterMessagePersistorImpl implements DeadLetterMessagePersistor {

	private static final String ID_FIELD = "_id";

	private static final Logger LOGGER = LoggerFactory.getLogger(DeadLetterMessagePersistorImpl.class);

	private static final String DEAD_LETTER_MESSAGE_COLLECTION = "dead_letter_message";

	private static final String RECOVERABLE_DEAD_LETTER_MESSAGE_COLLECTION = "recoverable_dead_letter_message";

	@Autowired
	private MongoOperations mongoOperations;

	@Autowired
	private RecoverableMessageFindingStrategy recoverableMessageFindingStrategy;

	@Override
	public List<DeadLetterMessage> findRecoverableMessageBeforeDate(final Date date) {
		return mongoOperations.findAll(DeadLetterMessage.class, RECOVERABLE_DEAD_LETTER_MESSAGE_COLLECTION);
	}

	@Override
	public Page<DeadLetterMessage> findRecoverableMessageBeforeDate(final Date date, final Pageable pageable) {
		new Criteria("");
		LOGGER.debug("Fetching DeadLetterMessages");
		final Query query = new Query(Criteria.where(DeadLetterMessage.FIELD_LAST_WORK_TIME).lt(date));
		query.limit(pageable.getPageSize());
		query.skip(pageable.getOffset());
		final long count = mongoOperations.count(query, RECOVERABLE_DEAD_LETTER_MESSAGE_COLLECTION);
		final List<DeadLetterMessage> list = mongoOperations.find(query, DeadLetterMessage.class, RECOVERABLE_DEAD_LETTER_MESSAGE_COLLECTION);
		if (list != null) {
			return new PageImpl<>(list, pageable, count);
		}

		return new PageImpl<>(new ArrayList(0), pageable, 0);
	}

	@Override
	public void remove(final Collection<DeadLetterMessage> messagesToRemove) {
		if (null != messagesToRemove) {
			final Collection<String> idsToRemove = new ArrayList<String>();
			for (final DeadLetterMessage message : messagesToRemove) {
				idsToRemove.add(message.getId());
			}
			final Query query = new Query(Criteria.where(ID_FIELD).in(idsToRemove));
			mongoOperations.remove(query, RECOVERABLE_DEAD_LETTER_MESSAGE_COLLECTION);
		}
	}

	@Override
	public DeadLetterMessage save(final DeadLetterMessage deadLetterMessage) {
		final boolean recoverableMessage = recoverableMessageFindingStrategy.apply(deadLetterMessage);
		if (recoverableMessage) {
			mongoOperations.save(deadLetterMessage, RECOVERABLE_DEAD_LETTER_MESSAGE_COLLECTION);
		} else {
			mongoOperations.save(deadLetterMessage, DEAD_LETTER_MESSAGE_COLLECTION);
		}
		return deadLetterMessage;
	}

	@Override
	public void updateReattemptFailedOn(final Collection<DeadLetterMessage> messagesToUpdate, final Date date) {
		if (null != messagesToUpdate) {
			final Collection<String> idsToUpdate = new ArrayList<String>();
			for (final DeadLetterMessage message : messagesToUpdate) {
				idsToUpdate.add(message.getId());
			}
			final Query query = new Query(Criteria.where(ID_FIELD).in(idsToUpdate));
			final Update update = new Update();
			update.set(DeadLetterMessage.FIELD_LAST_WORK_TIME, new DateTime(date));
			mongoOperations.updateMulti(query, update, RECOVERABLE_DEAD_LETTER_MESSAGE_COLLECTION);
		}
	}
}
