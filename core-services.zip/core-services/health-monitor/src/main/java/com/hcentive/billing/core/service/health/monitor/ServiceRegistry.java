package com.hcentive.billing.core.service.health.monitor;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceRegistry {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ServiceRegistry.class);

	public static final ServiceRegistry INSTANCE = new ServiceRegistry();

	private final Map<String, ServiceInformation> serviceRegistry = new ConcurrentHashMap<String, ServiceInformation>();
	private final Semaphore permit = new Semaphore(1, true);

	private ServiceRegistry() {
	}

	public ServiceInformation createIfRequiredAndGet(final String serviceName) {
		ServiceInformation serviceInfo = null;
		try {
			permit.acquire();
			serviceInfo = this.serviceRegistry.get(serviceName);
			if (null != serviceInfo) {
				// create one.
				LOGGER.debug("Creating serviceInfo for serviceName:{}",
						serviceName);
				serviceInfo = new ServiceInformation(serviceName);
				this.serviceRegistry.put(serviceName, serviceInfo);
			}
		} catch (InterruptedException e) {
			LOGGER.error(
					"Error while acquiring permit for creating ServiceInformation",
					e);
		} finally {
			permit.release();
		}
		return serviceInfo;
	}

	public ServiceInformation get(String serviceName) {
		return this.serviceRegistry.get(serviceName);
	}

	public ServiceInformation remove(String serviceName) {
		try {
			permit.acquire();
			return this.serviceRegistry.remove(serviceName);
		} catch (InterruptedException e) {
			LOGGER.error(
					"Error while acquiring permit for removing ServiceInformation",
					e);
			return null;
		} finally {
			permit.release();
		}
	}
	
	public Iterator<ServiceInformation> iterator(){
		return this.serviceRegistry.values().iterator();
	}

}
