package com.hcentive.billing.core.service.health.event.scheduler;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.mq.AMQPClient;
import com.hcentive.billing.core.commons.mq.support.MQConstants;
import com.hcentive.billing.core.commons.security.SystemUserOperation;
import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;
import com.hcentive.billing.core.service.health.repository.mongo.DeadLetterMessagePersistor;

public class DeadLetterMessageRepublishingSchedular {

	private static final Logger LOGGER = LoggerFactory.getLogger(DeadLetterMessageRepublishingSchedular.class);

	@Autowired
	private DeadLetterMessagePersistor deadLetterMessagePersistor;

	@SuppressWarnings("rawtypes")
	@Autowired
	private AMQPClient amqpClient;

	@Value("${event.republishing.minutesToWaitBeforeRetry:30}")
	private int minutesToWaitBeforeRetry;

	@Value("${event.republishing.event.fetch.size:50}")
	private int pageSize;

	// @PostConstruct
	// public void postInit() {
	//
	// for (int i = 0; i < 100; i++) {
	// this.republishRecoverableEvents();
	// }
	// }

	@Scheduled(cron = "${event.republishing.scheduler.job.interval:0 40/60 * * * ?}")
	@SystemUserOperation
	public void republishRecoverableEvents() {
		final Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MINUTE, -1 * minutesToWaitBeforeRetry);
		final Date date = calendar.getTime();
		new EventRecoverer(date).attemptRecovery();
	}

	private class EventRecoverer {

		private final Date eventsDeadLetteredBefore;

		private EventRecoverer(final Date eventsDeadLetteredBefore) {
			this.eventsDeadLetteredBefore = eventsDeadLetteredBefore;
		}

		public void attemptRecovery() {
			boolean flag = true;
			final PageRequest pageRequest = new PageRequest(0, pageSize);
			do {
				LOGGER.debug("Attempting dead letter recovery");
				final Page<DeadLetterMessage> messagesToRecoverPage = deadLetterMessagePersistor.findRecoverableMessageBeforeDate(eventsDeadLetteredBefore,
						pageRequest);

				final List<DeadLetterMessage> messagesToRecover = messagesToRecoverPage.getContent();
				flag = messagesToRecover != null && !messagesToRecover.isEmpty();
				if (flag) {
					LOGGER.debug("found messages to recover {}", messagesToRecover.size());
					doRecovery(messagesToRecover, eventsDeadLetteredBefore);
				}
			} while (flag);
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		private void doRecovery(final List<DeadLetterMessage> messagesToRecover, final Date date) {
			final Collection<DeadLetterMessage> messagesRecoveryAttempted = new HashSet<>();
			final Collection<DeadLetterMessage> messagesRecoveryFailed = new HashSet<>();
			for (final DeadLetterMessage message : messagesToRecover) {
				final String originalQueueName = message.getOriginalQueueName();
				LOGGER.debug("Recovering for queue {}", originalQueueName);
				try {
					final Event originalMessage = message.getOriginalMessage();
					if (message.getErrorCode() != null) {
						originalMessage.addHeader(MQConstants.ERROR_CODE, message.getErrorCode());
					}
					amqpClient.publish(originalMessage, originalQueueName);
					messagesRecoveryAttempted.add(message);
				} catch (final Exception e) {
					LOGGER.error("Error while repubishing message to OriginalQueue: {}", originalQueueName);
					messagesRecoveryFailed.add(message);
				}
			}
			deadLetterMessagePersistor.remove(messagesRecoveryAttempted);
			deadLetterMessagePersistor.updateReattemptFailedOn(messagesRecoveryFailed, date);
		}
	}
}
