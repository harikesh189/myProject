package com.hcentive.billing.core.service.health.monitor;

public class ServiceInstanceInformation{
	private final String serviceName;
	private final String instanceId;
	private final String serverAddress;
	
	ServiceInstanceInformation(String serviceName,
			String instanceId, String serverAddress) {
		this.serviceName = serviceName;
		this.instanceId = instanceId;
		this.serverAddress = serverAddress;
	}
	
	public String serviceName() {
		return serviceName;
	}
	public String instanceId() {
		return instanceId;
	}
	public String serverAddress() {
		return serverAddress;
	}
	
	@Override
	public int hashCode() {
		return this.serviceName.hashCode();
	}
	
	@Override
	public boolean equals(final Object obj) {
		if(null!=obj && !ServiceInstanceInformation.class.isAssignableFrom(obj.getClass())){
			final ServiceInstanceInformation that = (ServiceInstanceInformation)obj;
			return this.serviceName.equals(that.serviceName) && this.instanceId.equals(that.instanceId);
		}
		return false;
	}
	
}