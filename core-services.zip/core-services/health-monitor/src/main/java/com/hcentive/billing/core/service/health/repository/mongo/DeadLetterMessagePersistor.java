package com.hcentive.billing.core.service.health.repository.mongo;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;

public interface DeadLetterMessagePersistor {

	List<DeadLetterMessage> findRecoverableMessageBeforeDate(Date date);

	DeadLetterMessage save(DeadLetterMessage deadLetterMessage);
	
	public Page<DeadLetterMessage> findRecoverableMessageBeforeDate(Date date, Pageable pageable);
	
	public void remove(Collection<DeadLetterMessage> messagesToRemove);
	public void updateReattemptFailedOn(Collection<DeadLetterMessage> messagesToUpdate,Date date); 
}
