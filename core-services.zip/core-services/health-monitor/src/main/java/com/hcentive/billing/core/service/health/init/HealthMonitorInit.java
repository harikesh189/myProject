package com.hcentive.billing.core.service.health.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;
import com.hcentive.billing.core.commons.service.init.MongoConfiguration;

@Configuration
@PropertySources({ @PropertySource("file:${baseDir}/config/properties/db.properties"), @PropertySource("file:${baseDir}/config/properties/mongodb.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"), @PropertySource("file:${baseDir}/config/properties/amqp.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties") })
@EntityScan("com.hcentive.billing.core.commons")
@ComponentScan({ "com.hcentive.billing", "com.hcentive.billing.commons.mongo" })
@EnableAutoConfiguration
@EnableMongoRepositories(basePackages = {"com.hcentive.billing.core.commons.starter.persistence.repository", "com.hcentive.billing.core.service.health.repository.mongo" })
@Import({ MongoConfiguration.class, DeadLetterQueueConfiguration.class })
public class HealthMonitorInit {

	private static final Logger LOGGER = LoggerFactory.getLogger(HealthMonitorInit.class);

	/**
	 * Init method for ebill audit service
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		LOGGER.debug("Starting health-monitor service for hcentive !!");
		SpringApplication.run(HealthMonitorInit.class, args);
	}
	
	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
}
