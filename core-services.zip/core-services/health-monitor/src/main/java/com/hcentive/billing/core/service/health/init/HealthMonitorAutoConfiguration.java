package com.hcentive.billing.core.service.health.init;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.service.health.monitor.LogServiceMetrics;
import com.hcentive.billing.core.service.health.monitor.ServiceHealthMetricMonitor;
import com.hcentive.billing.core.service.health.monitor.ServiceInstanceAvailabilityMonitor;
import com.hcentive.billing.core.service.health.monitor.ServiceMetricsAnalyser;
import com.hcentive.billing.core.service.health.monitor.ServiceRegistry;

@Configuration
public class HealthMonitorAutoConfiguration {

	@Bean
	public ServiceInstanceAvailabilityMonitor serviceInstanceAvailabilityMonitor() {
		return new ServiceInstanceAvailabilityMonitor();
	}

	@Bean
	public ServiceRegistry serviceRegistry() {
		return ServiceRegistry.INSTANCE;
	}

	@Bean
	public ServiceHealthMetricMonitor serviceHealthMetricMonitor() {
		return new ServiceHealthMetricMonitor();
	}

	@Bean
	@ConditionalOnMissingBean(value = ServiceMetricsAnalyser.class)
	public ServiceMetricsAnalyser logServiceMetrics() {
		return new LogServiceMetrics();
	}

}
