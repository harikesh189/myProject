package com.hcentive.billing.core.service.health.init;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.hcentive.billing.core.commons.mq.AMQPConfigurer;
import com.hcentive.billing.core.commons.mq.MQAwareEventBus;
import com.hcentive.billing.core.commons.mq.MQEventConsumer;
import com.hcentive.billing.core.commons.mq.support.MQConstants;
import com.hcentive.billing.core.service.health.event.listener.DeadEventMessageListener;
import com.hcentive.billing.core.service.health.event.listener.ErrorMessageListener;
import com.hcentive.billing.core.service.health.event.mq.DeadEventMessageConsumer;
import com.hcentive.billing.core.service.health.event.scheduler.DeadLetterMessageRepublishingSchedular;
import com.hcentive.billing.core.service.health.event.service.helper.RecoverableMessageFindingStrategy;
import com.hcentive.billing.core.service.health.event.service.helper.RecoverableMessageFindingStrategyImpl;
import com.hcentive.billing.core.service.health.repository.mongo.DeadLetterMessagePersistor;
import com.hcentive.billing.core.service.health.repository.mongo.DeadLetterMessagePersistorImpl;

@Configuration
@EnableScheduling
public class DeadLetterQueueConfiguration {

	@Value(value = "${amqp.default.ttl.dead.letter.queue.name:DEAD_LETTER_QUEUE}")
	private String defaultDeadMessageQueueName;

	@Value(value = "${amqp.defaultQueue.minNumberOfWorkers:1}")
	private Integer defaultQueueMinNumberOfWorkers;

	@Value(value = "${amqp.defaultQueue.maxNumberOfWorkers:1}")
	private Integer defaultQueueMaxNumberOfWorkers;

	@Value(value = "${amqp.defaultQueue.durable:true}")
	private boolean defaultQueueDurability;

	@Autowired
	private MQAwareEventBus mQAwareEventBus;

	@Bean
	public MethodInvokingFactoryBean configureDeadLetterQueue() {
		final MethodInvokingFactoryBean factoryBean = new MethodInvokingFactoryBean();
		factoryBean.setTargetClass(AMQPConfigurer.class);
		factoryBean.setTargetMethod("registerQueue");
		final Object[] args = { this.defaultDeadMessageQueueName, this.defaultQueueDurability, true, 5, defaultQueueMinNumberOfWorkers,
				defaultQueueMaxNumberOfWorkers, new HashMap<String, Object>() };
		factoryBean.setArguments(args);
		return factoryBean;
	}

	@Bean
	public DeadEventMessageListener deadEventMessageListener() {
		final DeadEventMessageListener deadEventMessageListener = new DeadEventMessageListener();
		mQAwareEventBus.register(MQConstants.TTL_DEAD_LETTER_ROUTING_KEY, defaultDeadMessageQueueName, deadEventMessageListener,
				deadEventMessageListener.recieveOfflineEvents());
		return deadEventMessageListener;
	}

	@Bean
	public DeadLetterMessagePersistor deadLetterMessagePersistor() {
		return new DeadLetterMessagePersistorImpl();
	}

	@Bean
	public ErrorMessageListener errorMessageListener() {
		final ErrorMessageListener errorMessageListener = new ErrorMessageListener();
		mQAwareEventBus.register(MQConstants.ERROR_DEAD_LETTER_ROUTING_KEY, defaultDeadMessageQueueName, errorMessageListener,
				errorMessageListener.recieveOfflineEvents());
		return errorMessageListener;
	}

	@Bean(name = "mqEventConsumer")
	@Scope("prototype")
	public MQEventConsumer mqEventConsumer() {
		final MQEventConsumer eventConsumer = new DeadEventMessageConsumer();
		return eventConsumer;
	}

	@Bean
	public RecoverableMessageFindingStrategy recoverableMessageFindingStrategy() {
		return new RecoverableMessageFindingStrategyImpl();
	}

	@Bean
	DeadLetterMessageRepublishingSchedular deadLetterMessageRepublishingSchedular() {
		final DeadLetterMessageRepublishingSchedular deadLetterMessageRepublishingSchedular = new DeadLetterMessageRepublishingSchedular();
		return deadLetterMessageRepublishingSchedular;
	}
}
