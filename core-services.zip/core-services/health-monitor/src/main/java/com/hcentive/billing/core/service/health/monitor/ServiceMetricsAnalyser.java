package com.hcentive.billing.core.service.health.monitor;

import java.util.Map;

public interface ServiceMetricsAnalyser {

	public void analyze(final String serviceName, final String instanceId, Map<String, Number> metrics);
}
