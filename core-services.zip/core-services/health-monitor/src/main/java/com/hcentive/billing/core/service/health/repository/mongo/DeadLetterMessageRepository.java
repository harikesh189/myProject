/**
 * 
 */
package com.hcentive.billing.core.service.health.repository.mongo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;

public interface DeadLetterMessageRepository extends MongoRepository<DeadLetterMessage, String> {

}
