package com.hcentive.billing.core.service.health.event.service.helper;

import java.util.HashMap;
import java.util.Map;

import com.hcentive.billing.core.commons.exception.ErrorCode;
import com.hcentive.billing.core.commons.exception.StandardErrorCodes;
import com.hcentive.billing.core.service.health.domain.DeadLetterMessage;

public class RecoverableMessageFindingStrategyImpl implements RecoverableMessageFindingStrategy {

	private static class RecoverableErrors {
		private static final Map<ErrorCode, Boolean> recoverableErrorCodesMap = new HashMap<ErrorCode, Boolean>() {
			private static final long serialVersionUID = 1L;

			{
				this.put(StandardErrorCodes.DATABASE_CONNECTION_ERROR, true);
				this.put(StandardErrorCodes.CONNECTION_FAILURE, true);
			}
		};

		public static boolean contains(ErrorCode errorCode) {
			return recoverableErrorCodesMap.containsKey(errorCode);
		}
	}

	@Override
	public boolean apply(DeadLetterMessage deadLetterMessage) {
		final boolean isExplicitlyMarkedForAutoRecover = deadLetterMessage.isMarkedExplicitlyForAutoRecovery();
		
		if(isExplicitlyMarkedForAutoRecover){
			return true;
		}
		final ErrorCode errorCode = deadLetterMessage.getErrorCode();
		if (errorCode == null) {
			return true;
		}
		return RecoverableErrors.contains(errorCode);
	}

}
