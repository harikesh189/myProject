package com.hcentive.billing.core.service.health.event.listener;

import com.hcentive.billing.core.commons.event.EventListener;
import com.hcentive.billing.core.commons.event.EventSubscription;

public class DeadEventMessageListener implements EventListener {

	@Override
	public String handlerId() {
		return null;
	}

	@Override
	@EventSubscription(eventName="MQConstants.TTL_DEAD_LETTER_ROUTING_KEY")
	public void handle(Object eventPayload) {

	}

	@Override
	public boolean recieveOfflineEvents() {
		return true;
	}

}
