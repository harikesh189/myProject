package com.hcentive.billing.core.service.health.event.scheduler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;

import com.hcentive.billing.commons.workflow.WorkflowManager;
import com.hcentive.billing.commons.workflow.WorkflowProcessStatus;
import com.hcentive.billing.commons.workflow.si.WorkflowProcessingSnapshotVault;
import com.hcentive.billing.core.commons.security.SystemUserOperation;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.commons.batch.process.MultiTenantSupportItemReader;
import com.hcentive.commons.batch.process.RoundRobbinTenantDataReadStrategy;
import com.hcentive.commons.batch.process.TenantBasedItemReaderFactory;
import com.hcentive.commons.batch.process.TenantProvider;

public class ResumableFlowScheduler {

	private static final Logger LOGGER = LoggerFactory.getLogger(ResumableFlowScheduler.class);

	@Value("${event.resumeable.event.fetch.size:5}")
	private int pageSize;

	@Autowired
	private WorkflowManager wfManager;

	@Autowired
	private TenantProvider tenantProvider;
	
	@Autowired
	private WorkflowProcessingSnapshotVault snapshotVault;

	@Scheduled(cron = "${event.resumable.scheduler.job.interval:0 * * * * ?}")
	@SystemUserOperation
	public void resumeResumableWorkflow() {
		//find all whose snapshot is marked as resume
		//use tenant iterator
		TenantBasedItemReaderFactory<Page<String>> resumableProcesses = new TenantBasedItemReaderFactory<Page<String>>() {
			@Override
			public ItemReader<Page<String>> itemReader(String tenantId) {
				return new ItemReader<Page<String>>() {
					private int page = -1;

					@Override
					public Page<String> read() throws Exception,
							UnexpectedInputException, ParseException,
							NonTransientResourceException {
						page++;
						List<String> resumableIds = snapshotVault.findByStatus(WorkflowProcessStatus.RESUME.name(), new PageRequest(page, pageSize));
						return new PageImpl<String>(resumableIds);
					}
				};
			}
		};
		
		MultiTenantSupportItemReader<Page<String>> processIdReader = null;
		try {
			processIdReader = new MultiTenantSupportItemReader<Page<String>>(
			        tenantProvider, resumableProcesses, RoundRobbinTenantDataReadStrategy.factory());
			if (processIdReader != null) {
				processIdReader.open(null);
				
				for (Page<String> processIds : processIdReader) {
					if (processIds != null) {
						for (String processId : processIds) {
							//call resume from workflowProcess
							LOGGER.debug("Resuming process for id {} for tenant {}", processId, TenantUtil.getTenantId());
							wfManager.resume(processId);
						}
					} else {
						LOGGER.debug("No process ids to be resumption for tenant {}", TenantUtil.getTenantId());
					}
				}
			}
		} finally {
			if (processIdReader != null) processIdReader.close(null);
		}
	}
}
