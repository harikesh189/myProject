#!/bin/bash
clear
echo "Launching Health Monitor."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/health-monitor -Xloggc:/var/log/wfm/health-monitor/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar health-monitor-1.0.RELEASE.jar --server.port=8158