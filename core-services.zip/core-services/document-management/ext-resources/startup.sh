#!/bin/bash
clear
echo "Launching DMS Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/document-management -Xloggc:/var/log/wfm/document-management/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar document-management-1.0.RELEASE.jar --server.port=8081