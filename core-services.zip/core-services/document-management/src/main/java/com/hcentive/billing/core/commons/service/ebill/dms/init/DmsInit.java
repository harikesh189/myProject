package com.hcentive.billing.core.commons.service.ebill.dms.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.service.ebill.dms.web.controller.DMSServlet;
import com.hcentive.billing.core.commons.service.ebill.dms.web.controller.DmsConttroller;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;

/**
 * Init class for the service.
 * 
 * @author uttam.tiwari
 * 
 */
@PropertySources(value = {
		@PropertySource("file:${baseDir}/config/properties/db.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"),
		@PropertySource("file:${baseDir}/config/properties/amqp.properties"),
		@PropertySource("file:${baseDir}/config/properties/file.properties"),
		@PropertySource("file:${baseDir}/config/properties/mongodb.properties"),
		@PropertySource("file:${baseDir}/config/properties/aws.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties"),
		@PropertySource("file:${baseDir}/config/properties/log4j.properties"),
		@PropertySource("file:${baseDir}/config/properties/dms.properties") })
@ComponentScan(basePackages = { "com.hcentive.billing" })
@EnableJpaRepositories(basePackages = {
		"com.hcentive.billing.core.commons.service.ebill.dms.repository",
		"com.hcentive.billing.core.commons.starter.persistence.repository","com.hcentive.billing.core.commons.persistence.factory.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EnableMongoRepositories(basePackages={"com.hcentive.billing.core.commons.starter.persistence.repository","com.hcentive.billing.core.commons.service.wfm.print.repository"})
@EntityScan("com.hcentive.billing")
@EnableAutoConfiguration
public class DmsInit {

	private static final Logger LOGGER = LoggerFactory.getLogger(DmsInit.class);
	
	

	public static void main(String[] args) throws Exception {
		LOGGER.debug("Starting Dms service for hcentive !!");
		SpringApplication.run(DmsInit.class, args);
	}

	@Bean
	public DmsConttroller dmsController() {
		return new DmsConttroller();
	}
	
	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}

	@Bean
	public ServletRegistrationBean dmsServlet() {
		return new ServletRegistrationBean(dmsServletBean(), "/dms/*");
	}
	
	@Bean
	public DMSServlet dmsServletBean(){
		return new DMSServlet();
	}
	
	
}
