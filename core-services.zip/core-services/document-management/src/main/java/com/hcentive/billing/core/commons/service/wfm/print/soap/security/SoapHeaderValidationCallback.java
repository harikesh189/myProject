/*package com.hcentive.billing.core.commons.service.wfm.print.soap.security;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.springframework.ws.soap.security.callback.AbstractCallbackHandler;

import scala.annotation.meta.setter;

public class SoapHeaderValidationCallback extends AbstractCallbackHandler {

	@Override
	protected void handleInternal(Callback callback) throws IOException,
			UnsupportedCallbackException {
      if (callback instanceof CustomHeaderCallback) {
		final CustomHeaderCallback customHeaderCallback=(CustomHeaderCallback) callback;
	final String accessToken=customHeaderCallback.getAccessToken();
	final String tenantId=customHeaderCallback.getTenantId();
	final String ipAddress=customHeaderCallback.getIpAddress();
	
		
	}		
	}

}
*/