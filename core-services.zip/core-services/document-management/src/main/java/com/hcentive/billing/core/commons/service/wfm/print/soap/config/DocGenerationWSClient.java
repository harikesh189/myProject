package com.hcentive.billing.core.commons.service.wfm.print.soap.config;
/*package com.hcentive.billing.commons.pdfgeneration.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.hcentive.billing.commons.pdfgeneration.domain.DocumentGenerationRequest;
import com.hcentive.billing.commons.pdfgeneration.domain.DocumentGenerationRequest.DocumentDetails;
import com.hcentive.billing.commons.pdfgeneration.domain.DocumentGenerationRequest.DocumentDetails.DocumentIdentificationKeys;
import com.hcentive.billing.commons.pdfgeneration.domain.DocumentGenerationRequest.Header;
import com.hcentive.billing.commons.pdfgeneration.domain.DocumentGenerationRequest.TransactionInformation;
import com.hcentive.billing.commons.pdfgeneration.domain.DocumentGenerationResponse;

@Component
public class DocGenerationWSClient {
	
	@Value("${notices.pdf.generation.url:http://hix.dev.docgen.demo.hcentive.com:9090/document-generation/rest/generateDocument}")
	private String pdfServiceUrl;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public DocumentGenerationResponse consumeRestCall(){
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		headers.setContentType(MediaType.APPLICATION_XML);
		DocumentGenerationRequest request = new DocumentGenerationRequest();
		TransactionInformation information=new TransactionInformation();
		information.setControlNumber("p:ControlNumber8");
		information.setSourceSystemId("AR");
		request.setTransactionInformation(information);
		DocumentDetails details=new DocumentDetails();
		details.setDocumentData("sadasdasdas");
		details.setDocumentPaperPrintFlag("Y");
		DocumentIdentificationKeys documentIdentificationKeys=new DocumentIdentificationKeys();
		documentIdentificationKeys.setBusinessKey1("j");
		details.setDocumentIdentificationKeys(documentIdentificationKeys);
		request.setDocumentDetails(details);
		Header header=new Header();
		header.setVersionNumber("1.0");
		request.setHeader(header);


		HttpEntity<DocumentGenerationRequest> httpEntityrequest = new HttpEntity<DocumentGenerationRequest>(request, headers);
		ResponseEntity<DocumentGenerationResponse> response = restTemplate.postForEntity(pdfServiceUrl, httpEntityrequest, DocumentGenerationResponse.class);
      return response.getBody();
		  
	}
	
	
	
	
	

}
*/