package com.hcentive.billing.core.commons.service.wfm.print.soap.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.Operator;
import com.hcentive.billing.core.commons.persistence.factory.repository.OperatorRepository;
import com.hcentive.billing.core.commons.service.security.filter.HttpCreateProcessContextFilter;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.web.WebUtils;

/**
 * Filter to initialize process context from SOAP URL.
 * 
 * @author ajay.saxena
 * 
 */
public class DmsProcessContextFilter extends HttpCreateProcessContextFilter {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DmsProcessContextFilter.class);

	@Autowired
	private OperatorRepository operatorRepository;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		LOGGER.debug("Inside dofilter");

		if (isSoapURL(request)) {
			LOGGER.debug("Initializing process context.");
			createProcessContextFromSoapUrl(request);
			LOGGER.debug("filter processing completed");
		}
		else{
			LOGGER.debug("This is not a soap call hence creating process context from logged in user");
			createProcessContextFromLoggedInUser(request);
		}
		try {
			chain.doFilter(request, response);
		} finally {
			ProcessContext.clear();
		}
	}

	private boolean isSoapURL(ServletRequest request) {
		final String path = ((HttpServletRequest) request).getRequestURI();
		if (path.contains("/soap/wfm"))
			return true;
		return false;
	}

	protected void createProcessContextFromSoapUrl(final ServletRequest request) {
		final String[] path = WebUtils.pathItems(request);
		final String tenantId = WebUtils.resolve(request, path.length-1);
		LOGGER.debug("tenant id is {}", tenantId);

		if (null == tenantId || tenantId.isEmpty()) {
			throw new IllegalAccessError("No tenant configured");
		}
		final Operator operator = operatorRepository.findByExternalId(tenantId);
		if (null == operator) {
			throw new IllegalAccessError(
					"No operator configured for tenant id " + tenantId);
		}
		LOGGER.debug("Building Process Context with metadata for tenant {}",
				tenantId);
		ProcessContext.clear();
		ProcessContext.initializer().initialize().setTenantId(tenantId);
		LOGGER.debug("Process context created");
	}

	/*
	 * @Override protected String[] getIgnorePathPattern() { return
	 * this.ignorePattern; }
	 */
}
