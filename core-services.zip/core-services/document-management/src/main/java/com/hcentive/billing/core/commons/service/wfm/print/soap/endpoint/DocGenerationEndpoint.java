package com.hcentive.billing.core.commons.service.wfm.print.soap.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.hcentive.billing.core.commons.service.wfm.print.soap.api.DocGenerationService;
import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckRequest;
import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckResponse;

@Endpoint
public class DocGenerationEndpoint {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DocGenerationEndpoint.class);

	private static final String NAMESPACE_URI = "http://documentgenack.hcentive.com";

	@Autowired
	private DocGenerationService docGenerationService;
	

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "DocumentGenerationAckRequest")
	@ResponsePayload
	public DocumentGenerationAckResponse getResponse(
			@RequestPayload DocumentGenerationAckRequest request) {
		LOGGER.debug("Building the response from the request {}", request);
		final DocumentGenerationAckResponse documentGenerationAckResponse = docGenerationService
				.processDocumentGenerationRequest(request);
		return documentGenerationAckResponse;

	}

}
