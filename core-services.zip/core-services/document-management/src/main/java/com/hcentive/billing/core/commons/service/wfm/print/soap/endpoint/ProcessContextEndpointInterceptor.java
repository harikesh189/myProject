package com.hcentive.billing.core.commons.service.wfm.print.soap.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckRequest;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class ProcessContextEndpointInterceptor implements EndpointInterceptor {

	private static final String HCENTIVE_TENANT_DEFAULT = "HCENTIVE";

	private ApplicationContext appContext;

	@Autowired
	private Jaxb2Marshaller jaxb2Marshaller;

	@Autowired
	private MongoTemplate mongoTemplate;

	/*
	 * @Autowired private PrintJobRepository printJobRepository;
	 */

	@Override
	public boolean handleRequest(MessageContext messageContext, Object endpoint)
			throws Exception {
		final SaajSoapMessage saajSoapMessage = (SaajSoapMessage) messageContext
				.getRequest();
		final SoapBody requestBody = saajSoapMessage.getSoapBody();
		Object obj = jaxb2Marshaller.unmarshal(requestBody.getPayloadSource());
		if (obj instanceof DocumentGenerationAckRequest) {
			final String trackingId = ((DocumentGenerationAckRequest) obj)
					.getRequestTrackingNumber();
			if (null == trackingId || trackingId.isEmpty())
				throw new IllegalArgumentException(
						"No trackingId provided from Print Service");

			final PrintJob printJob = mongoTemplate.findOne(
					buildQueryOnTrackingId(trackingId), PrintJob.class);
			ProcessContext.clear();
			ProcessContext.initializer().initialize()
					.setTenantId(printJob.getPrintItem().getTenantId());
			return true;
		}
		return false;
	}

	private Query buildQueryOnTrackingId(final String trackingId) {
		final Query query = Query.query(Criteria.where("trackingId").is(
				trackingId));
		return query;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext, Object endpoint)
			throws Exception {
		return false;
	}

	@Override
	public boolean handleFault(MessageContext messageContext, Object endpoint)
			throws Exception {
		return false;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Object endpoint,
			Exception ex) throws Exception {
	}
}
