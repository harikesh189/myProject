package com.hcentive.billing.core.commons.service.wfm.print.soap.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckRequest;
import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckResponse;

/**
 * Util class to process SOAP response.
 * 
 * @author ajay.saxena
 *
 */
public final class PrintSoapUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PrintSoapUtil.class);
	
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	
	public static final DocumentGenerationAckResponse processFailure(DocumentGenerationAckRequest request) {
		DocumentGenerationAckResponse response = new DocumentGenerationAckResponse();
		response.setRequestStatus(FAILURE);
		final StringBuilder errorMsg = new StringBuilder();
		errorMsg.append("Tracking id is ").append(request.getRequestTrackingNumber()).append("and DCIN no is ").append(request.getDCIN());
		LOGGER.debug("error msg is {}",errorMsg.toString());
		response.getMessage().add(errorMsg.toString());
		return response;
	}

	public static DocumentGenerationAckResponse buildSuccessAckResponse() {
		DocumentGenerationAckResponse ackResponse = new DocumentGenerationAckResponse();
		ackResponse.setRequestStatus(SUCCESS);
		return ackResponse;
	}

}
