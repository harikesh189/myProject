@javax.xml.bind.annotation.XmlSchema(namespace = "http://documentgenack.hcentive.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.hcentive.billing.core.commons.service.wfm.print.soap.pojo;
