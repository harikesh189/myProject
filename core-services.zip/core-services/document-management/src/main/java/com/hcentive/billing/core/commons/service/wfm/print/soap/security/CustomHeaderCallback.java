package com.hcentive.billing.core.commons.service.wfm.print.soap.security;

import java.io.Serializable;

import javax.security.auth.callback.Callback;

public class CustomHeaderCallback implements Callback ,Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tenantId;
	private String accessToken;
	private String ipAddress;
	
	
	
	private CustomHeaderCallback(){}
	
	public  CustomHeaderCallback(final String tenantId,final String accessToken,final String ipAddress){
		if(tenantId == null || accessToken == null || ipAddress==null){
			throw new IllegalArgumentException("tenant id or access token cannot be null");
		}
	}
	
	public String getTenantId() {
		return tenantId;
	}
	
	public String getAccessToken() {
		return accessToken;
	}
	
	public String getIpAddress() {
		return ipAddress;
	}
	
	
	
	

}
