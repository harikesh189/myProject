/*package com.hcentive.billing.core.commons.service.wfm.print.soap.config;



import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationRequest;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationResponse;

public class DocGenerationClient extends WebServiceGatewaySupport {
	
public DocumentGenerationResponse getResponse(final DocumentGenerationRequest  documentGenerationRequest){
	final DocumentGenerationResponse documentGenerationResponse=new DocumentGenerationResponse();
	documentGenerationResponse.setControlNumber(documentGenerationRequest.getTransactionInformation().getControlNumber());
	documentGenerationResponse.setRequestStatus("Success");
	documentGenerationResponse.setRequestTrackingNumber("request tracking no");
	DocumentGenerationRequest request = new DocumentGenerationRequest();
	request.setHeader(documentGenerationRequest.getHeader());
	request.setDocumentDetails(documentGenerationRequest.getDocumentDetails());
	request.setTransactionInformation(documentGenerationRequest.getTransactionInformation());
	final DocumentGenerationResponse documentGenerationResponse=(DocumentGenerationResponse) getWebServiceTemplate().marshalSendAndReceive(documentGenerationRequest);
	return documentGenerationResponse;
	
	
}
public DocumentGenerationResponse printResponse(DocumentGenerationResponse response) { 
	final String requestTrackingNumber=response.getRequestTrackingNumber();
	  final String x=response.getControlNumber();
	  response.getResponses().get(0).getResponseCode();
	  return response;
			  
	   final List<DocumentGenerationResponseMetaData> datas=response.getResponses();
	   for (DocumentGenerationResponseMetaData documentGenerationResponseMetaData : datas) {
		System.out.println(documentGenerationResponseMetaData.getResponseCode());
		System.out.println(documentGenerationResponseMetaData.getResponseDescriptionText());
		System.out.println(documentGenerationResponseMetaData.getErrorDescriptionText().size());
	}
}

*/