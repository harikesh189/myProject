package com.hcentive.billing.core.commons.service.wfm.print.soap.api.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJobStatus;
import com.hcentive.billing.core.commons.service.wfm.print.repository.PrintJobRepository;
import com.hcentive.billing.core.commons.service.wfm.print.soap.api.DocGenerationService;
import com.hcentive.billing.core.commons.service.wfm.print.soap.endpoint.PrintSoapUtil;
import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckRequest;
import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckResponse;
import com.hcentive.billing.core.commons.service.wfm.print.util.PrintUtil;

@Component
public class DocGenerationServiceImpl implements DocGenerationService {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DocGenerationServiceImpl.class);

	private final Map<String, String> eventMapping = new HashMap<>();

	@Autowired
	private PrintJobRepository printJobRepository;

	@Override
	public DocumentGenerationAckResponse processDocumentGenerationRequest(
			DocumentGenerationAckRequest request) {

		LOGGER.debug("processing PDF service request from SOAP.");

		if (null == request.getRequestTrackingNumber()
				|| null == request.getDCIN()) {
			LOGGER.debug("Either DCN number is null or tracking number is NULL");
			return PrintSoapUtil.processFailure(request);
		}
		return processSuccess(request);
	}

	private DocumentGenerationAckResponse processSuccess(
			DocumentGenerationAckRequest request) {

		final String DCINNumber = request.getDCIN();
		final String requestTrackingNumber = request.getRequestTrackingNumber();
		final PrintJob printJob = printJobRepository
				.findByTrackingId(requestTrackingNumber);

		if (null == printJob)
			throw new IllegalArgumentException("No print job with tracking id "
					+ requestTrackingNumber + " existin in system.");

		printJob.setDcinNo(DCINNumber);
		printJob.setJobStatus(PrintJobStatus.GENERATED);
		LOGGER.debug("Updating the printjob {} with the DCIN id {}",
				printJob.getExternalId(), DCINNumber);
		printJobRepository.save(printJob);
		LOGGER.debug("printjob {} updated with the DCIN id {}",
				printJob.getExternalId(), DCINNumber);
		doPostProcessing(printJob);
		return PrintSoapUtil.buildSuccessAckResponse();
	}

	private void doPostProcessing(final PrintJob printJob) {
		PrintUtil.processGenereatedPrintJob(printJob);
	}

}