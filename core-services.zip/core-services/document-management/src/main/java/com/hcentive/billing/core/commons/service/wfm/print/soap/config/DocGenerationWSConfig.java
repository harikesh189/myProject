package com.hcentive.billing.core.commons.service.wfm.print.soap.config;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import com.hcentive.billing.core.commons.service.security.filter.CookieBasedSecuredAccessDataExtractor;
import com.hcentive.billing.core.commons.service.util.FilterRegistrationUtil;
import com.hcentive.billing.core.commons.service.wfm.print.soap.endpoint.ProcessContextEndpointInterceptor;
import com.hcentive.billing.core.commons.service.wfm.print.soap.filter.DmsProcessContextFilter;

@EnableWs
@Configuration
public class DocGenerationWSConfig  {
	
	@Value(value="${document.soap.ackUrl:/dms/soap/wfm/*}")
	private String urlMapping;
	
	@Value(value = "${cookie.based.secured.access.token.based.filter.path:/*}")
	public String cookieBasedSecuredAccessTokenBasedFilterPath;


	@Bean
	public ServletRegistrationBean messageDispatcherServlet(
			ApplicationContext applicationContext) {
		MessageDispatcherServlet servlet = new MessageDispatcherServlet();
		servlet.setApplicationContext(applicationContext);
		servlet.setTransformWsdlLocations(true);
		return new ServletRegistrationBean(servlet,urlMapping);
	}

	@Bean(name = "docgenack")
	public DefaultWsdl11Definition defaultWsdl11Definition(XsdSchema xsdSchema) {
		DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
		wsdl11Definition.setPortTypeName("Docgenack");
		wsdl11Definition.setLocationUri("/ws");
		wsdl11Definition.setSchema(xsdSchema);
		wsdl11Definition
				.setTargetNamespace("http://documentgenack.hcentive.com");
		return wsdl11Definition;
	}

	@Bean
	public XsdSchema xsdSchema() {
		return new SimpleXsdSchema(new ClassPathResource(
				"DocumentGenAckRequestResponse.xsd"));
	}

	@Bean
	public EndpointInterceptor processContextEndpointInterceptor() {
		ProcessContextEndpointInterceptor contextEndpointInterceptor = new ProcessContextEndpointInterceptor();
		return contextEndpointInterceptor;
	}

	@Bean
	public Jaxb2Marshaller jaxb2Marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller
				.setContextPath("com.hcentive.billing.core.commons.service.wfm.print.soap.pojo");
		return marshaller;
	}

	@Bean
	public DmsProcessContextFilter httpCreateProcessContextFilter() {
		return new DmsProcessContextFilter();
	}

	@Bean
	public FilterRegistrationBean createProcessContextFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil
				.createRegistrationBean(httpCreateProcessContextFilter(), "/*");
		filterRegistrationBean.setOrder(6);
		return filterRegistrationBean;
	}
	
	@Bean
	public CookieBasedSecuredAccessDataExtractor cookieBasedSecuredAccessDataExtractor() {
		return new CookieBasedSecuredAccessDataExtractor(){
			@Override
			protected void sendRedirectWithAngularContext(
					HttpServletRequest httpRequest,
					HttpServletResponse httpServletResponse, String clientId,
					String[] pathArray) throws IOException {
				// TODO Auto-generated method stub
				// Do nothing
			}
		};
	}
	
	@Bean
	public FilterRegistrationBean createCookieBasedSecuredDataAccessFilterRegistration() {
		String[] securedAccessPaths = splitFilterPathByComma(cookieBasedSecuredAccessTokenBasedFilterPath);
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(cookieBasedSecuredAccessDataExtractor(), securedAccessPaths);
		filterRegistrationBean.setOrder(4);
		return filterRegistrationBean;
	}
	private String[] splitFilterPathByComma(final String securedAccessTokenBasedFilterPath) {
		final String[] filterPaths = securedAccessTokenBasedFilterPath.split(",");
		return filterPaths;
	}

}
