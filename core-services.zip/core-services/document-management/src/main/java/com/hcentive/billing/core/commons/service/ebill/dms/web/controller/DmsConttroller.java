package com.hcentive.billing.core.commons.service.ebill.dms.web.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.locks.Lock;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hcentive.billing.commons.dms.util.DMSException;
import com.hcentive.billing.core.commons.cache.CacheClient;
import com.hcentive.billing.core.commons.concurrent.LockProvider;
import com.hcentive.billing.core.commons.otp.OTPProvider;
import com.hcentive.billing.core.commons.service.ebill.dms.service.DmsServiceManager;
import com.hcentive.billing.core.commons.service.ebill.dms.service.utility.DMSUtil;
import com.hcentive.billing.core.commons.service.ebill.dms.service.utility.KeyGenerator;

/**
 * @author Uttam Tiwari
 */

// @RestController
@RequestMapping("dms")
public class DmsConttroller {

	@Autowired
	private DmsServiceManager dmsManager;

	@Autowired
	private KeyGenerator keygen;

	@Autowired
	private CacheClient<String, Object> elasticCacheClient;
	
	@Autowired
	private OTPProvider otpProvider;
	
	@Autowired
	private LockProvider lockProvider;

	@Value("${otp.expirytime.seconds}")
	private Integer otpExpiryTimeInSec;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DmsConttroller.class);

	// @RequestMapping(method = RequestMethod.POST, value="/upload")
	public String upload(HttpServletRequest request, Map<String, String> headers)
			throws Exception {
		LOGGER.debug("Uploading stream .");
		String key = null;
		String contentClass = null;
		InputStream stream = null;
		try {
			stream = request.getInputStream();
			key = keygen.getKey();
			LOGGER.debug("Key generated is {}", key);
			contentClass = DMSUtil.getContentClass(stream);
			dmsManager.upload(stream, key, contentClass, headers);
			LOGGER.debug("Upload has been succesful for conent type="
					+ contentClass + " key=" + key);
		} catch (Throwable e) {
			LOGGER.error("Exception while uploading doc");
			throw new DMSException("Upload failed",e);
		} finally {
			if (null != stream) {
				LOGGER.debug("Closing the input stream.");
				stream.close();
			}
		}
		// AuditUtil.audit(AuditEventType.OTHER, DMS_UPLOAD_SUCCESS,
		// "contentClass",contentClass, "key", key);
		return key;

	}

	/**
	 * Method checks if key is valid and returns a one time token to download
	 * the file ,referenced through key.
	 * 
	 * @param key
	 * @return One time download token.
	 */
	public String getDownloadOTP(final String key) {
		if (dmsManager.isValidKey(key)) {
			Lock lock = null;
			String otp = null;
			try {
				lock = lockProvider.getLock(key);
				lock.lock();
				otp = String.valueOf(otpProvider.generateOTP());
				elasticCacheClient.put(otp, key, otpExpiryTimeInSec);
				LOGGER.debug("otp {} , for key {} is valid for {} secs", otp, key,
						otpExpiryTimeInSec);
			} catch (Exception e) {
				LOGGER.error("Error while generationg opt.Set value of otp as false ",e);
				otp = "false";
			}finally{
				lockProvider.release(lock);
			}
			return otp;
		}
		LOGGER.error("No entry in system for key {} in document-info table", key);
		return "false";

	}

	// @RequestMapping(method = RequestMethod.GET, value="/download/{key}")
	public @ResponseBody
	HttpServletResponse download(final String key, HttpServletResponse response) {
		final String dmsKey = (String) elasticCacheClient.get(key);
		if(null == dmsKey){
			LOGGER.error("No dmskey found. OTP {} has expired ", key);
			throw new IllegalAccessError("No dmskey found. OTP "+key+" has expired. Please retry.");
		}
		LOGGER.debug("Building the input stream from the dms key " + dmsKey);
		InputStream pdfInputStream = null;
		// Setting content type to application / pdf.
		response.setContentType("application/pdf");
		ServletOutputStream os = null;
		// Setting content type to application / pdf.
		response.setContentType("application/pdf");
		try {
			pdfInputStream = dmsManager.download(dmsKey);
			os = response.getOutputStream();
			final byte[] bufferData = new byte[1024];
			int read = 0;
			LOGGER.debug("Writing the data to output stream");
			while ((read = pdfInputStream.read(bufferData)) != -1) {
				os.write(bufferData, 0, read);
			}
		} catch (Throwable e) {
			LOGGER.error("Error while downloading file with key " + key
					+ " and dmskey " + dmsKey + "from dms server.", e);
		} finally {
			try {
				if (os != null) {
					LOGGER.debug("Flusing the output stream");
					os.flush();
					LOGGER.debug("Closing the output stream ");
					os.close();
				}
			} catch (IOException e) {
				LOGGER.error("Error while closing the output stream.", e);
			}
			try {
				if (pdfInputStream != null) {
					LOGGER.debug("Closing the input stream");
					pdfInputStream.close();
				}
			} catch (IOException e) {
				LOGGER.error("Error while closing the input stream.", e);
			}
		}
		return response;
	}

	// @RequestMapping(method = RequestMethod.GET, value="/remove/{key}")
	public String remove(final String key) {
		Boolean status = dmsManager.remove(key);
		return status.toString();
	}

}
