package com.hcentive.billing.core.commons.service.wfm.print.soap.api;

import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckRequest;
import com.hcentive.billing.core.commons.service.wfm.print.soap.pojo.DocumentGenerationAckResponse;

public interface DocGenerationService {
	
	DocumentGenerationAckResponse  processDocumentGenerationRequest(final DocumentGenerationAckRequest ackRequest);

}
