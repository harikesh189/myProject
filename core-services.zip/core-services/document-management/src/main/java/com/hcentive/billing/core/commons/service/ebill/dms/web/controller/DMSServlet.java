package com.hcentive.billing.core.commons.service.ebill.dms.web.controller;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

/**
 * @author Uttam Tiwari
 */

public class DMSServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6152281838843603307L;
	private static final Logger LOGGER = LoggerFactory.getLogger(DMSServlet.class);

	@Value(value = "${dms.service.supported.urls}")
	private String dmsSupportedUrls;

	private static final Set<String> validDmsURLs = new HashSet<>();

	@Autowired
	private DmsConttroller dmsController;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, config.getServletContext());
	}

	@PostConstruct
	public void populateValidURLs() {
		LOGGER.debug("dmsSupportedURLS {}", dmsSupportedUrls);
		if (null == dmsSupportedUrls || dmsSupportedUrls.isEmpty()) {
			throw new IllegalStateException(
					"No DMS URLs configured. Check value of key dms.service.supported.urls in properties file of application.");
		}

		final StringTokenizer st = new StringTokenizer(dmsSupportedUrls, ",");
		LOGGER.debug("Splitting URLs in property file dmsSupportedUrls");
		while (st.hasMoreElements()) {
			validDmsURLs.add(st.nextElement().toString());
		}
		LOGGER.debug("validDMSUrls are {}", validDmsURLs);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		final String path = req.getPathInfo();
		LOGGER.debug("url from request is {}", path);
		if (!isAValidURL(path)) {
			LOGGER.error(
					"No matching URL mapping found for path {}. DMS supported URLS are {}, configured through key dms.service.supported.urls in properties file of application",
					path, validDmsURLs);
			resp.setStatus(HttpStatus.SC_NOT_FOUND);
			return;
		}
		try {
			Map<String, String> headers = getDmsHeaders(req);
			resp.getWriter().write(dmsController.upload(req, headers));
		} catch (Exception e) {
			LOGGER.error("Exception occured::", e);
			resp.getWriter().write("false");
		} finally {
			resp.getWriter().flush();
			resp.getWriter().close();
		}

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		final String path = req.getPathInfo();
		LOGGER.debug("Inside do get method path is {}", path);
		String key = null;
		if (null != path && path.endsWith("")) {
			key = path.substring(path.lastIndexOf("/") + 1);
			if (key == null || key.isEmpty()) {
				LOGGER.error("Key is null or empty {}", key);
				throw new IllegalStateException("Key is NULL or EMPLTY");
			}

			final String url = path.substring(0, path.lastIndexOf("/"));
			LOGGER.debug("URL path is {}", url);
			if (!isAValidURL(url)) {
				LOGGER.error(
						"No matching URL mapping found for path {}. DMS supported URLS are {}, configured through key dms.service.supported.urls in properties file of application",
						path, validDmsURLs);
				resp.setStatus(HttpStatus.SC_NOT_FOUND);
				return;
			}
			try {
				if (StringUtils.containsIgnoreCase(url, "/remove")) {
					LOGGER.debug("Call is to remove the key");
					resp.getWriter().write(dmsController.remove(key));
					resp.getWriter().flush();
					resp.getWriter().close();
					LOGGER.debug("Call to remove the key done");
				} else if (StringUtils.containsIgnoreCase(url, "/otp")) {
					LOGGER.debug("Call is to get otp for the key");
					resp.getWriter().write(dmsController.getDownloadOTP(key));
					resp.getWriter().flush();
					resp.getWriter().close();
					LOGGER.debug("Call is get otp for the key done");
				} else if (StringUtils.containsIgnoreCase(url, "/download")) {
					LOGGER.debug("Call is to download the document for key {}", key);
					dmsController.download(key, resp);
				} else {
					LOGGER.error("No matching URL mapping found.");
					resp.setStatus(HttpStatus.SC_NOT_FOUND);
				}
			} catch (Throwable e) {
				LOGGER.error("Servlet errror:", e);
			}
		} else {
			LOGGER.error(
					"No matching URL mapping found for path {}. DMS supported URLS are {}, configured through key dms.service.supported.urls in properties file of application",
					path, validDmsURLs);
			resp.setStatus(404);
		}
	}

	private boolean isAValidURL(String url) {
		return validDmsURLs.contains(url);
	}

	private Map<String, String> getDmsHeaders(HttpServletRequest req) {
		Map<String, String> headers = new Hashtable<String, String>();
		Enumeration<String> enumration = req.getHeaderNames();
		while (enumration != null && enumration.hasMoreElements()) {
			String headerName = enumration.nextElement();
			if (StringUtils.containsIgnoreCase(headerName, "dms_")) {
				String headervalue = req.getHeader(headerName);
				headers.put(headerName, headervalue);
			}
		}
		return headers;
	}

}
