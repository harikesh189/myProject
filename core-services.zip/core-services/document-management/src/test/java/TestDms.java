import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;

/**
 * @author Uttam Tiwari
 */

public class TestDms {

	public static void main(String[] args) throws Exception {

		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost postRequest = new HttpPost(
				"http://localhost:8081/dms/upload/post");
		// StringEntity input = new StringEntity("uttam tiwari");
		File file = new File(
				"C:\\Users\\ajay.saxena\\Pictures\\biodata_2014.zip");
		InputStreamEntity input = new InputStreamEntity(new FileInputStream(
				file), file.length());
		postRequest.setEntity(input);
		HttpResponse response = httpClient.execute(postRequest);
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(response.getEntity().getContent())));
		String output;
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
			System.out.println(output);
		}

		httpClient.getConnectionManager().shutdown();
	}

}
