package com.hcentive.billing.core.commons.service.app.gateway.security.filter;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import com.hcentive.billing.core.commons.service.security.filter.FilterErrorHandler;

public class UIFilterErrorHandler implements FilterErrorHandler {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(UIFilterErrorHandler.class);

	private final PathMatcher pathMatcher = new AntPathMatcher();

	@Value(value = "${security.error.session.time.out.pattern:/**/*.html,/**/*.png,/**/*.gif,/**/*.bmp,/**/*.js,/**/*.ico,/**/*.svg,/**/*.less,/**/*.map,/**/*.css}")
	private String[] sessionTimeOutPattern;

	@Override
	public void handleSessionTimeOut(HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, final String errorUrl)
			throws IOException {
		final String requestPath = httpRequest.getRequestURI();
		for(final String customResourcePattern : sessionTimeOutPattern){
			LOGGER.debug("Checking for requestPath: {} against pattern: {} ",requestPath,customResourcePattern);
			if(pathMatcher.isPattern(customResourcePattern) && pathMatcher.match(customResourcePattern, requestPath)){
				httpServletResponse.sendError(HttpServletResponse.SC_GATEWAY_TIMEOUT);
				return;
			}else{
				if(requestPath.equalsIgnoreCase(customResourcePattern)){
					httpServletResponse.sendError(HttpServletResponse.SC_GATEWAY_TIMEOUT);
					return;
				}
			}
		}
		LOGGER.debug("Redirect to error URL");
		httpServletResponse.sendRedirect(errorUrl);
	}
	
	@Override
	public void handleAuthenticationFailed(HttpServletRequest request,
			HttpServletResponse response, final String errorUrl)
			throws IOException {
		LOGGER.error("Redirecting to Error URl : {}", errorUrl);
		response.sendRedirect(errorUrl);
	}

}
