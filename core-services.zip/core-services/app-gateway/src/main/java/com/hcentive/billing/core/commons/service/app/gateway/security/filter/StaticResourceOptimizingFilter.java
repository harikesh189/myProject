/**
 * 
 */
package com.hcentive.billing.core.commons.service.app.gateway.security.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * 
 * Filter to add HTTP headers for optimizing static resources.
 * 
 * @author Kumar Sambhav Jain
 * @since Nov 9, 2015
 *
 */
public class StaticResourceOptimizingFilter extends OncePerRequestFilter {

	/**
	 * Logger.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(StaticResourceOptimizingFilter.class);

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String requestURI = request.getRequestURI();
		if ((requestURI.endsWith("gz.js") || requestURI.endsWith("gz.css"))) {
			LOG.debug("Adding CONTENT_ENCODING header");
			response.setHeader(HttpHeaders.CONTENT_ENCODING, "gzip");
			response.setHeader(HttpHeaders.CACHE_CONTROL, "max-age=7200");
		}

		filterChain.doFilter(request, response);

	}

}
