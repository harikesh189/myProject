package com.hcentive.billing.core.commons.service.app.gateway.support;



public class UIContext {

	public static final ThreadLocal<UIContext> THREAD_LOCAL_UI_CONTEXT = new ThreadLocal<UIContext>();

	public static UIContext get() {
		return THREAD_LOCAL_UI_CONTEXT.get();
	}
	
	public static void clear(){
		THREAD_LOCAL_UI_CONTEXT.remove();
	}

	public static UIContext initialize(final String appKey){
		final UIContext context = new UIContext(appKey);
		THREAD_LOCAL_UI_CONTEXT.set(context);
		return context;
	}
	
	private final String appKey;

	private UIContext(String appKey) {
		super();
		this.appKey = appKey;
	}
	
	public String appKey(){
		return this.appKey;
	}
	
}
