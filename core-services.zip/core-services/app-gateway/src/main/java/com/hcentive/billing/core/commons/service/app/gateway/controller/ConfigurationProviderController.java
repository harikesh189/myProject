package com.hcentive.billing.core.commons.service.app.gateway.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.service.app.gateway.dto.ConfigResponse;
import com.hcentive.billing.core.commons.service.app.gateway.dto.ConfigResponse.Status;
import com.hcentive.billing.core.commons.service.app.gateway.service.ConfigurationProviderManager;

/**
 * The Class ConfigurationProviderController.
 * 
 * @author amit.agarwal
 * 
 *         Controller to handle load, update and save configuration.
 */

@RestController
@RequestMapping("configurations")
public class ConfigurationProviderController {
	
	
	private static final String GA_KEY = "ANALYTICS_CODE";

	@Autowired
	private ConfigurationProviderManager configProviderMngr;

	private static final Logger logger = LoggerFactory
			.getLogger(ConfigurationProviderController.class);

	@Autowired
	private WFMCache cache;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/removeKeys", method = RequestMethod.POST)
	public List<ConfigResponse> removeConfiguartionFromCache(
			@RequestBody final List<String> keys) {
		final List<ConfigResponse> configList = new ArrayList<ConfigResponse>();
		logger.debug("Removing keys from cache");
		for (String key : keys) {
			logger.debug("Removing entry from cache for key : {}", key);
			ConfigResponse configResponse = new ConfigResponse();
			configResponse.setKey(key);
			if (cache.get(key) != null) {
				logger.debug("Key :{} removed successfully", key);
				configResponse.setStatus(Status.SUCCESS);
				cache.remove(key);
			} else {
				logger.debug("Not able to remove key : {}", key);
				configResponse.setStatus(Status.FAIL);
			}
			configList.add(configResponse);
		}
		return configList;
	}

	/**
	 * Loads all configurations for tenant.
	 * 
	 * @param tenantId
	 *            the tenant id
	 * @return the list
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value ="/{beType}/{beId}" ,method = RequestMethod.POST, produces = "application/json")
	public List loadAllConfiguration(@PathVariable("beType") String beType, @PathVariable("beId") String beId) {
		logger.debug("Fetching configurations for tenant ");
		return configProviderMngr.getAllConfig();
	}
	
	@RequestMapping(value ="/admin/analytics/key" ,method = RequestMethod.GET)
	public Map<String,String> getGoogleAnalyticsKey(){
		String object = (String)configProviderMngr.get(GA_KEY);
		Map<String,String> map = new HashMap<>(1);
		map.put(GA_KEY, object);
		logger.debug("Google Analytics key fetch from configration is {}",object);
		return map;
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/admin" ,method = RequestMethod.POST, produces = "application/json")
	public List loadAllConfigurationForAdmin() {
		logger.debug("Fetching configurations for tenant ");
		return configProviderMngr.getAllConfig();
	}

	/**
	 * Loads configuration for a key.
	 * 
	 * @param key
	 *            the key
	 * @return the object
	 */
	@RequestMapping(value = "admin/{key}", method = RequestMethod.GET)
	public Object loadConfiguration(@PathVariable("key") String key) {
		logger.debug("Fetching  configuration for key : {}", key);
		return configProviderMngr.get(key);
	}

	/**
	 * Loads configuration for a key and subSection.
	 * 
	 * @param key
	 *            the key
	 * @param subSection
	 *            the sub section
	 * @return the object
	 */
	@RequestMapping(value = "/{key}/{subSection}", method = RequestMethod.GET)
	public Object loadConfiguration(@PathVariable("key") String key,
			@PathVariable("subSection") String subSection) {
		logger.debug(
				"Fetching  configuration for key : {} and subSection : {}",
				key, subSection);
		return configProviderMngr.get(key, subSection);
	}

	/**
	 * Saves configuration for key.
	 * 
	 * @param key
	 *            the key
	 * @param data
	 *            the data
	 */
	@RequestMapping(value = "admin/{key}", method = RequestMethod.POST)
	public void saveConfiguration(@PathVariable("key") String key,
			@RequestBody Object data) {
		logger.debug("Save  configuration for key : {} and object {}", key,
				data);
		configProviderMngr.add(key, data);
	}

	/**
	 * Saves configuration for key and subsection.
	 * 
	 * @param key
	 *            the key
	 * @param subSection
	 *            the sub section
	 * @param data
	 *            the data
	 */
	@RequestMapping(value = "/add/{key}/{subSection}", method = RequestMethod.POST)
	public void saveConfiguration(@PathVariable("key") String key,
			@PathVariable("subSection") String subSection,
			@RequestBody Object data) {
		logger.debug(
				"Save  configuration for key : {} , subSection {} and object {}",
				key, subSection, data);
		configProviderMngr.add(key, subSection, data);
	}
}
