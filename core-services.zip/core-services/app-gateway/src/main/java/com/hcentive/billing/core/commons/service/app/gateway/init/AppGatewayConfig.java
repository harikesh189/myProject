package com.hcentive.billing.core.commons.service.app.gateway.init;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.service.app.gateway.security.filter.CreateUIContextFilter;
import com.hcentive.billing.core.commons.service.app.gateway.security.filter.StaticResourceOptimizingFilter;
import com.hcentive.billing.core.commons.service.app.gateway.security.filter.UICreateProcessContextFilter;
import com.hcentive.billing.core.commons.service.app.gateway.security.filter.UIFilterErrorHandler;
import com.hcentive.billing.core.commons.service.app.gateway.security.filter.UIRootPathEnforcer;
import com.hcentive.billing.core.commons.service.app.gateway.support.AssetUtil;
import com.hcentive.billing.core.commons.service.security.filter.CookieBasedSecuredAccessDataExtractor;
import com.hcentive.billing.core.commons.service.security.filter.FilterErrorHandler;
import com.hcentive.billing.core.commons.service.security.filter.HttpSecuredAccessDataExtractor;
import com.hcentive.billing.core.commons.service.util.FilterRegistrationUtil;

@Configuration
public class AppGatewayConfig {
	
	@Value("${baseDir}")
	public String baseDirPath;
	
	@Value(value = "${cookie.based.secured.access.token.based.filter.path:/*}")
	public String cookieBasedSecuredAccessTokenBasedFilterPath;
	
	@Bean
	public MethodInvokingFactoryBean configureUIAssetDir() throws IOException {
		final MethodInvokingFactoryBean factory = new MethodInvokingFactoryBean();
		factory.setTargetClass(AssetUtil.class);
		factory.setStaticMethod("com.hcentive.billing.core.commons.service.app.gateway.support.AssetUtil.setUiAssetRootPath");
		File f = new File(baseDirPath);
		final Object[] args = {f.getCanonicalPath()+File.separator+AssetUtil.UI_ASSETS_FOLDER_NAME+File.separator };
		factory.setArguments(args);
		return factory;
	}

	@Bean
	public UIRootPathEnforcer uiRootPathEnforcer(){
		return new UIRootPathEnforcer();
	}
	
	
	@Bean
	public StaticResourceOptimizingFilter staticResourceOptimizingFilter(){
		return new StaticResourceOptimizingFilter();
	}
	
	
	@Bean
	public FilterRegistrationBean createUiRootPathEnforcer(){
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(uiRootPathEnforcer(),"/*");
		filterRegistrationBean.setOrder(3);
		return filterRegistrationBean;
	}
	
	@Bean
	public CookieBasedSecuredAccessDataExtractor cookieBasedSecuredAccessDataExtractor() {
		return new CookieBasedSecuredAccessDataExtractor();
	}

	@Bean
	public FilterRegistrationBean createCookieBasedSecuredDataAccessFilterRegistration() {
		String[] securedAccessPaths = splitFilterPathByComma(cookieBasedSecuredAccessTokenBasedFilterPath);
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(cookieBasedSecuredAccessDataExtractor(), securedAccessPaths);
		filterRegistrationBean.setOrder(4);
		return filterRegistrationBean;
	}

	private String[] splitFilterPathByComma(final String securedAccessTokenBasedFilterPath) {
		final String[] filterPaths = securedAccessTokenBasedFilterPath.split(",");
		return filterPaths;
	}
	
	@Bean
	public UICreateProcessContextFilter httpCreateProcessContextFilter() {
		return new UICreateProcessContextFilter();
	}

	@Bean
	public FilterRegistrationBean createProcessContextFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(httpCreateProcessContextFilter(), "/*");
		filterRegistrationBean.setOrder(6);
		return filterRegistrationBean;
	}
	
	@Bean
	public CreateUIContextFilter createUIContext(){
		return new CreateUIContextFilter();
	}
	
	@Bean
	public FilterRegistrationBean createUIContextFilterRegistrationBean(){
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(createUIContext(), "/*");
		filterRegistrationBean.setOrder(2);
		return filterRegistrationBean;
	}
	
	
	@Bean
	public HttpSecuredAccessDataExtractor httpSecuredAccessDataExtractor() {
		return new HttpSecuredAccessDataExtractor();
	}
	// Registering this filter for configuration
	@Bean
	public FilterRegistrationBean createHttpSecuredDataAccessFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(httpSecuredAccessDataExtractor(), "/configurations/*", "/configuration/*");
		filterRegistrationBean.setOrder(5);
		return filterRegistrationBean;
	}
	
	@Bean
	public FilterErrorHandler filterErrorHandler(){
		return new UIFilterErrorHandler();
	}
}