package com.hcentive.billing.core.commons.service.app.gateway.security.filter;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

public abstract class AppGatewayFilter {

	private static final Logger LOGGER = LoggerFactory.getLogger(AppGatewayFilter.class);

	private final PathMatcher pathMatcher = new AntPathMatcher();

	public AppGatewayFilter() {
		super();
	}

	public Boolean matchedFoundAgainstPattern(final String requestPath, final String[] pattern) {
		for (final String customResourcePattern : pattern) {
			LOGGER.debug("Checking for requestPath: {} against pattern: {} ", requestPath, customResourcePattern);
			if (pathMatcher.isPattern(customResourcePattern) && pathMatcher.match(customResourcePattern, requestPath)) {
				return true;
			} else {
				if (requestPath.equalsIgnoreCase(customResourcePattern)) {
					return true;
				}
			}
		}
		return false;
	}

	protected abstract String[] getIgnorePathPattern();

	protected boolean ignoreCurrentRequest(final ServletRequest request) {
		final String path = ((HttpServletRequest) request).getRequestURI();
		final String[] ignorePathPattern = getIgnorePathPattern();
		if (ignorePathPattern == null || ignorePathPattern.length == 0) {
			return false;
		}
		return matchedFoundAgainstPattern(path, ignorePathPattern);
	}
}