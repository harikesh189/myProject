package com.hcentive.billing.core.commons.service.app.gateway.dto;

public class ConfigResponse {

	private String key;
	private Status status;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public static enum Status {
		SUCCESS("SUCCESS"), FAIL("FAIL");

		private final String name;

		private Status(final String name) {
			this.name = name;
		}

		public static Status parse(final String value) {
			switch (value) {
			case "SUCCESS":
				return SUCCESS;
			default:
				return FAIL;
			}
		}
	}
}
