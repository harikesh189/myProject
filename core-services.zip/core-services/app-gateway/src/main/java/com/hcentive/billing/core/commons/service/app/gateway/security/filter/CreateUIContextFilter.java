package com.hcentive.billing.core.commons.service.app.gateway.security.filter;

import java.io.IOException;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.service.app.gateway.support.UIContext;
import com.hcentive.billing.core.commons.service.app.gateway.support.UiUtil;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;

public class CreateUIContextFilter extends AppGatewayFilter implements Filter {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreateUIContextFilter.class);

	@Value(value = "${config.ignore.pattern:/configurations/**,/configuration/**}")
	private final String[] configIgnorePatter = new String[0];

	@Autowired
	private WFMCache<String, Set<String>> cache;

	@Value(value = "${ui-gateway.appKey.location:2}")
	private int appKeyLocationInURL;

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		if (ignoreCurrentRequest(request)) {
			chain.doFilter(request, response);
			return;
		}
		ProcessContextUtil.initiateProcessContextWithIgnoreTenant();
		final String clientId = UiUtil.parseClientId((HttpServletRequest) request, cache.get(BillingConstant.REGISTERED_CLIENT_APPS), appKeyLocationInURL,
				appKeyLocationInURL + 1);
		ProcessContextUtil.invoilateProcessContext();
		LOGGER.debug("ClientId found as {}", clientId);
		UIContext.initialize(clientId);
		LOGGER.debug("UI Context initialized");
		chain.doFilter(request, response);
		UIContext.clear();
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	protected String[] getIgnorePathPattern() {
		// TODO Auto-generated method stub
		return configIgnorePatter;
	}

}
