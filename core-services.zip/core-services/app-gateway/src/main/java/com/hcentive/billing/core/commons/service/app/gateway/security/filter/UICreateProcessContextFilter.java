package com.hcentive.billing.core.commons.service.app.gateway.security.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.service.security.filter.HttpCreateProcessContextFilter;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class UICreateProcessContextFilter extends
		HttpCreateProcessContextFilter {

	private static final Logger logger = LoggerFactory
			.getLogger(UICreateProcessContextFilter.class);

	@Value(value = "${config.ignore.pattern:/configurations/**,/configuration/**}")
	private String[] configIgnorePattern = new String[0];
	@Override
	public void doFilter(final ServletRequest request,
			ServletResponse response, FilterChain chain) throws IOException,
			ServletException {
		if(ignoreCurrentRequest(request)){
			super.createContext(request, response, chain);
			return;
		}
		logger.debug("Inside doFilter");
		createProcessContextFromLoggedInUser(request);
		logger.debug("filter processing completed");
		chain.doFilter(request, response);
		ProcessContext.clear();
	}

	@Override
	protected String[] getIgnorePathPattern() {
		// TODO Auto-generated method stub
		return configIgnorePattern;
	}
}
