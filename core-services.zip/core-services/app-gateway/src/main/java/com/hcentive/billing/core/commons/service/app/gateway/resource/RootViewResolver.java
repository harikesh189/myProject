package com.hcentive.billing.core.commons.service.app.gateway.resource;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.web.servlet.resource.AbstractResourceResolver;
import org.springframework.web.servlet.resource.ResourceResolverChain;

import com.hcentive.billing.core.commons.service.app.gateway.support.UIContext;

public class RootViewResolver extends AbstractResourceResolver {

	private static final Logger LOGGER = LoggerFactory.getLogger(RootViewResolver.class);

	@Override
	protected Resource resolveResourceInternal(HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
		LOGGER.debug("In Root View Resolver");
		final String appKey = UIContext.get().appKey();
		LOGGER.debug("Resolving view for appKey : {}", appKey);
		if (appKey != null && requestPath.endsWith(appKey) || requestPath.endsWith(appKey + "/")) {
			LOGGER.debug("Building Request ath");
			final StringBuilder builder = new StringBuilder(requestPath);
			if (!requestPath.endsWith("/")) {
				LOGGER.debug("Appending /");
				builder.append("/");
			}
			LOGGER.debug("Adding index.html");
			builder.append("index.html");
			requestPath = builder.toString();
		}
		LOGGER.debug("Request Path : {}", requestPath);
		return chain.resolveResource(request, requestPath, locations);
	}

	@Override
	protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
		return chain.resolveUrlPath(resourceUrlPath, locations);
	}

}
