package com.hcentive.billing.core.commons.service.app.gateway.security.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.service.app.gateway.support.UIContext;
import com.hcentive.billing.core.commons.service.security.filter.AbstractFilter;
import com.hcentive.billing.core.commons.web.WebUtils;

public class UIRootPathEnforcer extends AbstractFilter implements Filter {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(UIRootPathEnforcer.class);
	@Value(value = "${config.ignore.pattern:/configurations/**,/configuration/**}")
	private String[] configIgnorePattern = new String[0];
	
	
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		LOGGER.debug("Inside filter");
		if(ignoreCurrentRequest(request)){
			chain.doFilter(request, response);
			return ;
		}
		final HttpServletRequest httpRequest = ((HttpServletRequest) request); 
		final HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		final String requestPath = httpRequest.getRequestURI();
		final String appKey = UIContext.get().appKey();
		LOGGER.debug("Resolving view for appKey : {}",appKey);
		if(appKey != null && requestPath.endsWith(appKey) || requestPath.endsWith(appKey+"/")){
			LOGGER.debug("Building Request ath");
			if(!requestPath.endsWith("/")){
				LOGGER.debug("app path is not correct.");
				if(httpRequest.getQueryString() != null)
					httpServletResponse.sendRedirect(WebUtils.getBaseUrl(httpRequest)+requestPath+"/?"+httpRequest.getQueryString());
				else{
					httpServletResponse.sendRedirect(WebUtils.getBaseUrl(httpRequest)+requestPath+"/");
				}
				return;
			}
		}
		chain.doFilter(request, response);
		LOGGER.debug("End filter");
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected String[] getIgnorePathPattern() {
		return configIgnorePattern;
	}
	
// Not in Use
	@Override
	protected void doInternalFilter(ServletRequest request,
			ServletResponse response, FilterChain chain) throws IOException,
			ServletException {}

}
