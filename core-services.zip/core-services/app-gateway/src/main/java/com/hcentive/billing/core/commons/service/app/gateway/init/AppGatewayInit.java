package com.hcentive.billing.core.commons.service.app.gateway.init;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration.WebMvcAutoConfigurationAdapter;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.resource.PathResourceResolver;

import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.service.app.gateway.resource.RootViewResolver;
import com.hcentive.billing.core.commons.service.app.gateway.resource.TenantBasedCustomResourceResolver;
import com.hcentive.billing.core.commons.service.app.gateway.support.AssetUtil;
import com.hcentive.billing.core.commons.service.app.gateway.support.ConfigurationPreLoader;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;

@Configuration
@PropertySources({ @PropertySource("file:${baseDir}/config/properties/app.properties"),
	@PropertySource("file:${baseDir}/config/properties/security.properties"), @PropertySource("file:${baseDir}/config/properties/db.properties"),
	@PropertySource("file:${baseDir}/config/properties/amqp.properties"), @PropertySource("file:${baseDir}/config/properties/mongodb.properties") })
@EnableAutoConfiguration
@EntityScan("com.hcentive.billing")
@EnableJpaRepositories(basePackages = { "com.hcentive.billing" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EnableMongoRepositories(basePackages = {"com.hcentive.billing.core.commons.starter.persistence.repository"})
@ComponentScan("com.hcentive.billing")
public class AppGatewayInit extends WebMvcAutoConfigurationAdapter {
	private static final Logger LOGGER = LoggerFactory.getLogger(AppGatewayInit.class);

	@Value("${baseDir}")
	public String baseDirPath;

	@Value("${ui.assets.external.paths}")
	private String externalUIAssets;

	@Value("${ui.gateway.resource.cache.period:3600}")
	public int cachePeriod;

	public static void main(String[] args) {
		SpringApplication.run(AppGatewayInit.class, args);
	}

	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
	
	@Override
	public void addResourceHandlers(final ResourceHandlerRegistry registry) {
		final File f = new File(baseDirPath);

		final List<String> resourcesPaths = new ArrayList<>();

		String resourcePath = null;
		try {
			resourcePath = "file:" + f.getCanonicalPath() + File.separator + AssetUtil.UI_ASSETS_FOLDER_NAME + File.separator;
			resourcesPaths.add(resourcePath);
		} catch (final IOException e) {
			LOGGER.info(AssetUtil.UI_ASSETS_FOLDER_NAME + " is missing");
		}

		if (!StringUtils.isEmpty(externalUIAssets)) {

			final String[] paths = externalUIAssets.split(",");

			for (final String path : paths) {
				resourcePath = "file:" + path;
				resourcesPaths.add(resourcePath);
			}
		}

		registry.addResourceHandler("/**").addResourceLocations(resourcesPaths.toArray(new String[resourcesPaths.size()])).setCachePeriod(cachePeriod)
		.resourceChain(false).addResolver(rootViewResolver()).addResolver(tenantBasedCustomResourceResolver()).addResolver(new PathResourceResolver());
	}

	@Bean
	@DependsOn("configureTenantManager")
	public ConfigurationPreLoader configurationPreLoader() {
		return new ConfigurationPreLoader();
	}

	@Bean
	public RootViewResolver rootViewResolver() {
		return new RootViewResolver();
	}

	@Bean
	public TenantBasedCustomResourceResolver tenantBasedCustomResourceResolver() {
		return new TenantBasedCustomResourceResolver();
	}

}
