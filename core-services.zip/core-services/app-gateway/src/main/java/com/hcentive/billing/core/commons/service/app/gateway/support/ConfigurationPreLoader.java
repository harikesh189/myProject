package com.hcentive.billing.core.commons.service.app.gateway.support;

import static com.hcentive.billing.core.commons.concurrent.Executors.newSingleThreadExecutor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoOperations;

import com.hcentive.billing.core.commons.configuration.api.Configuration;
import com.hcentive.billing.core.commons.configuration.service.ConfigurationCacheManager;
import com.hcentive.billing.core.commons.domain.Operator;
import com.hcentive.billing.core.commons.persistence.factory.repository.OperatorRepository;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * Preloads all configuration into cache on a per tenant basis.
 *
 * @author Bappaditya.Mallick
 *
 */
public class ConfigurationPreLoader {

	private static final String CONFIGURATION_PRE_LOADER_THREAD_POOL = "ConfigurationPreLoaderPool";

	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationPreLoader.class);

	@Autowired
	private ConfigurationCacheManager cacheManager;

	@Value(value = "${config.collection.prefix:_configuration}")
	private String configCollectionPrefix;

	private ExecutorService executor = newSingleThreadExecutor(CONFIGURATION_PRE_LOADER_THREAD_POOL);

	@Autowired
	private MongoOperations mongo;
	@Autowired
	private OperatorRepository operatorRepository;

	@PostConstruct
	public void loadAllToCache() {
		final Set<String> collectionNames = mongo.getCollectionNames();

		LOGGER.info("Loading all configurations.");
		final List<Operator> tenants = findAllTenants();
		// loop over the tenants and load config for each.
		if (null != tenants && !tenants.isEmpty()) {
			final CountDownLatch latch = new CountDownLatch(tenants.size());
			for (final Operator op : tenants) {
				final String tenant = op.getExternalId();
				final String collectionName = resolveCollectionName(tenant, collectionNames);
				if (null != collectionName) {
					final TenantConfigPreLoader tenantConfigPreLoader = new TenantConfigPreLoader(tenant, latch, collectionName);
					this.executor.submit(tenantConfigPreLoader);
				} else {
					LOGGER.error("No configuration collection exists for tenant {}", tenant);
					latch.countDown();
				}
			}
			// Add exe
			executor.submit(new Runnable() {
				@Override
				public void run() {
					try {
						latch.await();
						LOGGER.info("Loaded all configurations.");
					} catch (final InterruptedException e) {
						LOGGER.error("Error all configurations.", e);
					} finally {
						executor.shutdown();
						executor = null;
					}
				}
			});

		}
	}

	private void cacheAgainstKeys(final List<Configuration> allConfigs, Collection dataObjects) {
		for (final Configuration config : allConfigs) {
			final Object data = config.getData();
			final String key = config.getKey();
			if (null != key && null != data) {
				this.cacheManager.addToCache(key, data);
			}
			/*
			 * Ajay: Commenting out subsection caching.
			 */
			// cacheAgainstSubsection(key,config);
			dataObjects.add(data);
		}
	}

	private List<Operator> findAllTenants() {
		return operatorRepository.findAll();
	}

	private void loadTenantConfiguration(final String tenant, final String collectionName) {
		if (null != tenant) {
			// cache the tenantName.
			this.cacheManager.addToCache(TenantUtil.TENANT_KEY, tenant);
			final List<Configuration> allConfigs = this.mongo.findAll(Configuration.class, collectionName);
			final Collection dataObjects = new ArrayList();
			if (null != allConfigs && !allConfigs.isEmpty()) {
				cacheAgainstKeys(allConfigs, dataObjects);
			}
			// put all of this in cache against tenant name.
			this.cacheManager.addToCache(tenant, dataObjects);
		}
	}

	private String resolveCollectionName(String tenant, Set<String> collectionNames) {
		if (null != collectionNames && !collectionNames.isEmpty()) {
			for (final String collectionName : collectionNames) {
				if (collectionName.equals(tenant + configCollectionPrefix)) {
					return collectionName;
				}
			}
		}
		return null;
	}

	private class TenantConfigPreLoader implements Runnable {
		private final String collectionName;
		private final CountDownLatch latch;
		private final String tenant;

		private TenantConfigPreLoader(String tenant, final CountDownLatch latch, final String collectionName) {
			this.tenant = tenant;
			this.latch = latch;
			this.collectionName = collectionName;
		}

		@Override
		public void run() {
			LOGGER.info("Loading configurations for tenant {} from collection {}", this.tenant, this.collectionName);
			final ProcessContext pc = ProcessContext.initializer().forTenant(this.tenant).initialize();
			try {
				loadTenantConfiguration(this.tenant, collectionName);
				LOGGER.info("Loaded configurations for tenant {}", this.tenant);
			} catch (final Exception e) {
				LOGGER.error("Error caching configuration for tenant " + tenant, e);
			} finally {
				pc.clear();
				latch.countDown();
			}
		}

	}
}
