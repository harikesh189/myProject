package com.hcentive.billing.core.commons.service.app.gateway.support;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import com.hcentive.billing.core.commons.web.WebUtils;

public class UiUtil {

	public static String parseClientId(final HttpServletRequest request, final Set<String> registeredClientApps, final int... indexesToLook) {
		String clientId = null;
		if (indexesToLook != null) {
			for (final int index : indexesToLook) {
				clientId = doParseClientId(request, index, registeredClientApps);
				if (clientId != null) {
					break;
				}
			}
		}
		return clientId;
	}

	private static String doParseClientId(final HttpServletRequest request, final int indexToLook, final Set<String> registeredClientApps) {
		final String clientId = WebUtils.resolve(request, indexToLook);
		if (registeredClientApps.contains(clientId)) {
			return clientId;
		}
		return null;
	}

}
