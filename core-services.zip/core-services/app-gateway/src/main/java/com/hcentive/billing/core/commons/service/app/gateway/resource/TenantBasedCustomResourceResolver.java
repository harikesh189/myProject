package com.hcentive.billing.core.commons.service.app.gateway.resource;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.servlet.resource.AbstractResourceResolver;
import org.springframework.web.servlet.resource.ResourceResolverChain;

import com.hcentive.billing.core.commons.service.app.gateway.support.AssetUtil;
import com.hcentive.billing.core.commons.web.WebUtils;

@ManagedResource(objectName = "billing:name=appGateway.tenant.resource.Management", description = "Manages Tenant based custom resources.", log = true, logFile = "jmx.log", currencyTimeLimit = 15)
public class TenantBasedCustomResourceResolver extends AbstractResourceResolver {

	private static final Logger LOGGER = LoggerFactory.getLogger(TenantBasedCustomResourceResolver.class);

	@Value("${ui.gateway.resource.custom.pattern:/**/css/**,/**/messages/**,/**/img/**,/**/images/**,**/css/development.css,**/serverDomain.js}")
	private final String[] customResourcePatternArr = new String[0];
	private final PathMatcher pathMatcher = new AntPathMatcher();

	@Value("${ui.assets.external.paths}")
	private final String[] externalUIAssets = new String[0];

	private final Map<String, Boolean> isCustomResourceRegistry = new HashMap<String, Boolean>();
	private final Map<String, Boolean> customResourceMatchFoundRegistry = new HashMap<String, Boolean>();

	@ManagedOperation(description = "Clears the tenant resources & their mappings that are cached.")
	@ManagedOperationParameters(value = { @ManagedOperationParameter(description = "The tenant whose custom resources cache needs to be cleared.", name = "tenantId") })
	public String clearTenantCustomResourceCache(final String tenantId) {
		LOGGER.info("Clearing Custom Resource Cache for tenant:{}", tenantId);
		if (tenantId != null) {
			final Set<String> keys = new HashSet<>(customResourceMatchFoundRegistry.keySet());
			for (final String key : keys) {
				if (key.startsWith(tenantId)) {
					customResourceMatchFoundRegistry.remove(key);
				}
			}
		}
		return "Cleared Custom Resource Cache for tenant: " + tenantId;
	}

	@Override
	protected Resource resolveResourceInternal(HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain) {
		LOGGER.debug("Checking for requestPath: {}", requestPath);
		final String enterprise = resolveEnterprise(request);
		requestPath = removeEnterpriseFromRequestedPath(request, requestPath);
		LOGGER.debug("Requested Path after enterprise removed: {}", requestPath);
		final boolean customResourceCandidate = isCustomResourceCandidate(requestPath);
		if (customResourceCandidate) {
			LOGGER.debug("CustomResourceCandidate for requestPath: {}", requestPath);
			requestPath = resolveNewPath(requestPath, enterprise);
			LOGGER.debug("New requestPath: {}", requestPath);
		}
		return chain.resolveResource(request, requestPath, locations);
	}

	@Override
	protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain) {
		return chain.resolveUrlPath(resourceUrlPath, locations);
	}

	private boolean customResourceExists(String newRequestPath) {

		boolean flag = false;
		for (final String basePath : externalUIAssets) {
			LOGGER.debug("Checking for file: {}", basePath + newRequestPath);
			final File file = new File(basePath + newRequestPath);
			if (file.exists()) {
				flag = true;
				break;
			}
		}
		if (!flag) {
			// else check if something found.
			LOGGER.debug("Checking for file: {}", AssetUtil.uiAssetRootPath + newRequestPath);
			final File file = new File(AssetUtil.uiAssetRootPath + newRequestPath);
			if (file.exists()) {
				flag = true;
			}
		}
		return flag;
	}

	private boolean isCustomResourceCandidate(final String requestPath) {
		Boolean matchFoundInRegistry = isCustomResourceRegistry.get(requestPath);
		if (null == matchFoundInRegistry) {
			matchFoundInRegistry = matchedFoundAgainstPattern(requestPath);
			isCustomResourceRegistry.put(requestPath, matchFoundInRegistry);
		}
		return matchFoundInRegistry;
	}

	private Boolean matchedFoundAgainstPattern(final String requestPath) {
		for (final String customResourcePattern : customResourcePatternArr) {
			LOGGER.debug("Checking for requestPath: {} against pattern: {} ", requestPath, customResourcePattern);
			if (pathMatcher.isPattern(customResourcePattern) && pathMatcher.match(customResourcePattern, requestPath)) {
				return true;
			} else {
				if (requestPath.equalsIgnoreCase(customResourcePattern)) {
					return true;
				}
			}
		}
		return false;
	}

	private String removeEnterpriseFromRequestedPath(final HttpServletRequest request, final String path) {
		final String enterpriseName = resolveEnterprise(request);
		LOGGER.debug("Enterprise Resolved: {}", enterpriseName);
		return path.replaceAll(enterpriseName + "/", "/");
	}

	private String resolveEnterprise(HttpServletRequest request) {
		final String enterprise = WebUtils.resolve(request, 1);
		return enterprise;
	}

	private String resolveNewPath(String requestPath, final String tenantId) {
		final String newRequestPath = requestPath.startsWith(tenantId) ? requestPath : tenantId + File.separator + requestPath;
		// Does the customResourcePath Exists if not default.
		LOGGER.debug("Checking for file: {}", AssetUtil.uiAssetRootPath + newRequestPath);
		final Boolean customResourceExists = customResourceMatchFoundRegistry.get(newRequestPath);
		if (customResourceExists != null && customResourceExists) {
			return newRequestPath;
		}
		// else check if something found.
		if (!customResourceExists(newRequestPath)) {
			customResourceMatchFoundRegistry.remove(newRequestPath);
			return requestPath;
		} else {
			customResourceMatchFoundRegistry.put(newRequestPath, Boolean.TRUE);
			return newRequestPath;
		}
	}
}
