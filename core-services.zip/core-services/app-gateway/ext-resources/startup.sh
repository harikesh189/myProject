#!/bin/bash
clear
echo "Launching UI Gateway Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/app-gateway -Xloggc:/var/log/wfm/app-gateway/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx1024m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar app-gateway-1.0.RELEASE.jar --server.port=8100