package com.hcentive.billing.core.commons.service.wfm.print.rest.pojo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.hcentive.billing.core.commons.docref.print.pojo.DocumentResponse;
import com.hcentive.billing.core.commons.domain.DocumentRef;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJobStatus;
import com.hcentive.billing.core.commons.service.wfm.print.repository.PrintJobRepository;

@Component
public class PDFRestClient {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PDFRestClient.class);
	

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private PrintJobRepository printJobRepository;

	public DocumentResponse downloadPDF(DocumentRef documentRef) {
		LOGGER.debug("downloading pdf for dcin no {}", documentRef.getDocRefId());
		final String downloadURL = new StringBuilder().append(documentRef.getExternalURL()).append(documentRef.getDocRefId()).append("/").toString();
		LOGGER.debug("REST url to download generated pdf {}", downloadURL);
		final PrintJob pJob = printJobRepository.findByDcinNo(documentRef.getDocRefId());
		final HttpEntity httpEntity = RestUtil.buildDownloadHeaders(pJob);
		ResponseEntity<DocumentResponse> response;
		try {
			response = restTemplate.exchange(downloadURL,HttpMethod.GET, httpEntity,
					DocumentResponse.class);
		} catch (Exception e) {
			LOGGER.error("Exception while downloading pdf for dcin no {}", documentRef.getDocRefId());
			throw new IllegalAccessError("Error while Hitting restcilent.");
		}
		LOGGER.debug("Response returned");
		return response.getBody();

	}
	;
}
