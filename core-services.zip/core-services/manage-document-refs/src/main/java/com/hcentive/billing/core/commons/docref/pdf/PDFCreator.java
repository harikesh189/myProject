package com.hcentive.billing.core.commons.docref.pdf;

import java.util.Map;

public interface PDFCreator {

	public byte[] writePDF(Map<String,String> pdfData, String templateLocation) throws Exception;
}
