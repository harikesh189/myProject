package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.factory.IsForTask;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;

public interface PrintJobBuilder<T> extends IsForTask {
	
	PrintJob buildPrintJob(T t);

}
