package com.hcentive.billing.core.commons.service.wfm.print.schedular;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.security.SystemUserOperation;

@Component
public class PrintJobSchedular {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrintJobSchedular.class);

	@Autowired
	private PrintJobSchedularService printJobSchedularService;

	@Scheduled(cron = "${print.job.incomplete.interval}")
	@SystemUserOperation
	public void retryIncompleteJobs() {
		LOGGER.debug("Retrying the jobs in the Incomplete state");
		printJobSchedularService.scheduleIncompletePrintJobs();
	}
	
	@Scheduled(cron = "${print.job.failed.interval}")
	@SystemUserOperation
	public void retryFailedJobs() {
		LOGGER.debug("Retrying the jobs in the failed state");
		printJobSchedularService.scheduleFailedJobs();
	}

}