package com.hcentive.billing.core.commons.docref.integration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.cache.Cache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.docref.file.DefaultFileNameResolver;
import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.ftp.DefaultFTPConfig;
import com.hcentive.billing.core.commons.ftp.FTPClient;
import com.hcentive.billing.core.commons.ftp.FTPClientProvider;
import com.hcentive.billing.core.commons.ftp.FTPConfig;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.ConfigurationConstant;
import com.hcentive.billing.core.commons.service.ebill.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.util.EncryptionUtil;

public class FtpURLHandler extends URLHandler<TenantAwareDocRefPayLoad> {

	private static Logger logger = LoggerFactory.getLogger(FtpURLHandler.class);

	@Value("${docref.temp.directory}")
	private String tempDocRefDirectory;

	@Autowired
	private DefaultFileNameResolver fileNameResolver;

	@Autowired
	private Cache<String, List<Configuration>> tenantConnectionCache;

	/*
	 * Method download from url and enrich the headers with directory and
	 * filename
	 */
	public Message<TenantAwareDocRefPayLoad> handleURL(
			Message<TenantAwareDocRefPayLoad> payLoad) {

		if (payLoad.getPayload().getTenantId() != null) {
			logger.debug("Handling FTP URL for tenant {}", payLoad.getPayload()
					.getTenantId());
			List<Configuration> configurations = tenantConnectionCache
					.get(payLoad.getPayload().getTenantId().toUpperCase());

			if (null == configurations || configurations.isEmpty()) {
				logger.warn("No FTP configuration available for {}", payLoad
						.getPayload().getTenantId().toUpperCase());
				throw new IllegalStateException(
						"No FTP configruation available.");
			}
			final FTPConfig ftpConfig = buildFTPConfig(configurations);
			FTPClient ftpClient = null;
			final String tempFileName = getTempFileName();
			boolean status = true;

			try {
				ftpClient = FTPClientProvider.addNGetTenantAwareFtpClient(
						payLoad.getPayload().getTenantId().toUpperCase(),
						ftpConfig);
				logger.debug("FTP client created sucesfully");
				logger.debug("Attempting file download from FTP");
				final String fileName = fileNameResolver
						.getTenantSpecificFileName(payLoad.getPayload()
								.getTenantId().toUpperCase(), payLoad
								.getPayload().getDocRef().getDocRefId());
				ftpClient.downloadFile(fileName, tempDocRefDirectory,
						tempFileName);
				logger.debug("File downloaded from FTP for tenant : {}",
						payLoad.getPayload().getTenantId());
			} catch (Exception e) {
				status = false;
				logger.error("Error downloading file from URL:"
						+ payLoad.getPayload().getDocRef().getExternalURL()
						+ " for docrefid:"
						+ payLoad.getPayload().getDocRef().getDocRefId());
				logger.error("Error in file downloading ::", e);
			}

			Map<String, Object> modifiedHeaders = new HashMap<String, Object>();
			modifiedHeaders.put("tempDir", tempDocRefDirectory);
			modifiedHeaders.put("tempFile", tempFileName);
			modifiedHeaders.put("status", status);
			logger.debug("tempDir,tempFile and status is added to the message header");
			return enrichPayload(payLoad, modifiedHeaders);
		} else {
			logger.warn("No tenant found in payload");
			return null;
		}
	}

	private FTPConfig buildFTPConfig(List<Configuration> configurations) {

		logger.debug("Building ftp config");
		String host = ConfigurationUtil.getConfigValue(configurations,
				ConfigurationConstant.DMS_FTP_URL);
		String port = ConfigurationUtil.getConfigValue(configurations,
				ConfigurationConstant.DMS_FTP_PORT);
		String userName = ConfigurationUtil.getConfigValue(configurations,
				ConfigurationConstant.DMS_FTP_USER);
		String password = EncryptionUtil.twoWayDecryptString(ConfigurationUtil
				.getConfigValue(configurations,
						ConfigurationConstant.DMS_FTP_PASSWORD));
		FTPConfig ftpConfig = new DefaultFTPConfig.FTPConfigBuilder()
				.setHost(host).setPassword(password).setPort(port)
				.setUserName(userName).build();
		return ftpConfig;
	}
}
