package com.hcentive.billing.core.commons.docref.integration;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.util.StreamUtility;

public class HttpURLHanlder extends URLHandler<TenantAwareDocRefPayLoad> {

	private static Logger logger = LoggerFactory
			.getLogger(HttpURLHanlder.class);

	@Value("${docref.temp.directory}")
	private String tempDocRefDirectory;

	/*
	 * Method download from url and enrich the headers with directory and
	 * filename
	 */
	public Message<TenantAwareDocRefPayLoad> handleURL(
			Message<TenantAwareDocRefPayLoad> payLoad) {
		final String tempFileName = getTempFileName();
		boolean status = true;
		try {
			StreamUtility.downloadFromURL(payLoad.getPayload().getDocRef()
					.getExternalURL(), tempDocRefDirectory, tempFileName);
		} catch (Throwable e) {
			status = false;
			logger.error("Error downloading file from URL:"
					+ payLoad.getPayload().getDocRef().getExternalURL()
					+ " for docrefid:"
					+ payLoad.getPayload().getDocRef().getDocRefId());
			logger.error("Error in file downloading ::", e);
		}

		Map<String, Object> modifiedHeaders = new HashMap<String, Object>();
		modifiedHeaders.put("tempDir", tempDocRefDirectory);
		modifiedHeaders.put("tempFile", tempFileName);
		modifiedHeaders.put("status", status);
		logger.debug("tempDir,tempFile and status is added to the message header");
		return enrichPayload(payLoad, modifiedHeaders);

	}

}
