package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Invoice;

@Component
public class InvoiceXMLGenerator
		extends
		ItemRecordAwareItemXMLGenerator<Invoice, com.hcentive.billing.core.commons.xsdtopojo.Invoice> {

	@Override
	protected Class<com.hcentive.billing.core.commons.xsdtopojo.Invoice> getPojoClass() {
		return com.hcentive.billing.core.commons.xsdtopojo.Invoice.class;
	}

	@Override
	public boolean canHandle(Object arg0) {
		return Invoice.class.isAssignableFrom(arg0.getClass());
	}

	@Override
	protected String getPojoUniqueId(
			com.hcentive.billing.core.commons.xsdtopojo.Invoice pojo) {
		return pojo.getInvoiceId();
	}

}
