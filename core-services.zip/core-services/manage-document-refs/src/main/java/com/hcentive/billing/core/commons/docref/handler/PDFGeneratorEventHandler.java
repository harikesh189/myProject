package com.hcentive.billing.core.commons.docref.handler;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.docref.listner.PDFGeneratorEventListenerFactory;
import com.hcentive.billing.core.commons.event.EventUtils;

@Component
public class PDFGeneratorEventHandler {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PDFGeneratorEventHandler.class);
	

	@Value("${eventsToListen}")
	private String eventsToListen;
	
	@Autowired
	private PDFGeneratorEventListenerFactory listenerFactory;

	@SuppressWarnings("deprecation")
	@PostConstruct
	public void registerForEvents() {

		if(getEventsToListen()==null){
			LOGGER.debug("No event to register");
			return ;
		}
			for (String eventName:getEventsToListen()) {
			
				LOGGER.debug(
						"\n\n!!!Registering Notification Event listener for {}\n",
						eventName);
				EventUtils.register(eventName,
						listenerFactory.createNew(eventName));
			}
	}
	
	public String[] getEventsToListen(){
		if(null!=this.eventsToListen && !this.eventsToListen.isEmpty()){
			return this.eventsToListen.split(",");
		}
		return null;	
	}
}
