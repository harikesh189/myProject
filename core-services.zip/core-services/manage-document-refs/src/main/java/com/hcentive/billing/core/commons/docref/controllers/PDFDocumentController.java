/**
 * 
 *//*
package com.hcentive.billing.core.commons.docref.controllers;

import java.math.BigDecimal;
import java.util.HashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hcentive.billing.core.commons.domain.ContactSet;
import com.hcentive.billing.core.commons.domain.Customer;
import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.domain.Operator;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.enumtype.Gender;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.Currency;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.contract.EligibilityContract;

*//**
 * The Class PDFDocumentController.
 * 
 * @author neeraj.aggarwal
 *//*
@RestController
@RequestMapping("pdf")
public class PDFDocumentController {
	*//** The Constant logger. *//*
	final private static Logger logger = LoggerFactory
			.getLogger(PDFDocumentController.class);

	
	 * Generate pdf for invoices.
	 

	@RequestMapping(value = "/admin/generatePdf", produces="application/json", method = RequestMethod.GET)
	public void generatePdf() {

		// create dummy invoice.
		Invoice invoice = new Invoice("1ec3fbe069034a70bef900743af92dfb");
		Customer cust = new Customer("25f2f672288640cca14306f2e8f08881");
		Profile p = Profile.createAndGetPersonalProfile("Mr", "", "George",
				"Roger", Gender.FEMALE, null, null, null);
		ContactSet emails = new ContactSet(new HashSet());
		p.setEmails(emails);
		cust.setProfile(p);
		invoice.setGeneratedFor(cust);
		invoice.setGeneratedOn(new DateTime());
		// invoice.setExternalId("INV" + (int) ((Math.random() * 10000) %
		// 59999));
		invoice.setDueDate(new DateTime());
		invoice.setPayableAmount(new Amount(new BigDecimal(10.00),
				Currency.DEFAULT_CURRENCY));

		Operator operator = new Operator();
		operator.setIdentity("RMHP");
		// operator.setExternalId("operatorExternalId");
		cust.setOperator(operator);
		invoice.setOperator(operator);

		EligibilityContract contract = new EligibilityContract<>(
				"6568db6efa284ad290310789bea7f20c");

		Reference ref = Reference.newInternalReference(contract);
		invoice.addReference(ref);
		invoice.setExternalId("ext_id");
		EventUtils.publish(new Event<Object>(EventType.GENERATE_INVOICE_PDF, invoice));
	}
}
*/