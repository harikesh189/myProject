package com.hcentive.billing.core.commons.docref.integration;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.Headers;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;

public abstract class URLHandler<T> {

	private static Logger logger = LoggerFactory.getLogger(URLHandler.class);

	protected Message<T> enrichPayload(final Message<T> payLoad,
			@Headers Map<String, Object> headers) {
		Map<String, Object> modifiedHeaders = new HashMap<String, Object>();
		modifiedHeaders.putAll(payLoad.getHeaders());
		modifiedHeaders.putAll(headers);
		logger.debug("Adding the existing header and new header to Message<DocRef>");
		Message<T> newMsg = new GenericMessage<T>(payLoad.getPayload(),
				modifiedHeaders);
		return newMsg;
	}

	protected synchronized String getTempFileName() {
		return String.valueOf(System.currentTimeMillis()) + ".temp";
	}
}
