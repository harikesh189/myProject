package com.hcentive.billing.core.commons.service.wfm.print.rest.pojo;

import java.net.MalformedURLException;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.util.CommonUtility;

@Component
public class PrintRestClient implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrintRestClient.class);

	@Autowired
	private RestTemplate restTemplate;

	
	private HttpHeaders httpHeaders;

	public DocumentGenerationResponse postToPrint(
			DocumentGenerationRequest request) throws MalformedURLException {

		LOGGER.debug("Posting to print");
		final HttpEntity<DocumentGenerationRequest> httpEntityrequest = new HttpEntity<DocumentGenerationRequest>(
				request, httpHeaders);
		final String printUrl = ConfigurationUtil.get(PrintConstants.PRINT_JOB_CLIENT_URL);
		if (!CommonUtility.isValidURL(printUrl)) {
			LOGGER.error("URL {} configured for tenant {} is invalid.",
					printUrl, TenantUtil.getTenantId());
			throw new MalformedURLException("URL " + printUrl
					+ "configured for tenant " + TenantUtil.getTenantId()
					+ " is invalid");
		}
		final ResponseEntity<DocumentGenerationResponse> response = restTemplate
				.postForEntity(printUrl, httpEntityrequest,
						DocumentGenerationResponse.class);
		LOGGER.debug("Response returned");
		return response.getBody();

	}

	@Override
	public void afterPropertiesSet() throws Exception {
		LOGGER.debug("Populating headers");
		httpHeaders = new HttpHeaders();
		httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		httpHeaders.setContentType(MediaType.APPLICATION_XML);
	}

}
