package com.hcentive.billing.core.commons.docref.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;

public class DmsUploadRouter {

	private static final Logger logger = LoggerFactory
			.getLogger(DmsUploadRouter.class);

	/*
	 * Method which calls the handler on the basis of download (sucess or fail)
	 */
	public String routeToChannel(Message<TenantAwareDocRefPayLoad> payLoad) {
		if (null != payLoad.getHeaders().get("dmsKey")) {
			logger.debug("Routing to successfulDMSUploadChannel for docrefId::"
					+ payLoad.getPayload().getDocRef().getDocRefId());
			return "successfulDMSUploadChannel";
		}
		logger.debug("Routing to faildDMSUplaodChannel for docrefId::"
				+ payLoad.getPayload().getDocRef().getDocRefId());
		return "faildDMSUplaodChannel";
	}

}
