package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintStatusResolver;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

/**
 * @author ajay.saxena
 * 
 *         Class which checks if Invoice is printable or not for a particular
 *         tenant.
 *
 */
@Component
public class InvoicePrintStatusResolver implements PrintStatusResolver<Invoice> {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvoicePrintStatusResolver.class);

	@Override
	public boolean canHandle(Object type) {
		return Invoice.class.isAssignableFrom(type.getClass());
	}

	@Override
	public boolean isItemPrintable(Invoice invoice) {
		
		LOGGER.debug("Check if invoice is printable for tenant. ");
		final Boolean printStatus = ConfigurationUtil.get(PrintConstants.PRINT_FLAG_STATUS_INVOICE);
		LOGGER.debug("Print flag status configfured for tenant {} is {}", TenantUtil.getTenantId(), printStatus);
		if (!printStatus) {
			return printStatus;
		}

		LOGGER.debug("Check if zero $ run out invoice");
		if (isZeroDollarRunoutInvoice(invoice)) {
			final Boolean zeroRunoutInvoiceStatus = ConfigurationUtil
					.get(PrintConstants.PRINT_FLAG_STATUS_ZERO_RUN_OUT_INVOICE);
			LOGGER.debug("Print flag status configfured for zero $ runout invoice {} for tenant {} is {}",
					invoice.externalId(), TenantUtil.getTenantId(), zeroRunoutInvoiceStatus);
			return zeroRunoutInvoiceStatus;
		}
		LOGGER.debug("Returning printStatus {} ", printStatus);

		return printStatus;
	}

	private boolean isZeroDollarRunoutInvoice(Invoice invoice) {
		LOGGER.debug("Invoice details::: runout {} ::: amount {}", invoice.isRunout(), invoice.getPayableAmount());
		return invoice.isRunout() && invoice.getPayableAmount().isZero();
	}

}
