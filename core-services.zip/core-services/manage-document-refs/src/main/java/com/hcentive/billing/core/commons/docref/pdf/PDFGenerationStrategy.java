package com.hcentive.billing.core.commons.docref.pdf;

import java.util.Map;

public interface PDFGenerationStrategy {

	public byte[] execute(Map<String, String> pdfData, byte[] outputPDF) throws Exception;
}
