package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;

public interface PrintJobManager {
	
	void processPrintJob(PrintJob pJob);

}
