package com.hcentive.billing.core.commons.docref.integration;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;

import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.security.SystemUserOperation;
import com.hcentive.billing.core.commons.service.ebill.dms.service.DmsServiceManager;
import com.hcentive.billing.core.commons.service.ebill.dms.service.utility.DMSUtil;
import com.hcentive.billing.core.commons.service.ebill.dms.service.utility.KeyGenerator;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class SuccessfulDownloadChannel {

	public static final Logger logger = LoggerFactory
			.getLogger(SuccessfulDMSUploadChannel.class);

	@Autowired
	private DmsServiceManager dmsServiceManager;

	@Autowired
	private KeyGenerator keyGenerator;

	/*
	 * Method to upload the stream to DMS if download is successfully
	 */
	@SystemUserOperation
	public Message<TenantAwareDocRefPayLoad> uploadToDMS(
			Message<TenantAwareDocRefPayLoad> payLoad) {
		ProcessContext.clear();
		ProcessContext.initializer()
				.forTenant(payLoad.getPayload().getTenantId()).initialize();
		File file = new File((String) payLoad.getHeaders().get("tempDir"),
				(String) payLoad.getHeaders().get("tempFile"));
		final String dmsKey = keyGenerator.getKey();
		try {
			InputStream is = new FileInputStream(file);
			logger.debug("uploading the input Stream to dms");
			Map<String, String> headers = new HashMap<>();
			headers.put("tenant", TenantUtil.getTenantId());
			dmsServiceManager.upload(is, dmsKey, DMSUtil.getContentClass(is),
					headers);
		} catch (Throwable e) {
			logger.error("Error uploading file through dms service for docref id ::"
					+ payLoad.getPayload().getDocRef().getDocRefId());
		} finally {
			logger.debug("delete temp file for docref id ::"
					+ payLoad.getPayload().getDocRef().getDocRefId());
			file.delete();
			ProcessContext.clear();
		}

		Map<String, Object> headers = new HashMap<String, Object>();
		headers.put("dmsKey", dmsKey);
		logger.debug("Enriching headers with key :: " + dmsKey);
		return enrichPayload(payLoad, headers);

	}

	private Message<TenantAwareDocRefPayLoad> enrichPayload(
			final Message<TenantAwareDocRefPayLoad> docref,
			Map<String, Object> headers) {
		Map<String, Object> modifiedHeaders = new HashMap<String, Object>();
		modifiedHeaders.putAll(docref.getHeaders());
		modifiedHeaders.putAll(headers);
		Message<TenantAwareDocRefPayLoad> newMsg = new GenericMessage<TenantAwareDocRefPayLoad>(
				docref.getPayload(), modifiedHeaders);
		return newMsg;
	}

}
