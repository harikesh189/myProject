package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.service.wfm.print.api.PaperlessPreferenceChecker;

/**
 * Class which decicde if invoice is paperless or not .
 * 
 * @author ajay.saxena
 *
 */
@Component
public class InvoicePaperlessPreferenceChecker implements
		PaperlessPreferenceChecker<Invoice> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(InvoicePaperlessPreferenceChecker.class);

	@Autowired
	private FilterSupportRepository filterSupportRepository;

	@Override
	public boolean canHandle(Object type) {
		return Invoice.class.isAssignableFrom(type.getClass());
	}

	@Override
	public boolean resolvePaperlessPreference(Invoice invoice) {
		final BusinessEntity generatedFor = invoice.getGeneratedFor();

		if (null == generatedFor) {
			throw new IllegalAccessError(
					"Business entity is null for invoice id "
							+ invoice.getExternalId());
		}
		LOGGER.debug("Fetching the business entity for identity {}",
				generatedFor.getIdentity());
		final BusinessEntity businessEntity = filterSupportRepository
				.findDomainByIdentity(generatedFor.getIdentity(),
						generatedFor.getClass());
		if (null == businessEntity) {
			throw new IllegalAccessError(
					"Could not find Business entity for identity "
							+ generatedFor.getIdentity());
		}
		
		return isPaperLess(businessEntity);

	}

	private boolean isPaperLess(BusinessEntity t) {
		boolean isPaperLess = true;
		final String billingPref = t.getBillingPreferences();

		LOGGER.debug("value of billing preferene {}", billingPref);

		if (null == billingPref)
			return true;

		switch (billingPref) {
		case BusinessEntity.PAPER_ONLY:
			isPaperLess = false;
			break;
		case BusinessEntity.PAPER_LESS_ONLY:
			isPaperLess = true;
			break;
		case BusinessEntity.PAPER_AND_PAPER_LESS:
			isPaperLess = false;
			break;
		default:
			break;
		}
		LOGGER.debug(
				"returning the paperless prefernce {}  for business entity with id {}",
				isPaperLess, t.getExternalId());
		return isPaperLess;

	}

}
