package com.hcentive.billing.core.commons.service.wfm.print.schedular;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Operator;
import com.hcentive.billing.core.commons.persistence.factory.repository.OperatorRepository;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobManager;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJobStatus;
import com.hcentive.billing.core.commons.service.wfm.print.repository.PrintJobRepository;
import com.hcentive.billing.core.commons.service.wfm.print.util.PrintUtil;

@Component
public class DefaultPrintJobSchedularService implements
		PrintJobSchedularService {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DefaultPrintJobSchedularService.class);

	@Value(value = "${print.job.page.size:20}")
	private Integer jobsPageSize;

	@Autowired
	private PrintJobRepository printJobRepository;

	@Autowired
	private PrintJobManager printJobManager;

	@Autowired
	private OperatorRepository operatorRepository;

	@Override
	public void scheduleIncompletePrintJobs() {
		schedulePrintJobsOfStatus(PrintJobStatus.INCOMPLETE);

	}

	@Override
	public void scheduleFailedJobs() {
		schedulePrintJobsOfStatus(PrintJobStatus.FAILED);
	}

	private void schedulePrintJobsOfStatus(PrintJobStatus jobStatus) {
		final List<Operator> operatorsConfigurd = findAllOperators();
		LOGGER.debug("Total operators configured in system {}",
				operatorsConfigurd.size());
		for (Operator operator : operatorsConfigurd) {
			LOGGER.debug("Processing jobs of tenant {}", operator.externalId());
			PrintUtil.initateProcessContext(operator);
			doSchedulingOfJobs(operator, jobStatus);
			LOGGER.debug("All Initiated Jobs processed for tenant {}",
					operator.externalId());
			PrintUtil.clearProcessContext();

		}
	}

	private List<Operator> findAllOperators() throws IllegalAccessError {
		final List<Operator> operatorsConfigurd = operatorRepository.findAll();
		if (null == operatorsConfigurd || operatorsConfigurd.isEmpty())
			throw new IllegalAccessError(
					"NO operator is configured in the system. Can't proceed.");
		return operatorsConfigurd;
	}

	private void doSchedulingOfJobs(Operator operator, PrintJobStatus status) {
		int pageNo = 0;
		Page<PrintJob> jobs = printJobRepository
				.findByJobStatusAndPrintItemTenantId(status, operator
						.getExternalId(), new PageRequest(pageNo, jobsPageSize));
		while (jobs.hasContent()) {
			processPageContent(jobs);
			jobs = printJobRepository.findByJobStatusAndPrintItemTenantId(status, operator
					.getExternalId(), new PageRequest(
					++pageNo, jobsPageSize));
		}
		LOGGER.debug("Process Last Page");
	}

	private void processPageContent(Page<PrintJob> jobs) {
		LOGGER.debug("Iterating over the jobs");
		final Iterator<PrintJob> iteratorPrintJobs = jobs.getContent()
				.iterator();
		while (iteratorPrintJobs.hasNext()) {
			PrintJob printJob = iteratorPrintJobs.next();
			try {
				if (printJob.getJobStatus() == PrintJobStatus.FAILED) {
					LOGGER.debug(
							"Processing failed jobs.Sending the job with the id {} to print job manager",
							printJob.getExternalId());
					printJobManager.processPrintJob(printJob);
				} else if (printJob.getJobStatus() == PrintJobStatus.INCOMPLETE) {
					LOGGER.debug("Processing incomplete Jobs with id {} ", printJob.getExternalId());
					PrintUtil.processIncompleteJob(printJob);
				}
			} catch (Throwable e) {
				LOGGER.error(
						"Exception Occured while processing Job with id "
								+ printJob.getExternalId() + " and status "
								+ printJob.getJobStatus(), e);
			}
		}

	}

}
