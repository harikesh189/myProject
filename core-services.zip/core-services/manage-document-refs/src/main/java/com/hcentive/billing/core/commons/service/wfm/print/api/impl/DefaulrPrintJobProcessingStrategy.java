package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobProcessingStrategy;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintSerivceCallType;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintService;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

@Component("defaultProcessingStrategy")
public class DefaulrPrintJobProcessingStrategy implements
		PrintJobProcessingStrategy {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DefaulrPrintJobProcessingStrategy.class);

	@Autowired
	private RestPrintService restPrintService;

	@Override
	public PrintService resolvePrintService(PrintJob job) {
		final String printCallType = ConfigurationUtil.get(PrintConstants.PRINT_JOB_CLIENT_TYPE);
		if (PrintSerivceCallType.parse(printCallType).equals(
				PrintSerivceCallType.REST)) {
			LOGGER.debug("Redirecting to rest url strategy");
			return restPrintService;
		} else {
			LOGGER.debug("No strategy configured for print job");
			throw new IllegalArgumentException("No strategy configured to do printing for tenant "+TenantUtil.getTenantId());
		}
	}

}
