package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintResponseProcessor;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJobStatus;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;
import com.hcentive.billing.core.commons.service.wfm.print.repository.PrintJobRepository;

/**
 * Class to process Failure Print Response.
 * 
 * @author ajay.saxena
 *
 */
public class FailurePrintResponseProcessor implements PrintResponseProcessor {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(FailurePrintResponseProcessor.class);
	
	@Value(value = "${default.max.processing.attempts:3}")
	private Integer defaultMaxProcessingAttempts;

	@Autowired
	private PrintJobRepository printJobRepo;

	@Override
	public void processPrintResponse(PrintResponse printResponse) {

		/**
		 * if Response is Failure. update processing attempts count by 1 and if
		 * processing count reaches , max processing attempts configured for
		 * tenant, set Jobs status aborted
		 */
		final PrintJob printJob = printJobRepo.findByExternalId(printResponse.getJobId());
		int maxRetry = fetchMaxProcessingAttempts();
		if (printJob.getPrintJobSubmittedAttempts() >= (maxRetry - 1)) {
			LOGGER.debug("max processing attempts have reached. Marking job {} as aborted.",printJob.getExternalId());
			printJob.setPrintJobSubmittedAttempts(maxRetry);
			printJob.setJobStatus(PrintJobStatus.ABORTED);
		} else {
			int processingAttempts = printJob.getPrintJobSubmittedAttempts();
			printJob.setJobStatus(PrintJobStatus.FAILED);
			printJob.setPrintJobSubmittedAttempts(++processingAttempts);
		}
		printJobRepo.save(printJob);
		LOGGER.debug("Updating the print job obj with processingAttempts");

	}

	private int fetchMaxProcessingAttempts() {
		String maxRetry = ConfigurationUtil.get(PrintConstants.MAX_RETRY_COUNT);
		LOGGER.debug("maxRetryCount configured is {}",maxRetry);
		if (maxRetry == null || maxRetry.isEmpty()) {
			LOGGER.debug("seting maxRetry count to default {}", defaultMaxProcessingAttempts);
			return defaultMaxProcessingAttempts;
		}
		return Integer.parseInt(maxRetry);
	}
}
