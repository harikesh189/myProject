package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobManager;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobProcessingStrategy;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintResponseProcessor;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintResponseProcessorFactory;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintService;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.RestUtil;

@Component
public class DefaultPrintJobManager implements PrintJobManager {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DefaultPrintJobManager.class);

	@Autowired
	@Qualifier("defaultProcessingStrategy")
	private PrintJobProcessingStrategy printJobProcessingStrategy;

	@Autowired
	private PrintResponseProcessorFactory printResponseProcessorFactory;

	@Override
	public void processPrintJob(PrintJob pJob) {
		LOGGER.debug("Processing print jog with ext id {}",
				pJob.getExternalId());

		/**
		 * Resolve which service is configured for tenant. Default is REST Call
		 * Print service.
		 */
		final PrintService printService = printJobProcessingStrategy
				.resolvePrintService(pJob);
		PrintResponse printResponse;
		try {
			printResponse = printService.print(pJob);
		} catch (Throwable e) {
			LOGGER.error("Error from print service.",e);
			printResponse = RestUtil.buildFailResponse(pJob.getExternalId());
		}
		/**
		 * if print response is not null . Find response strategy and process
		 * response.
		 */
		if (null != printResponse) {
			final PrintResponseProcessor printResponseProcessor = printResponseProcessorFactory
					.getProcessor(printResponse);
			LOGGER.debug("print response processor is {}",
					printResponseProcessor);
			printResponseProcessor.processPrintResponse(printResponse);
		}

	}

}
