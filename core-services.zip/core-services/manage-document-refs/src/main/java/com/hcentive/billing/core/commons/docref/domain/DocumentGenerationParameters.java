package com.hcentive.billing.core.commons.docref.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.TenantAware;

@Entity
@Table(name = "document_generation_parameters")
public class DocumentGenerationParameters extends BaseEntity implements Serializable,TenantAware {

	private static final long serialVersionUID = 8064264444469516790L;
	
	@Column(name = "language_code")
	private String languageCode;
	
	@Column(name = "market")
	private String market;
	
	@Column(name = "pdf_template")
	private String pdfTemplate;
	
	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;
	
	@Column(name = "pdf_type")
	private String pdfType;
	
	public String getPdfType() {
		return pdfType;
	}

	public void setPdfType(String pdfType) {
		this.pdfType = pdfType;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getPdfTemplate() {
		return pdfTemplate;
	}

	public void setPdfTemplate(String pdfTemplate) {
		this.pdfTemplate = pdfTemplate;
	}

	public String getTransformer() {
		return transformer;
	}

	public void setTransformer(String transformer) {
		this.transformer = transformer;
	}

	private String transformer;

	@Override
	public String getTenantId() {
		return tenantId;
	}
	
}
