package com.hcentive.billing.core.commons.docref.integration;

import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.domain.DocumentRef;

public interface DocRefGateway {
	public void processDocRefs(Message<DocumentRef> docrefMsg);
}
