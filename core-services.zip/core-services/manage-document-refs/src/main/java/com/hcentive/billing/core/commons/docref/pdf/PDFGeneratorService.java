package com.hcentive.billing.core.commons.docref.pdf;

public interface PDFGeneratorService {

	void generatePDF(String eventName, Object pdfGenerationPayload);

}
