package com.hcentive.billing.core.commons.docref.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;

public class InvalidURLHandler {

	private static final Logger logger = LoggerFactory
			.getLogger(InvalidURLHandler.class);

	public void handleInvalidUrl(Message<TenantAwareDocRefPayLoad> payLoad) {
		logger.debug("invalid Url found while parsing the xml");

	}

}
