package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.factory.IsForTask;

public interface PaperlessPreferenceChecker<T> extends IsForTask {
	
	public boolean resolvePaperlessPreference(T t);

}
