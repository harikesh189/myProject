package com.hcentive.billing.core.commons.docref.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;

/*
 * 
 * Router determines on basis of status whether to redirect to the success download channel or 
 * to failed download channel
 * 
 * */

public class FileDownloadRouter {
	private final static Logger logger = LoggerFactory
			.getLogger(FileDownloadRouter.class);

	public String routeBasedOnStatus(Message<TenantAwareDocRefPayLoad> payLoad) {
		if (payLoad.getHeaders().get("status").equals(Boolean.TRUE)) {
			logger.debug("Status is true ,delegating to the successfulDownloadChannel:::FileDownloadRouter");
			return "successfulDownloadChannel";
		} else {
			logger.debug("Status is false ,delegating to the failedDownloadChannel:::FileDownloadRouter");
			return "failedDownloadChannel";
		}
	}

}
