package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;

public interface PrintService {
	
	PrintResponse print(PrintJob pJob);

}
