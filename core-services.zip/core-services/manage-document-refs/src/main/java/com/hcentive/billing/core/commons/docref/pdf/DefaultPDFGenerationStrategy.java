package com.hcentive.billing.core.commons.docref.pdf;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

@Component
public class DefaultPDFGenerationStrategy implements PDFGenerationStrategy{

	private static final Logger logger  = LoggerFactory.getLogger(DefaultPDFGenerationStrategy.class);
	
	public byte[] execute(Map<String, String> orderedParamsMap,
			byte[] outputPDF) throws Exception {

		byte[] outputPDF2;
		
		outputPDF2=populateAndMergePDFs(outputPDF,orderedParamsMap,1,7);
				
		return outputPDF2;
	}
	
	public byte[] populateAndMergePDFs(byte[] refPDF,
			Map<String, String> pdfFieldsMap, int location, int fontSize) throws Exception {
		PdfReader reader = new PdfReader(refPDF);
		PdfStamper stamper;
		ByteArrayOutputStream referencebaos = new ByteArrayOutputStream();
		stamper = new PdfStamper(reader, referencebaos);
		AcroFields stamperForm = stamper.getAcroFields();
		
		Set<?> set = pdfFieldsMap.keySet();
		Iterator<?> itor = set.iterator();
		while (itor.hasNext()) {
			String key1 = (String) itor.next();
			String value = (String) pdfFieldsMap.get(key1);
			//stamperForm.setFieldProperty(key1, "textfont", font, null);
			if (stamperForm.getFieldType(key1) != AcroFields.FIELD_TYPE_CHECKBOX) {
				//stamperForm.setFieldProperty(key1, "textsize", new Float(fontSize), null);
			}
			if (value != null) {
				//if (stamperForm.getFieldType(key1) == AcroFields.FIELD_TYPE_CHECKBOX) {
					stamperForm.setField(key1, value);
				//} else {
					//stamperForm.setField(key1, value.toUpperCase());
					//stamperForm.setField(key1, value);
				//}
			}
		}
		stamper.setFormFlattening(true);
		stamper.close();
		return referencebaos.toByteArray();
		
	}
	
	public static void writeToFile(byte[] dataXML, String fileName) throws IOException {
		FileOutputStream fos = new FileOutputStream(new File(fileName));
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		bos.write(dataXML);
		bos.close();
	}
}
