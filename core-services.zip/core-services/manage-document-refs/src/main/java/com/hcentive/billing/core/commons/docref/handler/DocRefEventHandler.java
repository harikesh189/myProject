package com.hcentive.billing.core.commons.docref.handler;

import static com.hcentive.billing.core.commons.concurrent.Executors.newFixedThreadPool;

import java.util.concurrent.ExecutorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;

@Component
public class DocRefEventHandler {

	private static final String DOC_REF_THREAD_POOL = "DocRefThreadPool";

	private static final Logger logger = LoggerFactory.getLogger(DocRefEventHandler.class);

	@Autowired
	@Qualifier("docRefChannel")
	private MessageChannel docRefChannel;

	private final ExecutorService executors = newFixedThreadPool(DOC_REF_THREAD_POOL, 2);

	/**
	 * Method to handle "Handle_doc_ref" event, it downloads file from externalURL, then through dms service upload that to cloud and eventually update docref
	 * table with the key for future reference.
	 *
	 * @param docref
	 */
	@EventSubscription(eventName = EventType.NEW_DOC_REF_FOUND)
	public void handleDocRef(final TenantAwareDocRefPayLoad invoiceDocumentRefPayLoad) {
		executors.submit(new Runnable() {

			@Override
			public void run() {
				logger.debug("Starting the executor service with DocRef Id:::" + invoiceDocumentRefPayLoad.getDocRef().getId());
				final Message<TenantAwareDocRefPayLoad> message = MessageBuilder.withPayload(invoiceDocumentRefPayLoad).build();
				logger.debug("Sending the message to DocRef Channel");
				docRefChannel.send(message);

			}
		});

	}

}
