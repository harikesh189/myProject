package com.hcentive.billing.core.commons.service.wfm.print.event.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.domain.DocumentRef;
import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobBuilder;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobManager;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintStatusResolver;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJobStatus;
import com.hcentive.billing.core.commons.service.wfm.print.repository.PrintJobRepository;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

/**
 * Class which listens to event fired for Printing a document.
 * 
 * @author ajay.saxena
 * 
 */
@Component
public class PrintJobHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(PrintJobHandler.class);

	@Autowired
	private PrintJobManager pJobManager;

	@Autowired
	private PrintJobRepository printJobRepository;

	@Value(value = "${default.max.pdf.uploaad.attempts:3}")
	private Integer defaultMaxPdfUploadAttempts;

	@EventSubscription(eventName = { EventType.PRINT_JOB_CREATED })
	public void handlePrintJob(PrintJob pJob) {
		LOGGER.debug(" Starting PrintJob with id {} ", pJob.getId());
		pJobManager.processPrintJob(pJob);
		LOGGER.debug("PrintJob with id {} completed ", pJob.getId());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@EventSubscription(eventName = { EventType.PRINT_INVOICE })
	public void initPrintJob(Invoice invoice) {
		LOGGER.debug("Check whether print flag is enabled or not");
		final PrintStatusResolver printStatusResolver = (PrintStatusResolver) Factories.INSTANCE
				.factory(PrintStatusResolver.class).get(invoice);
		final Boolean printStatus = printStatusResolver.isItemPrintable(invoice);
		if (printStatus) {
			final PrintJobBuilder printJobBuilder = (PrintJobBuilder) Factories.INSTANCE.factory(PrintJobBuilder.class)
					.get(invoice);
			LOGGER.debug("Building the print job builder for invoice id {}", invoice.getId());
			final PrintJob pJob = printJobBuilder.buildPrintJob(invoice);
			pJobManager.processPrintJob(pJob);

		} else {
			LOGGER.debug("Printing of invoice is not enabled for tenant {}", TenantUtil.getTenantId());
		}
	}

//	@EventSubscription(eventName = { EventType.DMS_UPLOAD_FLOW_COMPLETED })
	public void updateSucessPrintJobStatus(final TenantAwareDocRefPayLoad awareDocRefPayLoad) {
		if (awareDocRefPayLoad.getDocRef() != null) {
			final DocumentRef documentRef = awareDocRefPayLoad.getDocRef();
			if (documentRef != null && documentRef.getDocRefId() != null) {
				final String docRefId = documentRef.getDocRefId();
				LOGGER.debug("Fetching the print job for the DCN number " + docRefId);
				final PrintJob printJob = printJobRepository.findByDcinNo(docRefId);
				if (printJob != null) {
					LOGGER.debug("updating the status of print job with id " + printJob.getExternalId());
					printJob.setJobStatus(PrintJobStatus.COMPLETED);
					int wfmProcessingAttempts = printJob.getWfmProcessingAttempts();
					printJob.setWfmProcessingAttempts(++wfmProcessingAttempts);
					printJobRepository.save(printJob);
					LOGGER.debug("Status completed for the job" + printJob.getExternalId());
				}
			}

		}
	}

//	@EventSubscription(eventName = { EventType.DMS_UPLOAD_FLOW_FAILED,
//			EventType.FILE_DOWNLOAD_FROM_DOC_REF_URL_FAILED })
	public void updateFailedPrintJobStatus(final TenantAwareDocRefPayLoad awareDocRefPayLoad) {
		if (awareDocRefPayLoad.getDocRef() != null) {
			final DocumentRef documentRef = awareDocRefPayLoad.getDocRef();
			if (documentRef != null && documentRef.getDocRefId() != null) {
				final String docRefId = documentRef.getDocRefId();
				LOGGER.debug("Fetching the print job for the DCN number " + docRefId);
				final PrintJob printJob = printJobRepository.findByDcinNo(docRefId);
				if (printJob != null) {
					LOGGER.debug("updating the status of print job with id " + printJob.getExternalId());
					int maxRetry = fetchMaxProcessingAttempts();
					if (printJob.getWfmProcessingAttempts() >= (maxRetry - 1)) {
						LOGGER.debug("Setting status STOPPED and wfmProcessingcount {}", maxRetry);
						printJob.setJobStatus(PrintJobStatus.STOPPED);
						printJob.setWfmProcessingAttempts(maxRetry);
					} else {
						LOGGER.debug("Setting status INCOMPLETE and updating wfmprocessingcount");
						printJob.setJobStatus(PrintJobStatus.INCOMPLETE);
						int wfmProcessingAttempts = printJob.getWfmProcessingAttempts();
						printJob.setWfmProcessingAttempts(++wfmProcessingAttempts);
					}
					printJobRepository.save(printJob);
					LOGGER.debug("Status completed for the job" + printJob.getExternalId());
				}
			}

		}
	}

	private int fetchMaxProcessingAttempts() {
		String maxRetry = ConfigurationUtil.get(PrintConstants.MAX_RETRY_COUNT_PDF_UPLOAD);
		LOGGER.debug("maxRetryCount configured is {}", maxRetry);
		if (maxRetry == null || maxRetry.isEmpty()) {
			LOGGER.debug("seting maxRetry count to default {}", defaultMaxPdfUploadAttempts);
			return defaultMaxPdfUploadAttempts;
		}
		return Integer.parseInt(maxRetry);
	}

}
