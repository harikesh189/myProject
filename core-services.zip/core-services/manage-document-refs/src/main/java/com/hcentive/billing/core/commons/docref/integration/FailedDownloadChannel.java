package com.hcentive.billing.core.commons.docref.integration;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.service.wfm.print.event.handler.PrintJobHandler;

public class FailedDownloadChannel {

	private final static Logger logger = LoggerFactory
			.getLogger(FailedDownloadChannel.class);
	
	@Autowired
	private PrintJobHandler printJobHandler;

	/*
	 * Method for handling the failed download channel
	 */
	public void handleDownloadFailded(Message<TenantAwareDocRefPayLoad> payLoad) {
		File file = new File((String) payLoad.getHeaders().get("tempDir"),
				(String) payLoad.getHeaders().get("tempFile"));
		file.delete();
		logger.debug("Temp file delete ::" + file.getAbsolutePath());
		printJobHandler.updateFailedPrintJobStatus(payLoad.getPayload());
		
		
//		EventUtils.publish(new Event(EventType.FILE_DOWNLOAD_FROM_DOC_REF_URL_FAILED,
//				payLoad.getPayload()));
		
	}

}
