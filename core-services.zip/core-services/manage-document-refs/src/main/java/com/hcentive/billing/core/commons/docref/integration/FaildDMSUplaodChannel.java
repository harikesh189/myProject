package com.hcentive.billing.core.commons.docref.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.service.wfm.print.event.handler.PrintJobHandler;

public class FaildDMSUplaodChannel {

	private static final Logger logger = LoggerFactory
			.getLogger(FaildDMSUplaodChannel.class);

	@Autowired
	private PrintJobHandler printJobHandler;
	
	/*
	 * Method for handling the failed dms Upload scenario
	 */
	public void proces(Message<TenantAwareDocRefPayLoad> payLoad) {
		logger.debug("Processing failed for docref id ::"
				+ payLoad.getPayload().getDocRef().getDocRefId());
//		if(ProcessContext.get()==null || ProcessContext.get().getTenantId() == null){
//		ProcessContext.initializer().forTenant(payLoad.getPayload().getTenantId()).initialize();
//		}
//		EventUtils.publish(new Event(EventType.DMS_UPLOAD_FLOW_FAILED, payLoad.getPayload()));
		printJobHandler.updateFailedPrintJobStatus(payLoad.getPayload());
//		ProcessContext.clear();
	}

}
