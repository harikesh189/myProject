package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.ItemRecordAware;
import com.hcentive.billing.core.commons.service.wfm.print.api.ItemXMLGenerator;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.vo.CriteriaOperator;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.xml.JAXBContextRegistry;
import com.hcentive.billing.wfm.imports.util.api.ItemService;

public abstract class ItemRecordAwareItemXMLGenerator<T extends ItemRecordAware,P> implements ItemXMLGenerator<T>,InitializingBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ItemRecordAwareItemXMLGenerator.class);
	
	@Autowired
	private ItemService itemService;
	
	private JAXBContext jaxbContext;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		LOGGER.debug("Initializing jaxb marshaller");
		jaxbContext = JAXBContextRegistry.getContext(getPojoClass());
		LOGGER.debug("Initializing JAXBContext completed");
	}
	
	protected String convertXML(P pojo) {
		final StringWriter writer = new StringWriter();
		try {
			final Marshaller marshaller = createMarshallar();
			marshaller.marshal(pojo, writer);
		} catch (Throwable e) {
			LOGGER.error("Error while converting pojo to xml {} ", getPojoUniqueId(pojo) );
			throw new Error("XML can't be generated",e);
		}
		return writer.toString();
	}


	/**
	 * Because Marshallar is not thread safe object, We are creating a new
	 * Marshallar object for each request.
	 * 
	 * @return Marshaller
	 * @throws JAXBException
	 */
	private Marshaller createMarshallar() throws JAXBException {
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		return marshaller;
	}

	@Override
	public String generateXMLToPrint(T t) {
		LOGGER.debug("Generationg xml for itemrecord id {}",t.getItemRecordId());
		final String itemRecordId = t.getItemRecordId();
		final SearchCriteria searchCriteria = new SearchCriteria();
		searchCriteria.addSingleValueCriteriaForMongo("_id", CriteriaOperator.EQUALS, itemRecordId);
		final P pojo = itemService.getItem(searchCriteria, getPojoClass() );
		if (null == pojo) {
			throw new IllegalAccessError("Pojo is null for itemrecord "
					+ itemRecordId);
		}
		LOGGER.debug("Pojo generated itemrecord id {}",t.getItemRecordId());
		String marshalledXML =  convertXML(pojo);
		LOGGER.debug("marshalled xml {} ", marshalledXML);
		if(null != marshalledXML && !marshalledXML.isEmpty()){
			marshalledXML = marshalledXML.replace(PrintConstants.INVOICE_TAG, PrintConstants.INVOICE_TAG_WITH_WFM_NAMESPACE);
		}
		LOGGER.debug("marshalled xml after adding xmlns {} ", marshalledXML);
		return marshalledXML;
		
	}

	protected abstract Class<P> getPojoClass();
	
	protected abstract String getPojoUniqueId(P pojo) ;


}
