package com.hcentive.billing.core.commons.service.wfm.print.rest.pojo;

import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.domain.util.DomainEntityUtils;
import com.hcentive.billing.core.commons.service.util.SystemConfig;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationRequest.DocumentDetails;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationRequest.DocumentDetails.DocumentIdentificationKeys;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationRequest.Header;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationRequest.TransactionInformation;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.util.DateUtility;

/**
 * Util class for Rest client .
 * 
 * @author ajay.saxena
 * 
 */
public final class RestUtil {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(RestUtil.class);

	public final static DocumentGenerationRequest buildRequest(
			final PrintJob job) throws DatatypeConfigurationException {
		LOGGER.debug("Build requst to hit Rest to submit print job");
		final DocumentGenerationRequest documentGenerationRequest = new DocumentGenerationRequest();
		documentGenerationRequest.setHeader(buildHeaders());
		documentGenerationRequest
				.setTransactionInformation(buildTranscationInformation(job));
		documentGenerationRequest.setDocumentDetails(buildDocumentDetails(job));
		return documentGenerationRequest;

	}

	private static DocumentDetails buildDocumentDetails(final PrintJob job) {
		final DocumentDetails documentDetails = new DocumentDetails();
		documentDetails
				.setDocumentIdentificationKeys(buildDocumentIdentificationKeys(job));

		documentDetails.setDocumentData(job.getPrintItem().getXml());
		documentDetails.setDocumentPaperPrintFlag(job.getPrintItem()
				.isPaperless() ? PrintConstants.DO_NOT_PRINT_ITEM
				: PrintConstants.PRINT_ITEM);
		return documentDetails;
	}

	private static DocumentIdentificationKeys buildDocumentIdentificationKeys(
			final PrintJob job) {
		final DocumentIdentificationKeys documentIdentificationKeys = new DocumentIdentificationKeys();
		documentIdentificationKeys.setBusinessKey1(job.getPrintItem()
				.getTenantId());
		documentIdentificationKeys.setBusinessKey2(job.getPrintItem()
				.getItemType().getSimpleName().toUpperCase());// TODO
		documentIdentificationKeys
				.setBusinessKey3(PrintConstants.DEFAULT_BUSINESS_KEY_3);
		documentIdentificationKeys
				.setBusinessKey4(PrintConstants.DEFAULT_BUSINESS_KEY_4);
		documentIdentificationKeys
				.setBusinessKey5(PrintConstants.DEFAULT_BUSINESS_KEY_5);
		return documentIdentificationKeys;
	}

	private static TransactionInformation buildTranscationInformation(
			final PrintJob job) throws DatatypeConfigurationException {
		final TransactionInformation information = new TransactionInformation();
		information.setControlNumber(job.getExternalId());
		information.setCurrentTimeStamp(DomainEntityUtils
				.convertDateTimeToXMLGregorianCal(SystemConfig.INSTANCE
						.currentDate()));
		information.setSourceSystemId(PrintConstants.SOURCE_SYSTEM_ID);
		information.setSourceSystemAckUri(buildAckSoapURL());
		return information;
	}

	private static Header buildHeaders() {
		final Header header = new Header();
		header.setVersionNumber("1.0"); // TODO
		return header;
	}

	private static String buildAckSoapURL() {
		String ackURL = ConfigurationUtil
				.get(PrintConstants.WFM_SOAP_CALL_BACK);
		if (null == ackURL)
			throw new IllegalArgumentException(
					"No SOAP URI configured for tenant "
							+ TenantUtil.getTenantId());
		if (TenantUtil.getTenantId() == null)
			throw new IllegalArgumentException(
					"Tenant is not provided in the url");
		ackURL = ackURL.concat(TenantUtil.getTenantId());
		return ackURL;
	}

	public static PrintResponse buildPrintJobResponse(
			DocumentGenerationResponse response, PrintJob pJob) {
		final PrintResponse printResponse = new PrintResponse();
		if (response.getRequestStatus().equals(
				PrintConstants.RESPONSE_STATUS_FAILURE)) {
			final List<DocumentGenerationResponseMetaData> documentGenerationResponseMetaDatas = response
					.getResponses();
			for (DocumentGenerationResponseMetaData documentGenerationResponseMetaData : documentGenerationResponseMetaDatas) {
				printResponse.setErroMsgs(documentGenerationResponseMetaData
						.getErrorDescriptionText());
			}
		}
		printResponse.setJobId(pJob.getExternalId());
		printResponse.setTrackingNumber(response.getRequestTrackingNumber());
		printResponse.setResponseStatus(response.getRequestStatus()); // TODO
		return printResponse;
	}

	public static HttpEntity buildDownloadHeaders(PrintJob pJob) {
		final MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		HttpHeaders headers = new HttpHeaders();
		headers.add(PrintConstants.HEADER_SOURCE_SYSTEM_ID,
				PrintConstants.SOURCE_SYSTEM_ID);
		headers.add(PrintConstants.HEADER_VERSION_NUMBER, "1.0.1");
		headers.add(PrintConstants.HEADER_CONTROL_NUMBER, pJob.getExternalId());
		headers.add(PrintConstants.HEADER_CURRENT_TIMESTAMP, DateUtility
				.convertDateToString(SystemConfig.INSTANCE.currentDate()
						.getDate(), DateUtility.MM_DD_YYYY_HH_MM_SS));
		HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<MultiValueMap<String, String>>(
				map, headers);
		return requestEntity;

	}

	public static PrintResponse buildFailResponse(String externalId) {
		final PrintResponse printResponse = new PrintResponse();
		printResponse.setResponseStatus(PrintConstants.RESPONSE_STATUS_FAILURE);
		printResponse.setJobId(externalId);
		return printResponse;
	}

}
