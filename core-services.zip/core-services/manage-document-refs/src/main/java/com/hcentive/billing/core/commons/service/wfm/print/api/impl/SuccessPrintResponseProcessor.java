package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.wfm.print.api.PrintResponseProcessor;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJobStatus;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;
import com.hcentive.billing.core.commons.service.wfm.print.repository.PrintJobRepository;

/**
 * Class to process Successful PrintResponse.
 * 
 * @author ajay.saxena
 *
 */
@Component
public class SuccessPrintResponseProcessor implements PrintResponseProcessor {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SuccessPrintResponseProcessor.class);

	@Autowired
	private PrintJobRepository printJobRepo;

	@Override
	public void processPrintResponse(PrintResponse printResponse) {

		/**
		 * if Response is success. Update printjob with tracking id, change its
		 * status to Submitted and set processing attempst as 1.
		 * 
		 */
		final PrintJob printJob = printJobRepo.findByExternalId(printResponse.getJobId());
		printJob.setTrackingId(printResponse.getTrackingNumber());
		printJob.setJobStatus(PrintJobStatus.parse(printResponse
				.getResponseStatus()));
		int processingAttempts = printJob.getPrintJobSubmittedAttempts();
		printJob.setPrintJobSubmittedAttempts(++processingAttempts);
		LOGGER.debug("Updating the print job obj with status and tracking number");
		printJobRepo.save(printJob);

	}

}
