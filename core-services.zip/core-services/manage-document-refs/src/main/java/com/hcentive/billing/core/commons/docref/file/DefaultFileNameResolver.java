package com.hcentive.billing.core.commons.docref.file;

import java.util.List;

import org.apache.shiro.cache.Cache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.ConfigurationConstant;
import com.hcentive.billing.core.commons.service.ebill.configuration.util.ConfigurationUtil;

@Component
public class DefaultFileNameResolver implements FileNameResolver {

	private static final Logger logger = LoggerFactory
			.getLogger(DefaultFileNameResolver.class);

	@Autowired
	private Cache<String, List<Configuration>> tenantConnectionCache;

	@Override
	public String getTenantSpecificFileName(String tenantId, String fileName) {
		if (checkForExtension(fileName)) {
			return fileName;
		} else {
			List<Configuration> configurations = tenantConnectionCache
					.get(tenantId.toUpperCase());
			String defaultExtension = ConfigurationUtil.getConfigValue(
					configurations,
					ConfigurationConstant.DMS_TENANT_FILE_EXTENSION);
			if (defaultExtension != null) {
				return fileName + "." + defaultExtension;
			} else {
				return fileName;
			}

		}
	}

	private static boolean checkForExtension(String fileName) {
		int lastIndexOfSeparator = fileName.lastIndexOf('.');
		if (lastIndexOfSeparator == -1
				|| lastIndexOfSeparator + 1 == fileName.length()) {
			return false;
		}

		String ext = fileName.substring(lastIndexOfSeparator + 1);
		for (int i = 0; i < EXTENSIONS.length; i++) {
			if (ext.equals(EXTENSIONS[i])) {
				logger.debug("File name matched with probable extension : {}",
						ext);
				return true;
			}
		}
		logger.debug("File name does not contain extension");
		return false;
	}

}
