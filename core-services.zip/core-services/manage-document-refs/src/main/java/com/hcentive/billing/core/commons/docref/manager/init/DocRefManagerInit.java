package com.hcentive.billing.core.commons.docref.manager.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.hcentive.billing.core.commons.condition.ConditionalOnBeanNameAbsent;
import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.factory.IsForTask;
import com.hcentive.billing.core.commons.factory.TaskAwareFactory;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;
import com.hcentive.billing.core.commons.service.wfm.print.api.ItemXMLGenerator;
import com.hcentive.billing.core.commons.service.wfm.print.api.PaperlessPreferenceChecker;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobBuilder;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintResponseProcessor;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintService;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintStatusResolver;
import com.hcentive.billing.core.commons.service.wfm.print.api.impl.FailurePrintResponseProcessor;
import com.hcentive.billing.core.commons.service.wfm.print.api.impl.SuccessPrintResponseProcessor;

@Configuration
@PropertySources(value = {
		@PropertySource("file:${baseDir}/config/properties/db.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties"),
		@PropertySource("file:${baseDir}/config/properties/amqp.properties"),
		@PropertySource("file:${baseDir}/config/properties/dmsutil.properties"),
		@PropertySource("file:${baseDir}/config/properties/docref.properties"),
		@PropertySource("file:${baseDir}/config/properties/cronJob.properties"),
		@PropertySource("file:${baseDir}/config/properties/mongodb.properties") })
@EnableJpaRepositories(basePackages = {
		"com.hcentive.billing.core.commons.docref.repository",
		"com.hcentive.billing.core.commons.service.ebill.configuration.repository",
		"com.hcentive.billing.core.commons.starter.persistence.repository",
		"com.hcentive.billing.core.commons.service.ebill.dms.repository",
		"com.hcentive.billing.core.commons.persistence.factory.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EntityScan({ "com.hcentive.billing.core.commons",
		"com.hcentive.billing.wfm.domain" })
@EnableMongoRepositories(basePackages = { "com.hcentive.billing.core.commons.starter.persistence.repository","com.hcentive.billing.core.commons.service.wfm.print.repository" })
@ImportResource("docref-handler.xml")
@ComponentScan("com.hcentive.billing")
@EnableScheduling
@EnableAutoConfiguration
public class DocRefManagerInit {

	@Autowired
	private RestTemplate restTemplate;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DocRefManagerInit.class);

	public static void main(String... args) {
		LOGGER.debug("Starting DocRef Manager service for hcentive !!");
		SpringApplication.run(DocRefManagerInit.class, args);

	}
	
	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
	
	@Bean
	public TaskAwareFactory<IsForTask> printStatusResolverTransformerFactory() {
		final TaskAwareFactory<IsForTask> printStatusResolverTransformerFactory = new TaskAwareFactory(
				PrintStatusResolver.class);
		Factories.INSTANCE.registerBean(printStatusResolverTransformerFactory);
		return printStatusResolverTransformerFactory;
	}

	@Bean
	public TaskAwareFactory<IsForTask> printJobTransformerFactory() {
		final TaskAwareFactory<IsForTask> printJobBuilderTransformerFactory = new TaskAwareFactory(
				PrintJobBuilder.class);
		Factories.INSTANCE.registerBean(printJobBuilderTransformerFactory);
		return printJobBuilderTransformerFactory;
	}

	@Bean
	public TaskAwareFactory<IsForTask> itemXMLGeneratorFactory() {
		final TaskAwareFactory<IsForTask> itemXMLGenerator = new TaskAwareFactory(
				ItemXMLGenerator.class);
		Factories.INSTANCE.registerBean(itemXMLGenerator);
		return itemXMLGenerator;
	}

	@Bean
	public TaskAwareFactory<IsForTask> printServiceFactory() {
		final TaskAwareFactory<IsForTask> printService = new TaskAwareFactory(
				PrintService.class);
		Factories.INSTANCE.registerBean(printService);
		return printService;
	}
	
	@Bean
	public TaskAwareFactory<IsForTask> paperlessPreferenceChecker() {
		final TaskAwareFactory<IsForTask> paperlessPreferenceChecker = new TaskAwareFactory(
				PaperlessPreferenceChecker.class);
		Factories.INSTANCE.registerBean(paperlessPreferenceChecker);
		return paperlessPreferenceChecker;
	}

	@Bean
	@ConditionalOnBeanNameAbsent
	public PrintResponseProcessor successfulPrintResponseProcessor() {
		return new SuccessPrintResponseProcessor();
	}

	@Bean
	@ConditionalOnBeanNameAbsent
	public PrintResponseProcessor failurePrintResponseProcessor() {
		return new FailurePrintResponseProcessor();
	}
}
