package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.wfm.print.api.PrintResponseProcessor;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintResponseProcessorFactory;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;

@Component
public class DeaultPrintResponseProcessorFactory implements
		PrintResponseProcessorFactory, ApplicationContextAware {

	private static final Logger LOGGER = LoggerFactory.getLogger(DefaulrPrintJobProcessingStrategy.class);

	private ApplicationContext appContext;

	@Override
	public PrintResponseProcessor getProcessor(PrintResponse printResponse) {
		LOGGER.debug("finding print resposne processor for printResonse for job id {} and status {}",printResponse.getJobId(), printResponse.getResponseStatus());
		if (printResponse.getResponseStatus().equals(PrintConstants.SUCCESS)) {
			return appContext.getBean(PrintConstants.SUCCESS_PRINT_RESPONE_PROCESSOR,
					PrintResponseProcessor.class);
		}
		return appContext.getBean(PrintConstants.FAILURE_PRINT_RESPONSE_PROCESSOR,
				PrintResponseProcessor.class);

	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.appContext = applicationContext;
	}

}
