package com.hcentive.billing.core.commons.docref.pdf;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.docref.domain.DocumentGenerationParameters;
import com.hcentive.billing.core.commons.docref.repository.DocumentGenerationParametersRepository;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
public class PDFGeneratorServiceImpl implements PDFGeneratorService{
	
	private static Logger LOGGER = LoggerFactory.getLogger(PDFGeneratorServiceImpl.class);

	@Autowired
	DocumentGenerationParametersRepository documentGenerationParametersRepository;
	
	@Autowired
	PDFCreator pdfCreator;
	
	@Override
	public void generatePDF(String eventName, Object pdfGenerationPayload) {
		byte[] pdfData = null;
		String tenant = ProcessContext.get().getTenantId();
		pdfGenerationPayload.getClass();
		DocumentGenerationParameters documentGenerationParameters = documentGenerationParametersRepository.findByLanguageCodeAndTenantIdAndMarketAndPdfType("EN", tenant, "INDIVIDUAL", "Invoice");
		try {
			pdfData = pdfCreator.writePDF(BeanUtils.describe(pdfGenerationPayload),documentGenerationParameters.getPdfTemplate());
		} catch (Exception e) {
			LOGGER.error("Exception while creating PDF" , e);
		}		
	}
}
