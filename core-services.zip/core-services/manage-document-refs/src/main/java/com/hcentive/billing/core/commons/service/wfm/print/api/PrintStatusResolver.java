package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.factory.IsForTask;

/**
 * @author ajay.saxena
 * 
 * Interface to check if item is printable or not.
 *
 * @param <T>
 */
public interface PrintStatusResolver<T> extends IsForTask {
	
	boolean isItemPrintable(T t);

}
