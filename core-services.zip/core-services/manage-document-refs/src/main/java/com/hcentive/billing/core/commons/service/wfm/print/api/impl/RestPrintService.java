package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.wfm.print.api.PrintService;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationRequest;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.DocumentGenerationResponse;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.PrintRestClient;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.RestUtil;

@Component
public class RestPrintService implements PrintService {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(RestPrintService.class);
	
	@Autowired
	private PrintRestClient restClient;
	
	@SuppressWarnings("unchecked")
	@Override
	public PrintResponse print(PrintJob pJob)  {
		try {
			LOGGER.debug("Doing Print");
			final DocumentGenerationRequest documentGenerationRequest = RestUtil.buildRequest(pJob);
			final DocumentGenerationResponse response = restClient.postToPrint(documentGenerationRequest);
			return RestUtil.buildPrintJobResponse(response,pJob);
		} catch (Exception e) {
			LOGGER.error("Print Job couldnt be submitted to Rest Client.",e);
			throw new RuntimeException("Print Job Failed",e);
		}
	}


}
