package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;

public interface PrintJobProcessingStrategy {
	
	public PrintService resolvePrintService(final PrintJob  job);

}
