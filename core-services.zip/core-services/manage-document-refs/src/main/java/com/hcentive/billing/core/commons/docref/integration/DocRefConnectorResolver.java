package com.hcentive.billing.core.commons.docref.integration;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.shiro.cache.CacheException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.domain.DocumentRef;
import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.service.wfm.print.constant.PrintConstants;
import com.hcentive.billing.core.commons.util.CommonUtility;
import com.hcentive.billing.core.commons.util.CommonUtility.Connection;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/*
 * Class to resolve and route to proper connection(ftp/http) on the basis of tenant.
 */

public class DocRefConnectorResolver {

	private static final Logger logger = LoggerFactory
			.getLogger(DocRefConnectorResolver.class);

	@Autowired
	private WFMCache<String, List<Configuration>> tenantConnectionCache;

	public String resolveConnector(Message<TenantAwareDocRefPayLoad> payLoad)
			throws CacheException, InterruptedException, ExecutionException {
		logger.debug("Resolving connector for tenant");
		DocumentRef docRef = payLoad.getPayload().getDocRef();
		logger.debug("fetching configurations for : {}", payLoad.getPayload()
				.getTenantId());
		if (null != payLoad.getPayload().getTenantId()) {
			ProcessContext.clear();
			ProcessContext.initialize(null, null, payLoad.getPayload()
					.getTenantId(), null, null, null);
		}
		/*List<Configuration> connectionConfig = getConfigFromCache(payLoad
				.getPayload().getTenantId());
		for (Configuration configuration : connectionConfig) {
			logger.debug("{} : {}", configuration.getKey(),
					configuration.getValue());
		}*/
		Connection connectionType = getConnection(null);

		if (connectionType != null) {
			logger.debug("fetched connectionType : {} ", connectionType);
			switch (connectionType) {
			case FTP:
				logger.debug("Routing to ftpURLHandler for docrefId :: {} ",
						docRef.getDocRefId());
				return "ftpURLHandler";
			case HTTP:
				boolean isHTTPURL = CommonUtility.isValidURL(docRef
						.getExternalURL());
				if (isHTTPURL) {
					logger.debug(
							"Routing to httpURLHandler for docrefId :: {}",
							docRef.getDocRefId());
					return "httpURLHandler";
				} else {
					logger.debug(
							"Routing to invalidURLHandler for docrefId :: {}",
							docRef.getDocRefId());
					return "invalidURLHandler";
				}
			case REST:
				logger.debug("Routing to rest url for docrefId {}",docRef.getDocRefId());
				return "restURLHandler";
			default:
				return "invalidURLHandler";
			}
		} else {
			return "invalidURLHandler";
		}
	}

	/*private List<Configuration> getConfigFromCache(String tenantId)
			throws InterruptedException, ExecutionException {
		List<Configuration> configurations;
		logger.debug("Fetching tenant specific cached configurations");
		configurations = tenantConnectionCache.get(tenantId.toUpperCase());
		return configurations;
	}*/

	private Connection getConnection(List<Configuration> configs) {

		String conType = ConfigurationUtil.get(PrintConstants.PDF_DOWNLOAD_CLIENT);
		logger.debug("connection type found is : {}", conType);
		if (conType != null) {
			if (conType.equalsIgnoreCase("HTTP")) {
				return Connection.HTTP;
			}
			if (conType.equalsIgnoreCase("FTP")) {
				return Connection.FTP;
			} 
			if(conType.equalsIgnoreCase("REST")){
				return Connection.REST;
			}
			else {
				logger.debug("No connector found");
				return null;
			}
		} else {
			return null;
		}
	}

}
