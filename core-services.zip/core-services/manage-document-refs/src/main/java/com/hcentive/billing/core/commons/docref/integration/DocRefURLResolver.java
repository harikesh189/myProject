package com.hcentive.billing.core.commons.docref.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.domain.DocumentRef;
import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.util.CommonUtility;

/*
 * Class to route the httpURLHandler if the url is http otherwise to 
 * invalidURLHandler
 */

public class DocRefURLResolver {

	private static final Logger logger = LoggerFactory
			.getLogger(DocRefURLResolver.class);

	public String resolveURL(
			Message<TenantAwareDocRefPayLoad> invoiceDocRefPayLoad) {
		DocumentRef docRef = invoiceDocRefPayLoad.getPayload().getDocRef();
		String url = docRef.getExternalURL();

		// check if its FTP OR HTTP
		// forward it to corret channnel.

		boolean isHTTPURL = CommonUtility.isValidURL(docRef.getExternalURL());
		if (isHTTPURL) {
			logger.debug("Routing to httpURLHandler for docrefId ::"
					+ docRef.getDocRefId());
			return "httpURLHandler";
		}
		logger.debug("Routing to invalidURLHandler for docrefId ::"
				+ docRef.getDocRefId());

		return "invalidURLHandler";

	}

}
