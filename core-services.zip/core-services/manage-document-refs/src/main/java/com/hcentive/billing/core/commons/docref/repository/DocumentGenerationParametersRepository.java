package com.hcentive.billing.core.commons.docref.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.docref.domain.DocumentGenerationParameters;


public interface DocumentGenerationParametersRepository extends
		JpaRepository<DocumentGenerationParameters, Long> {

	public DocumentGenerationParameters findByLanguageCodeAndTenantIdAndMarketAndPdfType(
			String languageCode, String Tenant, String market,String pdfType);

}
