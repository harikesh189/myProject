package com.hcentive.billing.core.commons.docref.integration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.docref.file.DefaultFileNameResolver;
import com.hcentive.billing.core.commons.docref.print.pojo.DocumentResponse;
import com.hcentive.billing.core.commons.docref.print.pojo.DocumentResponseMetaData;
import com.hcentive.billing.core.commons.domain.DocumentRef;
import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.service.wfm.print.rest.pojo.PDFRestClient;

public class RestURLHandler extends URLHandler<TenantAwareDocRefPayLoad> {

	@Value("${docref.temp.directory}")
	private String tempDocRefDirectory;

	@Autowired
	private DefaultFileNameResolver fileNameResolver;

	@Autowired
	private PDFRestClient restClient;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(RestURLHandler.class);

	public Message<TenantAwareDocRefPayLoad> handleURL(
			Message<TenantAwareDocRefPayLoad> payLoad) {
		boolean status = true;
		final TenantAwareDocRefPayLoad tenantAwareDocRefPayLoad = payLoad
				.getPayload();
		final DocumentRef documentRef = tenantAwareDocRefPayLoad.getDocRef();
		LOGGER.debug("Setting the docrefId in the dcinNo");

		final String dcinNo = documentRef.getDocRefId();
		final String tempFileName = getTempFileName();
		try {
			final DocumentResponse response = restClient
					.downloadPDF(documentRef);
			processDownlaodResponse(response, payLoad, tempFileName);
		} catch (Throwable e) {
			status = false;
			LOGGER.error("Erro while hitting RestClinet ", e);
		}

		final Map<String, Object> modifiedHeaders = new HashMap<String, Object>();
		modifiedHeaders.put("tempDir", tempDocRefDirectory);
		modifiedHeaders.put("tempFile", tempFileName);
		modifiedHeaders.put("status", status);
		LOGGER.debug("tempDir,tempFile and status is added to the message header");
		return enrichPayload(payLoad, modifiedHeaders);

	}

	private void processDownlaodResponse(DocumentResponse documentResponse,
			Message<TenantAwareDocRefPayLoad> payLoad, String tempFileName)
			throws Exception {

		final DocumentResponseMetaData documentResponseMetaData = documentResponse
				.getResponse();
		if (documentResponseMetaData != null && !documentResponseMetaData.getResponseCode().equals("200")) {
			LOGGER.debug("Processing failure response.");
			processForError(documentResponseMetaData);
		} else {
			LOGGER.debug("Processing success reponse.");
			processForSuccess(documentResponse, tempFileName);
		}

	}

	private void processForSuccess(DocumentResponse documentResponse,
			String tempFileName) throws IOException {
		final File fileDir = new File(tempDocRefDirectory);
		if (!fileDir.exists()) {
			fileDir.mkdir();
		}
		final File newFile = new File(fileDir, tempFileName);
		LOGGER.debug("temp file created with name {}", tempFileName);
		InputStream inputStream = documentResponse.getDocumentContent()
				.getInputStream();
		FileUtils.copyInputStreamToFile(inputStream, newFile);
	}

	private void processForError(
			final DocumentResponseMetaData documentResponseMetaData) {
		final List<String> list = documentResponseMetaData
				.getErrorDescriptionText();
		final StringBuilder errorMsgBuilder = new StringBuilder();
		final String responseCode=documentResponseMetaData.getResponseCode();
		final String responseDescriptionText=documentResponseMetaData.getResponseDescriptionText();
		for (String errorMessages : list) {
			errorMsgBuilder.append(errorMessages);
		}
		errorMsgBuilder.append("::"+responseCode+"::");
		errorMsgBuilder.append(responseDescriptionText);
		throw new RuntimeException("Error while downloading pdf:::"
				+ errorMsgBuilder.toString());
	}
}
