package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintResponse;

public interface PrintResponseProcessor {
	
	void processPrintResponse(PrintResponse printResponse);

}
