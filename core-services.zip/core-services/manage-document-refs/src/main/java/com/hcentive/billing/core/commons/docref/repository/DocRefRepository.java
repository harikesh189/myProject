package com.hcentive.billing.core.commons.docref.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.DocumentRef;


@Transactional
public interface DocRefRepository extends JpaRepository<DocumentRef, Long> {

	DocumentRef findByDmsKey(String dmsKey);

}
