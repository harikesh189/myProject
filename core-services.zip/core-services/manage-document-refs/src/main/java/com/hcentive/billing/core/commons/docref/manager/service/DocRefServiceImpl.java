package com.hcentive.billing.core.commons.docref.manager.service;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.docref.pdf.PDFCreator;
import com.hcentive.billing.core.commons.docref.repository.DocRefRepository;
import com.hcentive.billing.core.commons.docref.repository.DocumentGenerationParametersRepository;
import com.hcentive.billing.core.commons.domain.DocumentRef;
import com.hcentive.billing.core.commons.util.StreamUtility;

@Component
public class DocRefServiceImpl implements DocRefService {

	@Autowired
	private DocRefRepository docRefRepository;
	
	@Autowired
	private PDFCreator pdfCreator;
	
	@Autowired
	private DocumentGenerationParametersRepository documentGenerationParametersRepository;

	private static final Logger logger = LoggerFactory
			.getLogger(DocRefServiceImpl.class);

	@Override
	public boolean downloadFromURL(final String externalUrl,
			final String tempDocRefDirectory, final String tempFileName) {
		boolean isDownloadSuccess = true;
		try {
			StreamUtility.downloadFromURL(externalUrl, tempDocRefDirectory,
					tempFileName);
		} catch (Exception e) {
			logger.error("Error while downloading file from URL::"
					+ externalUrl);
			isDownloadSuccess = false;
		}
		logger.debug("returning from downloadFromURL with the value"
				+ isDownloadSuccess);
		return isDownloadSuccess;
	}

	@Override
	public String uploadToURL(final String dmsServiceURL,
			final String tempDocRefDirectory, final String tempFileName) {
		String dmsKey = null;
		try {
			dmsKey = StreamUtility.postStreamToURL(dmsServiceURL,
					tempDocRefDirectory, tempFileName);
		} catch (Exception e) {
			logger.error("Exception while uploading through dms service", e);
		} finally {
			File file = new File(tempDocRefDirectory, tempFileName);
			file.delete();
			logger.debug("deleted temporary file" + file.getAbsolutePath());
		}
		return dmsKey;

	}

	@Override
	@Transactional
	public void saveDmsKey(DocumentRef docref) {
		logger.debug("Saving dmskey in docref table::" + docref.getDmsKey());
		DocumentRef docrefEntity = docRefRepository.findOne(docref.getId());
		docrefEntity.setDmsKey(docref.getDmsKey());
		docRefRepository.save(docrefEntity);
		logger.debug("Saved dmskey in docref table::" + docref.getDmsKey());

	}
}
