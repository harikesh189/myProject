package com.hcentive.billing.core.commons.docref.file;

public interface FileNameResolver {

	String[] EXTENSIONS = { ".pdf", ".xls", "txt" };

	String getTenantSpecificFileName(String tenantId, String fileName);
}
