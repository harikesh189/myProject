package com.hcentive.billing.core.commons.docref.manager.service;

import com.hcentive.billing.core.commons.domain.DocumentRef;

public interface DocRefService {

	public boolean downloadFromURL(final String externalUrl,
			final String tempDocRefDirectory, final String tempFile);

	public String uploadToURL(final String dmsServiceURL,
			final String tempDocRefDirectory, final String tempFile);

	public void saveDmsKey(DocumentRef docref);

}
