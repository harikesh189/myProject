package com.hcentive.billing.core.commons.service.wfm.print.api;

import com.hcentive.billing.core.commons.factory.IsForTask;

public interface ItemXMLGenerator<T>  extends IsForTask  {
	
	String generateXMLToPrint(T t);
}
