package com.hcentive.billing.core.commons.service.wfm.print.schedular;

public interface PrintJobSchedularService {

	public void scheduleIncompletePrintJobs();

	public void scheduleFailedJobs();
	
}
