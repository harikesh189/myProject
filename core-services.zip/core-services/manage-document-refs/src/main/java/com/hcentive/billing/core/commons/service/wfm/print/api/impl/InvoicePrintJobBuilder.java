package com.hcentive.billing.core.commons.service.wfm.print.api.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.service.wfm.print.api.ItemXMLGenerator;
import com.hcentive.billing.core.commons.service.wfm.print.api.PaperlessPreferenceChecker;
import com.hcentive.billing.core.commons.service.wfm.print.api.PrintJobBuilder;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintItem;
import com.hcentive.billing.core.commons.service.wfm.print.domain.PrintJob;
import com.hcentive.billing.core.commons.service.wfm.print.repository.PrintJobRepository;

@Component
public class InvoicePrintJobBuilder implements PrintJobBuilder<Invoice> {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(InvoicePrintJobBuilder.class);

	@Autowired
	private PrintJobRepository pJobRepository;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public PrintJob buildPrintJob(Invoice t) {
		LOGGER.debug("generating the xml to be printed");
		final ItemXMLGenerator<Invoice> xmlGenerator = (ItemXMLGenerator) Factories.INSTANCE
				.factory(ItemXMLGenerator.class).get(t);
		final String xml = xmlGenerator.generateXMLToPrint(t);
		
		LOGGER.debug("Building the print item obj");
		LOGGER.debug("generating the paperless prefernce ");
		final PaperlessPreferenceChecker<Invoice> invoicePaperlessPreference=(PaperlessPreferenceChecker) Factories.INSTANCE
				.factory(PaperlessPreferenceChecker.class).get(t);
		final PrintItem pItem = new PrintItem(t.getClass(), t.getIdentity(), t.getTenantId(), xml,invoicePaperlessPreference.resolvePaperlessPreference(t));
		final PrintJob pJob = PrintJob.initPrintJob(pItem);
		LOGGER.debug("Saving the print job object in mongo");
		final PrintJob printJob = pJobRepository.save(pJob);
		LOGGER.debug("PrintJob Saved");
		return printJob;
	}


	@Override
	public boolean canHandle(Object type) {
		return Invoice.class.isAssignableFrom(type.getClass());
	}

}
