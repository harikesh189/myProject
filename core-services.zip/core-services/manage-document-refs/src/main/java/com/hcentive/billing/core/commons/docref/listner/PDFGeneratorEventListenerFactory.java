/**
 * 
 */
package com.hcentive.billing.core.commons.docref.listner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.docref.pdf.PDFGeneratorService;
import com.hcentive.billing.core.commons.event.EventListener;

/**
 * @author Neeraj Aggarwal
 * 
 */
@Component
public class PDFGeneratorEventListenerFactory {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PDFGeneratorEventListenerFactory.class);
	
	@Autowired
	PDFGeneratorService pdfGeneratorService;

	private class PDFGeneratorEventListener implements EventListener {

		private final String eventName;

		public PDFGeneratorEventListener(String eventName) {
			this.eventName = eventName;
		}

		@Override
		public void handle(Object payload) {
			LOGGER.debug("Received payload for event:{} and payload {}",
					eventName, payload);
			doHandle(this.eventName, payload);
			LOGGER.debug("Processed payload for event:{} and payload {}",
					eventName, payload);
		}

		private void doHandle(String eventName, Object pdfGenerationPayload) {
			
			pdfGeneratorService.generatePDF(eventName,pdfGenerationPayload);
		}

		@Override
		public String handlerId() {
			return "PDFGeneratorEventListener_" + this.eventName;
		}

		@Override
		public boolean recieveOfflineEvents() {
			return true;
		}

	}

	public EventListener createNew(String eventName) {
		return new PDFGeneratorEventListener(eventName);
	}

}
