package com.hcentive.billing.core.commons.docref.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.hcentive.billing.core.commons.docref.manager.service.DocRefService;
import com.hcentive.billing.core.commons.domain.DocumentRef;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.event.TenantAwareDocRefPayLoad;
import com.hcentive.billing.core.commons.service.wfm.print.event.handler.PrintJobHandler;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class SuccessfulDMSUploadChannel {

	private static final Logger logger = LoggerFactory
			.getLogger(SuccessfulDMSUploadChannel.class);

	@Autowired
	private DocRefService docRefService;
	
	@Autowired
	private PrintJobHandler printJobHandler;

	/*
	 * Method for handling the success dms upload and set dmskey in docref and
	 * update it
	 */
	public void handleSuccessfulDMSUpload(
			Message<TenantAwareDocRefPayLoad> payLoad) {
		logger.debug("Inside handleSuccessfulDMSUpload method:: for docrefId::"
				+ payLoad.getPayload().getDocRef().getDocRefId());
		DocumentRef docref = payLoad.getPayload().getDocRef();
		String dmsKey = (String) payLoad.getHeaders().get("dmsKey");
		docref.setDmsKey(dmsKey);
		docRefService.saveDmsKey(docref);
		logger.debug("Docref updated with dmskey " + dmsKey + " for docrefId::"
				+ payLoad.getPayload().getDocRef().getDocRefId());
		printJobHandler.updateSucessPrintJobStatus(payLoad.getPayload());
//		if (ProcessContext.get() == null
//				|| ProcessContext.get().getTenantId() == null) {
//			ProcessContext.initializer()
//					.forTenant(payLoad.getPayload().getTenantId()).initialize();
//		}
//		EventUtils.publish(new Event(EventType.DMS_UPLOAD_FLOW_COMPLETED,
//				payLoad.getPayload()));
//		ProcessContext.clear();
	}
}
