#!/bin/bash
clear
echo "Launching Doc Ref Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/manage-document-refs -Xloggc:/var/log/wfm/manage-document-refs/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar manage-document-refs-1.0.RELEASE.jar --server.port=8118