/**
 * 
 */
package com.hcentive.billing.core.commons.notification;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.util.StringValueResolver;

/**
 * @author Kumar Sambhav Jain
 * 
 */
public class PropertyBasedReminderConfigurer implements
		BusinessReminderConfigurer, EmbeddedValueResolverAware {

	private static final String REMINDER_QUERY_PREFIX = "billing.reminder.query.";

	@Value("${billing.reminder.events}")
	private String businessReminderEventStr;

	private StringValueResolver propertyResolver;

	private Map<String, String> configuredReminders = new HashMap<String, String>();

	@Override
	public Map<String, String> configuredReminders() {

		return this.configuredReminders;
	}

	@PostConstruct
	public void init() {
		if (businessReminderEventStr != null) {
			final String[] reminderEvents = businessReminderEventStr.split(",");
			for (final String eventName : reminderEvents) {
				final String queryLookupStr = REMINDER_QUERY_PREFIX + eventName;
				final String query = this.propertyResolver
						.resolveStringValue("${" + queryLookupStr + "}");
				configuredReminders.put(eventName, query);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.context.EmbeddedValueResolverAware#
	 * setEmbeddedValueResolver(org.springframework.util.StringValueResolver)
	 */
	@Override
	public void setEmbeddedValueResolver(StringValueResolver resolver) {
		this.propertyResolver = resolver;
	}
}
