/**
 * 
 */
package com.hcentive.billing.core.commons.notification;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.notification.batch.ReminderProcessor;

/**
 * @author Kumar Sambhav Jain
 * 
 */
@Component
public class BusinessRemindersBean implements InitializingBean {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private JobRepository jobRepository;

	@Autowired
	private ItemReadListener<Object> itemReaderListener;

	private final List<Job> jobs = new ArrayList<>();

	private Map<String, String> eventQueryMap;

	@Autowired
	private JobExecutionListener jobExecutionListener;

	/**
	 * @return the eventQueryMap
	 */
	public Map<String, String> getEventQueryMap() {
		return eventQueryMap;
	}

	/**
	 * @param eventQueryMap
	 *            the eventQueryMap to set
	 */
	public void setEventQueryMap(Map<String, String> eventQueryMap) {
		this.eventQueryMap = eventQueryMap;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		if (eventQueryMap != null && eventQueryMap.size() > 0)
			for (String eventName : eventQueryMap.keySet()) {

				JpaPagingItemReader<Object> jpaPagingItemReader = new JpaPagingItemReader<>();
				jpaPagingItemReader
						.setEntityManagerFactory(entityManagerFactory);
				jpaPagingItemReader.setPageSize(10);
				jpaPagingItemReader
						.setQueryString(eventQueryMap.get(eventName));

				Job job = jobBuilderFactory
						.get(eventName + "Reminder")
						.start(stepBuilderFactory.get(eventName + "Step")
								.chunk(10).reader(jpaPagingItemReader)
								.listener(itemReaderListener)
								.processor(new ReminderProcessor(eventName))
								.build()).listener(jobExecutionListener)
						.build();
				jobs.add(job);
			}
	}

	/**
	 * @return the jobs
	 */
	public List<Job> getJobs() {
		return jobs;
	}

}
