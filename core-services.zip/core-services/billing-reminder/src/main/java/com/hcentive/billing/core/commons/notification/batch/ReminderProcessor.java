/**
 * 
 */
package com.hcentive.billing.core.commons.notification.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventUtils;

/**
 * @author Kumar Sambhav Jain
 * 
 */

public class ReminderProcessor implements ItemProcessor<Object, Object> {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(ReminderProcessor.class);

	private final String eventName;

	/**
	 * @param eventName
	 */
	public ReminderProcessor(String eventName) {
		super();
		this.eventName = eventName;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object process(Object targetObj) throws Exception {
		logger.debug("Will Process invoice item for notification now for {}",
				eventName);
		// publish event for notification.
		EventUtils.publish(new Event(eventName, targetObj));
		return targetObj;
	}

}
