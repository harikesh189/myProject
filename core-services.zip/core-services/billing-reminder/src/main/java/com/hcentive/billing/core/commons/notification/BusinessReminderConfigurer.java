/**
 * 
 */
package com.hcentive.billing.core.commons.notification;

import java.util.Map;

/**
 * @author Kumar Sambhav Jain
 * 
 */
public interface BusinessReminderConfigurer {

	public Map<String, String> configuredReminders();
}
