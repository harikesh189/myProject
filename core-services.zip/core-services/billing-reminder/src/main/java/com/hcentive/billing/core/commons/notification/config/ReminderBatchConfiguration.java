/**
 * 
 */
package com.hcentive.billing.core.commons.notification.config;

import java.util.Map;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.notification.BusinessReminderConfigurer;
import com.hcentive.billing.core.commons.notification.BusinessRemindersBean;
import com.hcentive.billing.core.commons.notification.PropertyBasedReminderConfigurer;
import com.hcentive.billing.core.commons.notification.batch.BatchJobExecutionListener;
import com.hcentive.billing.core.commons.notification.batch.JobItemReaderListener;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;

/**
 * 
 * Spring configuration class for batch processing.
 * 
 * @author Kumar Sambhav Jain
 * 
 */
@Configuration
@PropertySources({
		@PropertySource("file:${baseDir}/config/properties/db.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties"),
		@PropertySource("file:${baseDir}/config/properties/amqp.properties") })
@ComponentScan("com.hcentive.billing.core")
@EnableJpaRepositories(basePackages = {
		"com.hcentive.billing.core.commons.persistence.repository",
		"com.hcentive.billing.core.commons.starter.persistence.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EntityScan("com.hcentive.billing")
@EnableMongoRepositories(basePackages = {"com.hcentive.billing.core.commons.starter.persistence.repository"})
@EnableAutoConfiguration
@EnableBatchProcessing
@EnableScheduling
public class ReminderBatchConfiguration {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ReminderBatchConfiguration.class, args);
	}

	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
	
	@Bean
	public BusinessRemindersBean businessReminderBean() {
		BusinessRemindersBean businessReminderBean = new BusinessRemindersBean();
		Map<String, String> eventQueryMap = businessReminderConfigurer()
				.configuredReminders();

		// add event name and its query here.
		// eventQueryMap.put("InvoiceReminder", "select i from Invoice i");

		businessReminderBean.setEventQueryMap(eventQueryMap);
		return businessReminderBean;
	}

	@Bean
	public BusinessReminderConfigurer businessReminderConfigurer() {
		return new PropertyBasedReminderConfigurer();
	}

	@Bean
	public ReminderJobScheduler reminderJobScheduler() {
		ReminderJobScheduler reminderJobScheduler = new ReminderJobScheduler();
		return reminderJobScheduler;
	}

	@Bean
	public BatchJobExecutionListener batchJobExecutionListener() {
		BatchJobExecutionListener batchJobExecutionListener = new BatchJobExecutionListener();
		return batchJobExecutionListener;
	}

	@Bean
	public JobItemReaderListener jobItemReaderListener() {
		return new JobItemReaderListener();
	}

}
