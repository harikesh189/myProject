package com.hcentive.billing.core.commons.notification.batch;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

public class ReminderAuditor implements ItemWriter<Object> {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(ReminderAuditor.class);

	@Override
	public void write(List<? extends Object> items) throws Exception {
		logger.debug("Reminder Auditor for object =  {}", items);
	}

}
