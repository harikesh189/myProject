/**
 * 
 */
package com.hcentive.billing.core.commons.notification.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemReadListener;

/**
 * @author Kumar Sambhav Jain
 * 
 */
public class JobItemReaderListener implements ItemReadListener<Object> {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(JobItemReaderListener.class);

	@Override
	public void beforeRead() {
		logger.debug("Before Reading Item from the Reader");
	}

	@Override
	public void afterRead(Object item) {
		logger.debug("Sucessfully Read item from reader = {}", item);

	}

	@Override
	public void onReadError(Exception ex) {
		logger.error(
				"\n\n\n\t !!Error while reading item from reader while trying to execute a batch job",
				ex);
		ex.printStackTrace();
	}

}
