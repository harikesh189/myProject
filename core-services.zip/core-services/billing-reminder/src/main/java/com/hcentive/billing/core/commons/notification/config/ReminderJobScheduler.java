/**
 * 
 */
package com.hcentive.billing.core.commons.notification.config;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.notification.BusinessRemindersBean;

/**
 * @author Kumar Sambhav Jain
 * 
 */
@Component
public class ReminderJobScheduler {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(ReminderJobScheduler.class);

	@Autowired
	private BusinessRemindersBean businessRemindersBean;

	@Autowired
	private JobLauncher jobLauncher;

	@Scheduled(cron = " ${batch.job.cronexp:59 59 23 * * ?}")
	public void runBatchJobs() throws JobExecutionAlreadyRunningException,
			JobRestartException, JobInstanceAlreadyCompleteException,
			JobParametersInvalidException {
		List<Job> jobs = businessRemindersBean.getJobs();
		for (Job job : jobs) {
			logger.debug("Running Scheduled Job  []", job.getName());
			jobLauncher.run(job, new JobParameters());
		}
	}
}
