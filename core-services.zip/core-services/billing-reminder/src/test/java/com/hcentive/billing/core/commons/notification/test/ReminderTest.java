/**
 * 
 */
package com.hcentive.billing.core.commons.notification.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.hcentive.billing.core.commons.notification.config.ReminderBatchConfiguration;

/**
 * 
 * @author Kumar Sambhav Jain
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ReminderBatchConfiguration.class })
public class ReminderTest {

	@Test
	public void test() {
		System.out.println("Will Send the reminder");
	}
}
