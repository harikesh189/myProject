#!/bin/sh
clear
echo "Launching Billing Reminder Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/billing-reminder -Xloggc:/var/log/wfm/billing-reminder/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar billing-reminder-1.0.RELEASE.jar --server.port=8153
