package com.hcentive.billing.core.commons.service.ebill.configuration.init;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Import;

import com.hcentive.billing.core.commons.service.comm.DefaultServiceRequestConsumer;
import com.hcentive.billing.core.commons.service.comm.ServiceComm;
import com.hcentive.billing.core.commons.service.comm.ServiceConfig;
import com.hcentive.billing.core.commons.service.comm.ServiceRequestConsumer;
import com.hcentive.billing.core.commons.service.ebill.configuration.handler.FetchConfigurationByKey;
import com.hcentive.billing.core.commons.service.ebill.configuration.support.ConfigurationPreLoader;
import com.hcentive.billing.core.commons.service.init.TenantConfiguration;

@Configuration
@Import(TenantConfiguration.class)
public class ConfigurationInterServiceCommConfig {

	@Bean
	public ServiceRequestConsumer fetchConfigurationByKeyRequestConsumer() {
		return new DefaultServiceRequestConsumer(
				fetchConfigurationByKeyService(), fetchConfigurationByKey());
	}

	@Bean
	public FetchConfigurationByKey fetchConfigurationByKey() {
		return new FetchConfigurationByKey();
	}

	@Bean
	public ServiceConfig fetchConfigurationByKeyService() {
		final ServiceConfig config = new ServiceConfig(
				ServiceComm.CONFIG_BY_KEY);
		return config;
	}

	@Bean
	public ServiceRequestConsumer fetchConfigurationByKeyAndSubSecRequestConsumer() {
		return new DefaultServiceRequestConsumer(
				fetchConfigurationByKeyAndSubSecService(),
				fetchConfigurationByKeyAndSubSec());
	}

	@Bean
	public FetchConfigurationByKey fetchConfigurationByKeyAndSubSec() {
		return new FetchConfigurationByKey();
	}

	@Bean
	public ServiceConfig fetchConfigurationByKeyAndSubSecService() {
		final ServiceConfig config = new ServiceConfig(
				ServiceComm.CONFIG_BY_KEY_AND_SUB_SEC);
		return config;
	}
	
	@Bean
	@DependsOn("configureTenantManager")
	public ConfigurationPreLoader configurationPreLoader(){
		return new ConfigurationPreLoader();
	}

}
