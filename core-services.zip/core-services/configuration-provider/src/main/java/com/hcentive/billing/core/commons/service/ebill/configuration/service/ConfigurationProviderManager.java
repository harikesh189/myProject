/**
 * 
 */
package com.hcentive.billing.core.commons.service.ebill.configuration.service;

import java.util.List;

import com.hcentive.billing.core.commons.configuration.api.Configuration;

/**
 * @author amit.agarwal
 * 
 */
public interface ConfigurationProviderManager {

	Object get(String key);

	Object get(String key, String subSection);

	void add(String key, Object data);

	void add(String key, String subSection, Object data);

	List<Configuration> getAllConfig();

}
