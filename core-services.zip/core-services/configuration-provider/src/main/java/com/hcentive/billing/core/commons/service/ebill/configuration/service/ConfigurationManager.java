package com.hcentive.billing.core.commons.service.ebill.configuration.service;

import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * @author uttam.tiwari
 * 
 **/
public interface ConfigurationManager {

	Collection<Configuration> fetchAllConfigurationProperties();

	void loadConfiguration(List<ConfigurationParameter> list);

	Page<Configuration> fetchConfiguration(String tenantId,
			SearchCriteria criteria);

	void removeConfiguration(List<ConfigurationParameter> configParametersList);

	Collection<Configuration> searchConfiguration(SearchCriteria searchCriteria);
}
