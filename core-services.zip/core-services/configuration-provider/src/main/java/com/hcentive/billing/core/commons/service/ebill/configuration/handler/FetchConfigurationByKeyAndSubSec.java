package com.hcentive.billing.core.commons.service.ebill.configuration.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.service.comm.RequestHandler;
import com.hcentive.billing.core.commons.service.comm.RequestProcessingException;
import com.hcentive.billing.core.commons.service.ebill.configuration.service.ConfigurationProviderManager;

public class FetchConfigurationByKeyAndSubSec implements RequestHandler {

	private static Logger LOGGER = LoggerFactory
			.getLogger(FetchConfigurationByKeyAndSubSec.class);

	@Autowired
	private ConfigurationProviderManager configProviderMngr;

	@Override
	public Object handle(Object... arguments) throws RequestProcessingException {

		if (arguments != null && arguments.length > 0) {
			LOGGER.debug(
					"fetching configuration for key: {} and subSection : {}",
					arguments[0], arguments[1]);
			final String key = (String) arguments[0];
			final String subSection = (String) arguments[1];
			return configProviderMngr.get(key, subSection);
		}

		return null;
	}

}
