package com.hcentive.billing.core.commons.service.ebill.configuration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.Operator;


public interface OperatorRepository extends JpaRepository<Operator, Long>{
 
	public List<Operator> findAll();
 
}
