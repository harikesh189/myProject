package com.hcentive.billing.core.commons.service.ebill.configuration.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.service.comm.RequestHandler;
import com.hcentive.billing.core.commons.service.comm.RequestProcessingException;
import com.hcentive.billing.core.commons.service.ebill.configuration.service.ConfigurationProviderManager;

public class FetchConfigurationByKey implements RequestHandler {

	private static Logger LOGGER = LoggerFactory
			.getLogger(FetchConfigurationByKey.class);

	@Autowired
	private ConfigurationProviderManager configProviderMngr;

	@Override
	public Object handle(Object... arguments) throws RequestProcessingException {

		if (arguments != null && arguments.length > 0) {
			LOGGER.debug("fetching configuration for key: {}", arguments[0]);
			final String key = (String) arguments[0];
			return configProviderMngr.get(key);
		}

		return null;
	}

}
