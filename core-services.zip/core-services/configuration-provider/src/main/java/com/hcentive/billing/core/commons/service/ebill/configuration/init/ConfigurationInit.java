package com.hcentive.billing.core.commons.service.ebill.configuration.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;

/**
 * Init class for the service.
 * 
 * @author uttam.tiwari
 * 
 */
@Configuration
@PropertySources({
		@PropertySource("file:${baseDir}/config/properties/db.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties"),
		@PropertySource("file:${baseDir}/config/properties/amqp.properties"),
		@PropertySource("file:${baseDir}/config/properties/mongodb.properties") })
@EnableMongoRepositories(basePackages = {"com.hcentive.billing.core.commons.starter.persistence.repository"})
@EnableJpaRepositories(basePackages = {
		"com.hcentive.billing.core.commons.service.ebill.configuration.repository",
		"com.hcentive.billing.core.commons.domain.util.reference.repository",
		"com.hcentive.billing.core.commons.starter.persistence.repository","com.hcentive.billing.core.commons.persistence.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EntityScan("com.hcentive.billing.core.commons")
@ComponentScan("com.hcentive.billing")
@EnableAutoConfiguration
public class ConfigurationInit {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ConfigurationInit.class);

	public static void main(String[] args) throws Exception {

		LOGGER.debug("Starting Configuration service for hcentive !!");

		SpringApplication.run(ConfigurationInit.class, args);

	}
	
	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}

}
