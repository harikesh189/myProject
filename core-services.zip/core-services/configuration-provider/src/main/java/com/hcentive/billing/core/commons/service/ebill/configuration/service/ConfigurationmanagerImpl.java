package com.hcentive.billing.core.commons.service.ebill.configuration.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.configuration.DTO.ConfigurationParameter;
import com.hcentive.billing.core.commons.service.ebill.configuration.domain.Configuration;
import com.hcentive.billing.core.commons.service.ebill.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * @author Uttam Tiwari
 */

/*
 * In this class we do the necessary transformation in input objects and call
 * actual service..
 */
@Component
public class ConfigurationmanagerImpl implements ConfigurationManager {

	@Autowired
	ConfigurationService configurationService;

	public Collection<Configuration> fetchAllConfigurationProperties() {
		return configurationService.fetchAllConfigurationProperties();
	}

	public void loadConfiguration(List<ConfigurationParameter> list) {
		List<Configuration> domainList = new ArrayList<Configuration>();
		for (ConfigurationParameter parameter : list) {
			domainList.add(ConfigurationUtil.getConfigurationDomain(parameter));
		}
		configurationService.loadConfiguration(domainList);
	}

	public Page<Configuration> fetchConfiguration(String tenantId,
			SearchCriteria criteria) {

		if (null != tenantId) {

			return configurationService.fetchConfiguration(tenantId, criteria);
		}

		return new PageImpl<Configuration>(Collections.EMPTY_LIST);
	}

	@Override
	public void removeConfiguration(
			List<ConfigurationParameter> configParametersList) {
		configurationService.removeConfig(configParametersList);

	}

	@Override
	public Collection<Configuration> searchConfiguration(
			SearchCriteria searchCriteria) {

		return configurationService.searchConfiguration(searchCriteria);
	}

}
