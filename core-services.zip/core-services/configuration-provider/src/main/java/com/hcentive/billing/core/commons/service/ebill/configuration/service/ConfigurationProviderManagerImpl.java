/**
 * 
 */
package com.hcentive.billing.core.commons.service.ebill.configuration.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.configuration.api.Configuration;
import com.hcentive.billing.core.commons.configuration.service.ConfigurationCacheManager;
import com.hcentive.billing.core.commons.configuration.service.api.ConfigurationAPIService;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.util.Permission;

/**
 * The Class ConfigurationProviderManagerImpl.
 * 
 * @author amit.agarwal
 */
@Component
public class ConfigurationProviderManagerImpl implements
		ConfigurationProviderManager {

	@Autowired
	ConfigurationAPIService configurationAPIService;

	@Autowired
	ConfigurationCacheManager cacheManager;

	private static final Logger logger = LoggerFactory
			.getLogger(ConfigurationProviderManagerImpl.class);

	@Override
	//@RequiresPermissions(value = Permission.FETCH_CONFIGURATIONS)
	public Object get(String key) {
		logger.debug("Fetching configuration from cache");
		Object data = cacheManager.loadFromCache(key);
		if (null == data) {
			logger.debug("No configuration found in cache for key : {} ", key);
			data = configurationAPIService.get(key);
			if (null != data) {
				logger.debug("Delegating call to cacheManager for adding configuration into cache");
				cacheManager.addToCache(key, data);
			} else {
				logger.debug(
						"No configuration found in database for key : {} ", key);
			}
		} else {
			logger.debug(
					"Configuration found in cache for key : {}  and data :{}",
					key, data);
		}
		return data;
	}

	@Override
	//@RequiresPermissions(value = Permission.FETCH_CONFIGURATIONS)
	public Object get(String key, String subSection) {
		logger.debug("Fetching configuration from cache");
		Object data = cacheManager.loadFromCache(key, subSection);
		if (null == data) {
			logger.debug(
					"No configuration found in cache for key : {} and subsection {}",
					key, subSection);
			data = configurationAPIService.get(key, subSection);
			if (null != data) {
				logger.debug("Delegating call to cacheManager for adding configuration into cache");
				cacheManager.addToCache(key, subSection, data);
			} else {
				logger.debug(
						"No configuration found in database for key : {} and subsection {}",
						key, subSection);
			}
		} else {
			logger.debug(
					"Configuration found in cache for key : {}  section : {} and data :{}",
					key, subSection, data);
		}
		return data;

	}

	@Override
	@RequiresPermissions(value = Permission.ADD_CONFIGURATIONS)
	public void add(String key, Object data) {
		logger.debug("Saving configuration");
		if (key != null && null != data) {
			configurationAPIService.add(key, data);
			logger.debug("Delegating call to cacheManager for adding configuration into cache");
			cacheManager.addToCache(key, data);
		} else {
			logger.debug(
					"Unable to save configuration with key {} and data {}",
					key, data);
		}
	}

	@Override
	@RequiresPermissions(value = Permission.ADD_CONFIGURATIONS)
	public void add(String key, String subSection, Object data) {
		if (key != null && null != subSection && null != data) {
			configurationAPIService.add(key, subSection, data);
			logger.debug("Delegating call to cacheManager for adding configuration into cache");
			cacheManager.addToCache(key, subSection, data);
		} else {
			logger.debug(
					"Unable to save configuration with key {} and subSection {} and data {}",
					key, subSection, data);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@RequiresPermissions(value = Permission.FETCH_CONFIGURATIONS)
	public List getAllConfig() {
		List configDataList = null;
		String tenantId = TenantUtil.getTenantId();
		if (null != tenantId) {
			logger.debug("Fetching configurations for tenant id : {}", tenantId);
			configDataList = cacheManager.loadFromCache(tenantId);
			if (null == configDataList
					|| (null != configDataList && configDataList.size() == 0)) {
				logger.debug(
						"No configuration found in cache for tenantId : {} ",
						tenantId);
				configDataList = new ArrayList();
				List<Configuration> configurationList = configurationAPIService
						.getAllConfig();
				if (null != configurationList) {
					logger.debug(
							"Configuration found in database for tenantId : {} ,  configuration list {}",
							tenantId, configurationList);
					for (Configuration config : configurationList) {
						configDataList.add(config.getData());
					}
					cacheManager.addToCache(tenantId, configDataList);
				} else {
					logger.debug(
							"No configuration found in database for tenantId : {} ",
							tenantId);
				}
			} else {
				logger.debug(
						"Configuration found in cache for tenantId : {} , configurations {} ",
						tenantId, configDataList);
			}
		} else {
			logger.debug("Tenant not found");
		}
		return configDataList;
	}
}
