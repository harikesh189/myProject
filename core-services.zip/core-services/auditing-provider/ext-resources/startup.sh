#!/bin/bash
clear
echo "Launching Audit Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/auditing-provider -Xloggc:/var/log/wfm/auditing-provider/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar auditing-provider-1.0.RELEASE.jar --server.port=8301