/**
 *
 */
package com.hcentive.billing.core.commons.archive.test;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.hcentive.billing.core.archival.DefaultArchiveService;
import com.hcentive.billing.core.commons.archive.handler.ArchiveHandler;
import com.hcentive.billing.core.commons.archive.handler.DefaultArchiveHandler;
import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.init.EventConfiguration;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.security.config.ConditionalSecurityConfig;
import com.hcentive.billing.core.commons.security.config.ConditionalSecurityConfig.ConfigureSecurityConfigurationManager;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;
import com.hcentive.billing.core.commons.service.event.PrePublishTenantIdEnricher;
import com.hcentive.billing.core.commons.service.init.BillingAutoConfiguration;
import com.hcentive.billing.core.commons.service.init.FilterConfiguration;
import com.hcentive.billing.core.commons.service.init.TenantConfiguration;
import com.hcentive.billing.core.commons.service.vendor.eclipselink.EclipseLinkAutoConfigure;
import com.hcentive.billing.core.commons.starter.persistence.repository.OperatorRepositoryBasedTenantProvider;
import com.hcentive.billing.core.commons.tenant.util.TenantManager;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.commons.batch.process.TenantProvider;

@Configuration
@PropertySources({
		@PropertySource("file:${baseDir}/config/properties/db.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties"),
		@PropertySource("file:${baseDir}/config/properties/mongodb.properties"),
		@PropertySource("file:${baseDir}/config/properties/amqp.properties") })
@ComponentScan(value = { "com.hcentive.billing.core.commons.archival.archive","com.hcentive.billing.wfm.remit" }, excludeFilters = { @ComponentScan.Filter(value = {
		Configuration.class, Service.class, Component.class }, type = FilterType.ANNOTATION) })
@EnableJpaRepositories(basePackages = { "com.hcentive.billing.reinstatement",
		"com.hcentive.billing.configuration.jpa.repository",
		"com.hcentive.billing.core.commons.starter.persistence.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EnableMongoRepositories(basePackages = { "com.hcentive.billing.core.commons.starter.persistence.repository","com.hcentive.billing.core.commons.service.ebill.audit.mongo.repository" })
@EntityScan({ "com.hcentive.billing.core.commons",
		"com.hcentive.billing.wfm.domain" })
@EnableAutoConfiguration(exclude = { ConditionalSecurityConfig.class,
		WebMvcAutoConfiguration.class, BillingAutoConfiguration.class,
		ConfigureSecurityConfigurationManager.class, TenantConfiguration.class,
		FilterConfiguration.class })
@Import({ EventConfiguration.class, EclipseLinkAutoConfigure.class })
public class ArchiveOperationTestConfig {

	@Bean
	public TenantManager tenantManager() {
		final TenantManager tenantManager = new TenantManager() {
			@Override
			public String getTenantId() {
				return "ARKANSA";
			}
		};
		TenantUtil.configure(tenantManager);
		return tenantManager;
	}

	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
	
	@Bean
	PrePublishTenantIdEnricher prePublishTenantIdEnricher() {
		return new PrePublishTenantIdEnricher();
	}
	
	@Bean
	public ArchiveHandler archiveHandler() {
		return new DefaultArchiveHandler();
	}

	@Bean
	public TenantProvider tenantProvider() {
		return new OperatorRepositoryBasedTenantProvider();
	}
	
	@Bean
	public DefaultArchiveService archiveService(){
		return new DefaultArchiveService();
	}

}
