package com.hcentive.billing.core.commons.archive.test;

import java.util.concurrent.locks.LockSupport;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.hcentive.billing.core.archival.DefaultArchiveService;
import com.hcentive.billing.core.commons.domain.DummyEntity;
import com.hcentive.billing.core.commons.domain.enumtype.AuditableOperation;
import com.hcentive.billing.core.commons.tenant.util.TenantManager;
import com.hcentive.billing.core.commons.vo.ProcessContext;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = { ArchiveOperationTestConfig.class })
public class TestArchiveOperation {
	
	@Autowired
	DefaultArchiveService archiveService;
	
	@Autowired
	private TenantManager tenantManager;
	
	@Before
	public void init() {
		ProcessContext.initialize("", "", tenantManager.getTenantId(), "", null,"");
	}

	@Test
	public void test() {
		DummyEntity a = new DummyEntity(12L);
		a.setArchived(true);
		archiveService.archive(a, AuditableOperation.SAVE);
		LockSupport.parkNanos(10000000000L);
	}

}
