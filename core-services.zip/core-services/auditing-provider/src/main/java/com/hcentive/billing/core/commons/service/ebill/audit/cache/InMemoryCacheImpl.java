package com.hcentive.billing.core.commons.service.ebill.audit.cache;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.audit.domain.AuditMsg;
import com.hcentive.billing.core.commons.service.ebill.audit.jpa.repository.AuditMsgRepository;

@Component
public class InMemoryCacheImpl implements AuditCache, InitializingBean {

	private static final Logger logger = LoggerFactory
			.getLogger(InMemoryCacheImpl.class);

	@Autowired
	private AuditMsgRepository auditMsgRepository;

	final Map<LookUpKey, String> auditMsgCache = new HashMap<LookUpKey, String>(
			20);

	@Override
	public String getAuditMsg(String tenant, String key) {
		logger.debug("fetch tenant key from cache. tenant::" + tenant
				+ " key :" + key);
		final LookUpKey lookUpKey = new LookUpKey(tenant, key);
		return auditMsgCache.get(lookUpKey);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.debug("loading all audit keys in Inmemeory cache");
		Iterable<AuditMsg> auditIterable = auditMsgRepository.findAll();
		for (AuditMsg item : auditIterable) {
			auditMsgCache.put(new LookUpKey(item.getTenantId(), item.getKey()),
					item.getMsg());
		}
		logger.debug("Audit keys from DB are successfully loaded in cache. Total keys:"
				+ auditMsgCache.size());

	}

}

class LookUpKey {

	private String tenant;
	private String key;

	public LookUpKey(String tenant, String key) {
		this.tenant = tenant;
		this.key = key;
	}

	public String getTenant() {
		return tenant;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		result = prime * result + ((tenant == null) ? 0 : tenant.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LookUpKey other = (LookUpKey) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		if (tenant == null) {
			if (other.tenant != null)
				return false;
		} else if (!tenant.equals(other.tenant))
			return false;
		return true;
	}

}
