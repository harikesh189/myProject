package com.hcentive.billing.core.commons.service.ebill.audit.jpa.repository;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.service.ebill.audit.domain.AuditMsg;


@Transactional
public interface AuditMsgRepository extends JpaRepository<AuditMsg, Long> {

	Collection<AuditMsg> findByTenantIdAndKey(String role, String type);

}
