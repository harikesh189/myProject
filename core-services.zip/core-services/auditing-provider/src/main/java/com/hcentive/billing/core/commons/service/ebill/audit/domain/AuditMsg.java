package com.hcentive.billing.core.commons.service.ebill.audit.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.TenantAware;

@Entity
@Table(name = "Audit_Msg")
public class AuditMsg extends BaseEntity implements TenantAware {

	/**
	 *
	 */
	private static final long serialVersionUID = -3023039706473402616L;

	@Column(name = "tenant_id", insertable = false, updatable = false)
	@Access(AccessType.FIELD)
	private String tenantId;

	@Column(name = "key")
	@Access(AccessType.FIELD)
	private String key;

	@Column(name = "msg")
	@Access(AccessType.FIELD)
	private String msg;

	@Override
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
