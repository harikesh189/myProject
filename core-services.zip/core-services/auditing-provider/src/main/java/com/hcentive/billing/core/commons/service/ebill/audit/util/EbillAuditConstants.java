package com.hcentive.billing.core.commons.service.ebill.audit.util;

/**
 * Ebill audit constants file
 * 
 * @author Ankit.Garg
 * 
 */
public interface EbillAuditConstants {

	public static final String USER = "USER";
	public static final String AUDIT_EVENT_TYPE = "AUDIT_EVENT_TYPE";
	public static final String AUDIT_TYPE = "AUDIT_TYPE";
	public static final String AUDIT_KEY = "AUDIT_KEY";
	public static final String TENANT_TYPE = "TENANT_TYPE";

}
