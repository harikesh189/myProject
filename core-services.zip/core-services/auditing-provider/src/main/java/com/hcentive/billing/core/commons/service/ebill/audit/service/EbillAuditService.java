package com.hcentive.billing.core.commons.service.ebill.audit.service;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.service.ebill.audit.domain.Audit;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface EbillAuditService {

	String getAuditMessage(String tenant, String key);


	Page<Audit> getAllAuditsByCustomerId(String customerId,
			SearchCriteria searchCriteria);

	Page<Audit> getAdminAuditsByCustomerId(String customerId,
			SearchCriteria searchCriteria);
	
	Page<Audit> getAudits(final SearchCriteria searchCriteria);
	
	<T> void saveAuditData(final Audit<T> audit);
	
}
