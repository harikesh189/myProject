package com.hcentive.billing.core.commons.service.ebill.audit.message;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;

@Component
public class MessageEnumStringResolver implements RefMessageStringResolver<AuditMessageDefinition> {

	@Override
	public String resolveMessageString(AuditMessageDefinition messageId) {
		return messageId.getMessage();
	}

	@Override
	public boolean canHandle(Object messageId) {
		return messageId instanceof AuditMessageDefinition;
	}

	
	
}
