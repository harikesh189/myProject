/**
 *
 */
package com.hcentive.billing.core.commons.archive.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.persistence.dto.AuditableEntityWrapper;
import com.hcentive.billing.core.commons.service.ebill.audit.mongo.repository.AuditableEntityWrapperRepository;

/**
 * @author uttam.tiwari
 *
 */
@Component
public class DefaultArchiveHandler implements ArchiveHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultArchiveHandler.class);

	@Autowired
	AuditableEntityWrapperRepository auditableEntityWrapperRepository;

	@Override
	@EventSubscription(eventName = EventType.ARCHIVING)
	public void handle(final AuditableEntityWrapper wrapper) {
		try {
			auditableEntityWrapperRepository.save(wrapper);
		} catch (final Exception e) {
			LOGGER.error("Failed to persist archive record", e);
		}

	}

}
