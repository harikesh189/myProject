package com.hcentive.billing.core.commons.service.ebill.audit.manager;

import java.io.Serializable;

import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.audit.AuditLog;
import com.hcentive.billing.core.commons.domain.audit.AuditMessage;
import com.hcentive.billing.core.commons.service.ebill.audit.domain.Audit;
import com.hcentive.billing.core.commons.service.ebill.audit.dto.AuditRecord;
import com.hcentive.billing.core.commons.service.ebill.audit.message.MessageBuilder;
import com.hcentive.billing.core.commons.service.ebill.audit.message.MessageBuilderFactory;
import com.hcentive.billing.core.commons.service.ebill.audit.service.EbillAuditService;
import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.core.commons.vo.ProcessContextMetaDataConstants;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * Audit Manager for converting map into audit domain object and pass it to
 * service
 *
 * @author Ankit.Garg
 *
 */
@Component
public class AuditManagerImpl implements AuditManager {

	private static final Logger logger = LoggerFactory.getLogger(AuditManagerImpl.class);

	@Autowired
	private EbillAuditService ebillAuditService;
	
	@Autowired
	private MessageBuilderFactory builderFactory;
	
	@Override
	@RequiresPermissions(value =Permission.ADD_AUDIT)
	public <T extends Serializable> void saveAuditData(final AuditLog<T> auditRecord) {
		logger.debug("Calling audit service for saving the data");

		final Audit<T> audit = prepareAuditObject(auditRecord);
		ebillAuditService.saveAuditData(audit);

		logger.debug("Returning from audit service after saving the data");

	}

	/**
	 *
	 * this method will make the domain level audit object
	 */
	private <T extends Serializable> Audit<T> prepareAuditObject(final AuditLog<T> auditRecord) {
		logger.debug("preparing audit object");
		final Audit<T> audit = new Audit<T>();
		audit.setAuditTime(auditRecord.activityTime());
		audit.setAuditType(auditRecord.type());
		audit.setUserId(auditRecord.userId());
		//audit.setMessage(fetchAuditMessage(auditRecord));
		audit.setMessage(getMessage(auditRecord));
		audit.setProcessId(auditRecord.processId());
		audit.setUserId(auditRecord.userId());
		audit.setUserName(auditRecord.userName());
		audit.setAuditData(auditRecord.auditData());
		audit.setStatus(auditRecord.status());
		addRequestSourceIp(audit,auditRecord);
		return audit;
	}

	private <T extends Serializable> void addRequestSourceIp(
			final Audit<T> audit,final AuditLog<T> auditLog) {
		if(auditLog instanceof AuditRecord){
			final String requestSourceIp = ((AuditRecord)auditLog).getProcessContext().getMetaData().get(ProcessContextMetaDataConstants.IP);
			if( requestSourceIp != null){
				audit.setRequestSourceIp(requestSourceIp);
			}
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private <T extends Serializable> String getMessage(AuditLog<T> log) {
		String strMsg = null;
		MessageBuilder messageBuilder = 
				builderFactory.getMessageBuilder(log.message());
		if (messageBuilder != null) {
			strMsg = messageBuilder.buildMessage(log.message());
		}
		return strMsg;
	}

	@Override
	@RequiresPermissions(value =Permission.READ_AC_ACTIVITY)
	public Page<Audit> getAuditsByCustomerId(String customerId,
			SearchCriteria searchCriteria) {
		return getAudits(customerId, searchCriteria);
	}

	private Page<Audit> getAudits(String customerId,
			SearchCriteria searchCriteria) {
		logger.debug("Calling audit service for fetching account activity list ");
		Page<Audit> auditPage=ebillAuditService.getAllAuditsByCustomerId(customerId, searchCriteria);
		logger.debug("returning back from  audit service by fetching account activity list ");
		return auditPage;
	}

	@Override
	@RequiresPermissions(value =Permission.ADMIN_READ_AC_ACTIVITY)
	public Page<Audit> getAdminAuditsByCustomerId(String customerId,
			SearchCriteria searchCriteria) {
		return getAudits(customerId, searchCriteria);
	}
	
	@Override
	@RequiresPermissions(value =Permission.ADMIN_READ_AC_ACTIVITY)
	public Page<Audit> getAudits(final SearchCriteria searchCriteria){
		return this.ebillAuditService.getAudits(searchCriteria);
	}

}