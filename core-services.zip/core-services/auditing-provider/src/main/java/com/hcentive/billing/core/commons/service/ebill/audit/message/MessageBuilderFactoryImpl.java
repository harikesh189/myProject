package com.hcentive.billing.core.commons.service.ebill.audit.message;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.core.commons.domain.audit.AuditMessage;

@SuppressWarnings("rawtypes")
@Component
public class MessageBuilderFactoryImpl extends SpringBackedAbstractFactory<MessageBuilder> implements MessageBuilderFactory {

	@SuppressWarnings("unchecked")
	@Override
	public MessageBuilder<? extends AuditMessage> getMessageBuilder(AuditMessage msg) {
		
		for (MessageBuilder<? extends AuditMessage> builder : registeredInstances()) {
			if (builder.canHandle(msg)) {
				return builder;
			}
		}

		throw new IllegalStateException("No message builder found for msg: " + msg);
	}

	@Override
	protected Class<MessageBuilder> lookupForType() {
		return MessageBuilder.class;
	}

}
