package com.hcentive.billing.core.commons.service.ebill.audit.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hcentive.billing.core.commons.service.ebill.audit.domain.Audit;
import com.hcentive.billing.core.commons.service.ebill.audit.manager.AuditManager;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

@RestController
@RequestMapping("/account-statements")
public class AuditingProviderServiceController {

	@Autowired
	AuditManager auditManager;

	@RequestMapping(value = "/customers/{customerId}", method = RequestMethod.POST, produces = "application/json")
	public Page<Audit> getAccountActivity(@PathVariable final String customerId, @RequestBody final SearchCriteria searchCriteria) {
		return this.auditManager.getAuditsByCustomerId(customerId, searchCriteria);
		
	}

	@RequestMapping(value = "/admin/customers/{customerId}", method = RequestMethod.POST, produces = "application/json")
	public Page<Audit> getAccountActivityForAdmin(@PathVariable final String customerId, @RequestBody final SearchCriteria searchCriteria) {
		return this.auditManager.getAdminAuditsByCustomerId(customerId, searchCriteria);
	}
	
	@RequestMapping(value = "/admin/audits", method = RequestMethod.POST, produces = "application/json")
	public Page<Audit> getAudits(@RequestBody final SearchCriteria searchCriteria) {
		return this.auditManager.getAudits(searchCriteria);
	}

}
