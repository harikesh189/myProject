package com.hcentive.billing.core.commons.service.ebill.audit.manager;

import java.io.Serializable;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.domain.audit.AuditLog;
import com.hcentive.billing.core.commons.service.ebill.audit.domain.Audit;
import com.hcentive.billing.core.commons.service.ebill.audit.dto.AuditRecord;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface AuditManager {

	public <T extends Serializable> void saveAuditData(AuditLog<T> auditRecord);
	
	public Page<Audit> getAuditsByCustomerId(String customerId, SearchCriteria searchCriteria); 
	
	public Page<Audit> getAdminAuditsByCustomerId(String customerId, SearchCriteria searchCriteria);
	
	Page<Audit> getAudits(final SearchCriteria searchCriteria);
}
