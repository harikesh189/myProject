package com.hcentive.billing.core.commons.service.ebill.audit.message;

import com.hcentive.billing.core.commons.domain.audit.AuditMessage;

public interface MessageBuilder<T extends AuditMessage> {

	String buildMessage(T message);
	
	boolean canHandle(AuditMessage msg);
	
}
