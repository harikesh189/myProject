package com.hcentive.billing.core.commons.service.ebill.audit.manager;

import java.io.Serializable;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.audit.ActivityLog;
import com.hcentive.billing.core.commons.domain.audit.AuditLog;

@Component
public class ActivityLogManagerImpl implements ActivityLogManager {

	@Autowired 
	private ActivityLogCollectionResolver collectionResolver;
	
	@Autowired
	private AuditManager auditManager;
	
	@Autowired 
	private MongoOperations mongoTemplate;
	
	public ActivityLogManagerImpl() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends Serializable> void saveActivityLog(ActivityLog<T> log) {
		Collection<String> collections = collectionResolver.resolveLogCollections(log.category());
		for (String coll : collections) {
			mongoTemplate.save(log, coll);
		}
		
		if (log instanceof AuditLog) {
			auditManager.saveAuditData((AuditLog) log);
		}
		
	}

}