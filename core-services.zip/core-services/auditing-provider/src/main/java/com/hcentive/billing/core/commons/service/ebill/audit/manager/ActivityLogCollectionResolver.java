package com.hcentive.billing.core.commons.service.ebill.audit.manager;

import java.util.Collection;

public interface ActivityLogCollectionResolver {

	Collection<String> resolveLogCollections(String activityLogCategory);
	
}
