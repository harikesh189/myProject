package com.hcentive.billing.core.commons.service.ebill.audit.message;

import com.hcentive.billing.core.commons.domain.audit.AuditMessage;

public interface MessageBuilderFactory {

	MessageBuilder<?> getMessageBuilder(AuditMessage msg);
	
}
