package com.hcentive.billing.core.commons.service.ebill.audit.mongo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.service.ebill.audit.domain.Audit;

/**
 * 
 * Ebill Audit Repository for saving audit object
 * 
 * @author Ankit.Garg
 * 
 */
//@Repository
public interface EbillAuditRepository extends MongoRepository<Audit, String> {

	@Query("{'auditData.beIdentity' : ?0,  'auditType' : { $in: ['INBOUND_PAYMENT','PAYMENT', 'INVOICE','MONEY_TRANSFER','PREFERENCE','NOTIFICATION','DELINQUENCY','REINSTATEMENT'] } }")
	Page<Audit> findByAuditDataBeIdentityAndAuditTypeIn(String beIdentity, List<AuditEventType> auditypeList ,Pageable pageable);

	@Query(value = "{'auditData.beIdentity' : ?0,  'auditType' : { $in: ['INBOUND_PAYMENT','PAYMENT', 'INVOICE','MONEY_TRANSFER','PREFERENCE','NOTIFICATION','DELINQUENCY','REINSTATEMENT'] } }", count = true)
	public long countByAuditDataBeIdentityAndAuditTypeIn(String customerId,List<AuditEventType> auditypeList );

}
