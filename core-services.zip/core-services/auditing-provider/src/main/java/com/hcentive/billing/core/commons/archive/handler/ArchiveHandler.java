/**
 * 
 */
package com.hcentive.billing.core.commons.archive.handler;

import com.hcentive.billing.core.commons.persistence.dto.AuditableEntityWrapper;

/**
 * @author uttam.tiwari
 * 
 */
public interface ArchiveHandler {

	void handle(final AuditableEntityWrapper wrapper);
}
