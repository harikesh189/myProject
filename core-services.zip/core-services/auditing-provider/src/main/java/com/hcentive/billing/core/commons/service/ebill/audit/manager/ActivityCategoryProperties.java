package com.hcentive.billing.core.commons.service.ebill.audit.manager;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("audit.activity.log")
public class ActivityCategoryProperties {
	
	private Map<String, String> category = new HashMap<String, String>();

	public Map<String, String> getCategory() {
		return category;
	}

	public void setCategory(Map<String, String> category) {
		this.category = category;
	}

}
