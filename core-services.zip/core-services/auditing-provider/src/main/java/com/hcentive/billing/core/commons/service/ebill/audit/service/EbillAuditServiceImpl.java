package com.hcentive.billing.core.commons.service.ebill.audit.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.commons.mongo.repository.MongoFilterSupportRepository;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.converter.PageableTransformer;
import com.hcentive.billing.core.commons.service.ebill.audit.cache.AuditCache;
import com.hcentive.billing.core.commons.service.ebill.audit.domain.Audit;
import com.hcentive.billing.core.commons.service.ebill.audit.domain.AuditMsg;
import com.hcentive.billing.core.commons.service.ebill.audit.jpa.repository.AuditMsgRepository;
import com.hcentive.billing.core.commons.service.ebill.audit.mongo.repository.EbillAuditRepository;
import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * 
 * Ebill Audit service impl for saving the audit object
 * 
 * @author Ankit.Garg
 * 
 */

@Component
@Transactional
public class EbillAuditServiceImpl implements EbillAuditService {

	@Autowired
	private EbillAuditRepository ebillAuditRepository;

	@Autowired
	private AuditMsgRepository auditMsgRepository;

	@Autowired
	private MongoFilterSupportRepository mongoFilterRepository;
	

	@Autowired
	private AuditCache auditCache;

	private static final Logger logger = LoggerFactory
			.getLogger(EbillAuditServiceImpl.class);

	/*
	 * (non-Javadoc) Passes the audit object to repository
	 * 
	 * @see com.hcentive.billing.core.commons.service.ebill.audit.service.
	 * EbillAuditService
	 * #saveAuditData(com.hcentive.billing.core.commons.domain.Audit)
	 */
	@Override
	@RequiresPermissions(value = Permission.MANAGE_AUDIT)
	public <T> void saveAuditData(final Audit<T> audit) {
		logger.debug("Calling repository for saving the audit info");
		ebillAuditRepository.save(audit);
		logger.debug("Returning from audit repository");
	}

	@Override
	public String getAuditMessage(final String tenant, final String key) {
		logger.debug("fetching audit msg for tenenat: " + tenant + " and key :"
				+ key);
		final String auditMsg = auditCache.getAuditMsg(tenant, key);
		if (null != auditMsg)
			return auditMsg;
		logger.debug("No value found in cache for tenenat: " + tenant
				+ " and key :" + key);
		Collection<AuditMsg> auditMsgs = auditMsgRepository
				.findByTenantIdAndKey(tenant, key);
		if (null != auditMsgs && !auditMsgs.isEmpty()) {
			AuditMsg msg = auditMsgs.iterator().next();
			logger.debug("Value fetched fromm DB for tenenat: " + tenant
					+ " and key :" + key);
			return null != msg ? msg.getMsg() : null;
		}
		return auditMsg;

	}

	@Override
	public Page<Audit> getAllAuditsByCustomerId(String customerId,
			SearchCriteria searchCriteria) {
		return getAuditsForCustomerId(customerId,searchCriteria);
	}
	


	@Override
	public Page<Audit> getAdminAuditsByCustomerId(String customerId,
			SearchCriteria searchCriteria) {
		return getAuditsForCustomerId(customerId,searchCriteria);
	}
	

	private Page<Audit> getAuditsForCustomerId(String customerId,
			SearchCriteria searchCriteria) {
		Pageable pageable = null;
		
		
		pageable = PageableTransformer.INSTANCE.transform(searchCriteria.getPageRequestCriteria());
		
		
		logger.debug("calling ebillAuditRepository for finding total count of audit list");
		List<AuditEventType> list = new ArrayList<AuditEventType>();
		
		list.add(AuditEventType.INVOICE);
		list.add(AuditEventType.NOTIFICATION);
		list.add(AuditEventType.PAYMENT);
		list.add(AuditEventType.INBOUND_PAYMENT);
		list.add(AuditEventType.PREFERENCE);
		list.add(AuditEventType.MONEY_TRANSFER);
		list.add(AuditEventType.DELINQUENCY);
		list.add(AuditEventType.REINSTATEMENT);
		
		long count = ebillAuditRepository.countByAuditDataBeIdentityAndAuditTypeIn(customerId,list);
		logger.debug("total count of audit list: " + count);
		if(count<=0){
			// No Content found
			return null;
		}
		
		logger.debug("calling ebillAuditRepository for finding  audit list on basis of customer id");
		
		
		final Page<Audit> page = new PageImpl<Audit>(this.ebillAuditRepository.findByAuditDataBeIdentityAndAuditTypeIn(customerId,list ,pageable).getContent(), pageable,count);
		logger.debug("fetched list of audit");
		//final Page<Audit> pageResult = new PageImpl<>(list, pageable, totalCount);
		return page;
	}

	@Override
	public Page<Audit> getAudits(final SearchCriteria searchCriteria){
		return this.mongoFilterRepository.findByFilterCriteria(Audit.class, searchCriteria);
	}
	
}
