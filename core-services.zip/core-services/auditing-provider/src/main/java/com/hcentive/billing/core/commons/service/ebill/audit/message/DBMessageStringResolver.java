package com.hcentive.billing.core.commons.service.ebill.audit.message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.audit.service.EbillAuditService;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

@Component
public class DBMessageStringResolver implements RefMessageStringResolver<String> {

	@Autowired
	private EbillAuditService ebillAuditService;
	
	@Override
	public String resolveMessageString(String messageId) {
		return ebillAuditService.getAuditMessage(TenantUtil.getTenantId(), messageId);
	}

	@Override
	public boolean canHandle(Object messageId) {
		return messageId instanceof String;
	}

}
