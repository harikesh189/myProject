package com.hcentive.billing.core.commons.service.ebill.audit.domain;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.ExternalIdAware;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.vo.DateTime;

@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_audit")
public class Audit<T> implements Serializable, ExternalIdAware {

	/**
	 *
	 */
	private static final long serialVersionUID = 2831893379747305938L;

	@Id
	private String id;
	
	private String externalId;

	private String userId;

	private AuditEventType auditType;

	private String message;

	private DateTime auditTime;

	private String processId;
	
	private String userName;
	
	private String requestSourceIp = "Not-Applicable";
	
	private AuditWorkStatus status;
	
	public AuditWorkStatus getStatus() {
		return status;
	}

	public void setStatus(AuditWorkStatus status) {
		this.status = status;
	}

	private T auditData;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public DateTime getAuditTime() {
		return new DateTime(this.auditTime.getDate());
	}

	public void setAuditTime(DateTime auditTime) {
		this.auditTime = auditTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public AuditEventType getAuditType() {
		return auditType;
	}

	public void setAuditType(AuditEventType auditType) {
		this.auditType = auditType;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public T getAuditData() {
		return auditData;
	}

	public void setAuditData(T auditData) {
		this.auditData = auditData;
	}

	@Override
	public String getExternalId() {
		return externalId;
	}

	@Override
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getRequestSourceIp() {
		return requestSourceIp;
	}

	public void setRequestSourceIp(String requestSourceIp) {
		this.requestSourceIp = requestSourceIp;
	}
	
}
