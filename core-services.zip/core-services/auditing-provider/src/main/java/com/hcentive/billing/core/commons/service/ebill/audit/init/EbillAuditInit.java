package com.hcentive.billing.core.commons.service.ebill.audit.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.service.ebill.audit.manager.ActivityCategoryProperties;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;

/**
 * Init class for ebill audit service
 *
 * @author Ankit.Garg
 *
 */

@Configuration
@PropertySources({ @PropertySource("file:${baseDir}/config/properties/db.properties"), @PropertySource("file:${baseDir}/config/properties/mongodb.properties"),
        @PropertySource("file:${baseDir}/config/properties/app.properties"), @PropertySource("file:${baseDir}/config/properties/amqp.properties"),
        @PropertySource("file:${baseDir}/config/properties/security.properties"),
        @PropertySource("file:${baseDir}/config/properties/audit.properties") })
@EnableJpaRepositories(basePackages = { "com.hcentive.billing.core.commons.service.ebill.audit.jpa",
        "com.hcentive.billing.core.commons.starter.persistence.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EnableMongoRepositories(basePackages = {"com.hcentive.billing.core.commons.service.ebill.audit.mongo","com.hcentive.billing.core.commons.archive.repository","com.hcentive.billing.core.commons.starter.persistence.repository"})
@EntityScan("com.hcentive.billing.core.commons")
@ComponentScan({ "com.hcentive.billing", "com.hcentive.billing.commons.mongo" })
@EnableAutoConfiguration
@EnableConfigurationProperties(ActivityCategoryProperties.class)
public class EbillAuditInit {

	private static final Logger LOGGER = LoggerFactory.getLogger(EbillAuditInit.class);

	/**
	 * Init method for ebill audit service
	 *
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		LOGGER.debug("Starting ebill audit service for hcentive !!");

		SpringApplication.run(EbillAuditInit.class, args);

		LOGGER.debug("Ending ebill audit service for hcentive !!");

	}

	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
}
