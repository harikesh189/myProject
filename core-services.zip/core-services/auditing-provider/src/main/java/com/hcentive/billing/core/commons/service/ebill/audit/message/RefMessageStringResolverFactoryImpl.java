package com.hcentive.billing.core.commons.service.ebill.audit.message;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.core.commons.domain.audit.MessageReference;

@SuppressWarnings("rawtypes")
@Component
public class RefMessageStringResolverFactoryImpl extends SpringBackedAbstractFactory<RefMessageStringResolver> implements RefMessageStringResolverFactory {

	@Override
	public RefMessageStringResolver getResolver(MessageReference msgRef) {
		for (RefMessageStringResolver resolver : registeredInstances()) {
			if (resolver.canHandle(msgRef.getMessageId())) {
				return resolver;
			}
		}
		throw new IllegalStateException("No message reference resolver found for message id: " + msgRef.getMessageId());
	}

	@Override
	protected Class<RefMessageStringResolver> lookupForType() {
		return RefMessageStringResolver.class;
	}

}
