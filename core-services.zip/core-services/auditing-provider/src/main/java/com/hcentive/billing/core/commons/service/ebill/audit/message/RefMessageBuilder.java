package com.hcentive.billing.core.commons.service.ebill.audit.message;

import org.apache.commons.lang.text.StrSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.audit.AuditMessage;
import com.hcentive.billing.core.commons.domain.audit.MessageReference;

@Component
public class RefMessageBuilder implements MessageBuilder<MessageReference<?>> {

	@Autowired
	private RefMessageStringResolverFactory factory;
	
	@Override
	public String buildMessage(MessageReference<?> message) {
		return fetchAuditMessage(message);
	}
	
	/**
	 * this method will be convert the message returned from configuation
	 * service into the message that will be saved into db
	 *
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String fetchAuditMessage(final MessageReference<?> msgRef) {
		
		RefMessageStringResolver msgStrResolver = factory.getResolver(msgRef);
		String msgStr = msgStrResolver.resolveMessageString(msgRef.getMessageId());
		
		final StrSubstitutor strSubstitutor = new StrSubstitutor(msgRef.getArguments());
		return strSubstitutor.replace(msgStr);
	}

	@Override
	public boolean canHandle(AuditMessage msg) {
		return msg instanceof MessageReference;
	}

}
