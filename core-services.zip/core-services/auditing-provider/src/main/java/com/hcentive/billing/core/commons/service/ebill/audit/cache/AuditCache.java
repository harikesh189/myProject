package com.hcentive.billing.core.commons.service.ebill.audit.cache;

public interface AuditCache {

	String getAuditMsg(final String tenant, final String key);

}
