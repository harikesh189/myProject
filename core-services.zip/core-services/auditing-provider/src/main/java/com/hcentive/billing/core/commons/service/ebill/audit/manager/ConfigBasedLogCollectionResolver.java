package com.hcentive.billing.core.commons.service.ebill.audit.manager;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.audit.handler.AuditUtil;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

@Component
public class ConfigBasedLogCollectionResolver implements ActivityLogCollectionResolver {

	private static final String ACTIVITY_LOG_COLLECTIONS = "ACTIVITY_LOG_COLL_";

	@Autowired
	private ActivityCategoryProperties activityCategoryProperties;
	
	@SuppressWarnings("unchecked")
	@Override
	public Collection<String> resolveLogCollections(String activityLogCategory) {
		
		Collection<String> resolvedNames = new ArrayList<>();
		
		if(activityCategoryProperties != null && activityCategoryProperties.getCategory() != null && activityCategoryProperties.getCategory().containsKey(activityLogCategory)){
			resolvedNames.add(tenantAwareCollectionName(activityCategoryProperties.getCategory().get(activityLogCategory)));	
		}
		
		
/*		Object collNames = ConfigurationUtil.get(
				ACTIVITY_LOG_COLLECTIONS + activityLogCategory.toUpperCase());
		
		if (collNames != null) {
			if (collNames instanceof Collection) {
				Collection<String> collNameList = (Collection<String>) collNames;
				for (String collNm : collNameList) {
					resolvedNames.add(tenantAwareCollectionName(collNm));
				}
			}
		}
*/		
		return resolvedNames;
	}
	
	private String tenantAwareCollectionName(String collName) {
		String tenantId = TenantUtil.getTenantId();
		return tenantId + AuditUtil.ACTIVITY + collName;
	}

}
