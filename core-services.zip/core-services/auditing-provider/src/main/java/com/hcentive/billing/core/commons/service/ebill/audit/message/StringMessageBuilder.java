package com.hcentive.billing.core.commons.service.ebill.audit.message;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.audit.AuditMessage;
import com.hcentive.billing.core.commons.domain.audit.StringMessage;

@Component
public class StringMessageBuilder implements MessageBuilder<StringMessage> {


	@Override
	public String buildMessage(StringMessage message) {
		return message.getMessage();
	}

	@Override
	public boolean canHandle(AuditMessage msg) {
		return msg instanceof StringMessage;
	}

}
