package com.hcentive.billing.core.commons.service.ebill.audit.message;

public interface RefMessageStringResolver<T> {

	String resolveMessageString(T messageId);
	
	boolean canHandle(Object messageId);
	
}
