package com.hcentive.billing.core.commons.service.ebill.audit.handlers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.audit.ActivityLog;
import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.service.ebill.audit.dto.AuditRecord;
import com.hcentive.billing.core.commons.service.ebill.audit.manager.ActivityLogManager;
import com.hcentive.billing.core.commons.service.ebill.audit.manager.AuditManager;

/**
 * Audit Event handler Class
 * 
 * @author Ankit.Garg
 */
@Component
public class EbillAuditEventHandlers {

	private static final Logger logger = LoggerFactory
			.getLogger(EbillAuditEventHandlers.class);

	@Autowired
	private AuditManager auditManager;
	
	@Autowired
	private ActivityLogManager activityLogManager;

	/**
	 * Listens to EBILL_AUDIT_EVENT and passes the audit map to manager
	 * 
	 * @param variable
	 *            number of string as key pair values
	 */
	@EventSubscription(eventName = EventType.EBILL_AUDIT_EVENT)
	public void saveAuditInfo(AuditRecord auditRecord) {

		logger.debug("Calling audit manager for saving audit data");
		auditManager.saveAuditData(auditRecord);
		logger.debug("Audit Data Saved");
	}

	
	@EventSubscription(eventName = EventType.ACTIVITY_LOG_EVENT)
	public void handleActivityLogEvent(ActivityLog activityLog) {
		logger.debug("Calling activity log manager for saving activity log");
		activityLogManager.saveActivityLog(activityLog);
		logger.debug("Activity Log Saved");
	}
	
}
