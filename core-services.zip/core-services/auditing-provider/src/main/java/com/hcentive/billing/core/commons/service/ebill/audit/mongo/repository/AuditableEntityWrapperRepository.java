package com.hcentive.billing.core.commons.service.ebill.audit.mongo.repository;

import java.io.Serializable;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hcentive.billing.core.commons.persistence.dto.AuditableEntityWrapper;

public interface AuditableEntityWrapperRepository extends MongoRepository<AuditableEntityWrapper, Serializable> {

}
