package com.hcentive.billing.core.commons.service.ebill.audit.message;

import com.hcentive.billing.core.commons.domain.audit.MessageReference;

public interface RefMessageStringResolverFactory {

	@SuppressWarnings("rawtypes")
	RefMessageStringResolver getResolver(MessageReference msgRef);
	
}
