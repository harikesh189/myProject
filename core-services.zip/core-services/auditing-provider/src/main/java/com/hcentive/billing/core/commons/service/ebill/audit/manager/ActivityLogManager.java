package com.hcentive.billing.core.commons.service.ebill.audit.manager;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.audit.ActivityLog;

public interface ActivityLogManager {

	<T extends Serializable> void saveActivityLog(ActivityLog<T> log);

}
