#!/bin/bash
clear
echo "Launching Security provider Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/security-provider-bg -Xloggc:/var/log/wfm/security-provider-bg/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar security-provider-bg-1.0.RELEASE.jar --server.port=8002