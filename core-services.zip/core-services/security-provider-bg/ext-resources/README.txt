

############## Deployment Steps ####################
1. Update /config/properties/db.properties to specify service specific connection properties
2 .Execute /<service-name>-deployable/<service-name>.bat on windows or /<service-name>-deployable/<service-name>.sh on linux environment.