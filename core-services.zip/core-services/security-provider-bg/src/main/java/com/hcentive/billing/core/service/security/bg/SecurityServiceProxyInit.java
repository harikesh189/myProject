package com.hcentive.billing.core.service.security.bg;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration.VelocityNonWebConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration.VelocityWebConfiguration;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration.WebMvcAutoConfigurationAdapter;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

import com.hcentive.billing.core.AutoConfigureSecureRealms;
import com.hcentive.billing.core.IMInterserviceCommConfig;
import com.hcentive.billing.core.SecurityServiceConfig;
import com.hcentive.billing.core.SecurityServiceInit;
import com.hcentive.billing.core.commons.api.ClientAppLoader;
import com.hcentive.billing.core.commons.api.CreateRequestContextFilter;
import com.hcentive.billing.core.commons.api.EnterpriseLoader;
import com.hcentive.billing.core.commons.api.OAuth2Filter;
import com.hcentive.billing.core.commons.api.SecureHttpCreateProcessContextFilter;
import com.hcentive.billing.core.commons.api.SessionContextHandlerInterceptor;
import com.hcentive.billing.core.commons.api.support.HttpRedirectURIResolverSupport;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;
import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.security.config.AutoConfigureSecurity;
import com.hcentive.billing.core.commons.service.core.security.repository.DraftUserMongoRepository;
import com.hcentive.billing.core.commons.service.core.security.web.auth.OAuth2Controller.OAuth2HttpRedirectURIResolver;
import com.hcentive.billing.core.commons.service.security.filter.CookieBasedSecuredAccessDataExtractor;
import com.hcentive.billing.core.commons.service.util.FilterRegistrationUtil;
import com.hcentive.common.inter.service.annotation.EnableInterServiceCall;

@Configuration
@PropertySources({ @PropertySource("file:${baseDir}/config/properties/db.properties"), @PropertySource("file:${baseDir}/config/properties/app.properties"),
        @PropertySource("file:${baseDir}/config/properties/security.properties"), @PropertySource("file:${baseDir}/config/properties/amqp.properties"),  @PropertySource("file:${baseDir}/config/properties/mongodb.properties") })
@ImportResource(value = { "validator.xml" })
@EnableJpaRepositories(basePackages = { "com.hcentive.billing" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EntityScan("com.hcentive.billing")
@ComponentScan(basePackages = { "com.hcentive.billing" },excludeFilters={@Filter(type=FilterType.REGEX,pattern="com.hcentive.billing.core.commons.security.config.AutoConfigureSecurity"),
		@Filter(type=FilterType.REGEX,pattern="com.hcentive.billing.core.SecurityServiceInit")})
@EnableAutoConfiguration(exclude = {AutoConfigureSecurity.class,VelocityAutoConfiguration.class,VelocityNonWebConfiguration.class,VelocityWebConfiguration.class })
@EnableWebMvc
@EnableInterServiceCall(basePackagesToScan = { "com.hcentive.billing.core.commons.service.core.security.service"})
@EnableMongoRepositories(basePackages ={"com.hcentive.billing.core.commons.starter.persistence.repository"},basePackageClasses = {DraftUserMongoRepository.class})
@Import({SecurityServiceConfig.class,AutoConfigureSecureRealms.class,IMInterserviceCommConfig.class})
public class SecurityServiceProxyInit {

	private static final Logger logger = LoggerFactory.getLogger(SecurityServiceProxyInit.class);

	@Value("${baseDir}")
	private String baseDir;

		public static void main(String[] args) throws Exception {
			System.out.println("Staring Security Service Proxy");
		SpringApplication.run(SecurityServiceProxyInit.class, args);
	}
	@Bean
	public ClientAppLoader clientAppLoader() {
		return new ClientAppLoader();
	}
	
	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
	
	@Bean
	public EnterpriseLoader enterpriseLoader() {
		return new EnterpriseLoader();
	}
}
