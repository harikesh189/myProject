package com.hcentive.billing.core.service.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import com.hcentive.billing.core.commons.service.ebill.audit.init.EbillAuditInit;

/**
 * Init class for ebill audit service
 * 
 * @author Ankit.Garg
 * 
 */


public class EbillAuditProxyInit {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(EbillAuditProxyInit.class);

	/**
	 * Init method for ebill audit service
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		LOGGER.debug("Starting ebill audit service for hcentive !!");

		SpringApplication.run(EbillAuditInit.class, args);

		LOGGER.debug("Ending ebill audit service for hcentive !!");

	}

}
