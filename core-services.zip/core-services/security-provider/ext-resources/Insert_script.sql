INSERT INTO ebill_user(
            dtype, id, external_id, identity, version)
    VALUES ('Administrator', 1, 1, 1, 1);



INSERT INTO permission(
            id, external_id, identity, version, description, operationcode, 
            operationname)
    VALUES (1, 1, 1, 1, 'Read', 'Read', 
            'Read');


INSERT INTO permission(
            id, external_id, identity, version, description, operationcode, 
            operationname)
    VALUES (2, 2, 2, 1, 'Write', 'Write', 
            'Write');
INSERT INTO permission(id, external_id, identity, version, description, operationcode,operationname)VALUES (3, 3, 3, 1, 'ViewInovice', 'ViewInovice','ViewInovice');
INSERT INTO permission(id, external_id, identity, version, description, operationcode,operationname)VALUES (4, 4, 4, 1, 'SaveInvoice', 'SaveInvoice','SaveInvoice');
INSERT INTO permission(id, external_id, identity, version, description, operationcode,operationname)VALUES (5, 5, 5, 1, 'ViewTransaction', 'ViewTransaction','ViewTransaction');
INSERT INTO permission(id, external_id, identity, version, description, operationcode,operationname)VALUES (6, 6, 6, 1, 'SaveTransaction', 'SaveTransaction','SaveTransaction');
INSERT INTO permission(id, external_id, identity, version, description, operationcode,operationname)VALUES (7, 7, 7, 1, 'ViewProfileDetails', 'ViewProfileDetails','ViewProfileDetails');
INSERT INTO permission(id, external_id, identity, version, description, operationcode,operationname)VALUES (8, 8, 8, 1, 'ViewCustomer', 'ViewCustomer','ViewCustomer');
INSERT INTO permission(id, external_id, identity, version, description, operationcode,operationname)VALUES (9, 9, 9, 1, 'SaveCustomer', 'SaveCustomer','SaveCustomer');

INSERT INTO role(
            id, external_id, identity, version, code, description, name)
    VALUES (1, 1, 1, 1, 'Admin', 'Admin', 'Admin');

INSERT INTO role_permissions(
            role, permissions)
    VALUES (1, 1);
INSERT INTO role_permissions(
            role, permissions)
    VALUES (1, 2);
INSERT INTO role_permissions(role, permissions) VALUES (1, 3);
INSERT INTO role_permissions(role, permissions) VALUES (1, 4);
INSERT INTO role_permissions(role, permissions) VALUES (1, 5);
INSERT INTO role_permissions(role, permissions) VALUES (1, 6);
INSERT INTO role_permissions(role, permissions) VALUES (1, 7);
INSERT INTO role_permissions(role, permissions) VALUES (1, 8);
INSERT INTO role_permissions(role, permissions) VALUES (1, 9);
 
INSERT INTO ebill_user_roles(
            ebill_user, roles)
    VALUES (1, 1);

INSERT INTO usercredential(
            id, external_id, identity, version, password, username)
    VALUES (1, 1, 1, 1, 'password', 'Admin');

