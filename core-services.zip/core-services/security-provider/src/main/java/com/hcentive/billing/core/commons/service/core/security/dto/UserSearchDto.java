package com.hcentive.billing.core.commons.service.core.security.dto;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.dto.PageRequestCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteriaOnColumns;

public class UserSearchDto {

	private String userType;
	private SearchCriteria searchCriteria;
	private String activationCode;
	private String beIdentity;
	private final Map<String, String> params = new HashMap<String, String>();

	public SearchCriteria getSearchCriteria() {
		return this.searchCriteria;
	}

	public String getBeIdentity() {
		return this.beIdentity;
	}

	public void setBeIdentity(final String beIdenetity) {
		this.beIdentity = beIdenetity;
	}

	public void setSearchCriteria(final SearchCriteria searchCriteria) {
		this.searchCriteria = searchCriteria;
	}

	public String getUserType() {
		return this.userType;
	}

	public void setUserType(final String userType) {
		if (null != userType) {
			this.userType = userType.trim();
		}
	}

	public String getActivationCode() {
		return this.activationCode;
	}

	public void setActivationCode(final String activationCode) {
		if (null != activationCode) {
			this.activationCode = activationCode.trim();
		}
	}

	@JsonIgnore
	public SearchCriteria getUserSearchCriteria() {
		if (this.isActivateByActivationCode()) {
			return this.createActivationSearchCriteria();
		}
		if (this.userType.equalsIgnoreCase(BusinessEntityTypes.BROKER)) {
			final SearchCriteria brokerCriteria = this.getSearchCriteria();
			final String npn = brokerCriteria.getReferenceId();
			final Reference npnReference = Reference.newExternalReference(npn, "", "", "");
			brokerCriteria.setReferences(Collections.singleton(npnReference));
			return brokerCriteria;

		}
		return this.getSearchCriteria();
	}

	private SearchCriteria createActivationSearchCriteria() {

		if (this.activationCode != null) {
			final SearchCriteria searchCriteria = new SearchCriteria();
			final Map<String, SearchCriteriaOnColumns> criteria = searchCriteria.getCriteria();
			final SearchCriteriaOnColumns value = new SearchCriteriaOnColumns();
			value.setColumnValue("'" + this.activationCode + "'");
			value.setOperator("=");
			criteria.put("activationCode", value);
			final PageRequestCriteria pg = searchCriteria.getPageRequestCriteria();
			pg.setPageIndex(0);
			pg.setSize(1);
			searchCriteria.setCriteria(criteria);
			searchCriteria.setPageRequestCriteria(pg);
			return searchCriteria;
		} else {
			return null;
		}
	}

	public boolean isActivateByActivationCode() {
		if (null != this.activationCode && !this.activationCode.isEmpty()) {
			return true;
		}
		return false;

	}

	public String getBrokerId() {
		if (null != this.getSearchCriteria() && null != this.getSearchCriteria().getCriteria()
				&& null != this.getSearchCriteria().getCriteria().get("externalId")) {
			return this.getSearchCriteria().getCriteria().get("externalId").getColumnValue();
		}
		return null;
	}

	public String getNPN() {
		if (null != this.getSearchCriteria()) {
			return this.getSearchCriteria().getReferenceId();
		}
		return null;
	}

	public Map<String, String> getParams() {
		return Collections.unmodifiableMap(this.params);
	}

	public void setParams(final Map<String, String> params) {
		this.params.putAll(params);
	}

}
