package com.hcentive.billing.core.commons.api.support;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;

@SuppressWarnings("rawtypes")
@Component
public class IdpAdapterRegistry extends SpringBackedAbstractFactory<IdpAdapter> {

	public IdpAdapter getAdapter(final String idpKey) {
		for (final IdpAdapter adapter : registeredInstances()) {
			if (adapter.canProcess(idpKey)) {
				return adapter;
			}
		}
		throw new IllegalStateException("No IdpAdapter configured for key: "
				+ idpKey);
	}

	public IdpAdapter getAdapter() {
		return getAdapter(RequestContext.get().identityProvider().getIdpKey());
	}

	@Override
	protected Class<IdpAdapter> lookupForType() {
		return IdpAdapter.class;
	}

}
