package com.hcentive.billing.core.commons.service.core.security.service;

import com.hcentive.billing.core.commons.security.shiro.AbstractAuthToken;

public class WFMUsernamePasswordToken extends AbstractAuthToken {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final String username;
	private final String password;

	public WFMUsernamePasswordToken(final String username, final String password) {
		super();
		this.username = username;
		this.password = password;
	}

	@Override
	public Object getPrincipal() {
		return username;
	}

	@Override
	public Object getCredentials() {
		return password;
	}

	public String getUsername() {
		return username;
	}

}
