package com.hcentive.billing.core.commons.api;

import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.TenantAware;

@Entity
@Table(name = "security_identity_provider")
public class IdentityProvider extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Access(AccessType.FIELD)
	@Column(name = "idp_key", nullable = false)
	private String idpKey;

	@Access(AccessType.FIELD)
	@Column(name = "name")
	private String name;

	@Access(AccessType.FIELD)
	@Column(name = "domain", nullable = false)
	private String domain;

	@Access(AccessType.FIELD)
	@Column(name = "default_idp_end_point", nullable = false)
	private String defaultIdpEndPoint;

	@Access(AccessType.FIELD)
	@Column(name = "logout_idp_end_point")
	private String logoutIdpEndPoint;

	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	@Column(name = "default_mode", nullable = false)
	private AuthMode defaultMode;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "security_identity_provider_params", joinColumns = @JoinColumn(name = "id"))
	@Column(name = "identity_provider_params_value")
	@MapKeyColumn(name = "identity_provider_params_key")
	@Access(AccessType.FIELD)
	private Map<String, String> params;

	@Access(AccessType.FIELD)
	@Column(name = "handled_by_controller", nullable = false)
	private String handledByController;

	@Access(AccessType.FIELD)
	@Column(name = "handled_by_intrepreter")
	private String handledByIntrepreter;

	protected IdentityProvider() {
	}

	public String getHandledByIntrepreter() {
		return handledByIntrepreter;
	}

	public String getIdpKey() {
		return idpKey;
	}

	protected String getName() {
		return name;
	}

	protected String getDomain() {
		return domain;
	}

	protected String getLogoutIdpEndPoint() {
		return logoutIdpEndPoint;
	}

	protected String getDefaultIdpEndPoint() {
		return defaultIdpEndPoint;
	}

	protected AuthMode getDefaultMode() {
		return defaultMode;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public String getHandledByController() {
		return handledByController;
	}

	public IdpInfo idpInfo(){
		return new IdpInfo(idpKey, this.name ,this.handledByController);
	}
	public static class IdpInfo{
		private final String idpKey;
		private final String idpName;
		private final String handledByController;
		public IdpInfo(String idpKey, String idpName,String handledByController) {
			super();
			this.idpKey = idpKey;
			this.idpName = idpName;
			this.handledByController = handledByController;
		}
		public String getIdpKey() {
			return idpKey;
		}
		public String getIdpName() {
			return idpName;
		}
		
		public String getHandledByController(){
			return handledByController;
		}
		
		
	}

}
