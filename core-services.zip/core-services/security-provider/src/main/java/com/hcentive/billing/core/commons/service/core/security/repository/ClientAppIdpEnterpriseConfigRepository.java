package com.hcentive.billing.core.commons.service.core.security.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.api.ClientApp;
import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;


@Transactional
public interface ClientAppIdpEnterpriseConfigRepository extends
JpaRepository<ClientAppIdpEnterpriseConfig, Long> {

	public List<ClientAppIdpEnterpriseConfig> findByClientApp(ClientApp clientApp);

	public List<ClientAppIdpEnterpriseConfig> findByEnterpriseNameAndClientAppAppKey(
			String enterprise, String appKey);
	
	public List<ClientAppIdpEnterpriseConfig> findByEnterpriseNameAndIdentityProviderIdpKey(final String enterprise,final String idpKey);

}
