package com.hcentive.billing.core.commons.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.ModelAndView;

import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.EnterpriseImpl;
import com.hcentive.billing.core.commons.api.IdentityProvider.IdpInfo;
import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.SessionContext;
import com.hcentive.billing.core.commons.security.Credential;
import com.hcentive.billing.core.commons.web.WebUtils;

public class AuthWebUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthWebUtil.class);

	private static String defaultIdpKey;
	private static String defaultEnterpriseName;
	
	public static void setDefaultIdpKey(String newDefaultIdpKey){
		defaultIdpKey = newDefaultIdpKey;
	}
	
	public static String defaultIdpKey(){
		return defaultIdpKey;
	}
	
	public static void setDefaultEnterpriseName(String newDefaultEnterpriseName){
		defaultEnterpriseName = newDefaultEnterpriseName;
	}
	
	public static String defaultEnterpriseName(){
		return defaultEnterpriseName;
	}
	
	public static String createForwardToPathFromController(final String path) {
		final StringBuilder builder = new StringBuilder("forward:");
		return createPath(path, builder);
	}
	
	public static String createForwardToPath(final String path) {
		final StringBuilder builder = new StringBuilder();
		return createPath(path, builder);
	}

	private static String createPath(final String path,
			final StringBuilder builder) {
		
		builder.append("/security/");
		final EnterpriseImpl enterprise = RequestContext.get().enterprise();
		builder.append(enterprise.getName());
		builder.append("/").append(path);
		return builder.toString();
	}

	public static void attachCredential(HttpServletRequest request,
			Credential credential) {
		request.setAttribute("credential", credential);
	}

	public static Credential getCredential(HttpServletRequest request) {
		return (Credential) request.getAttribute("credential");
	}

	public static void attachStateAndCallBackUrl(
			final HttpServletRequest request, final String state,
			final String callBackUrl) {
		request.setAttribute("state", state);
		request.setAttribute("callBackUrl", callBackUrl);
	}

	public static String getCallBackUrl(final HttpServletRequest request) {
		return (String) request.getAttribute("callBackUrl");
	}

	public static String getState(final HttpServletRequest request) {
		return (String) request.getAttribute("state");
	}

	public static String identityAssertionPath() {
		return createForwardToPathFromController("authenticator/int/assertIdentity");
	}
	
	public static void attachSessionParams(final HttpServletRequest request,final Map<String,String> sessionParams){
		request.setAttribute("sessionParams", sessionParams);
	}
	
	@SuppressWarnings("unchecked")
	public static Map<String,String> sessionParams(final HttpServletRequest request){
		if(request.getAttribute("sessionParams") != null)
			return (Map<String,String>) request.getAttribute("sessionParams");
		return null;
	}
	
	/**
	 * @param request
	 * @param modelandView
	 */
	public static void addStandardViewItems(final HttpServletRequest request,
			ModelAndView modelandView, Environment env) {
		modelandView.addObject("login.footerURL",
				env.getProperty("copyrightURL"));
		modelandView.addObject("staticUrl",
				env.getProperty("security.static.resource.url"));
		modelandView.addObject("usingDefaultEnterprise",RequestContext.get().usingDefaultEnterprise());
		modelandView.addObject("state", AuthWebUtil.getState(request));
		modelandView.addObject("callBackUrl",
				AuthWebUtil.getCallBackUrl(request));
	}

	public static List<IdpInfo> getIdpInfos(
			List<ClientAppIdpEnterpriseConfig> configs) {
		final List<IdpInfo> idps = new ArrayList<>();
		if(null!=configs){
			for(final ClientAppIdpEnterpriseConfig config : configs){
				idps.add(config.getIdentityProvider().idpInfo());
			}
		}
		return idps;
	}
	
	public static String getTokenIdFromCookie(HttpServletRequest request,final String clientId) {
		final Map<String, String> sessionParams = WebUtils
				.getCookiesFromRequest(request);
		final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
		final String encryptedTokenId = sessionParams.get(SessionContext.sessionIdentifierKey()+cookieIdentifier);
		LOGGER.debug("Encrypted Token Id: {}",encryptedTokenId);
		return WebUtils.decryptTokenId(encryptedTokenId);
	}
	
	public static void populateSessionContext(final String tokenId,final String clientId) {
		SessionContext sessionContext = SessionContext.get();
		sessionContext.validSession();
		final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
		sessionContext.addCookie(SessionContext.sessionIdentifierKey()+cookieIdentifier,
				WebUtils.encryptTokenId(tokenId));
	}
	
}
