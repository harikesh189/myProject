package com.hcentive.billing.core.commons.api;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.service.core.security.repository.EnterpriseRepository;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class EnterpriseLoader {

	@Autowired
	private EnterpriseRepository enterpriseRepository;
	
	@Autowired
	private WFMCache<String, Set<String>> cache;
	
	@PostConstruct
	public void loadEnterprises(){
		EnterpriseConfigPreLoader enterpriseConfigPreLoader = new EnterpriseConfigPreLoader();
		final Thread th = new Thread(enterpriseConfigPreLoader);
		th.start();
	}
	
	private class EnterpriseConfigPreLoader implements Runnable{

		@Override
		public void run() {
			ProcessContext.initializer().initialize().ignoreTenantDuringProcessing();
			final List<EnterpriseImpl> configuredEnterprises = enterpriseRepository.findAll();
			cacheConfiguredEnterprises(configuredEnterprises);
			ProcessContext.clear();
		}

		private void cacheConfiguredEnterprises(
				List<EnterpriseImpl> configuredEnterprises) {
			final Set<String> enterprises = new HashSet<String>();
			for (EnterpriseImpl enterprise : configuredEnterprises) {
				enterprises.add(enterprise.getName());
			}
			cache.put(BillingConstant.REGISTERED_ENTERPRISES, enterprises,0);
		}
		
	}
}
