package com.hcentive.billing.core.commons.service.core.security.repository;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hcentive.billing.core.commons.domain.User;


@Transactional
public interface UserRepository extends JpaRepository<User, Long> {

	User findByIdentity(String identity);

	//Commented find by reference code - TO DO
	@Query("select d from com.hcentive.billing.core.commons.domain.Manager d INNER JOIN d.managedEntities me where me.id = ?1")
	/*@Query("select d from com.hcentive.billing.core.commons.domain.Manager d INNER JOIN d.manages rs INNER JOIN rs.references refs WHERE refs.id in((select ref.id FROM Reference ref WHERE upper(ref.typeName) = upper(?2) "
			+ " and upper(ref.referenceId) = upper(?1) and upper(ref.source) = upper(?3)  and d.isDeleted = false"
			+ " and ref.category = com.hcentive.billing.core.commons.domain.enumtype.ReferenceCategory.RELATED_ITEM)) ")*/
	public Collection<User> getBEManagers(Long beId);

	Collection<User> findByIsDeleted(boolean b);
	
	User findById(Long id);

	User findByExternalId(String externalId);

}
