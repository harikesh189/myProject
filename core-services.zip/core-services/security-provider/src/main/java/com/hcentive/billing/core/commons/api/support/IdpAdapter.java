package com.hcentive.billing.core.commons.api.support;

import java.util.Map;

import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.IdpRequestConfiguration;
import com.hcentive.billing.core.commons.api.IdpUserIdentity;

public interface IdpAdapter<C extends IdpRequestConfiguration> {

	public boolean canProcess(String idpKey);

	public IdpUserIdentity parseIdpResponse(
			ClientAppIdpEnterpriseConfig clientAppIdpConfig,
			Map<String, String[]> idpResponse);

	public Map<String, String[]> createIdpRequest(C idpConfig);

}
