package com.hcentive.billing.core.commons.api.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.vo.DateTime;

@Document(collection = "security_password_policy")
public class PasswordPolicy {
	
	@Id
	private String id;
	
	private String userCredentialsRef;
	
	private String[] storedPasswords;
	
	private DateTime currentPasswordExpiry;

	public String getUserCredentialsRef() {
		return userCredentialsRef;
	}

	public String[] getStoredPasswords() {
		return storedPasswords;
	}

	public void setStoredPasswords(String[] storedPasswords) {
		this.storedPasswords = storedPasswords;
	}

	public DateTime getCurrentPasswordExpiry() {
		return currentPasswordExpiry;
	}

	public void setCurrentPasswordExpiry(DateTime currentPasswordExpiry) {
		this.currentPasswordExpiry = currentPasswordExpiry;
	}
	
	protected PasswordPolicy(){}
	
	public PasswordPolicy(final String userCredentialsRef){
		this.userCredentialsRef = userCredentialsRef;
	}

}
