package com.hcentive.billing.core.commons.api;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "security_enterprise")
public class Enterprise extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Access(AccessType.FIELD)
	@Column(name = "name", nullable = false)
	private String name;
	
	public String getName(){
		return name;
	}

}
