package com.hcentive.billing.core.commons.api;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "security_client_app_idp_enterprise_config")
public class ClientAppIdpEnterpriseConfig extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Access(AccessType.FIELD)
	@JoinColumn(name = "client_app_id")
	@OneToOne
	private ClientApp clientApp;

	@Access(AccessType.FIELD)
	@JoinColumn(name = "identity_provider_id")
	@OneToOne
	private IdentityProvider identityProvider;
	
	@Access(AccessType.FIELD)
	@JoinColumn(name = "enterprise_id")
	@OneToOne
	private EnterpriseImpl enterprise;

	@Access(AccessType.FIELD)
	@Column(name = "idp_end_point")
	private String idpEndPoint;
	
	@Access(AccessType.FIELD)
	@Column(name = "logout_idp_end_point")
	private String logoutIdpEndPoint;

	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	@Column(name = "auth_mode")
	private AuthMode authMode;
	
	@Access(AccessType.FIELD)
	@Column(name = "issuer")
	private String issuer;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "security_client_app_idp_enterprise_config_params", joinColumns = @JoinColumn(name = "id"))
	@MapKeyColumn(name = "client_app_idp_enterprise_config_key")
	@Column(name = "client_app_idp_enterprise_config_value")
	@Access(AccessType.FIELD)
	private Map<String, String> params;
	

	protected ClientAppIdpEnterpriseConfig() {
	}
	
	public String getIssuer() {
		return issuer;
	}

	public EnterpriseImpl getEnterprise(){
		return enterprise;
	}
	
	public ClientApp getClientApp() {
		return clientApp;
	}

	public IdentityProvider getIdentityProvider() {
		return identityProvider;
	}

	public String getIdpEndPoint() {
		return idpEndPoint != null ? idpEndPoint : identityProvider
				.getDefaultIdpEndPoint();
	}
	
	public String getLogoutIdpEndPoint() {
		return logoutIdpEndPoint != null ? logoutIdpEndPoint : identityProvider
				.getLogoutIdpEndPoint();
	}

	public AuthMode getAuthMode() {
		return authMode != null ? authMode : identityProvider.getDefaultMode();
	}

	protected Map<String, String> getParams() {
		final Map<String, String> allParams = new HashMap<String, String>(
				this.identityProvider.getParams());
		allParams.putAll(this.params);
		return allParams;
	}

}
