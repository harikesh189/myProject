package com.hcentive.billing.core.commons.service.core.security.web.idpsupport;

public abstract class IdpAuthenticationProcesingController {

	public abstract String identity();

	public abstract String loginEndpointToForwardForProcessing();

	public abstract String logoutEndpointToForwardForProcessing();

	public abstract String registrationEndpointToForwardForProcessing() ;
	
	
}
