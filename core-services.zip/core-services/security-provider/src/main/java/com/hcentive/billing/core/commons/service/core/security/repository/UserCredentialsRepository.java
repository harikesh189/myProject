package com.hcentive.billing.core.commons.service.core.security.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import com.hcentive.billing.core.commons.domain.UserCredentials;

@NoRepositoryBean
@Transactional
public interface UserCredentialsRepository<T extends UserCredentials> extends
JpaRepository<T, Long> {

	public UserCredentials findByIdentity(String identity);

	public List<UserCredentials> getByUserTenantInfoIdentity(String identity);
}
