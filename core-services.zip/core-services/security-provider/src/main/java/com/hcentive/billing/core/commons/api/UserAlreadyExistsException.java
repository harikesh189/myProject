package com.hcentive.billing.core.commons.api;

public class UserAlreadyExistsException extends RuntimeException {
	
	private static final long serialVersionUID = -4198284497406150509L;
	public static final int ERROR_CODE = 602;
	
	public UserAlreadyExistsException(String errorMessage) {
		super(errorMessage);
	}

}
