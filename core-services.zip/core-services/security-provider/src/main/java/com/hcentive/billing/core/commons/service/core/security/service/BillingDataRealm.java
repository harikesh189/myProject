package com.hcentive.billing.core.commons.service.core.security.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.EntityManagerHolder;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.hcentive.billing.core.AbstractSecurityRealm;
import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.security.shiro.AbstractAuthToken;
import com.hcentive.billing.core.commons.security.shiro.AnonymousAuthToken;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.WFMUserCredentialsRepository;
import com.hcentive.billing.core.commons.service.ebill.audit.handler.AuditUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class BillingDataRealm extends AbstractSecurityRealm<WFMUsernamePasswordToken> {
	
	@Autowired
	protected UserRepository userRepository;

	@Autowired
	private EntityManagerFactory emf;
	@Autowired
	protected UserMgmt userMgmt;
	
	@Autowired
	private WFMUserCredentialsRepository userCredentialsRepository;
	
	public BillingDataRealm() {
		super(WFMUsernamePasswordToken.class);
		// TODO Auto-generated constructor stub
	}

	public void setCredentialsSevice(UserCredentialsSevice credentialsSevice) {
		this.credentialsSevice = credentialsSevice;
	}

	private UserService userService;
	private UserCredentialsSevice credentialsSevice;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(BillingDataRealm.class);

	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			final AuthenticationToken token) throws AuthenticationException {
			return getAuthenticationInfo((WFMUsernamePasswordToken) token);
	}

	private AuthenticationInfo getAuthenticationInfo(
			final WFMUsernamePasswordToken token) {
		LOGGER.debug("In getAuthenticationInfo");
		WFMUserCredentials credentials;
		try {
			LOGGER.debug("Fetching WFM User Credentials");
			final RequestContext requestContext = RequestContext.get();
			LOGGER.debug("Request Context Found : {}",requestContext);
			LOGGER.debug("/n/nFetching Credentials for username: {} for idpKey: {} for enterprise: {}",token.getUsername(),requestContext.identityProvider().getIdpKey(),requestContext.enterprise().getName());
			credentials = (WFMUserCredentials) credentialsSevice
					.getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseName(token.getUsername(),requestContext.identityProvider().getIdpKey(),requestContext.enterprise().getName());
			LOGGER.debug("Credentials found: {}",credentials);
		} catch (InvalidUserException e) {
			throw new AuthenticationException("No Matching credentials found");
		}
		UserTenantInfo userTenantInfo = credentials.getUserTenantInfo();
		LOGGER.debug("User Tenant Info : {}",userTenantInfo);
		final ProcessContext pc  = ProcessContext.get();
		LOGGER.debug("Process Context : {}",pc);
		final String tenantId = userTenantInfo.getTenantId();
		LOGGER.debug("Tenant is : {}",tenantId);
		final EntityManagerHolder emHolder = (EntityManagerHolder) TransactionSynchronizationManager.getResource(emf);
		LOGGER.debug("emHolder is : {}",emHolder);
		User user =null;
		AuthenticationInfo authenticationInfo = null;
		if(null != emHolder){
			//implies that an EntityManager is associated with the thread. Manipulate it.
			final EntityManager entityManager = emHolder.getEntityManager();
			entityManager.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, tenantId);
			LOGGER.debug("Fetching User");
			user =  userMgmt.findById(userTenantInfo.getId());
			initiliazeProcessContext(userTenantInfo);
			authenticationInfo = loadAuthenticationInfo(token, credentials,user);
			revertProcessContext(pc);
			LOGGER.debug("User Found: {}",user);
			entityManager.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, pc.getTenantId());
		}else{
			//there is not EntityManager attached feel the freedom.
			LOGGER.debug("Fetching User");
			initiliazeProcessContext(userTenantInfo);
			user =  userMgmt.findById(userTenantInfo.getId());
			authenticationInfo = loadAuthenticationInfo(token, credentials,user);
			LOGGER.debug("User Found: {}",user);
			revertProcessContext(pc);
		}
		credentials.setFailedAttempts(0);
		LOGGER.debug("Updating failed attempts to 0");
		userCredentialsRepository.save(credentials);
		return authenticationInfo;
	}
	
	@Override
	public AuthenticationInfo loadAuthenticationInfo(AbstractAuthToken token,
			UserCredentials credentials, User user) {
		AuthenticationInfo info = super.loadAuthenticationInfo(token, credentials, user);
		publishAuditEvent(token, user);
		return info;
	}

	private void publishAuditEvent(AbstractAuthToken token, User user) {
		if(!(token instanceof AnonymousAuthToken)){
			LOGGER.debug("Firing the audit for user login service");
			ProcessContext.get().acknowledgeTenantDuringProcessing();
			
			String displayName = "";
			if(null != user.getProfile() && null != user.getProfile().getDisplayName()){
				displayName = user.getProfile().getDisplayName();
			}
			
			LOGGER.debug("Audit for user display name [{}] , user identity [{}] ,tenanat [{}]",displayName,user.getIdentity(),ProcessContext.get().getTenantId());
			ProcessContext.get().setUserName(displayName);
			AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, "",
					user.getIdentity(), "", "", AuditMessageDefinition.USER_LOGGED_IN, 
					"username",displayName); // TODO Changed as per Token
			ProcessContext.get().ignoreTenantDuringProcessing();
			
			
			LOGGER.debug("Fired the audit for user login service");
		}
	}


	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
}
