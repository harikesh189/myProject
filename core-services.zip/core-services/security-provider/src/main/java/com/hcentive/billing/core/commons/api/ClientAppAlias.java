package com.hcentive.billing.core.commons.api;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "security_client_app_alias")
public class ClientAppAlias extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Access(AccessType.FIELD)
	@JoinColumn(name = "client_app_id", nullable = false)
	@ManyToOne
	private ClientApp clientApp;

	@Access(AccessType.FIELD)
	@Column(name = "alias", nullable = false)
	private String alias;

	public ClientApp getClientApp() {
		return clientApp;
	}

	public String getAlias() {
		return alias;
	}

}
