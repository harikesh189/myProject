package com.hcentive.billing.core.commons.api.domain;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;

import org.jasypt.util.password.StrongPasswordEncryptor;

import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.util.EncryptionUtil;

@SuppressWarnings("hiding")
@Entity
@Table(name = "user_credential")
@DiscriminatorValue(value = "WFM_USERCREDENTIAL")
public class WFMUserCredentials extends UserCredentials {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "user_name")
	@Access(AccessType.FIELD)
	private String userName;

	@Column(name = "password")
	@Access(AccessType.FIELD)
	private String password;
	
	@Column(name = "failed_attempts")
	@Access(AccessType.FIELD)
	private int failedAttempts;

	@ElementCollection(fetch = FetchType.EAGER)
	@MapKeyColumn(name = "question")
	@Column(name = "answer")
	@CollectionTable(name = "user_credential_sec_info", joinColumns = @JoinColumn(name = "wfmuser_credentials_id"))
	private Map<String, String> securityInfo;
	

	public int getFailedAttempts() {
		return failedAttempts;
	}

	public void setFailedAttempts(int failedAttempts) {
		this.failedAttempts = failedAttempts;
	}

	public Map<String, String> getSecurityInfo() {
		return this.securityInfo;
	}

	public void setSecurityInfo(final Map<String, String> securityInfo) {
		if (null == this.securityInfo) {
			this.securityInfo = new HashMap<>();
		}
		for (final Map.Entry<String, String> entry : securityInfo.entrySet()) {
			this.securityInfo.put(entry.getKey(),
					EncryptionUtil.oneWayEncryptString(entry.getValue()));
		}
	}

	protected WFMUserCredentials() {
	}

	private WFMUserCredentials(final String identity, final String externalId,
			final String username, final String password,final String enterpriseName) {
		super(identity, externalId,enterpriseName,AuthWebUtil.defaultIdpKey()); //TODO move it to security-provider
		this.userName = username;
		this.password = password;
	}

	public String getUsername() {
		return this.userName;
	}

	public String getPassword() {
		return this.password;
	}

	public static UserCredentialsBuilder createNewCredential() {
		return new UserCredentialsBuilder();
	}

	public static class UserCredentialsBuilder {
		private String identity;
		private String externalId;
		private String username;
		private String password;
		private String enterpriseName;
		
		public UserCredentialsBuilder forEnterprise(final String enterpriseName) {
			this.enterpriseName = enterpriseName;
			return this;
		}

		public UserCredentialsBuilder withIdentity(final String identity) {
			this.identity = identity;
			return this;
		}

		public UserCredentialsBuilder withExternalId(final String externalId) {
			this.externalId = externalId;
			return this;
		}

		public UserCredentialsBuilder forUserName(final String username) {
			this.username = username;
			return this;
		}

		public UserCredentialsBuilder withPassword(final String password) {
			this.password = EncryptionUtil.oneWayEncryptString(password);
			return this;
		}

		public WFMUserCredentials build() {
			return new WFMUserCredentials(this.identity, this.externalId,
					this.username, this.password,this.enterpriseName);
		}
	}

	public static void changePassword(final WFMUserCredentials userCredentials,
			final String password) {
		userCredentials.password = EncryptionUtil.oneWayEncryptString(password);
	}

	/**
	 * @see StrongPasswordEncryptor#matchSecurityInfo(String, String)
	 * @param plainPassword
	 * @param encryptedPassword
	 * @return
	 */
	public boolean matchSecurityInfo(final String question, final String answer) {
		return EncryptionUtil.oneWayCheckPassword(answer,
				this.securityInfo.get(question.trim()));
	}

	@Override
	public Object getAuthKey() {
		return this.getPassword();
	}

}
