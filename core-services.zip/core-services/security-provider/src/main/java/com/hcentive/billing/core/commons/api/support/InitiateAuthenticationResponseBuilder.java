package com.hcentive.billing.core.commons.api.support;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.hcentive.billing.core.commons.api.AuthMode;
import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.IdpRequestConfiguration;
import com.hcentive.billing.core.commons.api.RequestContext;

@Component
public class InitiateAuthenticationResponseBuilder {

	private static final Logger logger = LoggerFactory
			.getLogger(InitiateAuthenticationResponseBuilder.class);

	@Autowired
	private IdpAdapterRegistry registry;

	@Autowired
	private IdpRequestBuilderRegistry idpRequestBuilderRegistry;

	public ModelAndView buildResponse(final Map<String, String> params) {

		logger.debug("Building Response");
		RequestContext requestContext = RequestContext.get();
		ClientAppIdpEnterpriseConfig clientAppIdpConfig = requestContext
				.clientAppIdpEnterpriseConfig();
		final AuthMode authMode = clientAppIdpConfig.getAuthMode();
		logger.debug("AuthMode : {}", authMode);

		switch (authMode) {
		case CAPTURE_CREDENTIALS: {
			return buildMAVForCaptureCredentials(params);
		}
		case CAPTURE_CREDENTIALS_FOR_SYSTEM_AUTH: {
			return buildMAVForCaptureCredentials(params);
		}
		case SUBMIT_POST: {
			return buildMAVForSubmit(params);
		}
		default:
			return buildMAVForIdp(params);
		}

	}

	private ModelAndView buildMAVForSubmit(final Map<String, String> params) {
		logger.debug("Building MAV For Submit");
		ModelAndView mav = new ModelAndView("login");
		buildMavFromIdpRequestConfig(params, mav);
		logger.debug("MAV Build");
		return mav;
	}

	private ModelAndView buildMAVForCaptureCredentials(
			final Map<String, String> params) {
		logger.debug("Building MAV For CaptureCredentials");
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("params", params);
		mav.addObject("action", "login");
		logger.debug("MAV Build");
		return mav;
	}

	private ModelAndView buildMAVForIdp(final Map<String, String> requestParams) {
		logger.debug("Building MAV For Idp");
		ModelAndView mav = new ModelAndView("postToIdp");
		buildMavFromIdpRequestConfig(requestParams, mav);
		logger.debug("MAV Build");
		return mav;
	}

	@SuppressWarnings("unchecked")
	private void buildMavFromIdpRequestConfig(
			final Map<String, String> requestParams, ModelAndView mav) {
		logger.debug("Getting idpRequestConfig");
		IdpRequestConfiguration idpRequestConfiguration = idpRequestBuilderRegistry
				.getBuilder().buildRequest(requestParams);
		logger.debug("IdpRequestConfiguration found and creating Idp Request");
		Map<String, String> finalParams = registry.getAdapter()
				.createIdpRequest(idpRequestConfiguration);
		mav.addObject("action", idpRequestConfiguration.clientAppIdpConfig()
				.getIdpEndPoint());
		mav.addObject("params", finalParams);
	}

}
