package com.hcentive.billing.core.commons.service.core.security.service;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;

@Component
public class UserMgmtImpl implements UserMgmt {

	@Autowired
	private UserRepository userRepo;
	
	@Override
	@Transactional(value=TxType.REQUIRES_NEW)
	public User findById(Long id) {
		// TODO Auto-generated method stub
		return userRepo.findById(id);
	}
	
	@Override
	@Transactional
	public void updateUser(User user){
		userRepo.save(user);
	}

}
