package com.hcentive.billing.core.commons.api;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class IdpRequestConfiguration {

	private final ClientAppIdpEnterpriseConfig clientAppIdpConfig;
	private String resultEndpoint;
	private Map<String, String> paramsToAddInResult = new HashMap<String, String>();

	public IdpRequestConfiguration() {
		super();
		RequestContext requestContext = RequestContext.get();
		this.clientAppIdpConfig = requestContext.clientAppIdpEnterpriseConfig();
		// this.resultEndpoint = requestContext.resource();
	}

	public IdpRequestConfiguration(Map<String, String> paramsToAddInResult) {
		this();
		this.paramsToAddInResult = paramsToAddInResult;
	}

	public void add(final String param, final String value) {
		this.paramsToAddInResult.put(param, value);
	}

	public void addAll(Map<String, String> params) {
		this.paramsToAddInResult.putAll(params);
	}

	public String resultEndPoint() {
		return this.resultEndpoint;
	}

	public ClientAppIdpEnterpriseConfig clientAppIdpConfig() {
		return clientAppIdpConfig;
	}

	public Map<String, String> params() {
		return Collections.unmodifiableMap(paramsToAddInResult);
	}

}
