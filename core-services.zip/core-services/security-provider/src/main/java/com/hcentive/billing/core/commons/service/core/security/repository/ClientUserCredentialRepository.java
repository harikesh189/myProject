package com.hcentive.billing.core.commons.service.core.security.repository;

import com.hcentive.billing.core.commons.api.ClientUserCredential;


public interface ClientUserCredentialRepository extends
		UserCredentialsRepository<ClientUserCredential> {

	public ClientUserCredential findBySecretKey(final String secretKey);

}
