package com.hcentive.billing.core.commons.service.core.security.event.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.EventHandler;
import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.service.core.security.dto.LoginDetails;

@Component
public class SecurityEventHandler implements EventHandler {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SecurityEventHandler.class);

	@EventSubscription(eventName = "login")
	public void loginEvent(LoginDetails loginDetails) {
		String message = "UserId " + loginDetails.getUserId()
				+ " is logged in successfully at " + loginDetails.getDateTime();
		LOGGER.info(message);

	}

	@EventSubscription(eventName = "logout")
	public void logoutEvent(LoginDetails loginDetails) {
		String message = "UserId " + loginDetails.getUserId()
				+ " is logout successfully at " + loginDetails.getDateTime();
		LOGGER.info(message);

	}

}
