package com.hcentive.billing.core.commons.service.core.security.manager;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.commons.mongo.CustomMongoTemplate;
import com.hcentive.billing.core.commons.api.UserAlreadyExistsException;
import com.hcentive.billing.core.commons.api.UserCredentialAlreadyExistsException;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.api.resolver.DraftUserIdentifierResolver;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.Address;
import com.hcentive.billing.core.commons.domain.Administrator;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.ContactNumber;
import com.hcentive.billing.core.commons.domain.ContactPerson;
import com.hcentive.billing.core.commons.domain.ContactSet;
import com.hcentive.billing.core.commons.domain.DraftUser;
import com.hcentive.billing.core.commons.domain.Email;
import com.hcentive.billing.core.commons.domain.Facilitator;
import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.domain.UserRegistrationPayload;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.domain.enumtype.Status;
import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.domain.enumtype.UserType;
import com.hcentive.billing.core.commons.dto.UserOperation;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.DefaultAccessToken;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.dto.ProfileUtil;
import com.hcentive.billing.core.commons.service.core.security.dto.RegistrationFormDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserCreationDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserSearchDto;
import com.hcentive.billing.core.commons.service.core.security.repository.DraftUserMongoRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.TrustedEntityRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserTenantInfoRepository;
import com.hcentive.billing.core.commons.service.core.security.service.AccessTokenService;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.service.core.security.service.RoleService;
import com.hcentive.billing.core.commons.service.core.security.service.UserCredentialsSevice;
import com.hcentive.billing.core.commons.service.core.security.service.UserService;
import com.hcentive.billing.core.commons.service.ebill.audit.handler.AuditUtil;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.validation.config.ValidationConfig;
import com.hcentive.billing.core.commons.validation.config.ValidationConfigResolver;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

@SuppressWarnings({ "deprecation", "rawtypes", "unchecked" })
@Component
public class UserManagerImpl implements UserManager {

	private static final Logger logger = LoggerFactory
			.getLogger(UserManagerImpl.class);

	@Autowired
	private UserService userService;

	@Autowired
	private UserCredentialsSevice credentialsSevice;

	@Autowired
	private ValidationConfig addUserCredentialsValidationConfig;

	@Autowired
	private ValidationConfig addUserValidationConfig;

	@Autowired
	private ValidationConfig updateUserValidationConfig;

	@Autowired
	private ValidationConfigResolver validationConfigResolver;

	@Autowired
	private DraftUserMongoRepository draftUserMongoRepository;

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private CustomMongoTemplate customMongoTemplate;

	@Autowired
	private AccessTokenService accessTokenService;
	
	@Autowired
	private AuthManager authManager;
	
	@Autowired
	private UserTenantInfoRepository userTenantInfoRepository;
	
	@Autowired
	private DraftUserIdentifierResolver draftUserIdentifierResolver;
	
	@Autowired
	private TrustedEntityRepository trustedEntity;
	
	@Value("${user.registration.token.valid.time:365}")
	private String tokenValidTime;
	
	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;

	@Override
	public Page<User> getAdminUsers(SearchCriteria  searchCriteria) {
		logger.debug("Inside user Manager for getting user for Admin");
		return userService.getAdminUsers(searchCriteria);
	}

	@Override
	public User getUserById(String userId) {

		logger.debug("Inside user Manager for gettings user with userId"
				+ userId);
		User user = userService.getUserById(userId);
		return user;
	}
	
	

	@Override
	public Object associateWithCurrentUser(UserDTO userDTO) {
		String userId = ProcessContext.get().getUserId();
		userDTO.setIdentity(userId);
		return associateWithGivenUser(userDTO);
	}

	@Override
	/***
	 * Validate User and Manages BE and associate BE
	 */
	public Object associateWithGivenUser(UserDTO userDTO) {
		BusinessEntity be = getBusinessEntity(userDTO.getUserSearchDto());
		return userService.associateAndUpdate(userDTO.getIdentity(),
				Collections.singleton(be));
	}

	/**
	 * Update the user based on UserOperations performed
	 */
	@Override
	public Object updateUser(UserDTO userDTO) {
		User updatedUser = null;
		if (null == userDTO)
			return null;

		Set<UserOperation> operations = userDTO.getOperationsPerformed();
		if (null == operations || operations.isEmpty()) {
			logger.error("No operations to performed");
			return null;
		}
		
		for (UserOperation userOperation : operations) {
			switch (userOperation) {
			case UpdateUserProfile: {
				logger.debug("Inside SwitchU Case -pdateUserProfile.....");
				updatedUser = userService.updateUserProfile(
						userDTO.getIdentity(), userDTO.getPersonalProfile());
				
				AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, userDTO.getIdentity(), 
						userDTO.getIdentity(), null, null, AuditMessageDefinition.USER_PROFILE_UPDATED,"updatedUserName",userDTO.getPersonalProfile().getDisplayName());
				
				break;
			}
			case UpdateUserRoles: {
				if(userDTO.getRoleIdentities()!=null){
				Set<Role> roles = getRolesByIdentites(userDTO
						.getRoleIdentities());
				updatedUser = userService.updateUserRoles(
						userDTO.getIdentity(), roles);
				
				AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, userDTO.getIdentity(), 
						userDTO.getIdentity(), null, null, AuditMessageDefinition.USER_ROLE_UPDATED,"roleName",getRoleNames(roles));
				
				}
				break;
			}
			case UpdateUserStatus: {
				if(userDTO.getUserStatus()!=null){
					updatedUser = userService.updateUserStatus(
							userDTO.getIdentity(), userDTO.getUserStatus());
					}
				}

			}
		}
		return updatedUser;
	}
	
	private String getRoleNames(final Set<Role> roles){
		final StringBuilder builder = new StringBuilder();
		for(Role role : roles){
			if(builder.length() != 0){
				builder.append(",").append(" ");	
			}
			builder.append(role.getDescription());
			builder.append(" ");
		}
		return builder.toString();
	}
	
	private Set<Role> getRolesByIdentites(Set<String> roleIdentities) {
		String[] r1 = (String[]) roleIdentities.toArray(new String[0]);
		return roleService.getRolesByIdentities(r1);
	}
	

	@Override
	public Collection<User> getBEManagesManagers(String beId) {
		Set<String> beIds = new HashSet<>();
		beIds.add(beId);
		List<BusinessEntity> bes = userService.getBEByIdentities(beIds)
				.getContent();
		if (null == bes || bes.isEmpty()) {
			logger.error("No BE with Id {} found in system", beId);
			return null;
		}
		/*Reference reference = Reference.newInternalReference(bes.iterator()
				.next());*/
		return userService.getBEManagers(bes.iterator()
				.next());
	}

	/***
	 * Return the User i.e. Manager OR Administrator for registration
	 */
	@Override
	public User getUserForActivation(UserSearchDto searchDto) {
		if (searchDto.isActivateByActivationCode()) {
			return getManagerByActivationCode(searchDto);
		} else {
			return getManagerByBE(searchDto);
		}
	}

	private User getManagerByBE(UserSearchDto searchDTO) {
		logger.debug("Going to find Manager ");
		BusinessEntity be = getBusinessEntity(searchDTO);
		User user = userService.getBEManagesUser(be, searchDTO.getParams());
		if (isUserActiveAndNotRegistered(user))
			return user;
		logger.debug("user not found.........");
		return null;

	}

	@Override
	public BusinessEntity getBusinessEntity(UserSearchDto searchDTO) {
		logger.debug("Going to find businessEntity ::");
		if (searchDTO == null) {
			return null;
		}
		BusinessEntity be = null;
		if ((null == searchDTO.getBeIdentity() || searchDTO.getBeIdentity()
				.isEmpty())
				&& BusinessEntityTypes.BROKER.equals(searchDTO.getUserType())) {
			be = getMatcingBroker(searchDTO);
		} else {
			Page<BusinessEntity> b = userService.fetchMatchingBEs(searchDTO
					.getSearchCriteria());
			if (null != b && b.getContent() != null
					&& !b.getContent().isEmpty())
				be = b.getContent().iterator().next();
		}
		if (be == null) {
			logger.debug("No BE found for search criteria");
			return null;
		}
		return be;
	}

	private BusinessEntity getMatcingBroker(UserSearchDto searchDTO) {
		Facilitator facilitator = userService.fetchFaciliator(
				searchDTO.getBrokerId(), searchDTO.getNPN()).get();
		return facilitator;
	}

	private boolean isUserActiveAndNotRegistered(User user) {
		return user.isActive()
				&& !credentialsSevice.isWFMUserRegistered(user.getIdentity());
	}

	private User getManagerByActivationCode(UserSearchDto searchDto) {
		List<User> users = userService.getUserBySearchCriteria(searchDto
				.getUserSearchCriteria());
		if (null == users || users.size() != 1) {
			logger.debug("No user found OR invalid details");
			return null;
		}
		if (isUserActiveAndNotRegistered(users.iterator().next()))
			return users.iterator().next();
		logger.debug("User already registered");
		return null;
	}

	/**
	 * @see change loggedin user password
	 */
	@Override
	public String changePassword(String oldPassword, String newPassword) {
		String userIdentity = ProcessContext.get().getUserId();
		logger.debug("User Identity from session found is {} ", userIdentity);
		return changePassword(userIdentity, newPassword, oldPassword);
	}

	@Override
	public String changePassword(final UserDTO userDTO) {
		return changePassword(userDTO.getIdentity(),
				String.valueOf(userDTO.getPassword()),
				userDTO.getUserSecurityInfo());
	}

	private String changePassword(String userIdentity, String newPassword,
			Object oldAuthenticationInfo) {
		if (null == userIdentity || userIdentity.isEmpty()) {
			logger.error("no identity foung for loggedin user");
			return Status.FAILED.name();
		}
		User user = userService.getUserByIdentity(userIdentity);

		if (null == user) {
			logger.error("No user foung for Id {}", userIdentity);
			return Status.FAILED.name();
		}
		logger.debug("User found is {} ", user.getIdentity());
		UserCredentials userCredentials = null;
		try {
			userCredentials = credentialsSevice
					.getCredentialsByUserIdentity(userIdentity);
			if (oldAuthenticationInfo instanceof String){
				boolean status = credentialsSevice.updatePassword(userCredentials,
						newPassword, (String) oldAuthenticationInfo);
				if(!status){
					return Status.FAILED.name();
				}
			}else{
				credentialsSevice.updatePassword(userCredentials.getIdentity(),
						newPassword,
						(Map<String, String>) oldAuthenticationInfo);
			}
		} catch (InvalidUserException e) {
			logger.error("Unable to update password {}", e);
			//e.printStackTrace();
			if("old password is incorrect".equals(e.getDescription())){
				return "password-incorrect";
			}
			return Status.FAILED.name();
		}
		return Status.SUCCESS.name();
	}

	@Override
	public UserCredentials verifyUser(UserDTO userDto) {
		UserCredentials credentials;
		try {
			credentials = credentialsSevice.getCredentialsByUserNameIgnoreCase(userDto
					.getUserName());
		} catch (InvalidUserException e) {
			e.printStackTrace();
			return null;
		}
		logger.debug("User is verified");
		return credentials;
	}

	@Override
	public boolean verifyUserSecurityInfo(UserDTO userDTO) {
		boolean isValidSecInfo = false;
		try {
			UserCredentials credentials = credentialsSevice
					.getCredentialsByUserIdentity(userDTO.getIdentity());
			isValidSecInfo = credentialsSevice.isCredentialsSecInfoValid(
					credentials.getIdentity(), userDTO.getUserSecurityInfo());
		} catch (InvalidUserException e) {
			isValidSecInfo = false;
			e.printStackTrace();
		}
		return isValidSecInfo;
	}

	@Override
	public boolean removeUser(List<String> userIdentity) {

		return userService.removeUser(userIdentity);
	}

	public class AssociateBusinessEntity implements UserManagementTask {
		private final BusinessEntity businessEntity;
		private final User user;

		public AssociateBusinessEntity(BusinessEntity businessEntity, User user) {
			super();
			this.user = user;
			this.businessEntity = businessEntity;
		}

		@Override
		public User execute() {
			userService.associate(Collections.singleton(businessEntity), user);
			return user;
		}

	}

	public class AssociateBusinessEntityAndUpdateUser implements
			UserManagementTask {
		protected final BusinessEntity businessEntity;
		protected final String userIdentity;

		public AssociateBusinessEntityAndUpdateUser(
				BusinessEntity businessEntity, String userIdentity) {
			super();
			this.userIdentity = userIdentity;
			this.businessEntity = businessEntity;
		}

		@Override
		public User execute() {
			return userService.associateAndUpdate(userIdentity,
					Collections.singleton(businessEntity));

		}
	}

	public AssociateBusinessEntityAndUpdateUser associateUpdateBusinessEntityTask(
			BusinessEntity be, String userIdentity) {
		return new AssociateBusinessEntityAndUpdateUser(be, userIdentity);
	}

	public AssociateBusinessEntity associateBusinessEntityTask(
			BusinessEntity be, User user) {
		return new AssociateBusinessEntity(be, user);
	}

	@Transactional
	public void executeUserTasks(Set<UserManagementTask> tasks) {
		for (UserManagementTask userManagementTask : tasks) {
			userManagementTask.execute();
		}
	}

	private Set<String> getBEDefaultRole(String code) {
		Role role = roleService.getRoleByRoleCode(code);
		if (null == role) {
			throw new IllegalAccessError("Invalid BE type");
		}
		return Collections.singleton(role.getIdentity());
	}

	@Override
	public DefaultAccessToken createFixedAccessTokenForApp(String appkey) {
		if (null == appkey) {
			logger.debug("missing app key");
		}

		return accessTokenService.createFixedAccessToken(appkey);
	}

	@Override
	public List<UserCredentials> getUserCredentialByUserIdentity(String userId) {
		
		return userService.getUserCredentialByUserIdentity(userId);
	}

	@Override
	public void addUser(RegistrationFormDTO registrationFormDTO) {
		final AccessToken token = Utils.getAccessToken();
		logger.debug("access token is {}", token);
		logger.debug("Draft user identifier :- {}",token.getTokenAttributes().get(BillingConstant.DRAFT_USER_REFERENCE));
		final DraftUser draftUser = draftUserMongoRepository.findByIdentifier(token.getTokenAttributes().get(BillingConstant.DRAFT_USER_REFERENCE));
		logger.debug("Draft user is {}", draftUser);
		if(draftUser == null){
			logger.error("Draft User can not be null");
			throw new IllegalStateException("Draft User can not be null. Token expired. Contact customer care.");
		}
		WFMUserCredentials wfmUserCredentials = null;
		try{
			wfmUserCredentials = credentialsSevice.getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseName(registrationFormDTO.getUserName(), AuthWebUtil.defaultIdpKey(), registrationFormDTO.getEnterpriseName());
		}
		catch(InvalidUserException e){
			logger.debug("User credentials not created already, will be created now.");
		}
		if(wfmUserCredentials != null){
			logger.error("User name already exists for this enterprise.");
			throw new UserCredentialAlreadyExistsException("Username already exists.");
		}
		wfmUserCredentials = userService.createAndGetUserCredentials(registrationFormDTO);
		User user = createAndGetUserUsingDraftUser(draftUser);
		
		UserTenantInfo userTenantInfo = userTenantInfoRepository.findByIdentity(user.getIdentity());
		wfmUserCredentials.setUserTenantInfo(userTenantInfo);
		userService.saveWFMUserCredentials(wfmUserCredentials);
		
		AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, user.getIdentity(), 
				user.getIdentity(), null, null, AuditMessageDefinition.USER_ADDED, 
				"displayName",user.getProfile().getDisplayName(),"userType",draftUser.getUserType().getType());			
	}

	@Override
	public User createAndGetUserUsingDraftUser(final DraftUser draftUser) {
		final UserType userType = draftUser.getUserType();
		if(userType == null){
			logger.error("User type can not be null");
			throw new IllegalStateException("User Type can not be null.");
		}
		logger.debug("user type is {}", userType);
		User user = userService.getUserByExternalId(draftUser.getIdentifier());
		logger.debug("user from repo is {}", user);
		switch (userType) {
		case Administrator: {
			logger.debug("administrator case");
			user = createAdministrator(draftUser, user);
			break;
		}
		case Manager: {
			logger.debug("manager case");
			if(draftUser.getBeExternalIds() == null || draftUser.getBeExternalIds().size() == 0){
				logger.error("No Be to manage.");
				throw new IllegalStateException("No Be to manage.");
			}
			final String beExternalId = draftUser.getBeExternalIds().iterator().next();
			logger.debug("be external id", beExternalId);
			final BusinessEntity be = userService.getBEFromExternalId(beExternalId);
			user = userService.getBEManagesUser(be, null);
			if(user == null){
				PersonalProfile profile = copyProfile(draftUser);
				user = Manager.createNewManager(Utils.generateKey(), profile, draftUser.getRoles());
				((Manager) user).setManagesBEofTypes(draftUser.getManagesBEofTypes());
				user.setStatus(UserStatus.ACTIVE);
				((Manager) user).associate(be);
			}else{
				logger.error("This BE: with externalIs as : {} already has a manager",beExternalId);
				throw new UserAlreadyExistsException("This BE: with externalIs as : "+beExternalId+ "already has a manager");
			}
			break;
		}
		default:
			break;
		}
		userService.addUser(user);
		return user;
	}

	private User createAdministrator(final DraftUser draftUser, User user) {
		if(user == null){
			PersonalProfile profile = copyProfile(draftUser);
			user = Administrator.createNewAdministrator(Utils.generateKey(), draftUser.getIdentifier(), profile, draftUser.getRoles(), UserStatus.ACTIVE);
		}
		return user;
	}

	private PersonalProfile copyProfile(final DraftUser draftUser) {
		PersonalProfile profile = new PersonalProfile();
		PersonalProfile draftUserProfile = draftUser.getProfile();
		updateProfileEmail(draftUser, profile);
		updateProfileAddresses(draftUser,profile);
		updateContactNumbers(draftUser, profile);
		updateContactPersons(draftUser, profile);
		profile.setCommunicationLanguage(draftUserProfile.getCommunicationLanguage());
		profile.setDateOfBirth(draftUserProfile.getDateOfBirth());
		profile.setFirstName(draftUserProfile.getFirstName());
		profile.setGender(draftUserProfile.getGender());
		profile.setLastName(draftUserProfile.getLastName());
		profile.setMiddleName(draftUserProfile.getMiddleName());
		profile.setDisplayName(draftUserProfile.getDisplayName());
		profile.setPrefix(draftUserProfile.getPrefix());
		profile.setSpokenLanguage(draftUserProfile.getSpokenLanguage());
		profile.setSuffix(draftUserProfile.getSuffix());
		profile.setTitle(draftUserProfile.getTitle());
		profile.setStatus(Status.SUCCESS);
		return profile;
	}
	
	private void updateContactPersons(DraftUser draftUser, PersonalProfile profile) {
		PersonalProfile profileFromDraftUser = draftUser.getProfile();
		Collection<ContactPerson> contactPersons = new ArrayList<ContactPerson>();
		if(profileFromDraftUser.getContactPersons() !=null && profileFromDraftUser.getContactPersons().getContacts() != null){
			for (ContactPerson contactPerson : profileFromDraftUser.getContactPersons().getContacts()) {
				ContactPerson tempContactPerson = new ContactPerson();
				tempContactPerson.setType(contactPerson.getType());
				contactPersons.add(tempContactPerson);
			}
			ContactSet<ContactPerson> contactPersonContacts = new ContactSet<ContactPerson>(contactPersons);
			profile.setContactPersons(contactPersonContacts);
		}
	}
	
	private void updateContactNumbers(DraftUser draftUser, PersonalProfile profile) {
		PersonalProfile profileFromDraftUser = draftUser.getProfile();
		Collection<ContactNumber> contactNumbers = new ArrayList<ContactNumber>();
		if(profileFromDraftUser.getContactNumbers() !=null && profileFromDraftUser.getContactNumbers().getContacts() != null){
			for (ContactNumber number : profileFromDraftUser.getContactNumbers().getContacts()) {
				ContactNumber tempContactNumber = ContactNumber.newContactNumber(number.getNumber(), number.getCategory().name(), number.getType().name());
				tempContactNumber.setExtension(number.getExtension());
				contactNumbers.add(tempContactNumber);
			}
			ContactSet<ContactNumber> contactNumbersContacts = new ContactSet<ContactNumber>(contactNumbers);
			profile.setContactNumbers(contactNumbersContacts);
		}
	}

	private void updateProfileAddresses(DraftUser draftUser, PersonalProfile profile) {
		PersonalProfile profileFromDraftUser = draftUser.getProfile();
		Collection<Address> addressess = new ArrayList<Address>();
		if(null != profileFromDraftUser.getAddressess() && null != profileFromDraftUser.getAddressess().getContacts()){
			for (Address address2 : profileFromDraftUser.getAddressess().getContacts()) {
				Address tempAddress = new Address();
				tempAddress.setAddressLine1(address2.getAddressLine1());
				tempAddress.setAddressline2(address2.getAddressLine2());
				tempAddress.setAddressline3(address2.getAddressLine3());
				tempAddress.setAddressType(address2.getAddressType());
				tempAddress.setCity(address2.getCity());
				tempAddress.setCountry(address2.getCountry());
				tempAddress.setCounty(address2.getCounty());
				tempAddress.setState(address2.getState());
				tempAddress.setZipcode(tempAddress.getZipcode());
				addressess.add(tempAddress);
			}
			ContactSet<Address> addressContacts = new ContactSet<Address>(addressess);
			profile.setAddressess(addressContacts);
		}
	}
	
	private void updateProfileEmail(DraftUser draftUser, PersonalProfile profile) {
		Collection<Email> contacts = new ArrayList<>();
		contacts.add(Email.newDefaultEmail(draftUser.getEmail().getEmailId()));
		ContactSet<Email> emails = new ContactSet<Email>(contacts);
		profile.setEmails(emails);
	}

	@Override
	public void deleteTokenAndLogoutAfterProcessCompleted() {
		userService.deleteToken();
		authManager.logout();
	}

	
	@Override
	public void publishUserRegistrationEvent(DraftUser draftUser,BusinessEntity be) 
	{
		logger.debug("creating payload info for user registration");
		UserRegistrationPayload userRegistrationPayload = new UserRegistrationPayload();
		
		String tenantId = ProcessContext.get().getTenantId();
		
		final String clientAppDomain = SecurityUtil.enterpriseToClientAppDomain(tenantId, draftUser.getClientAppId());
		
		if(null == clientAppDomain || clientAppDomain.isEmpty()){
			logger.error("ClientAppDomain is null for BE {} and clientAppId {}", be.externalId(),draftUser.getClientAppId());
			return;
		}
		
		final StringBuilder url = new StringBuilder(clientAppDomain);
		url.append("/").append("user-management/").append("register").append("?tokenId=");
		
		logger.debug("sending email at following domain : {}", url.toString());
		DateTime validTill = new DateTime();
		validTill = validTill.plusDays(Integer.parseInt(tokenValidTime));
		Map<String, String> tokenAttributes = new HashMap<String, String>();
		tokenAttributes.put(BillingConstant.DRAFT_USER_REFERENCE, draftUser.getIdentifier());
		// set permissions
		final Set<Permission> permissions = new HashSet<Permission>();
		for (Role role : draftUser.getRoles()) {
			permissions.addAll(role.getPermissions());
		}
		AccessToken fixedValueToken = accessTokenService.createAnonymousFixedVaueToken(validTill,tenantId, permissions,tokenAttributes);
		final String fixedValueTokenIdentity = fixedValueToken.getIdentity();
		url.append(URLEncoder.encode(fixedValueTokenIdentity));
		userRegistrationPayload.setTokenId(fixedValueTokenIdentity);
		url.append("&client_id=").append(draftUser.getClientAppId());
		logger.debug("Link sent in email : {}", url.toString());
		userRegistrationPayload.setUrl(url.toString());
		logger.debug("Fixed Value Token created for Client User");
		userRegistrationPayload.setTenant(tenantId);
		userRegistrationPayload.setEmailTo(draftUser.getEmail().getEmailId());
		userRegistrationPayload.setBe(be);
		EventUtils.publish(new Event<UserRegistrationPayload>(EventType.NEW_USER_REGISTRATION, userRegistrationPayload));
	}


	@Override
	public DraftUser prepareAndGetDraftUser(final UserCreationDTO userCreationDTO) {
		final DraftUser draftUser = new DraftUser();
		final String draftUserIdentifier = resolveDraftUserIdentifier(userCreationDTO);
		if(!validateDraftUser(userCreationDTO , draftUserIdentifier)){
			return null;
		}
		draftUser.setIdentifier(draftUserIdentifier);
		draftUser.setBeExternalIds(userCreationDTO.getBeExternalIds());
		draftUser.setClientAppId(userCreationDTO.getClientAppId());
		draftUser.setEmail(ProfileUtil.populateEmailId(userCreationDTO.getPersonalProfile()));
		draftUser.setUserType(userCreationDTO.getUserType());
		draftUser.setRoles(roleService.getRolesByIdentities(userCreationDTO.getRoleIdentities()));
		draftUser.setManagesBEofTypes(userCreationDTO.getManagesBEofTypes());
		draftUser.setProfile(userCreationDTO.getPersonalProfile());
		customMongoTemplate.save(draftUser);
		return draftUser;
	}

	private boolean validateDraftUser(UserCreationDTO userCreationDTO, String draftUserIdentifier) {
		if(userCreationDTO.getUserType().equals(UserType.Administrator)){
			return validateAdminUser(draftUserIdentifier);
		}else{
			return validateManager(userCreationDTO);
		}
	}

	private boolean validateManager(UserCreationDTO userCreationDTO) {
		if(validateBEByExternalId(userCreationDTO.getBeExternalIds())){
			return validateRolesByIdentity(userCreationDTO.getRoleIdentities());
		}
		return false;
	}

	private boolean validateBEByExternalId(Set<String> beExternalIds) {
		if(beExternalIds == null || beExternalIds.size() == 0){
			return false;
		}else{
			BusinessEntity be = userService.getBEFromExternalId(beExternalIds.iterator().next());
			if(be == null)
				return false;
		}
		return true;
	}
	
	private boolean validateRolesByIdentity(Set<String> roleIdentities) {
		if(roleIdentities == null || roleIdentities.size() == 0){
			return false;
		}
		return true;
	}

	private boolean validateAdminUser(String draftUserIdentifier) {
		final User user = userService.getUserByExternalId(draftUserIdentifier);
		if(user == null)
			return true;
		else{
			logger.error("Admin user already exists with given draft user identifier.");
			throw new UserAlreadyExistsException("Admin User already exists with external Id :" + draftUserIdentifier);
		}
	}
	
	
	private String resolveDraftUserIdentifier(final UserCreationDTO userCreationDTO) {
		return draftUserIdentifierResolver.resolveDraftUserIdentifier(userCreationDTO);
	}

}
