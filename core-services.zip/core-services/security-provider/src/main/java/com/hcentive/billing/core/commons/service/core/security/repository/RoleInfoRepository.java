package com.hcentive.billing.core.commons.service.core.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.RoleInfo;


public interface RoleInfoRepository extends JpaRepository<RoleInfo,Long> {
	
	public RoleInfo findByCodeAndTenantId(final String roleCode,final String tenantId);

}
