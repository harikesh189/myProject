package com.hcentive.billing.core.commons.api;

import java.util.Map;

import com.hcentive.billing.core.commons.security.Credential;

public class UsernamePassword implements Credential {

	private final String userName;
	private final String password;

	public UsernamePassword(final String userName, final String password) {
		this.userName = userName;
		this.password = password;
	}

	@Override
	public String userIdentity() {
		return userName;
	}

	public String password() {
		return password;
	}

	@Override
	public Map<String, String> sessionParams() {
		// TODO Auto-generated method stub
		return null;
	}
}
