package com.hcentive.billing.core.commons.service.core.security.repository;

import javax.transaction.Transactional;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.core.commons.persistence.factory.repository.VersionAwareJpaRepository;


@Transactional
public interface BusinessEntityRepo extends
VersionAwareJpaRepository<BusinessEntity, Long> {

	public BusinessEntity<Profile> findByIdentity(String identity);
	
	public BusinessEntity<Profile> findByExternalId(String externalId);
}
