package com.hcentive.billing.core.commons.service.core.security.service;

import org.apache.shiro.authc.AuthenticationToken;

import com.hcentive.billing.core.commons.api.UsernamePassword;
import com.hcentive.billing.core.commons.security.shiro.ShiroAuthenticationTokenBuilder;

public class UsernamePasswordTokenBuilder implements
		ShiroAuthenticationTokenBuilder<UsernamePassword> {

	@Override
	public AuthenticationToken build(UsernamePassword credential) {
		final WFMUsernamePasswordToken token = new WFMUsernamePasswordToken(
				credential.userIdentity(), credential.password());
		// token.setRememberMe(true);
		return token;
	}

	@Override
	public Class<UsernamePassword> buildsFromType() {
		return UsernamePassword.class;
	}

}