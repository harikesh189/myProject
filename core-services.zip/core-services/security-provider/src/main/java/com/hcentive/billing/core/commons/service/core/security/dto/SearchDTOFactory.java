package com.hcentive.billing.core.commons.service.core.security.dto;

public class SearchDTOFactory {

	public static UserSearchDto getSearchDTO(String userType) {
		switch (userType) {
		case "Individual": {
			return new IndividualUserSearchDTO();
		}
		case "Broker": {
			return new BrokerUserSearchDTO();
		}
		case "Group": {
			return new GroupUserSearchDTO();
		}
		case "Operator": {
			return new OperatorUserSearchDTO();
		}
		default:
			return null;
		}

	}

}
