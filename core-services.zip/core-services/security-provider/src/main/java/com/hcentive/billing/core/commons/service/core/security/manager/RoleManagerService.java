package com.hcentive.billing.core.commons.service.core.security.manager;

import java.util.Collection;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.service.core.security.dto.RoleDTO;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface RoleManagerService {

	Collection<Permission> getAllPermissions();

	Collection<Permission> getAllPermissions(String roleId);

	Permission addPermission(Permission permission);

	Page<Role> getAllRoles(SearchCriteria searchCriteria);

	Object addRole(RoleDTO role);

	Object updateRole(RoleDTO role);

	void removeRole(Long id);

	Role getRoleByCode(String code);
}
