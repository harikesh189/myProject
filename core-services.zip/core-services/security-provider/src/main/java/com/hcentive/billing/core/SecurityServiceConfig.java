package com.hcentive.billing.core;

import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authz.permission.PermissionResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter;

import com.hcentive.billing.core.commons.api.AnonymousUserTokenBuilder;
import com.hcentive.billing.core.commons.api.ClientUserTokenBuilder;
import com.hcentive.billing.core.commons.api.SecureCacheBasedAccessTokenManager;
import com.hcentive.billing.core.commons.api.SecurityConfigurationsLoader;
import com.hcentive.billing.core.commons.security.AccessTokenManager;
import com.hcentive.billing.core.commons.security.RemoteLoginManager;
import com.hcentive.billing.core.commons.security.SecurityConfigurationManager;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.service.core.security.service.AnonymousUserRealm;
import com.hcentive.billing.core.commons.service.core.security.service.BillingDataRealm;
import com.hcentive.billing.core.commons.service.core.security.service.ClientUserRealm;
import com.hcentive.billing.core.commons.service.core.security.service.CredentialsMatcherService;
import com.hcentive.billing.core.commons.service.core.security.service.IdpTokenBuilder;
import com.hcentive.billing.core.commons.service.core.security.service.IdpUserRealm;
import com.hcentive.billing.core.commons.service.core.security.service.RemoteLoginManagerImpl;
import com.hcentive.billing.core.commons.service.core.security.service.UserCredentialsServiceImpl;
import com.hcentive.billing.core.commons.service.core.security.service.UserCredentialsSevice;
import com.hcentive.billing.core.commons.service.core.security.service.UserService;
import com.hcentive.billing.core.commons.service.core.security.service.UserServiceImpl;
import com.hcentive.billing.core.commons.service.core.security.service.UsernamePasswordTokenBuilder;
import com.hcentive.billing.core.commons.util.AuthWebUtil;

@Configuration
public class SecurityServiceConfig {

	@Autowired
	PermissionResolver permissionResolver;

	@Bean(name="securityConfigurationManager")
	public SecurityConfigurationManager securityConfigurationsLoader(){
		SecurityConfigurationsLoader scl = new SecurityConfigurationsLoader();
		SecurityUtil.set(scl);
		return scl;
	}
	@Bean
	public MethodInvokingFactoryBean configureDefaultIdpName(@Value("${security.idp.default:idp.wfm.hcentive}") String defaultIdpKey) {
		final MethodInvokingFactoryBean factory = new MethodInvokingFactoryBean();
		factory.setTargetClass(AuthWebUtil.class);
		factory.setStaticMethod("com.hcentive.billing.core.commons.util.AuthWebUtil.setDefaultIdpKey");
		final Object[] args = {defaultIdpKey};
		factory.setArguments(args);
		return factory;
	}
	
	@Bean
	public MethodInvokingFactoryBean configureDefaultEnterpriseName( @Value("${security.enterprise.default:default}") String defaultEnterpriseName) {
		final MethodInvokingFactoryBean factory = new MethodInvokingFactoryBean();
		factory.setTargetClass(AuthWebUtil.class);
		factory.setStaticMethod("com.hcentive.billing.core.commons.util.AuthWebUtil.setDefaultEnterpriseName");
		final Object[] args = {defaultEnterpriseName};
		factory.setArguments(args);
		return factory;
	}
	
	@Bean
	public BillingDataRealm billingDataRealm() {
		BillingDataRealm billingDataRealm = new BillingDataRealm();
		billingDataRealm.setPermissionResolver(permissionResolver);
		billingDataRealm.setUserService(userService());
		billingDataRealm.setCredentialsSevice(userCredentialsSevice());
		billingDataRealm.setCredentialsMatcher(getCredentialsMatcher());
		return billingDataRealm;
	}

	@Bean
	public IdpUserRealm idpUserRelam() {
		IdpUserRealm idpUserRealm = new IdpUserRealm();
		idpUserRealm.setPermissionResolver(permissionResolver);
		idpUserRealm.setCredentialsMatcher(getCredentialsMatcher());
		return idpUserRealm;
	}

	@Bean
	public ClientUserRealm clientUserRealm() {
		ClientUserRealm clientUserRealm = new ClientUserRealm();
		clientUserRealm.setPermissionResolver(permissionResolver);
		clientUserRealm.setCredentialsMatcher(getCredentialsMatcher());
		return clientUserRealm;
	}
	
	
	@Bean
	public AnonymousUserRealm anonymousUserRealm(){
		AnonymousUserRealm anonymousUserRealm = new AnonymousUserRealm();
		anonymousUserRealm.setPermissionResolver(permissionResolver);
		anonymousUserRealm.setCredentialsMatcher(getCredentialsMatcher());
		return anonymousUserRealm;
	}

	/**
	 * @return {@link CredentialsMatcher}
	 */
	@Bean
	public CredentialsMatcher getCredentialsMatcher() {
		return new CredentialsMatcherService();
	}

	@Bean
	public UserService userService() {
		return new UserServiceImpl();
	}

	@Bean
	public UserCredentialsSevice userCredentialsSevice() {
		return new UserCredentialsServiceImpl();
	}

	@Bean
	public UsernamePasswordTokenBuilder userNamePasswordTokenBuilder() {
		return new UsernamePasswordTokenBuilder();
	}

	@Bean
	public IdpTokenBuilder idpTokenBuilder() {
		return new IdpTokenBuilder();
	}

	@Bean
	public ClientUserTokenBuilder clientUserTokenBuilder() {
		return new ClientUserTokenBuilder();
	}
	
	@Bean
	public AnonymousUserTokenBuilder anonymousUserTokenBuilder(){
		return new AnonymousUserTokenBuilder();
	}

	@Bean
	public AccessTokenManager accessTokenManager() {
		return new SecureCacheBasedAccessTokenManager();
	}

	@Bean(name="/remote/issueAccessToken")
	public HttpInvokerServiceExporter httpExporter(){
		HttpInvokerServiceExporter exporter = new HttpInvokerServiceExporter();
		exporter.setServiceInterface(RemoteLoginManager.class);
		exporter.setService(remoteLoginManager());
		return exporter;
	}
	
	@Bean
	public RemoteLoginManager remoteLoginManager(){
		RemoteLoginManager remoteLoginManager = new RemoteLoginManagerImpl();
		return remoteLoginManager;
	}
}
