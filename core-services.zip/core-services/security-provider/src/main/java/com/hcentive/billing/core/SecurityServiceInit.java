package com.hcentive.billing.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration.VelocityNonWebConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration.VelocityWebConfiguration;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration.WebMvcAutoConfigurationAdapter;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

import com.hcentive.billing.core.commons.api.ClientAppLoader;
import com.hcentive.billing.core.commons.api.CreateRequestContextFilter;
import com.hcentive.billing.core.commons.api.EnterpriseLoader;
import com.hcentive.billing.core.commons.api.OAuth2Filter;
import com.hcentive.billing.core.commons.api.SecureHttpCreateProcessContextFilter;
import com.hcentive.billing.core.commons.api.SessionContextHandlerInterceptor;
import com.hcentive.billing.core.commons.api.support.HttpRedirectURIResolverSupport;
import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.security.config.AutoConfigureSecurity;
import com.hcentive.billing.core.commons.service.core.security.repository.DraftUserMongoRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.PasswordPolicyRepository;
import com.hcentive.billing.core.commons.service.core.security.web.auth.OAuth2Controller.OAuth2HttpRedirectURIResolver;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;
import com.hcentive.billing.core.commons.service.util.FilterRegistrationUtil;
import com.hcentive.common.inter.service.annotation.EnableInterServiceCall;

@Configuration
@PropertySources({ @PropertySource("file:${baseDir}/config/properties/db.properties"), @PropertySource("file:${baseDir}/config/properties/app.properties"),
        @PropertySource("file:${baseDir}/config/properties/security.properties"), @PropertySource("file:${baseDir}/config/properties/amqp.properties"),  @PropertySource("file:${baseDir}/config/properties/mongodb.properties") })
@ImportResource(value = { "validator.xml" })
@EnableJpaRepositories(basePackages = { "com.hcentive.billing" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EntityScan("com.hcentive.billing")
@ComponentScan(basePackages = { "com.hcentive.billing" },excludeFilters=@Filter(type=FilterType.REGEX,pattern="com.hcentive.billing.core.commons.security.config.AutoConfigureSecurity"))
@EnableAutoConfiguration(exclude = {AutoConfigureSecurity.class,VelocityAutoConfiguration.class,VelocityNonWebConfiguration.class,VelocityWebConfiguration.class })
@EnableWebMvc
@EnableInterServiceCall(basePackagesToScan = { "com.hcentive.billing.core.commons.service.core.security.service"})
@EnableMongoRepositories(basePackages={"com.hcentive.billing.core.commons.starter.persistence.repository"},basePackageClasses = {DraftUserMongoRepository.class,PasswordPolicyRepository.class})
public class SecurityServiceInit extends WebMvcAutoConfigurationAdapter {

	private static final Logger logger = LoggerFactory.getLogger(SecurityServiceInit.class);

	@Value("${baseDir}")
	private String baseDir;

	private static final String jspServletClassName = "org.apache.jasper.compiler.disablejsr199";
	
	@Value(value = "${cookie.based.secured.access.token.based.filter.path:/*}")
	public String cookieBasedSecuredAccessTokenBasedFilterPath;

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		logger.debug("Start::Add resource handlers");
		// registry.addResourceHandler(SecurityConstants.JS_PATTERN)
		// .addResourceLocations("/resources/js/");
		// registry.addResourceHandler(SecurityConstants.CSS_PATTERN)
		// .addResourceLocations("/resources/css/");
		// registry.addResourceHandler(SecurityConstants.IMG_PATTERN)
		// .addResourceLocations("/resources/images/");

		// registry.addResourceHandler("/html/**").addResourceLocations("resources/html");
		logger.debug("End::Add resource handlers");

	}


	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(sessionContextHandlerInterceptor()).addPathPatterns("/**")
		        .excludePathPatterns(new String[] { "/security/*/sctx", "/security/*/user/current" });
		super.addInterceptors(registry);
	}
	
	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
	
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();

	}

	public static void main(String[] args) throws Exception {
		System.setProperty(jspServletClassName, "true");
		SpringApplication.run(SecurityServiceInit.class, args);

	}

	/*
	 * @Bean InternalResourceViewResolver internalResourceViewResolver() {
	 * InternalResourceViewResolver viewResolver = new
	 * InternalResourceViewResolver();
	 * viewResolver.setPrefix("/resources/WEB-INF/jsp/");
	 * viewResolver.setSuffix(".jsp"); return viewResolver; }
	 */

	@Bean
	public CreateRequestContextFilter createRequestContextFilter() {
		return new CreateRequestContextFilter();
	}

	@Bean
	public FilterRegistrationBean createRequestContextFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(createRequestContextFilter(), "/*");
		filterRegistrationBean.setOrder(8);
		return filterRegistrationBean;
	}

	@Bean
	public SecureHttpCreateProcessContextFilter httpCreateProcessContextFilter() {
		return new SecureHttpCreateProcessContextFilter();
	}

	@Bean
	public FilterRegistrationBean createProcessContextFilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(httpCreateProcessContextFilter(), "/*");
		filterRegistrationBean.setOrder(6);
		return filterRegistrationBean;
	}

	@Bean
	public HttpRedirectURIResolverSupport httpRedirectURIResolverSupport() {
		return HttpRedirectURIResolverSupport.INSTANCE;
	}

	@Bean
	public OAuth2HttpRedirectURIResolver oAuth2HttpRedirectURIResolver() {
		return OAuth2HttpRedirectURIResolver.INSTANCE;
	}

	@Bean
	public OAuth2Filter oAuth2Filter() {
		return new OAuth2Filter();
	}

	@Bean
	public FilterRegistrationBean createOAuth2FilterRegistration() {
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(oAuth2Filter(), "/*");
		filterRegistrationBean.setOrder(12);
		return filterRegistrationBean;
	}

	/*@Bean
	public CookieBasedSecuredAccessDataExtractor cookieBasedSecuredAccessDataExtractor() {
		return new CookieBasedSecuredAccessDataExtractor();
	}*/
	
	@Bean
	public SessionContextHandlerInterceptor sessionContextHandlerInterceptor(){
		return new SessionContextHandlerInterceptor();
	}

	/*@Bean
	public FilterRegistrationBean createCookieBasedSecuredDataAccessFilterRegistration() {
		String[] securedAccessPaths = splitFilterPathByComma(cookieBasedSecuredAccessTokenBasedFilterPath);
		final FilterRegistrationBean filterRegistrationBean = FilterRegistrationUtil.createRegistrationBean(cookieBasedSecuredAccessDataExtractor(), securedAccessPaths);
		filterRegistrationBean.setOrder(4);
		return filterRegistrationBean;
	}*/
	
	
	
	@Bean
	public ClientAppLoader clientAppLoader() {
		return new ClientAppLoader();
	}
	
	@Bean
	public EnterpriseLoader enterpriseLoader() {
		return new EnterpriseLoader();
	}
	
	private String[] splitFilterPathByComma(final String securedAccessTokenBasedFilterPath) {
		final String[] filterPaths = securedAccessTokenBasedFilterPath.split(",");
		return filterPaths;
	}
}
