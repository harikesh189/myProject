package com.hcentive.billing.core.commons.api;

import com.hcentive.billing.core.commons.domain.User;

public class UserAlreadyLoggedInException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserAlreadyLoggedInException(User user) {
		super("User with userID : {}" + user.getIdentity()
				+ "already logged in");
	}

}
