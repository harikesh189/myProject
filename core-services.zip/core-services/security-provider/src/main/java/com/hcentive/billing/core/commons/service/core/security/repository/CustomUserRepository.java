package com.hcentive.billing.core.commons.service.core.security.repository;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.ClientUser;
import com.hcentive.billing.core.commons.domain.util.reference.repository.AbstractSearchCriteriaSupportRepositoryImpl;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteriaOnColumns;

@Component
public class CustomUserRepository extends
		AbstractSearchCriteriaSupportRepositoryImpl {

	@Override
	protected StringBuilder totalRecordsCountQueryStr(SearchCriteria criteria,
			Map<Integer, Object> queryParams) {
		final StringBuilder query = new StringBuilder("select count(user.id) from User user where user.isDeleted = false and TYPE(user) != ?1");
		queryParams.put(1, ClientUser.class);
		appendSearchCriterias(criteria, query);
		return query;
	}

	@Override
	protected StringBuilder buildQueryStr(SearchCriteria criteria,
			Map<Integer, Object> queryParams) {
		final StringBuilder query = new StringBuilder("select ").append(
				criteria.populateProjectedFields()).append(" from User user where user.isDeleted = false and TYPE(user) != ?1");
		queryParams.put(1, ClientUser.class);
		appendSearchCriterias(criteria, query);
		return query;
	}
	
	private void appendSearchCriterias(SearchCriteria criteria,
			final StringBuilder query) {
		final Map<String, SearchCriteriaOnColumns> searchCriterias = criteria.getCriteria();
		for (Map.Entry<String, SearchCriteriaOnColumns> entry : searchCriterias.entrySet()) {
			final String key = entry.getKey();
			final SearchCriteriaOnColumns columns = entry.getValue(); 
			query.append(" and ").append("user.").append(key).append(" ").append(columns.getOperator()).append(" ").append(columns.getColumnValue());
		}
	}


}
