package com.hcentive.billing.core.commons.service.core.security.dto;

import java.io.Serializable;

public class PasswordDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3173654924910644480L;

	private String newPassword;

	private String oldPassword;

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

}
