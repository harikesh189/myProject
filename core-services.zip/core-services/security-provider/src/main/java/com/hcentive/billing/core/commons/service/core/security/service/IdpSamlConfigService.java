package com.hcentive.billing.core.commons.service.core.security.service;

import com.hcentive.billing.core.commons.api.IdentityProvider;
import com.hcentive.billing.core.commons.api.IdpSamlConfiguration;

public interface IdpSamlConfigService {

	public IdpSamlConfiguration findByIdentityProvider(
			final IdentityProvider identityProvider);

}
