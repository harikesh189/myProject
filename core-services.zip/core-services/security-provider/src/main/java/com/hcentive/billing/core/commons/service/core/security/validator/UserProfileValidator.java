package com.hcentive.billing.core.commons.service.core.security.validator;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Address;
import com.hcentive.billing.core.commons.domain.ContactNumber;
import com.hcentive.billing.core.commons.domain.Email;
import com.hcentive.billing.core.commons.dto.UserOperation;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.manager.UserManagerImpl;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;

public class UserProfileValidator implements
		Validator<UserDTO, SingleValidationError<UserDTO>> {
	
	private static final Logger logger = LoggerFactory
			.getLogger(UserProfileValidator.class);
	
	@Override
	public SingleValidationError<UserDTO> validate(UserDTO t) {
		logger.debug("Validating User profile..");
		if (t.getOperationsPerformed().contains(UserOperation.UpdateUserProfile)
				|| t.getOperationsPerformed().contains(
						UserOperation.UpdateUserRoles)) {
			//String identity = t.getIdentity();
			if(t.getPersonalProfile()!=null && t.getPersonalProfile().getEmails()!=null){
				 Set<Email> emailSet = t.getPersonalProfile().getEmails().getContacts();
				
				 String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
				 
				 for(Email email : emailSet) { 
					  if(!email.getEmailId().matches(EMAIL_REGEX)){
						  return new SingleValidationError<>("Invalid Email",
									"Invalid Email, please enter correct email.", t);
					  }
				 }
			}
			if(t.getPersonalProfile()!=null && t.getPersonalProfile().getAddressess()!=null){
				 Set<Address> addressSet = t.getPersonalProfile().getAddressess().getContacts();
				 String ZIP_REGEX = "^\\d{5}?$";
				  for(Address address : addressSet) { 
					  if(address.getZipcode()==null || !address.getZipcode().matches(ZIP_REGEX)){
						  return new SingleValidationError<>("Invalid Zip Code",
									"Invalid Zip Code, please enter 5 digit zip code. ", t);
					  }
				 }
			}
			if(t.getPersonalProfile()!=null && t.getPersonalProfile().getContactNumbers()!=null){
			  Set<ContactNumber> contactNumberSet = t.getPersonalProfile().getContactNumbers().getContacts();
			  for(ContactNumber contactNumber : contactNumberSet) { 
				  if(contactNumber.getNumber()==null ||contactNumber.getNumber().equalsIgnoreCase("")){
					  return new SingleValidationError<>("Invalid Contact Number",
								"Invalid Contact Number, please enter correct contact number.", t);
				  }
			 }
			}
			  logger.debug("Validated User profile..");
			  
			
			return null;
		}
		return null;

	}

	@Override
	public String identity() {
		// TODO Auto-generated method stub
		return null;
	}

}
