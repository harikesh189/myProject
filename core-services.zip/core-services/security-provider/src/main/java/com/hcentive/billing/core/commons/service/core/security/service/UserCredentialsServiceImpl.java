package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.EntityManagerHolder;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.hcentive.billing.core.commons.api.ClientUserCredential;
import com.hcentive.billing.core.commons.api.domain.PasswordPolicy;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.domain.IdpUserCredential;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.dto.UserOperation;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.event.UserUpdatePayLoad;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.dto.RegistrationFormDTO;
import com.hcentive.billing.core.commons.service.core.security.repository.ClientUserCredentialRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.IdpUserCredentialRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.PasswordPolicyRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.WFMUserCredentialsRepository;
import com.hcentive.billing.core.commons.service.ebill.audit.handler.AuditUtil;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.util.EncryptionUtil;
import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public class UserCredentialsServiceImpl implements UserCredentialsSevice {

	@Autowired
	private WFMUserCredentialsRepository userCredentialsRepository;
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private IdpUserCredentialRepository idpRepository;

	@Autowired
	private ClientUserCredentialRepository clientUserCredentialRepository;
	
	@Value(value = "${security.error.new.password.matches.old.password:Your new password cannot be same as your current password, or any of your previous 3 passwords.}")
	private String newPasswordMatchesOldPasswordError;
	
	@Value(value = "${security.error.password.contains.username:Password cannot contain Username.}")
	private String passwordContainUserNameError;
	
	@Value(value = "${security.max.failed.attempts:5}")
	private int maxFailedAttempts;
	
	@Value(value = "${security.password.policy.regex.pattern:((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()'+,-./:;<=>?[/]\\\\_{|}~`\" ]).{8,20})}")
	private String passwordPattern;
	
	@Autowired
	protected UserMgmt userMgmt;
	
	@Autowired
	private EntityManagerFactory emf;
	
	@Autowired
	private PasswordPolicyRepository passwordPolicyRepository;
	
	@Value(value = "${security.password.policy.password.expiry.days:90}")
	private int daysAfterWhichPasswordExpires;
	
	@Value(value = "${security.password.policy.validate.against.old.passwords:4}")
	private int noOfOldPasswordsToBeChecked;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(UserCredentialsServiceImpl.class);

	@Override
	public UserCredentials getCredentialsByUserNameIgnoreCase(String username)
			throws InvalidUserException {
		WFMUserCredentials credentials = userCredentialsRepository
				.getByUserNameIgnoreCase(username);
		if (null == credentials) {
			throw new InvalidUserException("Invalid username",
					"Invalid username", "Invalid username");
		}
		return credentials;
	}

	@Override
	public UserCredentials getCredentialsByIdentity(String identity)
			throws InvalidUserException {
		UserCredentials credentials = userCredentialsRepository
				.findByIdentity(identity);
		if (null == credentials)
			throw new InvalidUserException("Invalid identity",
					"Invalid identity", "Invalid identity");

		return credentials;
	}

	@Override
	public boolean isCredentialsSecInfoValid(String identity,
			Map<String, String> secInfo) throws InvalidUserException {
		LOGGER.debug("Verify user security Info for Credentials identity  {} ",
				identity);
		UserCredentials credentials = getCredentialsByIdentity(identity);
		checkWFMCredentials(credentials);
		if (null == secInfo || secInfo.isEmpty()) {
			LOGGER.error("No security question found");
			return false;
		}
		boolean isVerified = false;
		for (Map.Entry<String, String> entry : secInfo.entrySet()) {
			isVerified = ((WFMUserCredentials) credentials).matchSecurityInfo(
					entry.getKey(), entry.getValue());
			LOGGER.debug("Anser of question {} is {}", entry.getKey(),
					isVerified);
			if (!isVerified)
				break;
		}
		return isVerified;
	}

	private void checkWFMCredentials(UserCredentials credentials)
			throws InvalidUserException {
		if (!(credentials instanceof WFMUserCredentials))
			throw new InvalidUserException(
					"Invalid WFM UserCredentials identity",
					"Invalid WFM UserCredentials",
					"Invalid WFM UserCredentials");
	}

	@Override
	public boolean addUserCredentials(UserCredentials userCredentials)
			throws InvalidUserException {
		if (null != userCredentialsRepository.findByIdentity(userCredentials
				.getIdentity())) {
			throw new InvalidUserException("User identity already exist",
					"User identity already exist",
					"User identity already exist");
		}
		WFMUserCredentials wfmCredentials = (WFMUserCredentials) userCredentials;
		if (wfmCredentials.getUsername() == null
				|| wfmCredentials.getUsername().isEmpty()
				|| null != userCredentialsRepository
						.getByUserNameIgnoreCase(wfmCredentials.getUsername())) {
			throw new InvalidUserException("User name already exist",
					"User name already exist", "User name already exist");
		}
		userCredentialsRepository.save(wfmCredentials);
		return true;
	}
	
	private boolean validatePasswordAgainstPolicy(final String password) {
		Pattern pattern = Pattern.compile(passwordPattern);
		Matcher matcher = pattern.matcher(password);
		return matcher.matches();
	}

	@Override
	public boolean updatePassword(UserCredentials credentials, String newPassword,
			String oldPassword) throws InvalidUserException {
		LOGGER.debug("credentials found are  {}", credentials.getId());
		if(!validatePasswordAgainstPolicy(newPassword)){
			LOGGER.error("Invalid Password. Doesnot match against policy");
			throw new IllegalArgumentException("Invalid Password. Doesnot match against policy");
		}
		
		checkWFMCredentials(credentials);
		WFMUserCredentials wfmcred = (WFMUserCredentials) credentials;
		if(!EncryptionUtil.oneWayCheckPassword(oldPassword, wfmcred.getPassword())){
			LOGGER.error("Invalid Password. Current password did'nt match enetered password");
			return false;
		}
		LOGGER.debug("WFM credentials found are  {}", wfmcred.getUsername());
		final PasswordPolicy passwordPolicy = passwordPolicyRepository.findByUserCredentialsRef(getUserCredentialsReference(wfmcred));
		if(null != passwordPolicy){
			SingleValidationError<UserCredentials> passwordPolicyError = checkPasswordPolicy(wfmcred, newPassword,passwordPolicy);
			if(passwordPolicyError!=null){
				return false;
			}
		}

		return updatePassword(newPassword, wfmcred , passwordPolicy);
	}

	private boolean updatePassword(String newPassword,
			WFMUserCredentials wfmcred, PasswordPolicy passwordPolicy) {
		wfmcred.changePassword(wfmcred, newPassword);
		wfmcred = userCredentialsRepository.save(wfmcred);
		LOGGER.debug("Publisihig update password event::{}",
				wfmcred.getIdentity());
		updatePasswordPolicy(wfmcred, passwordPolicy);
		fireUpdateUserPasswordEvent(wfmcred);
		return true;

	}

	private boolean updatePassword(String newPassword,
			WFMUserCredentials wfmcred) {
		wfmcred.changePassword(wfmcred, newPassword);
		wfmcred = userCredentialsRepository.save(wfmcred);
		LOGGER.debug("Publisihig update password event::{}",
				wfmcred.getIdentity());
		fireUpdateUserPasswordEvent(wfmcred);
		return true;
	}

	private void fireUpdateUserPasswordEvent(WFMUserCredentials wfmcred) {
		UserUpdatePayLoad payload = createPayload(UserOperation.UpdatePassword,
				wfmcred.getUserTenantInfo().getIdentity(), "", "",wfmcred.getUserTenantInfo().getExternalId());
		
		audit(payload);
		
		Event<UserUpdatePayLoad> event = new Event<UserUpdatePayLoad>(
				EventType.UPDATE_USER_PASSWORD, payload);
		EventUtils.publish(event);
	}
	
	private void audit(UserUpdatePayLoad pwdUpdate) {
		AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, pwdUpdate.getUserIdentity(), 
				null, null, null, AuditMessageDefinition.USER_PWD_UPDATED, 
				"updatedUserId", pwdUpdate.getUser().getExternalId());
	}

	private UserUpdatePayLoad createPayload(UserOperation userOperation,
			String userId, Object oldEntity, Object updatedEntity,String externalId) {
		User user = new User();
		user.setExternalId(externalId);
		UserUpdatePayLoad userUpdatePayLoad = new UserUpdatePayLoad(user);
		userUpdatePayLoad.setUserIdentity(userId);
		userUpdatePayLoad.setUserOperation(userOperation);
		userUpdatePayLoad.setOldEntity(oldEntity);
		userUpdatePayLoad.setNewEntity(updatedEntity);
		return userUpdatePayLoad;
	}

	@Override
	public boolean updatePassword(String identity, String newPassword,
			Map<String, String> securityInfo) throws InvalidUserException {
		if(!validatePasswordAgainstPolicy(newPassword)){
			LOGGER.error("Invalid Password. Doesnot match against policy");
			throw new IllegalArgumentException("Invalid Password. Doesnot match against policy");
		}
		UserCredentials credentials = getCredentialsByIdentity(identity);
		checkWFMCredentials(credentials);
		return updatePassword(newPassword, (WFMUserCredentials) credentials);
	}

	@Override
	public boolean updateSecInfo(String identity, Map<String, String> secInfo)
			throws InvalidUserException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public UserCredentials getCredenialsBySearchCriteria(
			SearchCriteria searchCriteria) throws InvalidUserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserCredentials getCredentialsByUserIdentityAndEnterprise(String userIdentity, String enterprise)
			throws InvalidUserException {
		List<WFMUserCredentials> credentials = userCredentialsRepository
				.getByUserTenantInfoIdentityAndEnterpriseName(userIdentity,enterprise);
		if (null == credentials || credentials.isEmpty()
				|| credentials.size() > 1) {
			throw new InvalidUserException("Invalid username",
					"Invalid username", "Invalid username");
		}
		return credentials.iterator().next();
	}

	@Override
	public boolean isWFMUserRegistered(String identity) {
		List<UserCredentials> credentials = userCredentialsRepository
				.getByUserTenantInfoIdentity(identity);
		if (credentials.isEmpty())
			return false;
		for (UserCredentials userCredentials : credentials) {
			if (userCredentials instanceof WFMUserCredentials)
				return true;

		}
		return false;
	}

	@Override
	public IdpUserCredential getCredentialByIdpUserIdentityAndIdpKeyAndEnterpriseName(
			final String idpUserIdentity, final String idpKey,final String enterpriseName)
			throws InvalidUserException {
		IdpUserCredential idpUserCredential = idpRepository
				.findByIdpUserIdentityAndIdpKeyAndEnterpriseName(idpUserIdentity, idpKey,enterpriseName);
		if (idpUserCredential == null) {
			LOGGER.debug("Invalid idp User");
			// throw new InvalidUserException("Invalid idp User",
			// "Invalid idp User", "Invalid idp User");
		}
		return idpUserCredential;
	}

	@Override
	public boolean isIDPUserRegistered(String userIdentity) {
		List<UserCredentials> credentials = idpRepository
				.getByUserTenantInfoIdentity(userIdentity);
		if (credentials.isEmpty())
			return false;
		for (UserCredentials userCredentials : credentials) {
			if (userCredentials instanceof IdpUserCredential)
				return true;

		}
		return false;

	}

	@Override
	public IdpUserCredential addIDPUserCredentials(IdpUserCredential credential) {
		if (idpRepository.findByIdentity(credential.getIdentity()) != null) {
			LOGGER.debug("IDP Credential already exists");
			throw new IllegalAccessError();
		}
		return idpRepository.save(credential);
	}

	@Override
	public ClientUserCredential getBySecretKey(final String secretKey) {
		LOGGER.debug("Getting Client User for Secret Key: {}", secretKey);
		return clientUserCredentialRepository.findBySecretKey(secretKey);
	}

	@Override
	public IdpUserCredential findByUserId(Long id) {
		LOGGER.debug("Finding IdpUserCredential for userId : {}", id);
		return idpRepository.findByUserTenantInfoId(id);
	}

	@Override
	public WFMUserCredentials getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseName(
			final String username, final String idpKey , final String enterpriseName) {
		LOGGER.debug("Going to fetch user credentials:" + username);
		WFMUserCredentials credentials = userCredentialsRepository
				.getByUserNameIgnoreCaseAndIdpKeyAndEnterpriseName(username,idpKey,enterpriseName);
		if (null == credentials) {
			LOGGER.error("Invalid Credential");
			throw new InvalidUserException("Invalid username",
					"Invalid username", "Invalid username");
		}
		LOGGER.debug("Returning from credential");
		return credentials;
	}

	@Override
	public WFMUserCredentials getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseNameAndPassword(
			String username, String idpKey, String enterpriseName,
			String password) {
		LOGGER.trace("In getCredentialsByUserNameAndIdpKeyAndEneterpriseNameAndPassword");
		WFMUserCredentials credentials = userCredentialsRepository
				.getByUserNameIgnoreCaseAndIdpKeyAndEnterpriseName(username,idpKey,enterpriseName);
		if (null != credentials) {
			boolean result = EncryptionUtil.oneWayCheckPassword(
					password,
					credentials.getPassword());
			if(result){
				LOGGER.trace("Returning from credential");
				return credentials;
			}else{
				int failedAttempts = credentials.getFailedAttempts();
				failedAttempts++;
				if(maxFailedAttempts == failedAttempts){
					UserTenantInfo userTenantInfo = credentials.getUserTenantInfo();
					LOGGER.debug("User Tenant Info : {}",userTenantInfo);
					final String tenantId = userTenantInfo.getTenantId();
					LOGGER.debug("Tenant is : {}",tenantId);
					final EntityManagerHolder emHolder = (EntityManagerHolder) TransactionSynchronizationManager.getResource(emf);
					LOGGER.debug("emHolder is : {}",emHolder);
					final EntityManager entityManager = emHolder.getEntityManager();
					entityManager.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, tenantId);
					LOGGER.debug("Fetching User");
					User user =  userMgmt.findById(userTenantInfo.getId());
					user.setStatus(UserStatus.INACTIVE);
					userMgmt.updateUser(user);
					credentials.setFailedAttempts(0);
					userCredentialsRepository.save(credentials);
					entityManager.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, ProcessContext.get().getTenantId());
				}else{
					LOGGER.debug("Updating Failed Attempts : {}",failedAttempts);
					credentials.setFailedAttempts(failedAttempts);
					userCredentialsRepository.save(credentials);
				}
				LOGGER.trace("Password Failed");
			}
			
		}
		LOGGER.error("Invalid Credential");
		throw new InvalidUserException("Invalid username",
				"Invalid username", "Invalid username");
		
	}


	@Override
	//@RequiresPermissions(value = Permission.FORGOT_PASSWORD)
	public SingleValidationError<UserCredentials> updatePassword(String username, String idpKey,
			String enterpriseName, String newPassword) {
		if(!validatePasswordAgainstPolicy(newPassword)){
			LOGGER.error("Invalid Password. Doesnot match against policy");
			throw new IllegalArgumentException("Invalid Password. Doesnot match against policy");
		}
		WFMUserCredentials userCredentials = getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseName(username, idpKey, enterpriseName);
		if(userCredentials == null){
			LOGGER.error("Ilegal Access as no such user credentials exist for enterprise {} , idp {} and username {}",enterpriseName,idpKey,username);
			throw new IllegalAccessError("User Credentials does not exist");
		}
		final PasswordPolicy passwordPolicy = passwordPolicyRepository.findByUserCredentialsRef(getUserCredentialsReference(userCredentials));
		if(null != passwordPolicy){
			SingleValidationError<UserCredentials> passwordPolicyError = checkPasswordPolicy(userCredentials, newPassword,passwordPolicy);
			if(passwordPolicyError!=null){
				return passwordPolicyError;
			}
		}
		
		LOGGER.debug("Encrypting Password");
		WFMUserCredentials.changePassword(userCredentials, newPassword);
		LOGGER.debug("Updating password");
		userCredentialsRepository.save(userCredentials);
		updatePasswordPolicy(userCredentials, passwordPolicy);
		return null;
	}

	private void updatePasswordPolicy(WFMUserCredentials userCredentials,
			final PasswordPolicy passwordPolicy) {
		if(null != passwordPolicy){
			LOGGER.debug("Updating password policy");
			String[] oldPasswords = passwordPolicy.getStoredPasswords();
			int oldPasswordsArraySizeToBuild = 0;
			if(oldPasswords.length < noOfOldPasswordsToBeChecked){
				oldPasswordsArraySizeToBuild = oldPasswords.length + 1;
			}else{
				oldPasswordsArraySizeToBuild = noOfOldPasswordsToBeChecked;
			}
			final String[] updatedOldPasswords = new String[oldPasswordsArraySizeToBuild];
			for (int i = oldPasswordsArraySizeToBuild - 1 ; i > 0 ; i-- ) {
				updatedOldPasswords[i] = oldPasswords[i-1];
			}
			updatedOldPasswords[0] = userCredentials.getPassword();
			passwordPolicy.setStoredPasswords(updatedOldPasswords);
			passwordPolicy.setCurrentPasswordExpiry(new DateTime().plusDays(daysAfterWhichPasswordExpires));
			LOGGER.debug("Password Policy Updated");
			passwordPolicyRepository.save(passwordPolicy);
		}else{
			LOGGER.debug("Creating new password policy");
			createPasswordPolicy(userCredentials);
		}
		
	}
	
	private SingleValidationError<UserCredentials> checkPasswordPolicy(WFMUserCredentials usrCredentials, String newPassword, final PasswordPolicy passwordPolicy){
		
		String[] oldPasswords = passwordPolicy.getStoredPasswords();
		
		for (String oldPassword : oldPasswords) {
			if(EncryptionUtil.oneWayCheckPassword(newPassword, oldPassword)){
				LOGGER.error("New Password cannot be not be equal to last 4 saved passwords.");
				String errorCode = "PASSWORD_POLCIY_PASSWORD_EQUAL_ERROR";
				return new SingleValidationError<UserCredentials>(errorCode, newPasswordMatchesOldPasswordError, usrCredentials);
			}
		}
		
		if(newPassword.contains(usrCredentials.getUsername())){
			LOGGER.error("Password cannot contain username.");
			String errorCode = "PASSWORD_POLICY_USERNAME_ERROR";
			return new SingleValidationError<UserCredentials>(errorCode, passwordContainUserNameError, usrCredentials);
		}
		return null;
	}

	@Override
	public UserCredentials getCredentialsByUserIdentity(String userIdentity)
			throws InvalidUserException {
		// Using Tenant as default Enterprise
		return getCredentialsByUserIdentityAndEnterprise(userIdentity, TenantUtil.getTenantId());
	}
	
	@Override
	public WFMUserCredentials createAndGetWFMUserCredentials(
			RegistrationFormDTO registrationFormDTO) {
		if(!validatePasswordAgainstPolicy(new String(registrationFormDTO.getPassword()))){
			LOGGER.error("Invalid Password. Doesnot match against policy");
			throw new IllegalArgumentException("Invalid Password. Doesnot match against policy");
		}
		WFMUserCredentials wfmUserCredentials = WFMUserCredentials
				.createNewCredential().withExternalId(Utils.generateKey())
				.withIdentity(Utils.generateKey())
				.forEnterprise(registrationFormDTO.getEnterpriseName())
				.withPassword(new String(registrationFormDTO.getPassword()))
				.forUserName(registrationFormDTO.getUserName()).build();
		LOGGER.debug("Credentials created successfully");
		createPasswordPolicy(wfmUserCredentials);
		return wfmUserCredentials;
	}

	private void createPasswordPolicy(WFMUserCredentials wfmUserCredentials) {
		LOGGER.debug("Creating Passsword Policy Document");
		PasswordPolicy policy = new PasswordPolicy(getUserCredentialsReference(wfmUserCredentials));
		policy.setCurrentPasswordExpiry(new DateTime().plusDays(daysAfterWhichPasswordExpires));
		policy.setStoredPasswords(new String[]{wfmUserCredentials.getPassword()});
		passwordPolicyRepository.save(policy);
		LOGGER.debug("Password Policy Document Created");
	}

	private String getUserCredentialsReference(final WFMUserCredentials wfmUserCredentials) {
		LOGGER.debug("Getting Unique ref id");
		final StringBuilder userCredentialsRefBuilder = new StringBuilder(wfmUserCredentials.getEnterpriseName());
		userCredentialsRefBuilder.append("_").append(wfmUserCredentials.getUsername());
		LOGGER.debug("Unique Ref ID :{}",userCredentialsRefBuilder);
		return userCredentialsRefBuilder.toString();
	}
	
	@Override
	public PasswordPolicy getPasswordPolicyForUserCredentials(final WFMUserCredentials wfmUserCredentials){
		LOGGER.debug("Getting password policy document");
		final PasswordPolicy passwordPolicy = passwordPolicyRepository.findByUserCredentialsRef(getUserCredentialsReference(wfmUserCredentials));
		LOGGER.debug("Returning password policy document");
		return passwordPolicy;
	}
	
	@Override
	public WFMUserCredentials getCredentialsByUserNameIgnoreCaseAndEneterpriseName(
			final String username,  final String enterpriseName){
		WFMUserCredentials credentials = userCredentialsRepository.getByUserNameIgnoreCaseAndEnterpriseName(username,enterpriseName);
		if (null == credentials) {
			throw new InvalidUserException("Invalid username",
					"Invalid username", "Invalid username");
		}
		return credentials;
	}
}
