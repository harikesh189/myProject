package com.hcentive.billing.core.commons.service.core.security.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcentive.billing.core.commons.api.ClientAppService;
import com.hcentive.billing.core.commons.api.SessionContext;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.exception.AuthenticationFailed;
import com.hcentive.billing.core.commons.security.exception.AuthorizationDenied;
import com.hcentive.billing.core.commons.security.exception.SessionTimedOut;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.web.WebUtils;

@Controller
@RequestMapping("/security")
public class ErrorHandlerController {

	private static final Logger logger = LoggerFactory
			.getLogger(ErrorHandlerController.class);

	@Autowired
	private ClientAppService clientAppService;

	@Autowired
	private Environment env;

	@Value(value = "${security.error.session.timed.out:Session Timed Out.}")
	private String sessionTimedOutError;
	
	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;
	
	@Autowired
	private AuthManager authManager;
	
	@RequestMapping("/{enterpriseName}/error/{errorCode}")
	public String handleError(@PathVariable("errorCode") int errorCode,  @PathVariable("enterpriseName") String enterpriseName,final HttpServletRequest request){
		return "redirect:" + getRedirectUrlAndDoLogin(errorCode,
				enterpriseName, request);
	}

	private StringBuilder getRedirectUrlAndDoLogin(int errorCode, String enterpriseName,
			final HttpServletRequest request) {
		final StringBuilder redirectUrlBuilder = buildRedirectUrl(request,
				enterpriseName).append("/#/error/").append(errorCode);
		authManager.doLoginForLoginTrustedEntity(AnonymousUserIdentity.LOGIN_USER_IDENTITY);
		return redirectUrlBuilder;
	}
	
	@RequestMapping("/error/{errorCode}")
	public String handleErrorWithoutEnterprise(@PathVariable("errorCode") int errorCode, final HttpServletRequest request){
		return "redirect:" + getRedirectUrlAndDoLogin(errorCode,
				AuthWebUtil.defaultEnterpriseName(), request);
	}
	
	@RequestMapping("/{enterpriseName}/error/501")
	public String handleNotImplementedError( @PathVariable("enterpriseName") String enterpriseName, final HttpServletRequest request){
		return "redirect:" + getRedirectUrlAndDoLogin(501,
				enterpriseName, request); 
	}
	
	@RequestMapping("/error/501")
	public String handleNotImplementedErrorWithOutEnterprise( final HttpServletRequest request){
		return "redirect:" + getRedirectUrlAndDoLogin(501,
				AuthWebUtil.defaultEnterpriseName(), request); 
	}
	

	/**
	 * @param request
	 * @param mav
	 */
	@RequestMapping("/{enterpriseName}/error/"+AuthorizationDenied.ERROR_CODE)
	public String handleAuthorizationError(final HttpServletRequest request , @PathVariable("enterpriseName") String enterpriseName) {
		final StringBuilder redirectUrlBuilder = buildRedirectUrl(request,
				enterpriseName).append("/#/accessDenied");
		popuateCookie(request);
		return "redirect:" + redirectUrlBuilder.toString(); 
	}

	private StringBuilder buildRedirectUrl(final HttpServletRequest request,
			String enterpriseName) {
		final StringBuilder redirectUrlBuilder = new StringBuilder(WebUtils.getBaseUrl(request));
		redirectUrlBuilder.append("/").append(enterpriseName).append("/").append(securityUIAppKey).append("/")
			.append("?client_id=").append(request.getParameter("client_id")).append("&response_type=token");
		return redirectUrlBuilder;
	}

	private void popuateCookie(final HttpServletRequest request) {
		final AccessToken accessToken = Utils.getAccessToken();
		AuthWebUtil.populateSessionContext(accessToken.getIdentity(),securityUIAppKey);
	}
	
	@RequestMapping("/{enterpriseName}/error/"+SessionTimedOut.ERROR_CODE)
	public String handleSessionTimeOut(final HttpServletRequest request, final HttpServletResponse response , 
			@PathVariable("enterpriseName") final String enterpriseName ) {
		SessionContext sessionContext = SessionContext.get();
		sessionContext.invalidateSession();
		return AuthWebUtil.createForwardToPathFromController("oAuth2/initiate")
				+ "?errorMessage="
				+ SessionTimedOut.ERROR_CODE+"&errorMessage="+sessionTimedOutError;
	}
	
	@RequestMapping("/{enterpriseName}/error/"+AuthenticationFailed.ERROR_CODE)
	public String handleAuthenticationFailed(final HttpServletRequest request, final HttpServletResponse response , 
			@PathVariable("enterpriseName") final String enterpriseName ) {
		SessionContext sessionContext = SessionContext.get();
		sessionContext.invalidateSession();
		return AuthWebUtil.createForwardToPathFromController("oAuth2/initiate");
	}
	
}
