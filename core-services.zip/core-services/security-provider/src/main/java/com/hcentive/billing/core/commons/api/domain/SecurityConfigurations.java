package com.hcentive.billing.core.commons.api.domain;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "security_configurations")
public class SecurityConfigurations<T> implements Serializable {


	private static final long serialVersionUID = 8483557567385058075L;

	@Id
	private String id;

	private final String key;

	private final T data;

	public SecurityConfigurations(String key, T data) {
		super();
		this.key = key;
		this.data = data;
	}

	public String getKey() {
		return key;
	}

	public T getData() {
		return data;
	}

	@Override
	public String toString() {
		return "Configuration [key=" + key + "]";
	}

}
