package com.hcentive.billing.core.commons.api;

public interface OAuth2ProtocolConstants {

	public static final String OAUTH2 = "OAUTH2";

	public static final String RESPONSE_TYPE = "response_type";

	public static final String REDIRECT_URI = "redirect_uri";

	public static final String STATE = "state";

	public static final String CLIENT_ID = "client_id";

}
