package com.hcentive.billing.core.commons.service.core.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.api.TrustedEntity;


public interface TrustedEntityRepository extends JpaRepository<TrustedEntity, Long>{
	
	public TrustedEntity findByName(final String name);

}
