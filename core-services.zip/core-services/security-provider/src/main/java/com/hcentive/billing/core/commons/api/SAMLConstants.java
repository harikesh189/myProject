package com.hcentive.billing.core.commons.api;

public interface SAMLConstants {

	public static final String BUISNESS_IDENTIFIER = "businessIdentifier";
	
	public static final String BUISNESS_IDENTIFIER_TYPE = "businessIdentifierType";

	public static final String NPN = "npn";

	public static final String ORGANIZATION_IDENTIFIER = "organizationIdentifier";
	
	public static final String ORGANIZATION_IDENTIFIER_TYPE = "organizationIdentifierType";
	
	public static final String BROKER_IDENTIFIER = "brokerIdentifier";
	
	public static final String FIRST_NAME = "firstName";
	
	public static final String LAST_NAME = "lastName";
	
	public static final String USER_ID = "userId";
	
	public static final String EMAIL = "email";


}
