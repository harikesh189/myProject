package com.hcentive.billing.core.commons.service.core.security.web.idpsupport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.UsernamePassword;
import com.hcentive.billing.core.commons.api.domain.PasswordPolicy;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.service.core.security.dto.LoginForm;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManagerHelper;
import com.hcentive.billing.core.commons.service.core.security.service.UserCredentialsSevice;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.util.EncryptionUtil;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.web.WebUtils;

@Controller
@RequestMapping("/security/{enterpriseName}/userCredentialBasedAuth")
public class UserCredentialBasedAuthenticationController extends
		IdpAuthenticationProcesingController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(UserCredentialBasedAuthenticationController.class);

	@Value("${security.logout.message}")
	private String logoutMessage;

	@Autowired
	private Environment env;
	
	@Autowired
	private AuthManagerHelper authManagerHelper;
	
	@Autowired
	private UserCredentialsSevice credentialsSevice;
	
	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;


	/**
	 * @param request
	 * @return
	 */
	protected List<ClientAppIdpEnterpriseConfig> otherConfigs(
			final HttpServletRequest request) {
		final List<ClientAppIdpEnterpriseConfig> allConfigs = ( List<ClientAppIdpEnterpriseConfig>)request.getAttribute("availableConfigs");
		final String selfName = this.identity();
		ClientAppIdpEnterpriseConfig configToRemove = null;
		for(final ClientAppIdpEnterpriseConfig cc : allConfigs){
			if(selfName.equals(cc.getIdentityProvider().getHandledByController())){
				configToRemove = cc;
			}
		}
		allConfigs.remove(configToRemove);
		return allConfigs;
	}

	
	@RequestMapping("/registration")
	// @RequiresPermissions(value=Permission.PORTAL_MANAGEMENT)
	public ModelAndView activation() {
		ModelAndView modelandView = new ModelAndView("register");
		List<PortalType> listPortals = prepareModel();
		modelandView.addObject("login.footerURL",
				env.getProperty("copyrightURL"));
		modelandView.addObject("portalList", listPortals);
		modelandView.addObject("staticUrl",
				env.getProperty("security.static.resource.url"));
		return modelandView;

	}

	private List<PortalType> prepareModel() {
		List<PortalType> portals = new ArrayList<UserCredentialBasedAuthenticationController.PortalType>();
		String customerTypes = env.getProperty("customerTypes");
		String[] items = customerTypes.split(",");
		List<String> userTypes = Arrays.asList(items);
		for (String userType : userTypes) {
			String display = env.getProperty(userType + ".display");
			PortalType p = new PortalType(display, userType);
			portals.add(p);
		}
		return portals;

	}

	public class PortalType {
		String displayName;
		String customerType;

		public String getDisplayName() {
			return displayName;
		}

		public void setDisplayName(String displayName) {
			this.displayName = displayName;
		}

		public String getCustomerType() {
			return customerType;
		}

		public void setCustomerType(String customerType) {
			this.customerType = customerType;
		}

		public PortalType(String displayName, String customerType) {
			super();
			this.displayName = displayName;
			this.customerType = customerType;
		}

	}

	@RequestMapping("/int/register")
	public String doRegister(HttpServletRequest request,@PathVariable("enterpriseName") String enterpriseName) {
		final RequestContext requestContext = RequestContext.get();
		final StringBuilder redirectUrlBuilder = new StringBuilder(WebUtils.getBaseUrl(request));
		redirectUrlBuilder.append("/").append(requestContext.enterprise().getName()).append("/").append(securityUIAppKey).append("/").
		append("?client_id=").append(requestContext.clientApp().getAppKey()).
		append("&idpKey=").append(requestContext.identityProvider().getIdpKey())
			.append("/#/registration");
		return "redirect:" + redirectUrlBuilder.toString();
	}
	
	@RequestMapping("/login")
	public String doAuthentication(@ModelAttribute LoginForm loginForm,
			HttpServletRequest request,@PathVariable("enterpriseName") String enterpriseName) {
		final Map<String, String> credentialsMap = populateCredentialsMapFromFormFields(request);
		final UsernamePassword credential = new UsernamePassword(credentialsMap.get("username"),credentialsMap.get("password"));
		AuthWebUtil.attachStateAndCallBackUrl(request, loginForm.getState(),
				loginForm.getCallBackUrl());
		AuthWebUtil.attachCredential(request, credential);
		return "forward:" + loginForm.getCallBackUrl();
	}
	
	@ResponseBody
	@RequestMapping("/checkUserCredentials")
	public Map<String,String> checkUserCredentials(@RequestBody LoginForm loginForm,
			HttpServletRequest request,@PathVariable("enterpriseName") String enterpriseName) {
		final Map<String, String> credentialsMap = populateCredentialsMapFromHeader(request);
		final String username = credentialsMap.get("username");
		final String password = credentialsMap.get("password");
		LOGGER.debug("Extracted username and password and going for matching credentials.");
		final RequestContext requestContext = RequestContext.get();
		final Map<String,String> isValidUserCredential = new HashMap<String,String>();
		WFMUserCredentials credentials = null;
		try{
			credentials = (WFMUserCredentials) credentialsSevice
					.getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseNameAndPassword(username,requestContext.identityProvider().getIdpKey(),
							requestContext.enterprise().getName(),password);
		}catch(InvalidUserException e){
			isValidUserCredential.put("isValidUserCredential", "false");
		}
		
		if(credentials != null){
			final PasswordPolicy passwordPolicy = credentialsSevice.getPasswordPolicyForUserCredentials(credentials);
			if(null != passwordPolicy && new DateTime().isAfter(passwordPolicy.getCurrentPasswordExpiry())){
				isValidUserCredential.put("isValidUserCredential", "Expired");
			}else{
				isValidUserCredential.put("isValidUserCredential", "true");
			}
		}
			
		return isValidUserCredential;
	}


	private Map<String, String> populateCredentialsMapFromHeader(
			HttpServletRequest request) {
		final String passphrase = request.getHeader("Authorization").replace("BASIC ","");//token
		LOGGER.debug("Extracted passphrase for decryption.");
		final String encryptedText = request.getHeader("user-credential");
		LOGGER.debug("Extracted encryptedText for decryption.");
		final String iv = request.getHeader("securityKey");
		LOGGER.debug("Extracted iv for decryption.");
		final String nonce = request.getHeader("nonce");
		LOGGER.debug("Extracted nonce for decryption.");
		final String salt = getSaltForDecryption(nonce);
		LOGGER.debug("Prepared salt using nonce for decryption.");
		final String decryptedUserCredentials = EncryptionUtil.getAesDecryptedString(encryptedText, passphrase, iv, salt);
		LOGGER.debug("Extracted decrypted user credentials for decryption.");
		final Map<String,String> credentialsMap = getUserNameAndPasswordFromDecryptedString(decryptedUserCredentials);
		return credentialsMap;
	}
	
	private Map<String, String> populateCredentialsMapFromFormFields(
			HttpServletRequest request) {
		final String passphrase = request.getParameter("passPhrase");//token
		LOGGER.debug("Extracted passphrase for decryption.");
		final String encryptedText = request.getParameter("userCredential");
		LOGGER.debug("Extracted encryptedText for decryption.");
		final String iv = request.getParameter("iv");
		LOGGER.debug("Extracted iv for decryption.");
		final String salt = request.getParameter("salt");
		LOGGER.debug("Extracted salt for decryption.");
		final String decryptedUserCredentials = EncryptionUtil.getAesDecryptedString(encryptedText, passphrase, iv, salt);
		LOGGER.debug("Extracted decrypted user credentials for decryption.");
		final Map<String,String> credentialsMap = getUserNameAndPasswordFromDecryptedString(decryptedUserCredentials);
		return credentialsMap;
	}

	/**
	 * added nonce 3 times in salt as AES algo requires salt to be hexadecimal 32 characters.
	 * @param nonce
	 * @return
	 */
	private String getSaltForDecryption(final String nonce) {
		LOGGER.debug("getting salt for decryption.");
		StringBuilder saltString = new StringBuilder();
		saltString.append(nonce);
		saltString.append(nonce);
		saltString.append(nonce);
		return saltString.substring(0, 32);
	}

	@ExceptionHandler(Throwable.class)
	public ModelAndView handleAllException(Throwable ex) {
		ModelAndView model = new ModelAndView("404");
		model.addObject("staticUrl",
				env.getProperty("security.static.resource.url"));
		return model;

	}

	@Override
	public String loginEndpointToForwardForProcessing() {
		return "userCredentialBasedAuth/login";
	}
	
	@Override
	public String registrationEndpointToForwardForProcessing() {
		return "userCredentialBasedAuth/int/register";
	}

	@Override
	public String identity() {
		return "UserCredentialBased";
	}

	@Override
	public String logoutEndpointToForwardForProcessing() {
		return null;
	}
	
	private final Map<String,String> getUserNameAndPasswordFromDecryptedString(final String deCryptedString){
		Map<String,String> credentialsMap = new HashMap<>();
		if(deCryptedString != null){
			String credentialsArray[] = deCryptedString.split("&&");
			String usernameKey = "userName=";
			String passwordKey = "password=";
			credentialsMap.put("username", credentialsArray[0].substring(usernameKey.length(),credentialsArray[0].length()));
			credentialsMap.put("password", credentialsArray[1].substring(passwordKey.length(),credentialsArray[1].length()));
			return credentialsMap;
		}
		return null;
	}

}
