package com.hcentive.billing.core.commons.api;

import java.util.List;

public interface ClientAppService {


	public List<ClientAppIdpEnterpriseConfig> findByClientApp(ClientApp clientApp);

	public List<ClientAppIdpEnterpriseConfig> findClientAppEnterpriseIdpConfigs(
			String enterprise, String appKey);
	
	public List<ClientAppIdpEnterpriseConfig> findClientAppEnterpriseIdpConfigsByIdp(String enterprise, String idpKey);
}
