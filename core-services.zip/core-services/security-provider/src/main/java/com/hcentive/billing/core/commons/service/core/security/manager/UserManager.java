package com.hcentive.billing.core.commons.service.core.security.manager;

import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.DraftUser;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.security.DefaultAccessToken;
import com.hcentive.billing.core.commons.service.core.security.dto.RegistrationFormDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserCreationDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserSearchDto;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface UserManager {

	Page<User> getAdminUsers(SearchCriteria  searchCriteria);

	User getUserById(String userId);
	
	List<UserCredentials> getUserCredentialByUserIdentity(String userId);

	Object associateWithCurrentUser(UserDTO userDTO);

	Object associateWithGivenUser(UserDTO userDTO);

	Object updateUser(UserDTO userCreationDTO);
	
	Collection<User> getBEManagesManagers(String beId);

	String changePassword(String oldPassword, String newPassword);

	UserCredentials verifyUser(UserDTO userDto);

	boolean verifyUserSecurityInfo(UserDTO userDTO);

	String changePassword(UserDTO userDTO);

	User getUserForActivation(UserSearchDto searchDto);

	boolean removeUser(List<String> userIdentity);

	BusinessEntity getBusinessEntity(UserSearchDto searchDTO);

	public interface UserManagementTask {
		public User execute();
	}

	DefaultAccessToken createFixedAccessTokenForApp(String appkey);

	void deleteTokenAndLogoutAfterProcessCompleted();

	DraftUser prepareAndGetDraftUser(UserCreationDTO userCreationDTO);

	void publishUserRegistrationEvent(DraftUser draftUser, BusinessEntity be);

	void addUser(RegistrationFormDTO registrationFormDTO);
	
	public User createAndGetUserUsingDraftUser(final DraftUser draftUser);


}
