package com.hcentive.billing.core.commons.service.core.security.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hcentive.billing.core.commons.api.domain.PasswordPolicy;

public interface PasswordPolicyRepository extends MongoRepository<PasswordPolicy, String> {
	
	public PasswordPolicy findByUserCredentialsRef(final String userCredentialsRef);

}
