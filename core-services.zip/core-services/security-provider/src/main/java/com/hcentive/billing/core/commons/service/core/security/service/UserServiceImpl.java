package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.api.TrustedEntity;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.AsyncIOU;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.Customer;
import com.hcentive.billing.core.commons.domain.Facilitator;
import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.converter.PageableTransformer;
import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.dto.UserOperation;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.event.UserUpdatePayLoad;
import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.DefaultAccessToken;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.dto.RegistrationFormDTO;
import com.hcentive.billing.core.commons.service.core.security.repository.AccessTokenRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.BusinessEntityRepo;
import com.hcentive.billing.core.commons.service.core.security.repository.CustomUserRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.ProfileRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.TrustedEntityRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserTenantInfoRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.WFMUserCredentialsRepository;
import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteriaOnColumns;

@Component
public class UserServiceImpl implements UserService {

	@Autowired
	ProfileRepository profileRepository;
	private static final Logger logger = LoggerFactory
			.getLogger(UserServiceImpl.class);
	@Autowired
	protected UserRepository userRepository;

	@Autowired
	private FilterSupportRepository filterSupportRepository;

	@Autowired
	private FacilitatorServiceSupport facilitatorServiceSupport;

	@Autowired
	private WFMUserCredentialsRepository userCredentialsRepository;

	@Autowired
	private UserTenantInfoRepository userTenantInfoRepository;

	@Autowired
	AccessTokenRepository accessTokenRepository;
	
	@Autowired
	TrustedEntityRepository trustedEntityRepository;
	
	@Autowired
	private BusinessEntityRepo beRepo;

	@Autowired
	private CustomUserRepository customUserRepository;
	
	@Autowired
	private UserCredentialsSevice userCredentialsSevice;
	
	/*
	 * (non-Javadoc)
	 * 
	 * 
	 * @see
	 * com.hcentive.billing.core.commons.service.core.security.service.UserService
	 * #getAdminUsers()
	 */
	@Override
	@RequiresPermissions(value = Permission.ADMIN_READ_USER)
	public Page<User> getAdminUsers(SearchCriteria searchCriteria) {
		Pageable pageable = null;
		if (searchCriteria.getPageRequestCriteria() != null) {
			pageable = PageableTransformer.INSTANCE.transform(searchCriteria.getPageRequestCriteria());
		}
		Page<User> users = filterSupportRepository.findDomainByFilterCriteria(User.class, searchCriteria);
		return users;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.hcentive.billing.core.commons.service.core.security.service.UserService
	 * #getUserById(java.lang.Long)
	 */
	@Override
	@RequiresPermissions(value = Permission.ADMIN_READ_USER)
	public User getUserById(String userId) {
		logger.debug("Inside userService for fetching user for userId" + userId);
		User user = (User) userRepository.findByIdentity(userId);
		return user;
	}

	@Override
	public List<UserCredentials> getUserCredentialByUserIdentity(String userId) {
		logger.debug("Inside userService for fetching user for userId" + userId);
		List<UserCredentials> user = userCredentialsRepository
				.getByUserTenantInfoIdentity(userId);
		return user;
	}

	@SuppressWarnings("rawtypes")
	@Override
	//@RequiresPermissions(value = { Permission.SEARCH_CUSTOMER })
	public Page<BusinessEntity> fetchMatchingBEs(SearchCriteria searchCriteria) {
		return filterSupportRepository.findDomainByFilterCriteria(
				BusinessEntity.class, searchCriteria);
	}

	@SuppressWarnings("rawtypes")
	@Override
	@RequiresPermissions(value = { Permission.SEARCH_CUSTOMER })
	public IOU<Facilitator, AsyncCallback<Facilitator>> fetchFaciliator(
			String externalId, String npn) {

		AsyncIOU<Facilitator, Facilitator> resultIOU = new AsyncIOU<Facilitator, Facilitator>() {

			@Override
			protected Facilitator onSuccessExecute(Facilitator facilitator) {
				return facilitator;
			}
		};

		final IOU<Facilitator, AsyncCallback<Facilitator>> baIOU = findFacilitatorByExternalIdAndNpn(
				externalId, npn);

		baIOU.set(resultIOU);
		return resultIOU;
	}

	private IOU<Facilitator, AsyncCallback<Facilitator>> findFacilitatorByExternalIdAndNpn(
			String externalId, String npn) {

		return facilitatorServiceSupport.fetchByOwnerIdentity(externalId, npn);
	}

	@Override
	@RequiresPermissions(value = { Permission.UPDATE_USER })
	public User associateAndUpdate(String userId, Collection<BusinessEntity> bes) {
		final User userEntity = userRepository.findByIdentity(userId);
		return associateAndUpdate(bes, userEntity);
	}

	private User associateAndUpdate(Collection<BusinessEntity> bes,
			User userEntity) throws IllegalAccessError {
		if (userEntity != null && userEntity instanceof Manager) {
			Manager manager = (Manager) userEntity;
			Collection<Reference> oldReferences = manager.getManagedEntities();

			associate(bes, manager);
			manager = userRepository.save(manager);
			logger.debug("Publisihig associate BusinessEntity event::{}",
					oldReferences);
			UserUpdatePayLoad payload = createPayload(
					UserOperation.AssociateBusinessEntities,
					manager.getIdentity(), oldReferences, bes);
			Event<UserUpdatePayLoad> event = new Event<UserUpdatePayLoad>(
					EventType.ASSOCIATE_BUSINESSENTITY, payload);
			EventUtils.publish(event);
			return manager;
		}
		logger.debug("Either User is null or not manager");
		return null;
	}

	@Override
	public void associate(Collection<BusinessEntity> bes, User userEntity)
			throws IllegalAccessError {
		if (userEntity != null && userEntity instanceof Manager) {
			Manager manager = (Manager) userEntity;
			for (BusinessEntity businessEntity : bes) {
				/*
				 * if (businessEntity.getProfile() instanceof PersonalProfile) {
				 * if (isAlreadyAssociated(businessEntity)) throw new
				 * IllegalAccessError( "Business Entity is already associated");
				 * businessEntity = filterSupportRepository
				 * .findDomainByIdentity(businessEntity.getIdentity(),
				 * BusinessEntity.class); manager.setProfile((PersonalProfile)
				 * businessEntity .getProfile()); }
				 */
				manager.associate(businessEntity);
			}
		}
	}

	private boolean isAlreadyAssociated(BusinessEntity businessEntity) {
		return !getBEManagers(businessEntity).isEmpty();

	}

	@Override
	@RequiresPermissions(value = { Permission.UPDATE_USER })
	public User deAssociate(String identity,
			Collection<BusinessEntity> businessEntities) {

		User userEntity = userRepository.findByIdentity(identity);
		if (userEntity != null && userEntity instanceof Manager) {
			Manager manager = (Manager) userEntity;
			Collection<Reference> oldReferences = manager.getManagedEntities();

			for (BusinessEntity businessEntity : businessEntities) {
				manager.disassociate(businessEntity);
			}
			manager = userRepository.save(manager);
			logger.debug("Publisihig associate BusinessEntity event::{}",
					oldReferences);
			UserUpdatePayLoad payload = createPayload(
					UserOperation.AssociateBusinessEntities,
					manager.getIdentity(), oldReferences, businessEntities);
			Event<UserUpdatePayLoad> event = new Event<UserUpdatePayLoad>(
					EventType.DISASSOCIATE_BUSINESSENTITY, payload);
			EventUtils.publish(event);
			return manager;
		}
		logger.debug("Either User is null or not manager");
		return null;
	}
	
	@Override
	@RequiresPermissions(value = { Permission.UPDATE_USER })
	public User updateUser(User user) {
		return userRepository.save(user);
	}

	/***
	 * Only update user first Name, Last Name
	 * 
	 * @param identity
	 * @param updatedProfile
	 * @return
	 */
	@Override
	@RequiresPermissions(value = { Permission.UPDATE_USER })
	public User updateUserProfile(String identity,
			PersonalProfile updatedProfile) {

		User user = userRepository.findByIdentity(identity);
		logger.debug("Fetching existing profile");
		PersonalProfile prevProfile = user.getProfile();
		logger.debug("going to update profile {} of user ::{}",
				prevProfile.getId(), identity);

		if (updatedProfile.getFirstName() != null
				&& !updatedProfile.getFirstName().isEmpty())
			prevProfile.setFirstName(updatedProfile.getFirstName());

		if (updatedProfile.getLastName() != null
				&& !updatedProfile.getLastName().isEmpty())
			prevProfile.setLastName(updatedProfile.getLastName());

		if (updatedProfile.getContactNumbers() != null)
			prevProfile.setContactNumbers(updatedProfile.getContactNumbers());

		if (updatedProfile.getAddressess() != null)
			prevProfile.setAddressess(updatedProfile.getAddressess());

		if (updatedProfile.getEmails() != null)
			prevProfile.setEmails(updatedProfile.getEmails());

		if (updatedProfile.getContactPersons() != null)
			prevProfile.setContactPersons(updatedProfile.getContactPersons());

		profileRepository.save(prevProfile);

		logger.debug("Publisihig update profile event::{}", identity);
		UserUpdatePayLoad payload = createPayload(
				UserOperation.UpdateUserProfile, user.getIdentity(),
				prevProfile, updatedProfile);
		Event<UserUpdatePayLoad> event = new Event<UserUpdatePayLoad>(
				EventType.PROFILE_UPDATE, payload);
		EventUtils.publish(event);
		return user;

	}

	private UserUpdatePayLoad createPayload(UserOperation userOperation,
			String userId, Object oldEntity, Object updatedEntity) {
		User user = getUserByIdentity(userId);
		UserUpdatePayLoad userUpdatePayLoad = new UserUpdatePayLoad(user);
		userUpdatePayLoad.setUserIdentity(userId);
		userUpdatePayLoad.setUserOperation(userOperation);
		userUpdatePayLoad.setOldEntity(oldEntity);
		userUpdatePayLoad.setNewEntity(updatedEntity);
		return userUpdatePayLoad;
	}

	@Override
	@RequiresPermissions(value = { Permission.UPDATE_USER })
	public User updateUserRoles(String identity, Set<Role> newRoles) {
		User user = userRepository.findByIdentity(identity);
		logger.debug("Fetching existing profile");
		Set<Role> oldRoles = user.getRoles();
		if (!isRolesSame(oldRoles, newRoles)) {
			user.setRoles(newRoles);
			logger.debug("going to update profile with user ::{}", identity);
			user = userRepository.save(user);
			logger.debug("Publisihig update Roles event::{}", identity);
			UserUpdatePayLoad payload = createPayload(
					UserOperation.UpdateUserRoles, user.getIdentity(),
					oldRoles, newRoles);
			Event<UserUpdatePayLoad> event = new Event<UserUpdatePayLoad>(
					EventType.USER_ROLES_UPDATED, payload);
			EventUtils.publish(event);
			return user;
		}
		return null;
	}

	private boolean isRolesSame(Set<Role> oldRoles, Set<Role> newRoles) {
		if (oldRoles.size() != newRoles.size()) {
			return false;
		}
		return newRoles.containsAll(oldRoles) && newRoles.containsAll(oldRoles);
	}

	@Override
	public User addUser(User user) {
		User addedUser = null;
		if (null == user) {
			logger.error("No Administrator to add");
			return null;
		}
		addedUser = userRepository.save(user);
		EventUtils.publish(new Event(EventType.NEW_USER_ADDED, addedUser));
		return addedUser;
	}

	@Override
	// @RequiresPermissions(value = { Permission.SEARCH_USER })
	public User getUserByIdentity(String identity) {
		logger.debug("going to find user with identity {}", identity);
		User user = userRepository.findByIdentity(identity);
		if (user == null || user.isDeleted()) {
			logger.debug("Invalid user ID");
			return null;
		}

		return user;
	}

	@Override
	@RequiresPermissions(value = { Permission.SEARCH_CUSTOMER })
	public Page<BusinessEntity> getBEByIdentities(Set<String> beId) {
		SearchCriteria searchCriteria = new SearchCriteria();
		Map<String, SearchCriteriaOnColumns> criteria = searchCriteria
				.getCriteria();
		SearchCriteriaOnColumns value = new SearchCriteriaOnColumns();
		value.setOperator("IN");
		String columnValue = populateIds(beId);
		value.setColumnValue("(" + columnValue + ")");
		criteria.put("identity", value);
		searchCriteria.setCriteria(criteria);

		return fetchMatchingBEs(searchCriteria);
	}

	private String populateIds(Set<String> beId) {
		StringBuffer idList = new StringBuffer();
		Iterator iter = beId.iterator();
		while (iter.hasNext()) {
			idList.append("'").append(iter.next()).append("'");
			if (iter.hasNext())
				idList.append(" , ");
		}
		return idList.toString();
	}

	@Override
	@RequiresPermissions(value = { Permission.SEARCH_USER })
	public Collection<User> getBEManagers(BusinessEntity be) {
		// Commented find by reference code - TO DO
		return userRepository.getBEManagers(be.getId());

	}

	@Override
	public List<User> getUserBySearchCriteria(SearchCriteria searchCriteria) {
		return filterSupportRepository.findDomainByFilterCriteria(User.class,
				searchCriteria).getContent();
	}

	@Override
	@Transactional
	public boolean removeUser(List<String> userIdentities) {
		for (String userIdentity : userIdentities) {
			logger.debug("Going to remove user {}  ", userIdentity);
			User user = userRepository.findByIdentity(userIdentity);
			if (null == user) {
				logger.debug("No user found with identity {} ", userIdentity);
				return false;
			}
			user.markDelete();
			userRepository.save(user);
			logger.debug("going to remove user ");
		}
		return false;
	}

	/***
	 * lookup in WFM_USER on the basis of BusinessEntity and type and return
	 * User
	 * 
	 * @param be
	 * @param matchingCriteria
	 * @return user
	 */
	@Override
	public User getBEManagesUser(BusinessEntity be,
			Map<String, String> matchingCriteria) {
		if (null == be) {
			logger.debug("No BE found");
			throw new IllegalAccessError();
		}
		switch (be.getType()) {
		case BusinessEntityTypes.INDIVIDUAL_CUSTOMER: {
			return getIndividualManager((Customer) be);

		}
		case BusinessEntityTypes.BROKER: {
			return getBrokerManager((Facilitator) be);
		}
		case BusinessEntityTypes.GROUP_CUSTOMER: {
			return getGroupManager((Customer) be, matchingCriteria);
		}

		default:
			break;
		}
		return null;
	}

	private User getGroupManager(Customer be,
			Map<String, String> matchingCriteria) {
		logger.debug("Fetch Managers for Group Id {}", be.externalId());
		Collection<User> users = getBEManagers(be);
		logger.debug("going to match users with matchCriteria");
		for (User user : users) {
			if (userMatchCriteria(user, matchingCriteria))
				return user;
		}
		return null;
	}

	private boolean userMatchCriteria(User user,
			Map<String, String> matchingCriteria) {
		return true;
	}

	private User getBrokerManager(Facilitator be) {
		logger.debug("Fetch Managers for Broker Id {}", be.externalId());
		Collection<User> users = getBEManagers(be);
		if (users == null || users.size() == 0) {
			return null;
		} else if (users.size() > 1) {
			logger.error("More than one manager found");
			throw new IllegalAccessError("Multiple managers found for Broker  "
					+ be.externalId());
		}
		return users.iterator().next();
	}

	private User getIndividualManager(Customer be) {
		logger.debug("Fetch Managers for Individual Id {}", be.externalId());
		Collection<User> users = getBEManagers(be);
		if (users == null || users.size() == 0) {
			return null;
		} else if (users.size() > 1) {
			logger.error("More than one manager found");
			throw new IllegalAccessError(
					"Multiple managers found for Individual  "
							+ be.externalId());
		}
		return users.iterator().next();
	}

	@Override
	public User updateUserStatus(String identity, UserStatus userStatus) {
		User user = getUserByIdentity(identity);
		if (userStatus.equals(user.getStatus())) {
			logger.debug("No change in userStatus nothing to do");
			return user;
		}
		user.setStatus(userStatus);
		user = userRepository.save(user);
		return user;
	}

	@Override
	public UserTenantInfo getUserTenantInfoByIdentity(String identity) {
		return userTenantInfoRepository.findByIdentity(identity);
	}

	@Override
	public void deleteToken() {
		accessTokenRepository.delete((DefaultAccessToken) Utils
				.getAccessToken());
	}

	@Override
	@Transactional
	public WFMUserCredentials createAndGetUserCredentials(RegistrationFormDTO registrationFormDTO) {
		WFMUserCredentials wfmUserCredentials = userCredentialsSevice.createAndGetWFMUserCredentials(registrationFormDTO);
		return userCredentialsRepository.save(wfmUserCredentials);
	}

	
	@Override
	public BusinessEntity getBEFromExternalId(final String externalId){
		return beRepo.findByExternalId(externalId);
	}

	@Override
	@Transactional
	public WFMUserCredentials saveWFMUserCredentials(WFMUserCredentials wfmUserCredentials){
		return userCredentialsRepository.save(wfmUserCredentials);
	}

	@Override
	public User getUserByExternalId(String externalId) {
		return userRepository.findByExternalId(externalId);
	}
	@Override
	public TrustedEntity getTrustedEntityByName() {
		return trustedEntityRepository.findByName(AnonymousUserIdentity.LOGIN_USER_IDENTITY.userIdentity());
	}

}
