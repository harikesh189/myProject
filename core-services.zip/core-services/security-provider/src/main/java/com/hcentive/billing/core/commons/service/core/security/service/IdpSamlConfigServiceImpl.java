package com.hcentive.billing.core.commons.service.core.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcentive.billing.core.commons.api.IdentityProvider;
import com.hcentive.billing.core.commons.api.IdpSamlConfiguration;
import com.hcentive.billing.core.commons.service.core.security.repository.IdpSamlConfigurationRepository;

@Service
public class IdpSamlConfigServiceImpl implements IdpSamlConfigService {

	@Autowired
	private IdpSamlConfigurationRepository idpSamlConfigurationRepository;

	@Override
	public IdpSamlConfiguration findByIdentityProvider(
			IdentityProvider identityProvider) {
		return idpSamlConfigurationRepository
				.findByIdentityProvider(identityProvider);
	}

}
