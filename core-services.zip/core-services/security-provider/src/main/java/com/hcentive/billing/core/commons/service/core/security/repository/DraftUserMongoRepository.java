package com.hcentive.billing.core.commons.service.core.security.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hcentive.billing.core.commons.domain.DraftUser;

public interface DraftUserMongoRepository extends MongoRepository<DraftUser, String>{

	DraftUser findByIdentifier(String identifier);
}
