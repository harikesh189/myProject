package com.hcentive.billing.core.commons.service.core.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.api.EnterpriseImpl;


public interface EnterpriseRepository extends JpaRepository<EnterpriseImpl,Long> {

}
