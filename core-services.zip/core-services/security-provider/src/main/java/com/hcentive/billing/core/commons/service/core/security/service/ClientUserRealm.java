package com.hcentive.billing.core.commons.service.core.security.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.EntityManagerHolder;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.hcentive.billing.core.AbstractSecurityRealm;
import com.hcentive.billing.core.commons.api.ClientUserCredential;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.FixedValueToken;
import com.hcentive.billing.core.commons.security.shiro.ClientUserToken;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class ClientUserRealm extends AbstractSecurityRealm<ClientUserToken> {

	public ClientUserRealm() {
		super(ClientUserToken.class);
	}

	@Autowired
	protected UserRepository userRepository;

	@Autowired
	private UserCredentialsSevice credentialsSevice;

	@Autowired
	private AccessTokenService accessTokenService;
	
	@Autowired
	private EntityManagerFactory emf;
	
	@Autowired
	protected UserMgmt userMgmt;

	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			final AuthenticationToken token) throws AuthenticationException {
		return getAuthenticationInfo((ClientUserToken) token);
	}

	private AuthenticationInfo getAuthenticationInfo(final ClientUserToken token) {
		ClientUserCredential credentials;
		try {
			credentials = (ClientUserCredential) credentialsSevice
					.getBySecretKey((String) token.getCredentials());
		} catch (InvalidUserException e) {
			throw new AuthenticationException("No Matching credentials found");
		}
		UserTenantInfo userTenantInfo = credentials.getUserTenantInfo();
		final String tenantId = userTenantInfo.getTenantId();
		final ProcessContext pc  = ProcessContext.get();
		final EntityManagerHolder emHolder = (EntityManagerHolder) TransactionSynchronizationManager.getResource(emf);
		User user =null;
		if(null != emHolder){
			//implies that an EntityManager is associated with the thread. Manipulate it.
			final EntityManager entityManager = emHolder.getEntityManager();
			entityManager.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, tenantId);
			user =  userMgmt.findById(userTenantInfo.getId());
			entityManager.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, pc.getTenantId());
		}else{
			//there is not EntityManager attached feel the freedom.
			initiliazeProcessContext(userTenantInfo);
			user =  userMgmt.findById(userTenantInfo.getId());
			revertProcessContext(pc);
		}
		final AuthenticationInfo authenticationInfo = loadAuthenticationInfo(
				token, credentials,user);
		// Save Access Token
		AccessToken accessToken = authenticationInfo.getPrincipals().oneByType(
				AccessToken.class);
		if (accessToken instanceof FixedValueToken) {
			accessTokenService.persistToken((FixedValueToken) accessToken);
		} else {
			throw new IllegalStateException("wrong token found");
		}
		return authenticationInfo;
	}

}
