package com.hcentive.billing.core.commons.api;

public enum AuthMode {

	CAPTURE_CREDENTIALS("Capture_Credentials"), CAPTURE_CREDENTIALS_FOR_SYSTEM_AUTH(
			"Capture_Credentials for Authentication by System"), SUBMIT_POST(
			"Submit_Post"), SUBMIT_GET("Submit_Get"), REDIRECT_POST(
			"Redirect_Post"), REDIRECT_GET("Redirect_Get");
	private String authMode;

	private AuthMode(String authMode) {
		this.authMode = authMode;
	}

	public String getAuthMode() {
		return authMode;
	}

}