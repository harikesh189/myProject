package com.hcentive.billing.core.commons.service.core.security.dto;

import java.io.Serializable;

public class SecurityToken implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1745660598549937628L;
	private String tokenId;
	private String clientId;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

}
