package com.hcentive.billing.core.commons.service.core.security.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.Profile;


@Transactional
public interface ProfileRepository extends JpaRepository<Profile, Long> {

}
