package com.hcentive.billing.core.commons.api.support;

import java.util.Map;

import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.IdpRequestConfiguration;
import com.hcentive.billing.core.commons.api.IdpUserIdentity;

public class IdpSAML2Adapter implements IdpAdapter<IdpRequestConfiguration> {

	@Override
	public boolean canProcess(String idpKey) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IdpUserIdentity parseIdpResponse(
			ClientAppIdpEnterpriseConfig clientAppIdpConfig,
			Map<String, String[]> idpResponse) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, String[]> createIdpRequest(
			IdpRequestConfiguration idpConfig) {
		// TODO Auto-generated method stub
		return null;
	}

}
