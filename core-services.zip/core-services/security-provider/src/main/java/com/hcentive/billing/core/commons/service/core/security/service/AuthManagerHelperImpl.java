package com.hcentive.billing.core.commons.service.core.security.service;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.Credential;
import com.hcentive.billing.core.commons.service.core.security.web.auth.OAuth2Controller.OAuth2Parameters;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.web.WebUtils;

@Component
public class AuthManagerHelperImpl implements AuthManagerHelper {
	
	private static final Logger logger = LoggerFactory
			.getLogger(AuthManagerHelperImpl.class);
	
	@Autowired
	private AuthManager authManager;

	@Override
	public String processLoginAndGetPostAuthenticationState(HttpServletRequest request, final String enterpriseName) {
		final Credential credential = AuthWebUtil.getCredential(request);
		final OAuth2Parameters oAuth2Parameters = OAuth2Parameters
				.parse(AuthWebUtil.getState(request));
		final AccessToken accessToken = authManager.doLogin(credential);
		AuthWebUtil.populateSessionContext(accessToken.getIdentity(),RequestContext.get().clientApp().getAppKey());
		logger.debug("Oauth2 Redirect URI: {}",oAuth2Parameters.getRedirectUri());
		String redirectUrl = null;
		if(!oAuth2Parameters.getRedirectUri().contains("enterprise")){
			redirectUrl = WebUtils.getBaseUrl(request)+"/"+enterpriseName+"/"+RequestContext.get().clientApp().getAppKey()+"/#"+oAuth2Parameters.getRedirectUri();
			logger.debug("Redirect URL : {}",redirectUrl);
			return redirectUrl;
		}
		redirectUrl = WebUtils.getBaseUrl(request)+"/"+WebUtils.replaceEnterprise(enterpriseName, oAuth2Parameters.getRedirectUri());
		logger.debug("Redirect URL : {}",redirectUrl);
		return redirectUrl;
	}


}
