package com.hcentive.billing.core.commons.service.core.security.repository;

import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hcentive.billing.core.commons.domain.Permission;


@Transactional
public interface PermissionRepository extends JpaRepository<Permission, Long> {

	Permission findByIdentity(String identity);

	@Query("select count(per) from Permission per where per.identity in ?1 ")
	int countByIdentityIn(Set<String> identities);
}
