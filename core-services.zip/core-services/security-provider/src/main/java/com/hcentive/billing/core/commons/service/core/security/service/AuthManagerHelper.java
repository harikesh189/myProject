package com.hcentive.billing.core.commons.service.core.security.service;

import javax.servlet.http.HttpServletRequest;

public interface AuthManagerHelper {
	
	public String processLoginAndGetPostAuthenticationState(final HttpServletRequest request, final String enterpriseName);

}
