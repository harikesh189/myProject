package com.hcentive.billing.core.commons.api.support;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.api.IdpUserIdentity;
import com.hcentive.billing.core.commons.api.RequestContext;

@Component
public class SAMLResponseInterpreter implements
		IdpResponseInterpreter<IdpUserIdentity> {
	
	@Override
	public IdpUserIdentity interpret(final Map<String, String> attributesMap) {
		
		final Map<String, String> wfmSpecificAttributes = populateWfmSpecificAttributes(attributesMap);
		return new IdpUserIdentity(attributesMap.get("subjectId"),
				RequestContext.get().identityProvider(), wfmSpecificAttributes);
	}

	private Map<String, String> populateWfmSpecificAttributes(
			final Map<String, String> attributesMap) {
		final Map<String,String> params = RequestContext.get().identityProvider().getParams();
		final Map<String,String> wfmSpecificAttributes = new HashMap<String,String>();
		
		for (Map.Entry<String, String> entry : attributesMap.entrySet())
		{
			final String key = entry.getKey();
			final String value = entry.getValue();
			final String wfmKey = params.get(key);
			if(null != wfmKey)
				wfmSpecificAttributes.put(wfmKey, value);
			else
				wfmSpecificAttributes.put(key, value);
		}
		
		interpretSAMLValues(params, wfmSpecificAttributes);
		return wfmSpecificAttributes;
	}

	private void interpretSAMLValues(final Map<String, String> params,
			final Map<String, String> wfmSpecificAttributes) {
		final Map<String,String> valueInterpreter = new HashMap<String,String>();
		for (Map.Entry<String, String> entry : wfmSpecificAttributes.entrySet())
		{
			final String keyToInterpretValue = extractKeyToInterpretValue(entry);
			final String wfmValue = params.get(keyToInterpretValue);
			if(null != wfmValue){
				valueInterpreter.put(entry.getKey(), wfmValue);
			}
		}
		
		wfmSpecificAttributes.putAll(valueInterpreter);
	}

	private String extractKeyToInterpretValue(Map.Entry<String, String> entry) {
		final String key = entry.getKey();
		final StringBuilder value = new StringBuilder(entry.getValue());
		value.trimToSize();
		int index = value.indexOf(" ");
		for(;index != -1;){
			value.deleteCharAt(index);
			index = value.indexOf(" ");
		}
		return key+"_"+value.toString().toLowerCase();
	}

	@Override
	public String identity() {
		return "SAML2.0";
	}

}
