package com.hcentive.billing.core.commons.service.core.security.validator;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.service.UserService;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;

/***
 * 
 * @author Prateek.Bansal Validate user Existence on basis of userIdentity
 *         throws Exception if user no user found
 * 
 */
public class UserExistsValidator implements
		Validator<UserDTO, SingleValidationError<UserDTO>> {

	@Autowired
	UserService userService;

	@Override
	public SingleValidationError<UserDTO> validate(UserDTO t) {
		SingleValidationError<UserDTO> validationError = null;
		User user = userService.getUserByIdentity(t.getIdentity());
		if (null == user) {
			validationError = new SingleValidationError<UserDTO>();
			validationError
					.setErrorCode("User Identity is invalid Or user not exists");
		}
		return validationError;
	}

	@Override
	public String identity() {
		// TODO Auto-generated method stub
		return null;
	}

}
