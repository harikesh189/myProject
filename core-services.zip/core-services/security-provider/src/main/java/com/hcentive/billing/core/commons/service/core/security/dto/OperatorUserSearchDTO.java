package com.hcentive.billing.core.commons.service.core.security.dto;

import java.util.Map;

import com.hcentive.billing.core.commons.dto.PageRequestCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteriaOnColumns;

public class OperatorUserSearchDTO extends UserSearchDto {

	String activationCode;

	@Override
	public SearchCriteria getUserSearchCriteria() {

		if (this.activationCode != null) {
			final SearchCriteria searchCriteria = new SearchCriteria();
			final Map<String, SearchCriteriaOnColumns> criteria = searchCriteria.getCriteria();
			final SearchCriteriaOnColumns value = new SearchCriteriaOnColumns();
			value.setColumnValue("'" + this.activationCode + "'");
			value.setOperator("=");
			criteria.put("activationCode", value);
			final PageRequestCriteria pg = searchCriteria.getPageRequestCriteria();
			pg.setPageIndex(0);
			pg.setSize(1);
			searchCriteria.setCriteria(criteria);
			searchCriteria.setPageRequestCriteria(pg);
			return searchCriteria;
		} else {
			return null;
		}
	}

	@Override
	public String getActivationCode() {
		return this.activationCode;
	}

	@Override
	public void setActivationCode(final String activationCode) {
		this.activationCode = activationCode;
	}

	@Override
	public boolean isActivateByActivationCode() {
		return true;
	}

}
