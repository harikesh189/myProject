package com.hcentive.billing.core.commons.service.core.security.validator;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.service.UserCredentialsSevice;
import com.hcentive.billing.core.commons.service.core.security.service.UserService;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;

/***
 * 
 * @author Prateek.Bansal check if user credentials already exists, executes
 *         while Add user credentials operation
 */
public class UserCredentialsAlreadyExistValidator implements
		Validator<UserDTO, SingleValidationError<UserDTO>> {

	@Autowired
	UserService userService;

	@Autowired
	UserCredentialsSevice credentialsSevice;

	@Override
	public SingleValidationError<UserDTO> validate(UserDTO t) {

		SingleValidationError<UserDTO> validationError = null;

		UserCredentials credentials = null;
		try {
			credentials = credentialsSevice.getCredentialsByUserNameIgnoreCase(t
					.getUserName());
		} catch (InvalidUserException e) {
			e.printStackTrace();
		}
		if (null != credentials) {
			validationError = new SingleValidationError<>();
			validationError.setErrorCode("UserCredentials Already exists");
		}
		return validationError;
	}

	@Override
	public String identity() {
		// TODO Auto-generated method stub
		return null;
	}

}
