package com.hcentive.billing.core.commons.service.core.security.service;

import com.hcentive.billing.core.commons.security.Credential;

public interface AuthenticationService {

	public void establishIdentity(Credential credential);

}
