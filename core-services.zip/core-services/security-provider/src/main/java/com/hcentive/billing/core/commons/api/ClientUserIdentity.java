package com.hcentive.billing.core.commons.api;

import java.util.Map;

import com.hcentive.billing.core.commons.security.Credential;

public class ClientUserIdentity implements Credential {

	private final String secretKey;

	public ClientUserIdentity(final String secretKey) {
		this.secretKey = secretKey;
	}

	@Override
	public String userIdentity() {
		return secretKey;
	}
	
	@Override
	public Map<String, String> sessionParams() {
		// TODO Auto-generated method stub
		return null;
	}

}
