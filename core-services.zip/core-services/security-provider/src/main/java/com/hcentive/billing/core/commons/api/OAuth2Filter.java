package com.hcentive.billing.core.commons.api;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.service.security.filter.AbstractFilter;

public class OAuth2Filter extends AbstractFilter implements Filter {

	private static final Logger logger = LoggerFactory
			.getLogger(OAuth2Filter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		logger.debug("In OAuth2 Filter");
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		final String path = httpRequest.getRequestURI();
		if (!ignoreCurrentRequest(request) && path.contains("oAuth2")) {
			final String responseType = httpRequest
					.getParameter(OAuth2ProtocolConstants.RESPONSE_TYPE);
			final String clientId = httpRequest
					.getParameter(OAuth2ProtocolConstants.CLIENT_ID);
			if (!validateOauth2Request(responseType, clientId)) {
				logger.error("Invalid OAuth2 Request");
				((HttpServletResponse)response).sendError(HttpServletResponse.SC_BAD_REQUEST);
				return;
			}
			chain.doFilter(request, response);
		} else {
			chain.doFilter(request, response);
		}
	}

	private boolean validateOauth2Request(String responseType, String clientId) {
		if (responseType != null && clientId != null
				&& !responseType.trim().equals("")
				&& !clientId.trim().equals("")) {
			return true;
		}
		return false;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	protected String[] getIgnorePathPattern() {
		// TODO Auto-generated method stub
		return null;
	}

}
