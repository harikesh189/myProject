package com.hcentive.billing.core.commons.api.support;

import java.util.Map;

import com.hcentive.billing.core.commons.api.IdpRequestConfiguration;

public interface IdpRequestBuilder<C extends IdpRequestConfiguration> {
	/**
	 * 
	 * @return the idpKey for which this is a request builder.
	 */
	public String buildsRequestForIdp();

	public C buildRequest(Map<String, String> requestParams);

}
