package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.Map;

import com.hcentive.billing.core.commons.api.ClientUserCredential;
import com.hcentive.billing.core.commons.api.domain.PasswordPolicy;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.domain.IdpUserCredential;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.service.core.security.dto.RegistrationFormDTO;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface UserCredentialsSevice {

	public UserCredentials getCredentialsByUserNameIgnoreCase(String username)
			throws InvalidUserException;

	public UserCredentials getCredentialsByIdentity(String identity)
			throws InvalidUserException;

	public UserCredentials getCredenialsBySearchCriteria(
			SearchCriteria searchCriteria) throws InvalidUserException;

	public boolean isCredentialsSecInfoValid(String identity,
			Map<String, String> secInfo) throws InvalidUserException;

	public boolean addUserCredentials(UserCredentials userCredentials)
			throws InvalidUserException;

	public boolean updatePassword(UserCredentials credentials, String newPassword,
			String oldPassword) throws InvalidUserException;

	public boolean updatePassword(String identity, String newPassword,
			Map<String, String> SecInfo) throws InvalidUserException;

	public boolean updateSecInfo(String identity, Map<String, String> secInfo)
			throws InvalidUserException;

	public UserCredentials getCredentialsByUserIdentity(String userIdentity)
			throws InvalidUserException;

	public boolean isWFMUserRegistered(String identity);

	public IdpUserCredential getCredentialByIdpUserIdentityAndIdpKeyAndEnterpriseName(
			final String idpUserIdentity, final String idpKey,final String enterpriseName)
			throws InvalidUserException;

	public boolean isIDPUserRegistered(String identity);

	public IdpUserCredential addIDPUserCredentials(IdpUserCredential credential);

	public ClientUserCredential getBySecretKey(final String secretKey);
	
	public IdpUserCredential findByUserId(final Long id);

	public WFMUserCredentials getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseName(
			final String username, final String idpKey, final String enterpriseName);
	
	public WFMUserCredentials getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseNameAndPassword(
			final String username, final String idpKey, final String enterpriseName,final String password);

	public SingleValidationError<UserCredentials> updatePassword(String username, String idpKey,
			String enterpriseName, String newPassword);

	UserCredentials getCredentialsByUserIdentityAndEnterprise(
			String userIdentity, String enterprise) throws InvalidUserException;
	
	public WFMUserCredentials createAndGetWFMUserCredentials(
			RegistrationFormDTO registrationFormDTO);
	
	public PasswordPolicy getPasswordPolicyForUserCredentials(final WFMUserCredentials wfmUserCredentials);
	
	public WFMUserCredentials getCredentialsByUserNameIgnoreCaseAndEneterpriseName(
			final String username,  final String enterpriseName);

}
