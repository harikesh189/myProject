package com.hcentive.billing.core.commons.service.core.security.service;

import com.hcentive.billing.core.commons.domain.User;

public interface UserMgmt {
	User findById(Long id);
	
	void updateUser(User user);
}
