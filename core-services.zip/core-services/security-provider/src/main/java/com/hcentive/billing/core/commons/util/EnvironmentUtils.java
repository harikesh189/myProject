package com.hcentive.billing.core.commons.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * @author Gaurav Agarwal.
 * 
 */
public final class EnvironmentUtils {

	private static EnvironmentWrapper env;

	public static String findRedirectURL(final String userType) {
		StringBuilder sb = new StringBuilder();
		sb.append(env.getEnvironment().getProperty(userType + ".url"));
		sb.append("?userType=");
		sb.append(env.getEnvironment().getProperty(userType + ".code"));
		return sb.toString();
	}

	public static void register(EnvironmentWrapper wrapper) {
		env = wrapper;
	}

}

@Component
class EnvironmentWrapper {

	@Autowired
	private Environment env;

	public EnvironmentWrapper() {
		EnvironmentUtils.register(this);
	}

	public Environment getEnvironment() {
		return env;
	}
}