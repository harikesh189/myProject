package com.hcentive.billing.core.commons.api;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.shiro.Application;
import com.hcentive.billing.core.commons.service.security.filter.HttpCreateProcessContextFilter;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.ProcessContextPersister;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;

public class SecureHttpCreateProcessContextFilter extends
		HttpCreateProcessContextFilter {

	private static final Logger logger = LoggerFactory
			.getLogger(SecureHttpCreateProcessContextFilter.class);

	@Autowired
	private WFMCache<String, ProcessContext> cache;

	@Override
	public void doFilter(final ServletRequest request,
			ServletResponse response, FilterChain chain) throws IOException,
			ServletException {
		
		try{
			if (!ignoreCurrentRequest(request)
					&& SecurityUtil.securityContextManager().currentUserIsSystem()) {
				logger.debug("Inside doFilter");
				final String id = Application.INSTANCE.getIdentity();
				ProcessContext.clear();
				ProcessContextUtil.buildProcessContext(id,id,id,id,id);
				ProcessContextPersister.save(ProcessContext.get());
				logger.debug("filter processing completed");
			} else {
				logger.debug("Creating Process Context From Logged In User");
				createProcessContextFromLoggedInUser(request);
			}
			chain.doFilter(request, response);
		}finally{
			ProcessContext.clear();
		}
	}
}
