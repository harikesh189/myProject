package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.Collection;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.Role.RoleStatus;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public interface RoleService {

	Collection<Permission> getAllPermission();

	Collection<Permission> getAllPermission(String roleId);

	Permission addPermission(Permission permission);

	Page<Role> getAllRoles(SearchCriteria searchCriteria);

	Set<Role> getRolesByIdentities(String... roleId);

	Role saveRole(Role role);

	Role getRoleByRoleCode(String code);

	void removeRole(Long id);
	
	Set<Role> getRoleByUserTypeAndIsDefaultAndStatus(String userType,boolean isDefault,RoleStatus status);

	Set<Role> getRolesByIdentities(Set<String> roleIdentities);
}
