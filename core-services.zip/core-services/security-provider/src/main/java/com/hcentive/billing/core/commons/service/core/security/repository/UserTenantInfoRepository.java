package com.hcentive.billing.core.commons.service.core.security.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.UserTenantInfo;


@Transactional
public interface UserTenantInfoRepository extends JpaRepository<UserTenantInfo, Long> {
	UserTenantInfo findByIdentity(String identity);
}
