package com.hcentive.billing.core.commons.service.core.security.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.ClientUser;

@Transactional
public interface ClientUserRepository extends JpaRepository<ClientUser, Long> {

	ClientUser findByAppKey(String appkey);

}
