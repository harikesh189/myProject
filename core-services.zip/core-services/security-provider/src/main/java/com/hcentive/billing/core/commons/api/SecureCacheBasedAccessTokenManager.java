package com.hcentive.billing.core.commons.api;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.RoleInfo;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousSlidingAccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.SlidingAccessToken;
import com.hcentive.billing.core.commons.security.shiro.ShiroCacheBasedAccessTokenManager;
import com.hcentive.billing.core.commons.tenant.mgmt.IgnoreTenantDuringProcessing;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class SecureCacheBasedAccessTokenManager extends
		ShiroCacheBasedAccessTokenManager {

	@Autowired
	private WFMCache<String, AccessToken> cache;
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SecureCacheBasedAccessTokenManager.class);

	@Override
	@IgnoreTenantDuringProcessing
	public AccessToken create(String tokenId, User user , final UserCredentials credential , final String issuedForIdp) {
			LOGGER.debug("Creating Sliding Token");
			final StringBuilder buildTokenIdentity = new StringBuilder(BillingConstant.SLIDING_ACCESS_TOKEN_PREFIX).append(tokenId);
			AccessToken accessToken = new SlidingAccessToken(buildTokenIdentity.toString(),
					UUID.randomUUID().toString(), user.getExternalId(),
					user.getTenantId(), getPermissions(user) ,credential.getId(),issuedForIdp, new DateTime().plusSeconds(validityInSeconds()));
			LOGGER.debug("Sliding Token Created with token id : {} and with vaill till {}",accessToken.getIdentity() ,accessToken.getValidTill());
			cache.put(ACCESS_TOKEN_PREFIX + accessToken.getIdentity(),
					accessToken,this.timeToLiveInSeconds);
			return accessToken;
	}
	
	@Override
	@IgnoreTenantDuringProcessing
	public AccessToken create(String tokenId, User user,
			Map<String, String> params , final UserCredentials credential,final String issuedForIdp) {
		LOGGER.debug("Creating Sliding Token");
		final StringBuilder buildTokenIdentity = new StringBuilder(BillingConstant.SLIDING_ACCESS_TOKEN_PREFIX).append(tokenId);
		final SlidingAccessToken accessToken = new SlidingAccessToken(buildTokenIdentity.toString(),
				UUID.randomUUID().toString(), user.getExternalId(),
				user.getTenantId(), getPermissions(user),params,credential.getId(),issuedForIdp,new DateTime().plusSeconds(validityInSeconds()));
		LOGGER.debug("Sliding Token Created with token id : {} and with vaill till {}",accessToken.getIdentity() ,accessToken.getValidTill());
		cache.put(ACCESS_TOKEN_PREFIX + accessToken.getIdentity(),
				accessToken,this.timeToLiveInSeconds);
		return accessToken;
	}
	
	@Override
	@IgnoreTenantDuringProcessing
	public AccessToken createAnonymousSlidingAccessToken(String tokenId,final Set<RoleInfo> roleInfos) {
		LOGGER.debug("Creating Sliding Token");
		final StringBuilder buildTokenIdentity = new StringBuilder(BillingConstant.SLIDING_ACCESS_TOKEN_PREFIX).append(tokenId);
		final AnonymousSlidingAccessToken accessToken = new AnonymousSlidingAccessToken(buildTokenIdentity.toString(),
				UUID.randomUUID().toString(),new AnonymousUser().getIdentity(),ProcessContext.get().getTenantId(),getPermissionsFromRoleInfo(roleInfos),null);
		LOGGER.debug("Sliding Token Created with token id : {} and with vaill till {}",accessToken.getIdentity() ,accessToken.getValidTill());
		cache.put(ACCESS_TOKEN_PREFIX + accessToken.getIdentity(),
				accessToken,this.timeToLiveInSeconds);
		return accessToken;
	}

	private Set<Permission> getPermissionsFromRoleInfo(final Set<RoleInfo> roleInfos){
		final Set<Permission> permissions = new HashSet<Permission>();
		for(final RoleInfo role : roleInfos){
			if(role.isActive())
				permissions.addAll(role.getPermissions());
		}
		return permissions;
	}
	
	private Set<Permission> getPermissions(User user) {
		final Set<Permission> permissions = new HashSet<Permission>();
		for(final Role role : user.getRoles()){
			if(role.isActive()){
				permissions.addAll(role.getPermissions());
			}
		}
		return permissions;
	}
}
