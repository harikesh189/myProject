package com.hcentive.billing.core.commons.service.core.security.manager;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.Role.RoleStatus;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.domain.RoleType;
import com.hcentive.billing.core.commons.service.core.security.dto.RoleDTO;
import com.hcentive.billing.core.commons.service.core.security.repository.PermissionRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.RoleRepository;
import com.hcentive.billing.core.commons.service.core.security.service.RoleService;
import com.hcentive.billing.core.commons.service.ebill.audit.handler.AuditUtil;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.config.ValidationConfig;
import com.hcentive.billing.core.commons.validation.config.ValidationConfigResolver;
import com.hcentive.billing.core.commons.validation.error.ValidationError;
import com.hcentive.billing.core.commons.validation.error.ValidationErrorSet;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

@Component
public class RoleManagerServiceImpl implements RoleManagerService {

	private static final Logger logger = LoggerFactory
			.getLogger(RoleManagerServiceImpl.class);
			
	@Autowired
	private RoleService userService;

	@Autowired
	private PermissionRepository permissionRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private ValidationConfigResolver validationConfigResolver;

	@Autowired
	private ValidationConfig roleValidationConfig;

	@Autowired
	private ValidationConfig roleUpdateValidationConfig;

	@Override
	public Collection<Permission> getAllPermissions() {
		return userService.getAllPermission();
	}

	@Override
	public Collection<Permission> getAllPermissions(String roleId) {
		return userService.getAllPermission(roleId);
	}

	@Override
	public Permission addPermission(Permission permission) {

		return userService.addPermission(permission);
	}

	@Override
	public Page<Role> getAllRoles(SearchCriteria searchCriteria) {

		return userService.getAllRoles(searchCriteria);
	}

	@Override
	public Object addRole(RoleDTO roleDto) {

		Validator<RoleDTO, ValidationError<RoleDTO>> roleValidator = validationConfigResolver
				.resolve(roleValidationConfig);

		ValidationErrorSet<RoleDTO> validationError = (ValidationErrorSet) roleValidator
				.validate(roleDto);

		if (validationError != null && validationError.getErrors().isEmpty()) {

			Set<com.hcentive.billing.core.commons.domain.Permission> permissions = new HashSet<com.hcentive.billing.core.commons.domain.Permission>();

			Role role = new Role(RandomGenerator.randomString());

			role.setCode(roleDto.getRoleCode());
			role.setDescription(roleDto.getRoleDesc());
			role.setName(roleDto.getRoleName());
			role.setPermissions(permissions);
			role.setTenantId(ProcessContext.get().getTenantId());
			role.setUserType(roleDto.getUserType());
			// if role has been created by admin, roletype will be user
			role.setRoleType(RoleType.USER);
			role.setDefault(roleDto.getIsDefault());
			role.setStatus(RoleStatus.ACTIVE);
			associatePermission(roleDto, permissions);
			Role savedRole = userService.saveRole(role);
			AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, savedRole.getIdentity(), 
					savedRole.getIdentity(), null, null, AuditMessageDefinition.USER_ROLE_ADDED,"roleName",savedRole.getName());
			return savedRole;
		} else {
			return validationError;
		}
	}

	@Override
	public void removeRole(Long id) {

		Role role = roleRepository.findByIdentity(id+"");
		final String roleName = role.getName();
		userService.removeRole(id);
		AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, id+"", 
				id+"", null, null, AuditMessageDefinition.USER_ROLE_DELETED,"roleName",roleName);
	}

	@Override
	public Object updateRole(RoleDTO roleDto) {

		Validator<RoleDTO, ValidationError<RoleDTO>> roleValidator = validationConfigResolver
				.resolve(roleUpdateValidationConfig);

		ValidationErrorSet<RoleDTO> validationError = (ValidationErrorSet) roleValidator
				.validate(roleDto);

		if (validationError != null && validationError.getErrors().isEmpty()) {

			Role role = roleRepository.findByIdentity(roleDto.getIdentity());

			Set<com.hcentive.billing.core.commons.domain.Permission> permissions = new HashSet<com.hcentive.billing.core.commons.domain.Permission>();

			role.setPermissions(permissions);

			associatePermission(roleDto, permissions);
			logger.debug("coming status is : "+roleDto.getStatus()+" and previous status is : "+role.getStatus().name());
			if(!role.getStatus().name().equalsIgnoreCase(roleDto.getStatus())){
				
				if(RoleStatus.ACTIVE.name().equalsIgnoreCase(roleDto.getStatus())){
					role.setStatus(RoleStatus.ACTIVE);
				}else{
					role.setStatus(RoleStatus.INACTIVE);
				}
			}
			Role savedRole = userService.saveRole(role);
			AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, savedRole.getIdentity(), 
					savedRole.getIdentity(), null, null, AuditMessageDefinition.USER_ROLE_UPDATED,"roleName",savedRole.getName());
			return savedRole;
		} else {
			return validationError;
		}
	}

	private void associatePermission(RoleDTO roleDto,
			Set<com.hcentive.billing.core.commons.domain.Permission> permissions) {
		Set<String> permissionIds = roleDto.getPermissionIds();

		for (Iterator<String> iterator = permissionIds.iterator(); iterator
				.hasNext();) {
			String identity = iterator.next();

			com.hcentive.billing.core.commons.domain.Permission permission = permissionRepository
					.findByIdentity(identity);

			permissions.add(permission);

		}
	}
	
	@Override
	public Role getRoleByCode(String code){
		return roleRepository.findByCode(code);
	}
}
