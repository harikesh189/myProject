package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.Role.RoleStatus;
import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.PermissionRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.RoleRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;
import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteriaOnColumns;

@Component
public class RoleServiceImpl implements RoleService {

	private static final Logger logger = LoggerFactory
			.getLogger(UserServiceImpl.class);
	@Autowired
	protected UserRepository userRepository;

	@Autowired
	protected RoleRepository roleRepository;

	@Autowired
	protected PermissionRepository permissionRepository;

	@Autowired
	protected FilterSupportRepository filterSupportRepository;

	@Override
	@RequiresPermissions(value = Permission.ADMIN_READ_PERMISSION)
	public Collection<com.hcentive.billing.core.commons.domain.Permission> getAllPermission() {

		Set<com.hcentive.billing.core.commons.domain.Permission> permissions = new HashSet<com.hcentive.billing.core.commons.domain.Permission>();

		List<com.hcentive.billing.core.commons.domain.Permission> permissionList = permissionRepository
				.findAll();

		permissions.addAll(permissionList);

		return permissions;
	}

	@Override
	@RequiresPermissions(value = Permission.ADMIN_READ_PERMISSION)
	public Collection<com.hcentive.billing.core.commons.domain.Permission> getAllPermission(
			String roleId) {

		Role role = roleRepository.findByIdentity(roleId);

		return role.getPermissions();
	}

	@Transactional
	@Override
	@RequiresPermissions(value = Permission.ADMIN_ADD_PERMISSION)
	public com.hcentive.billing.core.commons.domain.Permission addPermission(
			com.hcentive.billing.core.commons.domain.Permission permission) {
		permission.setIdentity(RandomGenerator.randomString());

		return permissionRepository.save(permission);
	}

	@Override
	@RequiresPermissions(value = Permission.ADMIN_READ_ROLE)
	public Page<Role> getAllRoles(SearchCriteria searchCriteria) {

		String tenantId = ProcessContext.get().getTenantId();

		SearchCriteriaOnColumns searchCriteriaOnColumns = new SearchCriteriaOnColumns();
		searchCriteriaOnColumns.setColumnValue("('" + tenantId + "','System')");
		searchCriteriaOnColumns.setOperator("IN");
		searchCriteriaOnColumns.setCaseSensitiveSearch(true);

		searchCriteria.getCriteria().put("tenantId", searchCriteriaOnColumns);

		return filterSupportRepository.findDomainByFilterCriteria(Role.class,
				searchCriteria);

	}

	@Transactional
	@Override
	@RequiresPermissions(value = Permission.ADMIN_ADD_ROLE)
	public Role saveRole(Role role) {
		if ("System".equalsIgnoreCase(role.getTenantId())) {
			throw new IllegalArgumentException(
					"Can not Add OR Update System roles");
		}
		return roleRepository.save(role);
	}

	@Override
	@Transactional
	@RequiresPermissions(value = Permission.ADMIN_REMOVE_ROLE)
	public void removeRole(Long id) {
		Role role = roleRepository.getOne(id);
		if (role == null || "System".equalsIgnoreCase(role.getTenantId())) {
			throw new IllegalArgumentException(
					"Can not delete System roles OR roles does not exists");
		}

		roleRepository.delete(id);
	}

	@Override
	@RequiresPermissions(value = Permission.ADMIN_READ_ROLE)
	public Set<Role> getRolesByIdentities(String... roleIds) {
		Set<String> roleIdentities = new HashSet<>(Arrays.asList(roleIds));
		return getRolesByIdentities(roleIdentities);
	}
	
	@Override
	@RequiresPermissions(value = Permission.ADMIN_READ_ROLE)
	public Set<Role> getRolesByIdentities(Set<String> roleIdentities) {
		Set<Role> roles = new HashSet<Role>();
		for (String roleId : roleIdentities) {
			Role role = roleRepository.findByIdentity(roleId);
			if (null != role)
				roles.add(role);
		}
		return roles;
	}

	@Override
	//@RequiresPermissions(value = Permission.ADMIN_READ_ROLE)
	public Role getRoleByRoleCode(String code) {

		return roleRepository.findByCode(code);

	}

	@Override
	public Set<Role> getRoleByUserTypeAndIsDefaultAndStatus(String userType,boolean isDefault,RoleStatus status) {
		return roleRepository.findByUserTypeAndIsDefaultAndStatus(userType,isDefault,status);
	}
}
