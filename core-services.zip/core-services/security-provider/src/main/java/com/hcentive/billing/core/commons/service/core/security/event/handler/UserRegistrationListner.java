package com.hcentive.billing.core.commons.service.core.security.event.handler;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.ContactPerson;
import com.hcentive.billing.core.commons.domain.ContactSet;
import com.hcentive.billing.core.commons.domain.DraftUser;
import com.hcentive.billing.core.commons.domain.OrgProfile;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.Role.RoleStatus;
import com.hcentive.billing.core.commons.domain.enumtype.UserType;
import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.service.core.security.dto.UserCreationDTO;
import com.hcentive.billing.core.commons.service.core.security.manager.UserManager;
import com.hcentive.billing.core.commons.service.core.security.service.RoleService;
import com.hcentive.billing.core.commons.util.PayloadWrapper;

@Component
public class UserRegistrationListner {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(UserRegistrationListner.class);

	@Autowired
	private EntityManagerFactory emf;
	
	@Autowired
	UserManager userManager;
	
	@Autowired
	RoleService roleService;
	
	@EventSubscription(eventName = { EventType.NEW_CUSTOMER_ADDED,EventType.NEW_BROKER_ADDED  })
	public void triggerUserRegistration(PayloadWrapper<BusinessEntity> payloadWrapper) {
		
		processUserRegistration(payloadWrapper);
	}
	
	private void processUserRegistration(PayloadWrapper<BusinessEntity> payloadWrapper) {
		LOGGER.debug("Creating and saving draft user.");
		BusinessEntity be = payloadWrapper.getPayload();
		final UserCreationDTO userCreationDTO = populateAndGetUserCreationDto(be);
		final DraftUser draftUser = userManager.prepareAndGetDraftUser(userCreationDTO);
		if(draftUser != null){
			userManager.publishUserRegistrationEvent(draftUser,be);
			LOGGER.debug("triggering email for user registration");
		}
		else{
			LOGGER.error("Insufficient information to trigger email as draft user is null.");
			throw new IllegalStateException("Draft User is null.");
		}
	}
	
	
	
	private UserCreationDTO populateAndGetUserCreationDto(final BusinessEntity be){
		LOGGER.debug("Populating User Creation DTO");
		final UserCreationDTO userCreationDTO = new UserCreationDTO();
		
		Set<String> beExternalIds = new HashSet<String>();
		beExternalIds.add(be.getExternalId());
		userCreationDTO.setBeExternalIds(beExternalIds);
		Profile profile = be.getProfile();
		PersonalProfile personalProfile = null;
		
		//TODO need to be changed when group-setup xsd support contact persons
		if(profile instanceof PersonalProfile){
			LOGGER.debug("Profile instance of personal profil");
			personalProfile =  (PersonalProfile)profile;
		}else if(profile instanceof OrgProfile){
			LOGGER.debug("Profile is org profile");
			OrgProfile orgProfile = (OrgProfile)profile;
			ContactSet<ContactPerson> contactPersonsContactSets = orgProfile.getContactPersons();
			if(contactPersonsContactSets!=null){
				Collection<ContactPerson> contactPersons = contactPersonsContactSets.contacts(); 
				for (ContactPerson contactPerson : contactPersons) {
					if(contactPerson.isPrimary()){
						LOGGER.debug("Assiging Personal Profile of primary contact person");
						personalProfile = contactPerson.getProfile();
						break;
					}
				}
			}
			else{
				LOGGER.debug(" contact persons is not defined");
			}
		}
		userCreationDTO.setPersonalProfile((profile == null) ? null : personalProfile);
		
		final String clientAppId = (String)SecurityUtil.securityConfigurationManager().getSecurityConfiguration(BillingConstant.BE_TO_CLIENT_APP_CACHING+be.getType());
		userCreationDTO.setClientAppId(clientAppId);
		
		Set<String> managesBeOfTypes = new HashSet<>();
		managesBeOfTypes.add(be.getType());
		userCreationDTO.setManagesBEofTypes(managesBeOfTypes);
		Set<Role> roles = roleService.getRoleByUserTypeAndIsDefaultAndStatus(be.getType(),true,RoleStatus.ACTIVE);
		
		Set<String> roleIdentities = new HashSet<String>();
		if(null != roles){
			for (Role role : roles) {
				roleIdentities.add((role == null) ? null : role.getIdentity());
			}
		}
		userCreationDTO.setRoleIdentities(roleIdentities);
		
		userCreationDTO.setUserType(UserType.Manager); //only manager can be added here.
		LOGGER.debug("Returning from user creation dto");
		return userCreationDTO;
	}
	
}
