package com.hcentive.billing.core.commons.service.core.security.constants;

public final class SecurityConstants {

	public static final String JS_PATTERN = "/js/**";
	public static final String CSS_PATTERN = "/css/**";
	public static final String IMG_PATTERN = "/images/**";
	
	public static final String APP_LOGOUT_END_POINT_KEY = "_logout_endpoint";

}
