/**
 * 
 */
package com.hcentive.billing.core.commons.service.core.security.service;

import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.api.support.IdpUserToken;
import com.hcentive.billing.core.commons.security.AuthAccessToken;
import com.hcentive.billing.core.commons.security.shiro.AnonymousAuthToken;
import com.hcentive.billing.core.commons.security.shiro.ClientUserToken;
import com.hcentive.billing.core.commons.util.EncryptionUtil;

/**
 * @author Kumar Sambhav Jain
 * 
 */
public class CredentialsMatcherService implements CredentialsMatcher {

	private static final Logger logger = LoggerFactory
			.getLogger(CredentialsMatcherService.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.shiro.authc.credential.CredentialsMatcher#doCredentialsMatch
	 * (org.apache.shiro.authc.AuthenticationToken,
	 * org.apache.shiro.authc.AuthenticationInfo)
	 */
	@Override
	public boolean doCredentialsMatch(AuthenticationToken token,
			AuthenticationInfo info) {
		logger.debug("\n\n\nWill try to match credentials");
		boolean result = false;
		logger.debug("\n\nPassword from token: {} Username from token : {}  Password from authentication info: {}",token.getCredentials(),token.getPrincipal(),info.getCredentials());
		if (token instanceof WFMUsernamePasswordToken) {
			logger.debug("Token instance of WFMUsernamePasswordToken");
			final WFMUsernamePasswordToken usernamePassword = (WFMUsernamePasswordToken) token;
			result = EncryptionUtil.oneWayCheckPassword(
					(String) usernamePassword.getCredentials(),
					(String) info.getCredentials());

			logger.debug("\n\n\n\t\t\t!!! Check password = {}" , result);

		} else if (token instanceof IdpUserToken) {
			logger.debug("Token instance of IdpUserToken");
			result = true;
		} else if (token instanceof ClientUserToken) {
			logger.debug("Token instance of ClientUserToken");
			return true;
		} else if (token instanceof AuthAccessToken) {
			logger.debug("Token instance of AuthAccessToken");
			result = true;
		}else if(token instanceof AnonymousAuthToken){
			logger.debug("Token instance of AnonymousAuthToken");
			return true;
		}
		logger.debug("Credential matching result is {}", result);
		return result;
	}

}
