package com.hcentive.billing.core.commons.service.core.security.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.api.IdentityProvider;
import com.hcentive.billing.core.commons.api.IdpSamlConfiguration;

@Transactional
public interface IdpSamlConfigurationRepository extends
JpaRepository<IdpSamlConfiguration, Long> {

	public IdpSamlConfiguration findByIdentityProvider(
			final IdentityProvider identityProvider);

}
