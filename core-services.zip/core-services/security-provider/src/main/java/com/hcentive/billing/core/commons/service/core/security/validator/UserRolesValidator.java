package com.hcentive.billing.core.commons.service.core.security.validator;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.dto.UserOperation;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.service.RoleService;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;

public class UserRolesValidator implements
		Validator<UserDTO, SingleValidationError<UserDTO>> {

	@Autowired
	RoleService roleService;

	@Override
	public SingleValidationError<UserDTO> validate(UserDTO t) {
		if (t.getOperationsPerformed().contains(UserOperation.AddUser)
				|| t.getOperationsPerformed().contains(
						UserOperation.UpdateUserRoles)) {
		if(t.getRoleIdentities()!=null){
					Set<String> roleIds = t.getRoleIdentities();
					String[] r1 = roleIds.toArray(new String[0]);
					Set<Role> roles = roleService.getRolesByIdentities(r1);
					if (r1.length != roles.size())
						return new SingleValidationError<>("Invalid Roles",
								"Invalid Roles", t);
					return null;
				}
		}
		return null;

	}

	@Override
	public String identity() {
		// TODO Auto-generated method stub
		return null;
	}

}
