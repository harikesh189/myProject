package com.hcentive.billing.core.commons.service.core.security.web.idpsupport;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.beans.SpringBackedBeanRegistry;

@Component
public class IdpAuthenticationProcessorRegistry extends
		SpringBackedBeanRegistry<IdpAuthenticationProcesingController> {

	private static final Logger logger = LoggerFactory
			.getLogger(IdpAuthenticationProcessorRegistry.class);

	private final Map<String, IdpAuthenticationProcesingController> registry = new HashMap<String, IdpAuthenticationProcesingController>();

	@Override
	protected Class<IdpAuthenticationProcesingController> lookupForType() {
		return IdpAuthenticationProcesingController.class;
	}

	@Override
	protected void registerBean(IdpAuthenticationProcesingController bean) {
		registry.put(bean.identity(), bean);
	}

	public IdpAuthenticationProcesingController getHandler() {
		return registry.get(RequestContext.get().identityProvider()
				.getHandledByController());
	}

}
