package com.hcentive.billing.core.commons.api.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.SpelEvaluationException;
import org.springframework.expression.spel.SpelParseException;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.security.SecurityConfigurationManager;
import com.hcentive.billing.core.commons.service.core.security.dto.UserCreationDTO;
import com.hcentive.billing.core.commons.service.core.security.event.handler.UserRegistrationListner;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@Component
@SuppressWarnings({"rawtypes", "unchecked"})
public class DraftUserIdentifierResolver {
	

	private static final String DRAFT_USER_IDENTIFIER_SUFFIX = "_draftUserIdentifierKey";
	
	private static final String DEFAULT_ADMINISTRATOR_IDENTIFIER = "personalProfile.emails.contacts.iterator().next().emailId";
	
	private static final String DEFAULT_MANAGER_IDENTIFIER = "personalProfile.emails.contacts.iterator().next().emailId+beExternalIds.iterator().next()";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserRegistrationListner.class);
	
	@Autowired
	private SecurityConfigurationManager scm;
	
	public String resolveDraftUserIdentifier(UserCreationDTO userCreationDTO){
		final String tenant = ProcessContext.get().getTenantId();
		final StringBuilder draftUserIdentifierKeyBuilder = new StringBuilder(tenant);
		draftUserIdentifierKeyBuilder.append("_").append(userCreationDTO.getUserType().getType()).append(DRAFT_USER_IDENTIFIER_SUFFIX);
		final String draftUserIdentifierKey =draftUserIdentifierKeyBuilder.toString();
		String draftUserIdentifierSpelExp = (String)scm.getSecurityConfiguration(draftUserIdentifierKey);
		if(draftUserIdentifierSpelExp==null){
			if(userCreationDTO.getUserType().getType().equals("Administrator")){
				draftUserIdentifierSpelExp=DEFAULT_ADMINISTRATOR_IDENTIFIER;
			}else if(userCreationDTO.getUserType().getType().equals("Manager")){
				draftUserIdentifierSpelExp=DEFAULT_MANAGER_IDENTIFIER;
			}
		}
		ExpressionParser parser = new SpelExpressionParser();
		StandardEvaluationContext itemContext = new StandardEvaluationContext(userCreationDTO);
		Expression exp = null;
		try{
			LOGGER.debug("draftUserIdentifierSpelExp is {}", draftUserIdentifierSpelExp);
			exp = parser.parseExpression(draftUserIdentifierSpelExp);
			LOGGER.debug("Spel expression is {}",exp);
		}
		catch (SpelEvaluationException e){
			LOGGER.error("SpelEvaluationException - Illegal Spel exp {}",e);
			throw new IllegalStateException("Illegal Spel expression evaluation"+draftUserIdentifierSpelExp);
		}
		catch (SpelParseException e){
			LOGGER.error("SpelParseException - Illegal Spel parse {}",e);
			throw new IllegalStateException("Spel parse evaluation"+draftUserIdentifierSpelExp);
		}
		catch (Exception e){
			LOGGER.error("Exception in getting draft user identifier",e);
			throw new IllegalStateException("Spel parse evaluation"+draftUserIdentifierSpelExp);
		}
		Object obj = exp.getValue(itemContext, Object.class);
		if( obj == null){
			throw new IllegalStateException("No Draft user identifier found for tenant: "+tenant);
		}
		return obj.toString();
	}
}
