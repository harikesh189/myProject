package com.hcentive.billing.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.service.comm.DefaultServiceRequestConsumer;
import com.hcentive.billing.core.commons.service.comm.ServiceClient;
import com.hcentive.billing.core.commons.service.comm.ServiceConfig;
import com.hcentive.billing.core.commons.service.comm.ServiceRequestConsumer;
import com.hcentive.billing.core.commons.util.ServiceComm;

@Configuration
public class IMInterserviceCommConfig {

	@Bean
	public ServiceClient serviceClient() {
		return new ServiceClient(serviceClientConfig());
	}

	@Bean
	public ServiceConfig serviceClientConfig() {
		return new ServiceConfig(ServiceComm.SECURITY_SERVICE_CLIENT,
				ServiceComm.SECURITY_SERVICE_CLIENT);
	}

	@Bean
	public FetchAuthenticationInfoByTokenIdHandler fetchTokenByTokenIdHandler() {
		return new FetchAuthenticationInfoByTokenIdHandler();
	}

	@Bean
	public ServiceConfig fetchTokenByTokenIdService() {
		final ServiceConfig config = new ServiceConfig(
				ServiceComm.SECURITYPROVIDER_FETCHAUTHENTICATIONINFOBBYTOKENID,
				ServiceComm.SECURITYPROVIDER_FETCHAUTHENTICATIONINFOBBYTOKENID);
		return config;
	}

	@Bean
	public ServiceRequestConsumer fetchTokenByTokenIdRequestConsumer() {
		return new DefaultServiceRequestConsumer(fetchTokenByTokenIdService(),
				fetchTokenByTokenIdHandler());
	}
}
