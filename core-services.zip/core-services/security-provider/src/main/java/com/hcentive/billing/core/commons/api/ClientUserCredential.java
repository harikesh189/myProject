package com.hcentive.billing.core.commons.api;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.UserCredentials;

@Entity
@Table(name = "user_credential")
@DiscriminatorValue(value = "CLIENT_CREDENTIAL")
public class ClientUserCredential extends UserCredentials {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Access(AccessType.FIELD)
	@Column(name = "secret_key")
	private String secretKey;

	protected ClientUserCredential(){
		this.setIdpKey("idp.wfm.hcentive");
	}
	@Override
	public Object getAuthKey() {
		return secretKey;
	}
}
