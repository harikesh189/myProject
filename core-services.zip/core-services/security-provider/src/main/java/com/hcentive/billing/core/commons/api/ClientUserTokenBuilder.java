package com.hcentive.billing.core.commons.api;

import org.apache.shiro.authc.AuthenticationToken;

import com.hcentive.billing.core.commons.security.shiro.ClientUserToken;
import com.hcentive.billing.core.commons.security.shiro.ShiroAuthenticationTokenBuilder;

public class ClientUserTokenBuilder implements
		ShiroAuthenticationTokenBuilder<ClientUserIdentity> {

	@Override
	public AuthenticationToken build(final ClientUserIdentity credential) {
		ClientUserToken clientUserToken = new ClientUserToken(
				credential.userIdentity());
		return clientUserToken;
	}

	@Override
	public Class<ClientUserIdentity> buildsFromType() {
		return ClientUserIdentity.class;
	}

}
