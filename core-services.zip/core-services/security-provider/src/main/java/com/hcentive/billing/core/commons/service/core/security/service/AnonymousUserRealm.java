package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.AbstractSecurityRealm;
import com.hcentive.billing.core.commons.api.TrustedEntity;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.shiro.AnonymousAuthToken;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.repository.TrustedEntityRepository;
import com.hcentive.billing.core.commons.util.RandomGenerator;

public class AnonymousUserRealm extends
		AbstractSecurityRealm<AnonymousAuthToken> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AnonymousUserRealm.class);
	
	@Autowired
	private TrustedEntityRepository trustedEntityRepository;

	public AnonymousUserRealm() {
		super(AnonymousAuthToken.class);
	}


	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken token) throws AuthenticationException {
		return loadAuthenticationInfo((AnonymousAuthToken) token);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private AuthenticationInfo loadAuthenticationInfo(
			final AnonymousAuthToken token) {
		final String realmName = this.getClass().getName();
		LOGGER.debug("Creating SimplePrincipalCollection");
		final String trustedEntityName = (String)token.getPrincipal();
		final TrustedEntity trustedEntity = trustedEntityRepository.findByName(trustedEntityName);
		if(trustedEntity == null){
			return null;
		}
		final SimplePrincipalCollection principalCollection = new SimplePrincipalCollection(
				token.getPrincipal(), realmName);
		LOGGER.debug("Created SimplePrincipalCollection");
		Collection principals = new ArrayList();
		final AccessToken accessToken = Utils.createAnonymousAccessToken(RandomGenerator
				.randomString(),trustedEntity.getRoles());
		principals.add(accessToken);
		principals.add(new AnonymousUser());
		principalCollection.addAll(principals, realmName);
		token.associateAccessToken(accessToken);
		LOGGER.debug("Returning from Authentication Info");
		return new SimpleAuthenticationInfo(principalCollection,
				token.getCredentials());
	}

}
