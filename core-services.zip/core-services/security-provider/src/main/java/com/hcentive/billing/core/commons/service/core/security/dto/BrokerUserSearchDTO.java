package com.hcentive.billing.core.commons.service.core.security.dto;

import com.hcentive.billing.core.commons.vo.SearchCriteria;

public class BrokerUserSearchDTO extends UserSearchDto {

	@Override
	public SearchCriteria getUserSearchCriteria() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isActivateByActivationCode() {
		// TODO Auto-generated method stub
		return false;
	}

}
