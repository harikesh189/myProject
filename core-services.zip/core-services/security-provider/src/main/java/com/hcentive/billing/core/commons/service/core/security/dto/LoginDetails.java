package com.hcentive.billing.core.commons.service.core.security.dto;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

public class LoginDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7358804810558776240L;
	private String userId;

	public String getUserId() {
		return userId;
	}

	public DateTime getDateTime() {
		return dateTime;
	}

	private DateTime dateTime;

	public LoginDetails(String userId, DateTime dateTime) {
		this.userId = userId;
		this.dateTime = dateTime;
	}

}
