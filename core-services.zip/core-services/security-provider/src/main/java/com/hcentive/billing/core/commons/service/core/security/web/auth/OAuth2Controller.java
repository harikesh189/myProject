package com.hcentive.billing.core.commons.service.core.security.web.auth;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.OAuth2ProtocolConstants;
import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.SessionContext;
import com.hcentive.billing.core.commons.api.support.HttpRedirectURIResolver;
import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.SecuredAccessContext;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.SlidingAccessToken;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.constants.SecurityConstants;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManagerHelper;
import com.hcentive.billing.core.commons.service.core.security.web.idpsupport.IdpAuthenticationProcesingController;
import com.hcentive.billing.core.commons.service.core.security.web.idpsupport.IdpAuthenticationProcessorRegistry;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;
import com.hcentive.billing.core.commons.web.WebUtils;

@Controller
@RequestMapping("/security/{enterpriseName}/oAuth2")
public class OAuth2Controller {


	private static final Logger logger = LoggerFactory
			.getLogger(OAuth2Controller.class);

	@Autowired
	private AuthManager authManager;

	@Value("${security.logout.message}")
	private String logoutMessage;
	
	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;

	@Autowired
	private Environment env;

	@Autowired
	private IdpAuthenticationProcessorRegistry idpAuthenticationProcessorRegistry;
	
	@Autowired
	private WFMCache<String, String> authenticationCache;

	@Autowired
	private AuthManagerHelper authManagerHelper;
	
	@Value(value = "${security.auth.timeToLiveInSeconds:10800}")
	protected int timeToLiveInSeconds;
	
	@RequestMapping("/initiate")
	public String initiateAuthentication(final HttpServletRequest request , @PathVariable("enterpriseName") final String enterpriseName) {
		final String oAuth2Parameters = OAuth2Parameters.parse(request)
				.toString();
		final AccessToken accessToken = authManager.doLoginForLoginTrustedEntity(AnonymousUserIdentity.LOGIN_USER_IDENTITY);
		AuthWebUtil.populateSessionContext(accessToken.getIdentity(),securityUIAppKey);
		final ProcessContext pc = ProcessContext.get();
		final boolean currentStatus = pc.shouldIgnoreTenant();
		pc.ignoreTenantDuringProcessing();
		authenticationCache.put(BillingConstant.AUTHENTICATION_STATE_CACHE_KEY+accessToken.getIdentity(), oAuth2Parameters,timeToLiveInSeconds);
		revertOldValue(currentStatus,pc);
		final StringBuilder redirectUrlBuilder = buildSecurityAppUrl(request,"login");
		return "redirect:" + redirectUrlBuilder.toString(); 
	}

	private StringBuilder buildSecurityAppUrl(final HttpServletRequest request,String htmlPageName) {
		final RequestContext requestContext = RequestContext.get();
		final String redirectUri = request
				.getParameter(OAuth2ProtocolConstants.REDIRECT_URI);
		final StringBuilder redirectUrlBuilder = new StringBuilder(WebUtils.getBaseUrl(request));
		redirectUrlBuilder.append("/").append(requestContext.enterprise().getName()).append("/").append(securityUIAppKey).append("/").
		append("?client_id=").append(requestContext.clientApp().getAppKey()).
		append("&idpKey=").append(requestContext.identityProvider().getIdpKey());
		if(redirectUri != null){
			redirectUrlBuilder.append("&redirect_uri=").append(redirectUri);
		}
		redirectUrlBuilder.append("/#/").append(htmlPageName);
		return redirectUrlBuilder;
	}
	
	private void revertOldValue(boolean ignoreTenant, ProcessContext pc) {
		if(ignoreTenant){
			pc.ignoreTenantDuringProcessing();
		}else{
			pc.acknowledgeTenantDuringProcessing();
		}
	}

	
	final private ObjectMapper mapper = new ObjectMapper();
	
	@RequestMapping("/login")
	public String login(final HttpServletRequest request , @PathVariable("enterpriseName") final String enterpriseName) throws JsonProcessingException {
		final String oAuth2Parameters = OAuth2Parameters.parse(request)
				.toString();
		final IdpAuthenticationProcesingController handler = idpAuthenticationProcessorRegistry
				.getHandler();
		AuthWebUtil.attachStateAndCallBackUrl(request, oAuth2Parameters,"/security/"+enterpriseName+"/oAuth2/int/assertIdentity");
		return AuthWebUtil.createForwardToPathFromController(handler.loginEndpointToForwardForProcessing());
	}
	
	@RequestMapping("/register")
	public String registration(final HttpServletRequest request , @PathVariable("enterpriseName") final String enterpriseName) throws JsonProcessingException {
		final String oAuth2Parameters = OAuth2Parameters.parse(request)
				.toString();
		final IdpAuthenticationProcesingController handler = idpAuthenticationProcessorRegistry
				.getHandler();
		AuthWebUtil.attachStateAndCallBackUrl(request, oAuth2Parameters,"/security/"+enterpriseName+"/oAuth2/int/register");
		return AuthWebUtil.createForwardToPathFromController(handler.registrationEndpointToForwardForProcessing());
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/int/chooseIdp")
	public ModelAndView choseIdp(final HttpServletRequest request) throws JsonProcessingException {
		final ModelAndView mav = new ModelAndView("index");
		AuthWebUtil.addStandardViewItems(request, mav,env);
		final List<ClientAppIdpEnterpriseConfig> availableConfigs = ( List<ClientAppIdpEnterpriseConfig>)request.getAttribute("availableConfigs");
		mav.addObject("availableIdps",  mapper.writeValueAsString(AuthWebUtil.getIdpInfos(availableConfigs)));
		return mav;
	}
	


	@RequestMapping("/int/assertIdentity")
	public String assertIdentity(HttpServletRequest request,@PathVariable("enterpriseName") String enterpriseName) {
		logger.debug("Going to assert credentials");
		processLogoutInternal();
		final String redirectUrl = authManagerHelper.processLoginAndGetPostAuthenticationState(request, enterpriseName);
		logger.debug("End::doAuthentication");
		return "redirect:" + redirectUrl;
	}
	
	
	@RequestMapping("/int/register")
	public String register(HttpServletRequest request,@PathVariable("enterpriseName") String enterpriseName) {
		logger.debug("Going to assert credentials");
		processLogoutInternal();
		final String redirectUrl = authManagerHelper.processLoginAndGetPostAuthenticationState(request, enterpriseName);
		logger.debug("End::doAuthentication");
		return "redirect:" + redirectUrl;
	}

	
	/**
	 * Logs out a loggedin user.
	 * 
	 * @return
	 */
	@RequestMapping( value = "/logout", method={RequestMethod.POST})
	public String doLogout(HttpServletRequest request,
			@RequestParam(required = false) String userType) {
		logger.debug("Logging out the user");
		RequestContext requestContext = RequestContext.get();
		associateToken(request, requestContext);
		buildProcessContext();
		String url = findLogoutRedirectURL(request);
		try {
			final User user = Utils.getUser();
			logger.debug("User found : {}", user);
			final AccessToken accessToken = Utils.getAccessToken();
			logger.debug("Access Token Found : {}",accessToken);
			processLogoutInternal();			
			final IdpAuthenticationProcesingController handler = idpAuthenticationProcessorRegistry
					.getHandler();
			
			if(null != user && handler.logoutEndpointToForwardForProcessing() != null && requestContext.clientAppIdpEnterpriseConfig()
					.getLogoutIdpEndPoint() != null && requestContext.clientAppIdpEnterpriseConfig()
							.getLogoutIdpEndPoint().trim() != null ){
				AuthWebUtil.attachStateAndCallBackUrl(request, user.getId().toString(),"/security/"+requestContext.enterprise().getName()+"/oAuth2/int/logout");
				logger.debug("User Id and call back url attached");
				if(accessToken instanceof SlidingAccessToken)
					AuthWebUtil.attachSessionParams(request, ((SlidingAccessToken)accessToken).getTokenAttributes());
				logger.debug("Session Params Attached");
				logger.debug("Forwarding to logout url");
				return AuthWebUtil.createForwardToPathFromController(handler.logoutEndpointToForwardForProcessing());
			}
		} catch (Throwable th) {
			logger.error("Error while logging out", th);
		}finally{
			logger.debug("Finally Clearing Process Context");
			ProcessContext.clear();
		}
		logger.debug("User logged out");
		final AccessToken accessToken = authManager.doLoginForLoginTrustedEntity(AnonymousUserIdentity.LOGIN_USER_IDENTITY);
		request.setAttribute("tokenId", accessToken.getIdentity());
		return "redirect:" + url;
	}

	private void associateToken(HttpServletRequest request,
			RequestContext requestContext) {
		final String sessionIdFromCookie = AuthWebUtil.getTokenIdFromCookie(request,requestContext.clientApp().getAppKey());
		logger.debug("Creating Secured Access Context");
		try{
			if(null != sessionIdFromCookie)
				SecuredAccessContext.createNew(sessionIdFromCookie);
		}catch (Exception e) {
			logger.debug("Failed to bind subject to sesssionId: {} as user already logged out", sessionIdFromCookie);
		}
	}


	private void buildProcessContext() {
		User user = Utils.getUser();
		if(null != user){
			ProcessContext.clear();
			logger.debug("Building Process Context");
			ProcessContextUtil.buildProcessContext(user.getExternalId(), null, user.getTenantId(), null,null);
		}
	}

	@RequestMapping(value = "/int/logout")
	public String doLogout(HttpServletRequest request){
		processLogoutInternal();
		String url = findLogoutRedirectURL(request);
		return "redirect:" + url;
	}
	
	private void processLogoutInternal() {
		//if already logged out do not do anything.
		if(null != Utils.getUser()){
			authManager.logout();
			SessionContext.get().invalidateSession();
			logger.debug("Successful logout");
		}
		logger.debug("No logged in user found");
	}

	private String findLogoutRedirectURL(HttpServletRequest request) {
		RequestContext requestContext = RequestContext.get();
		StringBuilder redirectUrlBuilder = new StringBuilder(requestContext.enterprise().getName()).
				append("_").append(requestContext.clientApp().getAppKey()).append(SecurityConstants.APP_LOGOUT_END_POINT_KEY);
		String redirectUrl =  (String)SecurityUtil.securityConfigurationManager().getSecurityConfiguration(redirectUrlBuilder.toString());
		if(null != redirectUrl && !StringUtils.isEmpty(redirectUrl)){
			return redirectUrl;
		}
		redirectUrl = requestContext.clientApp()
				.getDefaultLogoutEndPoint();
		if(null != redirectUrl && (redirectUrl.startsWith("http") || redirectUrl.startsWith("https"))){
			return redirectUrl;
		}
		return buildSecurityAppUrl(request,"logout").toString();
	}

	public static class OAuth2Parameters {

		private static final ObjectMapper MAPPER = new ObjectMapper();

		private String redirectUri;
		private String responseType = "token";
		private String state;

		public String getRedirectUri() {
			return redirectUri != null ? redirectUri : RequestContext.get()
					.clientApp().getDefaultEndPoint();
		}

		public void setRedirectUri(String redirectUri) {
			this.redirectUri = redirectUri;
		}

		public String getResponseType() {
			return responseType;
		}

		public void setResponseType(String responseType) {
			this.responseType = responseType;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		protected OAuth2Parameters() {
		}

		public String toString() {
			try {
				return WebUtils.encodeBase64String(MAPPER
						.writeValueAsString(this));
			} catch (JsonProcessingException e) {
				return e.toString();
			}
		}

		public static OAuth2Parameters parse(final HttpServletRequest request) {
			final OAuth2Parameters oAuth2Parameters = new OAuth2Parameters();
			oAuth2Parameters.setRedirectUri(request
					.getParameter(OAuth2ProtocolConstants.REDIRECT_URI));
			oAuth2Parameters.setResponseType(request
					.getParameter(OAuth2ProtocolConstants.RESPONSE_TYPE));
			oAuth2Parameters.setState(request
					.getParameter(OAuth2ProtocolConstants.STATE));
			return oAuth2Parameters;
		}

		public static OAuth2Parameters parse(final String encodedState) {
			final String state = WebUtils.decodeBase64(encodedState);
			try {
				return MAPPER.readValue(state, OAuth2Parameters.class);
			} catch (IOException e) {
				throw new IllegalArgumentException("Parse Failed.", e);
			}
		}

	}

	public static class OAuth2HttpRedirectURIResolver implements
			HttpRedirectURIResolver {

		public static final OAuth2HttpRedirectURIResolver INSTANCE = new OAuth2HttpRedirectURIResolver();

		private OAuth2HttpRedirectURIResolver() {

		}

		@Override
		public String resolve(HttpServletRequest request) {
			final String redirectUri = request
					.getParameter(OAuth2ProtocolConstants.REDIRECT_URI);
			return redirectUri != null ? redirectUri : RequestContext.get()
					.clientApp().getDefaultEndPoint();
		}

		@Override
		public String protocol() {
			return OAuth2ProtocolConstants.OAUTH2;
		}

	}

}
