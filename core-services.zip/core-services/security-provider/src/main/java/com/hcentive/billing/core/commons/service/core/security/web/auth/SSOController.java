package com.hcentive.billing.core.commons.service.core.security.web.auth;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcentive.billing.core.commons.util.Permission;

@Controller
@RequestMapping("/authenticated")
public class SSOController {

	@RequestMapping("/sso/{ssoId}")
	@RequiresPermissions(value = Permission.SSO_MANAGEMENT)
	public void doSSOValidation() {

	}

}
