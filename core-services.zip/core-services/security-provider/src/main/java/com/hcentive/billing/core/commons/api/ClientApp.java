package com.hcentive.billing.core.commons.api;

import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "security_client_app")
public class ClientApp extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Access(AccessType.FIELD)
	@Column(name = "app_key", nullable = false)
	private String appKey;

	@Access(AccessType.FIELD)
	@Column(name = "name", nullable = false)
	private String name;

	@Access(AccessType.FIELD)
	@Column(name = "default_end_point", nullable = false)
	private String defaultEndPoint;

	@Access(AccessType.FIELD)
	@Column(name = "domain", nullable = false)
	private String domain;

	@Access(AccessType.FIELD)
	@Column(name = "default_logout_end_point", nullable = false)
	private String defaultLogoutEndPoint;
	
	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "security_client_app_managed_be_type", joinColumns = @JoinColumn(name = "id"))
	@Column(name = "manage_be_type")
	@Access(AccessType.FIELD)
	private Set<String> managedBusinessEntityTypes;

	protected ClientApp() {
		super();
		// this.tenantId = TenantUtil.getTenantId();
	}
	
	
	public Set<String> getManagedBusinessEntityTypes() {
		return managedBusinessEntityTypes;
	}


	public void setManagedBusinessEntityTypes(
			Set<String> managedBusinessEntityTypes) {
		this.managedBusinessEntityTypes = managedBusinessEntityTypes;
	}



	public String getAppKey() {
		return this.appKey;
	}

	public String getName() {
		return this.name;
	}

	public String getDefaultEndPoint() {
		return this.defaultEndPoint;
	}

	public String getDomain() {
		return this.domain;
	}

	public String getDefaultLogoutEndPoint() {
		return this.defaultLogoutEndPoint;
	}

}
