package com.hcentive.billing.core.commons.api.support;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.beans.SpringBackedBeanRegistry;

@Component
public class IdpResponseInterpreterRegistry extends
		SpringBackedBeanRegistry<IdpResponseInterpreter> {

	private final Map<String, IdpResponseInterpreter> registry = new HashMap<String, IdpResponseInterpreter>();

	@Override
	protected Class<IdpResponseInterpreter> lookupForType() {
		return IdpResponseInterpreter.class;
	}

	@Override
	protected void registerBean(IdpResponseInterpreter idpResponseInterpreter) {
		registry.put(idpResponseInterpreter.identity(), idpResponseInterpreter);
	}

	public IdpResponseInterpreter getIdpResponseInterpreter(
			final String identity) {
		return registry.get(RequestContext.get().identityProvider()
				.getHandledByIntrepreter());
	}

}
