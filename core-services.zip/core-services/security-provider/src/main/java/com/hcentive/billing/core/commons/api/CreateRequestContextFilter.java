package com.hcentive.billing.core.commons.api;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import com.hcentive.billing.core.commons.api.RequestContext.RequestContextInitializer;
import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.service.core.security.repository.EnterpriseRepository;
import com.hcentive.billing.core.commons.service.security.filter.ClientAppIdentifierFilter;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.web.WebUtils;

public class CreateRequestContextFilter extends ClientAppIdentifierFilter {

	private static final Logger logger = LoggerFactory
			.getLogger(CreateRequestContextFilter.class);

	@Autowired
	private ClientAppService clientAppService;
	
	@Autowired
	private WFMCache<String, Set<String>> cache;
	
	@Autowired
	private EnterpriseRepository enterpriseRepository;
	
	@Value(value = "${api.enterprise.location}")
	private int enterpiseLocationInURL;

	
	@Override
	public void doInternalFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		final HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		final HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		final String path = httpServletRequest.getRequestURI();
		if (!ignoreCurrentRequest(request)
				&& path.contains("security") && !path.contains("user/current") && !path.contains("sctx") ) {
			logger.debug("In prehandle");
			String appKey = resolveClientId(request);
			logger.debug("AppKey found : {}", appKey);
			if(StringUtils.isEmpty(appKey)){
				logger.error("AppKey is mandatory");
				request.getRequestDispatcher("/security/error/501").forward(httpServletRequest, httpServletResponse);
				return;
			}
			// parse tenant and appKey from URL
			final RequestContextInitializer contextInitializer = RequestContext
					.initializer();
			final String enterprise = resolveAndValidateEnterprise(request, contextInitializer);
			logger.debug("Enterprise found : {}", enterprise);
			if (enterprise == null) {
				logger.error("Enterprise is mandatory");
				request.getRequestDispatcher("/security/error/501").forward(httpServletRequest, httpServletResponse);
				return;
			}
			final List<ClientAppIdpEnterpriseConfig> clientAppIdpEnterpriseConfigs = clientAppService
					.findClientAppEnterpriseIdpConfigs(enterprise, appKey);

			if (clientAppIdpEnterpriseConfigs == null
					|| clientAppIdpEnterpriseConfigs.isEmpty()) {
				logger.error("No IDP configured for enterprise {} and appKey {}",enterprise,appKey);
				request.getRequestDispatcher("/security/"+enterprise+"/error/501").forward(httpServletRequest, httpServletResponse);
				return;
			}
			logger.debug("Identifying forward path");
			doForwardRequestForProcessing(request, response,
					httpServletRequest, contextInitializer,
					clientAppIdpEnterpriseConfigs,path);
		} else {
			chain.doFilter(request, response);
		}
	}

	/**
	 * @param request
	 * @param response
	 * @param httpServletRequest
	 * @param contextInitializer
	 * @param clientAppIdpEnterpriseConfigs
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void doForwardRequestForProcessing(ServletRequest request,
			ServletResponse response,
			final HttpServletRequest httpServletRequest,
			final RequestContextInitializer contextInitializer,
			List<ClientAppIdpEnterpriseConfig> clientAppIdpEnterpriseConfigs, String requestPath)
			throws ServletException, IOException {
		logger.debug("In forward request");
		final ClientAppIdpEnterpriseConfig configToUse = resolveConfigToUse(
				httpServletRequest, clientAppIdpEnterpriseConfigs);
		httpServletRequest.setAttribute("availableConfigs",
				clientAppIdpEnterpriseConfigs);
		if (null != configToUse) {
			contextInitializer.withConfig(
					configToUse);
			
		} 
		logger.debug("Initiliazing Request Context");
		contextInitializer.initialize();
		
		if (requestPath.contains("oAuth2") && !requestPath.contains("logout") && !requestPath.contains("login") && !requestPath.contains("register")) {
			if (null != configToUse) {
				// forward to show idps.
				logger.debug("Forwarding to Initiate");
				httpServletRequest.getRequestDispatcher(
						AuthWebUtil.createForwardToPath("oAuth2/initiate"))
						.forward(request, response);
			}
			else {
				
				// forward to show idps.
				logger.debug("Forwarding to Choose IDP");
				httpServletRequest
						.getRequestDispatcher(
								AuthWebUtil
										.createForwardToPath("oAuth2/int/chooseIdp"))
						.forward(request, response);
			}
		}else{
			logger.debug("Forwarding Request");
			httpServletRequest
			.getRequestDispatcher(requestPath).forward(request, response);
		}
		
	}

	private ClientAppIdpEnterpriseConfig resolveConfigToUse(
			HttpServletRequest httpServletRequest,
			List<ClientAppIdpEnterpriseConfig> clientAppIdpEnterpriseConfigs) {
		logger.debug("Resolving config to use");
		String idpKey = resolveIdpKey(httpServletRequest);
		
		if (null == idpKey || StringUtils.isEmpty(idpKey)) {
			return clientAppIdpEnterpriseConfigs.get(0);
		}
		
		logger.debug("Idp Key : {}",idpKey);
		for (ClientAppIdpEnterpriseConfig config : clientAppIdpEnterpriseConfigs) {
			if (idpKey.equalsIgnoreCase(config.getIdentityProvider()
					.getIdpKey())) {
				logger.debug("Returning config");
				return config;
			}
		}
		logger.debug("Config not found");
		return null;
	}

	public String resolveAndValidateEnterprise(final ServletRequest request,
			final RequestContextInitializer contextInitializer) {
		logger.debug("Resolving Enterprise");
		String enterpriseName = WebUtils.resolve(request, enterpiseLocationInURL);
		if(null!=enterpriseName && enterpriseName.equalsIgnoreCase(AuthWebUtil.defaultEnterpriseName())){
			logger.debug("Initializing request context with default enterprise");
			contextInitializer.usingDefaultEnterprise();
		}
		logger.debug("Checking against enterprise: {}",enterpriseName);
		if(null!=enterpriseName){
			enterpriseName =  validateEnterprise(enterpriseName);
		}
		return enterpriseName;
	}

	private String validateEnterprise(final String enterpriseName) {
		final ProcessContext pc = ProcessContext.get();
		logger.debug("Process Context found : {}",pc);
		boolean oldValue = pc.shouldIgnoreTenant();
		pc.ignoreTenantDuringProcessing();
		try {
			final Set<String> preConfiguredEnterprises = cache.get(BillingConstant.REGISTERED_ENTERPRISES);
			if(preConfiguredEnterprises != null && !preConfiguredEnterprises.contains(enterpriseName)){
				logger.debug("Enterprise found from url not exists in our pre-configured enterprises");
				final List<EnterpriseImpl> configuredEnterprises = enterpriseRepository.findAll();
				cacheConfiguredEnterprises(configuredEnterprises);
				if(configuredEnterprises.contains(enterpriseName)){
					logger.debug("Enterprise found from new configured enterprises");
					return enterpriseName;
				}
				return null;
			}
		} finally {
			logger.debug("Reverting old value");
			revertOldValue(oldValue,pc);
		}
		logger.debug("Returning from enterprise: {}",enterpriseName);
		return enterpriseName;
	}
	
	private void cacheConfiguredEnterprises(
			List<EnterpriseImpl> configuredEnterprises) {
		final Set<String> enterprises = new HashSet<String>();
		for (EnterpriseImpl enterprise : configuredEnterprises) {
			enterprises.add(enterprise.getName());
		}
		cache.put(BillingConstant.REGISTERED_ENTERPRISES, enterprises,0);
	}
	
	private void revertOldValue(boolean ignoreTenant, ProcessContext pc) {
		if(ignoreTenant){
			pc.ignoreTenantDuringProcessing();
		}else{
			pc.acknowledgeTenantDuringProcessing();
		}
	}

	@Override
	protected String[] getIgnorePathPattern() {
		// TODO Auto-generated method stub
		return null;
	}
}
