package com.hcentive.billing.core.commons.service.core.security.repository;

import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.Role.RoleStatus;


@Transactional
public interface RoleRepository extends JpaRepository<Role, Long> {

	@Override
	Page<Role> findAll(Pageable pageable);

	Role findByIdentity(String identity);

	Role findByCode(String code);
	
	Set<Role> findByUserTypeAndIsDefaultAndStatus(String userType,boolean isDefault,RoleStatus status);

}
