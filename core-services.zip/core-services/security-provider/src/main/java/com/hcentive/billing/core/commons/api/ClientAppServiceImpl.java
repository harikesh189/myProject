package com.hcentive.billing.core.commons.api;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.core.security.repository.ClientAppIdpEnterpriseConfigRepository;

@Component
public class ClientAppServiceImpl implements ClientAppService {

	private static final Logger logger = LoggerFactory
			.getLogger(ClientAppServiceImpl.class);
	@Autowired
	private ClientAppIdpEnterpriseConfigRepository clientAppIdpEnterpriseConfigRepository;

	@Override
	public List<ClientAppIdpEnterpriseConfig> findByClientApp(ClientApp clientApp) {
		logger.debug("Finding clientAppconfig clientApp {}",
				clientApp.getAppKey());
		return clientAppIdpEnterpriseConfigRepository.findByClientApp(clientApp);
	}


	@Override
	public List<ClientAppIdpEnterpriseConfig> findClientAppEnterpriseIdpConfigs(
			String enterprise, String appKey){
		return clientAppIdpEnterpriseConfigRepository.findByEnterpriseNameAndClientAppAppKey(enterprise,appKey);
	}
	
	@Override
	public List<ClientAppIdpEnterpriseConfig> findClientAppEnterpriseIdpConfigsByIdp(String enterprise, String idpKey){
		return clientAppIdpEnterpriseConfigRepository.findByEnterpriseNameAndIdentityProviderIdpKey(enterprise,idpKey);
	}

}
