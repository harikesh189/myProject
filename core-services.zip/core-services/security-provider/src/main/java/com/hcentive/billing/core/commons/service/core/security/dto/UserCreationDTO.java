package com.hcentive.billing.core.commons.service.core.security.dto;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.enumtype.UserType;

public class UserCreationDTO {
	
	private PersonalProfile personalProfile;
	private UserType userType;
	private Set<String> beExternalIds;
	private Set<String> managesBEofTypes;
	private Set<String> roleIdentities;
	private String clientAppId;
	private String identity;
	private String userStatus;
	
	
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public PersonalProfile getPersonalProfile() {
		return personalProfile;
	}
	public void setPersonalProfile(PersonalProfile personalProfile) {
		this.personalProfile = personalProfile;
	}
	public UserType getUserType() {
		return userType;
	}
	public void setUserType(UserType userType) {
		this.userType = userType;
	}
	public Set<String> getBeExternalIds() {
		return beExternalIds;
	}
	public void setBeExternalIds(Set<String> beExternalIds) {
		this.beExternalIds = beExternalIds;
	}
	public Set<String> getManagesBEofTypes() {
		return managesBEofTypes;
	}
	public void setManagesBEofTypes(Set<String> managesBEofTypes) {
		this.managesBEofTypes = managesBEofTypes;
	}
	public Set<String> getRoleIdentities() {
		return roleIdentities;
	}
	public void setRoleIdentities(Set<String> roleIdentities) {
		this.roleIdentities = roleIdentities;
	}
	public String getClientAppId() {
		return clientAppId;
	}
	public void setClientAppId(String clientAppId) {
		this.clientAppId = clientAppId;
	}
	
}
