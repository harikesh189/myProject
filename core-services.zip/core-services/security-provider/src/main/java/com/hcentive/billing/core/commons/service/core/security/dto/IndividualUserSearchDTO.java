package com.hcentive.billing.core.commons.service.core.security.dto;

import java.util.Map;

import com.hcentive.billing.core.commons.dto.PageRequestCriteria;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.vo.SearchCriteriaOnColumns;

public class IndividualUserSearchDTO extends UserSearchDto {

	String subscriberId;
	String groupId;
	DateTime dateOfBirth;
	boolean isActivationCode;

	public String getSubscriberId() {
		return this.subscriberId;
	}

	public void setSubscriberId(final String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getGroupId() {
		return this.groupId;
	}

	public void setGroupId(final String groupId) {
		this.groupId = groupId;
	}

	public DateTime getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(final DateTime dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public boolean isActivationCode() {
		return this.isActivationCode;
	}

	public void setActivationCode(final boolean isActivationCode) {
		this.isActivationCode = isActivationCode;
	}

	@Override
	public SearchCriteria getUserSearchCriteria() {

		if (this.subscriberId != null) {
			final SearchCriteria searchCriteria = new SearchCriteria();
			final Map<String, SearchCriteriaOnColumns> criteria = searchCriteria.getCriteria();
			final SearchCriteriaOnColumns value = new SearchCriteriaOnColumns();
			value.setColumnValue("'" + this.subscriberId + "'");
			value.setOperator("=");
			criteria.put("externalId", value);
			final PageRequestCriteria pg = searchCriteria.getPageRequestCriteria();
			pg.setPageIndex(0);
			pg.setSize(1);
			searchCriteria.setCriteria(criteria);
			searchCriteria.setPageRequestCriteria(pg);
			return searchCriteria;
		} else {
			return null;
		}

	}

	@Override
	public boolean isActivateByActivationCode() {
		return this.isActivationCode;
	}

}
