package com.hcentive.billing.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.support.IdpUserToken;
import com.hcentive.billing.core.commons.domain.Broker;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.Role.RoleStatus;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.shiro.AbstractAuthToken;
import com.hcentive.billing.core.commons.security.shiro.AbstractBillingDataRealm;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;

public abstract class AbstractSecurityRealm<T extends AuthenticationToken> extends AbstractBillingDataRealm<T> {

	public AbstractSecurityRealm(Class<T> handlesTokenType) {
		super(handlesTokenType);
	}

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AbstractSecurityRealm.class);

	public final boolean isValidUserType(User user) {
		if (!user.isActive()) {
			LOGGER.error("User is Inactive ");
			return false;
		}
		boolean isAllRolesInActive = true;
		LOGGER.debug("Fetching all the roles of the user {}",user.getExternalId());
		final Set<Role> rolesSet=user.getRoles();
		LOGGER.debug("Total roles of the given user are {}", rolesSet == null ? null : rolesSet.size());
		if(null == rolesSet || rolesSet.size() == 0){
			LOGGER.debug("No roles assigned to the current user");
			return false;
		}else{
			for (Role role : rolesSet) {
				RoleStatus roleStatus=role.getStatus();
				if(roleStatus.equals(RoleStatus.ACTIVE)){
					LOGGER.debug("One of the roles assigned to the current user is ACTIVE");
					isAllRolesInActive = false;
					break;
				}
			}
			if(isAllRolesInActive){
				LOGGER.debug("All the roles of the current user are inactive :: returning false");
				return false;
			}
		}
		
		
		if( user instanceof Manager){
			LOGGER.debug("User is an instance of Manager");
			Manager manager = (Manager) user;
			Collection<Reference> references = manager.getManagedEntities();
			for (Reference reference : references) {
				LOGGER.debug("Matching References");
				if(BusinessEntity.class.isAssignableFrom(reference.getType())){
					LOGGER.debug("Getting Managed BE");
					BusinessEntity be = (BusinessEntity) reference.toObject();
					if(null==be){
						LOGGER.error("BE is NULL for REFERENCE {}", reference.getReferenceId());
						return true;
					}
					return !be.isExpired();
				}
			}
		}
		return true;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public  AuthenticationInfo loadAuthenticationInfo(
			final AbstractAuthToken token, UserCredentials credentials , User user) {
		
		if (user != null && isValidUserType(user)) {
			final String realmName = this.getClass().getName();
			LOGGER.debug("Creating SimplePrincipalCollection");

			final RequestContext requestContext = RequestContext.get();
			String idpKey = null;
			if( null != requestContext){
				idpKey = requestContext.identityProvider() != null ? requestContext.identityProvider().getIdpKey() : null;
			}
			AccessToken accessToken = null;
			if(token instanceof IdpUserToken ){
				accessToken = Utils.createAccessToken(
						RandomGenerator.randomString(), user, ((IdpUserToken)token).getParams() , credentials , idpKey );
			}else{
				accessToken = Utils.createAccessToken(
						RandomGenerator.randomString(), user, credentials, idpKey);
			}
			
			token.associateAccessToken(accessToken);
			final SimplePrincipalCollection principalCollection = new SimplePrincipalCollection(
					token.getPrincipal(), realmName);
			LOGGER.debug("Created SimplePrincipalCollection");
			Collection principals = new ArrayList();
			principals.add(accessToken);
			principals.add(user);
			principalCollection.addAll(principals, realmName);
			LOGGER.debug("Returning from Authentication Info");
			return new SimpleAuthenticationInfo(principalCollection,
					credentials.getAuthKey());
		}
		LOGGER.error("Either user is inactive or BE user is associated with got terminated");
		throw new AuthenticationException("Either user is inactive or BE user is associated with got terminated");
	}
	
	/**
	 * @param userTenantInfo
	 * @param user
	 * @return
	 */
	protected void initiliazeProcessContext(UserTenantInfo userTenantInfo) {
		invoilateProcessContext();
		if(userTenantInfo != null ){
				ProcessContext.initializer().initialize().setTenantId(userTenantInfo.getTenantId());
		}
	}
	
	protected void invoilateProcessContext(){
		ProcessContext.clear();
	}
	
	protected void revertProcessContext(final ProcessContext pc){
		invoilateProcessContext();
		ProcessContextUtil.buildProcessContext(pc.getUserId(), pc.getBeId(), pc.getTenantId(), pc.getBeType(),pc.getUserName());
		if(pc.shouldIgnoreTenant())
			ProcessContext.get().ignoreTenantDuringProcessing();
	}
	
	protected void addTenant(EntityManager target) {
		final String tenantId = TenantUtil.getTenantId();
		target.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, tenantId);
	}

}
