package com.hcentive.billing.core.commons.api.support;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.hcentive.billing.core.commons.api.OAuth2ProtocolConstants;
import com.hcentive.billing.core.commons.beans.SpringBackedBeanRegistry;

public class HttpRedirectURIResolverSupport extends
		SpringBackedBeanRegistry<HttpRedirectURIResolver> {

	public static final HttpRedirectURIResolverSupport INSTANCE = new HttpRedirectURIResolverSupport();

	private final Map<String, HttpRedirectURIResolver> registeredResolvers = new HashMap<String, HttpRedirectURIResolver>();

	private HttpRedirectURIResolverSupport() {

	}

	@Override
	protected Class<HttpRedirectURIResolver> lookupForType() {
		return HttpRedirectURIResolver.class;
	}

	@Override
	protected void registerBean(HttpRedirectURIResolver bean) {
		registeredResolvers.put(bean.protocol(), bean);
	}

	public HttpRedirectURIResolver getResolver(HttpServletRequest request) {
		String protocol = identifyProtocol();
		final HttpRedirectURIResolver resolver = registeredResolvers
				.get(protocol);
		return resolver;
	}

	public String getRedirectURI(HttpServletRequest request) {
		final HttpRedirectURIResolver resolver = getResolver(request);
		return resolver != null ? resolver.resolve(request) : null;
	}

	private String identifyProtocol() {
		final String clientProtocol = OAuth2ProtocolConstants.OAUTH2;// RequestContext.get().clientApp().getAuthProtocol();
		return clientProtocol;
	}

}
