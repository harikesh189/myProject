package com.hcentive.billing.core.commons.service.core.security.service;

import org.apache.shiro.authc.AuthenticationToken;

import com.hcentive.billing.core.commons.api.IdpUserIdentity;
import com.hcentive.billing.core.commons.api.support.IdpUserToken;
import com.hcentive.billing.core.commons.security.shiro.ShiroAuthenticationTokenBuilder;

public class IdpTokenBuilder implements
		ShiroAuthenticationTokenBuilder<IdpUserIdentity> {

	@Override
	public AuthenticationToken build(IdpUserIdentity credential) {
		IdpUserToken idpUserToken = new IdpUserToken(credential.userIdentity(),
				credential.idp(), credential.sessionParams());
		return idpUserToken;
	}

	@Override
	public Class<IdpUserIdentity> buildsFromType() {
		return IdpUserIdentity.class;
	}

}