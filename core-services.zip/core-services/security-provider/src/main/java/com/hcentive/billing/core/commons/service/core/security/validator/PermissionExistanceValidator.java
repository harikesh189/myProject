package com.hcentive.billing.core.commons.service.core.security.validator;

import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.service.core.security.dto.RoleDTO;
import com.hcentive.billing.core.commons.service.core.security.repository.PermissionRepository;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;
import com.hcentive.billing.core.commons.validation.error.ValidationErrorSet;

public class PermissionExistanceValidator implements
		Validator<RoleDTO, ValidationErrorSet<RoleDTO>> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DuplicateRoleValidator.class);

	@Autowired
	private PermissionRepository permissionRepository;

	@Override
	public ValidationErrorSet<RoleDTO> validate(RoleDTO roleDto) {

		ValidationErrorSet<RoleDTO> validationError = null;

		long count = permissionRepository.countByIdentityIn(roleDto
				.getPermissionIds());

		if (count != roleDto.getPermissionIds().size()) {

			validationError = new ValidationErrorSet<RoleDTO>();
			Set<String> permissionIds = roleDto.getPermissionIds();
			for (Iterator iterator = permissionIds.iterator(); iterator
					.hasNext();) {
				String identity = (String) iterator.next();

				Permission permission = permissionRepository
						.findByIdentity(identity);
				if (permission == null) {
					SingleValidationError<RoleDTO> validationErr = new SingleValidationError<RoleDTO>(
							"PermissionNotExists", "Permission " + identity
									+ " not Exists", roleDto);

					LOGGER.error("Permission Not Exists with id:" + identity);

					validationError.getErrors().add(validationErr);
				}
			}
		}

		return validationError;
	}

	@Override
	public String identity() {
		// TODO Auto-generated method stub
		return null;
	}

}
