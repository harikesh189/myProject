package com.hcentive.billing.core.commons.service.core.security.web.idpsupport;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hcentive.billing.core.commons.api.ClientUserIdentity;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.web.WebUtils;

@Controller
@RequestMapping("/security/{tenant}/secretKeyBasedAuth")
public class SecretKeyBasedAuthenticationController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SecretKeyBasedAuthenticationController.class);

	@Autowired
	private AuthManager authManager;

	@ResponseBody
	@RequestMapping("/authenticate")
	public AuthInfo doAuthentication(final HttpServletRequest request) {
		LOGGER.debug("Authenticating on the basis of secret key");
		final String secretKey = WebUtils.getAuthorizationHeader(request);
		final ClientUserIdentity clientCredential = new ClientUserIdentity(
				secretKey);
		LOGGER.debug("Trying to login using Client Credentials");
		final AccessToken accessToken = authManager.doLogin(clientCredential);
		LOGGER.debug("Client User Logged in Seccussfully");
		return new AuthInfo(accessToken.getIdentity(),
				accessToken.getSecurityKey());
	}

}
