package com.hcentive.billing.core.commons.api;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.service.core.security.repository.ClientAppRepository;
import com.hcentive.billing.core.commons.vo.ProcessContext;

public class ClientAppLoader {
	
	@Autowired
	private ClientAppRepository clientAppRepository;
	
	@Autowired
	private WFMCache<String, Set<String>> cache;
	
	@PostConstruct
	public void loadClientApps(){
		final ClientAppConfigPreLoader configLoader = new ClientAppConfigPreLoader();
		final Thread th = new Thread(configLoader);
		th.start();
	}

	private class ClientAppConfigPreLoader implements Runnable {
		
		public ClientAppConfigPreLoader() {
			super();
		}

		@Override
		public void run() {
			ProcessContext.initializer().initialize().ignoreTenantDuringProcessing();
			final List<ClientApp> clientApps = clientAppRepository.findAll();
			final Set<String> clientAppKeys = new HashSet<String>();
			for (ClientApp clientApp : clientApps) {
				clientAppKeys.add(clientApp.getAppKey());
			}
			//Setting expiry time to 0 so that it never expires from cache
			cache.put(BillingConstant.REGISTERED_CLIENT_APPS, clientAppKeys,0);
			ProcessContext.clear();
		}

	}
}
