package com.hcentive.billing.core.commons.api;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.domain.RoleInfo;

@Entity
@Table(name="security_trusted_entity")
public class TrustedEntity extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Access(AccessType.FIELD)
	@Column(name="name",nullable=false)
	private String name;
	
	@Access(AccessType.FIELD)
	@ManyToMany(fetch = FetchType.EAGER)
	@PrimaryKeyJoinColumn
	@JoinTable(name = "security_trusted_entities_role", joinColumns = { @JoinColumn(name = "trusted_entity_id") }, inverseJoinColumns = { @JoinColumn(name = "roles_id") })
	protected Set<RoleInfo> roles = new HashSet<RoleInfo>(0);
	
	public Collection<Permission> permissions() {
		final Collection<Permission> permissions = new HashSet<Permission>();
		for (final RoleInfo r : this.roles) {
			permissions.addAll(r.getPermissions());
		}
		return permissions;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<RoleInfo> getRoles() {
		return roles;
	}

	public void setRoles(Set<RoleInfo> roles) {
		this.roles = roles;
	}
	
	

}
