package com.hcentive.billing.core.commons.service.core.security.web.idpsupport;

import java.io.Serializable;

public class AuthInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String tokenId;
	private String securityKey;

	public AuthInfo(final String tokenId, final String securityKey) {
		this.tokenId = tokenId;
		this.securityKey = securityKey;
	}

	public AuthInfo() {
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getSecurityKey() {
		return securityKey;
	}

	public void setSecurityKey(String securityKey) {
		this.securityKey = securityKey;
	}

}
