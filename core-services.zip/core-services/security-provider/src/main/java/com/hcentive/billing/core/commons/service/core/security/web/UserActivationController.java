package com.hcentive.billing.core.commons.service.core.security.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserSearchDto;
import com.hcentive.billing.core.commons.service.core.security.manager.UserManager;

@Controller
@RequestMapping("/user-registration")
public class UserActivationController {

	@Autowired
	private Environment env;

	@Autowired
	private UserManager userManager;
	
	@Value(value = "${login.url:default}")
	private String loginUrl;

	@RequestMapping(value = "/associate/{userType}", method = RequestMethod.GET)
	public ModelAndView associate(@PathVariable String userType) {
		ModelAndView modelAndView = new ModelAndView("associate");
		UserSearchDto searchDTO = new UserSearchDto();
		searchDTO.setUserType(userType);

		modelAndView.addObject("userType", userType);
		modelAndView.addObject("searchDTO", searchDTO);
		modelAndView.addObject("userDto", new UserDTO());
		modelAndView.addObject("staticUrl",
				env.getProperty("security.static.resource.url"));
		return modelAndView;
	}

	@RequestMapping(value = "/associate", method = RequestMethod.GET)
	public ModelAndView addAndAssociate() {
		ModelAndView modelandView = new ModelAndView("index");
		modelandView.addObject("login.footerURL",
				env.getProperty("copyrightURL"));
		modelandView.addObject("staticUrl",
				env.getProperty("security.static.resource.url"));
		modelandView.addObject("clientApps", "{}");
		return modelandView;
	}

	@RequestMapping(value = "/users/activation", produces = "application/json", consumes = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	Object fetchBEByCriteria(@RequestBody UserSearchDto searchDTO) {
		User user = userManager.getUserForActivation(searchDTO);
		UserDTO userDTO = null;
		if (null != user) {
			userDTO = new UserDTO();
			userDTO.setIdentity(user.getIdentity());
			userDTO.setPersonalProfile(user.getProfile());
		}
		return userDTO;
	}


	@RequestMapping(value = "/users/verify/security-info", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	Object verifyUserSecurityInfo(@RequestBody UserDTO userDTO) {
		return userManager.verifyUserSecurityInfo(userDTO);
	}
	
}
	