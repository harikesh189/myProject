package com.hcentive.billing.core.commons.api;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.MapKeyJoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.IdAware;
import com.hcentive.billing.core.commons.domain.Persistable;

@Entity
@Table(name = "security_idp_saml_configuration")
public class IdpSamlConfiguration extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idp_id")
	@Access(AccessType.FIELD)
	private IdentityProvider identityProvider;

	@Column(name = "idp_public_cert_path")
	@Access(AccessType.FIELD)
	private String idpPublicCertPath;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinTable(name="security_saml_config_client_info",joinColumns=@JoinColumn(name="idp_saml_config_id"),
    inverseJoinColumns=@JoinColumn(name="saml_config_params_id"))
	@MapKeyJoinColumn(name = "saml_config_client_identifier_id")
	@Access(AccessType.FIELD)
	private Map<SamlConfigIdentifier, SamlConfigParams> samlConfigClientInfo = new HashMap<SamlConfigIdentifier, SamlConfigParams>();
	
	@Entity
	@Table(name = "security_saml_config_params")
	private static class SamlConfigParams implements IdAware<Long>, Serializable, Persistable{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "ID", unique = true, nullable = false)
		@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_seq")
		@SequenceGenerator(name = "id_seq", sequenceName = "id_seq", allocationSize = 500)
		private Long id;
		
		@Column(name = "sp_public_cert_path")
		@Access(AccessType.FIELD)
		private String spPublicCertPath;
		
		@Column(name = "assertion_consumer_url")
		@Access(AccessType.FIELD)
		private String assertionConsumerUrl;
		
		@Column(name = "key_store_path")
		@Access(AccessType.FIELD)
		private String keyStorePath;

		@Column(name = "key_store_password")
		@Access(AccessType.FIELD)
		private String keyStorePassword;

		@Column(name = "private_key_alias")
		@Access(AccessType.FIELD)
		private String privateKeyAlias;
		
		@Override
		public Long getId() {
			return this.id;
		}
		
		public String getAssertionConsumerUrl() {
			return assertionConsumerUrl;
		}

		public String getKeyStorePath() {
			return keyStorePath;
		}

		public String getKeyStorePassword() {
			return keyStorePassword;
		}

		public String getPrivateKeyAlias() {
			return privateKeyAlias;
		}

		public String getSpPublicCertPath() {
			return spPublicCertPath;
		}
		
	}
	
	@Entity
	@Table(name = "security_saml_config_identifier")
	private static class SamlConfigIdentifier implements IdAware<Long>, Serializable, Persistable{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "ID", unique = true, nullable = false)
		@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_seq")
		@SequenceGenerator(name = "id_seq", sequenceName = "id_seq", allocationSize = 500)
		private Long id;
		
		@Column(name = "enterprise_name")
		@Access(AccessType.FIELD)
		private String enterpriseName;
		
		@Column(name = "client_id")
		@Access(AccessType.FIELD)
		private String clientId;
		
		public SamlConfigIdentifier() {
			// TODO Auto-generated constructor stub
		}
		
		public SamlConfigIdentifier(final String enterpriseName, final String clientId){
			this.enterpriseName = enterpriseName;
			this.clientId = clientId;
		}
		
		@Override
		public Long getId() {
			return this.id;
		}

		@Override
		public boolean equals(Object o){
			if(this == o)
				return true;
			
			if(o == null){
				return false;
			}
			
			if (this.getClass() != o.getClass()) {
				return false;
			}
			SamlConfigIdentifier samlConfigClientInfo = (SamlConfigIdentifier)o;
			if(this.clientId != null && this.enterpriseName != null && samlConfigClientInfo.clientId != null && samlConfigClientInfo.enterpriseName != null){
				return this.clientId.equals(samlConfigClientInfo.clientId) && this.enterpriseName.equals(samlConfigClientInfo.enterpriseName);
			}
			return false;
		}
		
		@Override
		public int hashCode(){
			final int prime = 31;
			int hashCode = prime * 1;
			if(this.enterpriseName != null)
				hashCode = hashCode * this.enterpriseName.hashCode();
			
			if(this.clientId != null)
				hashCode = hashCode * this.clientId.hashCode();
			
			return hashCode;
			
		}
		
	}

	public SamlConfigIdentifier samlConfigIdentifier(final String enterpriseName, final String clientId){
		return new SamlConfigIdentifier(enterpriseName, clientId);
	}
	
	private IdpSamlConfiguration() {
	}

	public Map<SamlConfigIdentifier, SamlConfigParams> getSamlConfigClientInfo() {
		return samlConfigClientInfo;
	}

	public IdentityProvider getIdentityProvider() {
		return identityProvider;
	}

	public String getIdpPublicCertPath() {
		return idpPublicCertPath;
	}

	public String getSpPublicCertPath() {
		RequestContext requestContext = RequestContext.get();
		return this.samlConfigClientInfo != null ? this.samlConfigClientInfo
				.get(samlConfigIdentifier(
						requestContext.enterprise().getName(), requestContext
								.clientApp().getAppKey()))
				.getSpPublicCertPath() : null;
	}

	public String getKeyStorePassword() {
		RequestContext requestContext = RequestContext.get();
		return this.samlConfigClientInfo != null ? this.samlConfigClientInfo
				.get(samlConfigIdentifier(
						requestContext.enterprise().getName(), requestContext
								.clientApp().getAppKey()))
				.getKeyStorePassword() : null;
	}

	public String getPrivateKeyAlias() {
		RequestContext requestContext = RequestContext.get();
		return this.samlConfigClientInfo != null ? this.samlConfigClientInfo
				.get(samlConfigIdentifier(
						requestContext.enterprise().getName(), requestContext
								.clientApp().getAppKey()))
				.getPrivateKeyAlias() : null;
	}

	public String getKeyStorePath() {
		RequestContext requestContext = RequestContext.get();
		return this.samlConfigClientInfo != null ? this.samlConfigClientInfo
				.get(samlConfigIdentifier(
						requestContext.enterprise().getName(), requestContext
								.clientApp().getAppKey()))
				.getKeyStorePath() : null;
	}
	
	
	public String getAssertionConsumerUrl(){
		RequestContext requestContext = RequestContext.get();
		return this.samlConfigClientInfo != null ? this.samlConfigClientInfo
				.get(samlConfigIdentifier(
						requestContext.enterprise().getName(), requestContext
								.clientApp().getAppKey()))
				.getAssertionConsumerUrl() : null;
	}

}
