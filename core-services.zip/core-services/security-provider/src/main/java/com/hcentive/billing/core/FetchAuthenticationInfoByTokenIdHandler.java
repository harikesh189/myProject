package com.hcentive.billing.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.security.AuthAccessToken;
import com.hcentive.billing.core.commons.service.comm.RequestHandler;
import com.hcentive.billing.core.commons.service.comm.RequestProcessingException;
import com.hcentive.billing.core.commons.service.core.security.service.AccessTokenService;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.service.core.security.service.UserService;

public class FetchAuthenticationInfoByTokenIdHandler implements RequestHandler {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(FetchAuthenticationInfoByTokenIdHandler.class);

	@Autowired
	private AccessTokenService accessTokenService;

	@Autowired
	private AuthManager authManager;

	@Autowired
	private UserService userService;

	@Override
	public Object handle(Object... arguments) throws RequestProcessingException {
		String tokenIdentifier= arguments[0].toString();
		AuthAccessToken authAccessToken = (AuthAccessToken) arguments[1];
		LOGGER.debug("Fetching Access Token for token ID : {}", arguments[0]);
		return authManager.doLoginByPreConfiguredToken(tokenIdentifier ,authAccessToken );
	}

}
