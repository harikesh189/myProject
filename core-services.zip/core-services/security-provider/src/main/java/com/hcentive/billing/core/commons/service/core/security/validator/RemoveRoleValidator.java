package com.hcentive.billing.core.commons.service.core.security.validator;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.service.core.security.dto.RoleDTO;
import com.hcentive.billing.core.commons.service.core.security.service.RoleService;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;

public class RemoveRoleValidator implements
		Validator<RoleDTO, SingleValidationError<RoleDTO>> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(RemoveRoleValidator.class);

	@Autowired
	private RoleService roleService;

	@Override
	public SingleValidationError<RoleDTO> validate(RoleDTO roleDTO) {

		SingleValidationError<RoleDTO> validationError = null;

		Set<Role> roles = roleService.getRolesByIdentities(roleDTO
				.getIdentity());

		if (roles != null && !roles.isEmpty()) {
			LOGGER.debug("Role is duplicate");
			validationError = new SingleValidationError<RoleDTO>();
			validationError.setErrorCode("Role-Duplicate");

		}

		return validationError;
	}

	@Override
	public String identity() {
		// TODO Auto-generated method stub
		return null;
	}

}
