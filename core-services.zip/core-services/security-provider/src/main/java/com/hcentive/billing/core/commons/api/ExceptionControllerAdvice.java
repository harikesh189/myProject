package com.hcentive.billing.core.commons.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.opensaml.common.SAMLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.exception.AuthenticationFailed;
import com.hcentive.billing.core.commons.security.exception.SessionTimedOut;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.service.security.filter.InvalidAppException;
import com.hcentive.billing.core.commons.util.ClientAppToCookieNameMapping;
import com.hcentive.billing.core.commons.web.WebUtils;

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ExceptionControllerAdvice {

	private static final Logger logger = LoggerFactory.getLogger(ExceptionControllerAdvice.class);

	@Autowired
	private ClientAppService clientAppService;

	@Autowired
	private AuthManager authManager;

	@Autowired
	private Environment env;

	final private ObjectMapper mapper = new ObjectMapper();

	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;

	@ExceptionHandler({AuthenticationFailed.class,SAMLException.class})
	public void authenticationFailed(final AuthenticationFailed e, final HttpServletResponse response, final HttpServletRequest request) throws IOException {
		final RequestContext requestContext = RequestContext.get();
		final String appKey = requestContext.clientApp().getAppKey();
		final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(securityUIAppKey);
		final AccessToken accessToken = authManager.doLoginForLoginTrustedEntity(AnonymousUserIdentity.LOGIN_USER_IDENTITY).encryptedAccessTokenCopy();
		final Cookie cookie = new Cookie(BillingConstant.COOKIE_SID + cookieIdentifier, accessToken.getIdentity());
		cookie.setHttpOnly(true);
		cookie.setSecure(true);
		cookie.setPath("/");
		cookie.setDomain("." + request.getServerName());
		cookie.setMaxAge(5);
		response.addCookie(cookie);

		final StringBuilder redirectUrlBuilder = new StringBuilder(WebUtils.getBaseUrl(request));

		redirectUrlBuilder.append("/").append(requestContext.enterprise().getName()).append("/").append(securityUIAppKey).append("/").append("?client_id=")
				.append(appKey).append("&response_type=token").append("/#/error/").append(AuthenticationFailed.ERROR_CODE);
		response.sendRedirect(redirectUrlBuilder.toString());
	}

	@ExceptionHandler(Throwable.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Map<String, String> handleGenericException(final Exception e,final HttpServletResponse response, final HttpServletRequest request) throws IOException {
		logger.error("Handling Exception", e);
		//response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		logger.debug("Returning From Exception");
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", "Error");
		return hashMap;
	}

	@ExceptionHandler(InvalidAppException.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Map<String, String> handleInvalidAppException(final InvalidAppException e) {
		logger.debug("Handling InvalidAppException");
		logger.debug("Returning From Exception");
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", "Error");
		return hashMap;

	}

	@ExceptionHandler(SecurityException.class)
	@ResponseStatus(value=HttpStatus.UNAUTHORIZED)
	@ResponseBody
	public Map<String, String> handleSecurityException(final SecurityException e, final HttpServletResponse response) {
		logger.debug("Returning From Exception");
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", "Error");
		return hashMap;
	}

	

	@ExceptionHandler(UserAlreadyLoggedInException.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Map<String, String> handleUserAlreadyLoggedInException(final UserAlreadyLoggedInException e) {
		logger.debug("Handling UserAlreadyLoggedInException");
		logger.debug("Returning From Exception");
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", "Error");
		return hashMap;
	}
	
	@ExceptionHandler(InvalidUserException.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Map<String, String> handleInvalidUserException(final InvalidUserException e) {
		logger.debug("Handling UserAlreadyLoggedInException");
		logger.debug("Returning From Exception");
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("Error", "Invalid Username");
		return hashMap;
	}

	/**
	 * @param request
	 * @return
	 */
	protected List<ClientAppIdpEnterpriseConfig> otherConfigs(final HttpServletRequest request) {
		final List<ClientAppIdpEnterpriseConfig> allConfigs = (List<ClientAppIdpEnterpriseConfig>) request.getAttribute("availableConfigs");
		final String selfName = "UserCredentialBased";
		ClientAppIdpEnterpriseConfig configToRemove = null;
		for (final ClientAppIdpEnterpriseConfig cc : allConfigs) {
			if (selfName.equals(cc.getIdentityProvider().getHandledByController())) {
				configToRemove = cc;
			}
		}
		allConfigs.remove(configToRemove);
		return allConfigs;
	}

}
