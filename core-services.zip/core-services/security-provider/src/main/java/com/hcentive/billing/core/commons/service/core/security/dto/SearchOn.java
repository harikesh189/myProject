package com.hcentive.billing.core.commons.service.core.security.dto;

public enum SearchOn {
	ActivationCode, BusinessEntity

}
