package com.hcentive.billing.core.commons.api;

import org.apache.shiro.authc.AuthenticationToken;

import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.shiro.AnonymousAuthToken;
import com.hcentive.billing.core.commons.security.shiro.ShiroAuthenticationTokenBuilder;

public class AnonymousUserTokenBuilder implements
		ShiroAuthenticationTokenBuilder<AnonymousUserIdentity> {

	@Override
	public AuthenticationToken build(AnonymousUserIdentity credential) {
		final AnonymousAuthToken anonymousAuthToken = new AnonymousAuthToken(credential.userIdentity(),credential.roleName());
		return anonymousAuthToken;
	}

	@Override
	public Class<AnonymousUserIdentity> buildsFromType() {
		return AnonymousUserIdentity.class;
	}

}
