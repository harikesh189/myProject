package com.hcentive.billing.core.commons.api;

import static com.hcentive.billing.core.commons.concurrent.Executors.newSingleThreadExecutor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.hcentive.billing.commons.mongo.CustomMongoTemplate;
import com.hcentive.billing.core.commons.api.domain.SecurityConfigurations;
import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.security.SecurityConfigurationManager;
import com.hcentive.billing.core.commons.service.comm.support.ServiceRequestHandler;
import com.hcentive.billing.core.commons.service.core.security.repository.IdentityProviderRepository;
import com.hcentive.billing.core.commons.util.ServiceComm;
import com.hcentive.billing.core.commons.vo.ProcessContext;

@SuppressWarnings("all")
public class SecurityConfigurationsLoader<O> implements SecurityConfigurationManager<String,O> {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SecurityConfigurationsLoader.class);

	private static final String SECURITY_CONFIGURATION_PRE_LOADER_THREAD_POOL = "SecurityConfigurationPreLoaderPool";
	
	private ExecutorService executor = newSingleThreadExecutor(SECURITY_CONFIGURATION_PRE_LOADER_THREAD_POOL);

	@Autowired
	CustomMongoTemplate customMongoTemplate;

	@Autowired
	private WFMCache cache;
	
	@Autowired
	private IdentityProviderRepository identityProviderRepository;

	private static final Logger logger = LoggerFactory
			.getLogger(SecurityConfigurationsLoader.class);

	@PostConstruct
	public void loadSecurityConfigurations() {
		logger.debug("Now Start loading security configurations");
		SecurityConfigurationPreLoader securityConfigurationPreLoader = new SecurityConfigurationPreLoader();
		executor.submit(securityConfigurationPreLoader);
		logger.debug("Thread started to load security configurations");
	}
	
	@ServiceRequestHandler(serviceName=ServiceComm.LOAD_SECURITY_CONFIGURATION_BY_KEY)
	public O getSecurityConfiguration(String key) {
		logger.debug("key formed is {}", key);
		ProcessContext pc = ProcessContext.get();
		final boolean currentStatus = pc.shouldIgnoreTenant();
		pc.ignoreTenantDuringProcessing();
		O value = (O) cache.get(key);
		if(null != value){
			logger.debug("Returning value from cache: {}",value);
			revertOldValue(currentStatus,pc);
			return value;
		}
		
		logger.debug("Fetching security configuration with key : {}", key);
		Query query = new Query();
		query.addCriteria(Criteria.where("key").is(key));

		Object configObj = customMongoTemplate.findOne(query,
				SecurityConfigurations.class);
		
		if (null == configObj) {
			return null;
		}
		SecurityConfigurations<O> config = (SecurityConfigurations<O>) configObj;
		cache.put(key, config.getData());
		revertOldValue(currentStatus,pc);
		return config.getData();
	}
	
	private void revertOldValue(boolean ignoreTenant, ProcessContext pc) {
		if(ignoreTenant){
			pc.ignoreTenantDuringProcessing();
		}else{
			pc.acknowledgeTenantDuringProcessing();
		}
	}
	
	private class SecurityConfigurationPreLoader implements Runnable {

		@Override
		public void run() {
			LOGGER.debug("Loading all confugurations from mongo.");
			List<SecurityConfigurations> configurations = null;
			try {
				configurations = customMongoTemplate
						.findAll(SecurityConfigurations.class);
			} catch (Throwable e) {
				logger.error(
						"Error while loading security configuration from mongo",
						e);
				throw new RuntimeException(e);
			}
			LOGGER.debug("Loaded all confugurations from mongo {}",configurations);
			if (null != configurations) {
				cacheConfigurations(configurations);
			}
		}
		
		private void cacheConfigurations(final List<SecurityConfigurations> configurations) 
		{
			ProcessContext.initializer().initialize().ignoreTenantDuringProcessing();
			final Collection<String> whiteLabelDomains = new ArrayList<String>();
			// cache
			LOGGER.debug("Updating white label domains in cache.");
			for (SecurityConfigurations securityConfiguration : configurations) 
			{
				if(null != securityConfiguration.getKey()){
					if (securityConfiguration.getKey().equals(BillingConstant.API_DOMAINS))
					{
						Collection<String> otherReferers = (Collection<String>) securityConfiguration.getData();
						whiteLabelDomains.addAll(otherReferers);
					} 
					else if(securityConfiguration.getKey().startsWith(BillingConstant.DNS_CACHING))
					{
						cache.put(securityConfiguration.getKey(),securityConfiguration.getData());
						whiteLabelDomains.add((String) securityConfiguration.getData());
					}
					else 
					{
						cache.put(securityConfiguration.getKey(),securityConfiguration.getData());
					}
				}
			}
			
			addIDPsToWhiteLabelDomains(whiteLabelDomains);
			
			cache.put(BillingConstant.WHITE_LABEL_DOMAINS,whiteLabelDomains,0);
			ProcessContext.clear();
			LOGGER.debug("Security Configurations updated.");
		}

		private void addIDPsToWhiteLabelDomains(final Collection<String> whiteLabelDomains) 
		{
			//adding IDPs
			LOGGER.debug("Loading idp");
			final List<IdentityProvider> identityProviders = identityProviderRepository.findAll();
			for (IdentityProvider identityProvider : identityProviders) {
				whiteLabelDomains.add(identityProvider.getDomain());
			}
		}

	}

}
