package com.hcentive.billing.core.commons.service.core.security.service;

import org.apache.shiro.authc.AuthenticationInfo;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.AuthAccessToken;
import com.hcentive.billing.core.commons.security.Credential;

public interface AuthManager {

	AccessToken doLogin(Credential credential);

	AccessToken getAuthInfo(String tokenIdentifier);

	void logout();

	User fetchUser();

	AuthenticationInfo doLoginByPreConfiguredToken(String string, AuthAccessToken authAccessToken);
	
	public AccessToken doLoginForLoginTrustedEntity(final AnonymousUserIdentity anonymousUserIdentity);

	AccessToken doRemoteLoginForTrustedEntities(
			AnonymousUserIdentity anonymousUserIdentity);
}
