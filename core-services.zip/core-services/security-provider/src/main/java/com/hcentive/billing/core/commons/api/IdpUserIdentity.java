package com.hcentive.billing.core.commons.api;

import java.util.Collections;
import java.util.Map;

import com.hcentive.billing.core.commons.security.Credential;

public class IdpUserIdentity implements Credential {

	private final String userIdentifier;
	private final IdentityProvider idp;
	private final Map<String, String> sessionParams;

	public IdpUserIdentity(final String userIdentifier, IdentityProvider idp,
			final Map<String, String> sessionParams) {
		this.userIdentifier = userIdentifier;
		this.idp = idp;
		this.sessionParams = sessionParams;
	}

	@Override
	public String userIdentity() {
		return userIdentifier;
	}

	public IdentityProvider idp() {
		return this.idp;
	}

	@Override
	public Map<String, String> sessionParams() {
		return Collections.unmodifiableMap(sessionParams);
	}

	public void add(String param, String value) {
		this.sessionParams.put(param, value);
	}
	
	
}
