package com.hcentive.billing.core.commons.api.support;

import java.util.HashMap;
import java.util.Map;

import com.hcentive.billing.core.commons.api.IdentityProvider;
import com.hcentive.billing.core.commons.api.SAMLConstants;
import com.hcentive.billing.core.commons.security.shiro.AbstractAuthToken;

public class IdpUserToken extends AbstractAuthToken {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final String userIdentity;
	private final IdentityProvider identityProvider;
	private String beId;
	private final Map<String, String> params = new HashMap<String, String>();
	private String orgId;
	private String brokerId;

	@Override
	public Object getPrincipal() {
		return userIdentity;
	}

	@Override
	public Object getCredentials() {
		return identityProvider;
	}

	public IdpUserToken(final String userIdentity,
			final IdentityProvider identityProvider,
			final Map<String, String> params) {
		super();
		this.userIdentity = userIdentity;
		this.identityProvider = identityProvider;
		this.params.putAll(params);
		initializeUserType();
	}

	private void initializeUserType() {
		this.beId = this.params.get(SAMLConstants.BUISNESS_IDENTIFIER);
		this.orgId = this.params.get(SAMLConstants.ORGANIZATION_IDENTIFIER);
		this.brokerId = this.params.get(SAMLConstants.BROKER_IDENTIFIER);
	}

	public String getBrokerId(){
		return brokerId;
	}
	
	public String getBeId() {
		return beId;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public String getOrgId() {
		return orgId;
	}
}
