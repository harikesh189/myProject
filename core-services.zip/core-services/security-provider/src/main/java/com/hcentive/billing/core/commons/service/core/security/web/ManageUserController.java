package com.hcentive.billing.core.commons.service.core.security.web;

import java.net.URLEncoder;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.ClientAppService;
import com.hcentive.billing.core.commons.api.TrustedEntity;
import com.hcentive.billing.core.commons.api.UserCredentialAlreadyExistsException;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.domain.Address;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.ContactNumber;
import com.hcentive.billing.core.commons.domain.ContactPerson;
import com.hcentive.billing.core.commons.domain.DraftUser;
import com.hcentive.billing.core.commons.domain.Email;
import com.hcentive.billing.core.commons.domain.ForgotPasswordUserDTO;
import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.domain.enumtype.Status;
import com.hcentive.billing.core.commons.domain.util.DomainEntityUtils;
import com.hcentive.billing.core.commons.dto.UserOperation;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.DefaultAccessToken;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.dto.PasswordDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.RegistrationFormDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.RoleDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserCreationDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.service.core.security.manager.RoleManagerService;
import com.hcentive.billing.core.commons.service.core.security.manager.UserManager;
import com.hcentive.billing.core.commons.service.core.security.service.AccessTokenService;
import com.hcentive.billing.core.commons.service.core.security.service.UserCredentialsSevice;
import com.hcentive.billing.core.commons.service.core.security.service.UserService;
import com.hcentive.billing.core.commons.service.ebill.audit.handler.AuditUtil;
import com.hcentive.billing.core.commons.util.EncryptionUtil;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.core.commons.web.WebUtils;

@Controller
@RequestMapping("/user-management")
public class ManageUserController {

	private static final Logger logger = LoggerFactory.getLogger(ManageUserController.class);

	@Autowired
	private RoleManagerService roleManagerService;

	@Autowired
	private UserManager userManager;

	@Autowired
	private ClientAppService clientAppService;

	@Value(value = "${security.ui.app.key:security-ui}")
	private String securityUIAppKey;

	@Value(value = "${security.cookie.secure:true}")
	private boolean isCookieSecure;

	@Autowired
	private UserCredentialsSevice userCredentialsService;

	@Autowired
	private AccessTokenService accessTokenService;

	@Autowired
	private UserService userService;

	@ResponseBody
	@RequestMapping(value = "/admin/users/add", method = RequestMethod.POST, produces = "application/json")
	public Object addAdminUser(@RequestBody UserCreationDTO userCreationDTO) {
		Map<String, Boolean> isAdminUserRegistered = new HashMap<>();
		try {
			addDefaultRolesIdentity(userCreationDTO);
			DraftUser draftUser = userManager.prepareAndGetDraftUser(userCreationDTO);
			userManager.createAndGetUserUsingDraftUser(draftUser);
			userManager.publishUserRegistrationEvent(draftUser, null);
			isAdminUserRegistered.put("isAdminUserRegistered", true);

			AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, draftUser.getIdentity(),
					draftUser.getIdentity(), null, null, AuditMessageDefinition.USER_ADDED, "displayName",
					draftUser.getProfile().getDisplayName(), "userType", draftUser.getUserType().getType());

		} catch (Exception e) {

			logger.error("Error in adding Admin user. {}", e);
			isAdminUserRegistered.put("isAdminUserRegistered", false);
			return new SingleValidationError<>("Exist001 ", e.getMessage(), e);
		}
		return isAdminUserRegistered;
	}

	private void addDefaultRolesIdentity(UserCreationDTO userCreationDTO) {
		logger.debug("Adding default roles");
		Role role = roleManagerService.getRoleByCode("UserCreate");
		if(null != role){
			userCreationDTO.getRoleIdentities().add(role.getIdentity());
			logger.debug("Default roles added successfully");
		}
	}

	@ResponseBody
	@RequestMapping(value = "{beType}/{beId}/user/profile/update", method = RequestMethod.POST)
	public Object updateLoggedInuserProfile(@RequestBody UserDTO userDTO) {
		userDTO.setUserId(ProcessContext.get().getUserId());
		validate(userDTO);
		Set<UserOperation> operationsPerformed = new LinkedHashSet<>();
		operationsPerformed.add(UserOperation.UpdateUserProfile);
		userDTO.setOperationsPerformed(operationsPerformed);
		return userManager.updateUser(userDTO);
	}

	private void validate(UserDTO userDTO) throws InvalidUserException {

		final User user = SecurityUtil.sessionManager().getCurrentUser();
		
		boolean isOperatorUser = false;
		Set<Role> roles = user.getRoles();
		
		for (Role role : roles) {
			if(role.getUserType().equalsIgnoreCase("Operator")){
				isOperatorUser = true;
			}
		}
		
	
		final PersonalProfile updatedProfile = userDTO.getPersonalProfile();
		if(!isOperatorUser){
			if (!user.getIdentity().equalsIgnoreCase(userDTO.getIdentity())) {
				throw new InvalidUserException("Invalid User",
						"Invalid User: user identity from request does not match with the identity of logged in user",
						"Invalid User: user identity from request does not match with the identity of logged in user");
			}
			if (null != user.getProfile() && null != updatedProfile
					&& user.getProfile().getId().equals(updatedProfile.getId())) {
				throw new InvalidUserException("Invalid User",
						"Invalid User: profile id from request does not match with the profile id of logged in user",
						"Invalid User: profile id from request does not match with the profile id logged in user");
			}	
		}
		
		if (updatedProfile == null || updatedProfile.getFirstName() == null || updatedProfile.getFirstName().isEmpty()) {
			throw new InvalidUserException("Invalid User", "Invalid User: First name is mandatory",
					"Invalid User: First name is mandatory");
		}
		if (updatedProfile == null || updatedProfile.getLastName() == null || updatedProfile.getLastName().isEmpty()) {
			throw new InvalidUserException("Invalid User", "Invalid User: Last name is mandatory",
					"Invalid User: Last name is mandatory");
		}
		
		if(updatedProfile != null && updatedProfile.getContactNumbers()!=null){
			final Set<ContactNumber> contactNumbers = updatedProfile.getContactNumbers().getContacts();
			if (updatedProfile.getContactNumbers() == null || contactNumbers.isEmpty()) {
				throw new InvalidUserException("Invalid User", "Invalid User: Contact Number is mandatory",
						"Invalid User: Contact Number is mandatory");
			} else {
				if (!DomainEntityUtils.validContactNumber(contactNumbers)) {
					throw new InvalidUserException("Invalid User", "Invalid User: Contact Number is mandatory",
							"Invalid User: Contact Number is mandatory");
				}
			}
	
		}
		
		if(updatedProfile != null && updatedProfile.getAddressess()!=null){
			final Set<Address> addresses = updatedProfile.getAddressess().getContacts();
			if (updatedProfile.getAddressess() == null || addresses.isEmpty()) {
				throw new InvalidUserException("Invalid User", "Invalid User: Contact Address is mandatory",
						"Invalid User: Contact Address is mandatory");
			} else {
				if (!DomainEntityUtils.validAddress(addresses)) {
					throw new InvalidUserException("Invalid User", "Invalid User: Contact Number is mandatory",
							"Invalid User: Contact Number is mandatory");
				}
			}
		}
		
		if(updatedProfile != null && updatedProfile.getEmails()!=null){
			final Set<Email> emails = updatedProfile.getEmails().getContacts();
			if (updatedProfile.getEmails() == null || emails.isEmpty()) {
				throw new InvalidUserException("Invalid User", "Invalid User: Contact Email is mandatory",
						"Invalid User: Contact Email is mandatory");
			} else {
				if (!DomainEntityUtils.validEmail(emails)) {
					throw new InvalidUserException("Invalid User", "Invalid User: Contact Number is mandatory",
							"Invalid User: Contact Number is mandatory");
				}
			}
		}
		if(updatedProfile != null && updatedProfile.getContactPersons()!=null){
			
			final Set<ContactPerson> contactPersons = updatedProfile.getContactPersons().getContacts();
			if (updatedProfile.getContactPersons() == null || contactPersons.isEmpty()) {
				throw new InvalidUserException("Invalid User", "Invalid User: Contact Person is mandatory",
						"Invalid User: Contact Person is mandatory");
			} else {
				if (!DomainEntityUtils.validContactPerson(contactPersons)) {
					throw new InvalidUserException("Invalid User", "Invalid User: Contact Number is mandatory",
							"Invalid User: Contact Number is mandatory");
				}
			}
		}
	
	}

	@ResponseBody
	@RequestMapping(value = "/admin/users/update", method = RequestMethod.POST)
	public Object updateUserStatus(@RequestBody UserDTO userDTO) {
		userDTO.setUserId(ProcessContext.get().getUserId());
		validate(userDTO);
		if (userDTO.getOperationsPerformed() == null) {
			Set<UserOperation> operationsPerformed = new LinkedHashSet<>();
			operationsPerformed.add(UserOperation.UpdateUserProfile);
			operationsPerformed.add(UserOperation.UpdateUserRoles);
			operationsPerformed.add(UserOperation.UpdateUserStatus);
			userDTO.setOperationsPerformed(operationsPerformed);
		}
		return userManager.updateUser(userDTO);
	}

	@ResponseBody
	@RequestMapping(value = "admin/user/profile/update", method = RequestMethod.POST)
	public Object updateAdminLoggedInuserProfile(@RequestBody UserDTO userDTO) {
		userDTO.setUserId(ProcessContext.get().getUserId());
		validate(userDTO);
		Set<UserOperation> operationsPerformed = new LinkedHashSet<>();
		operationsPerformed.add(UserOperation.UpdateUserProfile);
		userDTO.setOperationsPerformed(operationsPerformed);
		return userManager.updateUser(userDTO);
	}

	@ResponseBody
	@RequestMapping(value = "/{enterprise}/user-manager/registration", method = RequestMethod.POST)
	public Map<String, String> userRegistration(@RequestBody RegistrationFormDTO registrationFormDTO,@PathVariable(value = "enterprise") String enterprise,
			final HttpServletRequest request, final HttpServletResponse response) {
		Map<String, String> isUserSuccessfullyRegistered = new HashMap<>();
		try {
			registrationFormDTO.setEnterpriseName(enterprise);
			final Map<String,String> credentialMap = getUserNameAndPasswordFromDecryptedString(populateCredentialsMapFromHeader(request));
			registrationFormDTO.setUserName(credentialMap.get("userName"));
			registrationFormDTO.setPassword(credentialMap.get("password").toCharArray());
			
			userManager.addUser(registrationFormDTO);
			userManager.deleteTokenAndLogoutAfterProcessCompleted();
			isUserSuccessfullyRegistered.put("isUserSuccessfullyRegistered", "true");
			clearCookies(request, response, "/", isCookieSecure);
		} catch (UserCredentialAlreadyExistsException e) {
			isUserSuccessfullyRegistered.put("exceptionName", "UserCredentialAlreadyExistsException");
		} catch (IllegalStateException e) {
			isUserSuccessfullyRegistered.put("exceptionName", "IllegalStateException");
		} catch (Exception e) {
			logger.error("Error in user registration {}", e);
			isUserSuccessfullyRegistered.put("exceptionName", "Exception");
		} finally {
			String status = isUserSuccessfullyRegistered.get("isUserSuccessfullyRegistered");
			if (status == null || status.trim().equals("")) {
				isUserSuccessfullyRegistered.put("isUserSuccessfullyRegistered", "false");
			}
		}
		return isUserSuccessfullyRegistered;
	}

	private void clearCookies(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,
			final String path, final boolean isCookieSecure) {
		final Map<String, String> cookieParams = WebUtils.getCookiesFromRequest(httpRequest);
		logger.debug("MAX age of cookies will be set to 0 to clear cookies on client side");
		for (final Map.Entry<String, String> entry : cookieParams.entrySet()) {
			final Cookie cookie = new Cookie(entry.getKey(), entry.getValue());
			cookie.setHttpOnly(true);
			cookie.setSecure(isCookieSecure);
			cookie.setMaxAge(0);
			cookie.setPath(path);
			cookie.setDomain("." + httpRequest.getServerName());
			httpServletResponse.addCookie(cookie);
		}
	}

	@RequestMapping(value = "/{enterprise}/register", method = RequestMethod.GET)
	public String registerUser(@PathVariable(value = "enterprise") String enterprise,
			final HttpServletRequest request) {
		logger.debug("Inside register method. Getting IDP List.");

		logger.debug("Inside register method. Getting IDP List.");
		String clientId = request.getParameter("client_id");
		List<ClientAppIdpEnterpriseConfig> clientAppIdpEnterpriseConfigs = clientAppService
				.findClientAppEnterpriseIdpConfigs(enterprise, clientId);
		if (clientAppIdpEnterpriseConfigs == null || clientAppIdpEnterpriseConfigs.size() == 0) {
			logger.error("No IDP Configured for enterprise {} and clientId {}", enterprise, clientId);
			throw new IllegalStateException("No IDP configured");
		}
		return buildRedirectUrl(enterprise, request, clientId, clientAppIdpEnterpriseConfigs);
	}

	private String buildRedirectUrl(String enterprise, final HttpServletRequest request, String clientId,
			List<ClientAppIdpEnterpriseConfig> clientAppIdpEnterpriseConfigs) {
		if (clientAppIdpEnterpriseConfigs.size() == 1) {
			final StringBuilder redirectUrlBuilder = new StringBuilder(WebUtils.getBaseUrl(request));
			redirectUrlBuilder.append("/").append("security").append("/").append(enterprise).append("/")
					.append("oAuth2").append("/").append("register").append("?client_id=").append(clientId)
					.append("&response_type=token").append("&idpKey=")
					.append(clientAppIdpEnterpriseConfigs.get(0).getIdentityProvider().getIdpKey());
			return "redirect:" + redirectUrlBuilder.toString();
		} else { // redirect to security-ui app to show list of idp

			final StringBuilder redirectUrlBuilder = new StringBuilder(WebUtils.getBaseUrl(request));
			redirectUrlBuilder.append("/").append(enterprise).append("/").append(securityUIAppKey).append("?client_id=")
					.append(clientId).append("/#/registration/selectIdp");
			logger.debug("Redirection :- {}", redirectUrlBuilder.toString());
			return "redirect:" + redirectUrlBuilder.toString();
		}
	}

	@ResponseBody
	@RequestMapping(value = "/admin/users/passwords", method = RequestMethod.POST)
	public Object updateLoggedInUser(HttpServletRequest request) {
		Map<String, String> resultMap = new HashMap<String, String>();
		PasswordDTO passwordDTO = populatePasswordDTO(request);
		String status = userManager.changePassword(passwordDTO.getOldPassword(), passwordDTO.getNewPassword());
		resultMap.put(status, status);
		return resultMap;

	}

	private PasswordDTO populatePasswordDTO(HttpServletRequest request) {
		final Map<String,String> credentialMap = getPasswordFromDecryptedString(populateCredentialsMapFromHeader(request));
		PasswordDTO passwordDTO = new PasswordDTO();
		passwordDTO.setNewPassword(credentialMap.get("newPassword"));
		passwordDTO.setOldPassword(credentialMap.get("oldPassword"));
		return passwordDTO;
	}

	@ResponseBody
	@RequestMapping(value = "/{beType}/{beId}/users/passwords", method = RequestMethod.POST)
	public Object updateLoggedInUserForCustomer(HttpServletRequest request) {
		
		return updateLoggedInUser(request);

	}
	
	@ResponseBody
	@RequestMapping(value = "/{enterprise}/update/expired/password", method = RequestMethod.POST)
	public Object updateExpiredPassword(@RequestBody Map<String,String> userNameMap , @PathVariable(value = "enterprise") String enterprise ,HttpServletRequest request) {
		Map<String, String> resultMap = new HashMap<String, String>();
		
		WFMUserCredentials wfmUserCredentials = userCredentialsService.getCredentialsByUserNameIgnoreCaseAndEneterpriseName(userNameMap.get("userName"), enterprise);
		PasswordDTO passwordDTO = populatePasswordDTO(request);
		boolean isPasswordUpdated = userCredentialsService.updatePassword(wfmUserCredentials,
				passwordDTO.getNewPassword(),passwordDTO.getOldPassword());
		String status =  null;
		if(!isPasswordUpdated){
			status =  Status.FAILED.name();
		}else{
			status = Status.SUCCESS.name();
		}
		resultMap.put(status, status);
		return resultMap;
	}
	
	private String populateCredentialsMapFromHeader(
			HttpServletRequest request) {
		final String passphrase = request.getHeader("passPhrase");
		logger.debug("Extracted passphrase for decryption.");
		final String encryptedText = request.getHeader("user-credential");
		logger.debug("Extracted encryptedText for decryption.");
		final String iv = request.getHeader("iv");
		logger.debug("Extracted iv for decryption.");
		final String salt = request.getHeader("salt");
		logger.debug("Prepared salt using nonce for decryption.");
		final String decryptedUserCredentials = EncryptionUtil.getAesDecryptedString(encryptedText, passphrase, iv, salt);
		logger.debug("Extracted decrypted user credentials for decryption.");
	return decryptedUserCredentials;	
	}
	
	
	private final Map<String,String> getPasswordFromDecryptedString(final String deCryptedString){
		Map<String,String> credentialsMap = new HashMap<>();
		if(deCryptedString != null){
			String credentialsArray[] = deCryptedString.split("&&");
			String newPasswordKey = "newPassword=";
			String currentPasswordKey = "currentPassword=";
			credentialsMap.put("newPassword", credentialsArray[0].substring(newPasswordKey.length(),credentialsArray[0].length()));
			credentialsMap.put("oldPassword", credentialsArray[1].substring(currentPasswordKey.length(),credentialsArray[1].length()));
			return credentialsMap;
		}
		return null;
	}

	private final Map<String,String> getUserNameAndPasswordFromDecryptedString(final String deCryptedString){
		Map<String,String> credentialsMap = new HashMap<>();
		if(deCryptedString != null){
			String credentialsArray[] = deCryptedString.split("&&");
			String userNameKey = "userName=";
			String passwordKey = "password=";
			credentialsMap.put("userName", credentialsArray[0].substring(userNameKey.length(),credentialsArray[0].length()));
			credentialsMap.put("password", credentialsArray[1].substring(passwordKey.length(),credentialsArray[1].length()));
			return credentialsMap;
		}
		return null;
	}
	
	@ResponseBody
	@RequestMapping(value = "/admin/permissions", method = RequestMethod.GET, produces = "application/json")
	public Collection<Permission> getAlPermissions() {
		return roleManagerService.getAllPermissions();
	}

	@RequestMapping(value = "/admin/users/remove", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Object removeUser(@RequestBody List<String> userIdentity) {
		return userManager.removeUser(userIdentity);
	}

	@ResponseBody
	@RequestMapping(value = "/admin/roles/{roleId}/permissions", method = RequestMethod.POST, produces = "application/json")
	public Collection<Permission> getAllPermission(@PathVariable("roleId") String roleId) {
		return roleManagerService.getAllPermissions(roleId);
	}

	@ResponseBody
	@RequestMapping(value = "admin/permissions", method = RequestMethod.POST, produces = "application/json")
	public void addPermission(Permission permission) {
		roleManagerService.addPermission(permission);
	}

	@ResponseBody
	@RequestMapping(value = "/admin/roles", method = RequestMethod.POST)
	public Page<Role> getAllRoles(@RequestBody SearchCriteria searchCriteria) {
		return roleManagerService.getAllRoles(searchCriteria);
	}

	@ResponseBody
	@RequestMapping(value = "/admin/roles/add", method = RequestMethod.POST)
	public Object addRole(@RequestBody RoleDTO role) {
		if(StringUtils.isEmpty(role.getUserType())){
			logger.error("UserType cannot be null or empty");
			throw new RuntimeException("UserType cannot be null or empty");
		}
		return roleManagerService.addRole(role);
	}

	@ResponseBody
	@RequestMapping(value = "/admin/roles/update", produces = "application/json", method = RequestMethod.POST)
	public Object updateRole(@RequestBody RoleDTO role) {
		return roleManagerService.updateRole(role);
	}

	@ResponseBody
	@RequestMapping(value = "/admin/roles/{roleId}/remove", produces = "application/json", method = RequestMethod.POST)
	public void removeRole(Long roleId) {
		roleManagerService.removeRole(roleId);
	}

	@ResponseBody
	@RequestMapping(value = "/admin/{beId}/managers", produces = "application/json", method = RequestMethod.GET)
	public Collection<User> getBEManagesManagers(@PathVariable String beId) {
		return userManager.getBEManagesManagers(beId);
	}

	@ResponseBody
	@RequestMapping(value = "/admin/business-types", produces = "application/json", method = RequestMethod.GET)
	public Collection<String> fetchUserTypes() {
		return BusinessEntityTypes.beTypesInApplication();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/admin/users", produces = "application/json")
	public @ResponseBody Page<User> getUsersByCriteria(@RequestBody SearchCriteria searchCriteria) {
		logger.debug("Start :: getting all users for admin");
		Page<User> users = userManager.getAdminUsers(searchCriteria);
		return users;

	}

	@RequestMapping(method = RequestMethod.GET, value = "/admin/users/{userId}", produces = "application/json")
	public @ResponseBody User getUsersByIdentity(@PathVariable String userId) {
		logger.debug("Start :: getting user for userid::" + userId);
		return userManager.getUserById(userId);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/{beType}/{beId}/users/{userId}", produces = "application/json")
	public @ResponseBody User getUserByIdentity(@PathVariable String userId) {
		logger.debug("Start :: getting user for userid for {beType}/{beId}::" + userId);
		return userManager.getUserById(userId);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/customer/users/{userId}", produces = "application/json")
	public @ResponseBody List<UserCredentials> getUserCredentialByUserIdentity(@PathVariable String userId) {
		logger.debug("Start :: getting user for userid::" + userId);
		return userManager.getUserCredentialByUserIdentity(userId);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/users/associate-users")
	public @ResponseBody Object associateWithCurrentUser(@RequestBody(required = true) final UserDTO userDTO) {
		if (userDTO == null) {
			logger.debug("searchCriteria is null or empty");
			return "Failed";
		}
		return userManager.associateWithCurrentUser(userDTO);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/admin/associate-user")
	public @ResponseBody Object associateWithGivenUser(@RequestBody(required = true) final UserDTO userDTO) {
		if (null == userDTO) {
			logger.debug("userID is either null or empty");
			return "Failed";

		}
		return userManager.associateWithGivenUser(userDTO);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/admin/{appkey}")
	public @ResponseBody DefaultAccessToken clientUserAuthManagment(@PathVariable final String appkey) {
		if (null == appkey) {
			logger.debug("appkey is either null or empty");
		}
		return userManager.createFixedAccessTokenForApp(appkey);
	}

	@ResponseBody
	@RequestMapping(value = "/{enterpriseName}/forgot-password", produces = "application/json", method = RequestMethod.POST)
	public Map<String, String> forgotPassword(@RequestBody ForgotPasswordUserDTO forgotPasswordUserDTO,
			HttpServletRequest request, @PathVariable("enterpriseName") String enterpriseName) {
		Map<String, String> mailMap = new HashMap<>();
		String idpKey = request.getParameter("idpKey");
		String username = forgotPasswordUserDTO.getUserName();
		WFMUserCredentials usrCredentials = userCredentialsService
				.getCredentialsByUserNameIgnoreCaseAndIdpKeyAndEneterpriseName(username, idpKey, enterpriseName);
		if (null == usrCredentials) {
			return null;
		}
		publishForgotPasswordEvent(usrCredentials, request);
		String emailId = usrCredentials.getUserTenantInfo().getProfile().getEmails().primaryContact().getEmailId();
		mailMap.put("emailId", emailId);
		return mailMap;
	}

	private void publishForgotPasswordEvent(WFMUserCredentials usrCredentials, HttpServletRequest request) {
		final String idpKey = request.getParameter("idpKey");
		final String clientId = request.getParameter("client_id");
		final String enterpriseName = usrCredentials.getEnterpriseName();
		final StringBuilder url = new StringBuilder(SecurityUtil.enterpriseToClientAppDomain(enterpriseName, clientId));
		url.append("/").append("security-ui/")
				.append("?tokenId=");
		Map<String, String> tokenAttributes = new HashMap<String, String>();

		tokenAttributes.put("idpKey", idpKey);
		tokenAttributes.put("enterpriseName", enterpriseName);
		tokenAttributes.put("userName", usrCredentials.getUsername());
		TrustedEntity entity = userService.getTrustedEntityByName();
		Set<Permission> permissions = new HashSet<Permission>();
		permissions = (Set<Permission>) entity.permissions();
		UserTenantInfo userTenantInfo = usrCredentials.getUserTenantInfo();
		AccessToken fixedValueToken = accessTokenService.createAnonymousFixedVaueToken(new DateTime().plusHour(24),
				userTenantInfo.getTenantId(), permissions, tokenAttributes);

		url.append(URLEncoder.encode(fixedValueToken.getIdentity())).append("&client_id=").append(clientId)
				.append("&idpKey=").append(idpKey).append("/#/update-password");

		ForgotPasswordUserDTO forgotPasswordUserDTO = new ForgotPasswordUserDTO();
		forgotPasswordUserDTO.setUserTenantInfo(userTenantInfo);
		forgotPasswordUserDTO.setUrl(url.toString());
		ProcessContext.clear();
		String userName = null;
		if (null != usrCredentials.getUserTenantInfo()
				&& null != usrCredentials.getUserTenantInfo().getProfile()) {
			userName = usrCredentials.getUserTenantInfo().getProfile().getDisplayName();
		}
		ProcessContextUtil.buildProcessContext(userTenantInfo.getIdentity(), null, userTenantInfo.getTenantId(), null,
				userName);
		EventUtils.publish(new Event<ForgotPasswordUserDTO>(EventType.FORGOT_PASSWORD, forgotPasswordUserDTO));
	}

	@ResponseBody
	@RequestMapping(value = "/{enterpriseName}/update-password", method = RequestMethod.POST)
	public Map<String, String> updatePassword(@RequestBody ForgotPasswordUserDTO forgotPasswordUserDTO,
			@PathVariable("enterpriseName") String enterpriseName, HttpServletRequest request,
			HttpServletResponse response) {
		AccessToken token = Utils.getAccessToken();
		Map<String, String> tokenAttributesMap = token.getTokenAttributes();
		String username = tokenAttributesMap.get("userName");
		String idpKey = request.getParameter("idpKey");
		String clientId = request.getParameter("client_id");
		String newPassword = forgotPasswordUserDTO.getPassword();
		Map<String, String> redirectionUrl = new HashMap<>();
		SingleValidationError<UserCredentials> passwordError = userCredentialsService.updatePassword(username, idpKey,
				enterpriseName, newPassword);
		if (passwordError != null) {
			redirectionUrl.put("errorMsg", passwordError.getErrorMsg());
			return redirectionUrl;
		}
		userManager.deleteTokenAndLogoutAfterProcessCompleted();
		clearCookies(request, response, "/", isCookieSecure);
		final StringBuilder redirectUrlBuilder = new StringBuilder(WebUtils.getBaseUrl(request));
		redirectUrlBuilder.append("/").append(enterpriseName).append("/").append(securityUIAppKey).append("/")
				.append("?client_id=").append(clientId).append("&idpKey=").append(idpKey).append("/#/login");
		redirectionUrl.put("error", "errorMsg");
		redirectionUrl.put("url", redirectUrlBuilder.toString());
		return redirectionUrl;
	}

}
