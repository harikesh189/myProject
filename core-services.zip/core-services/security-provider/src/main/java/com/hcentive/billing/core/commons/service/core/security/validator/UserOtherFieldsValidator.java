package com.hcentive.billing.core.commons.service.core.security.validator;

import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.validation.Validator;
import com.hcentive.billing.core.commons.validation.error.SingleValidationError;

public class UserOtherFieldsValidator implements
		Validator<UserDTO, SingleValidationError<UserDTO>> {

	@Override
	public SingleValidationError<UserDTO> validate(UserDTO t) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String identity() {
		// TODO Auto-generated method stub
		return null;
	}

}
