package com.hcentive.billing.core.commons.service.core.security.web.auth;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.SessionContext;
import com.hcentive.billing.core.commons.cache.WFMCache;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.SecuredAccessContext;
import com.hcentive.billing.core.commons.security.exception.SessionTimedOut;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.dto.SecurityToken;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.service.security.filter.FilterErrorHandler;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.util.ClientAppToCookieNameMapping;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.web.WebUtils;

@Controller
@RequestMapping("/security")
public class SecurityController {

	private static final Logger logger = LoggerFactory
			.getLogger(SecurityController.class);

	final private ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	private AuthManager authManager;
	
	@Autowired
	private WFMCache<String, String> authenticationCache;
	
	@Value(value = "${security.cookie.secure:true}")
	private boolean isCookieSecure;
	
	@Value(value = "${clear.cookie.for.client.app:security-ui,xpgApp}")
	private String[] clearCookieForClientApp = new String[0];
	
	@Autowired
	private FilterErrorHandler filterErrorHandler;


	@RequestMapping(method = RequestMethod.POST, value = "/sctx", produces = "application/json")
	public @ResponseBody
	AccessToken getSecurityInfo(final HttpServletRequest request,final HttpServletResponse response,
			@RequestBody final SecurityToken securityToken) throws IOException {
		logger.debug("Start:getSecurityInfo:: {}", securityToken);
		logger.debug("ClientId ::: {}",
				securityToken != null ? securityToken.getClientId() : null);
		if (null != securityToken && securityToken.getClientId() != null) {
			
			try {
				logger.debug("Getting Cookies from Request");
				// enable this check post changes for tenant in url.
				final String sessionIdFromCookie = AuthWebUtil.getTokenIdFromCookie(request,securityToken.getClientId());
				
				
				logger.debug("SessionId from Cookie : {}", sessionIdFromCookie);
				// match
				if (sessionIdFromCookie == null) {
					throw new SecurityException("Not valid session.",
							new IllegalAccessError());
				}else{
					logger.debug("Creating Secured Access Context");
					SecuredAccessContext.createNew(sessionIdFromCookie);
				}
				
				logger.debug("Start:getSecurityInfo:: {}",
						securityToken.getTokenId());
				final AccessToken accessToken = authManager
						.getAuthInfo(sessionIdFromCookie);
				logger.debug("Access token found :: {}", accessToken);
				
				clearCookieForIdentifiedClientApps(request,response,securityToken.getClientId());
				
				return accessToken.encryptedAccessTokenCopy();
			} catch(SessionTimedOut e){ 
				logger.error("Session Timed Out ");
				//WebUtils.clearCookie(httpRequest, httpServletResponse,"/",isCookieSecure);
				response.sendError(HttpServletResponse.SC_GATEWAY_TIMEOUT);;
				logger.debug("Returning from Secured Filter");
				return null;
			}
		}
		logger.error("Illegal Access");
		throw new SecurityException("Not valid session.",
				new IllegalAccessError());
	}

	private void clearCookieForIdentifiedClientApps(HttpServletRequest request,
			HttpServletResponse response, final String clientId) {
		for (String clientApp : clearCookieForClientApp) {
			if(clientApp.equals(clientId)){
				final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(clientId);
				WebUtils.clearCookie(request, response, "/", isCookieSecure,BillingConstant.COOKIE_SID+cookieIdentifier);
			}
		}
	}

	@RequestMapping(value = "/user/current", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody
	User getUser() {
		logger.debug("Start:getUser");
		final User user = authManager.fetchUser();
		logger.debug("End:getUser");
		return user;
	}
	
	@RequestMapping(value = "/{enterpriseName}/view/current/context", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody
	Map<String,Object> getCurrentViewContext(@PathVariable("enterpriseName") String enterpriseName , final HttpServletRequest request) throws JsonProcessingException {
		logger.debug("Start:getUser");
		final AccessToken accessToken = Utils.getAccessToken();
		final Map<String,Object> currentViewContextMap = new HashMap<String,Object>();
		final ProcessContext pc = ProcessContext.get();
		final boolean currentStatus = pc.shouldIgnoreTenant();
		pc.ignoreTenantDuringProcessing();
		final String oauAuth2Parameters = authenticationCache.get(BillingConstant.AUTHENTICATION_STATE_CACHE_KEY+accessToken.getIdentity());
		revertOldValue(currentStatus,pc);
		currentViewContextMap.put("state", oauAuth2Parameters);
		currentViewContextMap.put("userCredentialPrompt", request.getParameter("userCredentialPrompt"));
		currentViewContextMap.put("currentIdpKey", RequestContext.get().identityProvider().getIdpKey());
		final List<ClientAppIdpEnterpriseConfig> allConfigs = ( List<ClientAppIdpEnterpriseConfig>)request.getAttribute("availableConfigs");
		currentViewContextMap.put("availableIdps", mapper.writeValueAsString(AuthWebUtil.getIdpInfos(allConfigs)));
		currentViewContextMap.put("usingDefaultEnterprise", RequestContext.get().usingDefaultEnterprise());
		currentViewContextMap.put("callBackUrl", "/security/"+enterpriseName+"/oAuth2/int/assertIdentity");
		return currentViewContextMap;
	}
	
	private void revertOldValue(boolean ignoreTenant, ProcessContext pc) {
		if(ignoreTenant){
			pc.ignoreTenantDuringProcessing();
		}else{
			pc.acknowledgeTenantDuringProcessing();
		}
	}
	
}
