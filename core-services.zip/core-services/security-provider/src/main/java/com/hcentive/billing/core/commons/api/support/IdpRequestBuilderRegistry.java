package com.hcentive.billing.core.commons.api.support;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.beans.SpringBackedBeanRegistry;

@SuppressWarnings("rawtypes")
@Component
public class IdpRequestBuilderRegistry extends
		SpringBackedBeanRegistry<IdpRequestBuilder> {

	private final Map<String, IdpRequestBuilder> registry = new HashMap<String, IdpRequestBuilder>();

	@Override
	protected Class<IdpRequestBuilder> lookupForType() {
		return IdpRequestBuilder.class;
	}

	@Override
	protected void registerBean(IdpRequestBuilder builder) {
		registry.put(builder.buildsRequestForIdp(), builder);
	}

	public IdpRequestBuilder getBuilder(final String idpKey) {
		return registry.get(idpKey);
	}

	public IdpRequestBuilder getBuilder() {
		return registry
				.get(RequestContext.get().identityProvider().getIdpKey());
	}
}
