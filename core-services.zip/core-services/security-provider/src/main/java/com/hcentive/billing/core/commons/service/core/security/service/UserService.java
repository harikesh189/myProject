package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.hcentive.billing.core.commons.api.TrustedEntity;
import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;
import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.domain.Administrator;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Facilitator;
import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserCredentials;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.service.core.security.dto.RegistrationFormDTO;
import com.hcentive.billing.core.commons.service.core.security.dto.UserDTO;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * @author Uttam Tiwari
 * @author Mohit Gupta
 * @author Prateek.Bansal
 */

public interface UserService {

	public abstract User getUserById(String userId);

	public abstract List<UserCredentials> getUserCredentialByUserIdentity(
			String userId);

	public abstract Page<BusinessEntity> fetchMatchingBEs(
			SearchCriteria searchCriteria);

	public abstract User associateAndUpdate(String userId,
			Collection<BusinessEntity> bes);

	public abstract User deAssociate(String identity,
			Collection<BusinessEntity> businessEntities);

	public abstract User updateUserProfile(String identity,
			PersonalProfile personalProfile);

	User updateUserRoles(String identity, Set<Role> newRoles);

	public abstract Page<BusinessEntity> getBEByIdentities(Set<String> beId);

	User getUserByIdentity(String identity);

	Collection<User> getBEManagers(BusinessEntity be);

	public abstract List<User> getUserBySearchCriteria(
			SearchCriteria searchCriteria);

	IOU<Facilitator, AsyncCallback<Facilitator>> fetchFaciliator(
			String externalId, String npn);

	public abstract boolean removeUser(List<String> userIdentity);

	User getBEManagesUser(BusinessEntity be,
			Map<String, String> matchingCriteria);

	void associate(Collection<BusinessEntity> bes, User userEntity)
			throws IllegalAccessError;

	public abstract User updateUserStatus(String identity, UserStatus userStatus);

	Page<User> getAdminUsers(SearchCriteria searchCriteria);

	public abstract UserTenantInfo getUserTenantInfoByIdentity(String identity);

	void deleteToken();

	WFMUserCredentials createAndGetUserCredentials(RegistrationFormDTO registrationFormDTO);

	BusinessEntity getBEFromExternalId(String externalId);

	WFMUserCredentials saveWFMUserCredentials(
			WFMUserCredentials wfmUserCredentials);
	
	User getUserByExternalId(String externalId);

	User addUser(User user);

	TrustedEntity getTrustedEntityByName();

	public User updateUser(User user);
}
