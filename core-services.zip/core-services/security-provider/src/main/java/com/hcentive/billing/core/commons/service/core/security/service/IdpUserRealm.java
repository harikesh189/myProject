package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.orm.jpa.EntityManagerHolder;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.hcentive.billing.core.AbstractSecurityRealm;
import com.hcentive.billing.core.commons.api.IdentityProvider;
import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.SAMLConstants;
import com.hcentive.billing.core.commons.api.support.IdpUserToken;
import com.hcentive.billing.core.commons.domain.Administrator;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.DraftUser;
import com.hcentive.billing.core.commons.domain.IdpUserCredential;
import com.hcentive.billing.core.commons.domain.Manager;
import com.hcentive.billing.core.commons.domain.Operator;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.Role;
import com.hcentive.billing.core.commons.domain.Role.RoleStatus;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.UserTenantInfo;
import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.exception.InvalidUserException;
import com.hcentive.billing.core.commons.persistence.factory.repository.OperatorRepository;
import com.hcentive.billing.core.commons.service.core.security.manager.UserManager;
import com.hcentive.billing.core.commons.service.core.security.repository.DraftUserMongoRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.IdpUserCredentialRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserTenantInfoRepository;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.CriteriaOperator;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

public class IdpUserRealm extends AbstractSecurityRealm<IdpUserToken> {

	public IdpUserRealm() {
		super(IdpUserToken.class);
	}

	private static final Logger LOGGER = LoggerFactory
			.getLogger(IdpUserRealm.class);

	@Autowired
	private UserCredentialsSevice credentialsSevice;

	@Autowired
	private UserService userService;
	
	@Autowired
	private RoleService roleService;

	@Autowired
	protected UserRepository userRepository;
	
	@Autowired
	private DraftUserMongoRepository draftUserMongoRepository;
	
	@Autowired
	private UserManager userManager;
	
	@Autowired
	private UserTenantInfoRepository userTenantInfoRepository;
	
	@Autowired
	private EntityManagerFactory emf;
	
	@Autowired
	private IdpUserCredentialRepository idpRepository;
	
	@Autowired
	private OperatorRepository operatorRepository;

	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken token) throws AuthenticationException {
		LOGGER.debug("In doGetAuthenticationInfo");
		return getAuthenticationInfo((IdpUserToken) token);
	}

	private AuthenticationInfo getAuthenticationInfo(final IdpUserToken token) {
		LOGGER.debug("Getting authentication info for IDP token");
		IdpUserCredential credentials = null;
		final ProcessContext pc  = ProcessContext.get();
		try {
			LOGGER.debug("Going to find IDP Credentials");
			initiliazeProcessContext();
			final EntityManagerHolder emHolder = (EntityManagerHolder) TransactionSynchronizationManager.getResource(emf);
			if(null != emHolder){
				//implies that an EntityManager is associated with the thread. Manipulate it.
				final EntityManager entityManager = emHolder.getEntityManager();
				entityManager.setProperty(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, RequestContext.get().enterprise().getName());
				LOGGER.debug("Looking for credentials");
				credentials = lookupCredential(token);
				LOGGER.debug("Idp Credentials Found");
			}else{
				//there is not EntityManager attached feel the freedom.
				LOGGER.debug("Looking for credentials");
				credentials = lookupCredential(token);
			}
			LOGGER.debug("Identifying User");
			User user = createOrIdentifyUser(token);
			if(null != credentials && null == credentials.getUserTenantInfo()){
				LOGGER.debug("Attaching User to newly created credentials");
				attachUserToCredentials(credentials, user);
				LOGGER.debug("User attached successfully");
			}
			final AuthenticationInfo authInfo = loadAuthenticationInfo(token, credentials,user);
			revertProcessContext(pc);
			return authInfo;
		} catch (InvalidUserException e) {
			LOGGER.debug("No Idp Credentials Found");
			throw new AuthenticationException("No Matching credentials found");
		}
	}

	private void initiliazeProcessContext() {
		invoilateProcessContext();
		ProcessContext.initializer().initialize().setTenantId(RequestContext.get().enterprise().getName());
	}

	/***
	 * try to find BE, lookup user associated with this be. if more than one
	 * found throw exception. If user not found, create user. If user found,
	 * check whether already another token exists for this IDP.If so throw
	 * exception. create new credentials for this token.
	 * 
	 * @param token
	 * @return
	 * @throws InvalidUserException
	 */
	private IdpUserCredential lookupCredential(final IdpUserToken token)
			throws InvalidUserException {
		LOGGER.debug("Getting Principal");
		final String principal = (String) token.getPrincipal();
		LOGGER.debug("Getting idp Key");
		final String idpKey = ((IdentityProvider) token.getCredentials())
				.getIdpKey();
		LOGGER.debug(
				"Looking for Credentials for idp user identity : {} and idpKey {}",
				principal, idpKey);
		IdpUserCredential credential = createOrGetExistingIdpCredentials(token,
				principal, idpKey);
		return credential;
	}

	private IdpUserCredential createOrGetExistingIdpCredentials(
			final IdpUserToken token, final String principal,
			final String idpKey) {
		final String enterpriseName = RequestContext.get().enterprise().getName();
		IdpUserCredential credential = credentialsSevice
				.getCredentialByIdpUserIdentityAndIdpKeyAndEnterpriseName(principal, idpKey,enterpriseName);
		LOGGER.debug("Credentials found :{}", credential);
		if (credential == null) {
			LOGGER.debug("Creating IDP Credentials");
			IdpUserCredential idpUserCredentials = IdpUserCredential
					.createIdpUserCredentials(RandomGenerator.randomString(),
							"", principal, idpKey,enterpriseName);
			credential = credentialsSevice
					.addIDPUserCredentials(idpUserCredentials);
		}
		return credential;
	}

	private void attachUserToCredentials(IdpUserCredential idpUserCredentials,
			User user) {
		LOGGER.debug("Attaching credentials with user");
		UserTenantInfo userTenantInfo = userTenantInfoRepository.findByIdentity(user.getIdentity());
		idpUserCredentials.setUserTenantInfo(userTenantInfo);
		idpRepository.save(idpUserCredentials);
	}

	@SuppressWarnings("rawtypes")
	private User createOrIdentifyUser(final IdpUserToken token) {
		Map<String, String> params = token.getParams();
		BusinessEntity be = null;
		User user = null;
		if(null == token.getBeId() && token.getBrokerId() == null){
			if(null != token.getOrgId()){
				LOGGER.debug("Getting operator for operator id:{}",token.getOrgId());
				Operator operator = operatorRepository.findByExternalId(token.getOrgId());
				if(null != operator){
					return createAdministrator(token);
				}else{
					Set<String> manageBEOfTypes = new HashSet<String>();
					manageBEOfTypes.add(BusinessEntityTypes.GROUP_CUSTOMER);
					be = getBusinessEntityByExternalId(token.getOrgId(),manageBEOfTypes);
				}
			}else{
				LOGGER.error("Not able to create user as both beId and orgId are null");
				throw new IllegalStateException("Not able to create user as both beId and orgId are null");
			}
				
		}else{
			if(token.getBrokerId() != null && token.getBeId() != null){
				BusinessEntity beFromIdentifier = getBusinessEntityByExternalId(token.getBeId(),RequestContext.get().clientApp().getManagedBusinessEntityTypes());
				if(beFromIdentifier != null){
					LOGGER.debug("Looking for user ");
					user = lookForUserOrCreateUser(token, params, beFromIdentifier);
				}
				BusinessEntity beFromBrokerIdentifier = getBusinessEntityByExternalId(token.getBrokerId(),RequestContext.get().clientApp().getManagedBusinessEntityTypes());
				if(null != beFromBrokerIdentifier){
					if(null != user){
						List<BusinessEntity> listOfBE = new ArrayList<BusinessEntity>();
						listOfBE.add(beFromBrokerIdentifier);
						user = userService.associateAndUpdate(user.getIdentity(), listOfBE);
					}else{
						user = lookForUserOrCreateUser(token, params, beFromBrokerIdentifier);
					}
				}else if(null == beFromIdentifier){
					LOGGER.error("Invalid subscriber or group");
					throw new AuthenticationException("Invalid subscriber or group");
				}
			}else{
				final String beId = token.getBeId() != null ? token.getBeId() : token.getBrokerId();
				be = getBusinessEntityByExternalId(beId,RequestContext.get().clientApp().getManagedBusinessEntityTypes());
				LOGGER.debug("BE Found {}", be);
				if(null == be ){
					LOGGER.error("Invalid subscriber or group");
					throw new AuthenticationException("Invalid subscriber or group");
				}
				user = lookForUserOrCreateUser(token, params, be); 
			}
		}
		
		return user;
	}

	private User lookForUserOrCreateUser(final IdpUserToken token,
			Map<String, String> params, BusinessEntity be) {
		LOGGER.debug("Looking for user ");
		User user = userService.getBEManagesUser(be, params);
		LOGGER.debug("User Found : {}", user);
		if (user == null) {
			user = populateUser(token, be, params);
			if(null != user)
				userService.addUser(user);
			else{
				LOGGER.error("Insufficient Info to create user");
				throw new IllegalStateException("Insufficient Info to create user");
			}
		}
		return user;
	}

	private User createAdministrator(final IdpUserToken token) {
		LOGGER.debug("Creating Admin User");
		final Map<String,String> params = token.getParams();
		PersonalProfile profile = PersonalProfile.createAndGetPersonalProfile("", "",params.get(SAMLConstants.FIRST_NAME),params.get(SAMLConstants.LAST_NAME), null, null,null, null);
		LOGGER.debug("Fetching Default Role for Administrator");
		Role role = roleService.getRoleByRoleCode(RequestContext.get().clientApp().getAppKey());
		Set<Role> roles = new HashSet<Role>();
		roles.add(role);
		User user = Administrator.createNewAdministrator(RandomGenerator.randomString(), params.get(SAMLConstants.USER_ID), profile, roles, UserStatus.ACTIVE);
		userService.addUser(user);
		LOGGER.debug("Admin User Created");
		return user;
	}

	private User populateUser(final IdpUserToken token, BusinessEntity be,
			Map<String, String> params) {
		User user = null;
		PersonalProfile profile = PersonalProfile.createAndGetPersonalProfile("", "",params.get(SAMLConstants.FIRST_NAME),params.get(SAMLConstants.LAST_NAME), null, null,null, null);
		DraftUser draftUser = draftUserMongoRepository.findByIdentifier(resolveDraftUserIdentifier(token));
		if(draftUser == null){
			LOGGER.info("Draft Users can not be null .");
			
			LOGGER.debug("Creating Manager for NULL user");
			Set<Role> roles = roleService.getRoleByUserTypeAndIsDefaultAndStatus(be.getType(),true,RoleStatus.ACTIVE);
			user = Manager.createNewManager(RandomGenerator.randomString(), profile,roles );
			Set<String> managesBEofTypes = new HashSet<>();
			managesBEofTypes.add(be.getType());
			((Manager) user).setManagesBEofTypes(managesBEofTypes);
			((Manager) user).associate(be);
			user.setStatus(UserStatus.ACTIVE);
		}else{
			user = userManager.createAndGetUserUsingDraftUser(draftUser);
			user.setStatus(UserStatus.ACTIVE);
		}
		return user;
	}

	private String resolveDraftUserIdentifier(final IdpUserToken token) {
			//TODO create via factory
		Map<String, String> params = token.getParams();
		return params.get(SAMLConstants.EMAIL);
	}
	
	private BusinessEntity getBusinessEntityByExternalId(String beId,Set<String> beTypes) {
		LOGGER.debug("Getting BE for beId : {}", beId);
		SearchCriteria searchCriteria = SearchCriteria
				.createColumnSearchCriteria().addSingleValueCriteria(
						BusinessEntity.ExternalId, CriteriaOperator.EQUALS,
						beId);
		Page<BusinessEntity> bes = userService.fetchMatchingBEs(searchCriteria);
		if(null != bes){
			for (BusinessEntity businessEntity : bes) {
				LOGGER.debug("Matching against be {}", businessEntity.externalId());
				if (beTypes.contains(businessEntity.getType())) {
					LOGGER.debug("Mtached against be {}",
							businessEntity.externalId());
					return businessEntity;
				}

			}
		}
		return null;
	}

}
