package com.hcentive.billing.core.commons.service.core.security.dto;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.enumtype.UserStatus;
import com.hcentive.billing.core.commons.domain.enumtype.UserType;
import com.hcentive.billing.core.commons.dto.UserOperation;

/***
 * 
 * @author Prateek.Bansal DTO to add/update user of type Manager and
 *         Administrator
 * 
 */
public class UserDTO {

	private PersonalProfile personalProfile;
	private String identity;

	private UserType userType;

	// @Min(value = 10)
	private String userName;
	private String userId;
	// @Pattern(regexp =
	// "(?=[A-z0-9!@#$%^&*()]{8,20}$)(?=.*?[A-z])(?=.*?[!@#$%^&*()])(?=.*?\\d).*")
	private char[] password;
	private Set<String> roleIdentities;
	private Set<UserOperation> operationsPerformed;
	private String tenantId;
	private String enterpriseName;

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	private UserSearchDto userSearchDto;

	private String question1;
	private String answer1;

	private String question2;
	private String answer2;

	private String question3;
	private String answer3;

	private String question4;
	private String answer4;

	public String getQuestion1() {
		return question1;
	}

	public void setQuestion1(String question1) {
		this.question1 = question1;
	}

	public String getAnswer1() {
		return answer1;
	}

	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}

	public String getQuestion2() {
		return question2;
	}

	public void setQuestion2(String question2) {
		this.question2 = question2;
	}

	public String getAnswer2() {
		return answer2;
	}

	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}

	public String getQuestion3() {
		return question3;
	}

	public void setQuestion3(String question3) {
		this.question3 = question3;
	}

	public String getAnswer3() {
		return answer3;
	}

	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}

	public String getQuestion4() {
		return question4;
	}

	public void setQuestion4(String question4) {
		this.question4 = question4;
	}

	public String getAnswer4() {
		return answer4;
	}

	public void setAnswer4(String answer4) {
		this.answer4 = answer4;
	}

	public Map<String, String> getUserSecurityInfo() {
		Map<String, String> securityInfo = new HashMap<String, String>();
		if (null != this.question1)
			securityInfo.put(question1, answer1);
		if (null != this.question2)
			securityInfo.put(question2, answer2);
		if (null != this.question3)
			securityInfo.put(question3, answer3);
		if (null != this.question4)
			securityInfo.put(question4, answer4);
		return securityInfo;
	}

	// Only if user is Manager
	private Set<String> managesBEOfTypes;

	public Set<UserOperation> getOperationsPerformed() {
		return operationsPerformed;
	}

	private UserStatus userStatus;

	public UserStatus getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(UserStatus userStatus) {
		this.userStatus = userStatus;
	}

	public PersonalProfile getPersonalProfile() {
		return personalProfile;
	}

	public void setPersonalProfile(PersonalProfile personalProfile) {
		this.personalProfile = personalProfile;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		if (userName != null)
			this.userName = userName.trim();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public char[] getPassword() {
		return password;
	}

	public void setPassword(char[] password) {
		if (password != null)
			this.password = password.clone();
		else
			this.password = null;
	}

	public Set<String> getRoleIdentities() {
		return roleIdentities;
	}

	public void setRoleIdentities(Set<String> roleIdentities) {
		this.roleIdentities = roleIdentities;
	}

	public Set<String> getManagesBEOfTypes() {
		return managesBEOfTypes;
	}

	public void setManagesBEOfTypes(Set<String> managesBEOfTypes) {
		this.managesBEOfTypes = managesBEOfTypes;
	}

	public void setOperationsPerformed(Set<UserOperation> operationsPerformed) {
		this.operationsPerformed = operationsPerformed;
	}

	public void setUserSecurityQuestions(Map<String, String> securityInfo) {
		if (null == securityInfo)
			return;
		int i = 1;
		for (Map.Entry<String, String> entry : securityInfo.entrySet()) {
			switch (i) {
			case 1: {
				setQuestion1(entry.getKey());
				break;
			}
			case 2: {
				setQuestion2(entry.getKey());
				break;
			}
			case 3: {
				setQuestion3(entry.getKey());
				break;
			}
			}
			i++;

		}

	}

	public UserSearchDto getUserSearchDto() {
		if (null == userSearchDto)
			setUserSearchDto(new UserSearchDto());
		return userSearchDto;
	}

	public void setUserSearchDto(UserSearchDto userSearchDto) {
		this.userSearchDto = userSearchDto;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	 
	public void addManagesBEOfType(String type){
		if(this.managesBEOfTypes==null){
			this.managesBEOfTypes = new HashSet<>();
		}
		this.managesBEOfTypes.add(type);
	}

}
