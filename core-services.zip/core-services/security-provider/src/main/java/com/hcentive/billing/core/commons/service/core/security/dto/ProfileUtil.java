package com.hcentive.billing.core.commons.service.core.security.dto;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.ContactPerson;
import com.hcentive.billing.core.commons.domain.Email;
import com.hcentive.billing.core.commons.domain.OrgProfile;
import com.hcentive.billing.core.commons.domain.PersonalProfile;
import com.hcentive.billing.core.commons.domain.Profile;

public class ProfileUtil {
	
	public static Email populateEmailId(final Profile profile) {
		if (profile == null) {
			return null;
		}
		if (profile instanceof PersonalProfile) {
			return getEmailFromProfile(profile);
		} else if (profile instanceof OrgProfile) {
			if (profile.getContactPersons() == null) {
				return null;
			}
			for (ContactPerson contactPerson : profile.getContactPersons()
					.getContacts()) {
				if (contactPerson.isPrimary()) {
					Profile orgPrimaryProfile = contactPerson.getProfile();
					return getEmailFromProfile(orgPrimaryProfile);
				}
			}
		}
		return null;
	}
	
	private static Email getEmailFromProfile(Profile profile) {
		Set<Email> emails = (profile.getEmails() != null) ? profile.getEmails()
				.getContacts() : null;
		if (emails == null) {
			return null;
		}
		for (Email email : emails) {
			if (email.isPrimary()) {
				return email;
			}
		}
		return null;
	}

}
