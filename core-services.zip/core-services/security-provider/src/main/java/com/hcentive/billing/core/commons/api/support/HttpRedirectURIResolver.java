package com.hcentive.billing.core.commons.api.support;

import javax.servlet.http.HttpServletRequest;

public interface HttpRedirectURIResolver {
	public String resolve(HttpServletRequest request);

	public String protocol();
}
