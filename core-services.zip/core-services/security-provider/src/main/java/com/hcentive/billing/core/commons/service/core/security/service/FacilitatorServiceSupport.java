package com.hcentive.billing.core.commons.service.core.security.service;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.domain.Facilitator;
import com.hcentive.billing.core.commons.util.ServiceComm;
import com.hcentive.common.inter.service.annotation.InterService;
import com.hcentive.common.inter.service.annotation.InterServiceCall;

@InterService
public interface FacilitatorServiceSupport {

	@InterServiceCall(service = ServiceComm.BEM_FETCHBROKERBYNPNANDEXTID)
	IOU<Facilitator, AsyncCallback<Facilitator>> fetchByOwnerIdentity(String externalId, String npn);
}
