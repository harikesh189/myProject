package com.hcentive.billing.core.commons.service.core.security.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.RemoteLoginManager;

public class RemoteLoginManagerImpl implements RemoteLoginManager{
	@Autowired
	private AuthManager authManager;

	@Override
	public AccessToken doRemoteLoginForTrustedEntities(
			AnonymousUserIdentity anonymousUserIdentity) {
		return authManager.doRemoteLoginForTrustedEntities(anonymousUserIdentity);
	}
	
	
}
