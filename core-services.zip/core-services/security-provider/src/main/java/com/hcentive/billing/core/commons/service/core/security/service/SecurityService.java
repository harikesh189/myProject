package com.hcentive.billing.core.commons.service.core.security.service;

import org.apache.shiro.authc.AuthenticationInfo;

import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.AuthAccessToken;
import com.hcentive.billing.core.commons.security.Credential;
import com.hcentive.billing.core.commons.security.exception.AuthenticationFailed;

public interface SecurityService {
	public void logout();

	public AccessToken getAccessToken();

	public AccessToken login(final Credential credential)
			throws AuthenticationFailed;
	
	public AuthenticationInfo loginByPreConfiguredToken(AccessToken accessToken, AuthAccessToken authAccessToken);
	
}
