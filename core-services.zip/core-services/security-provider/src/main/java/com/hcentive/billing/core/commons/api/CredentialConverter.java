package com.hcentive.billing.core.commons.api;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.server.ServletServerHttpRequest;

import com.hcentive.billing.core.commons.api.support.IdpAdapterRegistry;
import com.hcentive.billing.core.commons.security.Credential;

public class CredentialConverter extends
		AbstractHttpMessageConverter<Credential> {

	private static final Logger logger = LoggerFactory
			.getLogger(CredentialConverter.class);

	@Autowired
	private IdpAdapterRegistry registry;

	@Override
	protected boolean supports(Class<?> clazz) {
		if (clazz != null && Credential.class.isInstance(clazz)) {
			return true;
		}
		return false;
	}

	@Override
	protected Credential readInternal(Class<? extends Credential> clazz,
			HttpInputMessage inputMessage) throws IOException,
			HttpMessageNotReadableException {
		logger.debug("inputMessage parsing starts here");
		ServletServerHttpRequest sshr = (ServletServerHttpRequest) inputMessage;
		logger.debug("Input Message Converted to ServletServerHttpRequest");
		final HttpServletRequest request = sshr.getServletRequest();
		final AuthMode authMode = RequestContext.get().clientAppIdpEnterpriseConfig()
				.getAuthMode();
		logger.debug("AuthMode : {}", authMode);
		switch (authMode) {
		case CAPTURE_CREDENTIALS: {
			return createUserCredential(request);
		}
		case CAPTURE_CREDENTIALS_FOR_SYSTEM_AUTH: {
			return createUserCredential(request);
		}
		default:
			return idpCredentials(request);
		}
	}

	@SuppressWarnings("unchecked")
	private Credential idpCredentials(HttpServletRequest request) {
		logger.debug("Creating Idp Credentials from request");
		return registry.getAdapter().parseIdpResponse(
				RequestContext.get().clientAppIdpEnterpriseConfig(),
				request.getParameterMap());
	}

	private Credential createUserCredential(final HttpServletRequest request) {
		logger.debug("Creating User Credentials from request");
		final String username = request.getParameter("username");
		logger.debug("Username : {}", username);
		final String password = request.getParameter("password");
		logger.debug("Credential of type UserName Created");
		return new UsernamePassword(username, password);
	}

	@Override
	protected void writeInternal(Credential t, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {
		// TODO Auto-generated method stub

	}

}
