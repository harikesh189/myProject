package com.hcentive.billing.core.commons.service.core.security.web.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.Credential;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;

@Deprecated
@RestController
@Scope("request")
@RequestMapping("/auth")
public class RestAuthController {

	private static final Logger logger = LoggerFactory
			.getLogger(RestAuthController.class);

	@Autowired
	private AuthManager authManager;

	@RequestMapping(method = RequestMethod.POST, value = "/login", produces = "application/json", consumes = "application/json")
	public AccessToken doRestAuthentication(
			@RequestBody final Credential userCredentials) throws Exception {
		logger.debug("Inside doRestAuthentication");
		if (null == userCredentials) {
			throw new Exception("Null credentials");
		}
		return authManager.doLogin(userCredentials);

	}
}
