package com.hcentive.billing.core.commons.service.core.security.service;

import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.AnonymousUserIdentity;
import com.hcentive.billing.core.commons.security.AuthAccessToken;
import com.hcentive.billing.core.commons.security.Credential;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.SystemUserOperation;
import com.hcentive.billing.core.commons.security.matcher.NonceMatcher;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.comm.support.ServiceRequestHandler;
import com.hcentive.billing.core.commons.tenant.mgmt.IgnoreTenantDuringProcessing;
import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.core.commons.util.ServiceComm;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * Manager class to facilitate authentication process.
 * 
 * @author ajay.saxena
 * 
 */
@Component
public class AuthManagerImpl implements AuthManager {

	private static final Logger logger = LoggerFactory
			.getLogger(AuthManagerImpl.class);

	@Autowired
	private SecurityService securityService;
	
	@Autowired
	AccessTokenService accessTokenService;
	
	@Autowired
	private NonceMatcher nonceMatcher;

	/*
	 * Method does the user authentication.If successful generates one time
	 * password , saves it in the caches and returns otp.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.hcentive.billing.core.commons.service.core.security.service.AuthManager
	 * #doLogin(java.lang.String, java.lang.String)
	 */
	@Override
	@IgnoreTenantDuringProcessing
	public AccessToken doLogin(final Credential credential) {
		final AccessToken accessToken = securityService.login(credential);
		return accessToken;
	}

	/*
	 * for input one time password , fetches access token from cache and returns
	 * the access token against the otp. (non-Javadoc)
	 * 
	 * @see
	 * com.hcentive.billing.core.commons.service.core.security.service.AuthManager
	 * #getAuthInfo(java.lang.String)
	 */
	@Override
	@RequiresPermissions(value = Permission.AUTH_MANAGEMENT)
	public AccessToken getAuthInfo(final String tokenIdentifier) {
		AccessToken accessToken = SecurityUtil.accessTokenManager().get(
				tokenIdentifier);
		return accessToken;
	}

	/*
	 * Logs out an loggedin user.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.hcentive.billing.core.commons.service.core.security.service.AuthManager
	 * #logout()
	 */
	@Override
	@IgnoreTenantDuringProcessing
	public void logout() {
		final AccessToken token = securityService.getAccessToken();
		this.nonceMatcher.clearNonce(token);		
		securityService.logout();
	}

	@Override
	@RequiresAuthentication
	public User fetchUser() {
		return Utils.getUser();
	}

	@Override
	@SystemUserOperation
	public AuthenticationInfo doLoginByPreConfiguredToken(
			String accessTokenId ,AuthAccessToken authAccessToken) {
		
		AccessToken accessToken = accessTokenService.getAccessTokenByIdentity(accessTokenId);
		if (accessToken == null) {
			logger.debug("Access Token not Found");
			return null;
		}
		ProcessContext.get().setTenantId(accessToken.getTenantId());
		return securityService.loginByPreConfiguredToken(accessToken,authAccessToken);
	}

	@Override
	@IgnoreTenantDuringProcessing
	public AccessToken doLoginForLoginTrustedEntity(final AnonymousUserIdentity anonymousUserIdentity) {
		AccessToken accessToken = doLoginForAnonymousUser(anonymousUserIdentity);
		return accessToken;
	}

	private AccessToken doLoginForAnonymousUser(
			final AnonymousUserIdentity anonymousUserIdentity) {
		final User user = Utils.getUser();
		AccessToken accessToken = null;
		if( user != null && user instanceof AnonymousUser){
				accessToken = Utils.getAccessToken();
		}else{
			accessToken = securityService.login(anonymousUserIdentity);
		}
		return accessToken;
	}
	
	@Override
	@IgnoreTenantDuringProcessing
	@ServiceRequestHandler(serviceName = ServiceComm.FETCH_ANONYMOUS_SLIDING_ACCESS_TOKEN)
	public AccessToken doRemoteLoginForTrustedEntities(final AnonymousUserIdentity anonymousUserIdentity) {
		AccessToken accessToken = doLoginForAnonymousUser(anonymousUserIdentity);
		return accessToken.encryptedAccessTokenCopy();
	}
	
	
}
