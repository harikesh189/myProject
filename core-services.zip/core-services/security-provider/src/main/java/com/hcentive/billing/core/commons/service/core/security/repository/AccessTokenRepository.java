package com.hcentive.billing.core.commons.service.core.security.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.security.DefaultAccessToken;


@Transactional
public interface AccessTokenRepository extends JpaRepository<DefaultAccessToken, Long> {

	public DefaultAccessToken findByIdentity(final String identity);

}
