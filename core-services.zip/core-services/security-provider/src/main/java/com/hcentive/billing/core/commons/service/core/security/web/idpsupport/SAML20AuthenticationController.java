package com.hcentive.billing.core.commons.service.core.security.web.idpsupport;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import java.util.Map;
import java.util.zip.DataFormatException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.impl.LogoutRequestImpl;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.XMLParserException;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.xml.sax.SAXException;

import com.hcentive.billing.core.commons.api.ClientAppIdpEnterpriseConfig;
import com.hcentive.billing.core.commons.api.ClientAppService;
import com.hcentive.billing.core.commons.api.IdpSamlConfiguration;
import com.hcentive.billing.core.commons.api.IdpUserIdentity;
import com.hcentive.billing.core.commons.api.RequestContext;
import com.hcentive.billing.core.commons.api.SessionContext;
import com.hcentive.billing.core.commons.api.support.SAMLResponseInterpreter;
import com.hcentive.billing.core.commons.domain.IdpUserCredential;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.TokenAssociator;
import com.hcentive.billing.core.commons.service.core.security.service.AuthManager;
import com.hcentive.billing.core.commons.service.core.security.service.IdpSamlConfigService;
import com.hcentive.billing.core.commons.service.core.security.service.UserCredentialsSevice;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.util.ClientAppToCookieNameMapping;
import com.hcentive.billing.core.commons.web.WebUtils;
import com.hcentive.billing.core.saml.AuthRequestBuilder;
import com.hcentive.billing.core.saml.LogoutRequestBuilder;
import com.hcentive.billing.core.saml.LogoutResponseBuilder;
import com.hcentive.billing.core.saml.LogoutResponseParserFactory;
import com.hcentive.billing.core.saml.SAMLConsumer;

@Controller
@RequestMapping("/security/{enterpriseName}/saml20BasedAuth")
public class SAML20AuthenticationController extends
		IdpAuthenticationProcesingController {

	private static final String SAML_REQUEST = "SAMLRequest";

	private static final String RELAY_STATE = "RelayState";
	
	@Autowired
	private AuthManager authManager;

	@Autowired
	private IdpSamlConfigService idpSamlConfigService;

	@Autowired
	private SAMLConsumer samlConsumer;

	@Autowired
	private SAMLResponseInterpreter samlResponseInterpreter;

	@Autowired
	private AuthRequestBuilder authRequestBuilder;

	@Autowired
	private LogoutRequestBuilder logoutRequestBuilder;

	@Autowired
	private UserCredentialsSevice credentialsSevice;
	
	@Autowired
	private LogoutResponseBuilder logoutResponseBuilder;
	
	@Autowired
	private LogoutResponseParserFactory logoutResponseParserFactory;
	
	@Autowired
	private ClientAppService clientAppService;
	
	@Value(value = "${security.cookie.secure:true}")
	private boolean isCookieSecure;

	private static final Logger logger = LoggerFactory
			.getLogger(SAML20AuthenticationController.class);

	@RequestMapping("/int/login")
	public ModelAndView login(final HttpServletRequest request) {
		logger.debug("In posting SAML to IDP");
		ModelAndView modelAndView = new ModelAndView("postSAMLToIdp");
		createSAMLView(request, modelAndView);
		return modelAndView;
	}

	private void createSAMLView(final HttpServletRequest request,
			ModelAndView modelAndView) {
		modelAndView.addObject(SAML_REQUEST, createAuthnRequest(request));
		String idpEndPoint = RequestContext.get()
				.clientAppIdpEnterpriseConfig().getIdpEndPoint();
		modelAndView.addObject("action", idpEndPoint);
		logger.debug("Going to hit idp : {} ", idpEndPoint);
		StringBuilder relayState = new StringBuilder();
		relayState.append(AuthWebUtil.getState(request) + "AND"
				+ AuthWebUtil.getCallBackUrl(request));
		logger.debug("Relay State : {} ", relayState);
		modelAndView.addObject(RELAY_STATE, relayState);
		logger.debug("Ending posting SAML to IDP");
	}

	@RequestMapping("/int/register")
	public ModelAndView register(final HttpServletRequest request) {
		logger.debug("In posting SAML to IDP");
		ModelAndView modelAndView = new ModelAndView("postSAMLToIdp");
		createSAMLView(request, modelAndView);
		return modelAndView;
	}

	private String createAuthnRequest(final HttpServletRequest request) {
		RequestContext requestContext = RequestContext.get();
		IdpSamlConfiguration idpSamlConfig = getSamlConfig();
		if (idpSamlConfig != null) {
			String baseUrl = WebUtils.getBaseUrl(request);
			return authRequestBuilder
					.forAssertionConsumerUrl(baseUrl+idpSamlConfig.getAssertionConsumerUrl())
					.toDestinationUrl(
							requestContext.clientAppIdpEnterpriseConfig()
									.getIdpEndPoint())
					.withCertPath(idpSamlConfig.getSpPublicCertPath())
					// SP public cert add in idp saml config
					.withKeyStorePassword(idpSamlConfig.getKeyStorePassword())
					.withKeyStorePath(idpSamlConfig.getKeyStorePath())
					.withPrivateKeyAlias(idpSamlConfig.getPrivateKeyAlias())
					.forIssuer(requestContext.clientAppIdpEnterpriseConfig().getIssuer()).build();
		} else {
			throw new IllegalStateException(
					"No SAML Config Found for identity provider :: "
							+ requestContext.identityProvider().getIdpKey());
		}

	}

	private IdpSamlConfiguration getSamlConfig() {
		return idpSamlConfigService.findByIdentityProvider(RequestContext.get()
				.identityProvider());
	}

	@RequestMapping("/response/{client_id}/{idpKey}")
	public String doAuthentication(final HttpServletRequest request)
			throws CertificateException, NoSuchAlgorithmException,
			InvalidKeySpecException, ConfigurationException,
			XMLParserException, UnmarshallingException, IOException,
			SAXException, ValidationException, SAMLException {
		logger.debug("Getting SAML Response ");
		String samlResponse = request.getParameter("SAMLResponse");
		
		logger.debug("SAML Response Found :: {}", samlResponse);
		Map<String, String> attributesMap = samlConsumer.consumeResponse(
				samlResponse, getSamlConfig().getIdpPublicCertPath());
		logger.debug("SAML Response Consumed");
		final IdpUserIdentity idpUserIdentity = samlResponseInterpreter
				.interpret(attributesMap);
		logger.debug("idpUserIdentity created");
		AuthWebUtil.attachCredential(request, idpUserIdentity);
		logger.debug("Credentials Attached");
		String relayState = request.getParameter(RELAY_STATE);
		logger.debug("Relay State Recieved : {}", relayState);
		String[] relayParams = null;
		if (relayState != null) {
			logger.debug("Splitting Relay Params");
			relayParams = relayState.split("AND");
			logger.debug("Relay Params Splitted");
		}
		if (relayParams != null) {
			logger.debug("State {} And CallBackURL {}", relayParams[0],
					relayParams[1]);
			AuthWebUtil.attachStateAndCallBackUrl(request, relayParams[0],
					relayParams[1]);
			logger.debug("Forwarding to :: {}", relayParams[1]);
			return "forward:" + relayParams[1];
		}
		return null;

	}

	private void processLogoutInternal(String enterprise,String idpKey,final HttpServletRequest request,final HttpServletResponse response) {
		logger.debug("Looking for config for enterprise: {} and idpKey: {}",enterprise,idpKey);
		final List<ClientAppIdpEnterpriseConfig> clientAppIdpEnterpriseConfigs = clientAppService
				.findClientAppEnterpriseIdpConfigsByIdp(enterprise, idpKey);
		final Map<String, String> sessionParams = WebUtils
				.getCookiesFromRequest(request);
		for (ClientAppIdpEnterpriseConfig clientAppIdpEnterpriseConfig : clientAppIdpEnterpriseConfigs) {
			final String appKey = clientAppIdpEnterpriseConfig.getClientApp().getAppKey();
			logger.debug("Looking for cookie identifier for appKey: {}",appKey);
			final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(appKey);
			final String cookieKey = SessionContext
					.sessionIdentifierKey()+cookieIdentifier;
			final String tokenId = WebUtils.decryptTokenId(sessionParams.get(cookieKey));
			logger.debug("TokenId found: {}",tokenId);
			if(null != tokenId){
				final TokenAssociator associator = SecurityUtil
						.tokenAssociator();
				logger.debug("Associating Token for tokenId: {}",tokenId);
				associator.associateToken(tokenId);
				authManager.logout();
				clearCookie(request, response, cookieKey, tokenId);
				logger.debug("Successful logout");
			}
		}
		SessionContext.clear();
	}

	private void clearCookie(final HttpServletRequest request,
			final HttpServletResponse response, final String cookieKey,
			final String tokenId) {
		Cookie cookie = new Cookie(cookieKey,  tokenId);
		cookie.setHttpOnly(true);
		cookie.setSecure(isCookieSecure);
		cookie.setMaxAge(0);
		cookie.setPath("/");
		cookie.setDomain("." + request.getServerName());
		response.addCookie(cookie);
	}
	
	@RequestMapping("/logout/response/{client_id}/{idpKey}")
	public String doLogout( @PathVariable("enterpriseName") final String enterpriseName,@PathVariable("idpKey") final String idpKey,
			final HttpServletRequest request,final HttpServletResponse response) throws CertificateException, NoSuchAlgorithmException,
	InvalidKeySpecException, ConfigurationException,
	XMLParserException, UnmarshallingException, IOException,
	SAXException, ValidationException, SAMLException, DataFormatException {
		logger.debug("Logout Response Recieved");
		
		String samlResponse = request.getParameter("SAMLResponse");
		
		if(null == samlResponse){
			samlResponse = request.getParameter("SAMLRequest");
		}
		final Object obj = logoutResponseParserFactory.parseLogoutResponse(samlResponse);
		
		if(obj instanceof LogoutRequestImpl){
			processLogoutInternal(enterpriseName,idpKey,request,response);
			
			final LogoutRequestImpl logoutRequest = (LogoutRequestImpl)obj;
			
			IdpSamlConfiguration idpSamlConfig = getSamlConfig();
			
			final String logoutResponse = logoutResponseBuilder
					.inResponseTo(logoutRequest.getID())
					.forConsent(logoutRequest.getConsent())
					.forIssuer(WebUtils.getBaseUrl(request))
					.withCertPath(idpSamlConfig.getSpPublicCertPath())
					.toDestinationUrl(
							RequestContext.get().clientAppIdpEnterpriseConfig()
									.getLogoutIdpEndPoint())
					.withKeyStorePassword(idpSamlConfig.getKeyStorePassword())
					.withKeyStorePath(idpSamlConfig.getKeyStorePath())
					.withPrivateKeyAlias(idpSamlConfig.getPrivateKeyAlias())
					.forIssuer(WebUtils.getBaseUrl(request))
					.build();
			request.setAttribute("logoutResponse", logoutResponse);
			return "forward:/security/"+enterpriseName+"/saml20BasedAuth/int/logoutResponse";
			
		}
		
		String relayState = request.getParameter(RELAY_STATE);
		logger.debug("Relay State Recieved : {}", relayState);
		String[] relayParams = null;
		if (relayState != null) {
			logger.debug("Splitting Relay Params");
			relayParams = relayState.split("AND");
			logger.debug("Relay Params Splitted");
		}
		if (relayParams != null) {
			logger.debug("State {} And CallBackURL {}", relayParams[0],
					relayParams[1]);
			AuthWebUtil.attachStateAndCallBackUrl(request, relayParams[0],
					relayParams[1]);
			logger.debug("Forwarding to :: {}", relayParams[1]);
			return "forward:" + relayParams[1];
		}
		return "forward:/security/"+enterpriseName+"/oAuth2/int/logout";
	}

	
	@RequestMapping("/int/logoutResponse")
	public ModelAndView sendLogoutResponse(final HttpServletRequest request) {
		logger.debug("In posting SAML Logout Request to IDP");
		ModelAndView modelAndView = new ModelAndView("postLogoutResponse");
		String logoutResponse = (String) request.getAttribute("logoutResponse");
		modelAndView.addObject("SAMLResponse", logoutResponse);
		String logoutIdpEndPoint = RequestContext.get()
				.clientAppIdpEnterpriseConfig().getLogoutIdpEndPoint();
		modelAndView.addObject("action", logoutIdpEndPoint);
		logger.debug("Going to hit idp for logout process : {} ",
				logoutIdpEndPoint);
		return modelAndView;
	}

	@RequestMapping("/int/logout")
	public ModelAndView logout(final HttpServletRequest request) {
		logger.debug("In posting SAML Logout Request to IDP");
		ModelAndView modelAndView = new ModelAndView("postSAMLToIdp");

		// Create Single Logout Request

		modelAndView.addObject(SAML_REQUEST, createLogoutRequest(request));
		String logoutIdpEndPoint = RequestContext.get()
				.clientAppIdpEnterpriseConfig().getLogoutIdpEndPoint();
		modelAndView.addObject("action", logoutIdpEndPoint);
		logger.debug("Going to hit idp for logout process : {} ",
				logoutIdpEndPoint);
		StringBuilder relayState = new StringBuilder();
		relayState.append(AuthWebUtil.getState(request) + "AND"
				+ AuthWebUtil.getCallBackUrl(request));
		logger.debug("Relay State : {} ", relayState);
		modelAndView.addObject(RELAY_STATE, relayState);
		logger.debug("Ending posting SAML Logout Request to IDP");
		return modelAndView;
	}

	private String createLogoutRequest(final HttpServletRequest request) {
		logger.debug("Creating Logout Request");
		RequestContext requestContext = RequestContext.get();
		IdpSamlConfiguration idpSamlConfig = getSamlConfig();
		logger.debug("SAML Config Found for IDP : {}", idpSamlConfig);
		final String userId = AuthWebUtil.getState(request);
		final IdpUserCredential idpUserCredential = credentialsSevice
				.findByUserId(Long.parseLong(userId));
		if (idpUserCredential == null) {
			logger.debug(
					"IDP User Credential not found for the logout request for user Id : {}",
					userId);
			throw new IllegalAccessError(
					"No idpUserCredential found for logout request for user Id :"
							+ userId);
		}
		if (idpSamlConfig != null) {
			logger.debug("Getting Session Params");
			final Map<String, String> sessionParams = AuthWebUtil
					.sessionParams(request);
			return logoutRequestBuilder
					.forIdpUserIdentity(idpUserCredential.getIdpUserIdentity())
					.forSessionIndex(
							sessionParams != null ? sessionParams
									.get("idpSessionIdentifier") : null)
					.withCertPath(idpSamlConfig.getSpPublicCertPath())
					.toDestinationUrl(
							requestContext.clientAppIdpEnterpriseConfig()
									.getLogoutIdpEndPoint())
					// SP public cert add in idp saml config
					.withKeyStorePassword(idpSamlConfig.getKeyStorePassword())
					.withKeyStorePath(idpSamlConfig.getKeyStorePath())
					.withPrivateKeyAlias(idpSamlConfig.getPrivateKeyAlias())
					.forIssuer(WebUtils.getBaseUrl(request))
					.build();
		} else {
			throw new IllegalStateException(
					"No SAML Config Found for identity provider :: "
							+ requestContext.identityProvider().getIdpKey());
		}

	}

	@Override
	public String loginEndpointToForwardForProcessing() {
		return "saml20BasedAuth/int/login";
	}

	@Override
	public String identity() {
		return "SAML2.0";
	}

	@Override
	public String logoutEndpointToForwardForProcessing() {
		return "saml20BasedAuth/int/logout";
	}

	@Override
	public String registrationEndpointToForwardForProcessing() {
		return "saml20BasedAuth/int/register";
	}

}
