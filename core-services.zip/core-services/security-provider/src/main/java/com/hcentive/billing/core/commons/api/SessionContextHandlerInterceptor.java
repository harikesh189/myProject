package com.hcentive.billing.core.commons.api;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.hcentive.billing.core.commons.api.support.HttpRedirectURIResolverSupport;
import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.SessionManager;
import com.hcentive.billing.core.commons.security.TokenAssociator;
import com.hcentive.billing.core.commons.util.AuthWebUtil;
import com.hcentive.billing.core.commons.util.ClientAppToCookieNameMapping;
import com.hcentive.billing.core.commons.web.WebUtils;


public class SessionContextHandlerInterceptor extends HandlerInterceptorAdapter {


	private static final Logger logger = LoggerFactory
			.getLogger(SessionContextHandlerInterceptor.class);

	@Value(value = "${security.ignore.current.request.path:default}")
	private String ignoreCurrentRequestPaths;

	@Value(value = "${security.cookie.secure:true}")
	private boolean isCookieSecure;

	protected boolean ignoreCurrentRequest(final ServletRequest request) {
		return WebUtils
				.ignoreCurrentRequest(request, ignoreCurrentRequestPaths);
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		final String path = ((HttpServletRequest) request).getRequestURI();
		if (!ignoreCurrentRequest(request)
				&& (path.contains("/security")) ){
			final Map<String, String> sessionParams = WebUtils
					.getCookiesFromRequest(request);
			final String cookieIdentifier = ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(RequestContext.get().clientApp().getAppKey());
			final String tokenId = WebUtils.decryptTokenId(sessionParams.get(SessionContext
					.sessionIdentifierKey()+cookieIdentifier));

			final SessionContext sc = SessionContext.initialize();
			sc.addAllCookies(sessionParams);
			if (tokenId != null) {
				try {
					logger.debug("Got tokenId {} from cookie.",tokenId);
					final TokenAssociator associator = SecurityUtil
							.tokenAssociator();
					associator.associateToken(tokenId);
					AuthWebUtil.populateSessionContext(tokenId,RequestContext.get().clientApp().getAppKey());
					// if correctly associated, we should be able to get the
					// current
					// logged in user.
					final SessionManager tokenManager = SecurityUtil
							.sessionManager();
					final User user = tokenManager.getCurrentUser();
					if (user != null && !(user instanceof AnonymousUser) && furtherProcessingRequired(request)) {
						// we have an idenfiable user. The user is already
						// logged in the
						// system. No need for further
						// checking. return with a result.
						AccessToken accessToken = SecurityUtil
								.accessTokenManager().get(tokenId);
						String redirectUri = getRedirectUri(request,
								accessToken);
						response.sendRedirect(redirectUri);
						return false;
					}
				} catch (Exception e) {
					logger.warn("Failed to Associate");
				}
			} else {
				logger.debug("Got null token id");
			}
		}
		return true;
	}

	private boolean furtherProcessingRequired(HttpServletRequest request) {
		if (request.getRequestURI().contains("logout") || request.getRequestURI().contains("error")) {
			return false;
		}
		return true;
	}

	private String getRedirectUri(HttpServletRequest request,
			AccessToken accessToken) {
		String redirectUri = HttpRedirectURIResolverSupport.INSTANCE
				.getRedirectURI(request);
		
		return WebUtils.getBaseUrl(request)+"/"+WebUtils.replaceEnterprise(WebUtils.resolve(request, 2), redirectUri);
	}

	@SuppressWarnings("static-access")
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

		populateCookieFromSessionContext(response, request);
		SessionContext.get().clear();

	}

	private void populateCookieFromSessionContext(HttpServletResponse response,
			HttpServletRequest request) {
		final SessionContext sc = SessionContext.get();
		RequestContext requestContext = RequestContext.get();
		String cookieIdentifier = null;
		if(null != requestContext){
			cookieIdentifier = BillingConstant.COOKIE_SID+ClientAppToCookieNameMapping.clientAppToCookieNameMap.get(requestContext.clientApp().getAppKey());
		}
		 
		if (sc != null) {
			final Map<String, String> params = sc.cookies();
			for (Map.Entry<String, String> entry : params.entrySet()) {
				Cookie cookie = new Cookie(entry.getKey(),  entry.getValue());
				cookie.setHttpOnly(true);
				cookie.setSecure(isCookieSecure);
				if(sc.invalidSession()){
					if(cookieIdentifier.equals(entry.getKey()))
						cookie.setMaxAge(0);
				}
				cookie.setPath("/");
				cookie.setDomain("." + request.getServerName());
				response.addCookie(cookie);
			}

		}
	}

}
