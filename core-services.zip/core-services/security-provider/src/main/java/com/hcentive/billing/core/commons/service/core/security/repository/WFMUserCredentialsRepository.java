package com.hcentive.billing.core.commons.service.core.security.repository;

import java.util.List;

import com.hcentive.billing.core.commons.api.domain.WFMUserCredentials;


public interface WFMUserCredentialsRepository extends
		UserCredentialsRepository<WFMUserCredentials> {

	public WFMUserCredentials getByUserNameIgnoreCase(String username);

	public WFMUserCredentials getByUserNameIgnoreCaseAndIdpKeyAndEnterpriseName(String username,
			String idpKey,String enterpriseName);
	
	public List<WFMUserCredentials> getByUserTenantInfoIdentityAndEnterpriseName(String identity, String enterpriseName);
	
	public WFMUserCredentials getByUserNameIgnoreCaseAndEnterpriseName(String username,String enterpriseName);
	

}
