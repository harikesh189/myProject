package com.hcentive.billing.core.commons.service.core.security.repository;

import com.hcentive.billing.core.commons.domain.IdpUserCredential;


public interface IdpUserCredentialRepository extends
		UserCredentialsRepository<IdpUserCredential> {

	public IdpUserCredential findByIdpUserIdentityAndIdpKeyAndEnterpriseName(
			final String idpUserIdentity, final String idpKey, final String enterpriseName);
	
	public IdpUserCredential findByUserTenantInfoId(final Long id);

}
