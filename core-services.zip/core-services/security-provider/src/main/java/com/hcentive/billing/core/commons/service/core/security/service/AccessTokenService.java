package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.Map;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.DefaultAccessToken;
import com.hcentive.billing.core.commons.vo.DateTime;

public interface AccessTokenService {

	public AccessToken getAccessTokenByIdentity(final String identity);

	public DefaultAccessToken createFixedAccessToken(final String appkey);

	public void persistToken(DefaultAccessToken accessToken);
	
	public AccessToken createAnonymousFixedVaueToken(final DateTime validTill, final String tenantId, final Set<Permission> permissions,final Map<String,String> tokenAttributes);

}
