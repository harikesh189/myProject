package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.subject.SubjectContext;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.User;
import com.hcentive.billing.core.commons.domain.audit.AuditEventType;
import com.hcentive.billing.core.commons.domain.audit.AuditMessageDefinition;
import com.hcentive.billing.core.commons.domain.audit.AuditWorkStatus;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousAccessToken;
import com.hcentive.billing.core.commons.security.AnonymousFixedValueToken;
import com.hcentive.billing.core.commons.security.AnonymousSlidingAccessToken;
import com.hcentive.billing.core.commons.security.AnonymousUser;
import com.hcentive.billing.core.commons.security.AuthAccessToken;
import com.hcentive.billing.core.commons.security.Credential;
import com.hcentive.billing.core.commons.security.SecurityUtil;
import com.hcentive.billing.core.commons.security.exception.AuthenticationFailed;
import com.hcentive.billing.core.commons.security.shiro.SessionManagement;
import com.hcentive.billing.core.commons.security.shiro.ShiroAuthenticationTokenBuilderRegistry;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.dto.LoginDetails;
import com.hcentive.billing.core.commons.service.ebill.audit.handler.AuditUtil;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;

/**
 * @author ajay.saxena
 * 
 */
@Component
public class ShiroAuthenticationService implements SecurityService {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ShiroAuthenticationService.class);
	
	@Autowired
	private UserService userService;

	@Autowired
	private ShiroAuthenticationTokenBuilderRegistry shiroAuthenticationTokenBuilderRegistry;

	private User getUser(final Subject subject) {
		if (subject != null && subject.isAuthenticated()) {
			LOGGER.debug("the subject is " + subject.getPrincipal().toString()
					+ "authenticated");
			PrincipalCollection principalCollection = subject.getPrincipals();
			final User user = (User) principalCollection.oneByType(User.class);
			return user;
		}
		return null;
	}

	private void onAuthenticationSuccess(final User user, final String username) {
		Event<LoginDetails> event = new Event<LoginDetails>("login",
				new LoginDetails(user.getIdentity(), new DateTime(new Date())));
		EventUtils.publish(event);
	}

	private void loadAuthorizationInfo(final Subject subject) {
		try {
			subject.checkPermission("DUMMY");
		} catch (AuthorizationException ae) {
			LOGGER.debug("Loaded AuthorizationInfo for user:{}",
					getUser(subject).getIdentity());
		}
	}

	private void authenticate(final Credential credential, final Subject subject) {
		LOGGER.info("Authenticating usertoken {}", credential.userIdentity());

		final AuthenticationToken authToken = shiroAuthenticationTokenBuilderRegistry
				.getShiroAuthenticationTokenBuilder(credential.getClass())
				.build(credential);
		subject.login(authToken);
		subject.getSession(false);
		LOGGER.info("Authenticated usertoken {} and created session",
				credential.userIdentity());
	}

	private boolean alreadyAuthenticated(final String username,
			final Subject subject) {
		if (subject.isAuthenticated()) {
			LOGGER.info("{} is already authenticated or remembered.", username);
			final String principal = (String) subject.getPrincipal();
			if (!username.equals(principal)) {
				LOGGER.error(
						"{} is already authenticated or remembered but with different credentials.",
						username);
				throw new AuthenticationFailed(
						username,
						"Attempt to re-login into an already logged in session, with different credentials.",
						null);
			}
		}
		return false;
	}

	@Override
	//@RequiresPermissions(value = Permission.AUTH_MANAGEMENT)
	public AccessToken login(final Credential credential)
			throws AuthenticationFailed {
		if (credential != null && credential.userIdentity() != null) {
			String userIdentity = credential.userIdentity();
			userIdentity = userIdentity.intern();// This is a bit dangerous.
			synchronized (userIdentity) {
				try {
					LOGGER.info("Authenticating: {}", userIdentity);
					final SubjectContext context = new DefaultSubjectContext();
					context.setAuthenticated(false);
					context.setSessionCreationEnabled(false);
					final Subject subject = SecurityUtils.getSecurityManager()
							.createSubject(context);
					if (!alreadyAuthenticated(userIdentity, subject)) {
						authenticate(credential, subject);
						loadAuthorizationInfo(subject);
					}
					//onAuthenticationSuccess(getUser(subject), userIdentity);
					return (AccessToken) subject.getPrincipals().oneByType(
							AccessToken.class);
				} catch (Throwable ae) {
					LOGGER.error("Authenticaion Failed", ae);
					throw new AuthenticationFailed(userIdentity,
							"AuthenticationFailed", null);
				}
			}
		}
		throw new AuthenticationFailed(credential, "Null Fields", null);
	}

	@Override
	@RequiresUser
	//@RequiresPermissions(value = Permission.AUTH_MANAGEMENT)
	public void logout() {
		User user = Utils.getUser();
		String userId = user.getIdentity();
		final Subject subject = SecurityUtils.getSubject();
		final String principal = (String) subject.getPrincipal();
		final AccessToken token = Utils.getAccessToken();
		final boolean isAnonymousToken = isAnonymousToken(token);
		subject.logout();
		LOGGER.info("Logged out {}", principal);
		onLogoutSuccess(userId,isAnonymousToken, user);
	}

	private boolean isAnonymousToken(final AccessToken token) {
		boolean isAnonymousToken = false;
		//Logout auditing for non anonymous events
		if(token instanceof AnonymousFixedValueToken || token instanceof AnonymousSlidingAccessToken){
			isAnonymousToken = true;
		}
		return isAnonymousToken;
	}

	private void onLogoutSuccess(String userId,final boolean isAnonymousToken,User user) {
//		EventUtils.publish(new Event<LoginDetails>(EventType.LOGOUT,
//				new LoginDetails(userId, new DateTime(new Date()))));
		publishAuditEvent(userId, isAnonymousToken,user);
	}

	private void publishAuditEvent(String userId, 
			final boolean isAnonymousToken, User user) {
		if(!isAnonymousToken){
			LOGGER.debug("Firing the audit for user logout service");
			ProcessContext.get().acknowledgeTenantDuringProcessing();
			
			LOGGER.debug("Audit for user display name :-",user);
			LOGGER.debug("Audit for user display name :-",user.getProfile().getDisplayName());
			
			String displayName = "";
			if(null != user.getProfile() && null != user.getProfile().getDisplayName()){
				displayName = user.getProfile().getDisplayName();
			}
			
			LOGGER.debug("Audit for user display name [{}] , user identity [{}] ,tenanat [{}]",displayName,user.getIdentity(),ProcessContext.get().getTenantId());
			if(ProcessContext.get() !=null && ProcessContext.get().getUserName() == null){
				LOGGER.debug("Setting user name");
				ProcessContext.get().setUserName(displayName);
			}
				
			
			AuditUtil.audit(AuditEventType.USER, AuditWorkStatus.SUCCESS, "",
					userId, "", "", AuditMessageDefinition.USER_LOGGED_OUT, "username",displayName);
			ProcessContext.get().ignoreTenantDuringProcessing();
			LOGGER.debug("Fired the audit for user logout service");
		}
	}

	@Override
	public AccessToken getAccessToken() {
		return SessionManagement.getSessionAttribute(Utils.ACCESS_TOKEN);
	}

	@Override
	public AuthenticationInfo loginByPreConfiguredToken(AccessToken accessToken, AuthAccessToken authAccessToken) {
		LOGGER.debug("Getting User");
		User user = userService
				.getUserById(accessToken.getUserIdentity());
		LOGGER.debug("Pushing access token in cache");
		SecurityUtil.accessTokenManager().update(accessToken);
		authAccessToken.associateAccessToken(accessToken);
		LOGGER.debug("Returning from FetchAccessTokenByTokenIdHandler");
		return loadAuthenticationInfo(authAccessToken, accessToken, user);
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private AuthenticationInfo loadAuthenticationInfo(
			final AuthAccessToken token, final AccessToken accessToken,
			User user) {
		final String realmName = this.getClass().getName();
		LOGGER.debug("Creating SimplePrincipalCollection");
		final SimplePrincipalCollection principalCollection = new SimplePrincipalCollection(
				token.getPrincipal(), realmName);
		LOGGER.debug("Created SimplePrincipalCollection");
		Collection principals = new ArrayList();
		principals.add(accessToken);
		if(accessToken instanceof AnonymousAccessToken && user == null){
			user = new AnonymousUser();
		}
		principals.add(user);
		principalCollection.addAll(principals, realmName);
		LOGGER.debug("Returning from Authentication Info");
		return new SimpleAuthenticationInfo(principalCollection,
				token.getCredentials());
	}

}
