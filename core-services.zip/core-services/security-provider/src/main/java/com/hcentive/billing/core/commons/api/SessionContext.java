package com.hcentive.billing.core.commons.api;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicBoolean;

import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.security.config.CommonSecurityServiceConfig.BillingAuthrizationAdviceInterceptor;

public class SessionContext {

	public static final ThreadLocal<SessionContext> THREAD_LOCAL_SESSION_CONTEXT = new ThreadLocal<SessionContext>();

	private final Map<String, String> cookieParams = new HashMap<String, String>();

	private final AtomicBoolean sessionInvalidated = new AtomicBoolean(true);

	public Map<String, String> cookies() {
		return cookieParams;
	}

	public void addCookie(final String param, final String paramValue) {
		this.cookieParams.put(param, paramValue);
	}

	public void addAllCookies(Map<String, String> params) {
		if (params != null) {
			for (Entry<String, String> entry : params.entrySet()) {
				this.cookieParams.put(entry.getKey(), entry.getValue());
			}
		}
	}

	public String getCookieValue(final String param) {
		return this.cookieParams.get(param);
	}

	public void removeCookie(final String param) {
		this.cookieParams.remove(param);
	}

	private SessionContext() {
	}

	public static SessionContext get() {
		return THREAD_LOCAL_SESSION_CONTEXT.get();
	}

	public static SessionContext initialize() {
		THREAD_LOCAL_SESSION_CONTEXT.set(new SessionContext());
		return get();
	}

	public static void clear() {
		THREAD_LOCAL_SESSION_CONTEXT.remove();
	}

	public static String sessionIdentifierKey() {
		return BillingConstant.COOKIE_SID;
	}

	public void invalidateSession() {
		this.sessionInvalidated.set(true);
	}

	public void validSession() {
		this.sessionInvalidated.set(false);
	}

	public boolean invalidSession() {
		return this.sessionInvalidated.get();
	}
}
