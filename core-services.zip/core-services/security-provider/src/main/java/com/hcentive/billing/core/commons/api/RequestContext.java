package com.hcentive.billing.core.commons.api;

public class RequestContext {

	public static final ThreadLocal<RequestContext> THREAD_LOCAL_REQUEST_CONTEXT = new ThreadLocal<RequestContext>();

	private final ClientAppIdpEnterpriseConfig clientAppIdpEnterpriseConfig;
	private final boolean usingDefaultEnterprise;

	private RequestContext(final ClientAppIdpEnterpriseConfig clientAppIdpEnterpriseConfig,boolean usingDefaultEnterprise) {
		this.clientAppIdpEnterpriseConfig = clientAppIdpEnterpriseConfig;
		this.usingDefaultEnterprise = usingDefaultEnterprise;
	}

	public static void clear() {
		THREAD_LOCAL_REQUEST_CONTEXT.remove();
	}

	public static RequestContextInitializer initializer(
			ClientAppIdpEnterpriseConfig clientAppIdpEnterpriseConfig) {
		return new RequestContextInitializer(clientAppIdpEnterpriseConfig);
	}
	
	public static RequestContextInitializer initializer() {
		return new RequestContextInitializer();
	}


	public static class RequestContextInitializer {
		private ClientAppIdpEnterpriseConfig clientAppIdpEnterpriseConfig;
		private boolean usingDefaultEnterprise = false;
		protected RequestContextInitializer(
				ClientAppIdpEnterpriseConfig clientAppIdpEnterpriseConfig) {
			this();
			this.clientAppIdpEnterpriseConfig = clientAppIdpEnterpriseConfig;
		}
		
		protected RequestContextInitializer(){
			
		}
		public RequestContextInitializer withConfig(ClientAppIdpEnterpriseConfig config){
			this.clientAppIdpEnterpriseConfig = config;
			return this;
		}
		public RequestContextInitializer usingDefaultEnterprise(){
			this.usingDefaultEnterprise = true;
			return this;
		}

		public RequestContext initialize() {
			RequestContext.initialize(clientAppIdpEnterpriseConfig,usingDefaultEnterprise);
			RequestContext context = RequestContext.get();
			return context;
		}
	}

	public static RequestContext get() {
		return THREAD_LOCAL_REQUEST_CONTEXT.get();
	}

	private static RequestContext initialize(
			ClientAppIdpEnterpriseConfig clientAppIdpConfig, boolean usingDefaultEnterprise) {
		final RequestContext rc = new RequestContext(clientAppIdpConfig,usingDefaultEnterprise);
		THREAD_LOCAL_REQUEST_CONTEXT.set(rc);
		return rc;
	}

	public ClientApp clientApp() {
		return this.clientAppIdpEnterpriseConfig.getClientApp();
	}

	public IdentityProvider identityProvider() {
		return this.clientAppIdpEnterpriseConfig.getIdentityProvider();
	}
	
	public EnterpriseImpl enterprise() {
		return this.clientAppIdpEnterpriseConfig.getEnterprise();
	}


	public ClientAppIdpEnterpriseConfig clientAppIdpEnterpriseConfig() {
		return clientAppIdpEnterpriseConfig;
	}
	public boolean usingDefaultEnterprise(){
		return this.usingDefaultEnterprise;
	}
}
