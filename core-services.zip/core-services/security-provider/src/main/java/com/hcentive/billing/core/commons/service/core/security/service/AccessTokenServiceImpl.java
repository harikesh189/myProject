package com.hcentive.billing.core.commons.service.core.security.service;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcentive.billing.core.commons.domain.ClientUser;
import com.hcentive.billing.core.commons.domain.Permission;
import com.hcentive.billing.core.commons.security.AccessToken;
import com.hcentive.billing.core.commons.security.AnonymousFixedValueToken;
import com.hcentive.billing.core.commons.security.DefaultAccessToken;
import com.hcentive.billing.core.commons.security.FixedValueToken;
import com.hcentive.billing.core.commons.security.shiro.Utils;
import com.hcentive.billing.core.commons.service.core.security.repository.AccessTokenRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.ClientUserRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.RoleInfoRepository;
import com.hcentive.billing.core.commons.service.core.security.repository.UserRepository;
import com.hcentive.billing.core.commons.tenant.util.TenantUtil;
import com.hcentive.billing.core.commons.vo.DateTime;

@Service
public class AccessTokenServiceImpl implements AccessTokenService {

	private static final Logger logger = LoggerFactory
			.getLogger(AccessTokenServiceImpl.class);

	@Autowired
	private AccessTokenRepository accessTokenRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ClientUserRepository clientUserRepository;
	
	@Autowired
	private RoleInfoRepository roleInfoRepository;

	@Override
	public AccessToken getAccessTokenByIdentity(final String identity) {
		logger.debug("Fetching Access Token for token ID : {}", identity);
		return accessTokenRepository.findByIdentity(identity);
	}

	@Override
	// @RequiresPermissions(value = Permission.CREATE_FIXED_VALUE_TOKEN)
	public DefaultAccessToken createFixedAccessToken(final String appkey) {
		logger.debug("create fixed accessToken request recieved");
		if (appkey == null || appkey.isEmpty()) {
			logger.debug("appkey is missing");
		}
		ClientUser clientUser = clientUserRepository.findByAppKey(appkey);

		final DefaultAccessToken fixedValueToken = new FixedValueToken(
				Utils.generateKey(), Utils.generateKey(),
				clientUser.getIdentity(), TenantUtil.getTenantId(),
				new HashSet<Permission>(clientUser.permissions()),null);
		accessTokenRepository.save(fixedValueToken);
		logger.debug("fixedvalueAccessToken saved");
		return fixedValueToken;
	}
	
	@Override
	public AccessToken createAnonymousFixedVaueToken(final DateTime validTill, final String tenantId, final Set<Permission> permissions, final Map<String,String> tokenAttributes){
		if(permissions == null || permissions.size() == 0){
			logger.error("Illegal Access : No permissions found." );
			throw new IllegalStateException("Illegal Access : No permissions found.");
		}
		final DefaultAccessToken anonymousFixedValueToken = new AnonymousFixedValueToken(Utils.generateKey(), Utils.generateKey(), null, tenantId, permissions, validTill,tokenAttributes);
		accessTokenRepository.save(anonymousFixedValueToken);
		return anonymousFixedValueToken.encryptedAccessTokenCopy();
	}

	@Override
	public void persistToken(DefaultAccessToken accessToken) {
		accessTokenRepository.save(accessToken);
		logger.debug("fixedvalueAccessToken saved");
	}

}
