package com.hcentive.billing.core.commons.service.core.security.dto;

import java.util.Set;

public class RoleDTO {

	private String userType;
	private String roleName;
	private String roleDesc;
	private String roleCode;
	private String identity;
	private Set<String> permissionIds;
	private boolean isDefault;
	private String status;
	

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public Set<String> getPermissionIds() {
		return permissionIds;
	}

	public void setPermissionIds(Set<String> permissionIds) {
		this.permissionIds = permissionIds;
	}
}
