package com.hcentive.billing.core;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.security.config.AutoConfigureSecurity;
import com.hcentive.billing.core.commons.service.core.security.service.AnonymousUserRealm;
import com.hcentive.billing.core.commons.service.core.security.service.BillingDataRealm;
import com.hcentive.billing.core.commons.service.core.security.service.ClientUserRealm;
import com.hcentive.billing.core.commons.service.core.security.service.IdpUserRealm;

@Configuration
public class AutoConfigureSecureRealms extends AutoConfigureSecurity {
	
	@Autowired
	private BillingDataRealm billingDataRealm;

	@Autowired
	private IdpUserRealm idpUserRelam;

	@Autowired
	private ClientUserRealm clientUserRealm;
	
	@Autowired
	private AnonymousUserRealm anonymousUserRealm;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	protected Collection getRealms() {
		final Collection realms = super.getRealms();
		realms.add(billingDataRealm);
		realms.add(idpUserRelam);
		realms.add(clientUserRealm);
		realms.add(anonymousUserRealm);
		return realms;
	}

}
