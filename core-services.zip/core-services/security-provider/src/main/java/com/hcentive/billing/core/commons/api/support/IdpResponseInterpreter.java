package com.hcentive.billing.core.commons.api.support;

import java.util.Map;

import com.hcentive.billing.core.commons.api.IdpUserIdentity;

public interface IdpResponseInterpreter<I extends IdpUserIdentity> {

	public I interpret(final Map<String, String> attributesMap);

	public String identity();

}
