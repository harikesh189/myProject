/**
 * 
 */
package com.hcentive.billing.core.commons.service.core.security;

import org.junit.Assert;
import org.junit.Test;

import com.hcentive.billing.core.commons.util.EncryptionUtil;

/**
 * @author Kumar Sambhav Jain
 * 
 */
public class PasswordEncryptTest {

	@Test
	public void test() {
		String encryptedPassword = EncryptionUtil
				.oneWayEncryptString("password");
		Assert.assertNotNull(encryptedPassword);
		Assert.assertTrue(EncryptionUtil.oneWayCheckPassword("password",
				encryptedPassword));
	}
}
