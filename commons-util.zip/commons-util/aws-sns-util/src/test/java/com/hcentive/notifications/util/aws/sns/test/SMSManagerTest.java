/**
 * 
 */
package com.hcentive.notifications.util.aws.sns.test;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.hcentive.billing.notifications.util.aws.sns.ClasspathPropertyLookUpSNSConfigurer;
import com.hcentive.billing.notifications.util.aws.sns.SMSManager;

/**
 * @author Kumar Sambhav Jain
 * 
 */
public class SMSManagerTest {

	@Autowired
	private AmazonSNSClient amazonSNSClient;

	/**
	 * Test method for
	 * {@link com.hcentive.billing.notifications.util.aws.sns.SNSManager#publishMessage(java.lang.String, java.lang.String)}
	 * .
	 */
	// @Test
	public void testPublishMessage() {
		SMSManager smsManager = new SMSManager(
				new ClasspathPropertyLookUpSNSConfigurer());
		try{
		smsManager.sendSMS(8527543244L, "Message1");
		smsManager.sendSMS(+918527543244L, "Message2");
		}
		catch(Exception e){
			System.out.println(e);
		}
		System.out.println(smsManager);
	}

	@Test
	public void testClient() {/*
							 * AmazonSNSClient amazonSNSClient = new
							 * AmazonSNSClient( new
							 * BasicAWSCredentials("AKIAJX3PEBXU4NXQXGQQ",
							 * "BsTFNF35TVaXWKlzdxioPndSEhd3kTrrhc/PTXse"));
							 * CreateTopicResult topic =
							 * amazonSNSClient.createTopic("smsTopic"); String
							 * topicArn = topic.getTopicArna(); PublishRequest
							 * publishRequest = new PublishRequest(topicArn,
							 * "Test Message", "918527543244"); PublishResult
							 * publish =
							 * amazonSNSClient.publish(publishRequest);
							 * Assert.assertNotNull(topic);
							 */
	}
}
