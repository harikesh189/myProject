package com.hcentive.billing.notifications.util.aws.sns;

/**
 * 
 * @author Kumar Sambhav Jain
 * 
 */
public interface SNSConfigProvider {
	/**
	 * 
	 * @return
	 */
	SNSConfig getSNSConfig();
}
