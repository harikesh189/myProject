package com.hcentive.billing.notifications.util.aws.sns;

import static com.hcentive.billing.core.commons.concurrent.Executors.newSingleThreadExecutor;

import java.util.List;
import java.util.concurrent.ExecutorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.CreateTopicRequest;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sns.model.ListSubscriptionsByTopicRequest;
import com.amazonaws.services.sns.model.ListSubscriptionsByTopicResult;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.amazonaws.services.sns.model.SetTopicAttributesRequest;
import com.amazonaws.services.sns.model.SubscribeRequest;
import com.amazonaws.services.sns.model.Subscription;

public abstract class SNSManager {

	private static final String AWS_SNS_POOL = "AWS-SNS-Pool";

	private static final Logger LOGGER = LoggerFactory.getLogger(SNSManager.class);

	protected static final String SMS = "sms";
	private static final String SEPARATOR = ":";
	private static final String ARN_AWS_SNS = "arn:aws:sns:";

	private static final String PENDING_CONFIRMATION = "PendingConfirmation";
	protected final SNSConfigProvider snsConfigProvider;
	protected final SNSCredentialsProvider snsCredentialsProvider;
	protected ExecutorService executors;
	protected AmazonSNSClient client;

	public SNSManager(final SNSManagerConfigurer configurer) {
		this(configurer, configurer);
	}

	public SNSManager(SNSConfigProvider snsConfigProvider, SNSCredentialsProvider snsCredentialsProvider) {
		super();
		this.snsConfigProvider = snsConfigProvider;
		this.snsCredentialsProvider = snsCredentialsProvider;
		if (this.snsConfigProvider == null || this.snsCredentialsProvider == null) {
			throw new SNSException("All fields are mandatory.");
		}
		init();
		LOGGER.info("SNSManager configuration done.");
	}

	private void init() {
		LOGGER.info("Initializing SMSManager.");
		try {
			this.executors = newSingleThreadExecutor(AWS_SNS_POOL);
			LOGGER.info("Initialized ThreadPool.");
			client = new AmazonSNSClient(snsCredentialsProvider.getCredentials());
			LOGGER.info("Initialized AmazonSNSClient.");
		} catch (final Throwable t) {
			LOGGER.error("Failed to intialize SMSManager", t);
		}
	}

	protected final String getTopicArn(final String msisdn) {
		final SNSConfig config = snsConfigProvider.getSNSConfig();
		return ARN_AWS_SNS + config.region().getName() + SEPARATOR + config.accountIdentity() + SEPARATOR + "BI" + msisdn;
	}

	protected final void createTopic(final String topicName) {
		LOGGER.debug("Creating topic for msisdn : {}", topicName);
		final CreateTopicRequest createTopicRequest = new CreateTopicRequest("BI" + topicName);
		final CreateTopicResult createTopicResult = client.createTopic(createTopicRequest);
		LOGGER.debug("Created topic for msisdn : {}", topicName);
		final String topicArn = createTopicResult.getTopicArn();
		LOGGER.debug("Created topic with ARN : {}", topicArn);
		final String displayName = snsConfigProvider.getSNSConfig().displayNameForSMS();
		final SetTopicAttributesRequest setDisplayNameRequest = new SetTopicAttributesRequest(topicArn, "DisplayName", displayName);
		client.setTopicAttributes(setDisplayNameRequest);
		LOGGER.debug("Added DisplayName {} to topic {} ", displayName, topicArn);
	}

	protected final void publishMessage(final String topicName, final String message) throws Exception {
		try {
			LOGGER.debug("Sending sms to msisdn: {}", topicName);
			final String topicArn = getTopicArn(topicName);
			final PublishRequest publishRequest = new PublishRequest();
			publishRequest.setTopicArn(topicArn);
			publishRequest.setMessage(message);
			final PublishResult publishResult = client.publish(publishRequest);
			LOGGER.debug("PublishResult messageid {}", publishResult.getMessageId());
		} catch (final Throwable t) {
			LOGGER.error("Error during sending sms to msisdn: {}", topicName, t);
			throw new Exception(t);
		}
		LOGGER.debug("Sent sms to msisdn: {}", topicName);
	}

	protected final void subscribeToTopic(final String subscriberId, final String topicArn) {
		LOGGER.debug("Sending Subscription Request for subscriberId: {}", subscriberId);
		final SubscribeRequest subscribeRequest = new SubscribeRequest(topicArn, SMS, snsConfigProvider.getSNSConfig().countryISDCode()
		        + subscriberId.toString());
		client.subscribe(subscribeRequest);
		LOGGER.debug("Sent Subscription Request for subscriberId: {}", subscriberId);
	}

	protected final boolean checkSubscritionConfirmation(final String topicARN) {
		LOGGER.debug("checking Subscription Request for topic ARN {}", topicARN);
		final List<Subscription> subscriptionList = getSubscriptionList(topicARN);
		if (subscriptionList != null && !subscriptionList.get(0).getSubscriptionArn().equals(PENDING_CONFIRMATION)) {
			return true;
		} else {
			return false;
		}
	}

	private List<Subscription> getSubscriptionList(String subscriptionTopic) {
		final ListSubscriptionsByTopicRequest listSubscriptionsByTopicRequest = new ListSubscriptionsByTopicRequest(subscriptionTopic);
		final ListSubscriptionsByTopicResult res = client.listSubscriptionsByTopic(listSubscriptionsByTopicRequest);
		return res.getSubscriptions();
	}

}
