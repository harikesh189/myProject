package com.hcentive.billing.notifications.util.aws.sns;

import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;

public class ClasspathPropertyLookUpSNSConfigurer extends PropertyFileLoaderSNSConfigurer {
	private static final Logger LOGGER = LoggerFactory.getLogger(ClasspathPropertiesFileCredentialsProvider.class);

	public ClasspathPropertyLookUpSNSConfigurer() {
		loadFromClassPath();
	}

	public void loadFromClassPath() {
		LOGGER.trace("Loading properties from classPath:{}", DEFAULT_FILE_NAME);
		try {
			final InputStream is = getClass().getResourceAsStream("/" + "" + DEFAULT_FILE_NAME);
			loadProperties(is);
			LOGGER.trace("Loaded properties from classPath:{}", DEFAULT_FILE_NAME);
		} catch (final Exception e) {
			LOGGER.error("Could not load file from classPath:{}", DEFAULT_FILE_NAME, e);
			throw new SNSException("Could not load file from classPath: " + DEFAULT_FILE_NAME, e);
		}

	}

	public static final String DEFAULT_FILE_NAME = "AwsCredentials.properties";

}
