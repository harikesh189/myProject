package com.hcentive.billing.notifications.util.aws.sns;

public interface SNSManagerConfigurer extends SNSCredentialsProvider,
		SNSConfigProvider {

}
