package com.hcentive.billing.notifications.util.aws.sns;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.regions.Regions;

@Component
public class SpringPropertyLookUpSNSConfigurer implements SNSManagerConfigurer {

	public static final String ACCESS_KEY = "aws.accessKey";
	public static final String SECRET_KEY = "aws.secretKey";
	public static final String REGION = "aws.region";
	public static final String ROOT_TOPIC = "aws.sns.rootTopic";
	public static final String ACCOUNT_IDENTITY = "aws.accountId";
	public static final String SMS_DISPLAY_NAME = "aws.sns.sms.displayName";
	public static final String COUNTRY_ISD_CODE = "aws.sns.sms.countryIsdCode";

	@Value("${aws.accessKey}")
	private String accessKey;
	@Value("${aws.secretKey}")
	private String secretKey;
	@Value("${aws.sns.rootTopic}")
	private String rootTopic;
	@Value("${aws.region}")
	private String region;
	@Value("${aws.accountId}")
	private String awsAccountIdentity;
	@Value("${aws.sns.sms.displayName}")
	private String smsDisplayName;
	@Value("${aws.sns.sms.countryIsdCode}")
	private String countryISDCode;

	@Override
	public AWSCredentials getCredentials() throws SNSException {
		return new SNSCredentials(accessKey, secretKey);
	}

	@Override
	public SNSConfig getSNSConfig() {
		final SNSConfig snsConfig = new SNSConfig();
		snsConfig.setRootTopic(rootTopic).setRegion(Regions.fromName(region))
				.setAccountIdentity(awsAccountIdentity);
		if(countryISDCode==null){
			countryISDCode="1";
		}
		snsConfig.setDisplayNameForSMS(smsDisplayName).setCountryISDCode(
				countryISDCode);
		return snsConfig;
	}

	protected final void setAwsAccountIdentity(String awsAccountIdentity) {
		this.awsAccountIdentity = awsAccountIdentity;
	}

	protected final void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	protected final void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	protected final void setRootTopic(String rootTopic) {
		this.rootTopic = rootTopic;
	}

	protected final void setRegion(String region) {
		this.region = region;
	}

	protected final void setSmsDisplayName(String smsDisplayName) {
		this.smsDisplayName = smsDisplayName;
	}
	public void setCountryISDCode(String countryISDCode) {
		this.countryISDCode = countryISDCode;
	}
}
