/**
 * 
 */
package com.hcentive.billing.notifications.util.aws.sns.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sns.AmazonSNSClient;

/**
 * @author Kumar Sambhav Jain
 * 
 */
@Configuration
@PropertySource(value = { "classpath:AwsCredentials.properties" }, ignoreResourceNotFound = false)
public class AwsSnsConfiguration {

	@Value("${aws.accessKey}")
	private String accessKey;

	@Value("${aws.secretKey}")
	private String secretKey;

	@Value("${aws.sns.rootTopic}")
	private String rootTopic;

	@Value("${aws.region}")
	private String region;

	@Value("${aws.accountId}")
	private String awsAccountIdentity;

	@Value("${aws.sns.sms.displayName}")
	private String smsDisplayName;

	@Value("${aws.sns.sms.countryIsdCode}")
	private String countryISDCode;

	@Bean
	public AmazonSNSClient amazonSNSClient() {
		AmazonSNSClient amazonSNSClient = new AmazonSNSClient(
				new BasicAWSCredentials(accessKey, secretKey));
		return amazonSNSClient;
	}
}
