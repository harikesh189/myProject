package com.hcentive.billing.notifications.util.aws.sns;

import com.amazonaws.auth.AWSCredentials;

/**
 * 
 * @author BAM
 * 
 */
public interface SNSCredentialsProvider {

	/**
	 * getCredentials
	 * 
	 * @return {@link AWSCredentials}
	 * @throws SNSException
	 */
	AWSCredentials getCredentials() throws SNSException;

}
