package com.hcentive.billing.notifications.util.aws.sns;

public class SNSException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3271665744028969803L;

	public SNSException(String arg0) {
		super(arg0);
	}

	public SNSException(Throwable arg0) {
		super(arg0);
	}

	public SNSException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
}
