package com.hcentive.billing.notifications.util.aws.sns;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyFileLoaderSNSConfigurer extends
		SpringPropertyLookUpSNSConfigurer {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(PropertyFileLoaderSNSConfigurer.class);

	protected PropertyFileLoaderSNSConfigurer() {

	}

	public static PropertyFileLoaderSNSConfigurer createNew(
			final String filePath) {
		PropertyFileLoaderSNSConfigurer configurer = new PropertyFileLoaderSNSConfigurer();
		configurer.loadProperties(filePath);
		return configurer;
	}

	protected void loadProperties(final String propertyFilePath) {
		LOGGER.info("Loading properties from file : {}", propertyFilePath);

		try {
			final InputStream is = new FileInputStream(propertyFilePath);
			loadProperties(is);
		} catch (FileNotFoundException e) {
			LOGGER.error("Unable to load file {}", propertyFilePath, e);
			throw new SNSException("Unable to load file " + propertyFilePath, e);
		} catch (IOException e) {
			LOGGER.error("Unable to load file {}", propertyFilePath, e);
			throw new SNSException("Unable to load file " + propertyFilePath, e);
		}
	}

	protected void loadProperties(final InputStream is) throws IOException {
		final Properties properties = new Properties();
		properties.load(is);
		setAccessKey(properties.getProperty(ACCESS_KEY));
		setSecretKey(properties.getProperty(SECRET_KEY));
		setRegion(properties.getProperty(REGION));
		setRootTopic(properties.getProperty(ROOT_TOPIC));
		setAwsAccountIdentity(properties.getProperty(ACCOUNT_IDENTITY));
		setSmsDisplayName(properties.getProperty(SMS_DISPLAY_NAME));
		setCountryISDCode(properties.getProperty(COUNTRY_ISD_CODE));
	}
}
