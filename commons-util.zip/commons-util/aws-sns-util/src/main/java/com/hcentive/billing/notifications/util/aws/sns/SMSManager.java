package com.hcentive.billing.notifications.util.aws.sns;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SMSManager extends SNSManager {
	static final Logger LOGGER = LoggerFactory.getLogger(SMSManager.class);

	public SMSManager(final SNSManagerConfigurer configurer) {
		this(configurer, configurer);
	}

	public SMSManager(SNSConfigProvider snsConfigProvider,
			SNSCredentialsProvider snsCredentialsProvider) {
		super(snsConfigProvider, snsCredentialsProvider);
		LOGGER.info("SNSManager configuration done.");
	}

	public void subscribe(final Long msisdn) {
		if (msisdn != null) {
			final Runnable r = new Runnable() {
				@Override
				public void run() {
					createTopicAndSubscribe(msisdn);
				}
			};
			executors.submit(r);
		}
	}

	public void sendSMS(final Long msisdn, final String message) throws Exception {
		if (msisdn != null && message != null) {
			/*
			 * final Runnable r = new Runnable() {
			 * 
			 * @Override public void run() {
			 */
			publishMessage(msisdn.toString(), message);
			/*
			 * } };
			 */
		}
	}

	public boolean checkSMSSubscriptionConfirmation(final Long msisdn) {
		return checkSubscritionConfirmation(getTopicArn(msisdn.toString()));
	}
	
	private String createTopicAndSubscribe(final Long msisdn) {
		String subscribeResult = null;
		try {
			createTopic(msisdn.toString());
			subscribeToTopic(msisdn.toString(), getTopicArn(msisdn.toString()));
			LOGGER.debug("Sent Subscription Request for msisdn: {}", msisdn);
		} catch (Throwable t) {
			LOGGER.error("Error during Subscription Request for msisdn: {}",
					msisdn, t);
		}
		return subscribeResult;
	}
}
