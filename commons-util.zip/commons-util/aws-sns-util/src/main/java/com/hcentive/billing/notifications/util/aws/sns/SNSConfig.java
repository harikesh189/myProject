package com.hcentive.billing.notifications.util.aws.sns;

import com.amazonaws.regions.Regions;

public class SNSConfig {
	private static final Regions DEFAULT_REGION = Regions.US_EAST_1;

	private String rootTopic;
	private String accountIdentity;
	private Regions region;
	private String displayNameForSMS;
	private String countryISDCode;

	public SNSConfig() {
		region = DEFAULT_REGION;
	}

	protected String countryISDCode() {
		return countryISDCode;
	}

	protected SNSConfig setCountryISDCode(String countryISDCode) {
		this.countryISDCode = countryISDCode;
		return this;
	}

	protected final String rootTopic() {
		return rootTopic;
	}

	protected final SNSConfig setRootTopic(String rootTopic) {
		this.rootTopic = rootTopic;
		return this;
	}

	protected final Regions region() {
		return region;
	}

	protected final SNSConfig setRegion(Regions region) {
		this.region = region;
		return this;
	}

	protected final String accountIdentity() {
		return accountIdentity;
	}

	protected final SNSConfig setAccountIdentity(String accountIdentity) {
		this.accountIdentity = accountIdentity;
		return this;
	}

	protected final String displayNameForSMS() {
		return displayNameForSMS;
	}

	protected final SNSConfig setDisplayNameForSMS(String displayNameForSMS) {
		this.displayNameForSMS = displayNameForSMS;
		return this;
	}

}
