package com.hcentive.billing.notifications.util.aws.sns;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;

/**
 * @see BasicAWSCredentials
 * @author BAM
 * 
 */
class SNSCredentials implements AWSCredentials {

	private final String awsAccessKey;
	private final String awsSecretKey;

	protected SNSCredentials(final String awsAccessKey,
			final String awsSecretKey) {
		super();
		this.awsAccessKey = awsAccessKey;
		this.awsSecretKey = awsSecretKey;
	}

	@Override
	public String getAWSAccessKeyId() {
		return this.awsAccessKey;
	}

	@Override
	public String getAWSSecretKey() {
		return this.awsSecretKey;
	}

}
