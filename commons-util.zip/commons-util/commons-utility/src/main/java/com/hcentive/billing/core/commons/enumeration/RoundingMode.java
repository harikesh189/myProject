package com.hcentive.billing.core.commons.enumeration;

public enum RoundingMode {
	DAY_START, DAY_END
}
