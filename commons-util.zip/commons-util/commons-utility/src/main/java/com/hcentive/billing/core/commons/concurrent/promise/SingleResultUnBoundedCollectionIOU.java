package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.Collection;

public class SingleResultUnBoundedCollectionIOU<O> extends AbstractUnBoundedCollectionIOU<Collection<O>, AsyncCallback<Collection<O>>, O> {

	public SingleResultUnBoundedCollectionIOU(final Collection<O> collectionToCollectInto) {
		super(new SingleResultCollector<O>(collectionToCollectInto));
	}

	public SingleResultUnBoundedCollectionIOU(final SingleResultCollector<O> singleResultCollector) {
		super(singleResultCollector);
	}
}
