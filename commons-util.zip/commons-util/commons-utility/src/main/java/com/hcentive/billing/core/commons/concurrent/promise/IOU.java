package com.hcentive.billing.core.commons.concurrent.promise;

/**
 * 
 * I Owe You.<br>
 * 
 * Analogous to Future or promise object.
 * 
 * @author BAM
 * 
 * @param <O>
 */
public interface IOU<O, A extends AsyncCallback<O>> {

	/**
	 * Return the processing result, null in case the processing is still in
	 * progress. Non-Blocking in nature.
	 * 
	 * @return
	 */
	public O get();

	/**
	 * Sets the callback to be invoked on completion of processing or on error.
	 * Callback is immediately invoked if processing has been completed or an
	 * error has already occurred.
	 * 
	 * @param callback
	 */
	public void set(A callback);

	/**
	 * Return the processing error if any, null in case the processing is still
	 * in progress. Non-Blocking in nature.
	 * 
	 * @return
	 */
	public <T extends Throwable> T getError();

	/**
	 * returns false is processing is still pending or ongoing.
	 * 
	 * @return
	 */
	public boolean isCompleted();

	public boolean hasError();

}
