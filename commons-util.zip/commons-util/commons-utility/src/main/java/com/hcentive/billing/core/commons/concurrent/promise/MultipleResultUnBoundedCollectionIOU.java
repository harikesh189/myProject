package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.Collection;

public class MultipleResultUnBoundedCollectionIOU<O> extends AbstractUnBoundedCollectionIOU<Collection<O>, AsyncCallback<Collection<O>>, Collection<O>> {

	public MultipleResultUnBoundedCollectionIOU(final Collection<O> collectionToCollectInto) {
		super(new MultipleResultCollector<O>(collectionToCollectInto));
	}
}
