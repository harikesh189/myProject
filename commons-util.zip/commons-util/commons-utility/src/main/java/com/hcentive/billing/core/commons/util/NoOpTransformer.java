package com.hcentive.billing.core.commons.util;

public class NoOpTransformer<E> implements ITransformer<E, E> {

	@Override
	public E transform(final E input) {
		return input;
	}

	public static final <E> NoOpTransformer<E> getInstance() {
		return new NoOpTransformer<E>();
	}
}
