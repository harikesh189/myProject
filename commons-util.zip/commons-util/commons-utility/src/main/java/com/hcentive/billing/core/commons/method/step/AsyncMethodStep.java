package com.hcentive.billing.core.commons.method.step;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;

public abstract class AsyncMethodStep<SD, O> extends MethodStep<SD> implements AsyncCallback<O> {

	private static final Logger LOGGER = LoggerFactory.getLogger(AsyncMethodStep.class);
	
	public AsyncMethodStep(final SD sharedData, final MethodStep<SD> nextStep) {
		super(sharedData, nextStep);
	}

	@Override
	public void onSuccess(final O result) {
		this.onSuccessExecute(result);
		this.executeNextStep();
	}

	@Override
	public void execute() {
		final IOU<O, AsyncCallback<O>> iou = this.makeAsyncCall();
		iou.set(this);
	}

	public abstract void onSuccessExecute(O result);

	public abstract IOU<O, AsyncCallback<O>> makeAsyncCall();

	@Override
	public void onError(final Throwable t) {
		LOGGER.error("Error executing async method step", t);
		throw new RuntimeException(t);
	}
}
