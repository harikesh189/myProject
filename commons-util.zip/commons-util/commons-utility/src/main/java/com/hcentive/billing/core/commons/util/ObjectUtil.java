package com.hcentive.billing.core.commons.util;

/**
 * Contains utility methods for working with {@link Object}s.
 */
public final class ObjectUtil {
	/**
	 * Prevent instantiation.
	 */
	private ObjectUtil() {
	}

	/**
	 * Determines whether two objects are equal, ensuring that a
	 * {@link NullPointerException} is not thrown.
	 * 
	 * @param first
	 *            The first {@link Object} to compare.
	 * @param second
	 *            The second {@link Object} to compare.
	 * @return {@code true} if both {@code first} and {@code second} are
	 *         {@code null} or equal, {@code false} otherwise.
	 */
	public static final boolean areEqual(final Object first, final Object second) {
		if (first == second) {
			return true;
		}

		if (first != null) {
			if (second != null && !first.getClass().equals(second.getClass())) {
				return false;
			}
			return first.equals(second);
		}
		return false;
	}

	/**
	 * Determines whether two objects are not equal, ensuring that a
	 * {@link NullPointerException} is not thrown.
	 * 
	 * @param first
	 *            The first {@link Object} to compare.
	 * @param second
	 *            The second {@link Object} to compare.
	 * @return {@code true} if {@code first} and {@code second} are unequal,
	 *         {@code false} otherwise.
	 */
	public static final boolean areNotEqual(final Object first,
			final Object second) {
		return !areEqual(first, second);
	}

	/**
	 * Determines whether all the objects are not null.
	 * 
	 * @param objects
	 *            The array of objects to tested.
	 * @return <p>
	 *         {@code true} if all the objects in the array are not null.
	 *         </p>
	 *         <p>
	 *         {@code false} otherwise.
	 *         </p>
	 */
	public static final boolean areNotNull(final Object... objects) {
		if (objects == null || objects.length == 0) {
			return false;
		}
		for (final Object object : objects) {
			if (object == null) {
				return false;
			}
		}
		return true;
	}
}
