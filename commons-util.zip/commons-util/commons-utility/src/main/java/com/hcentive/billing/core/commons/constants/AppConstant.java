package com.hcentive.billing.core.commons.constants;

public class AppConstant {

	public static final String KEY_FOR_SERVICE_NAME = "KEY_FOR_SERVICE_NAME";

	public static final String KEY_FOR_ID = "ID_KEY";

	public static final String KEY_FOR_TENANT_ID = "tenantId";

}
