package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.Collection;

public class SimpleCollectionIOU<O, A extends AsyncCallback<Collection<O>>> extends ResultCollectionIOU<Collection<O>, A, O> {

	public SimpleCollectionIOU(final Collection<O> collectionToCollectInto, final int resultCount) {
		super(new SingleResultCollector<O>(collectionToCollectInto), resultCount);
	}
}
