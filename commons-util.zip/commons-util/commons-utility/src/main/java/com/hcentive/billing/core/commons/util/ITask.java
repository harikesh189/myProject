package com.hcentive.billing.core.commons.util;

public interface ITask<K> {
	void execute(K input);
}
