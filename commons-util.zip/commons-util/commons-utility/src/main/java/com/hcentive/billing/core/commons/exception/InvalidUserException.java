package com.hcentive.billing.core.commons.exception;

public class InvalidUserException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8812245570203031574L;
	private final String errorCode;
	private final String errorMessage;
	private final String description;

	public InvalidUserException(String errorCode, String errorMessage,
			String description) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.description = description;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public String getDescription() {
		return description;
	}

}
