package com.hcentive.billing.core.commons.concurrent.promise;

public interface ResultCollector<R, CR> {
	void collect(R result);

	CR collectedResult();

	/**
	 * Return the number of results collected so far.
	 * @return
	 */
	public int size();
}