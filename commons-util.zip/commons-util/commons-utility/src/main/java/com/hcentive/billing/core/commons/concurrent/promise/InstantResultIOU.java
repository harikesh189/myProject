package com.hcentive.billing.core.commons.concurrent.promise;

public class InstantResultIOU<O, A extends AsyncCallback<O>> extends DefaultIOU<O, A> {

	public InstantResultIOU(O result) {
		super();
		setResult(result);
	}
	
	private InstantResultIOU(){
		
	}
	public static <R, C extends AsyncCallback<R>> InstantResultIOU<R,C> createIOUForResult(final R result){
		return new InstantResultIOU<R, C>(result);
	}
	
	public static <R, C extends AsyncCallback<R>> InstantResultIOU<R,C> createIOUForError(final Throwable throwable){
		InstantResultIOU<R, C> iou = new InstantResultIOU<R, C>();
		iou.setError(throwable);
		return iou;
	}
}
