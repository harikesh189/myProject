package com.hcentive.billing.core.commons.exception;

public interface ErrorCode {
	String name();
}
