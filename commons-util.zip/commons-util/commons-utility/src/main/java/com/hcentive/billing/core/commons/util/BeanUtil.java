package com.hcentive.billing.core.commons.util;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.FatalBeanException;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

public abstract class BeanUtil extends BeanUtils {

	/**
	 * It performs the deep copy of entity including collection within it.
	 * 
	 * @param target
	 * @param source
	 * @return
	 */
	public static <S> S copy(S target, S source) {

		return copy(target, source, true);
	}

	public static <S> S copy(S target, S source, boolean deepCopyEnable) {

		final Class<?> actualEditable = source.getClass();
		final PropertyDescriptor[] targetPds = BeanUtils
				.getPropertyDescriptors(actualEditable);

		for (final PropertyDescriptor targetPd : targetPds) {
			final Method writeMethod = targetPd.getWriteMethod();

			if (writeMethod != null) {
				final PropertyDescriptor sourcePd = BeanUtils
						.getPropertyDescriptor(source.getClass(),
								targetPd.getName());
				if (sourcePd != null) {
					final Method readMethod = sourcePd.getReadMethod();
					if (readMethod != null
							&& ClassUtils.isAssignable(
									writeMethod.getParameterTypes()[0],
									readMethod.getReturnType())) {
						try {
							if (!Modifier.isPublic(readMethod
									.getDeclaringClass().getModifiers())) {
								readMethod.setAccessible(true);
							}
							final Object value = getCopy(
									readMethod.invoke(source),
									targetPd.getPropertyType(), deepCopyEnable);
							if (!Modifier.isPublic(writeMethod
									.getDeclaringClass().getModifiers())) {
								writeMethod.setAccessible(true);
							}
							writeMethod.invoke(target, value);

						} catch (final Throwable ex) {
							throw new FatalBeanException(
									"Could not copy property '"
											+ targetPd.getName()
											+ "' from source to target", ex);
						}
					}
				}
			}
		}
		return target;
	}

	@SuppressWarnings({ "unchecked" })
	public static <S> S getCopy(final S source) {

		Assert.notNull(source, "Source must not be null");

		S target = null;
		try {
			target = (S) Class.forName(source.getClass().getName())
					.newInstance();
		} catch (InstantiationException | IllegalAccessException
				| ClassNotFoundException e) {
			throw new RuntimeException("Failed to create an instance of "
					+ source.getClass().getName());
		}
		copy(target, source);
		return target;
	}

	private static Collection<?> getCollectionCopy(
			final Collection<?> srcCollectionElements,
			final Class<?> targetCollectionType) {
		if (Set.class.isAssignableFrom(targetCollectionType)) {
			return new HashSet<>(srcCollectionElements);
		} else if (List.class.isAssignableFrom(targetCollectionType)) {
			return new ArrayList<>(srcCollectionElements);
		}
		return null;
	}

	private static Object getCopy(final Object sourceValue,
			final Class<?> targetType, boolean deepCopyEnable) {
		if (!Collection.class.isAssignableFrom(targetType) || !deepCopyEnable) {
			return sourceValue;
		}
		return getCollectionCopy((Collection<?>) sourceValue, targetType);
	}

	public static <S> S copyRDE(S target, S source, boolean deepCopyEnable) {

		final Class<?> actualEditable = source.getClass();
		final PropertyDescriptor[] targetPds = BeanUtils
				.getPropertyDescriptors(actualEditable);

		for (final PropertyDescriptor targetPd : targetPds) {
			if (targetPd.getName().equals("identity")
					|| targetPd.getName().equals("id")
					|| targetPd.getName().equals("auditInfo"))
				continue;
			final Method writeMethod = targetPd.getWriteMethod();

			if (writeMethod != null) {
				final PropertyDescriptor sourcePd = BeanUtils
						.getPropertyDescriptor(source.getClass(),
								targetPd.getName());
				if (sourcePd != null) {
					final Method readMethod = sourcePd.getReadMethod();
					if (readMethod != null
							&& ClassUtils.isAssignable(
									writeMethod.getParameterTypes()[0],
									readMethod.getReturnType())) {
						try {
							if (!Modifier.isPublic(readMethod
									.getDeclaringClass().getModifiers())) {
								readMethod.setAccessible(true);
							}
							final Object value = getCopy(
									readMethod.invoke(source),
									targetPd.getPropertyType(), deepCopyEnable);
							if (!Modifier.isPublic(writeMethod
									.getDeclaringClass().getModifiers())) {
								writeMethod.setAccessible(true);
							}
							writeMethod.invoke(target, value);

						} catch (final Throwable ex) {
							throw new FatalBeanException(
									"Could not copy property '"
											+ targetPd.getName()
											+ "' from source to target", ex);
						}
					}
				}
			}
		}
		return target;
	}
}
