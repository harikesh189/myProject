package com.hcentive.billing.core.commons.io;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("rawtypes")
public class SerializationUtil{
	private static final Logger LOGGER = LoggerFactory.getLogger(SerializationUtil.class);
	private static ObjectSerializer serializer;
	
	public static void configure(ObjectSerializer serializer) {
		SerializationUtil.serializer = serializer;
	}
	
	public static byte[] serialize(Serializable serializable) {
		long startTime = System.currentTimeMillis();
		byte[] data = serializer.serialize(serializable);
		LOGGER.debug("Time take to serialize object {} is {}", serializable.getClass().getName(), (System.currentTimeMillis() - startTime));
		return data;
	}
	
	
	public static Object deSerialize(byte[] data, Class type) {
		long startTime = System.currentTimeMillis();
		Object result = serializer.deSerialize(data, type);
		LOGGER.debug("Time take to deSerialize object {} is {}", result.getClass().getName(), (System.currentTimeMillis() - startTime));
		return result;
	}
}
