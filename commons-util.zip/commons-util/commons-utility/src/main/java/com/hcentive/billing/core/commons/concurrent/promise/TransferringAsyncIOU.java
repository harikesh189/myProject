package com.hcentive.billing.core.commons.concurrent.promise;

public class TransferringAsyncIOU<O, A extends AsyncCallback<O>> extends DefaultIOU<O, A> implements AsyncCallback<IOU<O, AsyncCallback<O>>> {

	private final AsyncCallback<O> transitiveAsync = new TransitiveAsyncCallback();

	@Override
	public void onSuccess(final IOU<O, AsyncCallback<O>> iou) {
		iou.set(this.transitiveAsync);
	}

	@Override
	public void onError(final Throwable t) {
		this.setError(t);
	}

	private class TransitiveAsyncCallback implements AsyncCallback<O> {

		@Override
		public void onSuccess(final O o) {
			TransferringAsyncIOU.this.setResult(o);
		}

		@Override
		public void onError(final Throwable t) {
			TransferringAsyncIOU.this.setError(t);
		}

	}

}
