package com.hcentive.billing.core.commons.util.reflection;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;
import static com.hcentive.billing.core.commons.util.CollectionUtil.isEmpty;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import com.hcentive.billing.core.commons.util.CollectionUtil;

public class ReflectionUtil {

	public static Collection<Field> findAllField(final Class<?> clazz) {
		Assert.notNull(clazz, "Class must not be null");
		Class<?> searchType = clazz;
		final List<Field> result = new LinkedList<>();
		while (!Object.class.equals(searchType) && searchType != null) {
			result.addAll(asList(searchType.getDeclaredFields()));
			searchType = searchType.getSuperclass();
		}
		return result;
	}

	public static <T> T merge(final T src, final T target) {
		return mergeWithIgnoreFields(src, target, null);
	}

	public static <T> T merge(final T src, final T target,
			final String[] fieldsNamesToMerge) {
		Assert.notNull(src, "Source must not be null");
		Assert.notNull(target, "Target must not be null");
		Assert.notNull(fieldsNamesToMerge,
				"Field names to be merged must not be null and empty");
		for (final String fieldNameToMerge : fieldsNamesToMerge) {
			mergeField(src, target,
					ReflectionUtils.findField(src.getClass(), fieldNameToMerge));
		}
		return target;
	}

	public static <T> T mergeWithIgnoreFields(final T src, final T target,
			final String[] fieldsNamesToIgnore) {
		Assert.notNull(src, "Source must not be null");
		Assert.notNull(target, "Target must not be null");
		final Collection<Field> fieldsToMerge = findAllField(src.getClass());
		for (final Field field : fieldsToMerge) {
			if (isEmpty(fieldsNamesToIgnore)
					|| !CollectionUtil.in(field.getName(), fieldsNamesToIgnore)) {
				mergeField(src, target, field);
			}
		}
		return target;
	}

	public static <T> void mergeField(final T src, final T target,
			final Field fieldToMerge) {
		try {
			fieldToMerge.setAccessible(true);
			if (fieldToMerge.get(src) != null) {
				ReflectionUtils.setField(fieldToMerge, target,
						fieldToMerge.get(src));
			}
		} catch (final Exception e) {
			throw new RuntimeException("Failed to merge field "
					+ fieldToMerge.getName() + " for class "
					+ src.getClass().getName(), e);
		}
	}

}
