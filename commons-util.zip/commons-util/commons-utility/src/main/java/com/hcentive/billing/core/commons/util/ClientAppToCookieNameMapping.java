package com.hcentive.billing.core.commons.util;

import java.util.HashMap;
import java.util.Map;

public class ClientAppToCookieNameMapping {
	
	public static final Map<String,String> clientAppToCookieNameMap = new HashMap<String,String>();
	
	static {
		clientAppToCookieNameMap.put("security-ui", "security-ui");
		clientAppToCookieNameMap.put("billing", "admin");
		clientAppToCookieNameMap.put("system", "admin");
		clientAppToCookieNameMap.put("ebill", "admin");
		clientAppToCookieNameMap.put("individual", "individual");
		clientAppToCookieNameMap.put("group", "group");
		clientAppToCookieNameMap.put("broker", "broker");
		clientAppToCookieNameMap.put("xpgApp", "xpgApp");
	}

}
