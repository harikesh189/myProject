package com.hcentive.billing.core.commons.converter;

import org.springframework.core.convert.converter.Converter;

import com.hcentive.billing.core.commons.exception.StandardErrorCodes;

public class StandardErrorCodeConverter implements Converter<String, StandardErrorCodes> {
	@Override
	public StandardErrorCodes convert(String source) {
		final StandardErrorCodes errorCode = StandardErrorCodes.valueOf(source);
		return errorCode;
	}
}