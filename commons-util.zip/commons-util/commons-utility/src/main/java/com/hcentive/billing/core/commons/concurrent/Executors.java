package com.hcentive.billing.core.commons.concurrent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public abstract class Executors {

	public static PriorityThreadPoolExecutor newPriorityThreadPoolExecutor(String poolName, int corePoolSize, int maximumPoolSize, long keepAliveTime,
	        TimeUnit unit, PriorityBlockingQueue<Runnable> workQueue) {
		return new PriorityThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, new DefaultThreadFactory(poolName));
	}

	public static ThreadPoolExecutor newThreadPoolExecutor(String poolName, int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
	        BlockingQueue<Runnable> workQueue) {
		return new ThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, new DefaultThreadFactory(poolName));
	}

	public static ScheduledThreadPoolExecutor newScheduledThreadPoolExecutor(String poolName, int corePoolSize) {
		return new ScheduledThreadPoolExecutor(corePoolSize, new DefaultThreadFactory(poolName));
	}

	public static ExecutorService newSingleThreadExecutor(String poolName) {
		return java.util.concurrent.Executors.newSingleThreadExecutor(new DefaultThreadFactory(poolName));
	}

	public static ExecutorService newFixedThreadPool(String poolName, int nThreads) {
		return java.util.concurrent.Executors.newFixedThreadPool(nThreads, new DefaultThreadFactory(poolName));
	}
}
