package com.hcentive.billing.core.commons.method.step;

public abstract class MethodStep<SD> {

	protected SD sharedData;

	protected MethodStep<SD> nextStep;

	public MethodStep(final SD sharedData, final MethodStep<SD> nextStep) {
		this.sharedData = sharedData;
		this.nextStep = nextStep;
	}

	public abstract void execute();

	public void executeNextStep() {
		if (this.nextStep != null) {
			this.nextStep.execute();
		}
	}

}
