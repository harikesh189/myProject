package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class AbstractUnBoundedCollectionIOU<O, A extends AsyncCallback<O>, CO> extends ResultCollectionIOU<O, A, CO> {

	final protected ResultCollector<CO, O> unBoundedresultCollector;
	private boolean inputCompleted;

	protected List<IOU<CO, AsyncCallback<CO>>> iouList = new LinkedList<>();
	private AtomicInteger iouCountWithResult = new AtomicInteger(0);

	public AbstractUnBoundedCollectionIOU(final ResultCollector<CO, O> unBoundedresultCollector) {
		super(unBoundedresultCollector, 0);
		this.unBoundedresultCollector = unBoundedresultCollector;
	}

	@Override
	public void addIOU(final IOU<CO, AsyncCallback<CO>> iou) {
		this.iouList.add(iou);
		iou.set(this);
	}

	@Override
	public void onSuccess(final CO o) {
		try {
			this.lock.lock();
			this.collectResult(o);
			this.checkAndSetResult();
		} finally {
			this.lock.unlock();
		}
	}
	
	/**
	 * It return the 
	 * @param o
	 */
	protected void collectResult(final CO o) {
		iouCountWithResult.incrementAndGet();
		super.collectResult(o);
	}

	@Override
	protected void checkAndSetResult() {
		if (this.inputCompleted && this.iouCountWithResult.get() == this.iouList.size()) {
			this.setResult(this.resultCollector.collectedResult());
		}
	}

	public void setInputCompleted(final boolean inputCompleted) {
		try {
			this.lock.lock();
			this.inputCompleted = inputCompleted;
			checkAndSetResult();
		} finally {
			this.lock.unlock();
		}
	}
}
