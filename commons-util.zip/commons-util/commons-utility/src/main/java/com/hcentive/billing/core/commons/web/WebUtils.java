package com.hcentive.billing.core.commons.web;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.util.EncryptionUtil;

public final class WebUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(WebUtils.class);

	public static final java.lang.String COOKIE_SID = "sid";

	/**
	 * @param httpRequest
	 * @param httpServletResponse
	 */
	public static void clearCookie(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, final String path, final boolean isCookieSecure,
			final String cookieIdentifier) {
		final Map<String, String> cookieParams = getCookiesFromRequest(httpRequest);
		for (final Map.Entry<String, String> entry : cookieParams.entrySet()) {
			final Cookie cookie = new Cookie(entry.getKey(), entry.getValue());
			cookie.setSecure(isCookieSecure);
			if (entry.getKey().equals(cookieIdentifier)) {
				cookie.setMaxAge(0);
			}
			cookie.setPath(path);
			cookie.setDomain("." + httpRequest.getServerName());
			httpServletResponse.addCookie(cookie);
		}
	}

	public static String decodeBase64(final String toBeDecoded) {
		return new String(Base64.decodeBase64(toBeDecoded));
	}

	public static String decryptTokenId(final String encryptedTokenId) {
		return EncryptionUtil.twoWayDecryptString(encryptedTokenId);
	}

	public static String encodeBase64String(final String toBeEncoded) {
		return Base64.encodeBase64String(toBeEncoded.getBytes());
	}

	public static String encryptTokenId(final String tokenId) {
		return EncryptionUtil.twoWayEncryptString(tokenId);
	}

	public static String getAuthorizationHeader(HttpServletRequest request) {
		final String encryptedTokenId = request.getHeader("Authorization") != null ? request.getHeader("Authorization").replaceFirst("BASIC ", "") : null;
		if (null != encryptedTokenId) {
			LOGGER.debug("Authorizing via Header {} ", encryptedTokenId);
			return WebUtils.decryptTokenId(encryptedTokenId);
		}
		return null;
	}

	public static String getBaseUrl(final HttpServletRequest request) {
		final StringBuilder builder = new StringBuilder();
		final String domainName = request.getServerName();
		builder.append("https://").append(domainName);
		return builder.toString();
	}

	public static Map<String, String> getCookiesFromRequest(final HttpServletRequest request) {
		final Map<String, String> cookiesMap = new HashMap<String, String>();
		final Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (final Cookie cookie : cookies) {
				final String cookieName = cookie.getName();
				if (cookieName.startsWith(COOKIE_SID)) {
					cookiesMap.put(cookieName, cookie.getValue());
				}
			}
		}
		return cookiesMap;
	}

	public static boolean ignoreCurrentRequest(final ServletRequest request, String ignoreCurrentRequestPaths) {
		final String path = ((HttpServletRequest) request).getRequestURI();
		final String[] ignoredPaths = ignoreCurrentRequestPaths.split(",");
		for (final String ignoredPath : ignoredPaths) {
			if (path.contains(ignoredPath)) {
				return true;
			}
		}
		return false;
	}

	public static String parseClientId(final HttpServletRequest request, final Set<String> registeredClientApps, final int... indexesToLook) {
		String clientId = null;
		if (indexesToLook != null) {
			for (final int index : indexesToLook) {
				clientId = doParseClientId(request, index, registeredClientApps);
				if (clientId != null) {
					break;
				}
			}
		}
		return clientId;
	}

	public static String[] pathItems(final ServletRequest request) {
		final String path = ((HttpServletRequest) request).getRequestURI();
		return path != null ? path.split("/") : null;
	}

	public static String replaceEnterprise(final String enterpriseName, final String url) {
		return url.replaceAll("\\{enterpriseName\\}", enterpriseName);
	}

	public static String resolve(final ServletRequest request, final int position) {
		final String[] path = pathItems(request);
		return path != null && path.length >= position + 1 ? path[position] : null;
	}

	private static String doParseClientId(final HttpServletRequest request, final int indexToLook, final Set<String> registeredClientApps) {
		final String clientId = WebUtils.resolve(request, indexToLook);
		if (registeredClientApps.contains(clientId)) {
			return clientId;
		}
		return null;
	}
}
