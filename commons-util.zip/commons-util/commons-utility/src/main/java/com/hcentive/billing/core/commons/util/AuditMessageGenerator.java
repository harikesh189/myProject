package com.hcentive.billing.core.commons.util;


public class AuditMessageGenerator {

	public String makePaymentAuditMessageGenerator(String id, String status) {
		if (status.toLowerCase().contains("success"))
			return "Payment with Transaction ID " + id + " was successful.";
		else if (status.toLowerCase().contains("fail"))
			return "Payment with Transaction ID " + id + " was unsuccessful.";
		else
			return "Payment with Transaction ID " + id + " was initiated.";
	}

	public String invoiceAuditMessageGenerator(String invoiceId,
			String subscription) {
		StringBuffer message = new StringBuffer("Invoice " + invoiceId + " has been generated for ");
		if(subscription != null){
			message = message.append("Billing Account "+ subscription+", ");
		}
		return message.toString();
	}

	public static String notificationPreferenceAuditMessageGenerator() {
		return "Notification Preferences has been updated.";
	}

	public String paymentMethodAuditMessageGenerator(String changeType,
			String status) {
		if (status.toLowerCase().contains("success")) {
			if (changeType.toLowerCase().contains("add"))
				return "Payment Method was added successfully.";
			else if (changeType.toLowerCase().contains("delete"))
				return "Payment Method was removed successfully.";
			else
				return "Preferred Payment Method was changed successfully.";
		} else {
			if (changeType.toLowerCase().contains("add"))
				return "Request for Payment Method addition was failed.";
			else if (changeType.toLowerCase().contains("delete"))
				return "Payment Method removal failed.";
			else
				return "Preferred Payment Method update failed.";
		}
	}

	public String recurringAuditMessageGenerator(String changeType,
			String status) {
		if (status.toLowerCase().contains("success")) {
			if (changeType.toLowerCase().contains("save"))
				return "New Recurring Setup is added successfully for ";
			else if (changeType.toLowerCase().contains("cancel"))
				return "Recurring Setup is cancelled successfully for ";
			else
				return "";
		} else {
			if (changeType.toLowerCase().contains("save"))
				return "Recurring Setup is failed for ";
			else if (changeType.toLowerCase().contains("cancel"))
				return "Recurring setup cancellation is failed for ";
			else
				return "";
		}
	}
	
	public String SchedulePaymentAuditMessageGenerator(String changeType,
			String status) {
		if (status.toLowerCase().contains("success")) {
			if (changeType.toLowerCase().contains("save"))
				return "New Schedule Payment Setup is added successfully for ";
			else if (changeType.toLowerCase().contains("cancel"))
				return "Schedule Payment setup is cancelled successfully for ";
			else
				return "";
		} else {
			if (changeType.toLowerCase().contains("save"))
				return "Schedule Payment Setup is failed for ";
			else if (changeType.toLowerCase().contains("cancel"))
				return "Schedule setup cancellation is failed for ";
			else
				return "";
		}
	}
	
	public String processContextAuditMessageGenerator(String status){
		if(status.equalsIgnoreCase("destroy")){
			return "process context successfully destroyed ";
		}
		return "process context successfully created ";
		
	}

}
