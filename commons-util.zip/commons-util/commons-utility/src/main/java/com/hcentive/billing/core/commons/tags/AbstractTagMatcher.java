package com.hcentive.billing.core.commons.tags;

import static com.hcentive.billing.core.commons.util.CollectionUtil.nullSafe;

import java.util.Collection;

import com.hcentive.billing.core.commons.util.CollectionUtil;

public abstract class AbstractTagMatcher implements TagMatcher {

	public <C, T extends TagAware<C>> boolean match(final T matchObj,
			final T matchTo) {
		final Collection<C> tags1 = nullSafe(matchObj.tags());
		final Collection<C> tags2 = nullSafe(matchTo.tags());

		Collection<C> commonTags = CollectionUtil.intersection(tags1, tags2);
		if (commonTags == null || commonTags.isEmpty()) {
			return false;
		}

		return match(commonTags, tags1, tags2);
	}

	protected abstract <C> boolean match(Collection<C> commonTags,
			Collection<C> matchObjTags, Collection<C> matchToTags);

}
