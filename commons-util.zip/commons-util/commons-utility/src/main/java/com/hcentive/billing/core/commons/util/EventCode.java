package com.hcentive.billing.core.commons.util;

public enum EventCode {
	// Extra information regarding the event 
	// Can be updated in case more codes are identified
	HOLD, UNHOLD
}