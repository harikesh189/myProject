package com.hcentive.billing.core.commons.condition;

import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.core.type.MethodMetadata;

public class BeanNameAbsentChecker implements Condition {

	@Override
	public boolean matches(final ConditionContext context,
			final AnnotatedTypeMetadata metadata) {
		final BeanDefinitionRegistry beanDefRegistry = context.getRegistry();
		final String beanNameToCheck = resolveBeanName(metadata);
		return beanNameToCheck == null ? true : !beanDefRegistry
				.containsBeanDefinition(beanNameToCheck);
	}

	private String resolveBeanName(final AnnotatedTypeMetadata metadata) {
		String beanName = null;
		if (metadata instanceof MethodMetadata
				&& metadata.isAnnotated(Bean.class.getName())) {
			beanName = ((MethodMetadata) metadata).getMethodName();
		}
		return beanName;
	}

}
