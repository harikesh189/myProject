package com.hcentive.billing.core.commons.condition;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Conditional;

@Conditional(BeanEnabledCondition.class)
@Target({ElementType.METHOD,ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ConditionalOnBeanEnabled {
	public static final String FIELD_KEY="key";
	public static final String FIELD_MATCH_ON_MISSING="matchOnMissing";
	
	public String key();
	public boolean matchOnMissing() default false;
}
