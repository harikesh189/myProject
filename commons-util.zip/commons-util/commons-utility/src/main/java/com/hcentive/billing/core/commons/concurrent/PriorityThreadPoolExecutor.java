package com.hcentive.billing.core.commons.concurrent;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class PriorityThreadPoolExecutor extends ThreadPoolExecutor {

	public PriorityThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit, PriorityBlockingQueue<Runnable> workQueue,
	        ThreadFactory threadFactory) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory);
	}

	@Override
	public <T> Future<T> submit(Callable<T> task) {
		if (task instanceof Comparable) {
			final RunnableFuture<T> futureTask = newTaskFor(task);
			execute(futureTask);
			return futureTask;
		}
		throw new IllegalArgumentException("The task submitted is not an instance of Comparable.");
	}

	@Override
	public Future<?> submit(Runnable task) {
		if (task instanceof Comparable) {
			final RunnableFuture futureTask = newTaskFor(task, null);
			execute(futureTask);
			return futureTask;
		}
		throw new IllegalArgumentException("The task submitted is not an instance of Comparable.");
	}

	@Override
	public <T> Future<T> submit(Runnable task, T result) {
		if (task instanceof Comparable) {
			final RunnableFuture futureTask = newTaskFor(task, result);
			execute(futureTask);
			return futureTask;
		}
		throw new IllegalArgumentException("The task submitted is not an instance of Callable.");
	}

	public <T> Future<T> submit(Callable<T> task, int priority) {

		final RunnableFuture<T> futureTask = newTaskFor(task, priority);
		execute(futureTask);
		return futureTask;
	}

	public Future<?> submit(Runnable task, int priority) {
		final RunnableFuture futureTask = newTaskFor(task, priority);
		execute(futureTask);
		return futureTask;
	}

	public <T> Future<T> submit(Runnable task, T result, int priority) {
		final RunnableFuture futureTask = newTaskFor(task, result, priority);
		execute(futureTask);
		return futureTask;
	}

	@Override
	protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
		return new ComparableFutureTask<T>(callable);

	}

	protected <T> RunnableFuture<T> newTaskFor(Runnable runnable, T value, int priority) {
		return new PriorityBasedFutureTask<T>(runnable, value, priority);
	}

	protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable, int priority) {
		return new PriorityBasedFutureTask<T>(callable, priority);

	}

	@Override
	protected <T> RunnableFuture<T> newTaskFor(Runnable runnable, T value) {
		return new ComparableFutureTask<T>(runnable, value);
	}

	private static class ComparableFutureTask<V> extends FutureTask<V> implements Runnable, Comparable<ComparableFutureTask<V>> {

		private final Comparable targetTask;

		private ComparableFutureTask(Callable<V> callable) {
			super(callable);
			this.targetTask = (Comparable) callable;
		}

		private ComparableFutureTask(Runnable runnable, V result) {
			super(runnable, result);
			this.targetTask = (Comparable) runnable;
		}

		@Override
		public int compareTo(ComparableFutureTask<V> that) {
			return this.targetTask.compareTo(that.targetTask);
		}

	}

	private static class PriorityBasedFutureTask<V> extends FutureTask<V> implements Runnable, Comparable<PriorityBasedFutureTask<V>> {
		private final int priority;

		private PriorityBasedFutureTask(Callable<V> callable, int priority) {
			super(callable);
			this.priority = priority;
		}

		private PriorityBasedFutureTask(Runnable runnable, V result, int priority) {
			super(runnable, result);
			this.priority = priority;
		}

		@Override
		public int compareTo(PriorityBasedFutureTask<V> that) {
			return this.priority - that.priority;
		}

	}

}
