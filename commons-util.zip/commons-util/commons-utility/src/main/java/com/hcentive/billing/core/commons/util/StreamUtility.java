package com.hcentive.billing.core.commons.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StreamUtility {

	private static final Logger logger = LoggerFactory
			.getLogger(StreamUtility.class);

	/**
	 * Downloads contents of a URL to a file.
	 * 
	 * @param downloadURL
	 * @param dirLocation
	 * @param fileName
	 * @throws Exception
	 */
	public static void downloadFromURL(final String downloadURL,
			final String dirLocation, final String fileName) throws Exception {
		logger.debug("downloading from urL::" + downloadURL);
		File directory = new File(dirLocation);
		if (!directory.exists()) {
			directory.mkdir();
		}
		final File fileObj = new File(dirLocation, fileName);
		FileUtils.copyURLToFile(new URL(downloadURL), fileObj);
		logger.debug("Successful downloaded from urL::" + downloadURL
				+ "to file:" + fileObj.getAbsolutePath());
	}

	public static String postStreamToURL(final String serviceURL,
			final String dirLocation, final String fileName) throws Exception {
		logger.debug("posting data to the url" + serviceURL);
		final HttpClient httpClient = HttpClientBuilder.create().build();
		final HttpPost postRequest = new HttpPost(serviceURL);
		InputStream inStream = null;
		InputStreamReader inReader = null;

		try {

			File fileObj = new File(dirLocation, fileName);
			InputStreamEntity input = new InputStreamEntity(
					new FileInputStream(fileObj), fileObj.length());
			postRequest.setEntity(input);
			HttpResponse response = httpClient.execute(postRequest);

			inStream = response.getEntity().getContent();
			inReader = new InputStreamReader((inStream));

			BufferedReader br = new BufferedReader(inReader);

			StringBuffer result = new StringBuffer();
			String output = "";
			while ((output = br.readLine()) != null) {
				result.append(output);
			}
			logger.debug("Operation successful");
			br.close();
			return result.toString();
		} finally {
			if (inStream != null)
				inStream.close();
			if (inReader != null)
				inReader.close();
		}

	}

	public static String postStreamToURL(final String serviceURL,
			final InputStream io) throws Exception {

		logger.debug("posting data to the url" + serviceURL);
		final HttpClient httpClient = HttpClientBuilder.create().build();
		final HttpPost postRequest = new HttpPost(serviceURL);
		InputStream inputSteam = null;
		InputStreamReader inReader = null;
		try {

			InputStreamEntity input = new InputStreamEntity(io, -1);
			postRequest.setEntity(input);
			HttpResponse response = httpClient.execute(postRequest);

			inputSteam = response.getEntity().getContent();
			inReader = new InputStreamReader((inputSteam));

			BufferedReader br = new BufferedReader(inReader);

			StringBuffer result = new StringBuffer();
			String output = "";
			while ((output = br.readLine()) != null) {
				result.append(output);
			}
			logger.debug("Operation successful");

			br.close();
			final String key =  result.toString();
			System.out.println("key::"+key);
 			return key;
		} finally {
			if (inputSteam != null)
				inputSteam.close();
			if (inReader != null)
				inReader.close();
		}

	}

}
