package com.hcentive.billing.core.commons.concurrent.promise;

/**
 * Callback interface for handling callback in future.
 * 
 * @author BAM
 * 
 * @param <O>
 */
public interface AsyncCallback<O> {

	/**
	 * Method to be executed on success event of asyn call.
	 * 
	 * @param o
	 */
	void onSuccess(O o);

	/**
	 * Method to be executed on error event of async callback.
	 * 
	 * @param t
	 */
	void onError(Throwable t);
}
