package com.hcentive.billing.core.commons.util;

/**
 * class holds permission constants.
 *
 * @author ajay.saxena
 *
 */
public class Permission {

	public static final String MAKE_PAYMENT_PERMISSION = "MakePayment";
	public static final String READ_PAYMENT_PERMISSION = "ReadPayment";
	public static final String ADMIN_READ_PAYMENT_PERMISSION = "AdminReadPayment";
	public static final String ADMIN_MAKE_PAYMENT_PERMISSION = "AdminMakePayment";

	public static final String ADMIN_READ_PI_PERMISSION = "AdminReadPI";
	public static final String READ_PI_PERMISSION = "ReadPI";
	public static final String ADMIN_ADD_PI_PERMISSION = "AdminAddPI";
	public static final String ADD_PI_PERMISSION = "AddPI";
	public static final String REMOVE_PI_PERMISSION = "RemovePI";
	public static final String ADMIN_REMOVE_PI_PERMISSION = "AdminRemovePI";
	public static final String UPDATE_PI_PERMISSION = "UpdatePI";

	public static final String READ_SCHEDULE_PAYMENT_SETUP = "ReadRecurringInfo";
	public static final String ADMIN_READ_SCHEDULE_PAYMENT_SETUP = "AdminReadRecurringInfo";
	public static final String ADMIN_ADD_RECURRING_INFO = "AdminAddRecurringInfo";
	public static final String ADD_RECURRING_INFO = "AddRecurringInfo";
	public static final String ADD_SCHEDULE_PAYMENT_INFO = "AddSchedulePaymentInfo";
	public static final String ADMIN_ADD_SCHEDULE_PAYMENT_INFO = "AdminAddSchedulePaymentInfo";
	public static final String ADMIN_CANCEL_RECURRING_INFO = "AdminCancelRecurringInfo";
	public static final String CANCEL_RECURRING_INFO = "CancelRecurringInfo";

	public static final String UPLOAD_DOC = "UploadDocument";
	public static final String DOWNLOAD_DOC = "DownLoadDocument";
	public static final String READ_DOC_STATUS = "ReadDocumentStatus";
	public static final String REMOVE_DOC = "RemoveDocument";

	public static final String READ_NOTIFICATION = "ReadNotification";
	public static final String ADMIN_READ_NOTIFICATION = "AdminReadNotification";
	public static final String READ_ASSOCIATED_NOTIFICATION = "ReadAssociatedNotification";
	public static final String READ_NOTIFICATION_PREFERENCE = "ReadNotificationPreference";
	public static final String ADD_NOTIFICATION_PREFERENCE = "AddNotificationPreference";
	public static final String UPDATE_NOTIFICATION_PREFERENCE = "UpdateNotificationPreference";
	public static final String SEND_NOTIFICATION = "SendNotification";
	public static final String ADMIN_SEND_NOTIFICATION = "AdminSendNotification";
	public static final String ADMIN_SEND_BULK_NOTIFICATION = "AdminSendBulkNotification";

	public static final String PORTAL_MANAGEMENT = "PortalManagement";
	public static final String SSO_MANAGEMENT = "SSOManagement";
	public static final String AUTH_MANAGEMENT = "AuthenticationManagement";

	public static final String CONFIG_MANAGEMENT = "ConfigManagement";
	public static final String ADMIN_UPDATE_USER = "AdminUpdateUser";
	public static final String ADMIN_ADD_USER = "AdminAddUser";
	public static final String ADMIN_DEACTIVATE_USER = "AdminDeactivateUser";
	public static final String ADMIN_ACTIVATE_USER = "AdminActivateUser";

	public static final String READ_INVOICE = "ReadInvoice";
	public static final String ADMIN_READ_INVOICE = "AdminReadInvoice";
	public static final String READ_INVOICE_DETAIL = "ReadInvoiceDetail";

	public static final String ADMIN_READ_INVOICE_DETAIL = "AdminReadInvoiceDetail";
	public static final String READ_AC_STMT = "ReadAccStmt";
	public static final String ADMIN_READ_AC_STMT = "AdminReadAccStmt";
	public static final String ADMIN_READ_AC_ACTIVITY = "AdminReadAccActivity";
	public static final String READ_AC_ACTIVITY = "ReadAccActivity";
	public static final String UPDATE_CONFIG = "AdminUpdateConfig";
	public static final String READ_PROFILE = "ReadProfile";
	public static final String ADD_INVOICE = "AddInvoice";
	public static final String UPDATE_INVOICE = "UpdateInvoice";
	public static final String CREATE_INVOICE_REPORT = "CreateInvoiceReport";
	public static final String READ_INVOICE_REPORT = "ReadInvoiceReport";

	public static final String ADMIN_READ_USER = "AdminReadUser";

	public static final String EXPORT_INVOICE = "ExportInvoice";
	public static final String INVOICE_BANNER = "InvoiceBanner";

	public static final String SEARCH_CUSTOMER = "SearchCustomer";
	public static final String ADMIN_SEARCH_CUSTOMER = "AdminSearchCustomer";
	public static final String MANAGE_AUDIT = "ManageAudit";
	public static final String READ_CONTRACT = "ReadContract";
	public static final String ADMIN_READ_CONTRACT = "AdminReadContract";

	public static final String ADMIN_READ_PERMISSION = "AdminReadPermission";
	public static final String ADMIN_ADD_PERMISSION = "AdminAddPermission";
	public static final String ADMIN_READ_ROLE = "AdminReadRole";
	public static final String ADMIN_ADD_ROLE = "AdminAddRole";
	public static final String ADMIN_REMOVE_ROLE = "AdminRemoveRole";

	public static final String UPDATE_USER = "UPDATE_USER";
	public static final String ADD_ADMINISTRATOR = "ADD_ADMINISTRATOR";
	public static final String ADD_MANAGER = "ADD_MANAGER";
	public static final String SEARCH_USER = "SEARCH_USER";

	public static final String FETCH_ASSOCIATED_PARTIES = "FetchAssociatedParties";
	public static final String ADMIN_FETCH_ASSOCIATED_PARTIES = "AdminFetchAssociatedParties";
	public static final String CREATE_FIXED_VALUE_TOKEN = "CreateFixedValueToken";

	public static final String WFM_OPERATOR_PORTAL = "WFMOperator";
	public static final String EBILL_OPERATOR_PORTAL = "Operator";
	public static final String INDIVIDUAL_PORTAL = "Individual";
	public static final String GROUP_PORTAL = "Group";
	public static final String BROKER_PORTAL = "Broker";

	// /NEW PERMISSIONS for WFM Operator
	public static final String ADD_AUDIT = "AddAudit";
	public static final String EXECUTE_BILL_RUN = "ExecuteBillRun";
	public static final String COMPLETE_BILLING_CONTRACT_RUN = "CompleteBillingContractRun";
	public static final String FAIL_BILLING_CONTRACT_RUN = "FailBillingContractRun";
	public static final String DELETE_AND_ADD_NOTIFICATION_PREF = "DeleteAddNotificationPref";
	public static final String ADD_NOTIFICATION_PREF = "AdminAddNotificationPref";
	public static final String FETCH_NOTIFICATION_PREF = "FetchNotificationPref";
	public static final String FETCH_FT_RULE = "FetchFTRule";
	public static final String ADD_FT_RULE = "AddFTRule";
	public static final String DELETE_BILLING_CONFIG_FLAT_CHARGE = "DeleteBillingConfigFlatCharge";
	public static final String DELETE_BILLING_CONFIG_PERCENT_CHARGE = "DeleteBillingConfigPercentCharge";
	public static final String FETCH_BILLING_CONFIG_FLAT_CHARGE = "FetchBillingConfigFlatCharge";
	public static final String FETCH_BILLING_CONFIG_PERCENT_CHARGE = "FetchBillingConfigPercentCharge";
	public static final String ADD_BILLING_CONFIG_FLAT_CHARGE = "AddBillingConfigFlatCharge";
	public static final String ADD_BILLING_CONFIG_PERCENT_CHARGE = "AddBillingConfigPercentCharge";
	public static final String DELETE_BILLING_CONFIG_FLAT_DISCOUNT = "DeleteBillingConfigFlatDiscount";
	public static final String FETCH_BILLING_CONFIG_FLAT_DISCOUNT = "FetchBillingConfigFlatDiscount";
	public static final String ADD_BILLING_CONFIG_FLAT_DISCOUNT = "AddBillingConfigFlatDiscount";
	public static final String DELETE_BILLING_CONFIG_FLAT_FEE = "DeleteBillingConfigFlatFee";
	public static final String FETCH_BILLING_CONFIG_FLAT_FEE = "FetchBillingConfigFlatFee";
	public static final String ADD_BILLING_CONFIG_FLAT_FEE = "AddBillingConfigFlatFee";
	public static final String DELETE_BILLING_CONFIG_FLAT_TAX = "DeleteBillingConfigFlatTax";
	public static final String FETCH_BILLING_CONFIG_FLAT_TAX = "FetchBillingConfigFlatTax";
	public static final String ADD_BILLING_CONFIG_FLAT_TAX = "AddBillingConfigFlatTax";
	public static final String DELETE_BILLING_CONFIG_PERCENT_DISCOUNT = "DeleteBillingConfigPercentDiscount";
	public static final String FETCH_BILLING_CONFIG_PERCENT_DISCOUNT = "FetchBillingConfigPercentDiscount";
	public static final String ADD_BILLING_CONFIG_PERCENT_DISCOUNT = "AddBillingConfigPercentDiscount";
	public static final String DELETE_BILLING_CONFIG_PERCENT_FEE = "DeleteBillingConfigPercentFee";
	public static final String FETCH_BILLING_CONFIG_PERCENT_FEE = "FetchBillingConfigPercentFee";
	public static final String ADD_BILLING_CONFIG_PERCENT_FEE = "AddBillingConfigPercentFee";

	public static final String DELETE_BILLING_CONFIG_PERCENT_TAX = "DeleteBillingConfigPercentTax";
	public static final String FETCH_BILLING_CONFIG_PERCENT_TAX = "FetchBillingConfigPercentTax";
	public static final String ADD_BILLING_CONFIG_PERCENT_TAX = "AddBillingConfigPercentTax";

	public static final String DELETE_BILLING_CONFIG_PRO_RATE = "DeleteBillingConfigProRate";
	public static final String FETCH_BILLING_CONFIG_PRO_RATE = "FetchBillingConfigProRate";
	public static final String ADD_BILLING_CONFIG_PRO_RATE = "AddBillingConfigProRate";

	public static final String DELETE_BILLING_CONFIG_REFUND = "DeleteBillingConfigRefund";
	public static final String FETCH_BILLING_CONFIG_REFUND = "FetchBillingConfigRefund";
	public static final String ADD_BILLING_CONFIG_REFUND = "AddBillingConfigRefund";

	public static final String DELETE_BILLING_CONFIG_REMIT = "DeleteBillingConfigRemit";
	public static final String FETCH_BILLING_CONFIG_REMIT = "FetchBillingConfigRemit";
	public static final String ADD_BILLING_CONFIG_REMIT = "AddBillingConfigRemit";

	public static final String DELETE_BILLING_CONFIG_RETRO = "DeleteBillingConfigRetro";
	public static final String FETCH_BILLING_CONFIG_RETRO = "FetchBillingConfigRetro";
	public static final String ADD_BILLING_CONFIG_RETRO = "AddBillingConfigRetro";

	public static final String DELETE_BILLING_CONFIG_SCHEDULE = "DeleteBillingConfigSchedule";
	public static final String FETCH_BILLING_CONFIG_SCHEDULE = "FetchBillingConfigSchedule";
	public static final String ADD_BILLING_CONFIG_SCHEDULE = "AddBillingConfigSchedule";
	public static final String FETCH_BILLING_POLICY = "FetchBillingPolicy";
	public static final String ADD_BILLING_POLICY = "AddBillingPolicy";
	public static final String EDIT_BILLING_POLICY = "EditBillingPolicy";
	public static final String EDIT_EXECUTED_BILLING_POLICY = "EditExecutedBillingPolicy";
	public static final String DELETE_BILLING_POLICY = "DeleteBillingPolicy";
	public static final String ADD_BILLING_POLICY_ENTITY_LINK = "AddBillingPolicyEntityLink";
	public static final String DELETE_BILLING_POLICY_ENTITY_LINK = "DeleteBillingPolicyEntityLink";
	public static final String FETCH_BILLING_POLICY_ENTITY_LINK = "FetchBillingPolicyEntityLink";
	public static final String FETCH_BILLING_RULE_CONFIG = "FetchBillingRuleConfig";
	public static final String FETCH_FINANCIAL_CHARGE = "FetchFinancialCharge";
	public static final String ADD_WRITE_ON_RULE = "AddWriteOnRule";
	public static final String FETCH_GL_ACCOUNT = "FetchGLAccount";
	public static final String ADD_GL_ACCOUNT = "AddGLAccount";
	public static final String IMPORT_ELIGIBILITY = "ImportEligibility";
	public static final String IMPORT_BE = "ImportBE";
	public static final String IMPORT_INVOICE = "ImportInvoice";
	public static final String IMPORT_GROUP_SETUP = "ImportGroupSetUp";
	public static final String IMPORT_PAYMENT_RECIEPT = "ImportPaymentReciept";
	public static final String IMPORT_3PPR = "Import3PPR";
	public static final String FETCH_CONFIGURATIONS = "FetchConfigurations";
	public static final String ADD_CONFIGURATIONS = "AddConfigurations";
	public static final String FETCH_WFM_INVOICE = "FetchWFMInvoice";
	public static final String GENERATE_WFM_INVOICE = "GenerateWFMInvoice";
	public static final String APPROVE_WFM_INVOICE = "ApproveWFMInvoice";
	public static final String REJECT_WFM_INVOICE = "RejectWFMInvoice";
	public static final String ADD_WFM_INVOICE = "AddWFMInvoice";
	public static final String UPDATE_WFM_INVOICE = "UpdateWFMInvoice";
	public static final String SETTLE_WFM_INVOICE = "SettleWFMInvoice";
	public static final String PROCESS_GENERATED_WFM_INVOICE = "ProcessGeneratedWFMInvoice";
	public static final String FETCH_BILL_RUN_CYCLE = "FetchBillRunCycle";
	public static final String FETCH_BILL_ACCOUNT_RUN_CYCLE = "FetchBillAccountRunCycle";
	public static final String ADD_BILL_CONTRACT_RUN = "AddBillContractRun";
	public static final String ADD_BILL_RUN_CYCLE = "AddBillRunCycle";
	public static final String UPDATE_BILL_RUN_CYCLE = "UpdateBillRunCycle";
	public static final String ADD_BILL_ACCOUNT_RUN_CYCLE = "AddBillAccountRunCycle";
	public static final String REGENERATE_WFM_INVOICE = "RegenerateWFMInvoice";
	public static final String FETCH_REMIT_REFUND = "FetchRemitRefund";
	public static final String ADD_REMIT_REFUND = "AddRemitRefund";

	// Latest
	public static final String UPDATE_BILL_ACCOUNT_RUN_CYCLE = "UpdateBillAccountRunCycle";
	public static final String ADD_WFM_INVOICE_GENERATION_REQUEST = "AddWFMInvoiceGenerationRequest";
	public static final String FETCH_WFM_INVOICE_GENERATION_REQUEST = "FetchWFMInvoiceGenerationRequest";
	public static final String UPDATE_WFM_INVOICE_GENERATION_REQUEST = "UpdateWFMInvoiceGenerationRequest";
	public static final String FETCH_BILLING_ACCOUNT = "FetchBillingAccount";
	public static final String PROCESS_CONTRACT = "ProcessContract";

	//
	public static final String FETCH_FT_ENTRY = "FetchFTEntry";
	public static final String ADD_FT_ENTRY = "AddFTEntry";
	public static final String FETCH_ITEM_RECORD = "FetchItemRecord";
	public static final String ADD_REMIT = "AddRemit";
	public static final String FETCH_REMIT = "FetchRemit";
	public static final String EXPORT_ORDER = "ExportOrder";
	public static final String FETCH_BE = "FetchBE";
	public static final String UPDATE_BE = "UpdateBE";

	public static final String READ_SUBSCRIPTION = "ReadSubscription";
	public static final String ADMIN_READ_SUBSCRIPTION = "AdminReadSubscription";
	public static final String VIEW_REPORT = "ViewReport";
	public static final String DOWNLOAD_REPORT = "DownloadReport";

	/**
	 * Ajay : permissions related to manualAdjustment
	 */
	public static final String SAVE_WRITE_OFF = "SaveWriteOff";
	public static final String REJECT_WRITE_OFF = "RejectWriteOff";
	public static final String REJECT_REFUND = "RejectRefund";
	public static final String SAVE_REFUND = "SaveRefund";
	public static final String REJECT_CREDIT_ADJUSTMENT = "RejectCredit";
	public static final String SAVE_CREDIT_ADJUSTMENT = "SaveCredit";
	public static final String SAVE_WRITE_ON = "SaveWriteOn";
	public static final String REJECT_WRITE_ON = "RejectWriteOn";
	public static final String VOID_WRITE_OFF = "VoidWriteOff";
	public static final String VOID_WRITE_ON = "VoidWriteOn";
	public static final String VOID_REFUND = "VoidRefund";
	public static final String VOID_CREDIT_ADJUSTMENT = "VoidCredit";
	public static final String LIST_REFUND = "ListRefund";
	public static final String LIST_WRITE_OFF = "ListWriteOff";
	public static final String LIST_WRITE_ON = "ListWriteOn";
	public static final String LIST_CREDIT = "ListCredit";

	public static final String FORGOT_PASSWORD = "ForgotPassword";
	
	public static final String ADMIN_MAKE_OUTBOUND_PAYMENT = "MakeOutboundPayment";
	public static final String ADMIN_VOID_INBOUND_PAYMENT = "VoidInboundPayment";
	public static final String ADMIN_VOID_OUTBOUND_PAYMENT = "VoidOutboundPayment";
}