package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public abstract class AbstractCollectionIOU<O, A extends AsyncCallback<Collection<O>>, CO> extends DefaultIOU<Collection<O>, A> implements AsyncCallback<CO> {

	final protected Collection<O> collection;

	final private Lock lock;

	private final AtomicInteger resultCounter;

	public AbstractCollectionIOU(final Collection<O> resultHolder, final int resultCount) {
		this.collection = resultHolder;
		this.resultCounter = new AtomicInteger(resultCount);
		this.lock = new ReentrantLock();
		this.checkAndSetResult();
	}

	public void addIOU(final IOU<CO, AsyncCallback<CO>> iou) {
		iou.set(this);
	}

	@Override
	public void onSuccess(final CO o) {
		try {
			this.lock.lock();
			this.collectResult(o);
			this.resultCounter.decrementAndGet();
			this.checkAndSetResult();
		} finally {
			this.lock.unlock();
		}
	}

	protected void checkAndSetResult() {
		if (this.resultCounter.get() == 0) {
			this.setResult(this.collection);
		}
	}

	protected abstract void collectResult(CO o);

	@Override
	public void onError(final Throwable t) {
		try {
			this.lock.lock();
			this.resultCounter.decrementAndGet();
			this.setError(t);
		} finally {
			this.lock.unlock();
		}

		// TODO: handle properly - error condition
	}

}
