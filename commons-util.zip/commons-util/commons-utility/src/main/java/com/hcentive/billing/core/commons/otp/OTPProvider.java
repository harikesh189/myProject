package com.hcentive.billing.core.commons.otp;

public interface OTPProvider {

	long generateOTP();

}
