package com.hcentive.billing.core.commons.util;

public class ContactNumberFormatter {

	public static String usContactNumberFormatter(final String number) {
		String contactNumber = "";
		if (number != null && !number.equals(""))
			contactNumber = String.format("(%s) %s-%s", number.substring(0, 3),
					number.substring(3, 6), number.substring(6, 10));
		return contactNumber;
	}

}
