package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default implementation for {@link IOU}
 * @author BAM
 * @param <O>
 */
public class DefaultIOU<O, A extends AsyncCallback<O>> implements IOU<O, A> {
	private static final Logger logger = LoggerFactory.getLogger(DefaultIOU.class);

	private volatile AtomicReference<O> resultHolder = new AtomicReference<O>();
	private volatile AtomicReference<Throwable> errorHolder = new AtomicReference<Throwable>();

	private volatile AtomicBoolean resultObtained = new AtomicBoolean(false);
	private volatile AtomicBoolean processingError = new AtomicBoolean(false);

	protected volatile AtomicReference<A> callbackHolder = new AtomicReference<A>();

	private volatile Semaphore permit = new Semaphore(1);

	/**
	 * Return the processing result, null in case the processing is still in progress. Non-Blocking in nature.
	 * @return
	 */
	@Override
	public O get() {
		if (this.processingError.get()) {
			throw new RuntimeException("Error had occured during processing.");
		}
		return this.resultHolder.get();
	}

	/**
	 * Sets the callback to be invoked on completion of processing or on error. Callback is immediately invoked if processing has been completed or an error has
	 * already occurred.
	 * @param callback
	 */
	@Override
	public void set(final A callback) {
		try {
			this.permit.acquire();
			if (this.callbackHolder.get() != null) {
				throw new IllegalStateException("Callback already has been set. Cannot modify it.");
			}
			this.callbackHolder.set(callback);
			this.checkAndInvokeCallback();
		} catch (final InterruptedException e) {
			throw new RuntimeException(e);
		} finally {
			this.permit.release();
		}

	}

	private void checkAndInvokeCallback() {
		if (this.callbackHolder.get() != null) {
			try {
				if (this.resultObtained.get()) {
					this.callbackHolder.get().onSuccess(this.resultHolder.get());
				}
				if (this.processingError.get()) {
					this.callbackHolder.get().onError(this.errorHolder.get());
				}
			} catch (final Throwable t) {
				logger.error("Processing error in callback invocation. ", t);
			}
		}
	}

	/**
	 * Sets the result. Invokes callback is callback has been already set else, defers invocations of callback till it is set.
	 * @param result
	 */
	public void setResult(final O result) {
		try {
			this.permit.acquire();
			if (this.resultObtained.get() || this.processingError.get()) {
				throw new IllegalStateException("Result has already been set.");
			}
			this.resultHolder.set(result);
			this.resultObtained.set(true);
			this.checkAndInvokeCallback();
		} catch (final InterruptedException e) {
			throw new RuntimeException(e);
		} finally {
			this.permit.release();
		}
	}

	/**
	 * Sets the error. Invokes callback is callback has been already set else, defers invocations of callback till it is set.
	 * @param result
	 */
	public void setError(final Throwable t) {
		try {
			logger.error("Setting error in IOU {}", ExceptionUtils.getFullStackTrace(t));
			this.permit.acquire();
			if (this.resultObtained.get() || this.processingError.get()) {
				throw new IllegalStateException("Result has already been set.");
			}
			this.errorHolder.set(t);
			this.processingError.set(true);
			this.checkAndInvokeCallback();
		} catch (final InterruptedException e) {
			throw new RuntimeException(e);
		} finally {
			this.permit.release();
		}
	}

	@Override
	public <T extends Throwable> T getError() {
		// TODO Auto-generated method stub
		return (T) this.errorHolder.get();
	}

	@Override
	public boolean isCompleted() {
		// TODO Auto-generated method stub
		return this.resultObtained.get() || this.processingError.get();
	}

	@Override
	public boolean hasError() {
		// TODO Auto-generated method stub
		return this.processingError.get();
	}

	protected A callback() {
		return this.callbackHolder.get();
	}
}
