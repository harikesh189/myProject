/**
* @author uttam.tiwari
*
*/
package com.hcentive.billing.core.commons.util;

public interface IDGenerator<T> {

	public T generateID(Object obj);
}


