package com.hcentive.billing.core.commons.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "auditInfo", "operator" })
public class SampleBEMixin {

}
