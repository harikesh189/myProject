package com.hcentive.billing.core.commons.exception;

public enum StandardErrorCodes implements ErrorCode {
	CONNECTION_FAILURE, DATABASE_CONNECTION_ERROR, DATABASE_CONTRAINT_VOILATION, GENERIC_ERROR;

	public static StandardErrorCodes fromString(String value) {
		if (value != null) {
			for (final StandardErrorCodes errorCode : values()) {
				if (errorCode.name().endsWith(value)) {
					return errorCode;
				}
			}
		}
		return null;
	}
}
