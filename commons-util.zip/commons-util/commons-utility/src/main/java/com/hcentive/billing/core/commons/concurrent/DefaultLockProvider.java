package com.hcentive.billing.core.commons.concurrent;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

public class DefaultLockProvider implements LockProvider {

	@Value(value = "${defaultTimeOut:10}")
	private Long defaultTimeOut;

	private final ConcurrentHashMap<Object, TargetObjAwareReentrantLock> lockRegistry = new ConcurrentHashMap<>();
	private static final Logger LOGGER = LoggerFactory
			.getLogger(DefaultLockProvider.class);

	@Override
	public Lock getLock(final Object obj){

		TargetObjAwareReentrantLock lock = lockRegistry.get(obj);
		if (lock == null) {
			LOGGER.debug("Creating Lock for Obj {} ", obj);
			lock = new TargetObjAwareReentrantLock(obj);
		}

		LOGGER.debug("Putting lock in registry  {}", obj);
		TargetObjAwareReentrantLock existingLock = lockRegistry.putIfAbsent(
				obj, lock);
		LOGGER.debug("Going to lock obj {} at {}", obj, new Date());

		return existingLock != null ? existingLock : lock;
	}

	@Override
	public void release(Lock lock) {
		if (lock instanceof TargetObjAwareReentrantLock) {
			releaseLockOf(((TargetObjAwareReentrantLock) lock).targetObj);
		}
	}

	@Override
	public boolean applyLock(Lock lock) throws InterruptedException {
		return lock.tryLock(defaultTimeOut, TimeUnit.SECONDS);
	}

	@Override
	public void releaseLockOf(Object obj) {
		LOGGER.debug("Releasing lock for Obj {}", obj);
		lockRegistry.remove(obj);
	}

	private class TargetObjAwareReentrantLock extends ReentrantLock {
		private final Object targetObj;

		public TargetObjAwareReentrantLock(Object targetObj) {
			super(true);
			this.targetObj = targetObj;
		}

		public Object targetObj() {
			return this.targetObj;
		}

		@Override
		public void unlock() {
			super.unlock();
			release(this);
		}
	}

}
