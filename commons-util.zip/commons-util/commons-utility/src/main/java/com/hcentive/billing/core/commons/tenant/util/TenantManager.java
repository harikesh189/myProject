package com.hcentive.billing.core.commons.tenant.util;

public interface TenantManager {

	public String getTenantId();

}
