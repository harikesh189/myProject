package com.hcentive.billing.core.commons.json;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <code>JsonResponse</code> annotation can be used on endpoint handler methods
 * of Spring Web controllers returning a JSON response. This annotation is used
 * to customize the JSON response created via Jackson Object Mapper by using
 * Jackson Mixins.
 * 
 * e.g. <code>
 * 
 * @JsonResponse(mixins = { @JsonMixin(target = BusinessEntity.class, mixin =
 *                      BEMixin.class),
 * @JsonMixin(target = Profile.class, mixin = ProfileMixin.class)}) public
 *                   BusinessEntity getBusinessEntity(String identity) { ... }
 *                   </code>
 * 
 * @author Dikshit.Luthra
 * 
 */

@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface JsonResponse {

	/**
	 * A list of Jackson Mixins.
	 */
	JsonMixin[] mixins() default {};

}