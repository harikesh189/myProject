/**
 * UGLII stands for Uniquely Generated Logical Indexing of Inventories..
 *
 */
package com.hcentive.billing.core.commons.uglii.algorithm;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author uttam.tiwari
 *
 */
public class UGLIIAlgo {
	private static final Logger LOGGER = LoggerFactory.getLogger(UGLIIAlgo.class);

	private static TimeTracker timeTracker = new TimeTracker();
	private static Semaphore semaphore = new Semaphore(1);

	public static String getReadableID() {
		String readableId = null;
		try {
			semaphore.acquire();
			LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(1));
			readableId = timeTracker.getTimeSinceTheStaringOfBaseQuarter();
		} catch (final InterruptedException e) {
			LOGGER.error("Failed to gnerate unique id. {}", e.getMessage());
			LOGGER.error(ExceptionUtils.getFullStackTrace(e));
		} finally {
			semaphore.release();
		}
		return readableId;
	}
}
