package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.Collection;

public class AggregatingCollectionIOU<O, A extends AsyncCallback<Collection<O>>> extends ResultCollectionIOU<Collection<O>, A, Collection<O>> {

	public AggregatingCollectionIOU(final Collection<O> collectionToCollectResultInto, final int resultCount) {
		super(new MultipleResultCollector<>(collectionToCollectResultInto), resultCount);
	}
}
