package com.hcentive.billing.core.commons.util;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;

public class PayloadWrapper<O> implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// The object desired by the listener 
	private O payload;
	
	// Identifier of the object desired by the listener. 
	// Can be populated in case sending the whole object is costly.
	private String identifier;
	
	// Extra information regarding the event.
	// Listener should be able to interpret the codes
	private Collection<EventCode> codes = new HashSet<>();
	
	public PayloadWrapper(O payload, String identifier) {
		super();
		this.payload = payload;
		this.identifier = identifier;
	}

	public O getPayload() {
		return payload;
	}

	public String getIdentifier() {
		return identifier;
	}

	public Collection<EventCode> getCodes() {
		return codes;
	}

	public void addAllCodes(Collection<EventCode> codes) {
		this.codes.addAll(codes);
	}
	
	public void addCode(EventCode code) {
		this.codes.add(code);
	}
	
	
}
