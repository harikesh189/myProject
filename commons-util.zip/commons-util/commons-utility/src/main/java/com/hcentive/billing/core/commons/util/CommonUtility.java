package com.hcentive.billing.core.commons.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

import org.apache.commons.validator.UrlValidator;

public class CommonUtility {

	private static final String accountNumberFormatter = "*******";
	private static final UrlValidator urlValidator = new UrlValidator();

	public enum Connection {
		HTTP, FTP,REST
	}

	public static String accountNumberFormatter(String accountNumber) {
		if (accountNumber == null) {
			return "0000";
		} else {
			if (accountNumber.length() > 4) {
				return accountNumberFormatter
						+ accountNumber.substring(accountNumber.length() - 4);
			}
			return accountNumberFormatter + accountNumber;
		}
	}

	/**
	 * Method to check if url is valid.
	 * 
	 * @param url
	 *            url
	 * @return boolean
	 */
	public static boolean isValidURL(final String url) {
		return urlValidator.isValid(url);
	}

	/**
	 * Format currency based on the Locale value
	 * 
	 * @param value
	 * @param locale
	 * @return
	 */
	public static String formatCurrencyValue(BigDecimal value, Locale locale) {

		NumberFormat fmt = NumberFormat.getCurrencyInstance(locale);
		return fmt.format(value);
	}

	// This method will remove all special characters and spaces ( if any) and
	// return plain number
	public static String convertToPlainNumber(String formattedNumber) {
		try {
			return formattedNumber.replaceAll("[a-zA-Z!@#$%^&*()_+={}\\-]", "");
		} catch (Exception e) {
			return formattedNumber;
		}

	}
}
