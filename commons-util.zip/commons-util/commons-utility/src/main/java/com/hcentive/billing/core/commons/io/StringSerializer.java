package com.hcentive.billing.core.commons.io;

import java.io.Serializable;

@SuppressWarnings("rawtypes")
public interface StringSerializer extends ISerializer<String> {
	String serialize(Serializable obj);

	Object deSerialize(String data, Class type);
}
