/**
 * 
 */
package com.hcentive.billing.core.commons.uglii.algorithm;

import java.util.Calendar;

/**
 * @author uttam.tiwari
 * 
 */
public class TimeTracker {

	private long baseTimeInMilli;
	private Calendar cal;

	public TimeTracker() {
		this.cal = Calendar.getInstance();

		cal.set(Calendar.MONTH, 0);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		// cal.set(Calendar.WEEK_OF_MONTH, 1);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		cal.set(Calendar.YEAR, 2000);
		this.baseTimeInMilli = cal.getTimeInMillis();
	}

	String getTimeSinceTheStaringOfBaseQuarter() {
		Calendar now = Calendar.getInstance();
		int currentQuarter = getquarterForTheMonth(now.get(Calendar.MONTH));
		int quarterFromStart = ((now.get(Calendar.YEAR) - cal
				.get(Calendar.YEAR)) * 4) + currentQuarter;
		long timeStamp = now.getTimeInMillis() - baseTimeInMilli;
		String ts = Converter.base10Tobase32(timeStamp);
		return "Q" + quarterFromStart + "-" + ts;
	}

	private static int getquarterForTheMonth(int month) {
		int quarter = (month / 3) + 1;
		return quarter;
	}

}
