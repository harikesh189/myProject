package com.hcentive.billing.core.commons.factory;

import java.util.HashMap;

import com.hcentive.billing.core.commons.beans.SpringBackedBeanRegistry;

public abstract class AbstractNamedArticleFactory<T extends IsNamedArticle>
		extends SpringBackedBeanRegistry<T> {

	private final HashMap<String, T> registry = new HashMap<String, T>();

	protected abstract Class<T> lookupForType();

	protected final void registerBean(T bean) {
		registry.put(bean.articleName(), bean);
	}

	public T get(Object articleName) {
		T obj = registry.get((String) articleName);
		if (obj == null) {
			throw new IllegalStateException("No class configured for Type : "
					+ (String) articleName);
		}
		return obj;
	}
}
