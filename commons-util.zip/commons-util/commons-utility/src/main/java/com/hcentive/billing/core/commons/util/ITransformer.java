package com.hcentive.billing.core.commons.util;

/**
 * <p>
 * Contract for transforming one object into another.
 * </p>
 * <p>
 * A <tt>Transformer</tt> converts an input object of one type to an output
 * object of another type. The input object should be left unchanged.
 * <p>
 * 
 * @param <K>
 *            The type of input objects to transform.
 * @param <V>
 *            The type of output objects.
 */
public interface ITransformer<K, V> {
	/**
	 * Transforms an object of one type into that of another.
	 * 
	 * @param input
	 *            The object to transform.
	 * @return The output object.
	 */
	V transform(K input);
}
