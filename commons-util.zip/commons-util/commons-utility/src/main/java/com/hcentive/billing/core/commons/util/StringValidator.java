package com.hcentive.billing.core.commons.util;

/**
 * Contains validation routines for text strings.
 */
public final class StringValidator {
	/**
	 * Gets whether two strings are the same, avoiding
	 * {@link NullPointerException}.
	 * 
	 * @param first
	 *            The first string to check.
	 * @param second
	 *            The second string to check.
	 * @return {@code true} if both {@code first} and {@code second} are not
	 *         {@code null} and equal.
	 */
	public static boolean equals(final String first, final String second) {
		return first != null && second != null && first.equals(second);
	}

	/**
	 * Gets whether two strings are the same ignoring the case, avoiding
	 * {@link NullPointerException}.
	 * 
	 * @param first
	 *            The first string to check.
	 * @param second
	 *            The second string to check.
	 * @return {@code true} if both {@code first} and {@code second} are not
	 *         {@code null} and equal ignoring case.
	 */
	public static boolean equalsIgnoreCase(final String first,
			final String second) {
		return first != null && second != null
				&& first.equalsIgnoreCase(second);
	}

	/**
	 * Gets whether a text string is blank, that is, it does not contain any
	 * printable characters.
	 * 
	 * @param text
	 *            The string to validate.
	 * @return <code>blank</code> if the string is blank, <code>false</code>
	 *         otherwise.
	 */
	public static Boolean isBlank(final String text) {
		return text == null || text.trim().equals("");
	}

	/**
	 * Gets whether a text string is empty, that is, it does not contain any
	 * characters.
	 * 
	 * @param text
	 *            The string to validate.
	 * @return <code>blank</code> if the string is empty, <code>false</code>
	 *         otherwise.
	 */
	public static Boolean isEmpty(final String text) {
		return text == null || text.equals("");
	}

	/**
	 * Gets whether a text string is not blank, that is, it contains at least
	 * one printable character.
	 * 
	 * @param text
	 *            The string to validate.
	 * @return <code>blank</code> if the string is not blank, <code>false</code>
	 *         otherwise.
	 */
	public static Boolean isNotBlank(final String text) {
		return !isBlank(text);
	}

	/**
	 * Gets whether a text string is not empty, that is, it contains at least
	 * one character.
	 * 
	 * @param text
	 *            The string to validate.
	 * @return <code>blank</code> if the string is not empty, <code>false</code>
	 *         otherwise.
	 */
	public static Boolean isNotEmpty(final String text) {
		return !isEmpty(text);
	}

	/**
	 * Prevent instantiation.
	 */
	private StringValidator() {
	}
}
