package com.hcentive.billing.core.commons.io;

import java.io.Serializable;

@SuppressWarnings("rawtypes")
public interface ISerializer<T> {
	T serialize(Serializable obj);
	
	Object deSerialize(T data, Class type);
}
