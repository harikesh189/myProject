package com.hcentive.billing.core.commons.method.step;

public abstract class SyncMethodStep<SD> extends MethodStep<SD> {

	public SyncMethodStep(SD sharedData, MethodStep<SD> nextStep) {
		super(sharedData, nextStep);
	}

	@Override
	public void execute() {
		executeStep();
		executeNextStep();
	}

	public abstract void executeStep();
	
}
