package com.hcentive.billing.core.commons.concurrent.promise;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AsyncIOU<O, CO> extends DefaultIOU<O, AsyncCallback<O>> implements AsyncCallback<CO> {

	private static Logger LOGGER = LoggerFactory.getLogger(AsyncIOU.class);

	@Override
	public final void onSuccess(final CO co) {
		try {
			final O o = this.onSuccessExecute(co);
			this.setResult(o);
		} catch (final Throwable t) {
			LOGGER.error("Error in success process [AsyncIOU]", t);
			this.setError(t);
		}

	}

	protected abstract O onSuccessExecute(CO co);

	@Override
	public void onError(final Throwable t) {
		this.setError(t);
	}

}
