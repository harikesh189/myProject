package com.hcentive.billing.core.commons.tags;

public interface TagMatcher {

	<C, T extends TagAware<C>> boolean match(T matchObj, T matchTo);

	boolean canHandle(MatchingStrategyType type);

}
