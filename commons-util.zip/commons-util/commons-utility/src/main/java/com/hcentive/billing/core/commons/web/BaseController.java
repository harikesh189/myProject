package com.hcentive.billing.core.commons.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseController {

	/**
	 * The sequence of characters to use as line break for the current runtime
	 * environment.
	 */
	public static final String LINEBREAK = System.getProperty("line.separator");

	private static Logger logger = LoggerFactory
			.getLogger(BaseController.class);

}
