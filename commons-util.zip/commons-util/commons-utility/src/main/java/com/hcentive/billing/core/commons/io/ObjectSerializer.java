package com.hcentive.billing.core.commons.io;

import java.io.Serializable;

public interface ObjectSerializer extends ISerializer<byte[]> {
	byte[] serialize(Serializable obj);

	Object deSerialize(byte[] data, Class type);
}
