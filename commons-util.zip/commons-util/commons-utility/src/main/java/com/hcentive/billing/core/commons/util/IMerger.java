package com.hcentive.billing.core.commons.util;

import com.hcentive.billing.core.commons.factory.IsForTask;

//FIXME Using implementation of this interface might be resulting in taller call stack. Can we not use static methods for the merging logic.
public interface IMerger<T> extends IsForTask {

	/**
	 * It merges the two same type of entity.
	 * 
	 * @param t1
	 *            First entity to merge
	 * @param t2
	 *            Second entity to merge
	 * @return Resultant merged entity.
	 */
	T merge(T t1, T t2);

	// boolean canHandle(Class<?> clazz);
}
