package com.hcentive.billing.core.commons.util;

public abstract class NumberUtil {
	/**
	 * Prevent instantiation.
	 */
	private NumberUtil() {
	}

	public static boolean inRange(final int numberToTest, final int lowerValue,
			final int upperValue) {
		return !notInRange(numberToTest, lowerValue, upperValue);
	}

	public static boolean notInRange(final int numberToTest,
			final int lowerValue, final int upperValue) {
		return numberToTest < lowerValue || numberToTest > upperValue ? true
				: false;
	}
}
