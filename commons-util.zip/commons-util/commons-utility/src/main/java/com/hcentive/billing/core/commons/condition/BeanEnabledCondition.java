package com.hcentive.billing.core.commons.condition;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.annotation.AnnotationAttributes;
import org.springframework.core.env.PropertyResolver;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class BeanEnabledCondition implements Condition{
	private static final Logger LOGGER = LoggerFactory.getLogger(BeanEnabledCondition.class);
		@Override
		public boolean matches(final ConditionContext context,
				final AnnotatedTypeMetadata metadata) {
			final AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(ConditionalOnBeanEnabled.class.getName()));
			final String key = attributes.getString(ConditionalOnBeanEnabled.FIELD_KEY);
			final boolean matchOnMissing = attributes.getBoolean(ConditionalOnBeanEnabled.FIELD_MATCH_ON_MISSING);
			PropertyResolver resolver = context.getEnvironment();
			if(resolver.containsProperty(key)){
				final String value = resolver.getProperty(key);
				LOGGER.debug("Condition for key {} resolved to :{}",key,value);
				return Boolean.parseBoolean(value);
			}else{
				return matchOnMissing;
			}
		}
}
