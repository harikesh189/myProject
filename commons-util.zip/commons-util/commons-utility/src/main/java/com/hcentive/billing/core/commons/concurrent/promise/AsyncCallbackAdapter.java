package com.hcentive.billing.core.commons.concurrent.promise;

public class AsyncCallbackAdapter<O> implements AsyncCallback<O> {

	@Override
	public void onSuccess(O o) {
	}

	@Override
	public void onError(Throwable t) {
		
	}

}
