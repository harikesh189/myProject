package com.hcentive.billing.core.commons.factory;

public interface Factory<T> {
	T get(Object o);

	Class<T> lookupForType();

}
