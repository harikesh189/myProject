package com.hcentive.billing.core.commons.beans;

import java.util.HashMap;
import java.util.Map;

import org.aspectj.util.LangUtil.ProcessController;


public abstract class CachingSpringBackedAbstractFactory<C,T,R> extends
		SpringBackedAbstractFactory<R> {

	
	private final Map<String,Map<C, T>> registry = new HashMap<>();
	
	public T get(String tenant, C lookupKey){
		final Map<C, T> t = this.registry.get(tenant);
		if(t==null || t.get(lookupKey)==null){
			return cacheAndResolve(tenant, lookupKey);
		}
		return t.get(lookupKey);
	}
	
	
	private T cacheAndResolve(final String tenant, final C lookupKey) {
		T t = resolveAndGet(lookupKey);
		 Map<C, T> map = this.registry.get(tenant);
		if(map==null){
			map=new HashMap<C,T>();
		}
		map.put(lookupKey, t);
		this.registry.put(tenant, map);
		return t;
	}


	protected abstract T resolveAndGet(C lookupKey);
}
