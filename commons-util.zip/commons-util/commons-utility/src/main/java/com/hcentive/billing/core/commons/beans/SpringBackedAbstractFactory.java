package com.hcentive.billing.core.commons.beans;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class SpringBackedAbstractFactory<T> extends SpringBackedBeanRegistry<T> {

	public static Logger logger = LoggerFactory.getLogger(SpringBackedAbstractFactory.class);
	private final Collection<T> matchedBeans = new ArrayList<T>();

	@Override
	protected void registerBean(final T bean) {
		this.matchedBeans.add(bean);
	}

	protected Collection<T> registeredInstances() {
		logger.trace("Matched Beans are:");
		for (final T t : this.matchedBeans) {
			logger.trace(t.getClass() + "");
		}
		return Collections.unmodifiableCollection(this.matchedBeans);
	}
}
