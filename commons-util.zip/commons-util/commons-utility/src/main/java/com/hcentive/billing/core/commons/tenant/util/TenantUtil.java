package com.hcentive.billing.core.commons.tenant.util;

import static com.hcentive.billing.core.commons.util.StringUtil.nullSafe;


public class TenantUtil {
	
	public static final String TENANT_KEY = "TENANT_KEY";
	private static final String SEPARATOR = "_";
	private static TenantManager tenantManager;

	public static void configure(final TenantManager tm) {
		tenantManager = tm;
	}

	public static String getTenantId() {
		return tenantManager != null ? tenantManager.getTenantId() : null;
	}


	public static StringBuilder getBuilderWithTenantIdPrefixed() {
		final StringBuilder builder = new StringBuilder();
		final String tenantId = nullSafe(TenantUtil.getTenantId());
		builder.append(tenantId).append(SEPARATOR);
		return builder;
	}
}
