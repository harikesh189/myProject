package com.hcentive.billing.core.commons.util;

import java.text.NumberFormat;
import java.util.Locale;

public class AmountFormatter {

	public static String usCurrencyFormatter(Double amount) {
		Locale inLocale = new Locale("en", "US");
		NumberFormat fmt = NumberFormat.getCurrencyInstance(inLocale);
		return fmt.format(amount);
	}
}
