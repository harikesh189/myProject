package com.hcentive.billing.core.commons.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.time.DateUtils;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.springframework.util.Assert;

import com.hcentive.billing.core.commons.enumeration.RoundingMode;

public class DateUtility {

	public static final String MM_DD_YYYY = "MM/dd/yyyy";
	public static final String YYYY_MM_DD = "yyyy/MM/dd";
	public static final String MM_DD_YYYY_HH_MM_SS = "MM/dd/yyyy HH:mm:ss";
	public static final String MM_DD_YYYY_H_MM_SS = "MM/dd/yyyy H:mm:ss";
	public static final String DAY_START_TIME = " 00:00:00";
	public static final String DAY_END_TIME = " 23:59:59";

	public static Date clearTime(Date date) {

		final Calendar newDate = Calendar.getInstance();
		newDate.setTime(date);

		newDate.set(Calendar.HOUR_OF_DAY, 0);
		newDate.set(Calendar.MINUTE, 0);
		newDate.set(Calendar.SECOND, 0);
		newDate.set(Calendar.MILLISECOND, 0);

		return newDate.getTime();
	}

	public static String convertDateStringToDayEndingDateString(String endDate) {
		return endDate != null ? endDate + DAY_END_TIME : null;
	}

	public static String convertDateStringToDayStartingDateString(String startDate) {
		return startDate != null ? startDate + DAY_START_TIME : null;
	}

	public static final String convertDateToString(Date date, String format) {
		final SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		if (date != null) {
			return dateFormat.format(date);
		} else {
			return null;
		}
	}

	public static Date convertStringToDate(String date, String format) {
		try {
			final SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.parse(date);
		} catch (final ParseException e) {
			return null;
		}
	}

	public static Date convertStringToDate(String date, String format, boolean isLenient) {
		try {
			final SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			dateFormat.setLenient(isLenient);
			final Date parsedDate = dateFormat.parse(date);

			return parsedDate;
		} catch (final Exception e) {
			return null;
		}
	}

	public static int daysInMonthAfter(Date date, boolean inclusive) {

		if (date == null) {
			throw new IllegalArgumentException("[date] should not be null");
		}

		final Calendar calDt = Calendar.getInstance();
		calDt.setTime(date);
		return calDt.getActualMaximum(Calendar.DAY_OF_MONTH) - calDt.get(Calendar.DAY_OF_MONTH) + (inclusive ? 1 : 0);
	}

	public static int daysInMonthBefore(Date date, boolean inclusive) {

		if (date == null) {
			throw new IllegalArgumentException("[date] should not be null");
		}

		final Calendar calDt = Calendar.getInstance();
		calDt.setTime(date);
		return calDt.get(Calendar.DAY_OF_MONTH) - (inclusive ? 0 : 1);
	}

	public static final SimpleDateFormat defaultDateFormat() {
		return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
	}

	public static int differenceInDays(final Calendar to, final Calendar from) {
		final LocalDate d1 = new LocalDate(to.getTimeInMillis());
		final LocalDate d2 = new LocalDate(from.getTimeInMillis());
		final Days daysBetween = Days.daysBetween(d2, d1);
		return daysBetween.getDays();

	}

	public static Date getFromDate(String date) {
		try {
			final SimpleDateFormat dateFormat = new SimpleDateFormat(MM_DD_YYYY);
			return dateFormat.parse(date);
		} catch (final ParseException e) {
			return null;
		}
	}

	public static Date getToDate(String date) {
		try {
			final SimpleDateFormat dateFormat = new SimpleDateFormat(MM_DD_YYYY);
			final Date parsedDate = dateFormat.parse(date);
			parsedDate.setTime(parsedDate.getTime() + TimeUnit.MILLISECONDS.convert(1, TimeUnit.DAYS) - 1);
			return parsedDate;
		} catch (final ParseException e) {
			return null;
		}
	}

	public static boolean isLeapYear(int year) {
		return new GregorianCalendar().isLeapYear(year);
	}

	public static boolean isMonthEndDate(Date date) {

		if (date == null) {
			throw new IllegalArgumentException("[date] should not be null");
		}

		final Calendar calDt = Calendar.getInstance();
		calDt.setTime(date);

		return calDt.get(Calendar.DAY_OF_MONTH) == calDt.getActualMaximum(Calendar.DAY_OF_MONTH);
	}

	public static boolean isMonthStartDate(Date date) {

		if (date == null) {
			throw new IllegalArgumentException("[date] should not be null");
		}

		final Calendar calDt = Calendar.getInstance();
		calDt.setTime(date);

		return calDt.get(Calendar.DAY_OF_MONTH) == 1;
	}

	public static boolean isSameDay(Date date1, Date date2) {

		if (date1 == null || date2 == null) {
			return false;
		}

		final Calendar calDate1 = Calendar.getInstance();
		calDate1.setTime(date1);

		final Calendar calDate2 = Calendar.getInstance();
		calDate2.setTime(date2);

		return DateUtils.isSameDay(calDate1, calDate2);
	}

	public static int numberOfDays(Date startDate, Date endDate) {

		if (startDate == null || endDate == null) {
			throw new IllegalArgumentException("[startDate] and [endDate] should not be null");
		}

		if (startDate.after(endDate)) {
			throw new IllegalArgumentException("[startDate] cannot be after [endDate]");
		}

		final long startDateTime = startDate.getTime();
		final long endDateTime = endDate.getTime();
		final long milPerDay = 1000 * 60 * 60 * 24;

		// calculate duration in days
		final int numOfDays = (int) ((endDateTime - startDateTime) / milPerDay);

		return numOfDays + 1; // add one day to include start date in interval
	}

	public static int numberOfMonths(Date startDate, Date endDate) {

		if (startDate.after(endDate)) {
			throw new IllegalArgumentException("[startDate] cannot be after [endDate]");
		}

		final Calendar startDt = Calendar.getInstance();
		startDt.setTime(startDate);

		final Calendar endDt = Calendar.getInstance();
		endDt.setTime(endDate);

		final int startMon = startDt.get(Calendar.MONTH);
		final int endMon = endDt.get(Calendar.MONTH);

		final int startYr = startDt.get(Calendar.YEAR);
		final int endYr = endDt.get(Calendar.YEAR);

		return (endYr - startYr) * 12 + endMon - startMon + 1;
	}

	public static Date offsetDays(Date baseDate, int offsetDays) {
		final Calendar dueDate = Calendar.getInstance();
		dueDate.setTime(baseDate);

		dueDate.add(Calendar.DAY_OF_MONTH, offsetDays);
		return dueDate.getTime();
	}

	public static Date round(Date date, RoundingMode roundingMode) {
		Assert.notNull(date, "Invalild date");
		Assert.notNull(roundingMode, "Rounding not specified");
		if (roundingMode == RoundingMode.DAY_END) {
			return roundAtDayEnd(date);
		}
		return roundAtDayStart(date);
	}

	public static Date roundAtDayEnd(Date date) {
		Assert.notNull(date, "Invalild date");
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
	}

	public static Date roundAtDayStart(Date date) {
		Assert.notNull(date, "Invalild date");
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}
	
	public static Date getDateByDayAndMonth(int day, int month) {
		final Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_MONTH, day);
		calendar.set(Calendar.MONTH, month);
		return roundAtDayStart(calendar.getTime());
	}
	
	public static Date setDayOfMonthBoundByMonthEnd(Date in, int day) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(in);
		int monthMax = calendar.getActualMaximum(Calendar.DATE);
		
		 System.out.println(monthMax);
		if (day > monthMax) {
			day = monthMax;
		}
		calendar.set(Calendar.DATE, day);
		return calendar.getTime();
	}
	
	public static int getLastDayOfMonth(Date date) {
		final Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.getActualMaximum(Calendar.DATE);
	}
	
	public static XMLGregorianCalendar toXmlGregorianCalendar(final Date date) {
		try {
			final GregorianCalendar calendar = new GregorianCalendar();
			calendar.setTimeInMillis(date.getTime());
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
		} catch (final DatatypeConfigurationException ex) {
		}
		return null;
	}
	
	public static XMLGregorianCalendar toXmlGregorianCalendar(final long date) {
		try {
			final GregorianCalendar calendar = new GregorianCalendar();
			calendar.setTimeInMillis(date);
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
		} catch (final DatatypeConfigurationException ex) {
		}
		return null;
	}
	
	public static Date toDateFromXMLGregorianCalendar(XMLGregorianCalendar xmlGC) {
		if(xmlGC == null) {
			return null;
		} else {
			return xmlGC.toGregorianCalendar().getTime();
		}
	}
	
	public static void main(String[] args) {
		Date dt = Calendar.getInstance().getTime();
		System.out.println("Inside DateUtility main method");
		System.out.println(DateUtility.setDayOfMonthBoundByMonthEnd(dt, 32));
	}
	
}
