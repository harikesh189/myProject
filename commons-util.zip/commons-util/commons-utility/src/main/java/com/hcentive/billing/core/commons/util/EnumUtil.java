package com.hcentive.billing.core.commons.util;

public class EnumUtil {

	@SuppressWarnings("unchecked")
	public static String fullyQualifiedName(final Enum<?> enumValue) {
		return enumValue.getClass().getName()
				+ "."
				+ Enum.valueOf((Class<Enum>) enumValue.getClass(),
						enumValue.name());
	}
}
