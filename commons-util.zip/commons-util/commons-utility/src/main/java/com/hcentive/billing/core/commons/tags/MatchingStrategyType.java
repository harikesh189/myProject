package com.hcentive.billing.core.commons.tags;

public enum MatchingStrategyType {
	EXACT, SUBSET, SUPERSET, INTERSECT
}
