package com.hcentive.billing.core.commons.concurrent;

import java.util.concurrent.locks.Lock;

public interface LockProvider {

	public Lock getLock(Object obj);

	public void release(Lock lock);

	public void releaseLockOf(Object obj);

	boolean applyLock(Lock lock) throws InterruptedException;
}
