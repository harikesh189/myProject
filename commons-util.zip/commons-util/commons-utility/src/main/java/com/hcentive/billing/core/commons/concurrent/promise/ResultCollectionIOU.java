package com.hcentive.billing.core.commons.concurrent.promise;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * It represent the IOU that collects(aggregate) result from other multiple
 * ious.
 * 
 * @author nitin.singla
 *
 * @param <O>
 *            The type of aggregated result expected from this iou.
 * @param <A>
 *            It represent type of iou whose result has to be collected by this
 *            iou.
 * @param <CO>
 *            The type of result returned from other iou whose result is
 *            collected by this iou.
 */
public class ResultCollectionIOU<O, A extends AsyncCallback<O>, CO> extends DefaultIOU<O, A> implements AsyncCallback<CO> {

	final protected ResultCollector<CO, O> resultCollector;

	final protected Lock lock;

	private final AtomicInteger resultCounter;

	public ResultCollectionIOU(final ResultCollector<CO, O> resultCollector, final int resultCount) {
		this.resultCollector = resultCollector;
		this.resultCounter = new AtomicInteger(resultCount);
		this.lock = new ReentrantLock();
		this.checkAndSetResult();
	}

	/**
	 * It adds the iou whose result has to be collected by this iou.
	 * 
	 * @param iou
	 *            The iou whose result has to be collected by this iou.
	 */
	public void addIOU(final IOU<CO, AsyncCallback<CO>> iou) {
		iou.set(this);
	}

	@Override
	public void onSuccess(final CO o) {
		try {
			this.lock.lock();
			this.collectResult(o);
			this.resultCounter.decrementAndGet();
			this.checkAndSetResult();
		} finally {
			this.lock.unlock();
		}
	}

	/**
	 * It performs the result aggregation from including ious whose result has
	 * to be collected.
	 */
	protected void checkAndSetResult() {
		if (this.resultCounter.get() == 0) {
			this.setResult(this.resultCollector.collectedResult());
		}
	}

	/**
	 * It return the
	 * 
	 * @param o
	 */
	protected void collectResult(final CO o) {
		this.resultCollector.collect(o);
	}

	@Override
	public void onError(final Throwable t) {
		try {
			this.lock.lock();
			this.resultCounter.decrementAndGet();
			this.setError(t);
		} finally {
			this.lock.unlock();
		}

		// TODO: handle properly - error condition
	}

	public static class MultipleResultCollector<R> implements ResultCollector<Collection<R>, Collection<R>> {
		private final Collection<R> collectedResult;

		public MultipleResultCollector(final Collection<R> collectedResult) {
			this.collectedResult = collectedResult;
		}

		@Override
		public Collection<R> collectedResult() {
			return this.collectedResult;
		}

		@Override
		public void collect(final Collection<R> result) {
			this.collectedResult.addAll(result);
		}

		@Override
		public int size() {
			return this.collectedResult.size();
		}
	}

	public static class SingleResultCollector<R> implements ResultCollector<R, Collection<R>> {
		private final Collection<R> collectedResult;

		public SingleResultCollector(final Collection<R> collectedResult) {
			super();
			this.collectedResult = collectedResult;
		}

		@Override
		public void collect(final R result) {
			this.collectedResult.add(result);
		}

		@Override
		public Collection<R> collectedResult() {
			return this.collectedResult;
		}

		@Override
		public int size() {
			return this.collectedResult.size();
		}
	}

}
