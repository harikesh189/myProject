package com.hcentive.billing.core.commons.util;

import java.util.Arrays;
import java.util.List;

/**
 * Contains utility methods for working with {@link String}s.
 */
public final class StringUtil {
	/**
	 * The default set of characters used for splitting text strings.
	 */
	public static final String DEFAULT_DELIMITERS = ",|;| |\\n|\\r";

	/**
	 * Prevent instantiation.
	 */
	private StringUtil() {
	}

	/**
	 * Finds the index of the first digit in a text string, starting from the
	 * beginning of the string.
	 * 
	 * @param text
	 *            The text string to search.
	 * @return The zero-based index of the first digit in the string, if the
	 *         string contains any digits, {@code -1} otherwise.
	 */
	public static int indexOfDigit(final String text) {
		return indexOfDigit(text, 0);
	}

	/**
	 * Finds the index of the first digit in a text string, starting from a
	 * specified position in the string.
	 * 
	 * @param text
	 *            The text string to search.
	 * @param start
	 *            The zero-based position at which to start the search.
	 * @return The zero-based index of the first digit in the string, if the
	 *         string contains any digits, {@code -1} otherwise.
	 */
	public static int indexOfDigit(final String text, final int start) {
		int index = -1;

		if (text != null && start >= 0 && start <= text.length()) {
			for (int i = start; i < text.length(); ++i) {
				if (Character.isDigit(text.charAt(i))) {
					index = i;
					break;
				}
			}
		}

		return index;
	}

	/**
	 * Finds the index of the first letter in a text string, starting from the
	 * beginning of the string.
	 * 
	 * @param text
	 *            The text string to search.
	 * @return The zero-based index of the first letter in the string, if the
	 *         string contains any letters, {@code -1} otherwise.
	 */
	public static int indexOfLetter(final String text) {
		return indexOfLetter(text, 0);
	}

	/**
	 * Finds the index of the first letter in a text string, starting from a
	 * specified position in the string.
	 * 
	 * @param text
	 *            The text string to search.
	 * @param start
	 *            The zero-based position at which to start the search.
	 * @return The zero-based index of the first letter in the string, if the
	 *         string contains any letters, {@code -1} otherwise.
	 */
	public static int indexOfLetter(final String text, final int start) {
		int index = -1;

		if (text != null && start >= 0 && start <= text.length()) {
			for (int i = start; i < text.length(); ++i) {
				if (Character.isLetter(text.charAt(i))) {
					index = i;
					break;
				}
			}
		}

		return index;
	}

	public static String nullSafe(final String str1) {
		return nullSafe(str1, "");
	}

	public static String nullSafe(final String str1, final String defaultString) {
		return str1 == null ? defaultString : str1;
	}

	/**
	 * Splits a text string on common punctuation marks - commas, semi-colons,
	 * spaces, newlines and carriage returns.
	 * 
	 * @param text
	 *            The text string to split.
	 * @return A {@link List} of {@link String}s.
	 */
	public static List<String> split(final String text) {
		return split(text, DEFAULT_DELIMITERS);
	}

	/**
	 * Splits a text string on specified characters.
	 * 
	 * @param text
	 *            The text string to split.
	 * @param splitters
	 *            The characters at which to split the text string.
	 * @return A {@link List} of {@link String}s.
	 */
	public static List<String> split(final String text, final String splitters) {
		return Arrays.asList(text.split(splitters));
	}

	/**
	 * Capitalizes the first character of every sentence in the text.
	 * 
	 * @param text
	 *            A {@link String} to convert to sentence case.
	 * @return The text converted to sentence case.
	 */
	public static String toSentenceCase(final String text) {
		if (StringValidator.isBlank(text)) {
			return text;
		}

		final StringBuilder buffer = new StringBuilder(text.trim()
				.toLowerCase());

		// Set a flag to indicate that the first character in the text should
		// be capitalized.
		boolean capitalize = true;
		for (int i = 0; i < buffer.length(); ++i) {
			if (capitalize) {
				// If the next available character needs to be capitalized, skip
				// all the leading whitespace characters and sentence
				// delimiters.
				while (i < buffer.length()
						&& (Character.isWhitespace(buffer.charAt(i))
								|| buffer.charAt(i) == '.'
								|| buffer.charAt(i) == '?' || buffer.charAt(i) == '!')) {
					++i;
				}

				if (i < buffer.length()) {
					// Check if the current character is a letter.
					if (Character.isLetter(buffer.charAt(i))) {
						// Capitalize the character.
						buffer.setCharAt(i,
								Character.toUpperCase(buffer.charAt(i)));
					}

					capitalize = false;
				}
			} else {
				// Skip until the next full-stop (period), question mark or
				// exclamation mark.
				while (i < buffer.length() && buffer.charAt(i) != '.'
						&& buffer.charAt(i) != '?' && buffer.charAt(i) != '!') {
					++i;
				}

				capitalize = true;
			}
		}

		return buffer.toString();
	}

	/**
	 * Capitalizes the first character of every word in the text.
	 * 
	 * @param text
	 *            A {@link String} to convert to title case.
	 * @return The text converted to title case.
	 */
	public static String toTitleCase(final String text) {
		if (StringValidator.isBlank(text)) {
			return text;
		}

		final StringBuilder buffer = new StringBuilder(text.trim()
				.toLowerCase());

		// Set a flag to indicate that the first character in the text should
		// be capitalized.
		boolean capitalize = true;
		for (int i = 0; i < buffer.length(); ++i) {
			if (capitalize) {
				// If the next available character needs to be capitalized, skip
				// all the leading whitespace characters and sentence
				// delimiters.
				while (i < buffer.length()
						&& (Character.isWhitespace(buffer.charAt(i))
								|| buffer.charAt(i) == '.'
								|| buffer.charAt(i) == '?' || buffer.charAt(i) == '!')) {
					++i;
				}

				if (i < buffer.length()) {
					// Check if the current character is a letter.
					if (Character.isLetter(buffer.charAt(i))) {
						// Capitalize the character.
						buffer.setCharAt(i,
								Character.toUpperCase(buffer.charAt(i)));
					}

					capitalize = false;
				}
			} else {
				// Skip until the next full-stop (period), question mark or
				// exclamation mark.
				while (i < buffer.length()
						&& !Character.isWhitespace(buffer.charAt(i))
						&& buffer.charAt(i) != '.' && buffer.charAt(i) != '?'
						&& buffer.charAt(i) != '!') {
					++i;
				}

				capitalize = true;
			}
		}

		return buffer.toString();
	}

	/**
	 * Trims whitespaces from both ends of a {@link String} text, ensuring that
	 * {@code NullPointerException} is not thrown.
	 * 
	 * @param text
	 *            The text to trim.
	 * @return Trimmed text if {@code text} is not {@code null}, otherwise
	 *         {@code null}.
	 */
	public static String trim(final String text) {
		return text != null ? text.trim() : text;
	}

	/**
	 * Trims whitespaces from both ends of a {@link String} text, ensuring that
	 * {@code NullPointerException} is not thrown. Then, trims the resulting
	 * text to a maximum specified length.
	 * 
	 * @param text
	 *            The text to trim.
	 * @param length
	 *            The maximum length of the trimmed text.
	 * @return Trimmed text if {@code text} is not {@code null}, otherwise
	 *         {@code null}.
	 */
	public static String trim(final String text, final int length) {
		String result = trim(text);

		if (length >= 0 && result != null && result.length() > length) {
			result = result.substring(0, length);
		}

		return result;
	}
}
