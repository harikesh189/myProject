package com.hcentive.billing.core.commons.otp;

import java.util.Calendar;

import org.springframework.stereotype.Component;

@Component
public class OTPProviderImpl implements OTPProvider {

	@Override
	public long generateOTP() {
		Calendar lCDateTime = Calendar.getInstance();
		return lCDateTime.getTimeInMillis();
	}

}
