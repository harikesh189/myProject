package com.hcentive.billing.core.commons.xml;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JAXBContextRegistry {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(JAXBContextRegistry.class);
	private static transient final Map<Class, JAXBContext> registry = new HashMap<>();

	private static transient Semaphore semaphore = new Semaphore(1);

	public static JAXBContext getContext(Class type) {
		final JAXBContext context = registry.get(type);
		LOGGER.debug("Jaxb context for class type {} is {}", type, context);
		return context != null ? context : createAndGetContext(type);
	}

	private static JAXBContext createAndGetContext(final Class type) {
		LOGGER.debug("Inside method createAndGetContext for type {} ", type);
		try {
			semaphore.acquire();
			JAXBContext context = registry.get(type);
			LOGGER.debug("Jaxb context for class type {} is {}", type, context);
			if (context == null) {
				context = JAXBContext.newInstance(type);
				LOGGER.debug("Jaxb context for class type {} created", type);
				registry.put(type, context);
				return context;
			} else {
				return context;
			}
		} catch (InterruptedException e) {
			LOGGER.error("InterruptedException occured ::", e);
		} catch (JAXBException e) {
			throw new RuntimeException(e);
		} finally {
			semaphore.release();
		}
		return null;
	}
}