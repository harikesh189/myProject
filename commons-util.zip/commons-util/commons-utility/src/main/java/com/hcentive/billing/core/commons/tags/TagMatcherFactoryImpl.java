package com.hcentive.billing.core.commons.tags;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;

@Component
public class TagMatcherFactoryImpl extends
		SpringBackedAbstractFactory<TagMatcher> implements TagMatcherFactory {

	private static final Logger logger = LoggerFactory
			.getLogger(TagMatcherFactoryImpl.class);

	@Override
	protected Class<TagMatcher> lookupForType() {
		return TagMatcher.class;
	}

	@Override
	public TagMatcher getMatcher(MatchingStrategyType type) {

		for (TagMatcher matcher : registeredInstances()) {
			if (matcher.canHandle(type)) {
				return matcher;
			}
		}

		logger.error("No tag matcher found for matching strategy: {}", type);
		throw new IllegalStateException(
				"No tag matcher found for matching strategy: " + type);
	}

}
