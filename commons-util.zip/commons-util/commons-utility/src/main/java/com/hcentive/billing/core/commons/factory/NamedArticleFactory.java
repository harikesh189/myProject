package com.hcentive.billing.core.commons.factory;

public class NamedArticleFactory<T extends IsNamedArticle> extends
		AbstractNamedArticleFactory<T> implements Factory<T> {

	public Class<T> lookupForType() {
		return this.lookupForType;
	}

	private final Class<T> lookupForType;

	public NamedArticleFactory(final Class<T> lookupForType) {
		super();
		this.lookupForType = lookupForType;
	}

}
