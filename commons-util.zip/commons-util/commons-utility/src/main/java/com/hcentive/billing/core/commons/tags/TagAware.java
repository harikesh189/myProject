package com.hcentive.billing.core.commons.tags;

import java.util.Collection;

public interface TagAware<T> {

	Collection<T> tags();

}
