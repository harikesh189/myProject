package com.hcentive.billing.core.commons.json;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;

@Component
public class CustomJsonSerializerRegisterer {

	@Autowired
	private RequestMappingHandlerAdapter adapter;

	@PostConstruct
	public void registerCustomJsonHandler() throws Exception {
		List<HandlerMethodReturnValueHandler> myHandlers = new ArrayList<>();
		for (HandlerMethodReturnValueHandler handler : adapter
				.getReturnValueHandlers()) {
			if (handler instanceof RequestResponseBodyMethodProcessor) {
				CustomJsonReturnValueHandler decorator = new CustomJsonReturnValueHandler(
						handler);
				myHandlers.add(decorator);
			} else
				myHandlers.add(handler);
		}
		adapter.setReturnValueHandlers(myHandlers);
	}

}