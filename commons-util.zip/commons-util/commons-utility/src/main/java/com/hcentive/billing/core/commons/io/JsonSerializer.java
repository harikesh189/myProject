package com.hcentive.billing.core.commons.io;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonSerializer implements StringSerializer {

	private static final Logger LOGGER = LoggerFactory.getLogger(JsonSerializer.class);

	private ObjectMapper objectMapper = new ObjectMapper();

	public JsonSerializer() {
		objectMapper = new ObjectMapper();
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	}

	@Override
	public String serialize(Serializable obj) {
		if (obj != null) {
			try {
				return objectMapper.writeValueAsString(obj);
			} catch (Exception e) {
				LOGGER.error("Failed to serialize object of type {}", obj.getClass().getName());
				LOGGER.error("Failed to serialize object of type " + obj.getClass().getName(), e);
				throw new RuntimeException("Failed to serialize object of type " + obj.getClass().getName(), e);
			}
		} else {
			throw new IllegalArgumentException("Failed to serialize object");
		}
	}

	@Override
	public Object deSerialize(String data, Class type) {
		if (data != null) {
			try {
				return (Object) objectMapper.readValue(data, type);
			} catch (Exception e) {
				LOGGER.error("Failed to deSerialize object");
				throw new RuntimeException("Failed to deSerialize object", e);
			}
		} else {
			throw new IllegalArgumentException("Failed to serialize object");
		}
	}

}
