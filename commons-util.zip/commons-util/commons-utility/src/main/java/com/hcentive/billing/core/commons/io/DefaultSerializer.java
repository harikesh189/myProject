package com.hcentive.billing.core.commons.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("rawtypes")
public class DefaultSerializer implements ObjectSerializer {

	private static final int ONE_KB = 1024;
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultSerializer.class);

	@Override
	public byte[] serialize(Serializable obj) {
		if (obj != null) {
			ByteArrayOutputStream b = new ByteArrayOutputStream(ONE_KB);
			try (ObjectOutputStream o = new ObjectOutputStream(b)) {
				o.writeObject(obj);
				return b.toByteArray();
			} catch (Exception e) {
				LOGGER.error("Failed to serialize object of type {}", obj.getClass().getName());
				throw new RuntimeException("Failed to serialize object of type " + obj.getClass().getName(), e);
			}
		} else {
			throw new IllegalArgumentException("Failed to serialize object");
		}
	}

	@Override
	public Object deSerialize(byte[] data, Class type) {
		if (data != null) {
			ByteArrayInputStream b = new ByteArrayInputStream(data);
			try (ObjectInputStream o = new ObjectInputStream(b);) {
				return o.readObject();
			} catch (Exception e) {
				LOGGER.error("Failed to deSerialize object");
				throw new RuntimeException("Failed to deSerialize object", e);
			}
		} else {
			throw new IllegalArgumentException("Failed to serialize object");
		}
	}

}
