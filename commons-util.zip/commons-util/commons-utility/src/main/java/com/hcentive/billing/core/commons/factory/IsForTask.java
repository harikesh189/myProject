package com.hcentive.billing.core.commons.factory;

public interface IsForTask<T> {
	public boolean canHandle(T type);
}
