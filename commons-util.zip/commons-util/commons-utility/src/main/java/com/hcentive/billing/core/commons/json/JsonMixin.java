package com.hcentive.billing.core.commons.json;

import java.io.Serializable;

public @interface JsonMixin {
	public Class<? extends Serializable> target();

	public Class<?> mixin();
}