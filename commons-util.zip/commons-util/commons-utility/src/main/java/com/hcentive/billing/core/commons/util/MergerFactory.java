package com.hcentive.billing.core.commons.util;

public interface MergerFactory {
	public IMerger getMerger(final Object entityToMerge);
}
