package com.hcentive.billing.core.commons.util;

import static com.hcentive.billing.core.commons.util.StringValidator.isNotBlank;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.util.Assert;

/**
 * Contains utility methods for working with collections.
 */
public final class CollectionUtil {

	private static final String DEFAULT_SEPERATOR = ",";

	/**
	 * Checks if two collections do not contain the same elements.
	 * @param a The first collection.
	 * @param b The second collection.
	 * @return {@code true} if the collections do not contain the same elements.
	 */
	public static <K> boolean areNotSame(final Collection<K> a, final Collection<K> b) {
		return !areSame(a, b);
	}

	/**
	 * Checks if two collections contain the same elements.
	 * @param a The first collection.
	 * @param b The second collection.
	 * @return {@code true} if both collections contain the same elements.
	 */
	public static <K> boolean areSame(final Collection<K> a, final Collection<K> b) {
		return a != null && b != null && (a == b || a.size() == b.size() && a.containsAll(b));
	}

	/**
	 * Transforms all elements from the input collection with the given transformer and return them as a {@link List}
	 * <p>
	 * If input elements is null or blank collection then it returns a blank {@link List}
	 * @param transformer The transformer to use, must not be null
	 * @param elements The elements to get the input from, may be null
	 * @return The {@link List} of elements obtained by after applying transformer on each element of given input collection.
	 */
	public static <K, V> List<V> asList(final ITransformer<K, V> transformer, final Collection<? extends K> elements) {
		if (transformer == null) {
			throw new IllegalArgumentException("Argument transformer cannot be null.");
		}

		final List<V> result = new ArrayList<V>();
		if (isNotEmpty(elements)) {
			for (final K element : elements) {
				result.add(transformer.transform(element));
			}
		}

		return result;
	}

	/**
	 * Transforms all elements from the input array with the given transformer and return them as a {@link List}
	 * <p>
	 * If input elements is null or blank array then it returns a blank {@link List}
	 * @param transformer the transformer to use, must not be null
	 * @param elements The elements to get the input from, may be null
	 * @return The {@link List} of elements obtained by after applying transformer on each element of given input collection.
	 */
	@SuppressWarnings("unchecked")
	public static <K, V> List<V> asList(final ITransformer<K, V> transformer, final K... elements) {
		if (transformer == null) {
			throw new IllegalArgumentException("Argument transformer cannot be null.");
		}

		final List<V> result = new ArrayList<V>();
		for (final K element : asList(elements)) {
			result.add(transformer.transform(element));
		}

		return result;
	}

	/**
	 * Converts an array into List. If input array is null then it returns an empty list.
	 * @param elements Array of elements to be converted into {@link List}
	 * @return {@link List} of elements in array.
	 */
	@SafeVarargs
	public static <T> List<T> asList(final T... elements) {
		final List<T> result = new ArrayList<T>();
		if (isNotEmpty(elements)) {
			for (final T element : elements) {
				result.add(element);
			}
		}
		return result;
	}

	/**
	 * Transforms all elements from the input collection into a {@link Map} of key and value where key is obtained by transforming collection element using key
	 * transformer and value is obtained by transforming collection element using value transformer.
	 * <p>
	 * If input elements is null or blank collection then it returns a blank {@link Map}
	 * @param elements The elements to get the input from, may be null.
	 * @param keyTransformer The transformer to use, must not be null. It converts elements of input collection in to key against which element has to be added
	 *            in the map to be returned.
	 * @param valueTransformer The transformer to use, must not be null. It converts elements of input collection in to value which has to stored in the map.
	 * @return The {@link Map} of key and value where key is obtained by transforming collection element using key transformer and value is obtained by
	 *         transforming collection element using value transformer.
	 */
	public static <K, V, E> Map<K, V> asMap(final Collection<E> elements, final ITransformer<E, K> keyTransformer, final ITransformer<E, V> valueTransformer) {
		if (keyTransformer == null) {
			throw new IllegalArgumentException("Argument key transformer cannot be null.");
		}
		if (valueTransformer == null) {
			throw new IllegalArgumentException("Argument value transformer cannot be null.");
		}

		Map<K, V> resultMap = new HashMap<K, V>();
		if (CollectionUtil.isNotEmpty(elements)) {
			resultMap = new HashMap<K, V>(elements.size());
			for (final E e : elements) {
				resultMap.put(keyTransformer.transform(e), valueTransformer.transform(e));
			}
		}
		return resultMap;
	}

	/**
	 * Transforms all elements from the input collection with the given transformer to covert in to key and add this key and element pair in map to be returned.
	 * <p>
	 * If input elements is null or blank collection then it returns a blank {@link Map}
	 * @param elements The elements to get the input from, may be null.
	 * @param transformer the transformer to use, must not be null. It converts elements of input collection in to key against which element has to be added in
	 *            the map to be returned.
	 * @return The {@link Map} of key and elements where key is obtained after applying transformer on each element of given input collection.
	 */
	public static <K, V, E extends K> Map<V, E> asMap(final Collection<E> elements, final ITransformer<K, V> transformer) {
		if (transformer == null) {
			throw new IllegalArgumentException("Argument transformer cannot be null.");
		}

		Map<V, E> resultMap = new HashMap<V, E>();
		if (CollectionUtil.isNotEmpty(elements)) {
			resultMap = new HashMap<V, E>(elements.size());
			for (final E e : elements) {
				resultMap.put(transformer.transform(e), e);
			}
		}
		return resultMap;
	}

	/**
	 * Transforms all elements from the input collection with the given transformer and return them as a {@link Set}
	 * <p>
	 * If input elements is null or blank collection then it returns a blank {@link Set}
	 * @param transformer The transformer to use, must not be null
	 * @param elements The elements to get the input from, may be null
	 * @return The {@link Set} of elements obtained by after applying transformer on each element of given input collection.
	 */
	public static <K, V> Set<V> asSet(final ITransformer<K, V> transformer, final Collection<? extends K> elements) {
		if (transformer == null) {
			throw new IllegalArgumentException("Argument transformer cannot be null.");
		}

		if (isNotEmpty(elements)) {
			final Set<V> result = new HashSet<V>(elements.size());
			for (final K element : elements) {
				result.add(transformer.transform(element));
			}
			return result;
		}

		return new HashSet<V>();
	}

	/**
	 * Transforms all elements from the input array with the given transformer and return them as a {@link Set}
	 * <p>
	 * If input elements is null or blank array then it returns a blank {@link Set}
	 * @param transformer the transformer to use, must not be null
	 * @param elements The elements to get the input from, may be null
	 * @return The {Set List} of elements obtained by after applying transformer on each element of given input collection.
	 */
	@SuppressWarnings("unchecked")
	public static <K, V> Set<V> asSet(final ITransformer<K, V> transformer, final K... elements) {
		if (transformer == null) {
			throw new IllegalArgumentException("Argument transformer cannot be null.");
		}

		if (isNotEmpty(elements)) {
			final Set<V> result = new HashSet<V>(elements.length);
			for (final K element : elements) {
				result.add(transformer.transform(element));
			}
			return result;
		}

		return new HashSet<V>();
	}

	@SafeVarargs
	public static <T> Set<T> asSet(final T... elements) {
		final Set<T> result = new HashSet<T>();

		if (isNotEmpty(elements)) {
			for (final T element : elements) {
				result.add(element);
			}
		}
		return result;
	}

	/**
	 * Cleans null values from a collection.
	 * @param elements The collection to be cleaned.
	 * @return Elements after cleaning <code>null</code> values.
	 */
	public static <T extends Iterable<?>> T cleanNull(final T elements) {
		if (elements != null) {
			final Iterator<?> iterator = elements.iterator();
			while (iterator.hasNext()) {
				if (iterator.next() == null) {
					iterator.remove();
				}
			}
		}
		return elements;
	}

	public static <E> void execute(final Collection<E> elements, final ITask<E> task) {
		if (task == null) {
			throw new IllegalArgumentException("Argument task cannot be null.");
		}
		for (final E element : nullSafe(elements)) {
			task.execute(element);
		}
	}

	public static <R> Collection<R> filter(final Collection<R> elements, final IFilter<R> filter) {
		if (filter == null) {
			throw new IllegalArgumentException("Argument filter cannot be null.");
		}
		final Set<R> result = new HashSet<R>();
		for (final R element : nullSafe(elements)) {
			if (filter.apply(element)) {
				result.add(element);
			}
		}
		return result;
	}

	public static <R, V> Collection<V> filterAndTransform(final Collection<R> elements, final IFilter<R> filter, final ITransformer<R, V> transformer) {
		if (filter == null) {
			throw new IllegalArgumentException("Argument filter cannot be null.");
		}
		final Collection<V> result = new HashSet<>();
		for (final R element : nullSafe(elements)) {
			if (filter.apply(element)) {
				result.add(transformer.transform(element));
			}
		}
		return result;
	}

	/**
	 * Transforms all elements from the input collection with the given transformer and compare the converted output with given value
	 * <p>
	 * If no converted output after applying transformer matches with given value the returns <code>null</code>
	 * <p>
	 * Return <code>null</code> if given input collection is <code>null</code> or empty.
	 * @param elements The elements to get the input from, may be null
	 * @param value The value to be compared with the output generated after applying transformer on elements of input collection.
	 * @param transformer the transformer to use, must not be null
	 * @return The element from input collection which after applying transfer is equal to given value to be compared with.
	 */
	public static <K, V, R extends K> R findByValue(final Collection<R> elements, final V value, final ITransformer<K, V> transformer) {
		if (transformer == null) {
			throw new IllegalArgumentException("Argument transformer cannot be null.");
		}

		if (elements != null) {
			for (final R element : elements) {
				if (transformer.transform(element).equals(value)) {
					return element;
				}
			}
		}

		return null;
	}

	/**
	 * Transforms all elements from the input collection with the given transformer and compare the converted output with given value
	 * <p>
	 * If converted output after applying transformer matches with given value the original element will be added in collection to be returned else not.
	 * <p>
	 * Return empty {@link Collection} if given input collection is <code>null</code> or empty.
	 * <p>
	 * Return empty {@link Collection} if given {@link Collection} of values to be filtered is <code>null</code> or empty.
	 * @param elements The elements to get the input from, may be null
	 * @param values The values to be compared with the output generated after applying transformer on elements of input collection.
	 * @param transformer the transformer to use, must not be null
	 * @return The {@link Collection} of elements from input collection which after applying transformer is present in Collection of values to be filtered.
	 */
	public static <K, V, R extends K> Collection<R> findByValues(final Collection<R> elements, final Collection<V> values, final ITransformer<K, V> transformer) {
		if (transformer == null) {
			throw new IllegalArgumentException("Argument transformer cannot be null.");
		}

		final Collection<R> result = new ArrayList<R>();

		if (isNotEmpty(elements) && isNotEmpty(values)) {
			for (final R r : elements) {
				if (values.contains(transformer.transform(r))) {
					result.add(r);
				}
			}
		}

		return result;
	}

	/**
	 * It checks if given element is present in the specified array.
	 * @param elementToTest Element to be searched in the array.
	 * @param elements The array of elements in which search for required element has to be performed.
	 * @return <code>true</code> if element is present in the array.
	 */
	@SafeVarargs
	public static <K> boolean in(final K elementToTest, final K... elements) {
		if (isNotEmpty(elements)) {
			for (final K k : elements) {
				if (ObjectUtil.areEqual(k, elementToTest)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Returns a {@link Collection} containing the intersection of the given {@link Collection}s.
	 * @param a the first collection, must not be null
	 * @param b the second collection, must not be null
	 * @return the intersection of the two collections
	 */
	public static <K> Collection<K> intersection(final Collection<K> a, final Collection<K> b) {
		return new HashSet<K>(subtract(a, subtract(a, b)));
	}

	/**
	 * Null-safe check if the specified collection is empty.
	 * <p>
	 * Null returns true.
	 * @param coll the collection to check, may be null
	 * @return true if empty or null
	 */
	public static <K> boolean isEmpty(final Collection<K> coll) {
		return coll == null || coll.isEmpty();
	}

	/**
	 * Null-safe check if the specified iterable is empty.
	 * <p>
	 * Null returns true.
	 *
	 * @param iterable the collection to check, may be null
	 * @return true if empty and or null
	 */
	public static <K> boolean isEmpty(final Iterable<K> iterable) {
		return iterable == null || !iterable.iterator().hasNext();
	}

	/**
	 * Null-safe check if the specified array is empty.
	 * <p>
	 * Null returns true.
	 * @param elements the elements to check, may be null
	 * @return true if empty or null
	 */
	public static <K> boolean isEmpty(final K[] elements) {
		return !isNotEmpty(elements);
	}

	/**
	 * Null-safe check if the specified collection is not empty.
	 * <p>
	 * Null returns false.
	 * @param coll the collection to check, may be null
	 * @return true if not empty and not null
	 */
	public static <K> boolean isNotEmpty(final Collection<K> coll) {
		return !isEmpty(coll);
	}

	/**
	 * Null-safe check if the specified iterable is not empty.
	 * <p>
	 * Null returns false.
	 *
	 * @param iterable the collection to check, may be null
	 * @return true if not empty and not null
	 */
	public static <K> boolean isNotEmpty(final Iterable<K> iterable) {
		return !isEmpty(iterable);
	}

	/**
	 * Null-safe check if the specified array is not empty.
	 * <p>
	 * Null returns false.
	 * @param elements the elements to check, may be null
	 * @return true if not empty and not null
	 */
	public static <K> boolean isNotEmpty(final K[] elements) {
		return elements != null && elements.length > 0;
	}

	public static <E> Collection<E> nullSafe(final Collection<E> c) {
		return isNotEmpty(c) ? c : new LinkedList<E>();
	}

	public static <E> List<E> nullSafe(final List<E> c) {
		return isNotEmpty(c) ? c : new LinkedList<E>();
	}

	public static <E> Set<E> nullSafe(final Set<E> c) {
		return isNotEmpty(c) ? c : new HashSet<E>();
	}

	/**
	 * Split the comma separated string into {@link List} of {@link String} tokens.
	 * @param input The comma separated string to be split.
	 * @return A {@link List} of {@link String} tokens.
	 */
	public static List<String> splitAsList(final String input) {
		return splitAsList(input, DEFAULT_SEPERATOR);
	}

	/**
	 * Split the input string delimited by delimiter into {@link List} of {@link String} tokens .
	 * @param input The string delimited by delimiter to be split.
	 * @return A {@link List} of {@link String} tokens.
	 */
	public static List<String> splitAsList(final String input, final String delimiter) {
		Assert.hasText(input);
		Assert.hasText(delimiter);
		List<String> result = new ArrayList<>();
		if (isNotBlank(input)) {
			result = asList(input.split(delimiter));
		}
		return result;
	}

	public static <C extends Collection<T>, T> Collection<C> splitCollection(final C inColl, final int splitSize, final CollectionCreator<C, T> collCreator) {

		final Collection<C> collectionBatch = new ArrayList<>();

		if (inColl.size() > splitSize && splitSize > 0) {

			int count = 0;
			C allocationPacket = collCreator.createEmptyCollection();

			for (final T collItem : inColl) {

				count++;
				allocationPacket.add(collItem);

				if (count % splitSize == 0 && count != 0) {
					collectionBatch.add(allocationPacket);
					allocationPacket = collCreator.createEmptyCollection();
				}

			}

			if (allocationPacket.size() > 0) {
				collectionBatch.add(allocationPacket);
			}

		} else {
			collectionBatch.add(inColl);
		}

		return collectionBatch;
	}

	/**
	 * Returns a new {@link Collection} containing <tt><i>a</i> - <i>b</i></tt>.
	 * @param a the collection to subtract from, must not be null
	 * @param b the collection to subtract, must not be null
	 * @return a new collection with the results
	 */
	public static <K> Collection<K> subtract(final Collection<K> a, final Collection<K> b) {
		final List<K> result = new ArrayList<K>();

		if (isNotEmpty(a)) {
			result.addAll(a);

			if (isNotEmpty(b)) {
				result.removeAll(b);
			}
		}

		return result;
	}

	/**
	 * Converts a collection of specific type to an array of same type. It returns null if collection is null or empty or all elements in collection are null.
	 * @param c The collection which has to converted in to an array.
	 * @return The array containing all the elements of collection.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T[] toArray(final Collection<T> c) {
		if (isEmpty(c)) {
			return null;
		}

		final T firstNotNullValue = getFirstNotNull(c);
		if (firstNotNullValue == null) {
			return null;
		}

		return c.toArray((T[]) Array.newInstance(firstNotNullValue.getClass(), c.size()));
	}

	public static String toString(final Collection<String> coll) {
		return toString(coll, DEFAULT_SEPERATOR, new NoOpTransformer<String>());
	}

	public static <T> String toString(final Collection<T> coll, final ITransformer<T, String> stringTransformer) {
		return toString(coll, DEFAULT_SEPERATOR, stringTransformer);
	}

	public static <T> String toString(final Collection<T> coll, final String seperator, final ITransformer<T, String> stringTransformer) {
		final StringBuffer result = new StringBuffer();
		if (isNotEmpty(coll)) {
			int i = 1;
			for (final T t : coll) {
				result.append(stringTransformer.transform(t));
				if (i < coll.size()) {
					result.append(seperator);
				}
				i++;
			}
		}
		return result.toString();
	}

	/**
	 * Transforms a collection of objects of one type into a set of objects of another type. There is no guarantee about the order of objects in the resulting
	 * set. The result is guaranteed not to contain a <tt>null</tt> value.
	 * @param collection The collection of objects to transform.
	 * @param transformer The {@link ITransformer} to use for transforming the collection.
	 * @return A set of objects of the required type.
	 */
	public static <T, U> Set<U> transform(final Collection<? extends T> collection, final ITransformer<T, U> transformer) {
		if (isEmpty(collection) || transformer == null) {
			return null;
		}

		final Set<U> result = new HashSet<U>();
		for (final T object : collection) {
			final U transformed = transformer.transform(object);

			if (transformed != null) {
				result.add(transformed);
			}
		}

		return result;
	}

	/**
	 * Transforms a collection of objects of one type into a {@link List} of objects of another type. The result is guaranteed not to contain a <tt>null</tt>
	 * value.
	 * @param collection The collection of objects to transform.
	 * @param transformer The {@link ITransformer} to use for transforming the collection.
	 * @return A {@link List} of objects of the required type.
	 */
	public static <T, U> List<U> transformAsList(final Collection<? extends T> collection, final ITransformer<T, U> transformer) {
		if (isEmpty(collection) || transformer == null) {
			return null;
		}

		final List<U> result = new ArrayList<U>(collection.size());
		for (final T object : collection) {
			final U transformed = transformer.transform(object);
			if (transformed != null) {
				result.add(transformed);
			}
		}

		return result;
	}

	/**
	 * Gets the union of collections of same type. It return null in case all collections are null or empty.
	 * @param args The collection of same type whose union is required.
	 * @return The union of collections of same type.
	 */
	public static <T> Collection<T> union(@SuppressWarnings("unchecked") final Collection<T>... args) {
		final Collection<T> result = new HashSet<T>();

		if (args != null) {
			for (final Collection<T> t : args) {
				if (CollectionUtil.isNotEmpty(t)) {
					result.addAll(t);
				}
			}
		}

		return isNotEmpty(result) ? result : null;
	}

	/**
	 * Gets the first not null value in the collection.
	 * @param arg The input collection.
	 * @return The First not null value in collection if present else return null.
	 */
	private static <T> T getFirstNotNull(final Collection<T> arg) {
		for (final T t : arg) {
			if (t != null) {
				return t;
			}
		}

		return null;
	}

	/**
	 * Prevent instantiation.
	 */
	private CollectionUtil() {
	}

	public static interface CollectionCreator<C extends Collection<T>, T> {
		C createEmptyCollection();
	}

	public static class ListCreator<T> implements CollectionCreator<List<T>, T> {

		@Override
		public List<T> createEmptyCollection() {
			return new ArrayList<T>();
		}

	}

	public static class SetCreator<T> implements CollectionCreator<Set<T>, T> {

		@Override
		public Set<T> createEmptyCollection() {
			return new HashSet<T>();
		}

	}
}
