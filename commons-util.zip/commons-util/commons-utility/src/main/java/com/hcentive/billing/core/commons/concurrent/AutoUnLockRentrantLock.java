package com.hcentive.billing.core.commons.concurrent;

import java.io.Closeable;
import java.util.concurrent.locks.ReentrantLock;

public class AutoUnLockRentrantLock extends ReentrantLock implements Closeable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void close() {
		this.unlock();
	}

	public AutoUnLockRentrantLock lockMe() {
		this.lock();
		return this;
	}
}