package com.hcentive.billing.core.commons.tags;

public class StringTagBuilder {

	public static final String CARRIER_ID = "CARRIER_ID=";
	public static final String COVERAGE_TYPE = "COVERAGE_TYPE=";
	public static final String GROUP_CATEGORY = "GROUP_CATEGORY=";
	public static final String GROUP_ID = "GROUP_ID=";
	public static final String PLAN_ID = "PLAN_ID=";
	public static final String PLAN_TYPE = "PLAN_TYPE=";
	public static final String PRODUCT_TYPE = "PRODUCT_TYPE=";
	public static final String SMOKER_FL = "SMOKER_FL=";
	public static final String SMOKING_CLASS = "SMOKING_CLASS=";
	public static final String SUB_GROUP_ID = "SUB_GROUP_ID=";
	public static final String SUBSCRIBER_ID = "SUBSCRIBER_ID=";

	public static String createTag(String prefix, String value) {
		return prefix + value;
	}

	public static String createTagIfNotNull(String prefix, Object value) {
		if (value != null) {
			return createTag(prefix, value.toString());
		}
		return null;
	}

}
