package com.hcentive.billing.core.commons.tags;

import java.util.Collection;

import org.springframework.stereotype.Component;

@Component
public class SupersetTagMatcher extends AbstractTagMatcher {

	@Override
	public boolean canHandle(MatchingStrategyType type) {
		return type == MatchingStrategyType.SUPERSET;
	}

	@Override
	protected <C> boolean match(Collection<C> commonTags,
			Collection<C> matchObjTags, Collection<C> matchToTags) {
		return commonTags.size() == matchToTags.size();
	}

}
