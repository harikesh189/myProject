package com.hcentive.billing.core.commons.tags;

import static com.hcentive.billing.core.commons.util.CollectionUtil.intersection;
import static com.hcentive.billing.core.commons.util.CollectionUtil.nullSafe;

import java.util.Collection;
import java.util.Comparator;

public class TagComparator<C extends Comparable<C>, T extends TagAware<C>>
		implements Comparator<T> {

	@Override
	public int compare(final T t1, final T t2) {
		final Collection<C> tags1 = nullSafe(t1.tags());
		final Collection<C> tags2 = nullSafe(t2.tags());

		final Collection<C> commonTags = intersection(tags1, tags2);

		if (commonTags.size() == 0) {
			return -2;
		}

		if (commonTags.size() == tags2.size()
				&& commonTags.size() == tags1.size()) {
			// both collections contains same elements.
			return 0;
		}

		if (commonTags.size() == tags2.size()
				&& commonTags.size() != tags1.size()) {
			// both collections contains same elements.
			return 0;
		}

		return 0;
	}

}
