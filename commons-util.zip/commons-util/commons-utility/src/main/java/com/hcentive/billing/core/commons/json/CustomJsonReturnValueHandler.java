package com.hcentive.billing.core.commons.json;

import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomJsonReturnValueHandler implements
		HandlerMethodReturnValueHandler {

	public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");

	public static final MediaType DEFAULT_MEDIA_TYPE = new MediaType(
			"application", "json", DEFAULT_CHARSET);

	private final HandlerMethodReturnValueHandler delegate;

	public CustomJsonReturnValueHandler(HandlerMethodReturnValueHandler delegate) {
		this.delegate = delegate;
	}

	@Override
	public boolean supportsReturnType(MethodParameter returnType) {
		return delegate.supportsReturnType(returnType);
	}

	@Override
	public void handleReturnValue(Object returnValue,
			MethodParameter returnType, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest) throws Exception {

		Method handlerMethod = returnType.getMethod();

		if (handlerMethod.getAnnotation(JsonResponse.class) != null) {

			HttpServletResponse httpResponse = webRequest
					.getNativeResponse(HttpServletResponse.class);

			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.setMixInAnnotations(getMixins(handlerMethod
					.getAnnotation(JsonResponse.class)));

			MappingJackson2HttpMessageConverter handler = new MappingJackson2HttpMessageConverter();
			handler.setObjectMapper(objectMapper);
			handler.write(returnValue, DEFAULT_MEDIA_TYPE,
					new ServletServerHttpResponse(httpResponse));

		} else {

			delegate.handleReturnValue(returnValue, returnType, mavContainer,
					webRequest);
		}
	}

	/**
	 * Converts Json.mixins() to a Map<Class, Class>
	 * 
	 * @param jsonFilter
	 *            Json annotation
	 * @return Map of Target -> Mixin classes
	 */
	protected Map<Class<?>, Class<?>> getMixins(JsonResponse jsonFilter) {

		Map<Class<?>, Class<?>> mixins = new HashMap<Class<?>, Class<?>>();

		if (jsonFilter != null) {
			for (JsonMixin jsonMixin : jsonFilter.mixins()) {
				mixins.put(jsonMixin.target(), jsonMixin.mixin());
			}
		}

		return mixins;
	}

}