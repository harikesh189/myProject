package com.hcentive.billing.core.commons.factory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Factories<F extends Factory> {

	private static Logger logger = LoggerFactory.getLogger(Factories.class);

	private final Collection<F> matchedBeans = new ArrayList<F>();

	public static final Factories INSTANCE = new Factories();

	public <F extends Factory<T>, T> F factory(Class<T> classz) {
		logger.trace("get factory for " + classz);
		for (final Factory<T> factory : registeredInstances()) {
			if (factory.lookupForType().equals(classz)) {
				logger.trace("factory found");
				return (F) factory;
			}
		}
		throw new IllegalStateException("No factory configured for : " + classz.getCanonicalName());
	}

	protected Collection<F> registeredInstances() {
		return Collections.unmodifiableCollection(matchedBeans);
	}

	public void registerBean(F bean) {
		matchedBeans.add(bean);
	}

}
