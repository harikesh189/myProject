/**
 * 
 */
package com.hcentive.billing.core.commons.uglii.algorithm;

/**
 * @author uttam.tiwari
 * 
 */
public class Converter {

	public static String base10Tobase32(Long number) {
		String[] symbol = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
				"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L",
				"M", "N", "O", "P", "Q", "R", "S", "T", "U", "V" };
		StringBuilder builder = new StringBuilder();
		if (number <= 0)
			return symbol[0];
		while (number > 0) {
			long j = number & 31;
			builder.append(symbol[(int) j]);
			number >>= 5;
		}
		return builder.toString();
	}

	/*
	 * public static void main(String[] args) {
	 * System.out.println(base10Tobase32(1406116376460L)); }
	 */
}
