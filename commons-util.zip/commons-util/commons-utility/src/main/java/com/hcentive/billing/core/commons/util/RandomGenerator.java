package com.hcentive.billing.core.commons.util;

import java.util.UUID;

public class RandomGenerator {

	public static String randomString() {
		return UUID.randomUUID().toString(); 
		// changing back to UUID as we don't need readable identity
		// UGLII Algo is producing duplicate in some rare cases
		//return UGLIIAlgo.getReadableID();
	}

	public static String randomReadableString() {
		return randomString();
	}

}