package com.hcentive.billing.core.commons.tags;

public interface TagMatcherFactory {

	TagMatcher getMatcher(MatchingStrategyType type);

}
