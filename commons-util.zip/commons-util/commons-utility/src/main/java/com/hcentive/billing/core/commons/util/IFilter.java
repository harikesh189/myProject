package com.hcentive.billing.core.commons.util;

public interface IFilter<K> {
	boolean apply(K input);
}
