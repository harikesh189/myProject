package com.hcentive.billing.core.commons.util;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;

@Component
public class DefaultMergerFactory extends SpringBackedAbstractFactory<IMerger>
		implements MergerFactory {

	@Override
	public IMerger getMerger(final Object entityToMerge) {
		for (final IMerger merger : this.registeredInstances()) {
			if (merger.canHandle(entityToMerge.getClass())) {
				return merger;
			}
		}
		return null;
	}

	@Override
	protected Class<IMerger> lookupForType() {
		return IMerger.class;
	}

}
