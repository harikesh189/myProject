package com.hcentive.billing.core.commons.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;

public class TaskAwareFactory<T extends IsForTask> extends SpringBackedAbstractFactory<T> implements Factory {

	private static Logger logger = LoggerFactory.getLogger(TaskAwareFactory.class);

	private final Class<T> lookupForType;

	@Override
	public Class<T> lookupForType() {
		return this.lookupForType;
	}

	public TaskAwareFactory(final Class<T> lookupForType) {
		super();
		this.lookupForType = lookupForType;
	}

	@Override
	public T get(Object o) {
		logger.trace("get type for inputType ", o);
		for (final T objectType : registeredInstances()) {
			if (objectType.canHandle(o)) {
				logger.trace("converrter object found.");
				return objectType;
			}
		}
		throw new IllegalStateException("No class configured for Type : " + o.toString());
	}
}