package com.hcentive.billing.core.commons.tags;

import java.util.Collection;

import org.springframework.stereotype.Component;

@Component
public class ExactTagMatcher extends AbstractTagMatcher {

	@Override
	public boolean canHandle(MatchingStrategyType type) {
		return type == MatchingStrategyType.EXACT;
	}

	@Override
	protected <C> boolean match(Collection<C> commonTags,
			Collection<C> matchObjTags, Collection<C> matchToTags) {
		return commonTags.size() == matchObjTags.size()
				&& commonTags.size() == matchToTags.size();
	}

}
