package com.hcentive.billing.core.commons.factory;

import org.springframework.beans.factory.BeanNameAware;

public interface IsNamedArticle extends BeanNameAware {
	public String articleName();
}
