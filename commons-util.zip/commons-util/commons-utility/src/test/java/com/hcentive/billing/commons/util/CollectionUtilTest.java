package com.hcentive.billing.commons.util;

import static com.hcentive.billing.core.commons.util.CollectionUtil.areNotSame;
import static com.hcentive.billing.core.commons.util.CollectionUtil.areSame;
import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;
import static com.hcentive.billing.core.commons.util.CollectionUtil.asMap;
import static com.hcentive.billing.core.commons.util.CollectionUtil.in;
import static com.hcentive.billing.core.commons.util.CollectionUtil.intersection;
import static com.hcentive.billing.core.commons.util.CollectionUtil.isEmpty;
import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;
import static com.hcentive.billing.core.commons.util.CollectionUtil.splitAsList;
import static com.hcentive.billing.core.commons.util.CollectionUtil.subtract;
import static com.hcentive.billing.core.commons.util.CollectionUtil.toArray;
import static com.hcentive.billing.core.commons.util.CollectionUtil.transform;
import static com.hcentive.billing.core.commons.util.CollectionUtil.union;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;

import org.junit.Test;

import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.util.ITransformer;

/**
 * Unit tests for {@link CollectionUtil}.
 */
public class CollectionUtilTest {
	private static final Random GENERATOR = new Random();

	/**
	 * Tests that collections with different elements are not treated as equivalent.
	 */
	@Test
	public void testAreNotSame() {
		assertTrue(areNotSame(null, Collections.<Integer> emptyList()));
		assertTrue(areNotSame(Collections.<Integer> emptyList(), null));

		assertFalse(areNotSame(Collections.<Integer> emptyList(), Collections.<Integer> emptyList()));
	}

	/**
	 * Tests that collections with the same elements are treated as equivalent.
	 */
	@Test
	public void testAreSame() {
		final List<Integer> list = new ArrayList<Integer>();
		final Queue<Integer> queue = new LinkedList<Integer>();
		final Set<Integer> set = new HashSet<Integer>();

		assertFalse(areSame(null, list));
		assertFalse(areSame(list, null));

		assertTrue(areSame(list, list));
		assertTrue(areSame(list, queue));
		assertTrue(areSame(list, set));
		assertTrue(areSame(queue, set));

		list.add(101 + GENERATOR.nextInt(100));
		list.add(101 + GENERATOR.nextInt(100));
		list.add(101 + GENERATOR.nextInt(100));

		queue.add(201 + GENERATOR.nextInt(100));
		queue.add(201 + GENERATOR.nextInt(100));
		queue.add(201 + GENERATOR.nextInt(100));

		set.addAll(list);
		set.add(501 + GENERATOR.nextInt(100));
		set.add(501 + GENERATOR.nextInt(100));

		assertFalse(areSame(list, queue));
		assertFalse(areSame(list, set));
		assertFalse(areSame(queue, set));
	}

	/**
	 * Tests that arrays can be converted into lists.
	 */
	@Test
	public void testAsList() {
		List<Integer> list = asList(null);
		assertEquals(0, list.size());

		list = asList(new Integer[0]);
		assertEquals(0, list.size());

		final Integer[] array = new Integer[1 + GENERATOR.nextInt(10)];
		for (int i = 0; i < array.length; ++i) {
			array[i] = GENERATOR.nextInt();
		}

		list = asList(array);
		assertEquals(array.length, list.size());
	}

	/**
	 * Tests that arrays can be converted into lists.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testAsListWithArrayAndInvalidTransformer() {
		CollectionUtil.<Long, String> asList(null, new Long[0]);
	}

	/**
	 * Tests that arrays can be converted into lists.
	 */
	@Test
	public void testAsListWithArrayAndValidTransformer() {
		assertEquals(0, CollectionUtil.<Long, String> asList(LongStringTransformer.INSTANCE, new Long[0]).size());

		final Long[] numbers = new Long[20];

		for (int i = 0; i < 20; ++i) {
			numbers[i] = GENERATOR.nextLong();
		}

		final List<String> list = CollectionUtil.<Long, String> asList(LongStringTransformer.INSTANCE, numbers);

		assertNotNull(list);
		assertEquals(numbers.length, list.size());
	}

	/**
	 * Tests that collections can be converted into lists.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testAsListWithCollectionAndInvalidTransformer() {
		CollectionUtil.<Long, String> asList(null, Collections.<Long> emptySet());
	}

	/**
	 * Tests that collections can be converted into lists.
	 */
	@Test
	public void testAsListWithCollectionAndValidTransformer() {
		final List<Long> numbers = new ArrayList<Long>();

		assertEquals(0, CollectionUtil.<Long, String> asList(LongStringTransformer.INSTANCE, numbers).size());

		for (int i = 0; i < 20; ++i) {
			numbers.add(GENERATOR.nextLong());
		}

		final List<String> list = CollectionUtil.<Long, String> asList(LongStringTransformer.INSTANCE, numbers);

		assertNotNull(list);
		assertEquals(numbers.size(), list.size());
	}

	/**
	 * Tests that arrays can be converted into map.
	 */
	@Test
	public void testAsMap() {
		Map<String, Long> map = asMap(null, LongStringTransformer.INSTANCE);
		assertEquals(0, map.size());

		final ArrayList<Long> elements = new ArrayList<Long>();

		map = asMap(elements, LongStringTransformer.INSTANCE);
		assertEquals(0, map.size());

		for (int i = 0; i < 20; ++i) {
			elements.add(GENERATOR.nextLong());
		}

		map = asMap(elements, LongStringTransformer.INSTANCE);
		assertEquals(elements.size(), map.size());
	}

	/**
	 * Tests that collection can be converted into map.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testAsMapWithArrayAndInvalidTransformer() {
		CollectionUtil.<Number, String, Long> asMap(new ArrayList<Long>(), null);
	}

	/**
	 * Tests that collection can be converted into map.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testAsMapWithArrayAndInvalidTransformers() {
		CollectionUtil.<Number, String, Long> asMap(new ArrayList<Long>(), null, null);
	}

	/**
	 * Tests that arrays can be converted into map.
	 */
	@Test
	public void testAsMapWithBothTransformer() {
		Map<String, String> map = asMap(null, LongStringTransformer.INSTANCE, LongStringTransformer.INSTANCE);
		assertEquals(0, map.size());

		final ArrayList<Long> elements = new ArrayList<Long>();

		map = asMap(elements, LongStringTransformer.INSTANCE, LongStringTransformer.INSTANCE);
		assertEquals(0, map.size());

		for (int i = 0; i < 20; ++i) {
			elements.add(GENERATOR.nextLong());
		}

		map = asMap(elements, LongStringTransformer.INSTANCE, LongStringTransformer.INSTANCE);
		assertEquals(elements.size(), map.size());
		final Set<String> keySet = map.keySet();
		for (final String key : keySet) {
			assertEquals(key, map.get(key));
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAsSetWithArrayAndInvalidTransformer() {
		CollectionUtil.<Long, String> asSet(null, new Long[0]);
	}

	/**
	 * Tests that arrays can be converted into lists.
	 */
	@Test
	public void testAsSetWithArrayAndValidTransformer() {
		assertEquals(0, CollectionUtil.<Long, String> asSet(LongStringTransformer.INSTANCE, new Long[0]).size());

		final Long[] numbers = new Long[20];

		for (int i = 0; i < 20; ++i) {
			numbers[i] = GENERATOR.nextLong();
		}

		final Set<String> list = CollectionUtil.<Long, String> asSet(LongStringTransformer.INSTANCE, numbers);

		assertNotNull(list);
		assertEquals(numbers.length, list.size());
	}

	/**
	 * Tests that elements can be extracted from collections based on some arbitrary property of the element.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testFindByValueWithInvalidTransformer() {
		assertNull(CollectionUtil.<Long, String, Long> findByValue(Collections.<Long> emptySet(), "1", null));
	}

	/**
	 * Tests that elements can be extracted from collections based on some arbitrary property of the element.
	 */
	@Test
	public void testFindByValueWithValidTransformer() {
		final List<Long> numbers = new ArrayList<Long>();

		assertNull(CollectionUtil.<Long, String, Long> findByValue(null, "1", LongStringTransformer.INSTANCE));
		assertNull(CollectionUtil.<Long, String, Long> findByValue(numbers, "1", LongStringTransformer.INSTANCE));

		for (long i = 0; i < 20; ++i) {
			numbers.add(i);
		}

		assertEquals(9, CollectionUtil.<Long, String, Long> findByValue(numbers, "9", LongStringTransformer.INSTANCE).longValue());
	}

	@Test
	public void testIn() {
		assertTrue(in(new Long(1), new Long(1)));
		assertTrue(in(new Long(3), new Long(1), new Long(2), new Long(3)));
		assertFalse(in(null, new Long(1), new Long(2), new Long(3)));
		assertTrue(in(null, new Long(1), new Long(2), new Long(3), null));
		assertFalse(in(null, null));
	}

	/**
	 * Tests for intersection of collections.
	 */
	@Test
	public void testIntersection() {
		final List<Integer> superset = Arrays.asList(1, 2, 3, 4, 5);
		final List<Integer> subset = Arrays.asList(2, 4);

		final Collection<Integer> intersection = intersection(superset, subset);

		assertNotNull(intersection);
		assertEquals(2, intersection.size());
		assertTrue(intersection.containsAll(subset));
	}

	/**
	 * Tests for empty collections.
	 */
	@Test
	public void testIsEmpty() {
		assertTrue(isEmpty(Collections.<Long> emptyList()));
		assertTrue(isEmpty(new ArrayList<Long>()));

		assertFalse(isEmpty(Arrays.asList(1L, 2L, 3L)));
	}

	/**
	 * Tests for non-empty arrays.
	 */
	@Test
	public void testIsNotEmptyWithArray() {
		assertFalse(isNotEmpty((Object[]) null));
		assertFalse(isNotEmpty(new Long[0]));

		assertTrue(isNotEmpty(new Long[] { 1L, 2L, 3L }));
	}

	/**
	 * Tests for non-empty collections.
	 */
	@Test
	public void testIsNotEmptyWithCollection() {
		assertFalse(isNotEmpty(Collections.<Long> emptyList()));
		assertFalse(isNotEmpty(new ArrayList<Long>()));

		assertTrue(isNotEmpty(Arrays.asList(1L, 2L, 3L)));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSplitAsString() {
		assertNull(splitAsList(null, null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSplitAsString2() {
		assertNull(splitAsList("ABCD", null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSplitAsString3() {
		assertNull(splitAsList("", ","));
	}

	@Test
	public void testSplitAsString4() {
		final List<String> splittedList = splitAsList("Ram,Nitin,Ajay", ",");
		assertEquals(3, splittedList.size());
		assertTrue(splittedList.contains("Ram"));
		assertTrue(splittedList.contains("Nitin"));
		assertTrue(splittedList.contains("Ajay"));
	}

	/**
	 * Tests for subtraction of collections.
	 */
	@Test
	public void testSubtract() {
		assertEquals(0, subtract(null, null).size());
		assertEquals(3, subtract(Arrays.<Long> asList(1L, 2L, 3L), null).size());
		assertEquals(0, subtract(Arrays.<Long> asList(1L, 2L, 3L), Arrays.<Long> asList(1L, 2L, 3L)).size());
	}

	/**
	 * Tests that collections can be converted into arrays.
	 */
	@Test
	public void testToArray() {
		assertNull(toArray(null));
		assertNull(toArray(Collections.<Long> emptyList()));
		assertNull(toArray(Arrays.asList(null, null, null)));

		assertNotNull(toArray(Arrays.asList(1, 2, 3)));
	}

	@Test
	public void testToString() {
		assertEquals("Nitin,Sachin", CollectionUtil.toString(asList("Nitin", "Sachin")));
		assertEquals("Nitin", CollectionUtil.toString(asList("Nitin")));
		assertEquals("", CollectionUtil.toString(asList("")));
	}

	/**
	 * Tests for {@link CollectionUtil#transform(Collection, ITransformer)}.
	 */
	@Test
	public void testTransform() {
		assertNull(transform(null, null));
		assertNull(transform(null, LongStringTransformer.INSTANCE));
		assertNull(transform(Arrays.asList(), null));
		assertNull(transform(Arrays.asList(1L, 2L, 3L), null));

		assertEquals(3, transform(Arrays.asList(1L, 2L, 3L), LongStringTransformer.INSTANCE).size());
	}

	/**
	 * Tests for union of collections.
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testUnion() {
		assertNull(union());
		assertNull(union((Collection<Object>) null));
		assertNull(union(null, null));
		assertNull(union(null, null, null));

		final List<Integer> odd = Arrays.asList(1, 3, 5);
		final List<Integer> even = Arrays.asList(2, 4);

		final Collection<Integer> union = union(odd, even);

		assertNotNull(union);
		assertTrue(union.size() >= odd.size());
		assertTrue(union.size() >= even.size());
		assertTrue(union.containsAll(odd));
		assertTrue(union.containsAll(even));
	}

	/**
	 * Converts long values into strings.
	 */
	private static final class LongStringTransformer implements ITransformer<Long, String> {
		private static final LongStringTransformer INSTANCE = new LongStringTransformer();

		/**
		 * Prevent instantiation.
		 */
		private LongStringTransformer() {
		}

		@Override
		public String transform(final Long element) {
			return element.toString();
		}
	}
}
