package com.hcentive.billing.commons.util;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import com.hcentive.billing.core.commons.enumeration.RoundingMode;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.util.DateUtility;

/**
 * Unit tests for {@link CollectionUtil}.
 */
public class DateUtilityTest {

	private static Date getDate(int year, int month, int date, int hourOfDay, int minute, int second) {
		final Calendar calendar = Calendar.getInstance();
		calendar.set(year, month, date, hourOfDay, minute, second);
		return calendar.getTime();
	}

	/**
	 * Tests that collections with different elements are not treated as
	 * equivalent.
	 */
	@Test
	public void testRounding() {
		final Date dateToTest = getDate(2015, 1, 16, 10, 15, 28);
		Date roundedDate = DateUtility.round(dateToTest, RoundingMode.DAY_START);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(roundedDate);
		assertEquals(2015, calendar.get(Calendar.YEAR));
		assertEquals(1, calendar.get(Calendar.MONTH));
		assertEquals(16, calendar.get(Calendar.DATE));
		assertEquals(0, calendar.get(Calendar.HOUR));
		assertEquals(0, calendar.get(Calendar.MINUTE));
		assertEquals(0, calendar.get(Calendar.SECOND));
		assertEquals(0, calendar.get(Calendar.MILLISECOND));

		roundedDate = DateUtility.round(dateToTest, RoundingMode.DAY_END);
		calendar = Calendar.getInstance();
		calendar.setTime(roundedDate);
		assertEquals(2015, calendar.get(Calendar.YEAR));
		assertEquals(1, calendar.get(Calendar.MONTH));
		assertEquals(16, calendar.get(Calendar.DATE));
		assertEquals(23, calendar.get(Calendar.HOUR_OF_DAY));
		assertEquals(59, calendar.get(Calendar.MINUTE));
		assertEquals(59, calendar.get(Calendar.SECOND));
		assertEquals(999, calendar.get(Calendar.MILLISECOND));

	}
}
