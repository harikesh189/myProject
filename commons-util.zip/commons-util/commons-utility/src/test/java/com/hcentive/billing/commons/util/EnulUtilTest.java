package com.hcentive.billing.commons.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.util.EnumUtil;

/**
 * Unit tests for {@link CollectionUtil}.
 */
public class EnulUtilTest {

	@Test
	public void testfullyQualifiedName() {
		assertEquals("com.hcentive.billing.commons.util.TestEnum.VAL1",
				EnumUtil.fullyQualifiedName(TestEnum.VAL1));
	}
}

enum TestEnum {
	VAL1, VAL2;
}
