package com.hcentive.billing.commons.util;

import org.junit.Assert;
import org.junit.Test;

import com.hcentive.billing.core.commons.util.ObjectUtil;

/**
 * Unit tests for {@link ObjectUtil}.
 */
public class ObjectUtilTest {
	/**
	 * Tests that two equivalent objects are treated as equal.
	 */
	@Test
	public void testAreEqual() {
		Assert.assertTrue(ObjectUtil.areEqual(null, null));
		Assert.assertTrue(ObjectUtil.areEqual(new Long(1), new Long(1)));
		Assert.assertTrue(ObjectUtil.areEqual("1", "1"));

		Assert.assertFalse(ObjectUtil.areEqual(null, "1"));
		Assert.assertFalse(ObjectUtil.areEqual("1", null));
	}

	/**
	 * Tests that two different objects are treated as unequal.
	 */
	@Test
	public void testAreNotEqual() {
		Assert.assertTrue(ObjectUtil.areNotEqual(new Long(1), "1"));
		Assert.assertTrue(ObjectUtil.areNotEqual(Boolean.FALSE, "false"));

		Assert.assertFalse(ObjectUtil.areNotEqual("1", "1"));
	}

	/**
	 * Tests that all specified objects are not null.
	 */
	@Test
	public void testAreNotNull() {
		Assert.assertTrue(ObjectUtil.areNotNull(new Long(1)));
		Assert.assertTrue(ObjectUtil.areNotNull(new Long(1), "2"));
		Assert.assertFalse(ObjectUtil.areNotNull(new Long(1), null));
		Assert.assertFalse(ObjectUtil.areNotNull(null));
		Assert.assertTrue(ObjectUtil.areNotNull(new int[5]));
		Assert.assertTrue(ObjectUtil.areNotNull(new int[0]));
	}
}
