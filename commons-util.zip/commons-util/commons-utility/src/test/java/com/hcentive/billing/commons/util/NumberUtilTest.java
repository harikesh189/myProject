package com.hcentive.billing.commons.util;

import static com.hcentive.billing.core.commons.util.NumberUtil.inRange;
import static com.hcentive.billing.core.commons.util.NumberUtil.notInRange;

import org.junit.Assert;
import org.junit.Test;

public class NumberUtilTest {

	@Test
	public void testInRange() {
		Assert.assertTrue(inRange(7, 6, 10));
		Assert.assertTrue(inRange(6, 6, 10));
		Assert.assertTrue(inRange(10, 6, 10));
		Assert.assertFalse(inRange(11, 6, 10));
		Assert.assertFalse(inRange(5, 6, 10));
	}

	@Test
	public void testNotInRange() {
		Assert.assertTrue(notInRange(5, 6, 10));
		Assert.assertFalse(notInRange(6, 6, 10));
		Assert.assertFalse(notInRange(10, 6, 10));
		Assert.assertTrue(notInRange(11, 6, 10));
	}
}
