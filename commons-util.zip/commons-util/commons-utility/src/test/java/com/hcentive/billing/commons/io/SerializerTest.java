package com.hcentive.billing.commons.io;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.hcentive.billing.core.commons.io.DefaultSerializer;

public class SerializerTest {

	private DefaultSerializer serializer = new DefaultSerializer();
	
	@Test(expected = IllegalArgumentException.class)
	public void testSerializationforNull() {
		serializer.serialize(null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testdeSerializationforNull() {
		serializer.deSerialize(null, null);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testForValidObject() {
		HashMap<String, String> data = new HashMap<>();
		data.put("firstName.surName", "Nitin.Singla");
		byte[] byteData = serializer.serialize(data);
		assertNotNull(byteData);
		Map<String, String> deSerializedObj = (Map<String, String>) serializer.deSerialize(byteData, null);
		assertNotNull(deSerializedObj);
		assertEquals("Nitin.Singla", deSerializedObj.get("firstName.surName"));
	}

}
