package com.hcentive.billing.core.commons.ftp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Hashtable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class DefaultFTPClient implements FTPClient {

	private ChannelSftp channelSftp;

	private static final Logger logger = LoggerFactory
			.getLogger(DefaultFTPClient.class);

	public void downloadFile(String targetFile, String fileDirPath,
			String tempFileName) throws Exception {
		byte[] buffer = new byte[1024];
		logger.debug("Reading file at ftp server");
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		try {
			bis = new BufferedInputStream(channelSftp.get(targetFile));
			File fileDir = new File(fileDirPath);
			if (!fileDir.exists()) {
				logger.debug("Folder doesn't exist, creating dir");
				fileDir.mkdir();
			}
			File newFile = new File(fileDir, tempFileName);
			logger.debug("Temp file created");
			OutputStream os = new FileOutputStream(newFile);
			bos = new BufferedOutputStream(os);
			int readCount;
			logger.debug("Writing file to local");
			while ((readCount = bis.read(buffer)) > 0) {
				bos.write(buffer, 0, readCount);
			}
		} catch (Exception e) {
			logger.error("Error while downloading file ", e);
		} finally {
			if (bis != null) {
				try {
					bis.close();
				} catch (Exception e) {
					logger.error("Error while closing BufferedInputStream", e);
				}
			}
			if (bos != null) {
				try {
					bos.close();
				} catch (Exception e) {
					logger.error("Error while closing BufferedOutputStream", e);
				}
			}

		}
		logger.debug("file {} downloaded sucessfully from ftp client {}.",targetFile,fileDirPath);
	}

	@Override
	public void buildClient(FTPConfig ftpConfig) throws NumberFormatException,
			JSchException {
		logger.debug("Building Session from ftpconfig");
		final JSch jsch = new JSch();
		int portNumber = tryParse(ftpConfig.getPort());
		Hashtable<String, String> config = new Hashtable<String, String>();
		config.put("StrictHostKeyChecking", "no");
		JSch.setConfig(config);
		Session session = jsch.getSession(ftpConfig.getUserName(),
				ftpConfig.getHost(), portNumber);
		session.setPassword(ftpConfig.getPassword());
		session.setConfig("PreferredAuthentications", 
                "publickey,keyboard-interactive,password");
		session.connect();
		Channel channel = session.openChannel("sftp");
		channel.connect();
		logger.debug("Creating ftpChannel");
		channelSftp = (ChannelSftp) channel;
	}

	private Integer tryParse(String text) {
		try {
			return Integer.parseInt(text);
		} catch (NumberFormatException e) {
			throw new NumberFormatException();
		}
	}

	@Override
	public void uploadSFTP(String fileContents, String uploadedFileName,
			FTPConfig ftpConfig) {
		try {
			channelSftp.put(new ByteArrayInputStream(fileContents.getBytes()), uploadedFileName);
		} catch (Exception e) {
			logger.error("error while uploding file : ", e);
		}
	}

	@Override
	public boolean isConnected() {
		return channelSftp.isConnected();
	}

}
