package com.hcentive.billing.core.commons.ftp;

import java.awt.BufferCapabilities.FlipContents;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FTPClientProvider {

	private static final Logger logger = LoggerFactory
			.getLogger(FTPClientProvider.class);
	private static final HashMap<String, FTPClient> ftpClientMap = new HashMap<String, FTPClient>();

	public static FTPClient addNGetTenantAwareFtpClient(String tenantId,
			FTPConfig ftpConfig) throws Exception {
		logger.debug("Looking for tenant specific ftp client : {}", tenantId);
		if (ftpClientMap.get(tenantId) == null || (ftpClientMap.get(tenantId) instanceof FTPClient && !ftpClientMap.get(tenantId).isConnected())) {
			logger.debug("tenant specific client not found.Building client");
			FTPClient client = new DefaultFTPClient();
			client.buildClient(ftpConfig);
			ftpClientMap.put(tenantId, client);
			return client;
		} else {
			logger.debug("tenant specific ftp client found for tenant : {}",
					tenantId);
			return ftpClientMap.get(tenantId);
		}

	}
}
