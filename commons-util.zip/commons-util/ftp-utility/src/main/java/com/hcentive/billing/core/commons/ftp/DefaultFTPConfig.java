package com.hcentive.billing.core.commons.ftp;

public class DefaultFTPConfig implements FTPConfig {

	private String host;
	private String port;
	private String userName;
	private String password;

	public static class FTPConfigBuilder {
		private String host;
		private String port;
		private String userName;
		private String password;

		public FTPConfigBuilder setHost(String host) {
			this.host = host;
			return this;
		}

		public FTPConfigBuilder setPort(String port) {
			this.port = port;
			return this;
		}

		public FTPConfigBuilder setUserName(String userName) {
			this.userName = userName;
			return this;
		}

		public FTPConfigBuilder setPassword(String password) {
			this.password = password;
			return this;
		}

		public DefaultFTPConfig build() {
			return new DefaultFTPConfig(this);
		}
	}

	public DefaultFTPConfig(FTPConfigBuilder ftpConfigBuilder) {
		this.host = ftpConfigBuilder.host;
		this.port = ftpConfigBuilder.port;
		this.password = ftpConfigBuilder.password;
		this.userName = ftpConfigBuilder.userName;
	}

	@Override
	public String getHost() {
		return host;
	}

	@Override
	public String getPort() {
		return port;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUserName() {
		return userName;
	}

}
