package com.hcentive.billing.core.commons.ftp;

import com.hcentive.billing.core.commons.ftp.FTPConfig;

public interface FTPClient {

	void downloadFile(String targetFile, String filePath, String tempFileName)
			throws Exception;

	void buildClient(FTPConfig ftpConfig) throws Exception;

	void uploadSFTP(String fileContents, String uploadedFileName,
			FTPConfig ftpConfig);
	
	boolean isConnected();

}
