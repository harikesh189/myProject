package com.hcentive.billing.core.commons.ftp;

public interface FTPConfig {

	String getHost();

	String getPort();

	String getUserName();

	String getPassword();

}
