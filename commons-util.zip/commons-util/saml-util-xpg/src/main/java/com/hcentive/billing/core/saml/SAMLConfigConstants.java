package com.hcentive.billing.core.saml;

import org.opensaml.common.SAMLVersion;

public interface SAMLConfigConstants {

	public static final String AUTHN_CONTEXT_REF_CLASS = "urn:oasis:names:tc:SAML:2.0:ac:classes:unspecified"; // "urn:oasis:names:tc:SAML:2.0:ac:classes:Password";
	public static final String ISSUER_FORMAT = "urn:oasis:names:tc:SAML:2.0:assertion";
	public static final String AUTHN_ISSUER_FORMAT = "urn:oasis:names:tc:SAML:2.0:nameid-format:entity";
	public static final String SUCCESS_STATUS_CODE = "urn:oasis:names:tc:SAML:2.0:status:Success";
	public static final String PROTOCOL_BINDING = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST";
	public static final SAMLVersion VERSION = SAMLVersion.VERSION_20;
	public static final Boolean FORCE_AUTHN = Boolean.TRUE;
	public static final Boolean IS_PASSIVE = Boolean.FALSE;

	public static final String SAML_ASSERTION_SIGN_REQUIRED = "saml.assertion.signature.required";
	public static final String SAML_RESPONSE_SIGN_REQUIRED = "saml.response.signature.required";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	/**
	 * Maximum time from response creation when the message is deemed valid.
	 */
	public static final int RESPONSE_SKEW = 300;

}
