package com.hcentive.billing.core.saml.configuration;

public interface SAMLReceiverEndpoint extends SAMLEndPoint {
	public String endpoint();

	public String encryptionCertPath();

	public String keystorePath();

	public String keystorePassword();

	public String privateKeyAlias();

	public String issuerPublicCertPath();
}
