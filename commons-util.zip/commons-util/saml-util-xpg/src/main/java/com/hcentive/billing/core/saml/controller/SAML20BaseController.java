package com.hcentive.billing.core.saml.controller;

import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.opensaml.common.SAMLException;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.XMLParserException;
import org.opensaml.xml.signature.SignatureException;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.xml.sax.SAXException;

import com.hcentive.billing.core.saml.AuthRequestBuilder;
import com.hcentive.billing.core.saml.SAMLConsumer;
import com.hcentive.billing.core.saml.SAMLResponseBuilder;
import com.hcentive.billing.core.saml.configuration.SAMLIssuerEndpoint;
import com.hcentive.billing.core.saml.configuration.SAMLReceiverEndpoint;
import com.hcentive.billing.core.saml.configuration.SamlConfiguration;

@Controller
public abstract class SAML20BaseController {
	private static final Logger logger = LoggerFactory
			.getLogger(SAML20BaseController.class);

	@Autowired
	private SAMLConsumer samlConsumer;

	/*
	 * @Autowired private SamlConfiguration samlConfiguration;
	 */
	/*
	 * @Autowired private SamlConfigService samlConfigService;
	 */

	protected final Map<String, String> consumeSAMLResponse(
			final HttpServletRequest request,
			final SamlConfiguration issuerConfig) throws CertificateException,
			NoSuchAlgorithmException, InvalidKeySpecException,
			ConfigurationException, XMLParserException, UnmarshallingException,
			IOException, SAXException, ValidationException, SAMLException,
			KeyStoreException, UnrecoverableEntryException,
			DecryptionException, MarshallingException {
		logger.debug("Getting SAML Response ");
		String samlResponse = request.getParameter("SAMLResponse");
		logger.debug("SAML Response Found :: {}", samlResponse);

		SAMLIssuerEndpoint issuer = (SAMLIssuerEndpoint) issuerConfig
				.samlEndPoint();

		Map<String, String> attributesMap = samlConsumer.consumeResponse(
				samlResponse, issuer.receiverPublicCertPath(),
				issuer.decryptionCertPath(), issuer.decryptionKeystorePath(),
				issuer.decryptionKeystorePassword(),
				issuer.decryptionPrivateKeyAlias(), issuerConfig.params());
		logger.debug("SAML Response Consumed");
		return attributesMap;
	}

	// final SAMLIssuerEndpoint issuer
	protected final Map<String, String> consumeSAMLResponse(
			final String samlResponse, final SamlConfiguration issuerConfig)
			throws CertificateException, NoSuchAlgorithmException,
			InvalidKeySpecException, ConfigurationException,
			XMLParserException, UnmarshallingException, IOException,
			SAXException, ValidationException, SAMLException,
			KeyStoreException, UnrecoverableEntryException,
			DecryptionException, MarshallingException {
		SAMLIssuerEndpoint issuer = (SAMLIssuerEndpoint) issuerConfig
				.samlEndPoint();
		Map<String, String> attributesMap = samlConsumer.consumeResponse(
				samlResponse, issuer.receiverPublicCertPath(),
				issuer.decryptionCertPath(), issuer.decryptionKeystorePath(),
				issuer.decryptionKeystorePassword(),
				issuer.decryptionPrivateKeyAlias(), issuerConfig.params());
		logger.debug("SAML Response Consumed");
		return attributesMap;
	}

	protected final String createAuthnRequest(final HttpServletRequest request,
			final SAMLReceiverEndpoint receiver,
			final String assertionConsumerUrl, final String issuerDomain) throws CertificateException, KeyStoreException, IOException, MarshallingException, SignatureException  {
		return AuthRequestBuilder.newBuilder()
				.forAssertionConsumerUrl(assertionConsumerUrl)
				.toDestinationUrl(receiver.endpoint())
				.withCertPath(receiver.issuerPublicCertPath())
				.withKeyStorePassword(receiver.keystorePassword())
				.withKeyStorePath(receiver.keystorePath())
				.withPrivateKeyAlias(receiver.privateKeyAlias())
				.forIssuer(issuerDomain).build();
	}

	private SAMLResponseBuilder createResponseBuilder(
			final Map<String, String> attributeMap,
			final SAMLReceiverEndpoint receiver, final String issuerDomain) {
		return (SAMLResponseBuilder) SAMLResponseBuilder.newBuilder()
				.withAttributeMap(attributeMap)
				.withCertPath(receiver.issuerPublicCertPath())
				.withKeyStorePassword(receiver.keystorePassword())
				.withKeyStorePath(receiver.keystorePath())
				.withPrivateKeyAlias(receiver.privateKeyAlias())
				.forIssuer(issuerDomain).toDestinationUrl(receiver.endpoint());
	}

	protected final String createSAMLResponse(
			final Map<String, String> attributeMap,final SAMLReceiverEndpoint receiver, final String issuerDomain,boolean isEncrypted) throws CertificateException, IOException, MarshallingException, KeyStoreException, SignatureException {
		logger.debug("Creating SAML Response..");
		if (isEncrypted) {
			return createResponseBuilder(attributeMap, receiver, issuerDomain)
					.withEncryption(receiver.encryptionCertPath()).build();
		} else {
			return createResponseBuilder(attributeMap, receiver, issuerDomain)
					.build();
		}
	}
}
