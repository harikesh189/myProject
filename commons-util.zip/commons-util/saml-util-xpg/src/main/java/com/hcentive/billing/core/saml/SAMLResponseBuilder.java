package com.hcentive.billing.core.saml;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Map;

import org.joda.time.DateTime;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.AttributeValue;
import org.opensaml.saml2.core.AuthnContext;
import org.opensaml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml2.core.AuthnStatement;
import org.opensaml.saml2.core.Conditions;
import org.opensaml.saml2.core.EncryptedAssertion;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.Status;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.Subject;
import org.opensaml.saml2.core.SubjectLocality;
import org.opensaml.saml2.core.impl.AssertionBuilder;
import org.opensaml.saml2.core.impl.AttributeBuilder;
import org.opensaml.saml2.core.impl.AttributeStatementBuilder;
import org.opensaml.saml2.core.impl.AuthnContextBuilder;
import org.opensaml.saml2.core.impl.AuthnContextClassRefBuilder;
import org.opensaml.saml2.core.impl.AuthnStatementBuilder;
import org.opensaml.saml2.core.impl.ConditionsBuilder;
import org.opensaml.saml2.core.impl.ResponseBuilder;
import org.opensaml.saml2.core.impl.StatusBuilder;
import org.opensaml.saml2.core.impl.StatusCodeBuilder;
import org.opensaml.saml2.core.impl.SubjectLocalityBuilder;
import org.opensaml.saml2.encryption.Encrypter;
import org.opensaml.saml2.encryption.Encrypter.KeyPlacement;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.XMLObjectBuilder;
import org.opensaml.xml.encryption.EncryptionConstants;
import org.opensaml.xml.encryption.EncryptionException;
import org.opensaml.xml.encryption.EncryptionParameters;
import org.opensaml.xml.encryption.KeyEncryptionParameters;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.schema.XSAny;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.keyinfo.KeyInfoGeneratorFactory;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.SignatureException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.util.RandomGenerator;

public class SAMLResponseBuilder extends SAMLObjectBuilder<Response> {

	private static final Logger logger = LoggerFactory
			.getLogger(SAMLResponseBuilder.class);

	private String assertionConsumerUrl;
	private Map<String, String> attributeMap;
	private boolean isEncrypted = false;
	private String encryptionCertPath;
	private DateTime issueInstant;
	private DateTime notOnOrAfterInstant;
	private static String saml2SuccessStatusCode = "urn:oasis:names:tc:SAML:2.0:status:Success";
	private static String authnContextRefClass = "urn:oasis:names:tc:SAML:2.0:ac:classes:unspecified";
	private static String attributeNameFormat = "urn:oasis:names:tc:SAML:2.0:attrname-format:unspecified";

	public static SAMLResponseBuilder newBuilder() {
		SAMLResponseBuilder samlResponseBuilder = new SAMLResponseBuilder();
		return samlResponseBuilder;
	}

	public SAMLResponseBuilder forAssertionConsumerUrl(
			final String assertionConsumerUrl) {
		this.assertionConsumerUrl = assertionConsumerUrl;
		return this;
	}

	public SAMLResponseBuilder withAttributeMap(
			final Map<String, String> attributeMap) {
		this.attributeMap = attributeMap;
		return this;
	}

	public SAMLResponseBuilder withEncryption(final String encryptionCertPath) {
		this.isEncrypted = true;
		this.encryptionCertPath = encryptionCertPath;
		return this;
	}

	protected Response doBuild() throws CertificateException,IOException,MarshallingException,KeyStoreException, SignatureException{
		issueInstant = new DateTime();
		notOnOrAfterInstant = new DateTime(
				issueInstant.getMillis() + 15 * 60 * 1000);
		logger.debug("SAML Response building starts here");
		Response response = ((ResponseBuilder) builderFactory
				.getBuilder(Response.DEFAULT_ELEMENT_NAME)).buildObject();
		response.setID(RandomGenerator.randomString());
		response.setIssuer(buildIssuer(issuer()));
		// response.setAssertionConsumerServiceURL(assertionConsumerUrl);
		response.setDestination(getDestinationUrl());
		response.setID(RandomGenerator.randomString());
		response.setVersion(SAMLConfigConstants.VERSION);
		response.setIssueInstant(issueInstant);
		setStatusCode(response);
		if (isEncrypted) {
			try {
				response.getEncryptedAssertions()
						.add(buildEncryptedAssertion());
			} catch (CertificateException e) {
				logger.error(e.getMessage(), e);
				logger.error("Inside catch of CertificateException..");
				throw new CertificateException("CertificateException");
				
			} catch (KeyStoreException e) {
				logger.error(e.getMessage(), e);
				throw new KeyStoreException("KeyStoreException");
			} catch (NoSuchAlgorithmException e) {
				logger.error(e.getMessage(), e);
			} catch (UnrecoverableEntryException e) {
				logger.error(e.getMessage(), e);
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				throw new IOException("IOException");
			} catch (EncryptionException e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			response.getAssertions().add(buildSignedAssertion());
		}
	
		try {
			signXMLObject(response);
		} catch (CertificateException e) {
			logger.error(e.getMessage(), e);
			throw new CertificateException("CertificateException");

		} catch (KeyStoreException e) {
			logger.error(e.getMessage(), e);
			throw new KeyStoreException("KeyStoreException");
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			throw new IOException("IOException");
		}catch (SignatureException e) {
			logger.error(e.getMessage(), e);
			throw new SignatureException("SignatureException");
		}
		logger.debug(" SAML Response :::: {}", response);
		return response;

	}

	private void setStatusCode(Response response) {
		StatusBuilder statusBuilder = (StatusBuilder) builderFactory
				.getBuilder(Status.DEFAULT_ELEMENT_NAME);
		Status status = statusBuilder.buildObject();
		response.setStatus(status);

		StatusCodeBuilder statusCodeBuilder = (StatusCodeBuilder) builderFactory
				.getBuilder(StatusCode.DEFAULT_ELEMENT_NAME);
		StatusCode statusCode = statusCodeBuilder.buildObject();
		statusCode.setValue(saml2SuccessStatusCode);
		status.setStatusCode(statusCode);
	}

	private Assertion buildSignedAssertion() throws CertificateException, IOException, MarshallingException, KeyStoreException, SignatureException {
		Assertion assertion = ((AssertionBuilder) builderFactory
				.getBuilder(Assertion.DEFAULT_ELEMENT_NAME)).buildObject();
		assertion.setID(RandomGenerator.randomString());
		assertion.setIssueInstant(issueInstant);
		assertion.setIssuer(buildIssuer(issuer()));
		Subject subject = buildSubject(attributeMap.get("subjectId"));
		attributeMap.remove("subjectId");
		assertion.setSubject(subject);
		Conditions conditions = buildConditions();
		assertion.setConditions(conditions);
		AttributeStatement attributeStatement = buildAttributeStatement(attributeMap);
		assertion.getAttributeStatements().add(attributeStatement);
		AuthnStatement authnStatement = buildAuthnStatement();
		assertion.getAuthnStatements().add(authnStatement);
		signXMLObject(assertion);
		return assertion;

	}

	private Conditions buildConditions() {

		ConditionsBuilder conditionsBuilder = (ConditionsBuilder) builderFactory
				.getBuilder(Conditions.DEFAULT_ELEMENT_NAME);
		Conditions conditions = conditionsBuilder.buildObject();
		conditions.setNotOnOrAfter(notOnOrAfterInstant);
		conditions.setNotBefore(issueInstant);
		return conditions;
	}

	private AuthnStatement buildAuthnStatement() {
		AuthnStatement authnStatement = ((AuthnStatementBuilder) builderFactory
				.getBuilder(AuthnStatement.DEFAULT_ELEMENT_NAME)).buildObject();
		authnStatement.setAuthnInstant(issueInstant);
		authnStatement.setSessionNotOnOrAfter(notOnOrAfterInstant);
		SubjectLocality subjectLocality = ((SubjectLocalityBuilder) builderFactory
				.getBuilder(SubjectLocality.DEFAULT_ELEMENT_NAME))
				.buildObject();
		authnStatement.setSubjectLocality(subjectLocality);
		AuthnContext authnContext = ((AuthnContextBuilder) builderFactory
				.getBuilder(AuthnContext.DEFAULT_ELEMENT_NAME)).buildObject();
		authnStatement.setAuthnContext(authnContext);
		AuthnContextClassRef authnContextClassRef = ((AuthnContextClassRefBuilder) builderFactory
				.getBuilder(AuthnContextClassRef.DEFAULT_ELEMENT_NAME))
				.buildObject();
		authnContextClassRef.setAuthnContextClassRef(authnContextRefClass);
		authnContext.setAuthnContextClassRef(authnContextClassRef);
		return authnStatement;
	}

	private AttributeStatement buildAttributeStatement(
			Map<String, String> attributeMap) {
		AttributeStatement attributeStatement = ((AttributeStatementBuilder) builderFactory
				.getBuilder(AttributeStatement.DEFAULT_ELEMENT_NAME))
				.buildObject();
		AttributeBuilder attributeBuilder = (AttributeBuilder) builderFactory
				.getBuilder(Attribute.DEFAULT_ELEMENT_NAME);
		@SuppressWarnings("unchecked")
		XMLObjectBuilder<XSAny> xsAnyBuilder = builderFactory
				.getBuilder(XSAny.TYPE_NAME);
		for (String attributeName : attributeMap.keySet()) {
			String attributeValue = attributeMap.get(attributeName);
			Attribute attribute = attributeBuilder.buildObject();
			attribute.setNameFormat(attributeNameFormat);
			attribute.setName(attributeName);
			attributeStatement.getAttributes().add(attribute);
			XSAny attributeValueAny = xsAnyBuilder
					.buildObject(AttributeValue.DEFAULT_ELEMENT_NAME);
			attributeValueAny.setTextContent(attributeValue);
			attribute.getAttributeValues().add(attributeValueAny);
		}

		return attributeStatement;
	}

	private EncryptedAssertion buildEncryptedAssertion()
			throws CertificateException, IOException, KeyStoreException,
			NoSuchAlgorithmException, UnrecoverableEntryException,
			EncryptionException, MarshallingException, SignatureException {
		EncryptedAssertion encryptedAssertion = null;
		Assertion assertion = buildSignedAssertion();
		Credential keyEncryptionCredential = intializeEncryptionCredentials();
		EncryptionParameters encParams = new EncryptionParameters();
		encParams.setAlgorithm(EncryptionConstants.ALGO_ID_BLOCKCIPHER_AES128);
		KeyEncryptionParameters kekParams = new KeyEncryptionParameters();
		kekParams.setEncryptionCredential(keyEncryptionCredential);
		kekParams
				.setAlgorithm(EncryptionConstants.ALGO_ID_KEYTRANSPORT_RSAOAEP);
		KeyInfoGeneratorFactory kigf = Configuration
				.getGlobalSecurityConfiguration().getKeyInfoGeneratorManager()
				.getDefaultManager().getFactory(keyEncryptionCredential);
		kekParams.setKeyInfoGenerator(kigf.newInstance());
		Encrypter samlEncrypter = new Encrypter(encParams, kekParams);
		samlEncrypter.setKeyPlacement(KeyPlacement.PEER);
		encryptedAssertion = samlEncrypter.encrypt(assertion);
		return encryptedAssertion;
	}

	protected Credential intializeEncryptionCredentials() throws IOException,
			CertificateException, KeyStoreException, NoSuchAlgorithmException,
			UnrecoverableEntryException {
		FileInputStream certificateStream = new FileInputStream(
				this.encryptionCertPath);
		CertificateFactory certificateFactory = CertificateFactory
				.getInstance("X.509");
		Certificate[] chain = {};
		chain = certificateFactory.generateCertificates(certificateStream)
				.toArray(chain);
		certificateStream.close();
		BasicX509Credential credential = new BasicX509Credential();
		credential.setEntityCertificate((X509Certificate) chain[0]);
		return credential;
	}
}
