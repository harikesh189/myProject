package com.hcentive.billing.core.saml.configuration;

public interface SAMLIssuerEndpoint extends SAMLEndPoint {
	public String receiverPublicCertPath();

	public String decryptionCertPath();

	public String decryptionKeystorePath();

	public String decryptionKeystorePassword();

	public String decryptionPrivateKeyAlias();
}
