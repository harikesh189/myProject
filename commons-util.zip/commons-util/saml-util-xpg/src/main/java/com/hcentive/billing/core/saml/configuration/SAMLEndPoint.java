package com.hcentive.billing.core.saml.configuration;

public interface SAMLEndPoint {

	public String getIdentifier();

	public String getName();

	public String getDomain();
}
