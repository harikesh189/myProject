package com.hcentive.billing.core.saml;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.namespace.QName;

import org.opensaml.DefaultBootstrap;
import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.EncryptedAssertion;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.encryption.Decrypter;
import org.opensaml.saml2.encryption.EncryptedElementTypeEncryptedKeyResolver;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.encryption.ChainingEncryptedKeyResolver;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.encryption.EncryptedKeyResolver;
import org.opensaml.xml.encryption.InlineEncryptedKeyResolver;
import org.opensaml.xml.encryption.SimpleRetrievalMethodEncryptedKeyResolver;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.BasicParserPool;
import org.opensaml.xml.parse.XMLParserException;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.keyinfo.StaticKeyInfoCredentialResolver;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.util.Base64;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

@Component
public class SAMLConsumer {
	private static Logger logger = LoggerFactory.getLogger(SAMLConsumer.class);

	@Autowired
	private SAMLResponseValidator samlResponseValidator;

	public Map<String, String> consumeResponse(String samlResponse,
			final String publicCertPath, final String encryptedCertPath,
			final String encryptedKeystorePath,
			final String encryptedKeystorePassword,
			final String encryptedKeyAlias, final Map<String, String> params)
			throws ConfigurationException, XMLParserException,
			UnmarshallingException, CertificateException,
			NoSuchAlgorithmException, InvalidKeySpecException, IOException,
			SAXException, ValidationException, SAMLException,
			KeyStoreException, UnrecoverableEntryException,
			DecryptionException, MarshallingException {
		Map<String, String> attributeMap = null;

		logger.info("Consuming Response");
		samlResponse = decodeSAMLResponse(samlResponse);
		logger.info("SAML Response:" + samlResponse);

		// initialize the opensaml library
		DefaultBootstrap.bootstrap();

		BasicParserPool parserPoolManager = createPoolManager();

		Response response = createSAMLResponse(parserPoolManager, samlResponse);

		samlResponseValidator.validate(response, publicCertPath,
				encryptedCertPath, encryptedKeystorePath,
				encryptedKeystorePassword, encryptedKeyAlias, params);

		attributeMap = getSAMLAttributes(response, encryptedCertPath,
				encryptedKeystorePath, encryptedKeystorePassword,
				encryptedKeyAlias);

		for (Entry<String, String> attribute : attributeMap.entrySet()) {
			logger.info(attribute.getKey(), "{} : {}", attribute.getValue());
		}
		return attributeMap;
	}

	private String decodeSAMLResponse(String samlResponse)
			throws UnsupportedEncodingException {
		byte[] data = Base64.decode(samlResponse);
		samlResponse = new String(data, "UTF-8");
		return samlResponse;
	}

	private Map<String, String> getSAMLAttributes(Response response,
			String encryptedCertPath, String encryptedKeystorePath,
			String encryptedKeystorePassword, String encryptedKeyAlias)
			throws DecryptionException, CertificateException,
			KeyStoreException, NoSuchAlgorithmException,
			UnrecoverableEntryException, IOException {

		Assertion assertion = null;
		if (response.getAssertions() != null
				&& response.getAssertions().size() > 0) {
			assertion = response.getAssertions().get(0);
		}

		if (response.getEncryptedAssertions() != null
				&& response.getEncryptedAssertions().size() > 0) {
			Credential decryptionCredential = intializeEncryptionCredentials(
					encryptedCertPath, encryptedKeystorePath,
					encryptedKeystorePassword, encryptedKeyAlias);

			final ChainingEncryptedKeyResolver encryptedKeyResolver = new ChainingEncryptedKeyResolver();
			final List<EncryptedKeyResolver> resolverChain = encryptedKeyResolver
					.getResolverChain();
			resolverChain.add(new SimpleRetrievalMethodEncryptedKeyResolver());
			resolverChain.add(new InlineEncryptedKeyResolver());
			resolverChain.add(new EncryptedElementTypeEncryptedKeyResolver());
			Decrypter samlDecrypter = new Decrypter(null,
					new StaticKeyInfoCredentialResolver(decryptionCredential),
					encryptedKeyResolver);
			EncryptedAssertion encryptedAssertion = response
					.getEncryptedAssertions().get(0);
			assertion = samlDecrypter.decrypt(encryptedAssertion);
		}

		logger.debug("Assertion Id : {}", assertion.getID());

		// loop through the nodes to get what we want
		List<AttributeStatement> attributeStatements = assertion
				.getAttributeStatements();
		Map<String, String> attributeMap = new HashMap<String, String>();
		for (int i = 0; i < attributeStatements.size(); i++) {
			List<Attribute> attributes = attributeStatements.get(i)
					.getAttributes();
			for (int x = 0; x < attributes.size(); x++) {
				String strAttributeName = attributes.get(x).getDOM()
						.getAttribute("Name");

				List<XMLObject> attributeValues = attributes.get(x)
						.getAttributeValues();
				for (int y = 0; y < attributeValues.size(); y++) {
					String strAttributeValue = attributeValues.get(y).getDOM()
							.getTextContent();
					attributeMap.put(strAttributeName, strAttributeValue);
				}
			}
		}

		if (assertion.getSubject() != null
				&& assertion.getSubject().getNameID() != null)
			attributeMap.put("subjectId", assertion.getSubject().getNameID()
					.getValue());
		return attributeMap;
	}

	private BasicParserPool createPoolManager() throws SAXException {
		BasicParserPool parserPoolManager = new BasicParserPool();
		parserPoolManager.setNamespaceAware(true);
		parserPoolManager.setIgnoreElementContentWhitespace(true);
		return parserPoolManager;
	}

	private Response createSAMLResponse(BasicParserPool parserPoolManager,
			String samlResponse) throws FileNotFoundException,
			XMLParserException, UnmarshallingException {
		logger.debug("SAML RESPONSE Creation starts here");
		InputStream inputStream = new ByteArrayInputStream(
				samlResponse.getBytes());
		Document document = parserPoolManager.parse(inputStream);
		Element metadataRoot = document.getDocumentElement();

		QName qName = new QName(metadataRoot.getNamespaceURI(),
				metadataRoot.getLocalName(), metadataRoot.getPrefix());

		// get an unmarshaller
		Unmarshaller unmarshaller = Configuration.getUnmarshallerFactory()
				.getUnmarshaller(qName);

		// unmarshall using the document root element
		Response response = (Response) unmarshaller.unmarshall(metadataRoot);
		logger.debug("SAML RESPONSE created");
		return response;
	}

	private Credential intializeEncryptionCredentials(String encryptedCertPath,
			String encryptedKeystorePath, String encryptedKeystorePassword,
			String encryptedKeyAlias) throws IOException, CertificateException,
			KeyStoreException, NoSuchAlgorithmException,
			UnrecoverableEntryException {

		KeyStore ks = null;
		FileInputStream fis = null;
		ks = KeyStore.getInstance(KeyStore.getDefaultType());
		fis = new FileInputStream(encryptedKeystorePath);
		ks.load(fis, encryptedKeystorePassword.toCharArray());
		fis.close();
		KeyStore.PrivateKeyEntry pkEntry = null;
		pkEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(
				encryptedKeyAlias,
				new KeyStore.PasswordProtection(encryptedKeystorePassword
						.toCharArray()));
		PrivateKey pk = pkEntry.getPrivateKey();
		FileInputStream certificateStream = new FileInputStream(
				encryptedCertPath);
		CertificateFactory certificateFactory = CertificateFactory
				.getInstance("X.509");
		Certificate[] chain = {};
		chain = certificateFactory.generateCertificates(certificateStream)
				.toArray(chain);
		certificateStream.close();
		BasicX509Credential credential = new BasicX509Credential();
		credential.setEntityCertificate((X509Certificate) chain[0]);
		credential.setPrivateKey(pk);
		return credential;
	}
}
