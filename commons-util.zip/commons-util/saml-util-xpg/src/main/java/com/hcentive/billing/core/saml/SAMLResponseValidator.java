package com.hcentive.billing.core.saml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.List;
import java.util.Map;

import org.apache.xml.security.signature.XMLSignatureException;
import org.joda.time.DateTime;
import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.EncryptedAssertion;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.StatusMessage;
import org.opensaml.saml2.encryption.Decrypter;
import org.opensaml.saml2.encryption.EncryptedElementTypeEncryptedKeyResolver;
import org.opensaml.security.SAMLSignatureProfileValidator;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.encryption.ChainingEncryptedKeyResolver;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.encryption.EncryptedKeyResolver;
import org.opensaml.xml.encryption.InlineEncryptedKeyResolver;
import org.opensaml.xml.encryption.SimpleRetrievalMethodEncryptedKeyResolver;
import org.opensaml.xml.io.Marshaller;
import org.opensaml.xml.io.MarshallerFactory;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.keyinfo.StaticKeyInfoCredentialResolver;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureValidator;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SAMLResponseValidator {

	private static Logger logger = LoggerFactory
			.getLogger(SAMLResponseValidator.class);

	public void validate(Response response, String publicCertPath,
			String encryptedCertPath, String encryptedKeystorePath,
			String encryptedKeystorePassword, String encryptedKeyAlias,
			Map<String, String> params) throws SAMLException,
			FileNotFoundException, CertificateException,
			NoSuchAlgorithmException, InvalidKeySpecException, IOException,
			ValidationException, KeyStoreException,
			UnrecoverableEntryException, DecryptionException,
			MarshallingException {

		verifyStatus(response);

		verifyIssueTime(response);

		validateSAMLSignature(response, publicCertPath, encryptedCertPath,
				encryptedKeystorePath, encryptedKeystorePassword,
				encryptedKeyAlias, params);

	}

	private void validateSAMLSignature(Response response,
			final String publicCertPath, String encryptedCertPath,
			String encryptedKeystorePath, String encryptedKeystorePassword,
			String encryptedKeyAlias, Map<String, String> params)
			throws FileNotFoundException, CertificateException, IOException,
			NoSuchAlgorithmException, InvalidKeySpecException,
			ValidationException, KeyStoreException,
			UnrecoverableEntryException, DecryptionException,
			MarshallingException {

		File certificateFile = new File(publicCertPath);

		// get the certificate from the file
		InputStream inputStream2 = new FileInputStream(certificateFile);
		CertificateFactory certificateFactory = CertificateFactory
				.getInstance("X.509");
		X509Certificate certificate = (X509Certificate) certificateFactory
				.generateCertificate(inputStream2);
		inputStream2.close();

		// pull out the public key part of the certificate into a KeySpec
		X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(certificate
				.getPublicKey().getEncoded());

		// get KeyFactory object that creates key objects, specifying RSA
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		logger.info("Security Provider: " + keyFactory.getProvider().toString());
		// generate public key to validate signatures
		PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);

		// we have the public key
		logger.info("Public Key created");
		// create credentials
		BasicX509Credential publicCredential = new BasicX509Credential();

		// add public key value
		publicCredential.setPublicKey(publicKey);

		// create SignatureValidator
		SignatureValidator signatureValidator = new SignatureValidator(
				publicCredential);

		// get the signature to validate from the response object
		Signature respSignature = response.getSignature();
		SAMLSignatureProfileValidator profileValidator = new SAMLSignatureProfileValidator();

		if (response.getAssertions() != null
				&& response.getAssertions().size() > 0) {
			for (Assertion assertion : response.getAssertions()) {
				Signature assertionSignature = assertion.getSignature();

				if (assertionSignature == null
						&& (SAMLConfigConstants.TRUE
								.equalsIgnoreCase(params
										.get(SAMLConfigConstants.SAML_ASSERTION_SIGN_REQUIRED)) || params
								.get(SAMLConfigConstants.SAML_ASSERTION_SIGN_REQUIRED) == null)) {
					throw new ValidationException(
							"assertionSignature is null and assertionSignatureFlag is true or null",
							new XMLSignatureException());

				}
				if (assertionSignature != null) {
					logger.info("Validating assertion Signature");
					profileValidator.validate(assertionSignature);
					signatureValidator.validate(assertionSignature);
					logger.info("Assertion Signature is valid.");
				}
			}

		}

		if (response.getEncryptedAssertions() != null
				&& response.getEncryptedAssertions().size() > 0) {
			Credential decryptionCredential = intializeEncryptionCredentials(
					encryptedCertPath, encryptedKeystorePath,
					encryptedKeystorePassword, encryptedKeyAlias);
			final ChainingEncryptedKeyResolver encryptedKeyResolver = new ChainingEncryptedKeyResolver();
			final List<EncryptedKeyResolver> resolverChain = encryptedKeyResolver
					.getResolverChain();
			resolverChain.add(new SimpleRetrievalMethodEncryptedKeyResolver());
			resolverChain.add(new InlineEncryptedKeyResolver());
			resolverChain.add(new EncryptedElementTypeEncryptedKeyResolver());
			Decrypter samlDecrypter = new Decrypter(null,
					new StaticKeyInfoCredentialResolver(decryptionCredential),
					encryptedKeyResolver);
			for (EncryptedAssertion encryptedAssertion : response
					.getEncryptedAssertions()) {

				Assertion assertion = samlDecrypter.decrypt(encryptedAssertion);
				MarshallerFactory marshallerFactory = Configuration
						.getMarshallerFactory();
				Marshaller asrtnMarshaller = marshallerFactory
						.getMarshaller(assertion);
				asrtnMarshaller.marshall(assertion);
				Signature assertionSignature = assertion.getSignature();

				if (assertionSignature == null
						&& (SAMLConfigConstants.TRUE
								.equalsIgnoreCase(params
										.get(SAMLConfigConstants.SAML_ASSERTION_SIGN_REQUIRED)) || params
								.get(SAMLConfigConstants.SAML_ASSERTION_SIGN_REQUIRED) == null)) {
					throw new ValidationException(
							"assertionSignature is null and assertionSignatureFlag is true or null",
							new XMLSignatureException());

				}

				if (assertionSignature != null) {
					logger.info("Validating assertion Signature");
					profileValidator.validate(assertionSignature);
					signatureValidator.validate(assertionSignature);
					logger.info("Assertion Signature is valid.");
				}
			}
		}

		if (respSignature == null
				&& (SAMLConfigConstants.TRUE.equalsIgnoreCase(params
						.get(SAMLConfigConstants.SAML_RESPONSE_SIGN_REQUIRED)) || params
						.get(SAMLConfigConstants.SAML_RESPONSE_SIGN_REQUIRED) == null)) {
			throw new ValidationException(
					"respSign is null and responseSignFlag is true or null",
					new XMLSignatureException());

		}
		// Validate response signature
		if (respSignature != null) {
			logger.info("Validating Response Signature");
			profileValidator.validate(respSignature);
			signatureValidator.validate(respSignature);
			logger.info("Response Signature is valid.");
		}
		// no validation exception was thrown

	}

	// Verify issue time
	private void verifyIssueTime(Response response) throws SAMLException {
		DateTime time = response.getIssueInstant();
		if (!SAMLUtil.isDateTimeSkewValid(SAMLConfigConstants.RESPONSE_SKEW,
				time)) {
			throw new SAMLException(
					"Response issue time is either too old or with date in the future, skew "
							+ SAMLConfigConstants.RESPONSE_SKEW + ", time "
							+ time);
		}
	}

	// Verify status
	private void verifyStatus(Response response) throws SAMLException {
		String statusCode = response.getStatus().getStatusCode().getValue();
		if (!StatusCode.SUCCESS_URI.equals(statusCode)) {
			StatusMessage statusMessage = response.getStatus()
					.getStatusMessage();
			String statusMessageText = null;
			if (statusMessage != null) {
				statusMessageText = statusMessage.getMessage();
			}
			throw new SAMLException("Response has invalid status code "
					+ statusCode + ", status message is " + statusMessageText);
		}
	}

	protected Credential intializeEncryptionCredentials(
			String encryptedCertPath, String encryptedKeystorePath,
			String encryptedKeystorePassword, String encryptedKeyAlias)
			throws IOException, CertificateException, KeyStoreException,
			NoSuchAlgorithmException, UnrecoverableEntryException {

		KeyStore ks = null;
		FileInputStream fis = null;
		ks = KeyStore.getInstance(KeyStore.getDefaultType());
		fis = new FileInputStream(encryptedKeystorePath);
		ks.load(fis, encryptedKeystorePassword.toCharArray());
		fis.close();
		KeyStore.PrivateKeyEntry pkEntry = null;
		pkEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(
				encryptedKeyAlias,
				new KeyStore.PasswordProtection(encryptedKeystorePassword
						.toCharArray()));
		PrivateKey pk = pkEntry.getPrivateKey();
		FileInputStream certificateStream = new FileInputStream(
				encryptedCertPath);
		CertificateFactory certificateFactory = CertificateFactory
				.getInstance("X.509");
		Certificate[] chain = {};
		chain = certificateFactory.generateCertificates(certificateStream)
				.toArray(chain);
		certificateStream.close();
		BasicX509Credential credential = new BasicX509Credential();
		credential.setEntityCertificate((X509Certificate) chain[0]);
		credential.setPrivateKey(pk);
		return credential;
	}
}
