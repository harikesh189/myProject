package com.hcentive.billing.core.saml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import org.joda.time.DateTime;
import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.Subject;
import org.opensaml.saml2.core.SubjectConfirmation;
import org.opensaml.saml2.core.SubjectConfirmationData;
import org.opensaml.saml2.core.impl.IssuerBuilder;
import org.opensaml.saml2.core.impl.NameIDBuilder;
import org.opensaml.saml2.core.impl.SubjectBuilder;
import org.opensaml.saml2.core.impl.SubjectConfirmationBuilder;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.XMLObjectBuilderFactory;
import org.opensaml.xml.io.MarshallerFactory;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.security.SecurityHelper;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.security.x509.X509KeyInfoGeneratorFactory;
import org.opensaml.xml.signature.SignableXMLObject;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureConstants;
import org.opensaml.xml.signature.SignatureException;
import org.opensaml.xml.signature.Signer;
import org.opensaml.xml.util.Base64;
import org.opensaml.xml.util.XMLHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;


@SuppressWarnings("rawtypes")
public abstract class SAMLObjectBuilder<X extends XMLObject> {

	private static final Logger logger = LoggerFactory
			.getLogger(SAMLObjectBuilder.class);

	protected static final XMLObjectBuilderFactory builderFactory = Configuration
			.getBuilderFactory();
	private static final MarshallerFactory marhsallerFactory = Configuration
			.getMarshallerFactory();

	private String keyStorePath;
	private String destinationUrl;
	private String keystorePassword;
	private String privateKeyAlias;
	private String certPath;
	private String issuer;
	private static String subjectConfirmationMethod = "urn:oasis:names:tc:SAML:2.0:cm:bearer";

	static {
		try {
			DefaultBootstrap.bootstrap();
		} catch (ConfigurationException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
		}
	}

	public final String build() throws CertificateException, IOException, MarshallingException, KeyStoreException, SignatureException {
		String saml = marshalAndEncode(doBuild());
		logger.debug(saml);
		return saml;
	}

	protected abstract X doBuild() throws CertificateException, IOException, MarshallingException, KeyStoreException, SignatureException;

	public SAMLObjectBuilder forIssuer(final String issuerValue) {
		this.issuer = issuerValue;
		return this;
	}

	public SAMLObjectBuilder toDestinationUrl(String destinationUrl) {
		this.destinationUrl = destinationUrl;
		return this;
	}

	public String getDestinationUrl() {
		return destinationUrl;
	}

	protected String issuer() {
		return this.issuer;
	}

	public SAMLObjectBuilder withKeyStorePath(final String keyStorePath) {
		this.keyStorePath = keyStorePath;
		return this;
	}

	public SAMLObjectBuilder withKeyStorePassword(final String keystorePassword) {
		this.keystorePassword = keystorePassword;
		return this;
	}

	public SAMLObjectBuilder withCertPath(final String certPath) {
		this.certPath = certPath;
		return this;
	}

	public SAMLObjectBuilder withPrivateKeyAlias(final String privateKeyAlias) {
		this.privateKeyAlias = privateKeyAlias;
		return this;
	}

	protected Issuer buildIssuer(final String issuerValue) {
		IssuerBuilder issuerBuilder = (IssuerBuilder) builderFactory
				.getBuilder(Issuer.DEFAULT_ELEMENT_NAME);
		Issuer issuer = issuerBuilder.buildObject();
		issuer.setFormat(SAMLConfigConstants.ISSUER_FORMAT);
		issuer.setValue(issuerValue);
		return issuer;
	}

	private String marshal(XMLObject xmlObject) {
		try {
			return XMLHelper.nodeToString(doMarshal(xmlObject));
		} catch (MarshallingException e) {
			throw new RuntimeException(e);
		}
	}

	private Element doMarshal(XMLObject xmlObject) throws MarshallingException {
		return marhsallerFactory.getMarshaller(xmlObject).marshall(xmlObject);
	}

	private String marshalAndEncode(XMLObject xmlObject) {
		final String xmlString = marshal(xmlObject);
		return Base64.encodeBytes(xmlString.getBytes(), Base64.NO_OPTIONS);
	}

	protected void signXMLObject(SignableXMLObject signableXMLObject) throws CertificateException,IOException,MarshallingException,KeyStoreException, SignatureException {
		Signature signature = (Signature) builderFactory.getBuilder(
				Signature.DEFAULT_ELEMENT_NAME).buildObject(
				Signature.DEFAULT_ELEMENT_NAME);
		X509KeyInfoGeneratorFactory keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
		keyInfoGeneratorFactory.setEmitEntityCertificate(true);
		signature
				.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA1);
		signature
				.setCanonicalizationAlgorithm(SignatureConstants.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);
		Credential signingCredential;
		try {
			signingCredential = intializeCredentials();
			signature.setSigningCredential(signingCredential);
			signature.setKeyInfo(keyInfoGeneratorFactory.newInstance()
					.generate(signingCredential));
			SecurityHelper.prepareSignatureParams(signature, signingCredential,
					null, null);
			signableXMLObject.setSignature(signature);
			doMarshal(signableXMLObject);
		} catch (CertificateException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
			 throw new CertificateException("Files Not found");
		} catch (IOException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
			throw new IOException("IOException");
		} catch (SecurityException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
		} catch (MarshallingException e) {
			// TODO Auto-generated catch block
			logger.error("Exception occured while bootstrapping SAML ", e);
			throw new MarshallingException("MarshallingException");
		} catch (KeyStoreException e) {
			e.printStackTrace();
			throw new KeyStoreException("KeyStoreException");
		}
		try {
			Signer.signObject(signature);
		} catch (SignatureException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
			throw new SignatureException("SignatureException.");
		}
	}

	private NameID createNameID(String subjectName) {
		NameIDBuilder nameIdBuilder = (NameIDBuilder) builderFactory
				.getBuilder(NameID.DEFAULT_ELEMENT_NAME);
		NameID nameID = nameIdBuilder.buildObject();
		nameID.setFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:X509SubjectName");
		nameID.setValue(subjectName);
		return nameID;
	}

	protected Subject buildSubject(String subjectName) {

		Subject subject = ((SubjectBuilder) builderFactory
				.getBuilder(Subject.DEFAULT_ELEMENT_NAME)).buildObject();
		if (subjectName != null) {
			subject.setNameID(createNameID(subjectName));
		}
		SubjectConfirmationBuilder subjectConfirmationBuilder = (SubjectConfirmationBuilder) builderFactory
				.getBuilder(SubjectConfirmation.DEFAULT_ELEMENT_NAME);
		SubjectConfirmation subjectConfirmation = subjectConfirmationBuilder
				.buildObject();
		subjectConfirmation.setMethod(subjectConfirmationMethod);
		subjectConfirmation
				.setSubjectConfirmationData(buildSubjectConfigurationData(subjectName));
		/*
		 * if(subjectName!=null){
		 * subjectConfirmation.setNameID(createNameID(subjectName)); }
		 */
		subject.getSubjectConfirmations().add(subjectConfirmation);
		return subject;
	}

	private SubjectConfirmationData buildSubjectConfigurationData(String data) {
		SubjectConfirmationData confirmationData = (SubjectConfirmationData) builderFactory
				.getBuilder(SubjectConfirmationData.DEFAULT_ELEMENT_NAME)
				.buildObject(SubjectConfirmationData.DEFAULT_ELEMENT_NAME);
		confirmationData.setNotOnOrAfter(new DateTime());
		confirmationData.setRecipient("https://dweb.hap.org/ssg/dei/billPay");
		return confirmationData;
	}

	private Credential intializeCredentials() throws IOException,
			CertificateException, KeyStoreException {

		KeyStore ks = null;
		FileInputStream fis = null;

		// Get Default Instance of KeyStore
		try {
			ks = KeyStore.getInstance(KeyStore.getDefaultType());
		} catch (KeyStoreException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
			throw new KeyStoreException("KeyStoreException exception.");
		}

		// Read Ketstore as file Input Stream
		try {
			fis = new FileInputStream(this.keyStorePath);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			throw new CertificateException("Files path not found");
		}

		// Load KeyStore
		try {
			if (ks != null)
				ks.load(fis, this.keystorePassword.toCharArray());
		} catch (Exception e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
			
		}

		// Close InputFileStream
		try {
			if (null != fis) {
				fis.close();
			}
		} catch (IOException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
			
		}

		// Get Private Key Entry From Certificate
		KeyStore.PrivateKeyEntry pkEntry = null;
		PrivateKey pk = null;

		try {
			if (null != ks) {
				pkEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(
						this.privateKeyAlias, new KeyStore.PasswordProtection(
								this.keystorePassword.toCharArray()));
				if (pkEntry != null) {
					pk = pkEntry.getPrivateKey();
				}
			}
		} catch (Exception e) {
			logger.error("Exception occured while bootstrapping SAML ", e);
		}
		
		FileInputStream certificateStream = null;
		
		try {
			 certificateStream = new FileInputStream(this.certPath);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			throw new CertificateException("Certificates not found");
		}
		
		CertificateFactory certificateFactory = CertificateFactory
				.getInstance("X.509");

		Certificate[] chain = {};

		chain = certificateFactory.generateCertificates(certificateStream)
				.toArray(chain);
		certificateStream.close();

		BasicX509Credential credential = new BasicX509Credential();
		credential.setEntityCertificate((X509Certificate) chain[0]);
		credential.setPrivateKey(pk);
		return credential;
	}
}
