package com.hcentive.billing.core.saml.configuration;

import java.util.Map;

public interface SamlConfiguration {
	public SAMLEndPoint samlEndPoint();

	public Map<String, String> params();
}