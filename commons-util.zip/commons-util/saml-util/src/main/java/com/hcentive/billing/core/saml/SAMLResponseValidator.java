package com.hcentive.billing.core.saml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import org.joda.time.DateTime;
import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.StatusMessage;
import org.opensaml.security.SAMLSignatureProfileValidator;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureValidator;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SAMLResponseValidator {

	private static Logger logger = LoggerFactory
			.getLogger(SAMLResponseValidator.class);

	public void validate(final Response response, final String publicCertPath)
			throws SAMLException, FileNotFoundException, CertificateException,
			NoSuchAlgorithmException, InvalidKeySpecException, IOException,
			ValidationException {

		verifyStatus(response);

		verifyIssueTime(response);

		validateSAMLSignature(response, publicCertPath);

	}

	private void validateSAMLSignature(Response response,
			final String publicCertPath) throws FileNotFoundException,
			CertificateException, IOException, NoSuchAlgorithmException,
			InvalidKeySpecException, ValidationException {

		File certificateFile = new File(publicCertPath);

		// get the certificate from the file
		InputStream inputStream2 = new FileInputStream(certificateFile);
		CertificateFactory certificateFactory = CertificateFactory
				.getInstance("X.509");
		X509Certificate certificate = (X509Certificate) certificateFactory
				.generateCertificate(inputStream2);
		inputStream2.close();

		// pull out the public key part of the certificate into a KeySpec
		X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(certificate
				.getPublicKey().getEncoded());

		// get KeyFactory object that creates key objects, specifying RSA
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		logger.info("Security Provider: " + keyFactory.getProvider().toString());
		// generate public key to validate signatures
		PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);

		// we have the public key
		logger.info("Public Key created");
		// create credentials
		BasicX509Credential publicCredential = new BasicX509Credential();

		// add public key value
		publicCredential.setPublicKey(publicKey);

		// create SignatureValidator
		SignatureValidator signatureValidator = new SignatureValidator(
				publicCredential);

		// get the signature to validate from the response object
		Signature respSignature = response.getSignature();
		SAMLSignatureProfileValidator profileValidator = new SAMLSignatureProfileValidator();

		if (response.getAssertions() != null
				&& response.getAssertions().size() > 0) {
			for (Assertion assertion : response.getAssertions()) {
				Signature assertionSignature = assertion.getSignature();
				if (assertionSignature != null) {
					logger.info("Validating assertion Signature");
					profileValidator.validate(assertionSignature);
					signatureValidator.validate(assertionSignature);
					logger.info("Assertion Signature is valid.");
				}
			}
		}

		// Validate response signature
		if (respSignature != null) {
			logger.info("Validating Response Signature");
			profileValidator.validate(respSignature);
			signatureValidator.validate(respSignature);
			logger.info("Response Signature is valid.");
		}

		// no validation exception was thrown

	}

	// Verify issue time
	private void verifyIssueTime(Response response) throws SAMLException {
		DateTime time = response.getIssueInstant();
		if (!SAMLUtil.isDateTimeSkewValid(SAMLConfigConstants.RESPONSE_SKEW,
				time)) {
			throw new SAMLException(
					"Response issue time is either too old or with date in the future, skew "
							+ SAMLConfigConstants.RESPONSE_SKEW + ", time "
							+ time);
		}
	}

	// Verify status
	private void verifyStatus(Response response) throws SAMLException {
		String statusCode = response.getStatus().getStatusCode().getValue();
		if (!StatusCode.SUCCESS_URI.equals(statusCode)) {
			StatusMessage statusMessage = response.getStatus()
					.getStatusMessage();
			String statusMessageText = null;
			if (statusMessage != null) {
				statusMessageText = statusMessage.getMessage();
			}
			throw new SAMLException("Response has invalid status code "
					+ statusCode + ", status message is " + statusMessageText);
		}
	}

}
