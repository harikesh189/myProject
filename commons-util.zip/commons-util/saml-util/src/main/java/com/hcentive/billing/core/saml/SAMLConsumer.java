package com.hcentive.billing.core.saml;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.namespace.QName;

import org.opensaml.DefaultBootstrap;
import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.AuthnStatement;
import org.opensaml.saml2.core.Response;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.BasicParserPool;
import org.opensaml.xml.parse.XMLParserException;
import org.opensaml.xml.util.Base64;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

@Component
public class SAMLConsumer {
	private static Logger logger = LoggerFactory.getLogger(SAMLConsumer.class);

	@Autowired
	private SAMLResponseValidator samlResponseValidator;
	
	public Map<String, String> consumeResponse(String samlResponse,
			final String publicCertPath) throws ConfigurationException,
			XMLParserException, UnmarshallingException, CertificateException,
			NoSuchAlgorithmException, InvalidKeySpecException, IOException,
			SAXException, ValidationException, SAMLException {
		Map<String, String> attributeMap = null;

		logger.info("Consuming Response");
		samlResponse = decodeSAMLResponse(samlResponse);
		logger.info("SAML Response:" + samlResponse);

		// initialize the opensaml library
		DefaultBootstrap.bootstrap();

		BasicParserPool parserPoolManager = createPoolManager();

		Response response = createSAMLResponse(parserPoolManager, samlResponse);

		samlResponseValidator.validate(response, publicCertPath);

		attributeMap = getSAMLAttributes(response);
		
		for (Entry<String, String> attribute : attributeMap.entrySet()) {
			logger.info(attribute.getKey(), "{} : {}", attribute.getValue());
		}
		return attributeMap;
	}

	private String decodeSAMLResponse(String samlResponse)
			throws UnsupportedEncodingException {
		byte[] data = Base64.decode(samlResponse);
		samlResponse = new String(data, "UTF-8");
		return samlResponse;
	}

	private String getSessionIdentifier(Response response){
		Assertion assertion = response.getAssertions().get(0);
		List<AuthnStatement> authnStatements = assertion.getAuthnStatements();
		for (AuthnStatement authnStatement : authnStatements) {
			final String sessionIndex = authnStatement.getSessionIndex();
			logger.debug("Session Identifier : {}",sessionIndex);
			return sessionIndex;
		}
		return null;
	}
	
	
	private Map<String, String> getSAMLAttributes(Response response) {
		Assertion assertion = response.getAssertions().get(0);
		logger.debug("Assertion Id : {}", assertion.getID());

		// loop through the nodes to get what we want
		List<AttributeStatement> attributeStatements = assertion
				.getAttributeStatements();
		Map<String, String> attributeMap = new HashMap<String, String>();
		for (int i = 0; i < attributeStatements.size(); i++) {
			List<Attribute> attributes = attributeStatements.get(i)
					.getAttributes();
			for (int x = 0; x < attributes.size(); x++) {
				String strAttributeName = attributes.get(x).getDOM()
						.getAttribute("Name");
				logger.debug("Attribute Name: {}",strAttributeName);
				List<XMLObject> attributeValues = attributes.get(x)
						.getAttributeValues();
				logger.debug("Attribute Values: {}",attributeValues);
				for (int y = 0; y < attributeValues.size(); y++) {
					String strAttributeValue = attributeValues.get(y).getDOM()
							.getTextContent();
					logger.debug("Attribute Value : {}",strAttributeValue);
					attributeMap.put(strAttributeName, strAttributeValue);
				}
			}
		}
		final String subjectId = assertion.getSubject().getNameID()
				.getValue();
		logger.debug("Subject ID: {}",subjectId);
		attributeMap.put("subjectId", subjectId);
		attributeMap.put("idpSessionIdentifier", getSessionIdentifier(response));
		return attributeMap;
	}

	private BasicParserPool createPoolManager() throws SAXException {
		BasicParserPool parserPoolManager = new BasicParserPool();
		parserPoolManager.setNamespaceAware(true);
		parserPoolManager.setIgnoreElementContentWhitespace(true);
		return parserPoolManager;
	}

	private Response createSAMLResponse(BasicParserPool parserPoolManager,
			String samlResponse) throws FileNotFoundException,
			XMLParserException, UnmarshallingException {
		logger.debug("SAML RESPONSE Creation starts here");
		InputStream inputStream = new ByteArrayInputStream(
				samlResponse.getBytes());
		Document document = parserPoolManager.parse(inputStream);
		Element metadataRoot = document.getDocumentElement();

		QName qName = new QName(metadataRoot.getNamespaceURI(),
				metadataRoot.getLocalName(), metadataRoot.getPrefix());

		// get an unmarshaller
		Unmarshaller unmarshaller = Configuration.getUnmarshallerFactory()
				.getUnmarshaller(qName);

		// unmarshall using the document root element
		Response response = (Response) unmarshaller.unmarshall(metadataRoot);
		logger.debug("SAML RESPONSE created");
		return response;
	}

}
