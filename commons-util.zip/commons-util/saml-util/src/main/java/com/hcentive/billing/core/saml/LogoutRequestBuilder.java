package com.hcentive.billing.core.saml;

import org.joda.time.DateTime;
import org.opensaml.saml2.core.LogoutRequest;
import org.opensaml.saml2.core.SessionIndex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.util.RandomGenerator;

@Component
public class LogoutRequestBuilder extends SAMLObjectBuilder<LogoutRequest> {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(LogoutRequestBuilder.class);
	
	private String idpUserIdentity;
	
	private String sessionIndex;
	
	public LogoutRequestBuilder forIdpUserIdentity(final String idpUserIdentity){
		this.idpUserIdentity = idpUserIdentity;
		return this;
	}

	public LogoutRequestBuilder forSessionIndex(final String sessionIndex){
		this.sessionIndex = sessionIndex;
		return this;
	}
	
	@Override
	protected LogoutRequest doBuild() {
		LOGGER.debug("SAML Logout Request building starts here");
		final LogoutRequest request = ((org.opensaml.saml2.core.impl.LogoutRequestBuilder) builderFactory
				.getBuilder(LogoutRequest.DEFAULT_ELEMENT_NAME)).buildObject();
		request.setID(RandomGenerator.randomString());
		request.setIssuer(buildIssuer(issuer(),
				SAMLConfigConstants.AUTHN_ISSUER_FORMAT));
		request.setNameID(buildNameId(this.idpUserIdentity));
		request.setReason("urn:oasis:names:tc:SAML:2.0:logout:user");
		request.setIssueInstant(new DateTime());
		request.getSessionIndexes().add(buildSessionIndex(sessionIndex));
		
		signXMLObject(request);
		LOGGER.debug("SAML Logout Request build");
		return request;
	}
	
	private SessionIndex buildSessionIndex(final String sessionId){
		LOGGER.debug("Building Session Index for session Id : {}",sessionId);
		final SessionIndex sessionIndex = ((org.opensaml.saml2.core.impl.SessionIndexBuilder) builderFactory
				.getBuilder(SessionIndex.DEFAULT_ELEMENT_NAME)).buildObject();
		
		sessionIndex.setSessionIndex(sessionId);
		LOGGER.debug("Returning from session Index");
		return sessionIndex;
	}

}
