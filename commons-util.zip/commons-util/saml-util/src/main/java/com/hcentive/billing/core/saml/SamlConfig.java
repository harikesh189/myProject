package com.hcentive.billing.core.saml;

public interface SamlConfig {

	public Boolean getForceAuthn();

	public Boolean isPassive();

	public int responseSkew();

}
