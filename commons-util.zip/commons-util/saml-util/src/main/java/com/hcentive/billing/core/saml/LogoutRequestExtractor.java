package com.hcentive.billing.core.saml;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import javax.xml.namespace.QName;

import org.opensaml.saml2.core.LogoutRequest;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.parse.BasicParserPool;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class LogoutRequestExtractor extends AbstractLogoutResponseParser<LogoutRequest> {

	@Override
	public LogoutRequest parseLogoutResponse(String logoutResponse) {
		try{
			final String decodedResponse = decodedLogoutRsponse(logoutResponse);
			BasicParserPool parserPoolManager = createPoolManager();
			InputStream inputStream = new ByteArrayInputStream(
					decodedResponse.getBytes());
			Document document = parserPoolManager.parse(inputStream);
			Element metadataRoot = document.getDocumentElement();

			QName qName = new QName(metadataRoot.getNamespaceURI(),
					"LogoutRequest", metadataRoot.getPrefix());

			// get an unmarshaller
			Unmarshaller unmarshaller = Configuration.getUnmarshallerFactory()
					.getUnmarshaller(qName);

			// unmarshall using the document root element
			LogoutRequest response = (LogoutRequest) unmarshaller.unmarshall(metadataRoot);
			return response;
		}catch(Exception e){
			return null;
		}
	}

}
