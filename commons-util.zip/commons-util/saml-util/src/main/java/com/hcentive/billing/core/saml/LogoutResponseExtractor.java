package com.hcentive.billing.core.saml;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import javax.xml.namespace.QName;

import org.opensaml.saml2.core.LogoutResponse;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.parse.BasicParserPool;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class LogoutResponseExtractor extends AbstractLogoutResponseParser<LogoutResponse> {

	@Override
	public LogoutResponse parseLogoutResponse(String logoutResponse) {
		try{
			final String decodedResponse = decodedLogoutRsponse(logoutResponse);
			BasicParserPool parserPoolManager = createPoolManager();
			InputStream inputStream = new ByteArrayInputStream(
					decodedResponse.getBytes());
			Document document = parserPoolManager.parse(inputStream);
			Element metadataRoot = document.getDocumentElement();

			QName qName = new QName(metadataRoot.getNamespaceURI(),
					"LogoutResponse", metadataRoot.getPrefix());

			// get an unmarshaller
			Unmarshaller unmarshaller = Configuration.getUnmarshallerFactory()
					.getUnmarshaller(qName);

			// unmarshall using the document root element
			LogoutResponse response = (LogoutResponse) unmarshaller.unmarshall(metadataRoot);
			return response;
		}catch(Exception e){
			return null;
		}
	}
	

}
