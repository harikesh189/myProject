package com.hcentive.billing.core.saml;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class LogoutResponseParserFactory<O> {
	
	private final Set<LogoutResponseParser> logoutResponseParsers = new HashSet<LogoutResponseParser>();
	
	public void register(List<LogoutResponseParser> parsers) {
		logoutResponseParsers.addAll(parsers);
	}
	
	public void addParser(LogoutResponseParser parser){
		logoutResponseParsers.add(parser);
	}
	
	public O parseLogoutResponse(final String samlResponse){
		for (LogoutResponseParser logoutResponseParser : logoutResponseParsers) {
			O logoutResponse = (O) logoutResponseParser.parseLogoutResponse(samlResponse);
			if(null != logoutResponse){
				return logoutResponse;
			}
		}
		return null;
	}
	
	@PostConstruct
	public void init(){
		logoutResponseParsers.add(new LogoutResponseExtractor());
		logoutResponseParsers.add(new LogoutRequestExtractor());
	}

}
