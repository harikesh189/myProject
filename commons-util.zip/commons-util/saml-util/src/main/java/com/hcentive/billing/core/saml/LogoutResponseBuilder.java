package com.hcentive.billing.core.saml;

import java.util.List;

import org.joda.time.DateTime;
import org.opensaml.common.SAMLVersion;
import org.opensaml.saml2.core.LogoutRequest;
import org.opensaml.saml2.core.LogoutResponse;
import org.opensaml.saml2.core.SessionIndex;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.util.RandomGenerator;

@Component
public class LogoutResponseBuilder extends SAMLObjectBuilder<LogoutResponse>{
	
	private String consent;
	
	private String inResponseTo;
	
	public LogoutResponseBuilder inResponseTo(String inResponseTo){
		this.inResponseTo = inResponseTo;
		return this;
	}
	
	public LogoutResponseBuilder forConsent(final String consent){
		this.consent = consent;
		return this;
	}
	
	

	@Override
	protected LogoutResponse doBuild() {
		final LogoutResponse response = ((org.opensaml.saml2.core.impl.LogoutResponseBuilder) builderFactory
				.getBuilder(LogoutResponse.DEFAULT_ELEMENT_NAME)).buildObject();
		response.setID(RandomGenerator.randomString());
		response.setIssuer(buildIssuer(issuer(),
				SAMLConfigConstants.ISSUER_FORMAT));
		response.setIssueInstant(new DateTime());
		response.setVersion(SAMLVersion.VERSION_20);
		response.setConsent(this.consent);
		response.setDestination(destinationUrl());
		response.setInResponseTo(this.inResponseTo);
		response.setIssueInstant(new DateTime());
		signXMLObject(response);
		return response;
	}

}
