package com.hcentive.billing.core.saml;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.zip.DeflaterOutputStream;

import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.impl.IssuerBuilder;
import org.opensaml.saml2.core.impl.NameIDBuilder;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.XMLObjectBuilderFactory;
import org.opensaml.xml.io.MarshallerFactory;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.security.SecurityHelper;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.security.x509.X509KeyInfoGeneratorFactory;
import org.opensaml.xml.signature.SignableXMLObject;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureConstants;
import org.opensaml.xml.signature.SignatureException;
import org.opensaml.xml.signature.Signer;
import org.opensaml.xml.util.Base64;
import org.opensaml.xml.util.XMLHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

@SuppressWarnings("rawtypes")
public abstract class SAMLObjectBuilder<X extends XMLObject> {

	private static final Logger logger = LoggerFactory
			.getLogger(SAMLObjectBuilder.class);

	protected static final XMLObjectBuilderFactory builderFactory = Configuration
			.getBuilderFactory();
	private static final MarshallerFactory marhsallerFactory = Configuration
			.getMarshallerFactory();

	private String keyStorePath;
	private String keystorePassword;
	private String privateKeyAlias;
	private String certPath;
	private String issuer;
	private String destinationUrl;

	static {
		try {
			logger.debug("Bootstrapping SAML");
			DefaultBootstrap.bootstrap();
		} catch (ConfigurationException e) {
			logger.error("Exception occured while bootstrapping SAML ", e);

		}
	}

	public final String build() {
		return marshalAndEncode(doBuild());
	}
	
	public final String buildForRedirectBinding(){
		final String samlXML = marshal(doBuild());
		 ByteArrayOutputStream os = new ByteArrayOutputStream();
         DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(os);
         try {
			deflaterOutputStream.write( samlXML.getBytes( "UTF-8" ) );
			 deflaterOutputStream.close();
	         os.close();
	         String base64 = Base64.encodeBytes(os.toByteArray(), Base64.NO_OPTIONS);
	         return URLEncoder.encode( base64, "UTF-8" );
		} catch (UnsupportedEncodingException e) {
			logger.error("UnsupportedEncodingException occurred :",e);
		} catch (IOException e) {
			logger.error("IOException occurred :",e);
		} 
        return null;
	}

	protected abstract X doBuild();
	
	public SAMLObjectBuilder toDestinationUrl(final String destinationUrl) {
		this.destinationUrl = destinationUrl;
		return this;
	}

	
	public NameID buildNameId(final String idpUserIdentity) {
		NameIDBuilder nameIDBuilder = (NameIDBuilder) builderFactory
				.getBuilder(NameID.DEFAULT_ELEMENT_NAME);
		NameID nameID = nameIDBuilder.buildObject();
		nameID.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:transient");
		/*nameID.setNameQualifier("");
		nameID.setSPNameQualifier("");
		nameID.setSPProvidedID("");*/
		nameID.setValue(idpUserIdentity);
		return nameID;
	}

	public SAMLObjectBuilder forIssuer(final String issuerValue) {
		this.issuer = issuerValue;
		return this;
	}

	protected String destinationUrl(){
		return this.destinationUrl;
	}
	
	protected String issuer() {
		return this.issuer;
	}

	public SAMLObjectBuilder withKeyStorePath(final String keyStorePath) {
		this.keyStorePath = keyStorePath;
		return this;
	}

	public SAMLObjectBuilder withKeyStorePassword(final String keystorePassword) {
		this.keystorePassword = keystorePassword;
		return this;
	}

	public SAMLObjectBuilder withCertPath(final String certPath) {
		this.certPath = certPath;
		return this;
	}

	public SAMLObjectBuilder withPrivateKeyAlias(final String privateKeyAlias) {
		this.privateKeyAlias = privateKeyAlias;
		return this;
	}

	protected Issuer buildIssuer(final String issuerValue,
			final String issuerFormat) {
		logger.debug("Building Issuer");
		IssuerBuilder issuerBuilder = (IssuerBuilder) builderFactory
				.getBuilder(Issuer.DEFAULT_ELEMENT_NAME);
		logger.debug("Getting Issuer from Issuer Builder");
		Issuer issuer = issuerBuilder.buildObject();
		issuer.setFormat(issuerFormat);
		issuer.setValue(issuerValue);
		logger.debug("Returning from Issuer");
		return issuer;
	}

	private String marshal(XMLObject xmlObject) {
		try {
			return XMLHelper.nodeToString(doMarshal(xmlObject));
		} catch (MarshallingException e) {
			throw new RuntimeException(e);
		}
	}

	private Element doMarshal(XMLObject xmlObject) throws MarshallingException {
		return marhsallerFactory.getMarshaller(xmlObject).marshall(xmlObject);
	}

	private String marshalAndEncode(XMLObject xmlObject) {
		logger.debug("In Marshal and Encode");
		final String xmlString = marshal(xmlObject);
		logger.debug("XML Object Marshalled");
		return Base64.encodeBytes(xmlString.getBytes(), Base64.NO_OPTIONS);
	}

	protected void signXMLObject(SignableXMLObject signableXMLObject) {
		logger.debug("Signing SAML Object");
		Signature signature = (Signature) builderFactory.getBuilder(
				Signature.DEFAULT_ELEMENT_NAME).buildObject(
				Signature.DEFAULT_ELEMENT_NAME);
		X509KeyInfoGeneratorFactory keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
		keyInfoGeneratorFactory.setEmitEntityCertificate(true);
		signature
				.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA1);
		signature
				.setCanonicalizationAlgorithm(SignatureConstants.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);
		Credential signingCredential;
		try {
			logger.debug("Initializing Signing Credentials");
			signingCredential = intializeCredentials();
			signature.setSigningCredential(signingCredential);
			signature.setKeyInfo(keyInfoGeneratorFactory.newInstance()
					.generate(signingCredential));
			SecurityHelper.prepareSignatureParams(signature, signingCredential,
					null, null);
			signableXMLObject.setSignature(signature);
			logger.debug("Marsharlling Singed Object");
			doMarshal(signableXMLObject);
		} catch (CertificateException e) {
			logger.error("CertificateException Occurred ", e);

		} catch (IOException e) {
			logger.error("IOException Occurred ", e);

		} catch (SecurityException e) {
			logger.error("SecurityException Occurred ", e);

		} catch (MarshallingException e) {
			logger.error("MarshallingException Occurred ", e);

		}
		try {
			Signer.signObject(signature);
		} catch (SignatureException e) {
			logger.error("SignatureException Occurred ", e);

		}
	}

	private Credential intializeCredentials() throws IOException,
			CertificateException {
		logger.debug("Initializing Credentials");
		KeyStore ks = null;
		FileInputStream fis = null;

		// Get Default Instance of KeyStore
		try {
			logger.debug("Getting Keystore Instance");
			ks = KeyStore.getInstance(KeyStore.getDefaultType());
		} catch (KeyStoreException e) {
			logger.error("KeyStoreException Occurred ", e);

		}

		// Read Ketstore as file Input Stream
		try {
			fis = new FileInputStream(this.keyStorePath);
		} catch (FileNotFoundException e) {
			logger.error("Key store not found  ", e);

		}

		// Load KeyStore
		try {
			if (null != ks) {
				ks.load(fis, this.keystorePassword.toCharArray());
			}
		} catch (Exception e) {
			logger.error("Exception Occurred ", e);

		}

		// Close InputFileStream
		try {
			if (null != fis) {
				fis.close();
			}
		} catch (IOException e) {
			logger.error("IOException Occurred ", e);
		}

		// Get Private Key Entry From Certificate
		KeyStore.PrivateKeyEntry pkEntry = null;

		try {
			if (null != ks) {
				pkEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(
						this.privateKeyAlias, new KeyStore.PasswordProtection(
								this.keystorePassword.toCharArray()));

			}
		} catch (Exception e) {
			logger.error("Exception Occurred ", e);

		}
		logger.debug("Getting Private Key");
		if (null != pkEntry) {
			PrivateKey pk = pkEntry.getPrivateKey();
			logger.debug("Reading Cert");
			FileInputStream certificateStream = new FileInputStream(
					this.certPath);
			logger.debug("Getting Instance of X509 CERT");
			CertificateFactory certificateFactory = CertificateFactory
					.getInstance("X.509");

			Certificate[] chain = {};
			logger.debug("Generating CERTS");
			chain = certificateFactory.generateCertificates(certificateStream)
					.toArray(chain);
			certificateStream.close();

			BasicX509Credential credential = new BasicX509Credential();
			credential.setEntityCertificate((X509Certificate) chain[0]);
			credential.setPrivateKey(pk);
			logger.debug("Returning from intializeCredentials");
			return credential;
		}
		return null;
	}

}
