package com.hcentive.billing.core.saml;

import org.joda.time.DateTime;

public final class SAMLUtil {

	/**
	 * Verifies that the current time is within skewInSec interval from the time
	 * value.
	 * 
	 * @param skewInSec
	 *            skew interval in seconds
	 * @param time
	 *            time the current time must fit into with the given skew
	 * @return true if time matches, false otherwise
	 */
	public static boolean isDateTimeSkewValid(int skewInSec, DateTime time) {
		return isDateTimeSkewValid(skewInSec, 0, time);
	}

	/**
	 * Verifies that the current time fits into interval defined by time minus
	 * backwardInterval minus skew and time plus forward interval plus skew.
	 * 
	 * 
	 * @param skewInSec
	 *            skew interval in seconds
	 * @param forwardInterval
	 *            forward interval in sec
	 * @param time
	 *            time the current time must fit into with the given skew
	 * @return true if time matches, false otherwise
	 */
	public static boolean isDateTimeSkewValid(int skewInSec,
			int forwardInterval, DateTime time) {
		long reference = System.currentTimeMillis();
		return time.isBefore(reference + (skewInSec * 1000))
				&& time.isAfter(reference
						- ((skewInSec + forwardInterval) * 1000));
	}

}
