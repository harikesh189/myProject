package com.hcentive.billing.core.saml;

import org.joda.time.DateTime;
import org.opensaml.saml2.core.AuthnRequest;
import org.opensaml.saml2.core.impl.AuthnRequestBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.util.RandomGenerator;

@Component
public class AuthRequestBuilder extends SAMLObjectBuilder<AuthnRequest> {

	private static final Logger logger = LoggerFactory
			.getLogger(AuthRequestBuilder.class);

	private String assertionConsumerUrl;

	@Autowired
	private SamlConfig defaultSamlConfig;

	public AuthRequestBuilder forAssertionConsumerUrl(
			final String assertionConsumerUrl) {
		this.assertionConsumerUrl = assertionConsumerUrl;
		return this;
	}

	protected AuthnRequest doBuild() {
		logger.debug("SAML Request building starts here");
		AuthnRequest request = ((AuthnRequestBuilder) builderFactory
				.getBuilder(AuthnRequest.DEFAULT_ELEMENT_NAME)).buildObject();
		request.setID(RandomGenerator.randomString());
		request.setIssuer(buildIssuer(issuer(),
				SAMLConfigConstants.AUTHN_ISSUER_FORMAT));
		request.setAssertionConsumerServiceURL(assertionConsumerUrl);
		request.setDestination(destinationUrl());
		request.setForceAuthn(defaultSamlConfig.getForceAuthn());
		request.setIsPassive(defaultSamlConfig.isPassive());
		request.setProtocolBinding(SAMLConfigConstants.PROTOCOL_BINDING);
		request.setVersion(SAMLConfigConstants.VERSION);
		request.setIssueInstant(new DateTime());
		signXMLObject(request);
		logger.debug(" SAML Request :::: {}", request);
		return request;

	}
}
