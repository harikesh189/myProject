package com.hcentive.billing.core.saml;

import java.io.UnsupportedEncodingException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

import org.apache.commons.codec.binary.Base64;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.BasicParserPool;
import org.opensaml.xml.parse.XMLParserException;
import org.xml.sax.SAXException;

public abstract class AbstractLogoutResponseParser<O> implements LogoutResponseParser<O> {
	
	public String decodedLogoutRsponse(String samlResponse) throws UnsupportedEncodingException, DataFormatException, SAXException, XMLParserException, UnmarshallingException {
		Base64 base64Decoder = new Base64();
		byte[] xmlBytes = samlResponse.getBytes("UTF-8");
		byte[] base64DecodedByteArray = base64Decoder.decode(xmlBytes);

		// Inflate (uncompress) the AuthnRequest data
		// First attempt to unzip the byte array according to DEFLATE (rfc 1951)

		Inflater inflater = new Inflater(true);
		inflater.setInput(base64DecodedByteArray);
		// since we are decompressing, it's impossible to know how much space we
		// might need; hopefully this number is suitably big
		byte[] xmlMessageBytes = new byte[5000];
		int resultLength = inflater.inflate(xmlMessageBytes);

		if (!inflater.finished()) {
		    throw new RuntimeException("didn't allocate enough space to hold "
		            + "decompressed data");
		}

		inflater.end();

		String decodedResponse = new String(xmlMessageBytes, 0, resultLength,
		        "UTF-8");
		
		return decodedResponse;
	}

	public BasicParserPool createPoolManager() throws SAXException {
		BasicParserPool parserPoolManager = new BasicParserPool();
		parserPoolManager.setNamespaceAware(true);
		parserPoolManager.setIgnoreElementContentWhitespace(true);
		return parserPoolManager;
	}
}
