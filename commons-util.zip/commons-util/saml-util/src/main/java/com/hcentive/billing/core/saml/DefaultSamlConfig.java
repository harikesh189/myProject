package com.hcentive.billing.core.saml;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DefaultSamlConfig implements SamlConfig {

	@Value(value = "${security.saml.force.authn:true}")
	private Boolean forceAuthn;

	@Value(value = "${security.saml.isPassive:false}")
	private Boolean isPassive;

	@Value(value = "${security.saml.responseSkew:60}")
	private int responseSkew;

	@Override
	public Boolean getForceAuthn() {
		return forceAuthn;
	}

	@Override
	public Boolean isPassive() {
		return isPassive;
	}

	public int responseSkew() {
		return responseSkew;
	}

}
