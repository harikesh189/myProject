package com.hcentive.billing.core.saml;

public interface LogoutResponseParser<O> {
	
	public O parseLogoutResponse(String logoutResponse);
	
}
