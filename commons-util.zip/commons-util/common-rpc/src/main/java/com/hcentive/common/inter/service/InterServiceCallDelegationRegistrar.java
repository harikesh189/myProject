/**
 *
 */
package com.hcentive.common.inter.service;

import java.lang.reflect.Proxy;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.util.MultiValueMap;

import com.hcentive.common.inter.service.annotation.EnableInterServiceCall;
import com.hcentive.common.inter.service.annotation.InterService;
import com.hcentive.common.inter.service.invocation.handler.InterServiceInvocationHandler;

/**
 * Handler for {@link EnableInterServiceCall}. <br>
 * <br>
 * The class implements {@link ImportBeanDefinitionRegistrar} ,
 * {@link BeanFactoryAware}, {@link BeanClassLoaderAware}
 * @author sambhav.jain
 */
public class InterServiceCallDelegationRegistrar implements ImportBeanDefinitionRegistrar, BeanFactoryAware, BeanClassLoaderAware {

	/**
	 * {@link ClassPathScanningCandidateComponentProvider} to scan inter service
	 * call related annotations.
	 */
	private static final ClassPathScanningCandidateComponentProvider annotationScanner;

	/**
	 * Required attribute name for {@link EnableInterServiceCall} annotation.
	 */
	private static final String BASE_PCKG_TO_SCAN = "basePackagesToScan";

	/**
	 * Slf4j logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(InterServiceCallDelegationRegistrar.class);

	static {
		annotationScanner = new ClassPathScanningCandidateComponentProvider(false) {
			@Override
			protected boolean isCandidateComponent(final AnnotatedBeanDefinition beanDefinition) {
				return beanDefinition.getMetadata().hasAnnotation(InterService.class.getName());
			}
		};
		annotationScanner.addIncludeFilter(new AnnotationTypeFilter(InterService.class, false, true));
	}

	/**
	 * Used to register beans in Spring's context.
	 */
	private DefaultListableBeanFactory beanFactory;

	/**
	 * {@link ClassLoader} used by Spring. <br>
	 * <br>
	 * This is made available through
	 * {@link BeanClassLoaderAware#setBeanClassLoader(ClassLoader)} which is
	 * overriden in this class.
	 */
	private ClassLoader classLoader;

	@Override
	public void registerBeanDefinitions(final AnnotationMetadata importingClassMetadata, final BeanDefinitionRegistry registry) {
		logger.trace("Will process EnableInterServiceCall configuration now !!!!");

		// Get packages to scan
		final Set<String> packagesToScan = this.getPackagesToScan(importingClassMetadata);
		if (null != packagesToScan) {
			logger.trace("{} Packages that will scanned-" + packagesToScan.size());

			// Get java interfaces defined in the packages.
			final Set<BeanDefinition> interfaces = new HashSet<BeanDefinition>();

			for (final String pckg : packagesToScan) {
				interfaces.addAll(annotationScanner.findCandidateComponents(pckg));
			}
			logger.trace("BeanDefinition Identified are {}", interfaces);

			// Register beans
			for (final BeanDefinition beanDefinition : interfaces) {
				String beanName = beanDefinition.getBeanClassName();
				//System.out.println("Registering bean: "+beanName);
				if (!this.beanFactory.containsBean(beanName)) {
					Object bean = this.getProxyObject(beanDefinition);
					this.beanFactory.registerSingleton(beanName, bean);
					this.beanFactory.initializeBean(bean, beanName);
				}
			}
		} else {
			logger.warn("No base packages found for inter service call scanning.");
		}
	}

	@Override
	public void setBeanClassLoader(final ClassLoader classLoader) {
		this.classLoader = classLoader;
	}

	@Override
	public void setBeanFactory(final BeanFactory beanFactory) throws BeansException {
		this.beanFactory = (DefaultListableBeanFactory) beanFactory;
	}

	/**
	 * Get list of packages that are to be scanned for inter service call
	 * @param importingClassMetadata
	 * @return
	 */
	private Set<String> getPackagesToScan(final AnnotationMetadata importingClassMetadata) {
		final MultiValueMap<String, Object> allAnnotationAttributes = importingClassMetadata.getAllAnnotationAttributes(EnableInterServiceCall.class.getName());

		final List<Object> packages = allAnnotationAttributes.get(BASE_PCKG_TO_SCAN);

		final Set<String> pckgs = new HashSet<>();

		for (final Object pck : packages) {
			final String[] object = (String[]) pck;
			for (final String packge : object) {
				pckgs.add(packge);
			}
		}

		return pckgs;
	}

	/**
	 * Get the runtime proxy instance that will be implementation of the inter
	 * service interface. The proxy will use promise api to asynchronously send
	 * and receive message from the remote service.
	 * @param beanDefinition {@link BeanDefinition} instance.
	 * @param serviceClient
	 * @return Object created by {@link Proxy}
	 */
	private Object getProxyObject(final BeanDefinition beanDefinition) {
		try {
			return Proxy.newProxyInstance(this.classLoader, new Class[] { Class.forName(beanDefinition.getBeanClassName()) },
			        new InterServiceInvocationHandler());
		} catch (final ClassNotFoundException e) {
			logger.error("Error While creating proxy instance for inter service", e);
			return null;
		}

	}

}
