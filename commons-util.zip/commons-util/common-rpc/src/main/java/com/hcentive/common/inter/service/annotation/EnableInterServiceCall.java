/**
 * 
 */
package com.hcentive.common.inter.service.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Import;

import com.hcentive.common.inter.service.InterServiceCallDelegationRegistrar;

/**
 * 
 * Class level marker annotation to enable inter service call using dynamic
 * runtime proxies.
 * 
 * 
 * @author sambhav.jain
 *
 */
@Inherited
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Import(InterServiceCallDelegationRegistrar.class)
public @interface EnableInterServiceCall {

	public String[] basePackagesToScan();

}
