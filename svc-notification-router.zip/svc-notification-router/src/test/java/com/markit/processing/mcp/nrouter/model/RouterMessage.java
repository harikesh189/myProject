package com.markit.processing.mcp.nrouter.model;

import org.springframework.messaging.Message;

public class RouterMessage
{
    private String queue;
    private long at;
    private Message<String> message;

    private RouterMessage( Builder builder )
    {
        queue = builder.queue;
        at = builder.at;
        message = builder.message;
    }

    public String getQueue()
    {
        return queue;
    }

    public long getAt()
    {
        return at;
    }

    public Message<String> getMessage()
    {
        return message;
    }

    public static final Builder builder()
    {
        return new Builder();
    }

    public static final class Builder
    {
        private String queue;
        private long at;
        private Message<String> message;

        public Builder()
        {
        }

        public Builder withQueue( String val )
        {
            queue = val;
            return this;
        }

        public Builder withAt( long val )
        {
            at = val;
            return this;
        }

        public Builder withMessage( Message val )
        {
            message = val;
            return this;
        }

        public RouterMessage build()
        {
            return new RouterMessage( this );
        }
    }


}
