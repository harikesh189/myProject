package com.markit.processing.mcp.nrouter.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Created by sukhmeet.sethi on 12/12/2016.
 */
@Component
public class MessageLoader {

    @Autowired
    ObjectMapper mapper;

    public Map<String, JsonNode> loadJsonFiles(String filePath) {

        String path = getClass().getResource(filePath).getPath();
        Map<String, JsonNode> messageMap = new HashMap<>();
        File file = new File(path);
        if (file.isDirectory()) {
            Stream.of(file.listFiles()).forEach(nestedFile -> {
                loadJsonToMap(messageMap, nestedFile);
            });
        } else {
            loadJsonToMap(messageMap, file);
        }

        return messageMap;
    }

    private void loadJsonToMap(Map<String, JsonNode> messageMap, File nestedFile) {
        try {
            JsonNode jsonNode = mapper.readTree(nestedFile);
            String name = nestedFile.getName();
            messageMap.put(name.substring(0, name.length() - 5), jsonNode); //remove .json from the key
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
