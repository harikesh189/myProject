package com.markit.processing.mcp.nrouter.service;

import com.markit.processing.mcp.nrouter.model.RouterMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestComponent;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;

import java.util.Collection;

@TestComponent
public class TestMessageListener
{
    @Autowired
    private Collection<RouterMessage> messages;

    @Value( "${outbound.route}" )
    private String outboundRoute;

    private void receive( String queue, Message<String> message )
    {
        messages.add( RouterMessage.builder()
                                   .withAt( System.currentTimeMillis() )
                                   .withMessage( message )
                                   .withQueue( queue )
                                   .build() );
    }


    @JmsListener( destination = "${outbound.route}.>" )
    public void outbound( Message message )
    {
        String queue = message.getHeaders()
                              .get( "jms_destination" )
                              .toString();

        receive( queue.substring( queue.indexOf( outboundRoute ) ), message );
    }
}
