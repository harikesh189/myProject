package com.markit.processing.mcp.nrouter.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.HttpStatus.OK;

/**
 * Created by sukhmeet.sethi on 12/13/2016.
 */
@RestController
public class DummyMailingService {

    private String incomingMessage;

    @RequestMapping(path = "/dummy/mail" , consumes = "application/json")
    public ResponseEntity<Void> sendMail(@RequestBody String payload){
        setIncomingMessage(payload);
        return new ResponseEntity<>(OK);
    }

    @RequestMapping(path = "/dummy/store" , consumes = "application/json")
    public ResponseEntity<Void> store(@RequestBody String payload){
        // STORING IN NOTIFICATION DB
        return new ResponseEntity<>(OK);
    }

    public String getIncomingMessage() {
        return incomingMessage;
    }

    public void setIncomingMessage(String incomingMessage) {
        this.incomingMessage = incomingMessage;
    }
}
