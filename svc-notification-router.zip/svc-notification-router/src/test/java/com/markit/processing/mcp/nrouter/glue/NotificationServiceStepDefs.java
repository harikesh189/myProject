package com.markit.processing.mcp.nrouter.glue;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.processing.mcp.nrouter.bdd.TestConfig;
import com.markit.processing.mcp.nrouter.model.RouterMessage;
import com.markit.processing.mcp.nrouter.service.DummyMailingService;
import com.markit.processing.mcp.nrouter.service.MessageLoader;
import com.markit.processing.mcp.nrouter.swagger.Swagger2SpringBoot;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.DEFINED_PORT;
import static org.junit.Assert.assertTrue;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.http.MediaType.APPLICATION_JSON;

/**
 * Created by sukhmeet.sethi on 12/12/2016.
 */
@ActiveProfiles( value = "bdd" )
@SpringBootTest( webEnvironment = DEFINED_PORT )
@ContextConfiguration( classes = { Swagger2SpringBoot.class, TestConfig.class } )
public class NotificationServiceStepDefs {

    Map<String,JsonNode> messageMap;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    MessageLoader messageLoader;

    @Value( "${rest.url}" )
    private String restUrl;

    @Autowired
    private Collection<RouterMessage> messages;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    DummyMailingService dummyMailingService;

    ResponseEntity<JsonNode> responseEntity;

    @Given("^\"([^\"]*)\" request-responses are available$")
    public void request_responses_are_available(String requestResponses) throws Throwable {
        messageMap = messageLoader.loadJsonFiles(requestResponses);
        assertFalse("Request responses not loaded", messageMap.isEmpty());
    }


    @When("^the \"([^\"]*)\" notification request is processed$")
    public void the_notification_request_is_processed(String message) throws Throwable {
        JsonNode jsonNode = messageMap.get(message);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType( APPLICATION_JSON );
        HttpEntity<JsonNode> request = new HttpEntity<>( jsonNode, headers );

        try
        {
            responseEntity = restTemplate.postForEntity( restUrl + "/notification", request, JsonNode.class );
        }
        catch ( HttpClientErrorException x )
        {
            responseEntity = new ResponseEntity( x.getResponseBodyAsString(),x.getResponseHeaders(),
                    x.getStatusCode() );
        }
    }

    @Then("^the response code should be \"([^\"]*)\"$")
    public void the_response_code_should_be(String statusCode) throws Throwable {
        assertEquals(statusCode,responseEntity.getStatusCode().toString());
    }


    @Then("^the \"([^\"]*)\" response message should be available on queue$")
    public void the_response_message_should_be_available_on_queue(String notificationMessage) throws Throwable {

        JsonNode requestMessage = messageMap.get(notificationMessage);
        JsonNode expectedResponseMessage = messageMap.get("response-" + notificationMessage);
        String type = requestMessage.get("providers").get(0).get("type").asText();

        Message message = messages.parallelStream()
                .filter(m -> {
                    return m.getQueue().equals("NOTIFICATION" + "." + type);
                })
                .map( RouterMessage::getMessage )
                .findFirst()
                .orElseThrow( () -> new AssertionError( "Unable to find message for priovider " + type ) );


        JsonNode receivedJson = mapper.readTree( message.getPayload().toString() );

        assertEquals( "Issues in message to provider " + type, expectedResponseMessage, receivedJson );

    }

    @Given("^\"([^\"]*)\" request-response are available$")
    public void request_response_are_available(String requestResponses) throws Throwable {
        messageMap = messageLoader.loadJsonFiles(requestResponses);
        assertFalse("Request responses not loaded", messageMap.isEmpty());
    }
    @When("^the \"([^\"]*)\" notification invalid request is processed$")
    public void the_notification_invalid_request_is_processed(String message) throws Throwable {
        messages.clear();
        JsonNode jsonNode = messageMap.get(message);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        HttpEntity<JsonNode> request = new HttpEntity<>(jsonNode, headers);

        try {
            responseEntity = restTemplate.postForEntity(restUrl + "/notification", request, JsonNode.class);
        } catch (HttpClientErrorException x) {
            responseEntity = new ResponseEntity(x.getResponseBodyAsString(), x.getResponseHeaders(),
                    x.getStatusCode());
        }
    }
    @Then("^the \"([^\"]*)\" response should be available on the endpoint$")
    public void the_response_should_be_available_on_the_endpoint(String notificationMessage) throws Throwable {
        JsonNode expectedResponseMessage = messageMap.get("response-" + notificationMessage);
        String incomingMessage = dummyMailingService.getIncomingMessage();
        assertEquals("invalid response reccived from service",expectedResponseMessage.toString(),incomingMessage);
    }

    @Then("^the \"([^\"]*)\" response message should not be available on queue$")
    public void the_response_message_should_not_be_available_on_queue(String notificationMessage) throws Throwable {
        JsonNode requestMessage = messageMap.get(notificationMessage);
        JsonNode expectedResponseMessage = messageMap.get("response-" + notificationMessage);

        String type = requestMessage.get("providers").get(0).get("type").asText();

        long count = messages.parallelStream()
                .filter(m -> {
                    return m.getQueue().equals("NOTIFICATION" + "." + type);
                }).count();


        assertTrue(count==0);
        assertEquals( "Invalid Schema" + type, expectedResponseMessage.toString(), responseEntity.getBody());
    }

    @Then("^the \"([^\"]*)\" response message should be available on queue with all resolved expressions$")
    public void the_response_message_should_be_available_on_queue_with_all_resolved_expressions(String notificationMessage) throws Throwable {
        JsonNode requestMessage = messageMap.get(notificationMessage);
        JsonNode expectedResponseMessage = messageMap.get("response-" + notificationMessage);
        String type = requestMessage.get("providers").get(0).get("type").asText();

        Message message = messages.parallelStream()
                .filter(m -> {
                    return m.getQueue().equals("NOTIFICATION" + "." + type);
                })
                .map( RouterMessage::getMessage )
                .findFirst()
                .orElseThrow( () -> new AssertionError( "Unable to find message for priovider " + type ) );


        JsonNode receivedJson = mapper.readTree( message.getPayload().toString() );

        assertEquals( "Issues in message to provider " + type, expectedResponseMessage, receivedJson );

        JsonNode meta = requestMessage.get("meta");
        Pattern pattern = Pattern.compile("\\$\\{([^}]*)}");
        Matcher matcher = pattern.matcher(receivedJson.toString());

        assertFalse(matcher.find()); // assertd that all expressions are resolved

        JsonNode jsonNode = messageMap.get(message);
        String responseProviderBody =  receivedJson.get("body").asText();

        boolean result = false;
        Matcher matcherFromRequest = pattern.matcher(requestMessage.toString());
        while (matcherFromRequest.find()) {
            String group = matcherFromRequest.group(1);
            String metaToBeReplaced = group.split("\\.")[1];
            if (meta.get(metaToBeReplaced)!=null){
                 result =  responseProviderBody.contains(meta.get(metaToBeReplaced).asText());
            }
        }
        assertTrue(result);

    }
    @Then("^the \"([^\"]*)\" response message should be returned from the service\\.$")
    public void the_response_message_should_be_returned_from_the_service(String notificationMessage) throws Throwable {
        JsonNode requestMessage = messageMap.get(notificationMessage);
        JsonNode expectedResponseMessage = messageMap.get("response-" + notificationMessage);

        String type = requestMessage.get("providers").get(0).get("type").asText();

        System.out.println("-------" + expectedResponseMessage.toString());
        System.out.println("XXXXX" );
        assertEquals(  expectedResponseMessage.toString(), responseEntity.getBody());
    }


    @Then("^the \"([^\"]*)\" response message should be returned from service and should be available on queue$")
    public void the_response_message_should_be_returned_from_service_and_should_be_available_on_queue(String notificationMessage) throws Throwable {
        JsonNode requestMessage = messageMap.get(notificationMessage);
        JsonNode expectedResponseMessage = messageMap.get("response-" + notificationMessage);
        String type = requestMessage.get("providers").get(0).get("type").asText();

        Message message = messages.parallelStream()
                .filter(m -> {
                    return m.getQueue().equals("NOTIFICATION" + "." + type);
                })
                .map( RouterMessage::getMessage )
                .findFirst()
                .orElseThrow( () -> new AssertionError( "Unable to find message for provider " + type ) );

        assertTrue(messages.size()>0);
        assertEquals(expectedResponseMessage.toString(), responseEntity.getBody().toString());



    }

}
