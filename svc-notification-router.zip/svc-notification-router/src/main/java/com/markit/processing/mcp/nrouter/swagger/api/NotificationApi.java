package com.markit.processing.mcp.nrouter.swagger.api;


import com.markit.processing.mcp.nrouter.swagger.model.NotificationMessage;
import com.markit.processing.mcp.nrouter.swagger.model.NotificationResponse;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-12-19T09:58:12.694Z")

@Api(value = "notification", description = "the notification API")
public interface NotificationApi {

    @ApiOperation(value = "Process Notification Request", notes = "Process Notification Request", response = NotificationResponse.class, responseContainer = "List", tags={ "Notification", })
    @ApiResponses(value = { 
        @ApiResponse(code = 207, message = "Partial success of the notification. One or more providers have failed", response = NotificationResponse.class),
        @ApiResponse(code = 400, message = "Bad request or invalid request", response = NotificationResponse.class),
        @ApiResponse(code = 417, message = "Expression evaluation failed because expression key is not found in meta", response = NotificationResponse.class),
        @ApiResponse(code = 200, message = "notification processed successfully", response = NotificationResponse.class) })
    @RequestMapping(value = "/notification",
        produces = { "application/json" }, 
        consumes = { "application/json" },
        method = RequestMethod.POST)
    ResponseEntity<List<NotificationResponse>> processNotificationRequest(@ApiParam(value = "Notification Query", required = true) @RequestBody NotificationMessage notificationRequest);

}
