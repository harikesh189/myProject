package com.markit.processing.mcp.nrouter.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Providers
 */
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-12-19T09:58:12.694Z")

public class Providers   {
  @JsonProperty("type")
  private String type = null;

  @JsonProperty("persist")
  private Boolean persist = null;

  @JsonProperty("details")
  private Map<String, Object> details = new HashMap<String, Object>();

  public Providers type(String type) {
    this.type = type;
    return this;
  }

   /**
   * type specify the provider
   * @return type
  **/
  @ApiModelProperty(value = "type specify the provider")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Providers persist(Boolean persist) {
    this.persist = persist;
    return this;
  }

   /**
   * persist the notification or not
   * @return persist
  **/
  @ApiModelProperty(value = "persist the notification or not")
  public Boolean getPersist() {
    return persist;
  }

  public void setPersist(Boolean persist) {
    this.persist = persist;
  }

  public Providers details(Map<String, Object> details) {
    this.details = details;
    return this;
  }

  public Providers putDetailsItem(String key, Object detailsItem) {
    this.details.put(key, detailsItem);
    return this;
  }

   /**
   * Get details
   * @return details
  **/
  @ApiModelProperty(value = "")
  public Map<String, Object> getDetails() {
    return details;
  }

  public void setDetails(Map<String, Object> details) {
    this.details = details;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Providers providers = (Providers) o;
    return Objects.equals(this.type, providers.type) &&
        Objects.equals(this.persist, providers.persist) &&
        Objects.equals(this.details, providers.details);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, persist, details);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Providers {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    persist: ").append(toIndentedString(persist)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

