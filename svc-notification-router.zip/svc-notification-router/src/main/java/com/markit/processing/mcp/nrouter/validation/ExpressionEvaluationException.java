package com.markit.processing.mcp.nrouter.validation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sukhmeet.sethi on 12/7/2016.
 */
public class ExpressionEvaluationException extends RuntimeException {

    public ExpressionEvaluationException(String message) {
        super(message);

    }

}
