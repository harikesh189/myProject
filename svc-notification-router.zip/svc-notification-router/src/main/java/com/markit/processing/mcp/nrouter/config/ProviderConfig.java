package com.markit.processing.mcp.nrouter.config;

import java.util.List;
import java.util.Map;

/**
 * POJO representing provider configuration. Mostly used for json to Object conversion and vise-versa
 * <p>
 * Created by sukhmeet.sethi on 12/9/2016.
 */

public class ProviderConfig {

    private List<Style> style;
    private String destinationUrl;
    private String destinationMqAddress;
    private Map<String, ValidationSchema> validations;

    public ProviderConfig(List<Style> style, String destinationUrl, String destinationMqAddress, Map<String, ValidationSchema> validations) {
        this.style = style;
        this.destinationUrl = destinationUrl;
        this.destinationMqAddress = destinationMqAddress;
        this.validations = validations;
    }

    /**
     *  Jackson uses it for json conversion
     */
    public ProviderConfig() {
    }

    public List<Style> getStyle() {
        return style;
    }

    public void setStyle(List<Style> style) {
        this.style = style;
    }

    public String getDestinationUrl() {
        return destinationUrl;
    }

    public void setDestinationUrl(String destinationUrl) {
        this.destinationUrl = destinationUrl;
    }

    public String getDestinationMqAddress() {
        return destinationMqAddress;
    }

    public void setDestinationMqAddress(String destinationMqAddress) {
        this.destinationMqAddress = destinationMqAddress;
    }

    public Map<String, ValidationSchema> getValidations() {
        return validations;
    }

    public void setValidations(Map<String, ValidationSchema> validations) {
        this.validations = validations;
    }

    /**
     *  Enum holds styles through which a notification can be processed:
     *  sync : processing through rest endpoint
     *  async : processing through AMQ
     */
    public static enum Style {
        async(), sync()
    }

    /**
     * Holds the rules for validation
     * type : expects field value to be of given 'type' described here
     * nullable : if the field can be null or not
     * custom: any custom rule to be applied on a field. Rule should be defined as function in custom-rules.js file
     */
    public static class ValidationSchema {
        private String type;
        private Boolean nullable;
        private String custom;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Boolean getNullable() {
            return nullable;
        }

        public void setNullable(Boolean nullable) {
            this.nullable = nullable;
        }

        public String getCustom() {
            return custom;
        }

        public void setCustom(String custom) {
            this.custom = custom;
        }
    }


}
