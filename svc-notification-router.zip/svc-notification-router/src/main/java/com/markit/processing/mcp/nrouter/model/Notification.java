package com.markit.processing.mcp.nrouter.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

/**
 * Created by sukhmeet.sethi on 12/19/2016.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Notification {

    private String subsystem;
    private String service;
    private String tag;
    private String type;
    private Boolean persist;
    private JsonNode details;


    public Notification(String subsystem, String service, String tag, String type, Boolean persist, JsonNode details) {

        this.subsystem = subsystem;
        this.service = service;
        this.tag = tag;
        this.type = type;
        this.persist = persist;
        this.details = details;
    }

    public Notification() {
    }

    public String getSubsystem() {
        return subsystem;
    }

    public void setSubsystem(String subsystem) {
        this.subsystem = subsystem;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getPersist() {
        return persist;
    }

    public void setPersist(Boolean persist) {
        this.persist = persist;
    }

    public JsonNode getDetails() {
        return details;
    }

    public void setDetails(JsonNode details) {
        this.details = details;
    }
}
