package com.markit.processing.mcp.nrouter.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.processing.mcp.nrouter.swagger.model.NotificationMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.function.Function;

@Component
public class JsonNodeConverter implements Function<NotificationMessage, JsonNode> {
    @Autowired
    private ObjectMapper mapper;

    @Override
    public JsonNode apply(NotificationMessage json) {
        return mapper.valueToTree(json);
    }
}
