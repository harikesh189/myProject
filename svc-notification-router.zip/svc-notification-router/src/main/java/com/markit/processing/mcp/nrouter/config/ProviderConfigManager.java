package com.markit.processing.mcp.nrouter.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * Loads all provider configurations and custom rules into a Map
 *
 * Created by sukhmeet.sethi on 12/9/2016.
 */
@Component
public class ProviderConfigManager {

    private Map<String, ProviderConfig> providerConfigs = new HashMap<String, ProviderConfig>();
    private  Invocable inv;

    @Autowired
    ObjectMapper mapper;

    @PostConstruct
    public void initialize() throws URISyntaxException {
        final String configDir = "/providers/";
        final String rulesDir = "/rules/";

        URL configUrl = getClass().getResource(configDir);
        URL rulesUrl = getClass().getResource(rulesDir);

        loadProviderConfigs(configUrl);
        if(rulesUrl != null)
            loadRules(rulesUrl);
    }

    /**
     *  Loads the javascript rules file(s) available in rules directory
     *
     * @param rulesUrl
     */
    private void loadRules(URL rulesUrl) throws URISyntaxException {
        File dir = new File(rulesUrl.toURI());
        ScriptEngineManager factory = new ScriptEngineManager();
        ScriptEngine engine = factory.getEngineByName("JavaScript");
        Arrays.stream(dir.listFiles()).forEach((File file) -> {
            String fileName = file.getName();
            if (fileName.endsWith(".js")) {
                try {
                    Scanner scanner = new Scanner(new FileInputStream(file), "UTF-8");
                    scanner.useDelimiter("\\A");
                    String jsMethod = scanner.next();
                    engine.eval(jsMethod);
                    inv = (Invocable) engine;
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (ScriptException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Loads all available provider configs available in config directory and creates a map
     *
     * @param configUrl
     * @throws URISyntaxException
     */
    private void loadProviderConfigs(URL configUrl) throws URISyntaxException {
        if(configUrl == null){
            throw new RuntimeException("config directory not available");
        }
        File dir = new File(configUrl.toURI());
        Arrays.stream(dir.listFiles()).forEach((File file) -> {
            String fileName = file.getName();

            String provider = fileName.substring(0, fileName.indexOf("-"));
            try {
                ProviderConfig providerConfig = mapper.readValue(file.toURI().toURL(), ProviderConfig.class);
                providerConfigs.put(provider, providerConfig);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public ProviderConfig getProviderConfig(String provider){
        return providerConfigs.get(provider);
    }

    public Invocable getScriptInvocationHandle() {
        return inv;
    }
}
