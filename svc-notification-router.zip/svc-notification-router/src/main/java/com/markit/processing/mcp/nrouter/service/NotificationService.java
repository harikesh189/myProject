package com.markit.processing.mcp.nrouter.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.markit.processing.mcp.nrouter.model.Notification;
import com.markit.processing.mcp.nrouter.swagger.model.NotificationMessage;
import com.markit.processing.mcp.nrouter.swagger.model.NotificationResponse;
import com.markit.processing.mcp.nrouter.validation.ExpressionEvaluationException;
import com.markit.processing.mcp.nrouter.validation.ProviderSchemaValidationException;
import com.markit.processing.mcp.nrouter.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.MessageDeliveryException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.MULTI_STATUS;

/**
 * Processes the incoming notification and provides corresponding responses
 * Decouples implementation logic from auto-generated controller class
 * <p>
 * Created by sukhmeet.sethi on 12/9/2016.
 */
@Component
public class NotificationService {

    public static final String FAILURE = "Failure";
    @Autowired
    private JsonNodeConverter jsonNodeConverter;

    @Autowired
    private VariableExpander variableExpander;

    @Autowired
    private ProviderSplitter providerSplitter;

    @Autowired
    private MessageSender messageSender;

    @Autowired
    private StorageHelper storageHelper;

    @Autowired
    private Validator validator;


    @Autowired
    private ObjectMapper mapper;

    /**
     * Performs following operations on incoming message:
     * - Converts the message to json
     * - Replaces all ${} expressions with corresponding keys in meta
     * - Validates each provider as per rules defined in provider config
     * - Sends the message to appropriate channel as per provider config
     *
     * @param notificationMessage
     * @return
     */
    public ResponseEntity<List<NotificationResponse>> processNotification(NotificationMessage notificationMessage) {

        List<NotificationResponse> errors = new ArrayList<NotificationResponse>();
        Stream<Notification> notificationStream = null;
        List<String> successResponse = null;
        try {

            notificationStream = Stream.of(notificationMessage)
                    .map(jsonNodeConverter)         // from string to JsonNode
                    .map(variableExpander)          // replace ${} with meta data
                    .map(providerSplitter::split)   // split provider msgs from notification
                    .flatMap(n -> n.stream());


            // handle validation stream separately to catch all errors
            successResponse = notificationStream.map(notification -> {
                return validateProvider(errors, notification);
            }).filter(notification -> notification != null)
                    .map((Notification notification) -> {
                        return storeMessage(errors, notification);
                    })
                    .filter(notification -> notification != null)
                    .map(notification -> {
                        return dispatchMessage(errors, notification);
                    })
                    .filter(jsonNode -> jsonNode != null)
                    .collect(Collectors.toList());
        } catch (ExpressionEvaluationException e) {
            errors.add(createNotificationResponse(FAILURE, "Expression evaluation failure", null, Arrays.asList(e.getMessage())));
            return createResponseEntity(Lists.newArrayList(), errors, HttpStatus.EXPECTATION_FAILED);
        }
        if (!errors.isEmpty()) {
            return createResponseEntity(successResponse, errors, successResponse == null || successResponse.isEmpty() ? BAD_REQUEST : MULTI_STATUS);
        }

        return createResponseEntity(successResponse, Lists.newArrayList(), HttpStatus.OK);
    }

    private Notification storeMessage(List<NotificationResponse> errors, Notification notification) {
        try {
            return storageHelper.storeNotification(notification); // send the messages for storage
        } catch (MessageDeliveryException de) {
            errors.add(createNotificationResponse(FAILURE, "Message storage failure", notification.getType(), Arrays.asList(de.getMessage())));
            return null;
        }
    }

    private String dispatchMessage(List<NotificationResponse> errors, Notification notification) {
        try {
            return messageSender.apply(mapper.valueToTree(notification)); // send the messages to the providers
        } catch (MessageDeliveryException de) {
            errors.add(createNotificationResponse(FAILURE, "Message delivery failure", notification.getType(), Arrays.asList(de.getMessage())));
            return null;
        }
    }

    private Notification validateProvider(List<NotificationResponse> errors, Notification notification) {
        try {
            validator.validate(mapper.valueToTree(notification)); // validate providers as per validation rules
            return notification;
        } catch (ProviderSchemaValidationException e) {
            errors.add(createNotificationResponse(FAILURE, "Invalid Schema", e.getNotificationType(), e.getMessages()));
            return null;
        }
    }

    private NotificationResponse createNotificationResponse(String status, String exceptionType, String provider, List<String> messages) {
        return new NotificationResponse().status(status).error(exceptionType).provider(provider).messages(messages);
    }

    private ResponseEntity<List<NotificationResponse>> createResponseEntity(List<String> successfulTypes, List<NotificationResponse> errors, HttpStatus status) {
        List<NotificationResponse> responses = successfulTypes.stream().map(this::createResponseForSuccessMessages).collect(Collectors.toList());
        responses.addAll(errors);
        ResponseEntity<List<NotificationResponse>> responseEntity = null;
        return new ResponseEntity<>(responses, status);
    }

    private NotificationResponse createResponseForSuccessMessages(String type) {
        return new NotificationResponse().status("Success").provider(type).messages(Arrays.asList("Notification processed successfully"));
    }

}
