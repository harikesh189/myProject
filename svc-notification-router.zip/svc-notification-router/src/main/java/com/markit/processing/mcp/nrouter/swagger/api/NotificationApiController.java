package com.markit.processing.mcp.nrouter.swagger.api;

import com.markit.processing.mcp.nrouter.service.NotificationService;
import com.markit.processing.mcp.nrouter.swagger.model.NotificationMessage;
import com.markit.processing.mcp.nrouter.swagger.model.NotificationResponse;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;


@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-12-19T09:58:12.694Z")

@Controller
public class NotificationApiController implements NotificationApi {

    @Autowired
    NotificationService notificationService;

    public ResponseEntity<List<NotificationResponse>> processNotificationRequest(@ApiParam(value = "Notification Query" ,required=true ) @RequestBody NotificationMessage notificationRequest) {
        return notificationService.processNotification(notificationRequest);
    }

}
