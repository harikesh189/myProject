package com.markit.processing.mcp.nrouter.swagger.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.*;

/**
 * NotificationMessage
 */
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-12-19T09:58:12.694Z")

public class NotificationMessage   {
  @JsonProperty("subsystem")
  private String subsystem = null;

  @JsonProperty("service")
  private String service = null;

  @JsonProperty("tag")
  private String tag = null;

  @JsonProperty("providers")
  private List<Providers> providers = new ArrayList<Providers>();

  @JsonProperty("meta")
  private Map<String, String> meta = new HashMap<String, String>();

  public NotificationMessage subsystem(String subsystem) {
    this.subsystem = subsystem;
    return this;
  }

   /**
   * subsystem.
   * @return subsystem
  **/
  @ApiModelProperty(value = "subsystem.")
  public String getSubsystem() {
    return subsystem;
  }

  public void setSubsystem(String subsystem) {
    this.subsystem = subsystem;
  }

  public NotificationMessage service(String service) {
    this.service = service;
    return this;
  }

   /**
   * service
   * @return service
  **/
  @ApiModelProperty(value = "service")
  public String getService() {
    return service;
  }

  public void setService(String service) {
    this.service = service;
  }

  public NotificationMessage tag(String tag) {
    this.tag = tag;
    return this;
  }

   /**
   * tag
   * @return tag
  **/
  @ApiModelProperty(value = "tag")
  public String getTag() {
    return tag;
  }

  public void setTag(String tag) {
    this.tag = tag;
  }

  public NotificationMessage providers(List<Providers> providers) {
    this.providers = providers;
    return this;
  }

  public NotificationMessage addProvidersItem(Providers providersItem) {
    this.providers.add(providersItem);
    return this;
  }

   /**
   * Get providers
   * @return providers
  **/
  @ApiModelProperty(value = "")
  public List<Providers> getProviders() {
    return providers;
  }

  public void setProviders(List<Providers> providers) {
    this.providers = providers;
  }

  public NotificationMessage meta(Map<String, String> meta) {
    this.meta = meta;
    return this;
  }

  public NotificationMessage putMetaItem(String key, String metaItem) {
    this.meta.put(key, metaItem);
    return this;
  }

   /**
   * Get meta
   * @return meta
  **/
  @ApiModelProperty(value = "")
  public Map<String, String> getMeta() {
    return meta;
  }

  public void setMeta(Map<String, String> meta) {
    this.meta = meta;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    NotificationMessage notificationMessage = (NotificationMessage) o;
    return Objects.equals(this.subsystem, notificationMessage.subsystem) &&
        Objects.equals(this.service, notificationMessage.service) &&
        Objects.equals(this.tag, notificationMessage.tag) &&
        Objects.equals(this.providers, notificationMessage.providers) &&
        Objects.equals(this.meta, notificationMessage.meta);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subsystem, service, tag, providers, meta);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NotificationMessage {\n");
    
    sb.append("    subsystem: ").append(toIndentedString(subsystem)).append("\n");
    sb.append("    service: ").append(toIndentedString(service)).append("\n");
    sb.append("    tag: ").append(toIndentedString(tag)).append("\n");
    sb.append("    providers: ").append(toIndentedString(providers)).append("\n");
    sb.append("    meta: ").append(toIndentedString(meta)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

