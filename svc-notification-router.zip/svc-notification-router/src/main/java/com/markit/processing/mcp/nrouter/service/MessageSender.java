package com.markit.processing.mcp.nrouter.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.markit.processing.mcp.nrouter.config.ProviderConfig;
import com.markit.processing.mcp.nrouter.config.ProviderConfigManager;
import com.markit.processing.mcp.nrouter.validation.ProviderSchemaValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.messaging.MessageDeliveryException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.function.Function;

import static com.markit.processing.mcp.nrouter.config.ProviderConfig.Style;
import static java.lang.String.format;
import static org.springframework.http.MediaType.APPLICATION_JSON;


/**
 *
 * Sends the message to right channel based on provider config
 *
 * Created by sukhmeet.sethi on 12/13/2016.
 */
@Component
public class MessageSender implements Function<JsonNode, String> {
    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    ProviderConfigManager providerConfigManager;


    @Override
    public String apply(JsonNode node) {

        String type = node.get("type").asText();

        ProviderConfig providerConfig = providerConfigManager.getProviderConfig(type);
        if(providerConfig == null){
            throw new ProviderSchemaValidationException(format("provider '%s' is not configured in system ", type));
        }
        providerConfig.getStyle().forEach((Style style) -> {
            if (Style.sync.name().equalsIgnoreCase(style.name())) {
                processMessageSynchronously(providerConfig, node);
            } else if (Style.async.name().equalsIgnoreCase(style.name())) {
                processMessageAsynchronously(providerConfig , node);
            }
        });
        return type;
    }

    /**
     * Sends the incoming json node to destination mq address
     *
     * @param providerConfig
     * @param node
     */
    private void processMessageAsynchronously(ProviderConfig providerConfig, JsonNode node) {
        jmsTemplate.convertAndSend(providerConfig.getDestinationMqAddress(), node.get("details").toString());
    }

    /**
     * Sends the message to rest endpoint defined in provider config
     * #MessageDeliveryException is thrown in case rest api fails to process request
     *
     * @param providerConfig
     * @param node
     */
    private void processMessageSynchronously(ProviderConfig providerConfig, JsonNode node) {
        RestTemplate restTemplate = new RestTemplate();
        String destinationUrl = providerConfig.getDestinationUrl();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<String>(node.get("details").toString(), headers);
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.postForEntity(destinationUrl, request, String.class);
            if (response.getStatusCode() != HttpStatus.OK) {
                throw new MessageDeliveryException(response.getBody());
            }
        } catch (HttpClientErrorException x) {
            throw new MessageDeliveryException(x.getMessage());
        }

    }
}
