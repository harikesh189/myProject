package com.markit.processing.mcp.nrouter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.processing.mcp.nrouter.model.Notification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.MessageDeliveryException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.net.ConnectException;

import static org.springframework.http.MediaType.APPLICATION_JSON;

/**
 * Created by sukhmeet.sethi on 12/19/2016.
 */
@Component
public class StorageHelper {

    @Value("${persistence.store.endpoint}")
    private String storeEndpoint;


    @Autowired
    ObjectMapper mapper;

    private Notification store(Notification notificationMessage) {
        RestTemplate restTemplate = new RestTemplate();
        String destinationUrl = storeEndpoint;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        HttpEntity<String> request = null;
        try {
            request = new HttpEntity<String>(mapper.writeValueAsString(notificationMessage), headers);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.postForEntity(destinationUrl, request, String.class);
            if (response.getStatusCode() != HttpStatus.OK) {
                throw new MessageDeliveryException(response.getBody());
            }
        } catch (HttpClientErrorException  | ResourceAccessException x) {
            throw new MessageDeliveryException(x.getMessage());
        }
        return notificationMessage;
    }

    public Notification storeNotification(Notification notification) {
        Boolean persist = notification.getPersist();
        return persist != null && persist ? store(notification) : notification;
    }
}
