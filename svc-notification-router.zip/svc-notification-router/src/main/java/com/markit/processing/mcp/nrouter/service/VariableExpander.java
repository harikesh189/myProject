package com.markit.processing.mcp.nrouter.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.processing.mcp.nrouter.validation.ExpressionEvaluationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/***
 * Replaces the ${} expressions in incoming json with corresponding values in meta info
 */
@Component
public class VariableExpander implements Function<JsonNode, JsonNode> {

    @Autowired
    ObjectMapper mapper;

    @Override
    public JsonNode apply(JsonNode s) throws ExpressionEvaluationException {
        JsonNode meta = s.get("meta");
        Pattern pattern = Pattern.compile("\\$\\{([^}]*)}");
        Matcher matcher = pattern.matcher(s.toString());
        StringBuffer sb = new StringBuffer();

        while (matcher.find()) {
            String group = matcher.group(1);
            String metaToBeReplaced = group.split("\\.")[1];
            if (meta.get(metaToBeReplaced) != null) {
                matcher.appendReplacement(sb, meta.get(metaToBeReplaced).asText());
            } else {
                throw new ExpressionEvaluationException("Expression key not found in meta : " + metaToBeReplaced);
            }
        }

        matcher.appendTail(sb);

        try {
            return mapper.readTree(sb.toString());
        } catch (IOException e) {
            return s;
        }
    }

}
