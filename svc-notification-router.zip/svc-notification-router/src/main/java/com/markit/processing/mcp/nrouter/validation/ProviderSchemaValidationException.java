package com.markit.processing.mcp.nrouter.validation;

import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

/**
 * Created by sukhmeet.sethi on 12/7/2016.
 */
public class ProviderSchemaValidationException extends RuntimeException {

    List<String> messages = new ArrayList<String>();
    String notificationType;

    public ProviderSchemaValidationException(String message) {
        super(message);
        messages.add(message);
    }

    public ProviderSchemaValidationException() {
        super();
    }

    public List<String> getMessages(){
        return messages;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }
}
