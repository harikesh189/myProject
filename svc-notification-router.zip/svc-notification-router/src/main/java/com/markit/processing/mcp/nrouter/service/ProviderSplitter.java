package com.markit.processing.mcp.nrouter.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.processing.mcp.nrouter.model.Notification;
import com.markit.processing.mcp.nrouter.swagger.model.NotificationMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class ProviderSplitter
{

    @Autowired
    ObjectMapper mapper;


    public List<Notification> split(JsonNode node )
    {
        if ( !node.has( "providers" ) )
            throw new JsonValidationException( "Providers missing form JSON" );

        NotificationMessage notificationMessage = null;
        try {
            notificationMessage = mapper.readValue(node.toString(),NotificationMessage.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        final NotificationMessage message = notificationMessage; // to enable lambda processing

        List<Notification> listOfMessages = message.getProviders().stream()
                .map(provider -> {
//                    return new NotificationMessage().subsystem(message.getSubsystem()).service(message.getService()).tag(message.getTag()).addProvidersItem(provider);
                    return new Notification(message.getSubsystem(), message.getService(), message.getTag(), provider.getType(), provider.getPersist(), mapper.valueToTree(provider.getDetails()));
                })
                .collect(Collectors.toList());


        return listOfMessages;
    }
}
