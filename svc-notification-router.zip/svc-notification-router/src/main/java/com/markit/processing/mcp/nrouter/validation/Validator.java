package com.markit.processing.mcp.nrouter.validation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.processing.mcp.nrouter.config.ProviderConfig;
import com.markit.processing.mcp.nrouter.config.ProviderConfigManager;
import com.markit.processing.mcp.nrouter.service.JsonValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.script.Invocable;
import javax.script.ScriptException;
import java.lang.reflect.Method;
import java.util.Map;

import static java.lang.String.format;

/**
 * Created by sukhmeet.sethi on 12/6/2016.
 */
@Component
public class Validator {

    @Autowired
    ProviderConfigManager configManager;

    @Autowired
    ObjectMapper mapper;

    /**
     * Validates the incoming node as per validation rules
     * throws #ProviderSchemaValidationException in case of validation failure
     *
     * @param node
     */
    public void validate(JsonNode node) {

        if (!node.has("type"))
            throw new JsonValidationException("Unable to determine type for provider");

        String type = node.get("type").asText();
        validate(type, node);
    }

    private void validate(String type, JsonNode jsonNode) {

        JsonNode details = jsonNode.get("details");
        ProviderConfig providerConfig = configManager.getProviderConfig(type);
        if (providerConfig == null) {
            throw new ProviderSchemaValidationException(format("provider '%s' is not configured in system ", type));
        }
        Map<String, ProviderConfig.ValidationSchema> validations = providerConfig.getValidations();

        ProviderSchemaValidationException exceptions = new ProviderSchemaValidationException();

        if (validations != null) { // if rules are defined, validate else just leave
            validations.forEach((fieldName, rule) -> {
                try {
                    matchAgainstRules(fieldName, details.get(fieldName), validations);
                } catch (ProviderSchemaValidationException e) {
                    exceptions.getMessages().add(e.getMessage());
                }
            });
        }

        if (!exceptions.getMessages().isEmpty()) {
            exceptions.setNotificationType(type);
            throw exceptions;
        }
    }

    private void matchAgainstRules(String fieldName, JsonNode jsonNode, Map<String, ProviderConfig.ValidationSchema> validations) {

        ProviderConfig.ValidationSchema validationSchema = validations.get(fieldName);

        validateNullability(fieldName, jsonNode, validationSchema.getNullable());
        validateTypes(fieldName, jsonNode, validationSchema.getType());
        validateCustomField(fieldName, jsonNode, validationSchema.getCustom());

    }

    private void validateCustomField(String fieldName, JsonNode jsonNode, String ruleMethod) {

        if (ruleMethod != null && jsonNode != null) {
            try {
                Invocable inv = configManager.getScriptInvocationHandle();
                if (!(boolean) inv.invokeFunction(ruleMethod, jsonNode.asText())) {
                    throw new ProviderSchemaValidationException("invalid format for field '" + fieldName + "'");
                }
            } catch (ScriptException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                throw new ProviderSchemaValidationException("provider not correctly configured");
            }
        }
    }

    private void validateNullability(String fieldName, JsonNode jsonNode, Boolean rule) {
        if (rule != null && (jsonNode == null || jsonNode.isNull()) && !rule) {
            throw new ProviderSchemaValidationException("'" + fieldName + "' should be not null");
        }
    }

    private void validateTypes(String fieldName, JsonNode jsonNode, String rule) {
        if (rule != null && jsonNode != null) {
            String validatingMethod = DataTypes.getType(rule).getValidatingMethod();
            try {
                Method method = JsonNode.class.getMethod(validatingMethod);
                if (!(boolean) method.invoke(jsonNode)) {
                    throw new ProviderSchemaValidationException("Incorrect data type for field '" + fieldName + "', expected type is :" + rule);
                }
            } catch (ReflectiveOperationException e) {
                e.printStackTrace();
            }
        }
    }


    public enum DataTypes {
        INT("isInt"), STRING("isTextual"), BOOLEAN("isBoolean");

        String methodName;

        DataTypes(String methodName) {
            this.methodName = methodName;
        }

        public static DataTypes getType(String type) {
            DataTypes validType = DataTypes.valueOf(type.toUpperCase());
            return validType;
        }

        public String getValidatingMethod() {
            return methodName;
        }
    }

}
