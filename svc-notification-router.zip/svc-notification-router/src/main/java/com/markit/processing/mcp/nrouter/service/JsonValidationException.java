package com.markit.processing.mcp.nrouter.service;


import org.springframework.web.bind.annotation.ResponseStatus;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@ResponseStatus( value= BAD_REQUEST, reason="Invalid Json")
public class JsonValidationException extends RuntimeException
{
    public JsonValidationException( String message )
    {
        super( message );
    }


}
