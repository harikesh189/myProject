package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum FeeType {
	ADMINISTRATIVE, MONTHLY_ASSOCIATION
}
