package com.hcentive.billing.wfm.domain.contract;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.Member;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "member")
@DiscriminatorValue("EligibleMember")
public class EligibleMember extends Member implements Effectivity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -48350878065115317L;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "effective_date")) })
	@Access(AccessType.FIELD)
	private DateTime effectiveDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "termination_date")) })
	@Access(AccessType.FIELD)
	private DateTime terminationDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "cancellation_date")) })
	@Access(AccessType.FIELD)
	private DateTime cancellationDate;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Access(AccessType.FIELD)
	@JoinTable(name = "member_eligibility_factors", joinColumns = @JoinColumn(name = "member_id"), inverseJoinColumns = @JoinColumn(name = "eligibility_factors_id"))
	private Set<EligibilityFactor> eligibilityFactors = new HashSet<>();

//	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@Access(AccessType.FIELD)
//	@JoinTable(name = "member_qualified_subsidies", joinColumns = @JoinColumn(name = "member_id"), inverseJoinColumns = @JoinColumn(name = "qualified_subsidies_id"))
//	private Set<Subsidy> qualifiedSubsidies = new HashSet<>();

	public DateTime getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(DateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public DateTime getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(DateTime terminationDate) {
		this.terminationDate = terminationDate;
	}

	public DateTime getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(DateTime cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public Set<EligibilityFactor> getEligibilityFactors() {
		return eligibilityFactors;
	}

	public void setEligibilityFactors(Set<EligibilityFactor> eligibilityFactors) {
		this.eligibilityFactors = eligibilityFactors;
	}
	
	public void clearEligibilityFactors() {
		this.eligibilityFactors.clear();
	}
	
/*	public Set<Subsidy> getQualifiedSubsidies() {
		return qualifiedSubsidies;
	}

	public void setQualifiedSubsidies(Set<Subsidy> qualifiedSubsidies) {
		this.qualifiedSubsidies = qualifiedSubsidies;
	}*/

	@Override
	public Period effectivePeriod() {
		return new Period(effectiveDate, terminationDate);
	}

	public EligibleMember() {
	}

}
