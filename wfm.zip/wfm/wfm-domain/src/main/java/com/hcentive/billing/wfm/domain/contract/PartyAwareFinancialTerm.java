package com.hcentive.billing.wfm.domain.contract;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.PartyAware;

public interface PartyAwareFinancialTerm<V> extends FinancialTerm<V>,
		PartyAware<BusinessEntity<Profile>> {

}
