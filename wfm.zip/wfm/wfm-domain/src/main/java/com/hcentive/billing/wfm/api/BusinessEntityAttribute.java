package com.hcentive.billing.wfm.api;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.wfm.domain.ServicePeriod;

public class BusinessEntityAttribute extends
		FinancialEventRecordAttr<BusinessEntity<Profile>> {

	private Set<ServicePeriod> servicePeriods;

	public BusinessEntityAttribute(final String code,
			final BusinessEntity<Profile> value) {
		super(code, value);
	}

	public Set<ServicePeriod> getServicePeriods() {
		return this.servicePeriods;
	}

	public void setServicePeriods(final Set<ServicePeriod> servicePeriods) {
		this.servicePeriods = servicePeriods;
	}

}
