package com.hcentive.billing.wfm.api;

import com.hcentive.billing.core.commons.vo.Amount;

public class AmountAttribute extends FinancialEventRecordAttr<Amount> {

	private AmountCategory category;

	private String amountName;

	public AmountAttribute(final String code, final String description, final Amount value,
			final AmountCategory category, final String name) {
		super(code, description, value);
		this.amountName = name;
		this.category = category;
	}

	public AmountCategory getCategory() {
		return this.category;
	}

	public void setCategory(final AmountCategory category) {
		this.category = category;
	}

	public String getAmountName() {
		return amountName;
	}

	public void setAmountName(String amountName) {
		this.amountName = amountName;
	}

}
