package com.hcentive.billing.wfm.api;

public enum FinancialTermValueType {

	FIXED, PERCENTAGE

}
