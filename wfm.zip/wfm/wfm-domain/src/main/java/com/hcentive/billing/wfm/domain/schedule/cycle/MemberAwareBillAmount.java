package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.MemberBreakUpAmountAware;

@Entity
@Table(name = "bill_amount")
@DiscriminatorValue("MEM_AWARE_BILL_AMT")
public class MemberAwareBillAmount extends BillAmount implements
		MemberBreakUpAmountAware {

	private static final long serialVersionUID = 8965180092123088508L;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "bill_amount_member_break_ups", joinColumns = @JoinColumn(name = "bill_amount_id"), inverseJoinColumns = @JoinColumn(name = "member_break_ups_id"))
	private Set<MemberBreakUp> memberBreakUps;

	protected MemberAwareBillAmount() {
	}

	public MemberAwareBillAmount(String code, String name, Amount amount,
			AmountCategory type, String desc, Period coveragePeriod) {
		this(code, name, amount, type, null, AmountGroup.DEFAULT, desc, coveragePeriod, null);
	}

	public MemberAwareBillAmount(String code, String name, Amount amount,
			AmountCategory type, Set<MemberBreakUp> memberBreakUps, 
			AmountGroup amtGrp, String desc, Period coveragePeriod, DateTime associatedDate) {
		super(code, name, amount, type, amtGrp, desc, coveragePeriod, associatedDate);
		this.memberBreakUps = memberBreakUps == null ? new HashSet<MemberBreakUp>()
				: memberBreakUps;
	}

	public void addMemberBreakUp(MemberBreakUp memberBreakUp) {
		memberBreakUps.add(memberBreakUp);
	}

	public Set<MemberBreakUp> getMemberBreakUps() {
		return memberBreakUps;
	}

	@Override
	public Set<MemberBreakUp> memberBreakUpAmounts() {
		return getMemberBreakUps();
	}

	public BillAmount makeFTEntryAwareBillAmount(Set<String> ftEntryIds,
			AmountGroup amtGrp,DateTime associatedDate) {
		return new FTEntryMemberAwareBillAmount(getCode(), getName(),
				getAmountCategory(), getAmount(), ftEntryIds,
				getMemberBreakUps(), amtGrp, getDescription(), getCoveragePeriod(),associatedDate);
	}

	public String toString() {
		return super.toString() + ": member breakup: " + memberBreakUps;
	}

}
