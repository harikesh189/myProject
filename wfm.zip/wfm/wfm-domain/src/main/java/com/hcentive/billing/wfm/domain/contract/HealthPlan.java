package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("HEALTH_PLAN")
public class HealthPlan extends BillingPlan{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3118669210692344357L;

	@Access(AccessType.FIELD)
	@Column(name = "issuer_plan_id")
	private String issuerPlanId;


	@Access(AccessType.FIELD)
	@Column(name = "line_of_business")
	private String lineOfBusiness;
	
	
	protected HealthPlan() {

	}

	public HealthPlan(String identity, String externalId) {
		super();
		this.identity = identity;
		this.externalId = externalId;

	}
	


	public String getIssuerPlanId() {
		return issuerPlanId;
	}

	public void setIssuerPlanId(String issuerPlanId) {
		this.issuerPlanId = issuerPlanId;
	}

	@Override
	public String typeName() {
		return "HealthPlan";
	}


	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	
	

}
