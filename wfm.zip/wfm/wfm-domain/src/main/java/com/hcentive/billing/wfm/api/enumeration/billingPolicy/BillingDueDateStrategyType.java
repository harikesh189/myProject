package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * It represent the strategy to define the billing due date w.r.t billing
 * period.
 * 
 * @author nitin.singla
 * 
 */
public enum BillingDueDateStrategyType {

	/**
	 * It means billing due date will be calculated by subtracting specified
	 * number of days from first date of the billing cycle. <br/>
	 * Example : Conditions
	 * <ul>
	 * <li>Billing period type = QUARTERLY</li>
	 * <li>Number of specified days = 10</li>
	 * <li>Billing cycle is run for Jan-Mar period</li>
	 * </ul>
	 * Billing due date = 22 Dec (1 Jan - 10 days)
	 */
	@Deprecated
	FIRST_DAY_BILLING_PERIOD_MINUS,

	/**
	 * It means billing due date will be calculated by adding specified number
	 * of days from first date of the billing cycle. Example : Conditions
	 * <ul>
	 * <li>Billing period type = QUARTERLY</li>
	 * <li>Number of specified days = 10</li>
	 * <li>Billing cycle is run for Jan-Mar period</li>
	 * </ul>
	 * Billing due date = 11 Jan (1 Jan + 10 days)
	 */
	@Deprecated
	FIRST_DAY_BILLING_PERIOD_PLUS,

	/**
	 * It means billing due date will be calculated by adding specified number
	 * of days from first date of the billing cycle. Example : Conditions
	 * <ul>
	 * <li>Billing period type = QUARTERLY</li>
	 * <li>Billing cycle is run for Jan-Mar period</li>
	 * </ul>
	 * Billing due date = 1 Jan (First day of billing period)
	 */
	@Deprecated
	FIRST_DAY_OF_BILLING_PERIOD,

	/**
	 * It means billing due date will be calculated by adding specified number
	 * of days from first date of the billing cycle. Example : Conditions
	 * <ul>
	 * <li>Billing period type = QUARTERLY</li>
	 * <li>Billing cycle is run for Jan-Mar period</li>
	 * </ul>
	 * Billing due date = 31 March (Last day of billing period)
	 */
	@Deprecated
	LAST_DAY_BILLING_PERIOD_MINUS,
	
	DAYS_AFTER_GENERATION_DATE,
	
	/**
	 * It means a particular day of the month in the month 
	 * derived after adding month variant to the reference date
	 * For ex. dayOfMonth = 5, monthVariance = -2 and refDate = April 3rd
	 * Month will be calculated as -2 months from April which comes as February.
	 * Day of month should be set as 5th of the month
	 * Result = February 5th
	 */
	DAYS_AND_MONTH_VARIANT
}
