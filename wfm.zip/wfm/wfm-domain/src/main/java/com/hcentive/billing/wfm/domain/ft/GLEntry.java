package com.hcentive.billing.wfm.domain.ft;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.enumeration.ft.GLEntryCategory;
import com.hcentive.billing.wfm.api.enumeration.ft.PostingType;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@Entity
@Table(name = "gl_entry")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class GLEntry extends BaseEntity implements TenantAware {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "value")),
	        @AttributeOverride(name = "name", column = @Column(name = "name")), @AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
	        @AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	@OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinColumn(name = "billing_account_id", nullable = false)
	@Access(AccessType.FIELD)
	private BillingAccount billingAccount;

	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	@Column(name = "gl_category", nullable = false)
	private GLEntryCategory category;

	@SuppressWarnings("rawtypes")
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinColumn(name = "biller_entity_id", nullable = true)
	private BusinessEntity billerEntity;

	@OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinColumn(name = "gl_account_id", nullable = false)
	@Access(AccessType.FIELD)
	private GLAccount glAccount;

	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	@Column(name = "posting_type", nullable = false)
	private PostingType postingType;

	/**
	 * +1 for debit, -1 for credit.
	 */
	@Access(AccessType.FIELD)
	@Column(name = "posting_type_value")
	private short postingTypeValue;

	@Column(name = "gl_reversible")
	@Access(AccessType.FIELD)
	private boolean reversible;

	@Access(AccessType.FIELD)
	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;

	public GLEntry() {
	}

	public GLEntry(final Amount amount, final BillingAccount billingAccount, final GLEntryCategory category, final GLAccount glAccount,
	        final PostingType postingType, final boolean reversible) {
		super();
		this.amount = amount;
		this.billingAccount = billingAccount;
		this.category = category;
		this.glAccount = glAccount;
		this.reversible = reversible;
		setPostingType(postingType);
	}

	public Amount getAmount() {
		return amount;
	}

	public Amount getAmountWithPostingType() {
		final Amount amountWithPostingType = new Amount(this.amount.getValue());
		if (this.postingTypeValue == -1) {
			amountWithPostingType.setValue(amountWithPostingType.getValue().negate());
		}

		return amountWithPostingType;
	}

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

	public GLEntryCategory getCategory() {
		return category;
	}

	public GLAccount getGlAccount() {
		return glAccount;
	}

	public PostingType getPostingType() {
		return postingType;
	}

	@Override
	public String getTenantId() {
		if (this.tenantId == null) {
			return "";
		}
		return this.tenantId;
	}

	public boolean isReversible() {
		return reversible;
	}

	public GLEntry realizedEntry() {
		if (getGlAccount().isHoldingAccount()) {
			final GLEntry realizedResult = new GLEntry();
			realizedResult.setAmount(getAmount());
			realizedResult.setBillingAccount(getBillingAccount());
			realizedResult.setCategory(getCategory());
			realizedResult.setGlAccount(getGlAccount().getRealizedAccount());
			realizedResult.setPostingType(getPostingType());
			realizedResult.setReversible(isReversible());
			return realizedResult;
		}

		return null;
	}

	public GLEntry reverse() {
		final GLEntry reversedResult = new GLEntry();
		reversedResult.setAmount(getAmount());
		reversedResult.setBillingAccount(getBillingAccount());
		reversedResult.setCategory(getCategory());
		reversedResult.setGlAccount(getGlAccount());
		reversedResult.setPostingType(getPostingType().reverse());
		reversedResult.setReversible(isReversible());
		return reversedResult;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	public void setBillingAccount(final BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}

	public void setCategory(final GLEntryCategory category) {
		this.category = category;
	}

	public void setGlAccount(final GLAccount glAccount) {
		this.glAccount = glAccount;
	}

	/**
	 * postingTypeValue will also be updated accordingly.
	 *
	 * @param postingType
	 */
	public void setPostingType(final PostingType postingType) {
		this.postingType = postingType;
		if (this.postingType == PostingType.DR) {
			postingTypeValue = 1;
		} else {
			postingTypeValue = -1;
		}
	}

	public void setReversible(final boolean reversible) {
		this.reversible = reversible;
	}

	// Do no delete this method. It is used in logs.
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("GLEntry [amount=");
		builder.append(amount);
		builder.append(", billingAccount=");
		builder.append(billingAccount.getIdentity());
		builder.append(", category=");
		builder.append(category);
		builder.append(", glAccount=");
		builder.append(glAccount.getIdentity());
		builder.append(", postingType=");
		builder.append(postingType);
		builder.append(", postingTypeValue=");
		builder.append(postingTypeValue);
		builder.append(", reversible=");
		builder.append(reversible);
		builder.append(", tenantId=");
		builder.append(tenantId);
		builder.append("]");
		return builder.toString();
	}

	public BusinessEntity getBillerEntity() {
		return billerEntity;
	}

	public void setBillerEntity(BusinessEntity billerEntity) {
		this.billerEntity = billerEntity;
	}
}
