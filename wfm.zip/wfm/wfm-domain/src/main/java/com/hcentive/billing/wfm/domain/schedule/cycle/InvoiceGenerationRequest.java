package com.hcentive.billing.wfm.domain.schedule.cycle;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@Entity
@Table(name = "invoice_generation_request")
public class InvoiceGenerationRequest extends
		ReferenceableDomainEntity<InvoiceGenerationRequest, String> {

	private static final long serialVersionUID = 6179085683591282594L;

	@ManyToOne
	@JoinColumn(name = "invoice_for_id")
	private BillingAccount invoiceFor;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "billing_begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "billing_ends_on")) })
	private Period billingPeriod;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "trxn_begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "trxn_ends_on")) })
	private Period transactionPeriod;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "run_date")) })
	private DateTime runDate;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private RunStatus status;

	@ManyToOne
	@JoinColumn(name = "billing_account_run_cycle_id")
	private BillingAccountRunCycle billingAccountRunCycle;

	@Column(name = "generated_invoice_identity")
	private String generatedInvoiceIdentity;

	public InvoiceGenerationRequest(final BillingAccount billAcct,
			final Period billingPeriod) {
		this.invoiceFor = billAcct;
		this.billingPeriod = billingPeriod;
		this.setOperator(billAcct.getOperator());
	}

	protected InvoiceGenerationRequest() {
	}

	public Period getBillingPeriod() {
		return this.billingPeriod;
	}

	public BillingAccountRunCycle getBillingAccountRunCycle() {
		return this.billingAccountRunCycle;
	}

	public BillingAccount getInvoiceFor() {
		return this.invoiceFor;
	}

	public DateTime getRunDate() {
		return this.runDate;
	}

	public RunStatus getStatus() {
		return this.status;
	}

	public Period getTransactionPeriod() {
		return this.transactionPeriod;
	}

	@Override
	public String refValue() {
		return this.getIdentity();
	}

	public void setBillingPeriod(final Period billingPeriod) {
		this.billingPeriod = billingPeriod;
	}

	public void setBillingAccountRunCycle(
			final BillingAccountRunCycle billingRunCycle) {
		this.billingAccountRunCycle = billingRunCycle;
	}

	public void setInvoiceFor(final BillingAccount invoiceFor) {
		this.invoiceFor = invoiceFor;
	}

	public void setRunDate(final DateTime runDate) {
		this.runDate = runDate;
	}

	public void setStatus(final RunStatus status) {
		this.status = status;
	}

	public void setTransactionPeriod(final Period transactionPeriod) {
		this.transactionPeriod = transactionPeriod;
	}

	public String getGeneratedInvoiceIdentity() {
		return this.generatedInvoiceIdentity;
	}

	public void setGeneratedInvoiceIdentity(
			final String generatedInvoiceIdentity) {
		this.generatedInvoiceIdentity = generatedInvoiceIdentity;
	}

	@Override
	public String typeName() {
		return "InvoiceGenerationRun";
	}

}
