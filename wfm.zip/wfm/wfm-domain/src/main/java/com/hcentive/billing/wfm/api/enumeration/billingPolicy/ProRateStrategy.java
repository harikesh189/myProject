package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum ProRateStrategy {
	COVERAGE_DAYS, DAILY_PROROATE, MONTHLY_THRESHOLD
}
