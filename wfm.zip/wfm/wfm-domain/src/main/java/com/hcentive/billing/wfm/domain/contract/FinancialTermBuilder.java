/**
 *
 */
package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;

/**
 * @author Dikshit.Vaid
 *
 */
public interface FinancialTermBuilder {

	Collection<FinancialTerm<?>> build(BillingAccount billingAccount,
	        FinancialContract<ContractType, ?> contract, Period effectivePeriod);

	boolean canHandle(BillRunContext runContext);

}
