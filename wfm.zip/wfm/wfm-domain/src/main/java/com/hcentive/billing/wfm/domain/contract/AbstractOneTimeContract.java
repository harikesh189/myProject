package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ONE_TIME_CONTRACT")
public abstract class AbstractOneTimeContract extends
		AbstractFinancialContract<ContractInfo> implements OneTimeContract {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6124560797281589010L;

	@Access(AccessType.FIELD)
	@Column(name = "billed_status")
	protected boolean billedStatus;

	public AbstractOneTimeContract(String identity, String externalId) {
		super(identity, externalId);
	}

	public AbstractOneTimeContract() {
		super();
	}

	@Override
	public boolean getBilledStatus() {
		return billedStatus;
	}

	public void setBilledStatus(boolean status) {
		this.billedStatus = status;
	}
}
