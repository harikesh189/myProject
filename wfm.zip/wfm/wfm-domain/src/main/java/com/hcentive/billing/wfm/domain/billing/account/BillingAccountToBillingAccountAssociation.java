package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.wfm.api.enumeration.BillingAccountAssociationType;

@Entity
@DiscriminatorValue("subscription_association")
public class BillingAccountToBillingAccountAssociation extends BillingAccountAssociation {

	private static final long serialVersionUID = -7965166017241437861L;

	@OneToOne(targetEntity = BillingAccount.class)
	@JoinColumn(name = "linked_subscription")
	private BillingAccount linkedSubscription;

	public BillingAccountToBillingAccountAssociation() {
		super();
		this.setAssociationName(BillingAccountAssociationType.NEXT_SUBSCRIPTION);
	}

	public BillingAccount getLinkedSubscription() {
		return this.linkedSubscription;
	}

	public void setLinkedSubscription(final BillingAccount linkedSubscription) {
		this.linkedSubscription = linkedSubscription;
	}

}
