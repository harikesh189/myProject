package com.hcentive.billing.wfm.domain.contract;

import com.hcentive.billing.wfm.domain.Premium;

public abstract class DynamicPremium extends Premium {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7101133673544889945L;

}
