package com.hcentive.billing.wfm.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.Period;

@Entity
@Table(name = "service_period")
public class ServicePeriod extends DomainEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period period;

	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	private ServiceType type;

	public Period getPeriod() {
		return this.period;
	}

	public ServiceType getType() {
		return this.type;
	}

	public void setPeriod(final Period period) {
		this.period = period;
	}

	public void setType(final ServiceType type) {
		this.type = type;
	}

}
