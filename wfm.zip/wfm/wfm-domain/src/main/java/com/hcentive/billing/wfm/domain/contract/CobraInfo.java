package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "cobra_info")
public class CobraInfo extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6776692458388046221L;

	@Access(AccessType.FIELD)
	@Column(name = "qualifying_event")
	private String qualifyingEvent;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "qualifying_date")) })
	@Access(AccessType.FIELD)
	private DateTime qualifyingDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "begin_date")) })
	@Access(AccessType.FIELD)
	private DateTime beginDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "end_date")) })
	@Access(AccessType.FIELD)
	private DateTime endDate;

	public CobraInfo() {
		super();
	}

	public CobraInfo(String cobraQualifyingEvent, DateTime cobraQualifyingDate,
			DateTime cobraBeginDate, DateTime cobraEndDate) {
		super();
		qualifyingEvent = cobraQualifyingEvent;
		qualifyingDate = cobraQualifyingDate;
		beginDate = cobraBeginDate;
		endDate = cobraEndDate;
	}

	public DateTime getBeginDate() {
		return beginDate;
	}

	public DateTime getEndDate() {
		return endDate;
	}

	public DateTime getQualifyingDate() {
		return qualifyingDate;
	}

	public String getQualifyingEvent() {
		return qualifyingEvent;
	}

	// public void setBeginDate(DateTime beginDate) {
	// this.beginDate = beginDate;
	// }
	//
	// public void setEndDate(DateTime endDate) {
	// this.endDate = endDate;
	// }
	//
	// public void setQualifyingDate(DateTime qualifyingDate) {
	// this.qualifyingDate = qualifyingDate;
	// }
	//
	// public void setQualifyingEvent(String qualifyingEvent) {
	// this.qualifyingEvent = qualifyingEvent;
	// }

}
