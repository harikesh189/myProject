package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;


@DiscriminatorValue("Benefit")
@Entity
public class BenefitMemberCoverage extends AbstractMemberCoverageInfo<EligibleMember>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -188000130358726974L;
	
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "benefit_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "benefit_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "benefit_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "benefit_amount_shortName")) })
	private Amount benefitAmount;
	
	protected BenefitMemberCoverage(){
	}

	public BenefitMemberCoverage(InsuredMember<EligibleMember> insuredMember, Period coveragePeriod,
			Amount totalAmount) {
		this.benefitAmount = totalAmount;
		this.insuredMember = insuredMember;
		this.coverage = coveragePeriod;
	}

	public Amount getBenefitAmount() {
		return benefitAmount;
	}

	public void setBenefitAmount(Amount benefitAmount) {
		this.benefitAmount = benefitAmount;
	}

	@Override
	public Period effectivePeriod() {
		return getCoverage();
	}

}
