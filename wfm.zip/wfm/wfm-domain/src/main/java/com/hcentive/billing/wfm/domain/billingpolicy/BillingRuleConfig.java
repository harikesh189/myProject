package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.IFilter;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

/**
 * Parent class off all billing rule configuration.
 * 
 * @author nitin.singla
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_billing_rule_config")
public class BillingRuleConfig extends BillingConfiguration {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	private ConfigType configType;

	// do not delete this constructor. It is used by Json using reflection at
	// the time of save billing policy operation.
	public BillingRuleConfig() {

	}

	/**
	 * Initialize the billing policy configuration,
	 * 
	 * @param type
	 *            The type of billing policy to initialize.
	 */
	public BillingRuleConfig(final ConfigType type) {
		this.configType = type;
		this.period = new Period();
	}

	/**
	 * Gets the type of billing policy configuration.
	 * 
	 * @return The type of billing policy configuration.
	 */
	public ConfigType getConfigType() {
		return this.configType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("\nBillingRuleConfig [configType=");
		builder.append(this.configType);
		builder.append(", active=");
		builder.append(this.active);
		builder.append(", description=");
		builder.append(this.description);
		builder.append(", name=");
		builder.append(this.name);
		builder.append(", period=");
		builder.append(this.period);
		builder.append(", id=");
		builder.append(this.id);
		builder.append(", identity=");
		builder.append(this.identity);
		builder.append(", dateCreated=");
		builder.append(this.dateCreated);
		builder.append(", lastModified=");
		builder.append(this.lastModified);
		builder.append("]\n");
		return builder.toString();
	}

	@Override
	public String type() {
		return configType.getDisplayName();
	}

}

class ActivePolicyRuleConfigFilter implements IFilter<BillingRuleConfig> {
	public static final ActivePolicyRuleConfigFilter INSTANCE = new ActivePolicyRuleConfigFilter();

	@Override
	public boolean apply(final BillingRuleConfig input) {
		return input.isActive();
	}
}
