package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.RefundCriteria;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.RefundDurationType;

/**
 * It represent the configuration related to making a refund. It tells WFM how
 * and when to automatically refund. This rule is used to let the Operator set
 * up automatic refunds if an Entity has a positive balance (money in suspense).
 * Refund will only happen for an entity, if there is no transactions
 * (Billing/payment) happened for an Entity for a defined period in WFM
 * 
 * @author nitin.singla
 */
public class BillingConfigRefund extends BillingRuleConfig {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private RefundCriteria criteria = RefundCriteria.TIME_PERIOD;

	/**
	 * It represent the refund duration.
	 */
	@Min(0)
	@Max(999999)
	private int duration;

	/**
	 * It represent the type of refund duration.
	 */
	private RefundDurationType durationType;

	public BillingConfigRefund() {
		super(ConfigType.REFUND);
	}

	/**
	 * Gets the criteria of refund.
	 * 
	 * @return The criteria of refund.
	 */
	public RefundCriteria getCriteria() {
		return this.criteria;
	}

	/**
	 * Gets the refund duration.
	 * <ul>
	 * <li>If the refund is day based, its possible value is from 1 to 365.</li>
	 * <li>If the refund is month based, its possible value is from 1 to 12.</li>
	 * </ul>
	 * 
	 * @return The refund duration.
	 */
	public int getDuration() {
		return this.duration;
	}

	/**
	 * Getst the type of refund duration.
	 * 
	 * @return The type of refund duration.
	 */
	public RefundDurationType getDurationType() {
		return this.durationType;
	}

	/**
	 * Sets the criteria of refund.
	 * 
	 * @param criteria
	 *            The criteria of refund.
	 */
	public void setCriteria(final RefundCriteria criteria) {
		this.criteria = criteria;
	}

	/**
	 * Sets the refund duration.
	 * <ul>
	 * <li>If the refund is day based, its possible value is from 1 to 365.</li>
	 * <li>If the refund is month based, its possible value is from 1 to 12.</li>
	 * </ul>
	 * 
	 * @param duration
	 *            The refund duration.
	 */
	public void setDuration(final int duration) {
		this.duration = duration;
	}

	/**
	 * Sets the type of refund duration.
	 * 
	 * @param durationType
	 *            The type of refund duration.
	 */
	public void setDurationType(final RefundDurationType durationType) {
		this.durationType = durationType;
	}

}