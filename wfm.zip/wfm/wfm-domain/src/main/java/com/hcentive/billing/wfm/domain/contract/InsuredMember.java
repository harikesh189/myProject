package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Member;

@Entity
@Table(name = "insured_member")
public class InsuredMember<M extends Member> extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne(targetEntity = Member.class, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinColumn(name = "member_id")
	private M member;

	@Column(name = "issuer_member_id")
	private String issuerMemberId;

	@Column(name = "issuer_subscriber_id")
	private String issuerSubscriberId;
	
	@Column(name = "exchange_issuer_group_id")
	private String exchangeIssuerGroupId;
	

	protected InsuredMember() {
	}

	public InsuredMember(M member) {
		this.member = member;
	}

	public InsuredMember(M member, String issuerMemberId) {
		this.member = member;
		this.issuerMemberId = issuerMemberId;
	}

	public M getMember() {
		return member;
	}
	
	public void setMember(M member) {
		this.member = member;
	}

	public String getIssuerMemberId() {
		return issuerMemberId;
	}

	public void setIssuerMemberId(String issuerMemberId) {
		this.issuerMemberId = issuerMemberId;
	}

	public String getIssuerSubscriberId() {
		return issuerSubscriberId;
	}

	public void setIssuerSubscriberId(String issuerSubscriberId) {
		this.issuerSubscriberId = issuerSubscriberId;
	}
	
	public String getExchangeIssuerGroupId() {
		return exchangeIssuerGroupId;
	}
	
	public void setExchangeIssuerGroupId(String exchangeIssuerGroupId) {
		this.exchangeIssuerGroupId = exchangeIssuerGroupId;
	}
}
