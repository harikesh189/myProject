package com.hcentive.billing.wfm.domain.bill.invoice;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.ReferenceAware;
import com.hcentive.billing.core.commons.domain.ReferenceSet;
import com.hcentive.billing.core.commons.domain.Referenceable;
import com.hcentive.billing.wfm.api.FTEntryAware;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.InsuranceCoverageBillAmount;

@Entity
@Table(name = "contract_bill_amount")
public class ContractBillAmount extends BaseEntity implements FTEntryAware, ReferenceAware {

	private static final long serialVersionUID = 8918684888442908384L;

	@Column(name = "contract_id")
	private String contractId;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "contract_bill_amount_amounts",
			joinColumns = @JoinColumn(name = "contract_bill_amount_id"),
			inverseJoinColumns = @JoinColumn(name = "amounts_id"))
	private Set<BillAmount> billAmounts;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "reference_set_id")
	private ReferenceSet referenceSet;

	protected ContractBillAmount() {
	}

	public ContractBillAmount(final String contractId) {
		this.contractId = contractId;
		this.billAmounts = new HashSet<>();
	}

	public String getContractId() {
		return this.contractId;
	}

	public Set<BillAmount> getBillAmounts() {
		return this.billAmounts;
	}

	public void addBillAmount(final BillAmount billAmount) {
		this.billAmounts.add(billAmount);
	}

	@Override
	public Set<String> ftEntryIds() {
		final Set<String> ftEntryIds = new HashSet<>();
		for (final BillAmount billAmt : this.billAmounts) {
			if (billAmt instanceof FTEntryAware) {
				ftEntryIds.addAll(((FTEntryAware) billAmt).ftEntryIds());
			}
		}
		return ftEntryIds;
	}

	public void addReference(final Reference reference) {
		this.getReferenceSet().add(reference);
	}

	@Override
	public Set<? extends Reference> references() {
		return this.getReferenceSet().references();
	}

	@Override
	public <I, T extends Referenceable, V, R extends Reference<I, T, V>> Set<R> referencesByType(final Class<T> type, final Class<I> identityType,
			final Class<V> refValueType) {
		return this.getReferenceSet().referencesByType(type, identityType, refValueType);
	}

	@Override
	public Set<Reference> referencesByTypeName(final String typeName) {
		return this.getReferenceSet().referencesByTypeName(typeName);
	}

	public void addBillAmount(final InsuranceCoverageBillAmount icBillAmt) {
		for (final BillAmount billAmt : icBillAmt.getBillAmounts()) {
			this.addBillAmount(billAmt);
		}
	}

	public ReferenceSet getReferenceSet() {
		return this.referenceSet == null ? (this.referenceSet = new ReferenceSet()) : this.referenceSet;
	}
}
