package com.hcentive.billing.wfm.domain.contract;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.Premium;

@DiscriminatorValue("Eligibility")
@Entity
public class EligibleMemberCoverage extends
		AbstractMemberCoverageInfo<EligibleMember> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3429814135433414143L;

	/**
	 * It represent the total premium of the member.
	 */
	@NotNull
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name = "total_prm")
	@Access(AccessType.FIELD)
	private Premium totalPremium;

	/**
	 * It represent the employer contribution towards total premium. It is valid
	 * only in case of Group eligibility.
	 */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name = "employer_contr_prm")
	@Access(AccessType.FIELD)
	private Premium employerContribution;

	/**
	 * It represent the employee contribution towards total premium. It is valid
	 * only in case of Group eligibility.
	 */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name = "employee_contr_prm")
	@Access(AccessType.FIELD)
	private Premium employeeContribution;

	/**
	 * It represent the individual contribution towards total premium. It is
	 * valid only in case of individual eligibility contract. <br>
	 * Individual Responsibility = Total Premium - Subsidy
	 */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name = "indv_resp_prm")
	@Access(AccessType.FIELD)
	private Premium indvResponsibility;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Access(AccessType.FIELD)
	@JoinTable(name = "member_coverage_info_opt_in_subsidies", joinColumns = @JoinColumn(name = "member_coverage_info_id"), inverseJoinColumns = @JoinColumn(name = "opt_in_subsidies_id"))
	private Set<Subsidy> optInSubsidies = new HashSet<>();

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "cobra_info_id")
	@Access(AccessType.FIELD)
	private CobraInfo cobraInfo;
	
//	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval=true)
//	@Access(AccessType.FIELD)
//	@JoinTable(name = "member_coverage_maintenance_info_set", joinColumns = @JoinColumn(name = "member_coverage_info_id"), inverseJoinColumns = @JoinColumn(name = "maintenance_info_set_id"))
//	private List<MaintenanceInfoSet> maintenanceInfoSet = new LinkedList<MaintenanceInfoSet>();

	public EligibleMemberCoverage(final InsuredMember<EligibleMember> member,
			final Period coverage, final Premium totalPremium) {
		this.insuredMember = member;
		this.coverage = coverage;
		this.totalPremium = totalPremium;
	}

	protected EligibleMemberCoverage() {
	}

	public Set<Subsidy> getOptInSubsidies() {
		return this.optInSubsidies;
	}

	public void setOptInSubsidies(final Set<Subsidy> optInSubsidies) {
		this.optInSubsidies = optInSubsidies;
	}

	public CobraInfo getCobraInfo() {
		return this.cobraInfo;
	}

	public void setCobraInfo(final CobraInfo cobraInfo) {
		this.cobraInfo = cobraInfo;
	}

	public Premium getTotalPremium() {
		return this.totalPremium;
	}

	public void setTotalPremium(final Premium totalPremium) {
		this.totalPremium = totalPremium;
	}

	public Premium getEmployerContribution() {
		return this.employerContribution;
	}

	public void setEmployerContribution(final Premium employerContribution) {
		this.employerContribution = employerContribution;
	}

	public Premium getEmployeeContribution() {
		return this.employeeContribution;
	}

	public void setEmployeeContribution(final Premium employeeContribution) {
		this.employeeContribution = employeeContribution;
	}

	public Premium getIndvResponsibility() {
		return this.indvResponsibility;
	}

	public void setIndvResponsibility(final Premium indvResponsibility) {
		this.indvResponsibility = indvResponsibility;
	}

	@Override
	public Period effectivePeriod() {
		final DateTime termDate = this.insuredMember.getMember()
				.getTerminationDate();

		if (termDate == null || this.coverage.getEndsOn().isBefore(termDate)) {
			return this.coverage;
		} else {
			return new Period(this.coverage.getBeginsOn(), termDate);
		}
	}

	public Collection<Premium> getAllPremiums() {
		final Collection<Premium> premiums = new ArrayList<Premium>(4);
		if (null != this.employeeContribution) {
			premiums.add(this.employeeContribution);
		}
		if (null != this.employerContribution) {
			premiums.add(this.employerContribution);
		}
		if (null != this.indvResponsibility) {
			premiums.add(this.indvResponsibility);
		}
		if (null != this.totalPremium) {
			premiums.add(this.totalPremium);
		}
		return premiums;

	}

}
