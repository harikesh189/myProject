package com.hcentive.billing.wfm.domain.remit;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@Entity
@Table(name = "remit_advice_run")
public class RemitAdviceRun extends
		ReferenceableDomainEntity<RemitAdviceRun, String> {

	private static final long serialVersionUID = -2400906098639364738L;

	@OneToOne
	@JoinColumn(name = "billing_account_id")
	private BillingAccount billingAccount;

	@Enumerated(EnumType.STRING)
	private RunStatus runStatus;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "created_at")) })
	@Access(AccessType.FIELD)
	private DateTime runDate;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period remitPeriod;

	@ManyToOne
	@JoinColumn(name = "remit_advice_cycle_id")
	private RemitAdviceCycle remitAdviceCycle;

	@Access(AccessType.FIELD)
	private String remitAdviceIdentity;

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

	public RemitAdviceCycle getRemitAdviceCycle() {
		return remitAdviceCycle;
	}

	public Period getRemitPeriod() {
		return remitPeriod;
	}

	public DateTime getRunDate() {
		return runDate;
	}

	public RunStatus getRunStatus() {
		return runStatus;
	}

	@Override
	public String refValue() {
		return identity;
	}

	public void setBillingAccount(BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}

	public void setRemitAdviceCycle(RemitAdviceCycle remitAdviceCycle) {
		this.remitAdviceCycle = remitAdviceCycle;
	}

	public void setRemitPeriod(Period runPeriod) {
		remitPeriod = runPeriod;
	}

	public void setRunDate(DateTime runDate) {
		this.runDate = runDate;
	}

	public void setRunStatus(RunStatus runStatus) {
		this.runStatus = runStatus;
	}

	public String getRemitAdviceIdentity() {
		return remitAdviceIdentity;
	}

	public void setRemitAdviceIdentity(String remitAdviceIdentity) {
		this.remitAdviceIdentity = remitAdviceIdentity;
	}

	@Override
	public String typeName() {
		return "RemitAdviceRun";
	}

}
