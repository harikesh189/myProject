package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

public class BillingConfigFlatCharge extends BillingConfigCharge<Amount>
		implements AmountAware {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * A flat dollar Fee amount
	 */
	private Amount amount;

	@Override
	public Amount getAmount() {
		return this.amount;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	@Override
	public Amount value() {
		return this.getAmount();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.core.commons.api.Effectivity#effectivePeriod()
	 */
	@Override
	public Period effectivePeriod() {
		return period;
	}
}
