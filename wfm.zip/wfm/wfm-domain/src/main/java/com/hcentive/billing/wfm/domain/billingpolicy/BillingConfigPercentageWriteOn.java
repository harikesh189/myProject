package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.contract.PercentageAmount;

public class BillingConfigPercentageWriteOn extends
		BillingConfigWriteOn<PercentageAmount> implements PercentageAware {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@Min(0)
	@Max(100)
	private double percentage;

	@NotNull
	@Size(min = 1)
	private String refAmountCode;

	@Override
	public double getPercentage() {
		return this.percentage;
	}

	public String getRefAmountCode() {
		return this.refAmountCode;
	}

	public void setPercentage(final double percentage) {
		this.percentage = percentage;
	}

	public void setRefAmountCode(final String refAmountCode) {
		this.refAmountCode = refAmountCode;
	}

	@Override
	public PercentageAmount value() {
		return new PercentageAmount(this.percentage, this.refAmountCode);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.core.commons.api.Effectivity#effectivePeriod()
	 */
	@Override
	public Period effectivePeriod() {
		return this.period;
	}

}
