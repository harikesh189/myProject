package com.hcentive.billing.wfm.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.wfm.domain.contract.PremiumCode;

@Entity
@Table(name = "premium")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "premium_type")
public abstract class Premium extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4878371936723153780L;

	@Access(AccessType.FIELD)
	@Column(name = "premium_name")
	protected String premiumName;

	@Column(nullable = false, name = "code")
	@Access(AccessType.FIELD)
	@Enumerated(value = EnumType.STRING)
	protected PremiumCode code;

	protected Premium() {
	}

	protected Premium(final PremiumCode code) {
		this.code = code;
	}

	protected Premium(final PremiumCode code, final String premiumName) {
		this(code);
		this.premiumName = premiumName;
	}

	public String getPremiumName() {
		return this.premiumName;
	}

	public void setPremiumName(final String premiumName) {
		this.premiumName = premiumName;
	}

	public PremiumCode getCode() {
		return this.code;
	}
}
