package com.hcentive.billing.wfm.domain.billingpolicy;

import java.io.Serializable;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BillGenerationDateStrategyType;

/**
 * It represent the strategy to be used to calculate the bill generation date.
 * 
 * @author nitin.singla
 * 
 */
public class BillGenerationDateStrategy implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	private BillGenerationDateStrategyType generationDateStrategyType;

	private int marginDays;
	
	@Deprecated
	private DateTime calendarDate;
	
	@Min(0)
	@Max(12)
	private int month;
	
	@Min(0)
	@Max(31)
	private int dayOfMonth;

	private int monthVariance;
	
	public BillGenerationDateStrategy() {
		this(null, 0,null);
	}

	public BillGenerationDateStrategy(
			final BillGenerationDateStrategyType generationDateStrategyType,
			final int marginDays,final DateTime calendarDate) {
		this.generationDateStrategyType = generationDateStrategyType;
		this.marginDays = marginDays;
		this.calendarDate=calendarDate;

	}

	public BillGenerationDateStrategy(
			final BillGenerationDateStrategyType generationDateStrategyType,
			final int marginDays,final DateTime calendarDate, int month, int dayOfMonth, int bufferPeriod) {
		this.generationDateStrategyType = generationDateStrategyType;
		this.marginDays = marginDays;
		this.calendarDate=calendarDate;
		this.month = month;
		this.dayOfMonth = dayOfMonth;
	}
	
	/**
	 * Gets the type of strategy to use to calculate the bill generation date.
	 * 
	 * @return The type of strategy to use to calculate the bill generation
	 *         date.
	 */
	public BillGenerationDateStrategyType getGenerationDateStrategyType() {
		return this.generationDateStrategyType;
	}

	/**
	 * Gets the offset value in terms of number of days to calculate the billing
	 * generation date.
	 * 
	 * @return The offset value in terms of number of days to calculate the
	 *         billing generation date.
	 */
	public int getMarginDays() {
		return this.marginDays;
	}

	/**
	 * Sets the type of strategy to use to calculate the bill generation date.
	 * 
	 * @param generationDateStrategyType
	 *            The type of strategy to use to calculate the bill generation
	 *            date.
	 */
	public void setGenerationDateStrategyType(
			final BillGenerationDateStrategyType generationDateStrategyType) {
		this.generationDateStrategyType = generationDateStrategyType;
	}

	/**
	 * Sets the offset value in terms of number of days to calculate the billing
	 * generation date.
	 * 
	 * @param marginDays
	 *            The offset value in terms of number of days to set to
	 *            calculate the billing generation date.
	 */
	public void setMarginDays(final int marginDays) {
		this.marginDays = marginDays;
	}
	
	public DateTime getCalendarDate() {
		return calendarDate;
	}
	
	public void setCalendarDate(DateTime calendarDate) {
		this.calendarDate = calendarDate;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getDayOfMonth() {
		return dayOfMonth;
	}

	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}

	public int getMonthVariant() {
		return monthVariance;
	}

	public void setMonthVariant(int monthVariant) {
		this.monthVariance = monthVariant;
	}
	
}
