package com.hcentive.billing.wfm.domain.payment;

import java.io.Serializable;

public abstract class AmountRemovalDetail implements Serializable {

	private static final long serialVersionUID = 1653050574626609838L;

	public static enum RemovalReason {
		PAYMENT_FAILURE, PAYMENT_REFUND, PAYMENT_CANCELLATION,MONEYTRANSFER_VOID
	}
	
	protected RemovalReason reason;
	
	private String businessEntityIdentity;
	
	private String billingAccountIdentity;
	
	// used in case, when payment of inactive subscription is failed and failure needs to be apply on primary subscription.
	// in that case, oldBillingAccountIdentity will have inactive subscription and billingAccountIdentity will have primary subscription.
	private String oldBillingAccountIdentity;
	
	protected AmountRemovalDetail() {
		// for ORMs
	}
	
	public AmountRemovalDetail(RemovalReason reason) {
		this.reason = reason;
	}

	public RemovalReason getReason() {
		return reason;
	}

	public void setReason(RemovalReason reason) {
		this.reason = reason;
	}

	public String getBillingAccountIdentity() {
		return billingAccountIdentity;
	}

	public void setBillingAccountIdentity(String billingAccountIdentity) {
		this.billingAccountIdentity = billingAccountIdentity;
	}

	public String getOldBillingAccountIdentity() {
		return oldBillingAccountIdentity;
	}

	public void setOldBillingAccountIdentity(String oldBillingAccountIdentity) {
		this.oldBillingAccountIdentity = oldBillingAccountIdentity;
	}

	public String getBusinessEntityIdentity() {
		return businessEntityIdentity;
	}

	public void setBusinessEntityIdentity(String businessEntityIdentity) {
		this.businessEntityIdentity = businessEntityIdentity;
	}
	
}
