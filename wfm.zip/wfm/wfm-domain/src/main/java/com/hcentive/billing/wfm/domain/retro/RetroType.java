/**
 * 
 */
package com.hcentive.billing.wfm.domain.retro;

/**
 * Enum for retro types/cases
 * 
 * @author Kumar Sambhav Jain
 * 
 */
public enum RetroType {
	/**
	 * Only eligibility got changed in retro period. For example - a new
	 * beneficiary is added.
	 */
	ELIGIBILITY_RETRO,
	/**
	 * Only billing policy / rules got changed in retro period. For example -
	 * new tax rates or premium update for a age group.
	 */

	BILLING_POLICY_RETRO,
	/**
	 * When both eligibility and billing policy got changed in retro period.
	 */
	ELIGIBILITY_AND_POLICY_RETRO,
	
	/**
	 * Treating adjustment of 3ppr as a retro. 
	 */
	THIRD_PARTY_PAYMENT_PREMIUM_ADJUSTMENT
}
