package com.hcentive.billing.wfm.domain.bill.doc;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;
import com.hcentive.billing.core.commons.xsdtopojo.Invoice;
import com.hcentive.billing.wfm.api.BillRunType;

@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_wfm_invoice")
public class WFMInvoiceDocument extends AbstractMongoEntity {

	private static final long serialVersionUID = 1L;

	private Invoice invoicePojo;
	
	private BillRunType invoiceType = BillRunType.REGULAR;
	
	public BillRunType getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(BillRunType invoiceType) {
		this.invoiceType = invoiceType;
	}

	protected WFMInvoiceDocument() { }
	
	public WFMInvoiceDocument(String identity, Invoice invoice,BillRunType invoiceType) {
		this.identity = identity;
		this.invoicePojo = invoice;
		this.invoiceType = invoiceType;
	}

	public Invoice getInvoicePojo() {
		return invoicePojo;
	}

	public void setInvoicePojo(Invoice invoicePojo) {
		this.invoicePojo = invoicePojo;
	}
	
}

