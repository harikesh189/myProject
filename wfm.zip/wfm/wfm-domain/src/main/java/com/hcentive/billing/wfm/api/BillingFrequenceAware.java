package com.hcentive.billing.wfm.api;

public interface BillingFrequenceAware {

}
