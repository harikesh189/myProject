package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.FinancialEventContext;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;
import com.hcentive.billing.wfm.domain.schedule.cycle.RunSegment.RunType;

@Entity
@Table(name = "billing_contract_run")
@SuppressWarnings("rawtypes")
public class BillingContractRun extends ReferenceableDomainEntity<BillingContractRun, String> implements FinancialEventContext {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "billing_account_run_cycle_id")
	private BillingAccountRunCycle billingAccountRunCycle;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "billingContractRun", fetch = FetchType.EAGER, orphanRemoval = true)
	private final Set<BillRunContext> billRunContexts;

	@Enumerated(EnumType.STRING)
	@Column(name = "bill_run_status")
	private RunStatus billRunStatus;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "contract_id")
	private AbstractFinancialContract contract;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "associated_billing_account_id")
	private BillingAccount associatedBillingAccount;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "run_date")) })
	@Access(AccessType.FIELD)
	private DateTime runDate;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "run_type")
	private RunType runType;

	public BillingContractRun() {
		this(null, null, null, null,null);
	}

	public BillingContractRun(final BillingAccountRunCycle billingAccountRunCycle, 
			final RunStatus billRunStatus, final AbstractFinancialContract contract, RunType runType,final BillingAccount associatedBillingAccount) {
		super();
		this.billingAccountRunCycle = billingAccountRunCycle;
		this.billRunStatus = billRunStatus;
		this.contract = contract;
		this.runType = runType;
		this.billRunContexts = new HashSet<BillRunContext>();
		this.associatedBillingAccount = associatedBillingAccount;
	}

	public BillingAccountRunCycle getBillingAccountRunCycle() {
		return this.billingAccountRunCycle;
	}

	public void setBillingAccountRunCycle(final BillingAccountRunCycle billingAccountRunCycle) {
		this.billingAccountRunCycle = billingAccountRunCycle;
	}

	public RunStatus getBillRunStatus() {
		return this.billRunStatus;
	}

	public AbstractFinancialContract getContract() {
		return this.contract;
	}

	public DateTime getRunDate() {
		return this.runDate;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setBillRunStatus(final RunStatus billRunStatus) {
		this.billRunStatus = billRunStatus;
	}

	public void setContract(final AbstractFinancialContract contract) {
		this.contract = contract;
	}

	public void setRunDate(final DateTime runDate) {
		this.runDate = runDate;
	}

	@Override
	public String typeName() {
		return "BillingContractRun";
	}

	/**
	 * @return
	 */
	public BillRunContext getCurrentBillRunContext() {
		final Period currentBillingPeriod = this.billingAccountRunCycle.getBillingRunCycle().getBillingPeriod();
		for (final BillRunContext ctx : this.billRunContexts) {
			if (!ctx.isRetro() && ctx.getCoveragePeriod().equals(currentBillingPeriod)) {
				return ctx;
			}
		}
		return null;
	}

	@JsonIgnore
	public Set<BillRunContext> getBillRunContexts() {
		return this.billRunContexts;
	}

	/**
	 * @param runContext
	 */
	public void addBillRunContext(final BillRunContext runContext) {
		runContext.setBillingContractRun(this);
		this.billRunContexts.add(runContext);
	}

	/**
	 * @return
	 */
	public boolean hasRetro() {
		for (final BillRunContext ctx : this.billRunContexts) {
			if (ctx.isRetro()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return
	 */
	public Set<BillRunContext> getRetroContexts() {
		final Set<BillRunContext> retroCtxs = new HashSet<BillRunContext>();
		for (final BillRunContext ctx : this.billRunContexts) {
			if (ctx.isRetro()) {
				retroCtxs.add(ctx);
			}
		}
		return retroCtxs;
	}

	public RunType getRunType() {
		return runType;
	}

	public void setRunType(RunType runType) {
		this.runType = runType;
	}

	public BillingAccount getAssociatedBillingAccount() {
		return associatedBillingAccount;
	}

	public void setAssociatedBillingAccount(BillingAccount associatedBillingAccount) {
		this.associatedBillingAccount = associatedBillingAccount;
	}

}
