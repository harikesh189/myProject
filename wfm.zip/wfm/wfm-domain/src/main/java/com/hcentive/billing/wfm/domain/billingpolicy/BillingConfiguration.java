/**
 * 
 */
package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.VersionableEntity;
import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;

/**
 * Abstract parent class for all mongo managed billing configuration rule and
 * policy.
 * 
 * @author Kumar Sambhav Jain
 */
public abstract class BillingConfiguration extends AbstractMongoEntity implements VersionableEntity {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	//@JsonIgnore
	protected boolean active = true;

	//@JsonIgnore
	private boolean billRunExecuted;

	@NotNull
	@Size(min = 1)
	protected String description;

	@NotNull
	@Size(min = 1)
	protected String name;

	@NotNull
	protected Period period;

	/**
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * @return the period
	 */
	public Period getPeriod() {
		return this.period;
	}

	/**
	 * @return the active
	 */
	public boolean isActive() {
		return this.active;
	}

	/**
	 * @return the billRunExecuted
	 */
	public boolean isBillRunExecuted() {
		return this.billRunExecuted;
	}

	/**
	 * @param active
	 *            the active to set
	 */
	public void setActive(final boolean active) {
		this.active = active;
	}

	/**
	 * @param billRunExecuted
	 *            the billRunExecuted to set
	 */
	public void setBillRunExecuted(final boolean billRunExecuted) {
		this.billRunExecuted = billRunExecuted;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(final String description) {
		this.description = description;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(final String name) {
		this.name = name;
	}

	/**
	 * @param period
	 *            the period to set
	 */
	public void setPeriod(final Period period) {
		this.period = period;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("BillingConfiguration [id=");
		builder.append(this.id);
		builder.append(", active=");
		builder.append(this.active);
		builder.append(", description=");
		builder.append(this.description);
		builder.append(", name=");
		builder.append(this.name);
		builder.append(", identity=");
		builder.append(this.identity);
		builder.append(", period=");
		builder.append(this.period);
		builder.append(", billRunExecuted=");
		builder.append(this.billRunExecuted);
		builder.append("]");
		return builder.toString();
	}

	public abstract String type(); 
	
}
