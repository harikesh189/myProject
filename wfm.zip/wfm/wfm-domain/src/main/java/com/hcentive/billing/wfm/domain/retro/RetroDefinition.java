/**
 * 
 */
package com.hcentive.billing.wfm.domain.retro;

import com.hcentive.billing.core.commons.domain.Period;

/**
 * Model class for information related to an identified retro billing period.
 * 
 * @author Kumar Sambhav Jain
 * 
 */
public class RetroDefinition {

	/**
	 * {@link RetroType} identified.
	 */
	private RetroType retroType;

	/**
	 * {@link Period} identified.
	 */
	private Period retroPeriod;

	/**
	 * Default constructor. Does nothing.
	 */
	public RetroDefinition() {

	}

	/**
	 * Parameterized constructor.
	 * 
	 * @param retroType
	 * @param retroPeriod
	 */
	public RetroDefinition(RetroType retroType, Period retroPeriod) {
		super();
		this.retroType = retroType;
		this.retroPeriod = retroPeriod;
	}

	/**
	 * @return the retroType
	 */
	public RetroType getRetroType() {
		return retroType;
	}

	/**
	 * @param retroType
	 *            the retroType to set
	 */
	public void setRetroType(RetroType retroType) {
		this.retroType = retroType;
	}

	/**
	 * @return the retroPeriod
	 */
	public Period getRetroPeriod() {
		return retroPeriod;
	}

	/**
	 * @param retroPeriod
	 *            the retroPeriod to set
	 */
	public void setRetroPeriod(Period retroPeriod) {
		this.retroPeriod = retroPeriod;
	}

}
