package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * It defines how to define the billing period. 
 * Made a generic enum to deal with all the period which requires 
 * days mentioned in DAYS or MONTHS
 * 
 * @author manish.bothiyal
 * 
 */
public enum BillingRulePeriodType {
	/**
	 * It represent that billing period is defined in terms of days.
	 */
	DAYS,

	/**
	 * It represent that billing period is defined in terms of months.
	 */
	MONTHS
}