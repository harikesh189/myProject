package com.hcentive.billing.wfm.domain.bill;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class BillArtifactSummary extends BaseEntity {

	private static final long serialVersionUID = 7248401776740684004L;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "generation_date")) })
	private DateTime generationDate;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "billing_begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "billing_ends_on")) })
	private Period billPeriod;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "generated_for_id")
	private BillingAccount generatedFor;

	@Column(name = "bill_number")
	private String billNumber;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "current_bill_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "current_bill_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "current_bill_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "current_bill_amount_short_name")) })
	private Amount currentBillAmount;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "net_due_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "net_due_amount_short_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "net_due_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "net_due_amount_name")) })
	private Amount netDueAmount;

	public DateTime getGenerationDate() {
		return this.generationDate;
	}

	public void setGenerationDate(final DateTime generationDate) {
		this.generationDate = generationDate;
	}

	public Period getBillPeriod() {
		return this.billPeriod;
	}

	public void setBillPeriod(final Period billPeriod) {
		this.billPeriod = billPeriod;
	}

	public BillingAccount getGeneratedFor() {
		return this.generatedFor;
	}

	public void setGeneratedFor(final BillingAccount generatedFor) {
		this.generatedFor = generatedFor;
	}

	public String getBillNumber() {
		return this.billNumber;
	}

	public void setBillNumber(final String billNumber) {
		this.billNumber = billNumber;
	}

	public Amount getCurrentBillAmount() {
		return this.currentBillAmount;
	}

	public void setCurrentBillAmount(final Amount currentBillAmount) {
		this.currentBillAmount = currentBillAmount;
	}

	public Amount getNetDueAmount() {
		return this.netDueAmount;
	}

	public void setNetDueAmount(final Amount netDueAmount) {
		this.netDueAmount = netDueAmount;
	}

}
