package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;
import com.hcentive.billing.core.commons.vo.DateTime;

// Represents a unit of update
// Should contain all the updates coming in a single eligibility update
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_contract_maintenance_update")
public class ContractMaintenanceUpdate extends AbstractMongoEntity {

	private static final long serialVersionUID = 1L;

	@Field
	private final List<MaintenanceInfo> maintenanceUpdates;

	private DateTime updateDate;

	@NotNull
	private String enrollmentId;

	public ContractMaintenanceUpdate() {
		this.maintenanceUpdates = new LinkedList<>();
	}

	public void addAllUpdates(Collection<MaintenanceInfo> maintInfos) {
		for (MaintenanceInfo maintInfo : maintInfos) {
			populateMaintenanceDescription(maintInfo);
		}
		getMaintenanceUpdates().addAll(maintInfos);
	}

	public void addUpdate(MaintenanceInfo maintInfo) {
		populateMaintenanceDescription(maintInfo);
		getMaintenanceUpdates().add(maintInfo);
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}

	public List<MaintenanceInfo> getMaintenanceUpdates() {
		return maintenanceUpdates;
	}

	public DateTime getUpdateDate() {
		return updateDate;
	}

	public boolean hasUpdates() {
		return !getMaintenanceUpdates().isEmpty();
	}

	public void setEnrollmentId(String contractId) {
		this.enrollmentId = contractId;
	}

	public void setUpdateDate(DateTime updateDate) {
		this.updateDate = updateDate;
	}
	
	public void populateMaintenanceDescription(MaintenanceInfo update) {
		if (update != null) {
			update.setDescription(update.constructDescription());
		}
	}
}
