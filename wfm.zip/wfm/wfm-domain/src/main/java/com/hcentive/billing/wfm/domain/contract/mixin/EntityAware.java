package com.hcentive.billing.wfm.domain.contract.mixin;

import java.util.Collection;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Profile;

public interface EntityAware {
	Collection<BusinessEntity<Profile>> getEntities();

	Collection<String> getEntitieTypes();
}
