/**
 * 
 */
package com.hcentive.billing.wfm.api;


/**
 * @author Dikshit.Vaid
 * 
 */
public interface MemberAwareFinancialTerm<V> extends FinancialTerm<V> {

	Long getInsuredMemberId();

}
