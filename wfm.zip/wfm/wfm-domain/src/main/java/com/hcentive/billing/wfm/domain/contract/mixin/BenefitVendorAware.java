package com.hcentive.billing.wfm.domain.contract.mixin;

import java.util.Collection;

import com.hcentive.billing.core.commons.domain.BenefitVendor;

public interface BenefitVendorAware {
	
	Collection<BenefitVendor> getBenefitVendors();
	
	Collection<String> getBenefitProducts();

}
