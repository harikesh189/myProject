package com.hcentive.billing.wfm.domain.manualadjustment;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;



@Entity
@Table(name = "manual_adj_add_info")
public class ManualAdjustmentAdditionalInfo extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5375164435823649632L;

	private String key;

	private String value;

	private String qualifier;

	private String description;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		
		if (this == obj)
			return true;
		/*
		 * if (!super.equals(obj)) Ajay -- No need to check super return false;
		 */
		/*if (!super.equals(obj))
			return false;*/
		if (getClass() != obj.getClass())
			return false;
		ManualAdjustmentAdditionalInfo other = (ManualAdjustmentAdditionalInfo) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		return true;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getQualifier() {
		return qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
