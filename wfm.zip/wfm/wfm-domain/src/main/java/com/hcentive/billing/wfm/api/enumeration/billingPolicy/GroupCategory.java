package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum GroupCategory {
	LARGE, MEDIUM, SMALL;

}
