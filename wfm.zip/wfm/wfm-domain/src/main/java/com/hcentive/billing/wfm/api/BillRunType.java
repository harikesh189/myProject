package com.hcentive.billing.wfm.api;

public enum BillRunType {
	REGULAR, BINDER, REINSTATEMENT, RUNOUT
}
