package com.hcentive.billing.wfm.domain.contract;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "eligibility_factor")
@DiscriminatorValue("Disability")
public class DisabilityFactor extends EligibilityFactor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -76829509923020109L;

	@Access(AccessType.FIELD)
	@Column(name = "is_disabled")
	private boolean isDisabled;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = Disability.class)
	@Access(AccessType.FIELD)
	@JoinTable(name = "eligibility_factor_disabilities", joinColumns = @JoinColumn(name = "eligibility_factor_id"), inverseJoinColumns = @JoinColumn(name = "disabilities_id"))
	private Set<Disability> disabilities = new HashSet<Disability>();

	public boolean isDisabled() {
		return isDisabled;
	}

	public void setDisabled(boolean isDisabled) {
		this.isDisabled = isDisabled;
	}

	public Set<Disability> getDisabilities() {
		return disabilities;
	}

	public void setDisabilities(Set<Disability> disabilities) {
		this.disabilities = disabilities;
	}

}
