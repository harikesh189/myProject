package com.hcentive.billing.wfm.api.enumeration;

public enum BillingAccountAssociationType {
	CONTRACT_ASSOCIATION, NEXT_SUBSCRIPTION
}
