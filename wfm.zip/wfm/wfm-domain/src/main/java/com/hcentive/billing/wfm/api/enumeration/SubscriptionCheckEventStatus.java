package com.hcentive.billing.wfm.api.enumeration;

public enum SubscriptionCheckEventStatus {
	PENDING, COMPLETED, CANCELLED;
}
