package com.hcentive.billing.wfm.domain.writeon;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Transient;

import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigPercentageWriteOn;

@Entity
@DiscriminatorValue("Invoice_Percentage_Write_On_Rule")
public class EntityBillingPercentageWriteOnRule extends AbstractBillingWriteOnRule {

	private static final long serialVersionUID = 1L;

	@Column(name = "percentage_write_on_charge_id")
	private String percentageWriteOnChargeId;
	
	@Transient
	private BillingConfigPercentageWriteOn percentageWriteOnFTCharge;
	
	public EntityBillingPercentageWriteOnRule() {

	}

	public EntityBillingPercentageWriteOnRule(final String businessEntityIdentity, final String writeOnFtRuleId, 
			final String percentageWriteOnChargeId) {
		super(businessEntityIdentity, writeOnFtRuleId);
		this.percentageWriteOnChargeId = percentageWriteOnChargeId;
	}


	public String getPercentageWriteOnChargeId() {
		return percentageWriteOnChargeId;
	}

	public void setPercentageWriteOnChargeId(String percentageWriteOnChargeId) {
		this.percentageWriteOnChargeId = percentageWriteOnChargeId;
	}

	public BillingConfigPercentageWriteOn getPercentageWriteOnFTCharge() {
		return percentageWriteOnFTCharge;
	}

	public void setPercentageWriteOnFTCharge(BillingConfigPercentageWriteOn percentageWriteOnFTCharge) {
		this.percentageWriteOnFTCharge = percentageWriteOnFTCharge;
	}

	@Override
	public String toString() {
		return "EntityBillingPercentageWriteOnRule [percentageWriteOnChargeId=" + percentageWriteOnChargeId + ", percentageWriteOnFTCharge="
				+ percentageWriteOnFTCharge + ", getBusinessEntityIdentity()=" + getBusinessEntityIdentity() + ", getWriteOnFtRuleId()=" + getWriteOnFtRuleId()
				+ ", getWriteOnFTRule()=" + getWriteOnFTRule() + ", getIdentity()=" + getIdentity() + "]";
	}

}
