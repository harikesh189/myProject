package com.hcentive.billing.wfm.dto;

public class InvoiceReversalResult {

	private String invoiceIdentity;
	
	private String billingAccountIdentity;
	
	private boolean regenerateRequired;
	
	private boolean rebillRequired;

	public String getInvoiceIdentity() {
		return invoiceIdentity;
	}

	public void setInvoiceIdentity(String invoiceIdentity) {
		this.invoiceIdentity = invoiceIdentity;
	}

	public String getBillingAccountIdentity() {
		return billingAccountIdentity;
	}

	public void setBillingAccountIdentity(String billingAccountIdentity) {
		this.billingAccountIdentity = billingAccountIdentity;
	}

	public boolean isRegenerateRequired() {
		return regenerateRequired;
	}

	public void setRegenerateRequired(boolean regenerateRequired) {
		this.regenerateRequired = regenerateRequired;
	}

	public boolean isRebillRequired() {
		return rebillRequired;
	}

	public void setRebillRequired(boolean rebillRequired) {
		this.rebillRequired = rebillRequired;
	}
	
}
