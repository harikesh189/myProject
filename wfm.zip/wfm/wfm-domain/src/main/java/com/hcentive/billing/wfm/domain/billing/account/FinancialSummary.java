package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "financial_summary")
public class FinancialSummary extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "auto_recurring")
	private boolean autoRecurring;

	@Column(name = "identity")
	private String identity;

	@ManyToOne(optional = false)
	@JoinColumn(name = "billing_account_id", nullable = false)
	private BillingAccount billingAccount;

	@Transient
	private Amount currentBalance;

	@Column(name = "deliquent")
	private boolean deliquent;

	@Column(name = "last_invoice")
	private String lastInvoiceIdentity;
	
	@Column(name = "last_invoice_external_id")
	private String lastInvoiceExternalId;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "last_paid_invoice_date")) })
	private DateTime lastPaidInvoiceDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "last_payment_date")) })
	private DateTime lastPaymentDate;

	@Column(name = "last_payment")
	private String lastPaymentIdentity;
	
	@Column(name = "last_payment_external_id")
	private String lastPaymentExternalId;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "delinquency_exception_begins_on", nullable = false)),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "delinquency_exception_ends_on", nullable = false)) })
	@Access(AccessType.FIELD)
	private Period delinquencyExceptionPeriod;

	public FinancialSummary() {

	}

	public FinancialSummary(String identity) {
		this.identity = identity;
	}

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

	public Amount getCurrentBalance() {
		return currentBalance;
	}

	public String getLastInvoiceIdentity() {
		return lastInvoiceIdentity;
	}

	public DateTime getLastPaymentDate() {
		return lastPaymentDate;
	}

	public String getLastPaymentIdentity() {
		return lastPaymentIdentity;
	}

	public boolean isAutoRecurring() {
		return autoRecurring;
	}

	public boolean isDeliquent() {
		return deliquent;
	}
	
	public boolean getDeliquent() {
		return deliquent;
	}

	public void setAutoRecurring(boolean autoRecurring) {
		this.autoRecurring = autoRecurring;
	}

	public void setBillingAccount(BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}

	public void setCurrentBalance(Amount currentBalance) {
		this.currentBalance = currentBalance;
	}

	public void setDeliquent(boolean deliquent) {
		this.deliquent = deliquent;
	}

	public void setLastInvoiceIdentity(String lastInvoiceIdentity) {
		this.lastInvoiceIdentity = lastInvoiceIdentity;
	}

	public void setLastPaymentDate(DateTime lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	public void setLastPaymentIdentity(String lastPaymentIdentity) {
		this.lastPaymentIdentity = lastPaymentIdentity;
	}

	public String getLastInvoiceExternalId() {
		return lastInvoiceExternalId;
	}

	public void setLastInvoiceExternalId(String lastInvoiceExternalId) {
		this.lastInvoiceExternalId = lastInvoiceExternalId;
	}

	public String getLastPaymentExternalId() {
		return lastPaymentExternalId;
	}

	public void setLastPaymentExternalId(String lastPaymentExternalId) {
		this.lastPaymentExternalId = lastPaymentExternalId;
	}

	public String getIdentity() {
		return identity;
	}

	public Period getDelinquencyExceptionPeriod() {
		return delinquencyExceptionPeriod;
	}

	public void setDelinquencyExceptionPeriod(Period delinquencyExceptionPeriod) {
		this.delinquencyExceptionPeriod = delinquencyExceptionPeriod;
	}

	public DateTime getLastPaidInvoiceDate() {
		return lastPaidInvoiceDate;
	}

	public void setLastPaidInvoiceDate(DateTime lastPaidInvoiceDate) {
		this.lastPaidInvoiceDate = lastPaidInvoiceDate;
	}
}
