package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

import static com.hcentive.billing.core.commons.util.CollectionUtil.asList;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.util.ITransformer;

public enum ConfigType {
	BILLING_CYCLE("Bill Schedule"), OTHER_CHARGE("Charge"), DISCOUNT("Discount"), FEE("Fee"), FT("Financial Transaction"), PRO_RATE_BILLING("Prorate Billing"), 
	REFUND("Refund"), REMITTANCE("Remittance"), RETRO_BILLING("Retro Billing"), TAX("Tax"), WRITE_ON("Write-On"), TOLERANCE("Tolerance"), 
	REINSTATEMENT("Reinstatement"), INVOICE_REVIEW("Invoice Review"), DELINQUENCY_RULE("Delinquency"), RUN_OUT("Run Out");

	public static ConfigType[] POLICY_CONFIGY_TYPES = new ConfigType[] {
			PRO_RATE_BILLING, RETRO_BILLING,TOLERANCE,RUN_OUT };

	public static ConfigType[] FINANCIAL_CHARGES = new ConfigType[] { FEE, TAX,
			OTHER_CHARGE, DISCOUNT, WRITE_ON };

	public static ConfigType[] NON_FINANCIAL_CHARGES = new ConfigType[] {
			BILLING_CYCLE, PRO_RATE_BILLING, REMITTANCE, RETRO_BILLING,TOLERANCE,REINSTATEMENT,DELINQUENCY_RULE,RUN_OUT };

	public static final ValueTransformer<ConfigType> TRANSFORMER = new ValueTransformer<>();

	private final String displayName;
	
	private ConfigType(String displayName) {
		this.displayName = displayName;
	}
	
	public String getDisplayName() {
		return displayName;
	}

	public boolean in(final ConfigType... types) {
		return CollectionUtil.in(this, types);
	}

	private static Collection<String> getAllConfigTypes() {
		return asList(TRANSFORMER, values());
	}

	private static final class ValueTransformer<T extends Enum<T>> implements
			ITransformer<Enum<T>, String> {
		@Override
		public String transform(final Enum<T> input) {
			return input.toString();
		}
	}

	public static List<String> getTypeList(final String ruleType) {

		final List<String> typeList = new LinkedList<String>();

		if (ruleType.equals(ConfigType.BILLING_CYCLE.name())) {
			typeList.add(ConfigType.BILLING_CYCLE.toString());// BILL SCHEDULE
		} else if (ruleType.equals(ConfigType.FT.name())) {
			typeList.add(ConfigType.FT.toString());// FINANCIALS
		} else if (ruleType.equals(ConfigType.REMITTANCE.name())) {
			typeList.add(ConfigType.REMITTANCE.toString());// REMIT
		} else if (ruleType.equals("POLICY_CONFIGY_TYPES")) {// BILLING
			typeList.addAll(asList(TRANSFORMER, POLICY_CONFIGY_TYPES));
		} else if (ruleType.equals("NON_FINANCIAL_CHARGES")) {// ALL
			typeList.addAll(asList(TRANSFORMER, NON_FINANCIAL_CHARGES));
		} else if (ruleType.equals("FINANCIAL_CHARGES")) {
			typeList.addAll(asList(TRANSFORMER, FINANCIAL_CHARGES));
		} else if (ruleType.equals(ConfigType.REINSTATEMENT.name())) {
			typeList.add(ConfigType.REINSTATEMENT.toString());// REINSTATEMENT
		} else if (ruleType.equals(ConfigType.INVOICE_REVIEW.name())) {
			typeList.add(ConfigType.INVOICE_REVIEW.toString());// REINSTATEMENT
		} else if (ruleType.equals(ConfigType.DELINQUENCY_RULE.name())) {
			typeList.add(ConfigType.DELINQUENCY_RULE.toString());// Delinquency
		} else if (ruleType.equals(ConfigType.RUN_OUT.name())) {
			typeList.add(ConfigType.RUN_OUT.toString());// Delinquency
		}

		return typeList;
	}
}