/**
 *
 */
package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.DocumentEntity;
import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingPolicy;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;

@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_bill_run_data")
@SuppressWarnings("rawtypes")
public class BillRunData extends AbstractMongoEntity implements DocumentEntity, Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5084553913259532929L;

	private final AbstractFinancialContract contract;
	private final BillingPolicy contractBillingPolicy;

	// BillRunContext gets transferred to FT which does not have
	// Financial Term implementation classes in its classpath
	// need to revisit this
	private final transient Set<FinancialTerm<?>> financialTerms;

	/**
	 * Default Constructor
	 */
	public BillRunData() {
		this(null, null);
	}

	public BillRunData(final AbstractFinancialContract contract,
			final BillingPolicy contractBillingPolicy) {
		this.identity = RandomGenerator.randomString();
		this.contract = contract;
		this.contractBillingPolicy = contractBillingPolicy;
		this.financialTerms = Collections.synchronizedSet(new HashSet<FinancialTerm<?>>());
	}

	public AbstractFinancialContract getContract() {
		return this.contract;
	}

	public BillingPolicy getContractBillingPolicy() {
		return this.contractBillingPolicy;
	}

	/**
	 * @return the id
	 */
	@Override
	public String getId() {
		return this.id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	@Override
	public void setId(final String id) {
		this.id = id;
	}

	public void addFinancialTerms(Collection<FinancialTerm<?>> finTerms) {
		financialTerms.addAll(CollectionUtil.nullSafe(finTerms));
	}

	public void addFinancialTerm(FinancialTerm<?> finTerm) {
		financialTerms.add(finTerm);
	}

	public Collection<FinancialTerm<?>> financialTerms() {
		return Collections.unmodifiableCollection(financialTerms);
	}

}