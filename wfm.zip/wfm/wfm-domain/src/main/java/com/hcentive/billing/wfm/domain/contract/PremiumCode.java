package com.hcentive.billing.wfm.domain.contract;

public enum PremiumCode {
	
	EMPLOYER_RESP("Employer Responsibility"), EMPLOYEE_RESP("Employee Responsibility"), 
	INDV_RESP("Individual Responsibility"), TOTAL_PREMIUM("Total Premium");
	
	private String displayName;
	
	private PremiumCode(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}
}
