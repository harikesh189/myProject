package com.hcentive.billing.wfm.api.enumeration.ft;

public enum FinancialEventQualifier {

	RETRO, VOID, CANCEL, RERUN, DEFAULT;

}
