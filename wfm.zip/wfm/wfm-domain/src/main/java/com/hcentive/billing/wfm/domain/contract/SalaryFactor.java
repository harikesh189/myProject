package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.Amount;

@Entity
@Table(name = "eligibility_factor")
@DiscriminatorValue("Salary")
public class SalaryFactor extends EligibilityFactor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4308800610469989031L;

	@Access(AccessType.FIELD)
	@Column(name = "salary_type")
	@Enumerated(EnumType.STRING)
	private SalaryType salaryType; // North America Industry Class

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "salary_value")),
			@AttributeOverride(name = "name", column = @Column(name = "salary_currency_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "salary_currency_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "salary_currency_short_name")) })
	@Access(AccessType.FIELD)
	private Amount salaryAmount; // standard industry class

	public SalaryType getSalaryType() {
		return salaryType;
	}

	public void setSalaryType(SalaryType salaryType) {
		this.salaryType = salaryType;
	}

	public Amount getSalaryAmount() {
		return salaryAmount;
	}

	public void setSalaryAmount(Amount salaryAmount) {
		this.salaryAmount = salaryAmount;
	}

}
