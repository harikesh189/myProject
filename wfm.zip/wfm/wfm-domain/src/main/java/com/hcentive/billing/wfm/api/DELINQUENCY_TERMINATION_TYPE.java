package com.hcentive.billing.wfm.api;

public enum DELINQUENCY_TERMINATION_TYPE {
	GRACE_DAY, LAST_DAY_OF_COVG
}
