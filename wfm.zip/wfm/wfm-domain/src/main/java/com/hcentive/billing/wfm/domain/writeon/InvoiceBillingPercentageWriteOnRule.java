package com.hcentive.billing.wfm.domain.writeon;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Transient;

import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigPercentageWriteOn;

@Entity
@DiscriminatorValue("Invoice_Percentage_Write_On_Rule")
public class InvoiceBillingPercentageWriteOnRule extends AbstractBillingWriteOnRule {

	private static final long serialVersionUID = 1L;

	@Column(name = "invoice_identity")
	private String invoiceIdentity;

	@Column(name = "percentage_write_on_charge_id")
	private String percentageWriteOnChargeId;
	
	@Transient
	private BillingConfigPercentageWriteOn percentageWriteOnFTCharge;
	
	public InvoiceBillingPercentageWriteOnRule() {

	}

	public InvoiceBillingPercentageWriteOnRule(final String businessEntityIdentity, final String writeOnFtRuleId, 
			final String invoiceIdentity, final String percentageWriteOnChargeId) {
		super(businessEntityIdentity, writeOnFtRuleId);
		this.invoiceIdentity = invoiceIdentity;
		this.percentageWriteOnChargeId = percentageWriteOnChargeId;
	}

	public String getInvoiceIdentity() {
		return invoiceIdentity;
	}

	public void setInvoiceIdentity(String invoiceIdentity) {
		this.invoiceIdentity = invoiceIdentity;
	}

	public String getPercentageWriteOnChargeId() {
		return percentageWriteOnChargeId;
	}

	public void setPercentageWriteOnChargeId(String percentageWriteOnChargeId) {
		this.percentageWriteOnChargeId = percentageWriteOnChargeId;
	}

	public BillingConfigPercentageWriteOn getPercentageWriteOnFTCharge() {
		return percentageWriteOnFTCharge;
	}

	public void setPercentageWriteOnFTCharge(BillingConfigPercentageWriteOn percentageWriteOnFTCharge) {
		this.percentageWriteOnFTCharge = percentageWriteOnFTCharge;
	}

	@Override
	public String toString() {
		return "InvoiceBillingPercentageWriteOnRule [invoiceIdentity=" + invoiceIdentity + ", percentageWriteOnChargeId=" + percentageWriteOnChargeId
				+ ", percentageWriteOnFTCharge=" + percentageWriteOnFTCharge + ", getBusinessEntityIdentity()=" + getBusinessEntityIdentity()
				+ ", getWriteOnFtRuleId()=" + getWriteOnFtRuleId() + ", getWriteOnFTRule()=" + getWriteOnFTRule() + ", getIdentity()=" + getIdentity() + "]";
	}

}
