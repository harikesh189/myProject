package com.hcentive.billing.wfm.domain.billingpolicy;

import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BufferPeriodStrategyType;
import com.hcentive.billing.wfm.dto.DatesHolder;
import com.hcentive.billing.wfm.dto.DatesHolder.DateType;

public class DaysAndMonthVarianceBufferPeriodStrategy extends
		BufferPeriodStrategy {

	private final static Logger logger = LoggerFactory
			.getLogger(DaysAndMonthVarianceBufferPeriodStrategy.class);

	private int monthVariant;

	private int dayOfMonth;

	public DaysAndMonthVarianceBufferPeriodStrategy(int monthVariant,
			int dayOfMonth) {
		super(BufferPeriodStrategyType.DAYS_AND_MONTH_VARIANT);
		this.monthVariant = monthVariant;
		this.dayOfMonth = dayOfMonth;
	}

	public int getMonthVariant() {
		return monthVariant;
	}

	public void setMonthVariant(int monthVariant) {
		this.monthVariant = monthVariant;
	}

	public int getDayOfMonth() {
		return dayOfMonth;
	}

	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}

	@Override
	public Date resolveBufferEndDate(DatesHolder dates) {
		Date bpStart = dates.getDateByType(DateType.BILL_PERIOD_START_DATE);
		if (bpStart == null) {
			logger.error("Bill period start date not found. Required to calculate buffer end date");
			throw new RuntimeException(
					"Bill period start date not found. Required to calculate buffer end date");
		}

		DateTime temp = DateTime.getDateTime(bpStart).add(monthVariant,
				Calendar.MONTH);
		return DateUtility.roundAtDayEnd(DateUtility.setDayOfMonthBoundByMonthEnd(temp.getDate(),
				dayOfMonth));
	}

}
