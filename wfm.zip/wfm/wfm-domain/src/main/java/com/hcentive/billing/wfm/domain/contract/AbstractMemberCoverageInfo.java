package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Member;
import com.hcentive.billing.core.commons.domain.Period;

@Entity
@Table(name = "member_coverage_info")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "member_type")
public abstract class AbstractMemberCoverageInfo<T extends Member> extends
		BaseEntity implements Effectivity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8273824965004612548L;

	@Access(AccessType.FIELD)
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Embedded
	public Period coverage;

	@Access(AccessType.FIELD)
	@JoinColumn(name = "member_id")
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	public InsuredMember<T> insuredMember;

	public AbstractMemberCoverageInfo() {
	}

	public Period getCoverage() {
		return coverage;
	}

	public void setCoverage(Period coverage) {
		this.coverage = coverage;
	}

	public InsuredMember<T> getInsuredMember() {
		return insuredMember;
	}

	public void setInsuredMember(InsuredMember<T> insuredMember) {
		this.insuredMember = insuredMember;
	}
}