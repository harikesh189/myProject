package com.hcentive.billing.wfm.api;

import java.util.Set;

import com.hcentive.billing.wfm.domain.contract.InsuranceCoverage;

public interface InsuranceCoverageAwareContract {

	Set<InsuranceCoverage> insuranceCoverages();

}
