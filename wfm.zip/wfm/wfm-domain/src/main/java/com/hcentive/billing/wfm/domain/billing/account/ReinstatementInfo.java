package com.hcentive.billing.wfm.domain.billing.account;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.configuration.SystemConfiguration;
import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Customer;
import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.domain.ItemRecordAware;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.reinstatement.ReinstatementStatus;
import com.hcentive.billing.core.commons.domain.enumtype.Status;

@Entity
@Table(name = "reinstatement_info")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class ReinstatementInfo extends DomainEntity implements TenantAware, IdentityAware, ItemRecordAware {

	private static final long serialVersionUID = -5083216521642353975L;

	@Column(name = "item_record_id")
	@Access(AccessType.FIELD)
	private String itemRecordId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "billing_account_id")
	private BillingAccount billingAccount;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private ReinstatementStatus status;
	

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "reinstatement_date")) })
	private DateTime reinstatementDate;

	@Access(AccessType.FIELD)
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "reinstatement_period_begins")),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "reinstatement_period_ends")) })
	@Embedded
	private Period reinstatementPeriod;
	
	@Access(AccessType.FIELD)
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "last_bill_period_begins_on")),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "last_bill_period_period_ends")) })
	@Embedded
	private Period lastBillPeriod;
	
	@Embedded
	@AttributeOverride(name = "date", column = @Column(name = "valid_through"))
	private DateTime validThrough;
	
	@Embedded
	@AttributeOverride(name = "date", column = @Column(name = "lapse_period_breakups_end_date"))
	private DateTime lapsePeriodBreakupsEndDate;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "reinstatement_lapse_period_breakups", joinColumns = @JoinColumn(name = "reinstatement_id"), inverseJoinColumns = @JoinColumn(name = "line_item_id"))
	List<LapsePeriodAmountBreakup> lapsePeriodBreakUps;
	
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "total_reinstatement_charges_value")),
			@AttributeOverride(name = "name", column = @Column(name = "total_reinstatement_charges_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "total_reinstatement_charges_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "total_reinstatement_charges_short_name")) })
	Amount totalReinstatementCharges;
	
	@OneToOne(targetEntity = BaseAmountBreakups.class, fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinColumn(name = "reinstatement_base_amount_breakups")
	@Access(AccessType.FIELD)
	BaseAmountBreakups baseAmountBreakUp;
	
	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;

	public ReinstatementInfo(String identity, BillingAccount billingAccount, DateTime reinstatementDate, Period reinstatementPeriod,
	        ReinstatementStatus reinstatementStatus) {
		super();
		this.identity = identity;
		this.billingAccount = billingAccount;
		this.reinstatementDate = reinstatementDate;
		this.reinstatementPeriod = reinstatementPeriod;
		this.lapsePeriodBreakUps=new ArrayList<LapsePeriodAmountBreakup>();
	}
	public ReinstatementInfo() {
	}

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

		public DateTime getReinstatementDate() {
		return reinstatementDate;
	}

	public Period getReinstatementPeriod() {
		return reinstatementPeriod;
	}

	public void setBillingAccount(BillingAccount assocAccount) {
		this.billingAccount = assocAccount;
	}

	@Override
	public void setIdentity(String identity) {
		this.identity = identity;
	}


	public void setReinstatementDate(DateTime reinstatementDate) {
		this.reinstatementDate = reinstatementDate;
	}

	public void setReinstatementPeriod(Period reinstPeriod) {
		this.reinstatementPeriod = reinstPeriod;
	}
	
	
	
	public BaseAmountBreakups getBaseAmountBreakUp() {
		return baseAmountBreakUp;
	}
	public void setBaseAmountBreakUp(BaseAmountBreakups baseAmountBreakUp) {
		this.baseAmountBreakUp = baseAmountBreakUp;
	}
	
	public DateTime getLapsePeriodBreakupsEndDate() {
		return lapsePeriodBreakupsEndDate;
	}
	public void setLapsePeriodBreakupsEndDate(DateTime lapsePeriodBreakupsEndDate) {
		this.lapsePeriodBreakupsEndDate = lapsePeriodBreakupsEndDate;
	}
	public List<LapsePeriodAmountBreakup> getLapsePeriodBreakUps() {
		return Collections.unmodifiableList(lapsePeriodBreakUps);
	}
	public void reInitializeLapseBreakups(){
		this.lapsePeriodBreakUps=new ArrayList<LapsePeriodAmountBreakup>();
	}
	
	public Period getLastBillPeriod() {
		return lastBillPeriod;
	}
	public void setLastBillPeriod(Period lastBillPeriod) {
		this.lastBillPeriod = lastBillPeriod;
	}
	public void addLapsePeriodBreakUps(
			LapsePeriodAmountBreakup lapsePeriodBreakUp) {
		if(null!=lapsePeriodBreakUp){
			if(this.lapsePeriodBreakUps==null)
				this.lapsePeriodBreakUps=new ArrayList<LapsePeriodAmountBreakup>();
		this.lapsePeriodBreakUps.add(lapsePeriodBreakUp);
		}
	}
	public void addAllLapsePeriodBreakUps(
			List<LapsePeriodAmountBreakup>lapsePeriodBreakUps) {
		if(null!=lapsePeriodBreakUps && !lapsePeriodBreakUps.isEmpty()){
			if(this.lapsePeriodBreakUps==null)
				this.lapsePeriodBreakUps=new ArrayList<LapsePeriodAmountBreakup>();
		this.lapsePeriodBreakUps.addAll(lapsePeriodBreakUps);
		}
	}

	public DateTime getValidThrough() {
		return validThrough;
	}
	public ReinstatementStatus getStatus() {
		return status;
	}
	public void setStatus(ReinstatementStatus status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ReinstatementInfo [billingAccount=" + billingAccount.getIdentity() + ", identity=" + identity + ", reinstatementDate=" + reinstatementDate + ", reinstatementPeriod=" + reinstatementPeriod
		        +  ", tenantId=" + tenantId + "]";
	}
	public boolean isExpired() {
		if(null==validThrough){
			return true;
		}
		return new DateTime(Calendar.getInstance().getTime()).isAfterOrEquals(validThrough);
	}
	public void setValidThrough(DateTime validThrough) {
		this.validThrough=validThrough;
	}
	
	public Amount getTotalReinstatementCharges() {
		return totalReinstatementCharges;
	}
	
	public void setTotalReinstatementCharges(Amount totalReinstatementCharges) {
		this.totalReinstatementCharges = totalReinstatementCharges;
	}
	public void setNetBreakup(){
		Amount netBreakup=new Amount();
		for (LapsePeriodAmountBreakup lapsePeriodAmountBreakup : lapsePeriodBreakUps) {
			netBreakup=netBreakup.add(lapsePeriodAmountBreakup.getLapsePeriodAmount());
		}
		this.setTotalReinstatementCharges(netBreakup);
	}
	@Override
	public String getTenantId() {
		if (this.tenantId == null) {
			return "";
		}
		return this.tenantId;
	}
	@Override
	public String getItemRecordId() {
		return this.itemRecordId;
	}
	@Override
	public void setItemRecordId(String itemRecordId) {
		this.itemRecordId=itemRecordId;
	}
}
