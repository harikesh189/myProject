package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.Set;
import java.util.TreeSet;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.BillRunType;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.schedule.cycle.RunSegment.RunSegmentComparator;

@Entity
@Table(name = "billing_account_run_cycle")
public class BillingAccountRunCycle extends
		ReferenceableDomainEntity<BillingAccountRunCycle, String> {
	
	public static enum ReRunType {
		NONE, COMPLETE, PARTIAL, VOID_ONLY, INVOICE_ONLY;
	}

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "billing_account_id")
	private BillingAccount billingAccount;

	@ManyToOne
	@JoinColumn(name = "billing_run_cycle_id")
	private BillingRunCycle billingRunCycle;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private RunStatus status;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "billing_acct_run_cycle_run_segments", joinColumns = @JoinColumn(name = "billing_account_run_cycle_id"), inverseJoinColumns = @JoinColumn(name = "run_segments_id"))
	private Set<RunSegment> runSegments = new TreeSet<>(new RunSegmentComparator());
	
	// Signifies that this is a re-run of another BA run cycle
	@Enumerated(EnumType.STRING)
	@Column(name = "re_run_type")
	private ReRunType reRunType;

	@Column(name = "original_run_identity")
	private String originalRunIdentity;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "actual_run_date")) })
	private DateTime actualRunDate;

	@Column(name = "bill_run_type")
	@Enumerated(EnumType.STRING)
	private BillRunType billRunType;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "invoice_amount_value")),
			@AttributeOverride(name = "currency.name", column = @Column(name = "invoice_amount_name")),
			@AttributeOverride(name = "currency.symbol", column = @Column(name = "invoice_amount_symbol")),
			@AttributeOverride(name = "currency.shortName", column = @Column(name = "invoice_amount_short_name")) })
	private Amount invoiceAmount;
	
	protected BillingAccountRunCycle() {
		this(null, null);
	}

	public BillingAccountRunCycle(final BillingAccount billAcct,
			final BillingRunCycle runCycle) {
		
		this.billingAccount = billAcct;
		this.billingRunCycle = runCycle;
		this.status = RunStatus.PENDING;
		this.reRunType = ReRunType.NONE;
	}

	public BillingAccount getBillingAccount() {
		return this.billingAccount;
	}

	public BillingRunCycle getBillingRunCycle() {
		return this.billingRunCycle;
	}

	public RunStatus getStatus() {
		return this.status;
	}

	public void setStatus(final RunStatus status) {
		this.status = status;
	}

	@Override
	public String typeName() {
		return "BillingAccountRunCycle";
	}

	@Override
	public String refValue() {
		return this.getIdentity();
	}

	public boolean isReRun() {
		return !reRunType.equals(ReRunType.NONE);
	}
	
	public boolean isCompleteReRun() {
		return reRunType.equals(ReRunType.COMPLETE);
	}
	
	public boolean isVoidOnlyReRun() {
		return reRunType.equals(ReRunType.VOID_ONLY);
	}
	
	public boolean isPartialReRun() {
		return reRunType.equals(ReRunType.PARTIAL);
	}
	
	public boolean isInvoiceOnlyReRun() {
		return ReRunType.INVOICE_ONLY.equals(reRunType);
	}

	public void setReRunType(ReRunType reRun) {
		this.reRunType = reRun;
	}
	
	public ReRunType getReRunType() {
		return reRunType;
	}

	public boolean reRunRequiresBilling() {
		return ReRunType.COMPLETE.equals(reRunType) ||
				ReRunType.PARTIAL.equals(reRunType);
 	}
	
	public boolean reRunRequiresVoid() {
		return reRunRequiresBilling() ||
				ReRunType.VOID_ONLY.equals(reRunType);
	}
	
	public boolean reRunRequiresInvoiceGeneration() {
		return reRunRequiresBilling() ||
				ReRunType.INVOICE_ONLY.equals(reRunType);
	}

	public String getOriginalRunIdentity() {
		return originalRunIdentity;
	}

	public void setOriginalRunIdentity(String originalRunIdentity) {
		this.originalRunIdentity = originalRunIdentity;
	}

	public DateTime getActualRunDate() {
		return actualRunDate;
	}

	public void setActualRunDate(DateTime actualRunDate) {
		this.actualRunDate = actualRunDate;
	}

	public Set<RunSegment> getRunSegments() {
		return runSegments;
	}

	public void setRunSegments(Set<RunSegment> initContexts) {
		this.runSegments.clear();
		for (RunSegment rs : initContexts) {
			addRunSegment(rs);
		}
	}

	public void addRunSegment(RunSegment execFlow) {
		
		for (RunSegment initCtx : runSegments) {
			
			if (initCtx.getType().equals(execFlow.getType())) {
				// not adding as it already exists
				return;
			}
			
		}
		
		runSegments.add(execFlow);
	}

	public boolean isInitPending() {
		return RunStatus.PENDING == status || RunStatus.INIT_STARTED == status;
	}

	public BillRunType getBillRunType() {
		return billRunType;
	}

	public void setBillRunType(BillRunType billRunType) {
		this.billRunType = billRunType;
	}

	public Amount getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(Amount invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	
}
