package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.RemitScheduleStrategy;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.RunCycleType;

/**
 * It tell WFM how and when to remit money to entities like carrier, agent,
 * exchanges etc.
 * 
 * @author nitin.singla
 */
public class BillingConfigRemittance extends BillingRuleConfig {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * It defines maximum remittance amount allowed for remittance. Beyond Max
	 * remittance amount, remittance would not be allowed. It is set by an
	 * operator.
	 */
	@NotNull
	private Amount maxRemittanceAmount;

	@NotNull
	private RunCycleType scheduleFrequency;

	@NotNull
	private RemitScheduleStrategy scheduleStrategy;

	@Min(0)
	@Max(999999)
	private int scheduleValue;

	public BillingConfigRemittance() {
		super(ConfigType.REMITTANCE);
	}

	/**
	 * Gets the maximum remittance amount allowed for remittance. Beyond Max
	 * remittance amount, remittance would not be allowed.
	 * 
	 * @return The maximum remittance amount allowed for remittance
	 */
	public Amount getMaxRemittanceAmount() {
		return this.maxRemittanceAmount;
	}

	public RunCycleType getScheduleFrequency() {
		return this.scheduleFrequency;
	}

	public RemitScheduleStrategy getScheduleStrategy() {
		return this.scheduleStrategy;
	}

	/**
	 * Gets the value of schedule. <br/>
	 * <ul>
	 * <li>If schedule is Weekly or BiWeekly its value can be 1(Monday) to
	 * 5(Friday)</li>
	 * <li>If schedule is Monthly its value can be 1(January) to 12(December)</li>
	 * <li>If schedule is Quarterly its value can be 1 to 4</li>
	 * </ul>
	 * 
	 * @return The value of schedule
	 */
	public int getScheduleValue() {
		return this.scheduleValue;
	}

	/**
	 * Sets the maximum remittance amount allowed for remittance.
	 * 
	 * @param maxRemittanceAmount
	 *            The maximum remittance amount allowed for remittance to set.
	 */
	public void setMaxRemittanceAmount(final Amount maxRemittanceAmount) {
		this.maxRemittanceAmount = maxRemittanceAmount;
	}

	public void setScheduleFrequency(final RunCycleType scheduleFrequency) {
		this.scheduleFrequency = scheduleFrequency;
	}

	public void setScheduleStrategy(final RemitScheduleStrategy scheduleStrategy) {
		this.scheduleStrategy = scheduleStrategy;
	}

	/**
	 * Sets the value of schedule. <br/>
	 * <ul>
	 * <li>If schedule is Weekly or BiWeekly its value can be 1(Monday) to
	 * 5(Friday)</li>
	 * <li>If schedule is Monthly its value can be 1(January) to 12(December)</li>
	 * <li>If schedule is Quarterly its value can be 1 to 4</li>
	 * </ul>
	 * 
	 * @param scheduleValue
	 *            The value of schedule to set.
	 */
	public void setScheduleValue(final int scheduleValue) {
		this.scheduleValue = scheduleValue;
	}

}