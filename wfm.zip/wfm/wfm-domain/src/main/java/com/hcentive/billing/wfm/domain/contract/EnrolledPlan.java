package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

import com.hcentive.billing.core.commons.domain.HealthPlanProvider;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.wfm.domain.contract.mixin.HealthPlanAware;
import com.hcentive.billing.wfm.domain.contract.mixin.LOBAware;

@Entity
@DiscriminatorValue("ENROLLED_PLAN")
public class EnrolledPlan extends EligibilityCoverage implements HealthPlanAware, LOBAware{

	private static final long serialVersionUID = 1L;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval=true)
	@Access(AccessType.FIELD)
	@JoinTable(name = "enrolled_plan_member_coverages",
			joinColumns = @JoinColumn(name = "enrolled_plan_id"),
			inverseJoinColumns = @JoinColumn(name = "member_coverages_id"))
	private final Set<EligibleMemberCoverage> memberCoverages = new HashSet<EligibleMemberCoverage>();
	
	public EnrolledPlan(final HealthPlan plan) {
		super(plan);
	}

	public EnrolledPlan(final HealthPlan plan, final Period coverage) {
		super(plan, coverage);
	}

	protected EnrolledPlan() {
	}

	public void addMemberCoverage(final EligibleMemberCoverage memberCoverage) {
		this.memberCoverages.add(memberCoverage);
		if (this.getTotalCoverage() == null) {
			this.setTotalCoverage(new Period());
		}
		this.getTotalCoverage().populateWithUnion(memberCoverage.getCoverage());
	}

	@Override
	public Period effectivePeriod() {
		return this.getTotalCoverage();
	}


	public Set<EligibleMemberCoverage> getMemberCoverages() {
		return this.memberCoverages;
	}


	@Override
	public String refValue() {
		return this.getHealthPlan().getExternalId();
	}

	@Override
	public String typeName() {
		return "EnrolledPlan";
	}

	@Override
	public Collection<String> getHealthPlanProducts() {
		final Collection<String> result = new LinkedList<>();
		final String productType = this.getHealthPlan().getProductType();
		if (productType != null) {
			result.add(productType);
		}
		return result;
	}
	
	public HealthPlan getHealthPlan() {
		return (HealthPlan) healthPlan;
	}

	@Override
	public Collection<String> getLineOfBusiness() {
		final Collection<String> result = new LinkedList<>();
		final String lob = this.getHealthPlan().getLineOfBusiness();
		if (lob != null) {
			result.add(lob);
		}
		return result;
	}

	@Override
	public Collection<HealthPlanProvider> getHealthPlanProviders() {
		if (getHealthPlan().getCarrier() instanceof HealthPlanProvider) {
			return CollectionUtil.asList((HealthPlanProvider) this.getHealthPlan().getCarrier());
		}
		return Collections.EMPTY_LIST;
	}
}
