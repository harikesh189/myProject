package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.Premium;

@Entity
@Table(name = "premium")
@DiscriminatorValue("Fixed")
public class FixedPremium extends Premium {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "value")),
			@AttributeOverride(name = "name", column = @Column(name = "name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	public FixedPremium(Amount amount, PremiumCode code) {
		super(code);
		this.amount = amount;
	}

	public FixedPremium(Amount amount, PremiumCode code, String name) {
		super(code, name);
		this.amount = amount;
	}

	public Amount getAmount() {
		return amount;
	}

	protected FixedPremium() {
	}
}
