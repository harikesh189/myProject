/**
 * 
 */
package com.hcentive.billing.wfm.api;

/**
 * @author Kumar Sambhav Jain
 * @param <V>
 */
public interface FTConstants {

	public static final String AMOUNT_PAYMENT_CODE = "PAYMENT";
	public static final String BILLING_PERIOD_CODE = "BILLING_PERIOD";
	public static final String COVERAGE_PERIOD_CODE = "COVERAGE_PERIOD";
	public static final String ENTITY_BROKER_CODE = "BROKER";
	public static final String ENTITY_CLIENT_CODE = "CLIENT";
	public static final String ENTITY_EXCHANGE_CODE = "EXCHANGE";
	public static final String ENTITY_GROUP_CODE = "GROUP";
	public static final String ENTITY_HEALTH_PLAN_PROVIDE_CODE = "HP_PROVIDER";
	public static final String ENTITY_INDIVIDUAL_CODE = "INDIVIDUAL";
	public static final String ENTITY_BENEFIT_VENDOR_CODE = "BENEFIT_VENDOR";

	public static final String ENTITY_OTHER_CODE = "OTHER";
	public static final String ENTITY_SUBSCRIBER_CODE = "SUBSCRIBER";

	public static final String ENTITY_SUBSIDY_PROVIDER_CODE = "SUBSIDY_PROVIDER";
	public static final String INSURANCE_PLAN_CODE = "INSURANCE_PLAN_CODE";
	public static final String INSURED_MEMBER_CODE = "INSURED_MEMBER";
	public static final String PAYER_CODE = "PAYER";
	public static final String PAYEE_CODE = "PAYEE";
	public static final String AMOUNT_WRITEOFF_CODE = "WRITEOFF";
	public static final String AMOUNT_WRITEON_CODE = "WRITEON";
	public static final String AMOUNT_REFUND_CODE = "REFUND";
	public static final String AMOUNT_CREDIT_CODE = "CREDIT";
	public static final String MAN_ADJ_PRIMARY_CODE = "PRIMARY_ENTITY";
	public static final String MAN_ADJ_SECONDARY_CODE = "SECONDARY_ENTITY"; 
	public static final String PAYMENT_ID = "PAYMENT_ID";
	public static final String CONTRACT_RECORD_ID = "CONTRACT_RECORD_ID";
	public static final String MAN_ADJ_EXTERNAL_ID = "MAN_ADJ_EXTERNAL_ID";
	
	public static final String MONEY_TRANSFER = "MONEY_TRANSFER";
	public static final String MONEY_TRANSFER_ID = "MONEY_TRANSFER_ID";
	
		
	

}