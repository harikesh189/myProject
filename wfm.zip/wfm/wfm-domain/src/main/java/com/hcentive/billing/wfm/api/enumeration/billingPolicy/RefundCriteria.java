package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * It represent the criteria to make a refund payment.
 * 
 * @author nitin.singla
 * 
 */
public enum RefundCriteria {
	TIME_PERIOD
}
