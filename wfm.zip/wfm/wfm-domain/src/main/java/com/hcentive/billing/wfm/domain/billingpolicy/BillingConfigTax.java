package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

/**
 * It represent the bill configuration related to calculation of tax.
 * 
 * @author nitin.singla
 */
public abstract class BillingConfigTax<V> extends FinancialCharge<V> {

	private static final long serialVersionUID = 1L;

	private String type;

	public BillingConfigTax() {
		super(ConfigType.TAX);
	}

	public String getType() {
		return this.type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	@Override
	public String name() {
		return this.getType();
	}

}
