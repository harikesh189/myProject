package com.hcentive.billing.wfm.domain.contract.mixin;

import java.util.Collection;

public interface EntityIdAware {
	Collection<String> getEntityIds();
}
