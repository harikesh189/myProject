package com.hcentive.billing.wfm.domain.ft.rule;

import static com.hcentive.billing.core.commons.util.StringValidator.isNotBlank;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.enumtype.FinancialTrxnStatus;
import com.hcentive.billing.core.commons.tags.TagAware;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.ft.FTEntryAssociationType;
import com.hcentive.billing.wfm.api.enumeration.ft.FTEntryProcessingType;
import com.hcentive.billing.wfm.api.enumeration.ft.GLEntryCategory;
import com.hcentive.billing.wfm.api.enumeration.ft.PostingType;
import com.hcentive.billing.wfm.domain.ft.GLAccount;

public class GLEntryTemplate implements TagAware<String>, Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String identity;

	/**
	 * It is used to map to billing account of the entity involved in the transaction.
	 */
	@NotNull
	private String businessEntityCode;

	@NotNull
	private GLEntryCategory category;

	@NotNull
	private String eventAmountCode;

	private String businessEntityId;

	private String associatedEntityCode;

	private String associatedEntityId;

	/**
	 * IMPORTANT!!!! This field get saved embedded in MongoDD. while reading it back, do fetch GLAcount from RDMS for the given identity.
	 */
	@NotNull
	private GLAccount glAccount;

	private AmountCategory amountCategory;

	private FTEntryAssociationType associationTypeWithParent;

	private FTEntryProcessingType parentLLineProcessingType;

	@NotNull
	private PostingType postingType;

	private boolean nonReversible;

	private final Set<GLEntryTemplate> toSettle = new LinkedHashSet<>();

	private String notes;

	private String line;
	
	private FinancialTrxnStatus status = FinancialTrxnStatus.NEW;

	public GLEntryTemplate() {

	}

	public GLEntryTemplate(final GLEntryCategory category, final String eventAmountCode, final String businessEntityId, final String businessEntityCode,
			final PostingType postingType) {
		this.setCategory(category);
		this.setEventAmountCode(eventAmountCode);
		this.setBusinessEntityId(businessEntityId);
		this.setBusinessEntityCode(this.businessEntityCode);
		this.setPostingType(postingType);
	}

	public void addAllToSettle(final Set<GLEntryTemplate> glEntryemplates) {
		this.toSettle.addAll(glEntryemplates);
	}

	public void addToSettle(final GLEntryTemplate glEntryemplate) {
		this.toSettle.add(glEntryemplate);
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(final String identity) {
		this.identity = identity;
	}

	public String getBusinessEntityCode() {
		return this.businessEntityCode;
	}

	public String getBusinessEntityId() {
		return this.businessEntityId;
	}

	public GLEntryCategory getCategory() {
		return this.category;
	}

	public String getEventAmountCode() {
		return this.eventAmountCode;
	}

	/**
	 * @return the line
	 */
	public String getLine() {
		return this.line;
	}

	/**
	 * @return the notes
	 */
	public String getNotes() {
		return this.notes;
	}

	public PostingType getPostingType() {
		return this.postingType;
	}

	public Set<GLEntryTemplate> getToSettle() {
		return this.toSettle;
	}

	public boolean isMatching(final Collection<String> filterTags) {
		if (filterTags.containsAll(this.tags())) {
			return true;
		}
		return false;
	}

	public boolean isNonReversible() {
		return nonReversible;
	}

	public void removeAllFromToSettle() {
		this.toSettle.clear();
	}

	public boolean removeFromToSettle(final GLEntryTemplate glEntryemplate) {
		return this.toSettle.remove(glEntryemplate);
	}

	public void setBusinessEntityCode(final String businessEntityCode) {
		this.businessEntityCode = businessEntityCode;
	}

	public void setBusinessEntityId(final String businessEntityId) {
		this.businessEntityId = businessEntityId;
	}

	public String getAssociatedEntityCode() {
		return associatedEntityCode;
	}

	public void setAssociatedEntityCode(final String associatedEntityCode) {
		this.associatedEntityCode = associatedEntityCode;
	}

	public String getAssociatedEntityId() {
		return associatedEntityId;
	}

	public void setAssociatedEntityId(final String associatedEntityId) {
		this.associatedEntityId = associatedEntityId;
	}

	public void setCategory(final GLEntryCategory category) {
		this.category = category;
	}

	public void setEventAmountCode(final String eventAmountCode) {
		this.eventAmountCode = eventAmountCode;
	}

	/**
	 * @param line the line to set
	 */
	public void setLine(final String line) {
		this.line = line;
	}

	/**
	 * @param notes the notes to set
	 */
	public void setNotes(final String notes) {
		this.notes = notes;
	}

	public void setPostingType(final PostingType postingType) {
		this.postingType = postingType;
	}

	public void setNonReversible(final boolean nonReversible) {
		this.nonReversible = nonReversible;
	}

	@Override
	public Collection<String> tags() {
		final Set<String> tagSet = new HashSet<>();
		if (isNotBlank(this.eventAmountCode)) {
			tagSet.add(this.eventAmountCode);
		}
		if (isNotBlank(this.businessEntityId)) {
			tagSet.add(this.businessEntityId);
		} else if (isNotBlank(this.businessEntityCode)) {
			tagSet.add(this.businessEntityCode);
		}
		return tagSet;
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("\nGLEntryTemplate [businessEntityCode=");
		builder.append(this.businessEntityCode);
		builder.append(", category=");
		builder.append(this.category);
		builder.append(", eventAmountCode=");
		builder.append(this.eventAmountCode);
		builder.append(", eventAssociatedEntityCode=");
		builder.append(this.businessEntityId);
		builder.append(", glAccount=");
		builder.append(this.glAccount);
		builder.append(", postingType=");
		builder.append(this.postingType);
		builder.append(", nonReversible=");
		builder.append(this.nonReversible);
		builder.append(", status=");
		builder.append(this.status);
		builder.append(", notes=");
		builder.append(this.notes);
		builder.append(", line=");
		builder.append(this.line);
		builder.append("]\n");
		return builder.toString();
	}

	public AmountCategory getAmountCategory() {
		return this.amountCategory;
	}

	public void setAmountCategory(final AmountCategory amountCategory) {
		this.amountCategory = amountCategory;
	}

	public FTEntryAssociationType getAssociationTypeWithParent() {
		return this.associationTypeWithParent;
	}

	public void setAssociationTypeWithParent(final FTEntryAssociationType associationTypeWithParent) {
		this.associationTypeWithParent = associationTypeWithParent;
	}

	public FTEntryProcessingType getParentLLineProcessingType() {
		return this.parentLLineProcessingType;
	}

	public void setParentLLineProcessingType(final FTEntryProcessingType parentLLineProcessingType) {
		this.parentLLineProcessingType = parentLLineProcessingType;
	}

	/**
	 * @return the glAccount
	 */
	public GLAccount getGlAccount() {
		return glAccount;
	}

	/**
	 * @param glAccount the glAccount to set
	 */
	public void setGlAccount(final GLAccount glAccount) {
		this.glAccount = glAccount;
	}

	// Giving error on edit and save
	@JsonIgnore
	public boolean isAssociatedEntityPopulated() {
		return associatedEntityCode != null && associatedEntityId != null;
	}

	public FinancialTrxnStatus getStatus() {
		return status;
	}

	public void setStatus(FinancialTrxnStatus status) {
		this.status = status;
	}

}
