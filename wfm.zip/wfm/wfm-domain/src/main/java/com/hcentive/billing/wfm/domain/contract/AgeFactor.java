package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "eligibility_factor")
@DiscriminatorValue("Age")
public class AgeFactor extends EligibilityFactor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -852881718925217673L;
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "dob")) })
	@Access(AccessType.FIELD)
	private DateTime dob;

	public DateTime getDob() {
		return dob;
	}

	public void setDob(DateTime dob) {
		this.dob = dob;
	}

}
