package com.hcentive.billing.wfm.domain.contract;

/**
 * @author ajay.saxena
 * 
 *         Interface to represent a contract that can be run only once.
 */
public interface OneTimeContract {

	public boolean getBilledStatus();
	
	public void setBilledStatus(boolean status);

}
