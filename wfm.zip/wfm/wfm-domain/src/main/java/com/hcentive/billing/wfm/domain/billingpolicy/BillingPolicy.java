package com.hcentive.billing.wfm.domain.billingpolicy;

import static com.hcentive.billing.core.commons.util.CollectionUtil.filter;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.validation.constraints.Size;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.condition.Condition;
import com.hcentive.billing.condition.ConditionContextResolver;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

/**
 * It represent a billing policy.
 *
 * @author nitin.singla
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_billing_policy")
public class BillingPolicy extends BillingConfiguration {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private boolean archived;

	private boolean defaultConfig;

	private Condition matchingCondition;

	@Size(min = 1)
	@DBRef
	private Set<BillingRuleConfig> policyConfigs = new HashSet<>();

	/**
	 * Adds the specified policy rule in this policy.
	 *
	 * @param ruleConfig The specified policy rule to be added in this policy.
	 */
	public void addPolicyConfig(final BillingRuleConfig ruleConfig) {
		this.policyConfigs.add(ruleConfig);
	}

	public void addPolicyConfig(final Collection<BillingRuleConfig> ruleConfigs) {
		for (final BillingRuleConfig ruleToAdd : ruleConfigs) {
			this.policyConfigs.add(ruleToAdd);
		}
	}

	@JsonIgnore
	public Collection<BillingRuleConfig> getActivePolicyConfigs() {
		return filter(this.policyConfigs, ActivePolicyRuleConfigFilter.INSTANCE);
	}

	@JsonIgnore
	public BillingConfigProRate getBillingConfigProRating() {
		return this.getPolicyConfigRule(ConfigType.PRO_RATE_BILLING, BillingConfigProRate.class);
	}

	@JsonIgnore
	public BillingConfigRemittance getBillingConfigRemittance() {
		return this.getPolicyConfigRule(ConfigType.REMITTANCE, BillingConfigRemittance.class);
	}

	/**
	 * Gets the active policy configurations.
	 *
	 * @return The active policy configurations.
	 */
	@JsonIgnore
	public BillingConfigRunOut getBillingConfigRunOut() {
		return this.getPolicyConfigRule(ConfigType.RUN_OUT, BillingConfigRunOut.class);
	}

	@JsonIgnore
	public BillingConfigSchedule getBillingConfigSchedule() {
		return this.getPolicyConfigRule(ConfigType.BILLING_CYCLE, BillingConfigSchedule.class);
	}

	public Condition getMatchingCondition() {
		return this.matchingCondition;
	}

	/**
	 * Gets the policy configurations.
	 *
	 * @return The he policy configurations.
	 */
	public Set<BillingRuleConfig> getPolicyConfigs() {
		return this.policyConfigs;
	}

	/**
	 * Gets the policy configurations based on type of specified configuration.
	 *
	 * @param type The type of required configurations.
	 * @return A {@link Set} of {@link BillingRuleConfig}s as per specified types.
	 */
	public Set<BillingRuleConfig> getPolicyConfigsByType(final ConfigType type) {
		final Set<BillingRuleConfig> result = new HashSet<>();
		if (type != null) {
			for (final BillingRuleConfig policyConfig : this.policyConfigs) {
				if (policyConfig != null && type == policyConfig.getConfigType()) {
					result.add(policyConfig);
				}
			}
		}
		return result;
	}

	public boolean isArchived() {
		return archived;
	}

	/**
	 * Gets if the entity is default entity.
	 *
	 * @return <code>true</code> if this entity is default entity.
	 */
	public boolean isDefaultConfig() {
		return this.defaultConfig;
	}

	public boolean matchWith(final ConditionContextResolver conditionValueResolver) {
		return this.getMatchingCondition() != null ? this.getMatchingCondition().evaluate(conditionValueResolver) : false;
	}

	public void removePolicyConfig(final BillingRuleConfig ruleConfig) {
		this.policyConfigs.remove(ruleConfig);
	}

	public void removePolicyConfig(final Collection<BillingRuleConfig> ruleConfigs) {
		for (final BillingRuleConfig policyRuleConfig : ruleConfigs) {
			this.policyConfigs.remove(policyRuleConfig);
		}
	}

	public void setArchived(final boolean archived) {
		this.archived = archived;
	}

	@Override
	public void setBillRunExecuted(final boolean billRunExecuted) {
		for (final BillingRuleConfig policyRuleConfig : this.getActivePolicyConfigs()) {
			policyRuleConfig.setBillRunExecuted(billRunExecuted);
		}
		super.setBillRunExecuted(billRunExecuted);
	}

	/**
	 * Sets if the entity is default entity.
	 *
	 * @param active Set to <code>true</code> only if this is the currently default entity.
	 */
	public void setDefaultConfig(final boolean defaultConfig) {
		this.defaultConfig = defaultConfig;
	}

	public void setMatchingCondition(final Condition matchingCondition) {
		this.matchingCondition = matchingCondition;
	}

	/**
	 * Sets the policy configurations.
	 *
	 * @param ruleConfigs The policy configurations to set.
	 */
	public void setPolicyConfigs(final Set<BillingRuleConfig> ruleConfigs) {
		this.policyConfigs = ruleConfigs;
	}

	@Override
	public String type() {
		return "Policy";
	}

	private <T extends BillingRuleConfig> T getPolicyConfigRule(final ConfigType ruleType, final Class<T> ruleClazz) {

		final Set<BillingRuleConfig> rules = this.getPolicyConfigsByType(ruleType);

		if (rules != null && !rules.isEmpty()) {

			for (final BillingRuleConfig ruleConfig : rules) {
				if (ruleClazz.isInstance(ruleConfig)) {
					return ruleClazz.cast(ruleConfig);
				}
			}
		}

		return null;
	}

}
