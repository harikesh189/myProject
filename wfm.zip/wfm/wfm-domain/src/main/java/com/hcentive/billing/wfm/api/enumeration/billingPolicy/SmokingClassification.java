package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum SmokingClassification {
	HEAVY, LIGHT, MODERATE, STANDARD;
}
