package com.hcentive.billing.wfm.api.enumeration.runcycle;

public enum RunStatus {
	PENDING, CANCELLED, INIT_STARTED, INITIATED, COMPLETED, FAILED, CANCELLED_FOR_RERUN, CANCELLED_FOR_REJECTION, WAITING, CANCELLED_BY_RENEWAL;
}
