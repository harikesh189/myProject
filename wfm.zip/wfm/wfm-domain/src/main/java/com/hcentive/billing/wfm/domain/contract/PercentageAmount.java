package com.hcentive.billing.wfm.domain.contract;

public class PercentageAmount {

	private Double percentage;

	private String refAmountCode;

	protected PercentageAmount() {

	}

	public PercentageAmount(Double percentage, String refAmountCode) {
		this.percentage = percentage;
		this.refAmountCode = refAmountCode;
	}

	public Double getPercentage() {
		return percentage;
	}

	public String getRefAmountCode() {
		return refAmountCode;
	}

	public String toString() {
		return "ref amount code: " + refAmountCode + ", percentage: "
				+ percentage;
	}
}
