package com.hcentive.billing.wfm.domain.schedule.cycle;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.RandomGenerator;

@Entity
@Table(name = "binder_billing_trigger")
public class BinderBillingTrigger extends DomainEntity {

	private static final long serialVersionUID = 1L;

	@Column(name="billed_entity_external_id")
	private String billedEntityExternalId;
	
	@Column(name="billed_contract_external_id")
	private String billedContractExternalId;
	
	@Column(name="binder_billing")
	private boolean binderBilling;
	
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
		@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period binderBillingTriggerPeriod;

	
	protected BinderBillingTrigger() {
		
	}
	
	public BinderBillingTrigger(String entityExtrnlId, String contractExtrnlId, boolean binderBilling,final Period binderBillingPeriod) {
		this.billedEntityExternalId = entityExtrnlId;
		this.billedContractExternalId = contractExtrnlId;
		this.binderBilling = binderBilling;
		this.identity = RandomGenerator.randomString();
		this.binderBillingTriggerPeriod=binderBillingPeriod;
	}

	public String getBilledEntityExternalId() {
		return billedEntityExternalId;
	}

	public void setBilledEntityExternalId(String billedEntityExternalId) {
		this.billedEntityExternalId = billedEntityExternalId;
	}

	public String getBilledContractExternalId() {
		return billedContractExternalId;
	}

	public void setBilledContractExternalId(
			String billedContractExternalId) {
		this.billedContractExternalId = billedContractExternalId;
	}

	public boolean isBinderBilling() {
		return binderBilling;
	}

	public void setBinderBilling(boolean binderBilling) {
		this.binderBilling = binderBilling;
	}

	public Period getBinderBillingTriggerPeriod() {
		return binderBillingTriggerPeriod;
	}

	public void setBinderBillingTriggerPeriod(Period binderBillingTriggerPeriod) {
		this.binderBillingTriggerPeriod = binderBillingTriggerPeriod;
	}

}
