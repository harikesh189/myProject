package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum BillingConfigPlanType {
	HMO, POS, PPO;
}
