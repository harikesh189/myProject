package com.hcentive.billing.wfm.domain.remit;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "remit_data_run")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class RemitDataRun extends BaseEntity implements TenantAware{

	private static final long serialVersionUID = 729731998598196191L;

	public static enum Status {
		PENDING, COMPLETED, FAILED;
	}

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "from_date")) })
	@Access(AccessType.FIELD)
	private DateTime fromDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "to_date")) })
	@Access(AccessType.FIELD)
	private DateTime toDate;
	
	
	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status = Status.PENDING.toString();

	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;
	
	public RemitDataRun() {
		super();
	}

	public RemitDataRun(String financialTrxnId) {
		super();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public DateTime getFromDate() {
		return fromDate;
	}

	public void setFromDate(DateTime fromDate) {
		this.fromDate = fromDate;
	}

	public DateTime getToDate() {
		return toDate;
	}

	public void setToDate(DateTime toDate) {
		this.toDate = toDate;
	}

	@Override
	public String toString() {
		return "RemitDataRun [fromDate=" + fromDate + ",toDate=" + toDate + ", status=" + status + "]";
	}
}
