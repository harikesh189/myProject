package com.hcentive.billing.wfm.domain.ft.rule;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.condition.Condition;
import com.hcentive.billing.condition.ConditionContextResolver;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.ft.ContractType;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingRuleConfig;
import com.hcentive.billing.wfm.domain.ft.FinancialTrxnEntry;

public class FTRule extends BillingRuleConfig {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private boolean defaultConfig;

	@NotNull
	private FinancialEventType eventType;

	@Valid
	private final Set<GLEntryTemplate> glEntryTemplates = new LinkedHashSet<>();

	private Condition matchingCondition;

	private ContractType contractType;

	@Valid
	private final Set<FTProcessingCriteria> processingCriterias = new HashSet<>();

	public FTRule() {
		super(ConfigType.FT);
		this.setPeriod(new Period());
	}

	public FTRule(final boolean defaultConfig, final String description, final FinancialEventType eventType, final String name) {
		super(ConfigType.FT);
		this.defaultConfig = defaultConfig;
		this.setDescription(description);
		this.eventType = eventType;
		this.setName(name);
	}

	public boolean addGLEntryTemplate(final GLEntryTemplate glEntryTemplate) {
		return this.glEntryTemplates.add(glEntryTemplate);
	}

	public boolean addProcessingCriteria(final FTProcessingCriteria processingCriteria) {
		return this.processingCriterias.add(processingCriteria);
	}

	public FinancialEventType getEventType() {
		return this.eventType;
	}

	public Set<GLEntryTemplate> getGLEntryTemplates() {
		return this.glEntryTemplates;
	}

	public Set<GLEntryTemplate> getAllGLEntryTemplates() {
		final Set<GLEntryTemplate> result = new LinkedHashSet<>();
		result.addAll(this.getGLEntryTemplates());
		for (final GLEntryTemplate glEntryTemplate : getGLEntryTemplates()) {
			result.addAll(glEntryTemplate.getToSettle());
		}
		return result;
	}

	public void clearGlEntryTemplates() {
		this.glEntryTemplates.clear();
	}

	public Condition getMatchingCondition() {
		return this.matchingCondition;
	}

	public Collection<GLEntryTemplate> getMatchingSettlementTemplates(final FinancialTrxnEntry financialTrxnEntry) {
		final Collection<GLEntryTemplate> glEntryTemplates = new LinkedList<>();
		for (final FTProcessingCriteria processingCriteria : this.processingCriterias) {
			if (processingCriteria.matchWith(financialTrxnEntry)) {
				glEntryTemplates.addAll(processingCriteria.getGLEntryTemplates());
			}
		}
		return glEntryTemplates;
	}

	public Set<FTProcessingCriteria> getProcessingCriteria() {
		return Collections.unmodifiableSet(this.processingCriterias);
	}

	public boolean isDefaultConfig() {
		return this.defaultConfig;
	}

	public boolean matchWith(final ConditionContextResolver conditionValueResolver) {
		return this.getMatchingCondition() == null || this.getMatchingCondition().evaluate(conditionValueResolver);
	}

	public void removeAllGLEntryTemplates() {
		this.glEntryTemplates.clear();
	}

	public boolean removeGLEntryTemplate(final GLEntryTemplate glEntryTemplate) {
		return this.glEntryTemplates.remove(glEntryTemplate);
	}

	public void setDefaultConfig(final boolean defaultConfig) {
		this.defaultConfig = defaultConfig;
	}

	public void setEventType(final FinancialEventType eventType) {
		this.eventType = eventType;
	}

	public void setMatchingCondition(final Condition matchingCondition) {
		this.matchingCondition = matchingCondition;
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("FTRule [defaultConfig=");
		builder.append(this.defaultConfig);
		builder.append(", eventType=");
		builder.append(this.eventType);
		builder.append(", glEntryTemplates=");
		builder.append(this.glEntryTemplates);
		builder.append(", identity=");
		builder.append(", version=");
		builder.append(", getConfigType()=");
		builder.append(this.getConfigType());
		builder.append(", isActive()=");
		builder.append(this.isActive());
		builder.append(", isBillRunExecuted()=");
		builder.append(this.isBillRunExecuted());
		builder.append(", getTenantId()=");
		builder.append("]");
		return builder.toString();
	}

	public ContractType getContractType() {
		return contractType;
	}

	public void setContractType(final ContractType contractType) {
		this.contractType = contractType;
	}

}
