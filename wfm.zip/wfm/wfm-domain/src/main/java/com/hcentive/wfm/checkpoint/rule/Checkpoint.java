package com.hcentive.wfm.checkpoint.rule;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * Configurable checkpoints during monitoring process. <br>
 * <br>
 * Implements Comparable based on the checkpoint day.
 * 
 * @author Kumar Sambhav Jain
 *
 */
public class Checkpoint implements Comparable<Checkpoint>, Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1771613343073401269L;

	@NotNull
	@Min(value = 1)
	private int day;
	@NotNull
	private String name;
	private String id;
	private CheckpointType type;

	private static enum CheckpointType {
		EXIT, TERM;
	}

	/*
	 * @DBRef(lazy = false) protected NotificationRule notificationRule;
	 */

	public Checkpoint(int day, String name, CheckpointType type) {
		this.day = day;
		this.name = name;
		this.type = type;
	}

	public Checkpoint(int day) {
		this(day, null,null);
	}

	/**
	 * Does Nothing
	 */
	public Checkpoint() {
		this(-1, null, null);
	}

	
	
	/**
	 * @return the type
	 */
	public CheckpointType getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(CheckpointType type) {
		this.type = type;
	}

	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}

	/**
	 * @param day
	 *            the day to set
	 */
	public void setDay(int day) {
		this.day = day;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Checkpoint o) {
		return this.day - o.day;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + day;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Checkpoint other = (Checkpoint) obj;
		if (day != other.day)
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DelinquencyCheckpoint [day=" + day + ", name=" + name + ", id="
				+ id + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
