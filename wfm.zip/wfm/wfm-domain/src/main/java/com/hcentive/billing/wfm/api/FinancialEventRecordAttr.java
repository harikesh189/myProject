package com.hcentive.billing.wfm.api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

public class FinancialEventRecordAttr<V> {

	public static final String FT_EVENT_RECORD_ATTR_BROKER_CODE = FTConstants.ENTITY_BROKER_CODE;
	public static final String FT_EVENT_RECORD_ATTR_CLIENT_CODE = FTConstants.ENTITY_CLIENT_CODE;
	public static final String FT_EVENT_RECORD_ATTR_EXCHANGE_CODE = FTConstants.ENTITY_EXCHANGE_CODE;
	public static final String FT_EVENT_RECORD_ATTR_GROUP_CODE = FTConstants.ENTITY_GROUP_CODE;
	public static final String FT_EVENT_RECORD_ATTR_HEALTH_PLAN_PROVIDE_CODE = FTConstants.ENTITY_HEALTH_PLAN_PROVIDE_CODE;
	public static final String FT_EVENT_RECORD_ATTR_INDIVIDUAL_CODE = FTConstants.ENTITY_INDIVIDUAL_CODE;
	public static final String FT_EVENT_RECORD_ATTR_OTHER_CODE = FTConstants.ENTITY_OTHER_CODE;
	public static final String FT_EVENT_RECORD_ATTR_PAYER_CODE = FTConstants.PAYER_CODE;
	public static final String FT_EVENT_RECORD_ATTR_PAYEE_CODE = FTConstants.PAYEE_CODE;

	public static final String FT_EVENT_RECORD_ATTR_PAYMENT_ID = FTConstants.PAYMENT_ID;
	public static final String FT_EVENT_RECORD_ATTR_CONTRACT_RECORD_ID = FTConstants.CONTRACT_RECORD_ID;
	
	public static final String FT_EVENT_RECORD_ATTR_SUBSCRIBER_CODE = FTConstants.ENTITY_SUBSCRIBER_CODE;
	public static final String FT_EVENT_RECORD_ATTR_SUBSIDY_PROVIDER_CODE = FTConstants.ENTITY_SUBSIDY_PROVIDER_CODE;
	public static final String FT_EVENT_RECORD_ATTR_MAN_ADJ_PRIMARY = FTConstants.MAN_ADJ_PRIMARY_CODE;
	public static final String FT_EVENT_RECORD_ATTR_MAN_ADJ_SECONDARY = FTConstants.MAN_ADJ_SECONDARY_CODE;
	public static final String FT_EVENT_RECORD_ATTR_MAN_ADJ_EXTERNAL_ID = FTConstants.MAN_ADJ_EXTERNAL_ID;

	public static final String PAYMENT = FTConstants.AMOUNT_PAYMENT_CODE;
	public static final String WRITEOFF = FTConstants.AMOUNT_WRITEOFF_CODE;
	public static final String WRITEON = FTConstants.AMOUNT_WRITEON_CODE;
	public static final String REFUND = FTConstants.AMOUNT_REFUND_CODE;
	public static final String CREDIT = FTConstants.AMOUNT_CREDIT_CODE;
	
	public static final String MONEY_TRANSFER = FTConstants.MONEY_TRANSFER;
	public static final String FT_EVENT_RECORD_ATTR_MONEY_TRANSFER_ID = FTConstants.MONEY_TRANSFER_ID;
	public static final String FT_EVENT_RECORD_ATTR_BENEFIT_VENDOR_CODE = FTConstants.ENTITY_BENEFIT_VENDOR_CODE;
	
	
	

	private String code;
	private String description;
	private final Set<ReferenceableDomainEntity> referenceableDomainEntitySet = new HashSet<>();
	private V value;

	public FinancialEventRecordAttr(final String code, final String description, final V value) {
		this.code = code;
		this.description = description;
		this.value = value;
	}

	public FinancialEventRecordAttr(final String code, final V value) {
		this(code, "", value);
	}

	public void addReference(final ReferenceableDomainEntity referenceableDomainEntity) {
		this.referenceableDomainEntitySet.add(referenceableDomainEntity);
	}

	public String getCode() {
		return this.code;
	}

	public String getDescription() {
		return this.description;
	}

	public Collection<Reference> getReferences() {
		final Collection<Reference> referenceSet = new ArrayList<>(this.referenceableDomainEntitySet.size());
		for (final ReferenceableDomainEntity referenceableDomainEntity : this.referenceableDomainEntitySet) {
			referenceSet.add(referenceableDomainEntity.toReference());
		}
		return referenceSet;
	}

	public V getValue() {
		return this.value;
	}

	public void setCode(final String code) {
		this.code = code;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public void setValue(final V value) {
		this.value = value;
	}
}
