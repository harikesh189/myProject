package com.hcentive.billing.wfm.domain.ft.rule;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.wfm.domain.ft.GLAccount;

@Entity
@DiscriminatorValue("FixedGLAccount")
public class GLAccountFixedValueRef extends FixedValueAttrRef<GLAccount> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinColumn(name = "gl_account_id")
	@Access(AccessType.FIELD)
	private final GLAccount glAccount;

	public GLAccountFixedValueRef() {
		this(null);
	}

	public GLAccountFixedValueRef(final GLAccount glAccount) {
		this.glAccount = glAccount;
	}

	@Override
	public GLAccount refData() {
		return this.glAccount;
	}

}
