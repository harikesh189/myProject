package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.contract.PercentageAmount;

/**
 * 
 * @author nitin.singla
 * 
 */
public class BillingConfigPercentageDiscount extends
		BillingConfigDiscount<PercentageAmount> implements PercentageAware {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private double percentage;

	private String refAmountCode;

	@Override
	public double getPercentage() {
		return this.percentage;
	}

	public String getRefAmountCode() {
		return this.refAmountCode;
	}

	public void setPercentage(final double percentage) {
		this.percentage = percentage;
	}

	public void setRefAmountCode(final String refAmountCode) {
		this.refAmountCode = refAmountCode;
	}

	@Override
	public PercentageAmount value() {
		return new PercentageAmount(this.getPercentage(),
				this.getRefAmountCode());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.core.commons.api.Effectivity#effectivePeriod()
	 */
	@Override
	public Period effectivePeriod() {
		return period;
	}

}
