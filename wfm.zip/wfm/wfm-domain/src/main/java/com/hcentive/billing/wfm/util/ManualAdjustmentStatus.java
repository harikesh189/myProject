package com.hcentive.billing.wfm.util;

public enum ManualAdjustmentStatus {
	
	INITIATED,PROGRESS,SUCCESS,FAILED,REJECTED,OVERDUE, CONFIRM, VOID;

	
	public static ManualAdjustmentStatus parse(final String value) {
		switch (value) {
			case "INITIATED":
				return INITIATED;
			case "PROGRESS":
				return PROGRESS;
			case "SUCCESS":
				return SUCCESS;
			case "FAILED":
				return FAILED;
			case "REJECTED":
				return REJECTED;
			case "OVERDUE":
				return OVERDUE;
			case "CONFIRM":
				return CONFIRM;
			default:
				return VOID;
		}
	}
}
