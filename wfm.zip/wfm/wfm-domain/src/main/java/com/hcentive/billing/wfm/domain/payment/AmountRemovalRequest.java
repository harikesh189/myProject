package com.hcentive.billing.wfm.domain.payment;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.FinancialEventContext;
import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;

@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_amount_removal_request")
public class AmountRemovalRequest<T extends AmountRemovalDetail> extends AbstractMongoEntity 
		implements FinancialEventContext {

	private static final long serialVersionUID = 1L;
	
	public static enum RequestStatus {
		PENDING, PROCESS_INIT_STARTED, PROCESS_INITIATED, COMPLETED
	}
	
	private String description;
	
	private T removalDetail;
	
	private RequestStatus status;
	
	protected AmountRemovalRequest() {
		super();
	}

	public AmountRemovalRequest(T removalDetail) {
		this(removalDetail, null);
	}
	
	public AmountRemovalRequest(T removalDetail, String description) {
		super();
		this.removalDetail = removalDetail;
		this.description = description;
		this.status = RequestStatus.PENDING;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public RequestStatus getStatus() {
		return status;
	}

	public void setStatus(RequestStatus status) {
		this.status = status;
	}

	public T getRemovalDetail() {
		return removalDetail;
	}

	public void setRemovalDetail(T removalDetail) {
		this.removalDetail = removalDetail;
	}

	@Override
	public String toString() {
		return "AmountRemovalRequest [removalDetail=" + removalDetail
				+ ", status=" + status + ", identity=" + identity + "]";
	}	

}
