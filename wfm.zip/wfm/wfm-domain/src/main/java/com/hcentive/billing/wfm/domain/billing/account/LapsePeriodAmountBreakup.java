package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.wfm.api.AmountCategory;

@Entity
@Table(name = "reinstatement_lapse_period_amount_breakup")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class LapsePeriodAmountBreakup extends BaseEntity implements TenantAware {
	
	private static final long serialVersionUID = 4336328389716781697L;
	
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "lapse_period_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "lapse_period_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "lapse_period_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "lapse_period_amount_short_name")) })
	 Amount lapsePeriodAmount;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "category")
	AmountCategory amountCategory;
	
	@Access(AccessType.FIELD)
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "lapse_period_begins")),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "lapse_period_ends")) })
	@Embedded
	Period lapsePeriod;
	
	
	public LapsePeriodAmountBreakup(Amount lapsePeriodAmount,
			AmountCategory amountCategory, Period lapsePeriod) {
		super();
		this.lapsePeriodAmount = lapsePeriodAmount;
		this.amountCategory = amountCategory;
		this.lapsePeriod = lapsePeriod;
	}
	
	public LapsePeriodAmountBreakup() {
		super();
	}

	public Amount getLapsePeriodAmount() {
		return lapsePeriodAmount;
	}
	public AmountCategory getAmountCategory() {
		return amountCategory;
	}
	public Period getLapsePeriod() {
		return lapsePeriod;
	}
	@Override
	public String getTenantId() {
		return ProcessContext.get().getTenantId();
	}
	
	
	
}
