package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.FinancialPartner;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;



@Entity
@Table(name = "health_plan")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "billing_plan_type")
public abstract class BillingPlan extends ReferenceableDomainEntity<BillingPlan, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 770881410007977673L;
	
	@OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinColumn(name = "carrier_id")
	@Access(AccessType.FIELD)
	protected FinancialPartner carrier;

	@Access(AccessType.FIELD)
	@Column(name = "name")
	protected String name;

	@Column(name = "product_type")
	@Access(AccessType.FIELD)
	protected String productType;

	public FinancialPartner getCarrier() {
		return carrier;
	}

	public void setCarrier(FinancialPartner carrier) {
		this.carrier = carrier;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	@Override
	public String refValue() {
		return identity;
	}

}
