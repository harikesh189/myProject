package com.hcentive.billing.wfm.api.enumeration.eligibility;

import javax.persistence.Embeddable;

@Embeddable
public enum MaintenanceReasonCode {
	
	DIVORCE("01"),
	BIRTH("02"),
	DEATH("03"),
	RETIREMENT("04"),
	ADOPTION("05"),
	STRIKE("06"),
	TERMINATION_OF_BENEFITS("07"),
	TERMINATION_OF_EMPLOYEMENT("08"),
	COBRA("09"),
	COBRA_PREMIUM_PAID("10"),
	SURVIVING_SPOUSE("11"),
	VOLUNTARY_WITHDRAWAL("14"),
	PCP_CHANGE("15"),
	QUIT("16"),
	FIRED("17"),
	SUSPENDED("18"),
	ACTIVE("20"),
	DIABILITY("21"),
	PLAN_CHANGE("22"),
	CHANGE_IN_IDENTIFYING_DATA("25"),
	DECLINED_COVERAGE("26"),
	PRE_ENROLLMENT("27"),
	INITIAL_ENROLLMENT("28"),
	BENEFIT_SELECTION("29"),
	LEGAL_SEPARATION("31"),
	MARRIAGE("32"),
	PERSONAL_DATA("33"),
	LEAVE_OF_ABSENCE_WITH_BENEFITS("37"),
	LEAVE_OF_ABSENCE_WITHOUT_BENEFITS("38"),
	LAYOFF_WITH_BENEFITS("39"),
	LAYOFF_WITHOUT_BENEFITS("40"),
	REENROLLMENT("41"),
	CHANGE_OF_LOCATION("43"),
	NON_PAYMENT("59"),
	MEMBER_BENEFIT_SELECTION("EC"),
	NO_REASON_GIVEN("AI"),
	NOTIFICATION_ONLY("XN"),
	TRANSFER("XT"),
	ALGORITHM_ASSIGNED_BENEFIT_SELECTION("AL"),
	DISSATISFACTION_WITH_OFFICE_STAFFS("AA"),
	DISSATISFACTION_WITH_MEDICAL_CARE("AB"),
	INCONVENIENT_OFFICE_LOCATION("AC"),
	DISSATISFACTION_WITH_OFFICE_HOURS("AD"),
	UNABLE__TO_SCHEDULE_APPOINTMENT_IN_TIMELY_MANNER("AE"),
	DISSATISFACTION_WITH_PHYSICIAN_REFERAL_POLICY("AF"),
	LESS_ATTENTION_TIME_GIVEN_THAN_OTHER_PATIENTS("AG"),
	PATIENT_MOVED_TO_NEW_LOCATION("AH"),
	APPOINTMENT_TIME_NOT_MET_IN_TIMELY_MANNER("AJ");
	
	private String code;

	MaintenanceReasonCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
	
	public static MaintenanceReasonCode processReasonCode(String maintenanceReasonCode){
		if(maintenanceReasonCode!=null){
			for (MaintenanceReasonCode reasonCode : MaintenanceReasonCode.values()) {
				if(maintenanceReasonCode.equalsIgnoreCase(reasonCode.getCode())){
					return reasonCode;
				}
			}
		}
		return null;
	}
}
