/**
 * 
 */
package com.hcentive.wfm.checkpoint.rule;

import java.util.List;

import com.hcentive.billing.wfm.api.BillRunType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.DelinquencyRuleType;

/**
 * @author sambhav.jain
 *
 */
public class DelinquencyCheckpointRule extends CheckpointRule {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7895502505976654993L;

	/**
	 * Default no-arg constructor that takes care of setting the rule
	 * {@link ConfigType} to DELINQUENCY_RULE
	 */
	public DelinquencyCheckpointRule() {
		super(ConfigType.DELINQUENCY_RULE);
	}

	/**
	 * Type of invoices to which this rule applies.
	 */
	private List<BillRunType> invoiceTypes;

	private DelinquencyRuleType delinquencyRuleType;
	
	private boolean reinstatementAllowed = true;

	public DelinquencyRuleType getDelinquencyRuleType() {
		return delinquencyRuleType;
	}

	public void setDelinquencyRuleType(DelinquencyRuleType delinquencyRuleType) {
		this.delinquencyRuleType = delinquencyRuleType;
	}

	public List<BillRunType> getInvoiceTypes() {
		return invoiceTypes;
	}

	public void setInvoiceTypes(List<BillRunType> invoiceTypes) {
		this.invoiceTypes = invoiceTypes;
	}
	
	public boolean isReinstatementAllowed() {
		return reinstatementAllowed;
	}

	public void setReinstatementAllowed(boolean reinstatementAllowed) {
		this.reinstatementAllowed = reinstatementAllowed;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DelinquencyCheckpointRule [invoiceTypes=");
		builder.append(invoiceTypes);
		builder.append(", gracePeriod=");
		builder.append(gracePeriod);
		builder.append(", delinquencyCheckpoints=");
		builder.append(delinquencyCheckpoints);
		builder.append(", active=");
		builder.append(active);
		builder.append(", reinstatementAllowed=");
		builder.append(reinstatementAllowed);
		builder.append("]");
		return builder.toString();
	}

}
