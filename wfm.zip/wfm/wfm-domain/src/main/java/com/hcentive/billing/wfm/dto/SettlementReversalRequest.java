package com.hcentive.billing.wfm.dto;

import java.io.Serializable;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.FinancialEventContext;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType;

public class SettlementReversalRequest implements Serializable, FinancialEventContext {

	private static final long serialVersionUID = 1L;

	public static enum PostReversalAction {
		NONE, REGENERATE, REBILL
	}
	
	private Set<String> ftEntryIds;
	
	private ReversalCandidate reversalFor;
	
	private FinancialEventType eventType;

	private PostReversalAction postReversalAction;

	public Set<String> getFtEntryIds() {
		return ftEntryIds;
	}

	public void setFtEntryIds(Set<String> ftEntryIds) {
		this.ftEntryIds = ftEntryIds;
	}

	public ReversalCandidate getReversalFor() {
		return reversalFor;
	}

	public void setReversalFor(ReversalCandidate reversalFor) {
		this.reversalFor = reversalFor;
	}

	public FinancialEventType getEventType() {
		return eventType;
	}

	public void setEventType(FinancialEventType eventType) {
		this.eventType = eventType;
	}

	public PostReversalAction getPostReversalAction() {
		return postReversalAction;
	}

	public void setPostReversalAction(PostReversalAction postReversalAction) {
		this.postReversalAction = postReversalAction;
	}

	public static class ReversalCandidate {
		
		public static enum Type {
			INVOICE
		}
		
		private String identity;
		
		private String displayId;
		
		private Type candidateType;
		
		private String associatedBillingAccount;
		
		public Type getCandidateType() {
			return candidateType;
		}

		public void setCandidateType(Type candidateType) {
			this.candidateType = candidateType;
		}

		public String getIdentity() {
			return identity;
		}

		public void setIdentity(String identity) {
			this.identity = identity;
		}

		public String getDisplayId() {
			return displayId;
		}

		public void setDisplayId(String displayId) {
			this.displayId = displayId;
		}

		public String getAssociatedBillingAccount() {
			return associatedBillingAccount;
		}

		public void setAssociatedBillingAccount(String associatedBillingAccount) {
			this.associatedBillingAccount = associatedBillingAccount;
		}

		@Override
		public String toString() {
			return "ReversalCandidate [identity=" + identity + ", displayId="
					+ displayId + ", candidateType=" + candidateType
					+ ", associatedBillingAccount=" + associatedBillingAccount
					+ "]";
		}
		
	}

	@Override
	public String toString() {
		return "SettlementReversalRequest [ftEntryIds=" + ftEntryIds
				+ ", reversalFor=" + reversalFor + ", eventType=" + eventType
				+ ", postReversalAction=" + postReversalAction + "]";
	}
	
}
