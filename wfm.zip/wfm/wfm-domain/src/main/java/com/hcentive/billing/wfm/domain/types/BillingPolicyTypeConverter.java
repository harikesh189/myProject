/**
 * 
 */
package com.hcentive.billing.wfm.domain.types;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.hcentive.billing.core.commons.domain.converter.MongoFacadeFactory;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingPolicy;

/**
 * 
 * @author manish.bothiyal
 * 
 */
@Converter
public class BillingPolicyTypeConverter implements
		AttributeConverter<BillingPolicy, String> {

	private static final Logger log = LoggerFactory
			.getLogger(BillingPolicyTypeConverter.class);

	@Override
	public String convertToDatabaseColumn(BillingPolicy billingPolicy) {
		return billingPolicy.getId();
	}

	@Override
	public BillingPolicy convertToEntityAttribute(String mongoId) {
		log.debug("Converter Get operation for BillingPolicy");
		MongoTemplate mongoTemplate = MongoFacadeFactory.getMongoTemplate();
		if (null != mongoTemplate) {
			return mongoTemplate.findById(mongoId, BillingPolicy.class);
		} else {
			log.error("mongoTemplate was found as null");
			return null;
		}
	}

}
