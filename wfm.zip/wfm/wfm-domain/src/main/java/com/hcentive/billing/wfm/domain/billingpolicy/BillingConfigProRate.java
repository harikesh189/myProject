package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;

/**
 * It represent the billing configuration to prorate premium, discount and fee.
 * 
 * @author nitin.singla
 */
public class BillingConfigProRate extends BillingRuleConfig {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@Min(0)
	@Max(999999999)
	private int coverageDays;

	@Min(0)
	@Max(999999999)
	private int endMonthlyCutoff;

	@NotNull
	private ProRateStrategy proRateStrategy;

	@Min(0)
	@Max(999999999)
	private int startMonthlyCutoff;

	public BillingConfigProRate() {
		super(ConfigType.PRO_RATE_BILLING);
	}

	public int getCoverageDays() {
		return this.coverageDays;
	}

	public int getEndMonthlyCutoff() {
		return this.endMonthlyCutoff;
	}

	public ProRateStrategy getProRateStrategy() {
		return this.proRateStrategy;
	}

	public int getStartMonthlyCutoff() {
		return this.startMonthlyCutoff;
	}

	public void setCoverageDays(final int coverageDays) {
		this.coverageDays = coverageDays;
	}

	public void setEndMonthlyCutoff(final int endMonthlyCutoff) {
		this.endMonthlyCutoff = endMonthlyCutoff;
	}

	public void setProRateStrategy(final ProRateStrategy proRateStrategy) {
		this.proRateStrategy = proRateStrategy;
	}

	public void setStartMonthlyCutoff(final int startMonthlyCutoff) {
		this.startMonthlyCutoff = startMonthlyCutoff;
	}

}
