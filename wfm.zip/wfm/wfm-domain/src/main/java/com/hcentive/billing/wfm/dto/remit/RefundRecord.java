package com.hcentive.billing.wfm.dto.remit;

import java.io.Serializable;

import com.hcentive.billing.wfm.dto.AbstractSettlementRecord;

public class RefundRecord extends AbstractSettlementRecord<RefundRecord> implements Serializable {

	private static final long serialVersionUID = 1L;

	private String paymentRecordIdentity;

	public String getPaymentRecordIdentity() {
		return paymentRecordIdentity;
	}

	public void setPaymentRecordIdentity(String paymentRecordIdentity) {
		this.paymentRecordIdentity = paymentRecordIdentity;
	}

	@Override
	public String toString() {
		return "RefundRecord [paymentRecordIdentity=" + paymentRecordIdentity + ", " + super.toString() + "]";
	}

	@Override
	public RefundRecord clone() {
		RefundRecord cloneObj = new RefundRecord();
		copyValues(this, cloneObj);
		cloneObj.setPaymentRecordIdentity(getPaymentRecordIdentity());
		return cloneObj;
	}
}
