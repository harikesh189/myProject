package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * 
 */
public enum RemitScheduleStrategy {
	DAY_OF_SCHEDULE, LAST_DAY_OF_SCHEDULE;
}
