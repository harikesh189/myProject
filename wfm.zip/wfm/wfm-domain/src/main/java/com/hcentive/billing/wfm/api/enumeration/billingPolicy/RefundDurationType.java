package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * It represent the type of refund duration.
 * 
 * @author nitin.singla
 * 
 */
public enum RefundDurationType {
	/**
	 * It represent that refund duration is biweekly.
	 */
	DAY,
	/**
	 * 
	 */
	MONTH
}
