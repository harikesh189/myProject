package com.hcentive.billing.wfm.domain.ft.rule;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
@DiscriminatorValue("EventRecordAttrRef")
public class EventRecordAttrRef extends
		GLEntryAttributeRef<EventRecordAttrRefData> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "event_record_ref_data_id")
	@Access(AccessType.FIELD)
	private EventRecordAttrRefData refData;

	private EventRecordAttrRef() {
	}

	public EventRecordAttrRef(final EventRecordAttrRefData refData) {
		this.refData = refData;
	}

	@Override
	public EventRecordAttrRefData refData() {
		return this.refData;
	}

}
