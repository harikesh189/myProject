package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

public class BillingConfigFlatDiscount extends BillingConfigDiscount<Amount>
		implements AmountAware {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	private Amount amount;

	@Override
	public Amount getAmount() {
		return this.amount;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	@Override
	public Amount value() {
		return this.getAmount();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.core.commons.api.Effectivity#effectivePeriod()
	 */
	@Override
	public Period effectivePeriod() {
		return period;
	}

}
