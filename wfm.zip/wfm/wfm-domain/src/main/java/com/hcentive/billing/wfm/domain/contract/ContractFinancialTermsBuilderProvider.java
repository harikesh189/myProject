/**
 * 
 */
package com.hcentive.billing.wfm.domain.contract;

import org.springframework.stereotype.Component;

/**
 * @author Dikshit.Vaid
 */
@Component
public class ContractFinancialTermsBuilderProvider {

	private static ContractFinancialTermsBuilder contractFinancialTermsBuilder;

	/**
	 * @return
	 */
	public static ContractFinancialTermsBuilder get() {
		return contractFinancialTermsBuilder;
	}

	public static void registerFinancialTermsBuilder(final ContractFinancialTermsBuilder builder) {
		contractFinancialTermsBuilder = builder;
	}
}
