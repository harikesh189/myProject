package com.hcentive.billing.wfm.dto;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.FinancialEventContext;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@SuppressWarnings("rawtypes")
public class PaymentRecordDTO implements FinancialEventContext, Serializable {

	private static final long serialVersionUID = 1L;

	private Amount amountPaid;

	private String identity;

	private BusinessEntity payer;

	private BillingAccount paymentFor;

	private DateTime txnDate;

	public PaymentRecordDTO() {
		super();
	}

	public PaymentRecordDTO(Amount amountPaid, BusinessEntity payer,
			BillingAccount paymentFor) {
		super();
		this.amountPaid = amountPaid;
		this.payer = payer;
		this.paymentFor = paymentFor;
	}



	public Amount getAmountPaid() {
		return amountPaid;
	}

	public String getIdentity() {
		return identity;
	}

	public BusinessEntity getPayer() {
		return payer;
	}

	public BillingAccount getPaymentFor() {
		return paymentFor;
	}

	public DateTime getTxnDate() {
		return txnDate;
	}

	public void setAmountPaid(Amount amountPaid) {
		this.amountPaid = amountPaid;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public void setPayer(BusinessEntity payer) {
		this.payer = payer;
	}

	public void setPaymentFor(BillingAccount paymentFor) {
		this.paymentFor = paymentFor;
	}

	public void setTxnDate(DateTime txnDate) {
		this.txnDate = txnDate;
	}

}
