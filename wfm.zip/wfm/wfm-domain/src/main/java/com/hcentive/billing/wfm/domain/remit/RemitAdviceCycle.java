package com.hcentive.billing.wfm.domain.remit;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigRemittance;
import com.hcentive.billing.wfm.domain.types.BillingConfigRemittanceTypeConverter;

@Entity
@Table(name = "remit_advice_cycle")
public class RemitAdviceCycle extends
		ReferenceableDomainEntity<RemitAdviceCycle, String> {

	private static final long serialVersionUID = -5116425142186038020L;

	@Column(name = "entities_count")
	@Access(AccessType.FIELD)
	private int entitiesCount;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "remit_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "remit_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "remit_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "remit_amount_short_name")) })
	@Access(AccessType.FIELD)
	private Amount remitAmount;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "remit_begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "remit_ends_on")) })
	@Access(AccessType.FIELD)
	private Period remitPeriod;

	@Convert(converter = BillingConfigRemittanceTypeConverter.class)
	@Column(name = "remittance_config_id", nullable = false, unique = false)
	private BillingConfigRemittance remittanceConfig;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "run_date")) })
	@Access(AccessType.FIELD)
	private DateTime runDate;

	@Enumerated(EnumType.STRING)
	@Column(name = "run_status")
	private RunStatus runStatus;

	public int getEntitiesCount() {
		return this.entitiesCount;
	}

	public Amount getRemitAmount() {
		return this.remitAmount;
	}

	public Period getRemitPeriod() {
		return this.remitPeriod;
	}

	public BillingConfigRemittance getRemittanceConfig() {
		return this.remittanceConfig;
	}

	public DateTime getRunDate() {
		return this.runDate;
	}

	public RunStatus getRunStatus() {
		return this.runStatus;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setEntitiesCount(final int entitiesCount) {
		this.entitiesCount = entitiesCount;
	}

	public void setRemitAmount(final Amount invoiceAmount) {
		this.remitAmount = invoiceAmount;
	}

	public void setRemitPeriod(final Period remitPeriod) {
		this.remitPeriod = remitPeriod;
	}

	public void setRemittanceConfig(
			final BillingConfigRemittance remittanceConfig) {
		this.remittanceConfig = remittanceConfig;
	}

	public void setRunDate(final DateTime runDate) {
		this.runDate = runDate;
	}

	public void setRunStatus(final RunStatus runStatus) {
		this.runStatus = runStatus;
	}

	@Override
	public String typeName() {
		return "RemitAdviceCycle";
	}

}
