package com.hcentive.billing.wfm.domain.eighttwenty;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.hcentive.billing.core.commons.api.BusinessEntityAware;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.wfm.api.enumeration.PaymentRecordType;
import com.hcentive.billing.wfm.domain.payment.AbstractPaymentRecord;

@Entity
@DiscriminatorValue("Outbound_Payment_Record")
public class OutboundPaymentRecord extends AbstractPaymentRecord implements BusinessEntityAware<BusinessEntity>{
	
	public static final String BANK_ACCOUNT = "ACH";

	public static String OUTBOUND_TYPE = "Outbound_Payment_Request";
	
	@Column(name = "source_ref_id")
	private String sourceRefId;
	
	@Column(name = "payment_mode")
	private String paymentMode;

	@Column(name = "gateway_confirmation_number")
	private String gatewayConfirmationNumber;
	
	@Column(name = "record_type")
	@Enumerated(EnumType.STRING)
	private PaymentRecordType recordType;
	
	@Override
	public String typeName() {
		return "Outbound_Payment_Record";
	}

	@Override
	public Object refValue() {
		return null;
	}

	public String getSourceRefId() {
		return sourceRefId;
	}

	public void setSourceRefId(String sourceRefId) {
		this.sourceRefId = sourceRefId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getGatewayConfirmationNumber() {
		return gatewayConfirmationNumber;
	}

	public void setGatewayConfirmationNumber(String gatewayConfirmationNumber) {
		this.gatewayConfirmationNumber = gatewayConfirmationNumber;
	}

	@Override
	public void setBusinessEntity(BusinessEntity businessEntity) {
		setPayee(businessEntity);
	}

	public PaymentRecordType getRecordType() {
		return recordType;
	}

	public void setRecordType(PaymentRecordType recordType) {
		this.recordType = recordType;
	}
}
