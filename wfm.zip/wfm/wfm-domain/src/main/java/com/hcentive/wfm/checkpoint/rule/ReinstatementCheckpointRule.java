/**
 * 
 */
package com.hcentive.wfm.checkpoint.rule;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BillingRulePeriodType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

/**
 * 
 * It represent the billing configuration for reinstatement purpose.
 * 
 * @author sambhav.jain
 *
 */
public class ReinstatementCheckpointRule extends CheckpointRule {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 250385066551343966L;

	/**
	 * It defines how to define the reinstatement period. WFM will use number of
	 * Days and/or number of Months in the reinstatement rule to determine the
	 * reinstatement period.
	 */
	@NotNull
	private BillingRulePeriodType periodType;

	/**
	 * It represent the look back periods/timeframe for the reinstatement, if
	 * Entity is allowed for reinstatement.
	 */
	@Min(0)
	@Max(999999)
	private int periodValue;

	@Min(0)
	private Integer allowedReinstatementCycles;

	public Integer getAllowedReinstatementCycles() {
		return this.allowedReinstatementCycles;
	}

	public void setAllowedReinstatementCycles(Integer allowedReinstatementCycles) {
		this.allowedReinstatementCycles = allowedReinstatementCycles;
	}

	public ReinstatementCheckpointRule() {
		super(ConfigType.REINSTATEMENT);
	}

	public BillingRulePeriodType getPeriodType() {
		return periodType;
	}

	public int getPeriodValue() {
		return periodValue;
	}

	public void setPeriodValue(int periodValue) {
		setGracePeriod(periodValue, periodType);
		this.periodValue = periodValue;
	}

	private void setGracePeriod(int periodValue, BillingRulePeriodType periodType) {
		final Calendar today = Calendar.getInstance();
		final Calendar future = Calendar.getInstance();
		if (BillingRulePeriodType.MONTHS == periodType) {
			future.add(Calendar.MONTH, periodValue);
			long diff = future.getTime().getTime() - today.getTime().getTime();
			this.gracePeriod = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		} else {
			this.gracePeriod = periodValue;
		}
	}

	public void setPeriodType(BillingRulePeriodType periodType) {
		this.periodType = periodType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ReinstatementCheckpointRule [periodType=");
		builder.append(periodType);
		builder.append(", periodValue=");
		builder.append(periodValue);
		builder.append(", gracePeriod=");
		builder.append(gracePeriod);
		builder.append(", delinquencyCheckpoints=");
		builder.append(delinquencyCheckpoints);
		builder.append("]");
		return builder.toString();
	}

}
