package com.hcentive.billing.wfm.dto;

import java.io.Serializable;
import java.util.Date;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.bill.invoice.WFMInvoice.Status;

/**
 * DTO for invoice status change processing.
 *
 * @author sambhav.jain
 *
 */
public class InvoiceSettledEventDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private String billingAccountIdentity;
	private String invoiceIdentity;
	private Status status;
	private DateTime invoiceGenerationDateTime;
	private Period period;
	private Date settlementDate;

	public InvoiceSettledEventDTO() {
	}

	/**
	 * @param billingAccountId
	 * @param invoiceIdentity
	 * @param status
	 */
	public InvoiceSettledEventDTO(final String billingAccountId, final String invoiceIdentity, final Status status, final DateTime invoiceGenerationDateTime,
			final Period period, final Date settlementDate) {
		super();
		this.billingAccountIdentity = billingAccountId;
		this.invoiceIdentity = invoiceIdentity;
		this.status = status;
		this.invoiceGenerationDateTime = invoiceGenerationDateTime;
		this.period = period;
		this.settlementDate = settlementDate;
	}

	/**
	 * @return the billingAccountIdentity
	 */
	public String getBillingAccountIdentity() {
		return this.billingAccountIdentity;
	}

	public DateTime getInvoiceGenerationDateTime() {
		return this.invoiceGenerationDateTime;
	}

	/**
	 * @return the invoiceIdentity
	 */
	public String getInvoiceIdentity() {
		return this.invoiceIdentity;
	}

	public Period getPeriod() {
		return this.period;
	}

	public Date getSettlementDate() {
		return this.settlementDate;
	}

	/**
	 * @return the status
	 */
	public Status getStatus() {
		return this.status;
	}

	/**
	 * @param billingAccountIdentity
	 *            the billingAccountIdentity to set
	 */
	public void setBillingAccountIdentity(final String billingAccountIdentity) {
		this.billingAccountIdentity = billingAccountIdentity;
	}

	public void setInvoiceGenerationDateTime(final DateTime invoiceGenerationDateTime) {
		this.invoiceGenerationDateTime = invoiceGenerationDateTime;
	}

	/**
	 * @param invoiceIdentity
	 *            the invoiceIdentity to set
	 */
	public void setInvoiceIdentity(final String invoiceIdentity) {
		this.invoiceIdentity = invoiceIdentity;
	}

	public void setPeriod(final Period period) {
		this.period = period;
	}

	public void setSettlementDate(final Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(final Status status) {
		this.status = status;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InvoiceSettledEventDTO [billingAccountId=" + this.billingAccountIdentity + ", invoiceIdentity=" + this.invoiceIdentity + ", status="
		        + this.status + "]";
	}

}
