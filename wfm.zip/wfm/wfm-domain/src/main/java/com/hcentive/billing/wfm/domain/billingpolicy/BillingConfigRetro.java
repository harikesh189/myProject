package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.PeriodType;

/**
 * It represent the billing configuration from retroactivity purpose.
 * 
 * @author nitin.singla
 */
public class BillingConfigRetro extends BillingRuleConfig {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * It defines how to define the retroactivity period. WFM will use number of
	 * Days and/or number of Months in the retroactive rule to determine the
	 * retroactive period.
	 */
	@NotNull
	private PeriodType periodType;

	/**
	 * It represent the look back periods/timeframe for the Retroactivity, if
	 * Entity is allowed for retroactivity.
	 */
	@Min(0)
	@Max(999999)
	private int periodValue;

	public BillingConfigRetro() {
		super(ConfigType.RETRO_BILLING);
	}

	/**
	 * Gets the type of retroactivity period.
	 * 
	 * @return The type of retroactivity period.
	 */
	public PeriodType getPeriodType() {
		return this.periodType;
	}

	/**
	 * Gets the value of retroactivity period.
	 * 
	 * @return The value of retroactivity period.
	 */
	public int getPeriodValue() {
		return this.periodValue;
	}

	/**
	 * Sets the type of retroactivity period.
	 * 
	 * @param periodType
	 *            The type of retroactivity period to set.
	 */
	public void setPeriodType(final PeriodType periodType) {
		this.periodType = periodType;
	}

	/**
	 * Sets the value of retroactivity period.
	 * 
	 * @param periodValue
	 *            The value of retroactivity period to set.
	 */
	public void setPeriodValue(final int periodValue) {
		this.periodValue = periodValue;
	}

}
