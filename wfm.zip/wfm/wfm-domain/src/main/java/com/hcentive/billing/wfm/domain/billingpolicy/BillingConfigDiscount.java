package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

/**
 * It represent the bill configuration related to calculation of discount.
 * 
 * @author nitin.singla
 */
public abstract class BillingConfigDiscount<V> extends FinancialCharge<V> {

	private static final long serialVersionUID = 1L;
	/**
	 * It represent the type of discount.
	 */
	private String type;

	public BillingConfigDiscount() {
		super(ConfigType.DISCOUNT);
	}

	public String getType() {
		return this.type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	@Override
	public String name() {
		return this.getType();
	}
}
