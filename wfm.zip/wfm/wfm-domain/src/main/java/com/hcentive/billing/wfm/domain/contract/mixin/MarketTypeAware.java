package com.hcentive.billing.wfm.domain.contract.mixin;

import java.util.Collection;

public interface MarketTypeAware {
	Collection<String> getMarketTypes();
}
