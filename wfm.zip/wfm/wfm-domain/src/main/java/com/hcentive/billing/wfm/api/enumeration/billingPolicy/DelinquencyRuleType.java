package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum DelinquencyRuleType {
	BINDER, REGULAR;
}
