/**
 * 
 */
package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;

import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;

/**
 * @author Dikshit.Vaid
 */
public interface ContractFinancialTermsBuilder {

	/**
	 * @param eligibilityContract
	 * @param effectivePeriod
	 * @return
	 */
	Collection<FinancialTerm<?>> buildFinancialTerms(BillRunContext billRunContext);
}
