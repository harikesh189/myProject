package com.hcentive.billing.wfm.api;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.hcentive.billing.condition.ConditionContextResolverAware;
import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.ReferenceSet;
import com.hcentive.billing.core.commons.tags.TagAware;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventQualifier;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType;

public abstract class FinancialEventRecord implements TagAware<String>, Effectivity, ConditionContextResolverAware {

	private final Map<String, FinancialEventRecordAttr<?>> attributeMap = new HashMap<>();
	private String eventId;
	private String eventAdditionalId;

	private ReferenceSet references;
	private FinancialEventType type;
	private FinancialEventQualifier qualifier;

	public FinancialEventRecord() {
		this.qualifier = FinancialEventQualifier.DEFAULT;
	}

	public void addAttribute(final FinancialEventRecordAttr<?> attribute) {
		this.attributeMap.put(attribute.getCode(), attribute);
	}

	public FinancialEventRecord(final String eventId, final String eventAdditionalId, 
			final ReferenceSet references, final FinancialEventType type, final FinancialEventQualifier qualifier) {
		super();
		this.eventId = eventId;
		this.eventAdditionalId = eventAdditionalId;
		this.references = references;
		this.type = type;
		this.qualifier = qualifier;
	}

	@SuppressWarnings("rawtypes")
	public FinancialEventRecordAttr getAttribute(final String code) {
		final FinancialEventRecordAttr attr = this.attributeMap.get(code);
		if (attr != null) {
			return attr;
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public <T> T getAttributeValue(final String code, final Class<T> clazz) {
		final FinancialEventRecordAttr<T> attr = (FinancialEventRecordAttr<T>) this.attributeMap.get(code);
		if (attr != null) {
			return attr.getValue();
		}
		return null;
	}

	public String getEventId() {
		return this.eventId;
	}

	public ReferenceSet getReferences() {
		return this.references;
	}

	public FinancialEventType getType() {
		return this.type;
	}

	public void setEventId(final String eventId) {
		this.eventId = eventId;
	}

	public void setReferences(final ReferenceSet references) {
		this.references = references;
	}

	public void setType(final FinancialEventType type) {
		this.type = type;
	}

	public FinancialEventQualifier getQualifier() {
		return this.qualifier;
	}

	public void setQualifier(final FinancialEventQualifier qualifier) {
		this.qualifier = qualifier;
	}

	@Override
	public Collection<String> tags() {
		final Set<String> keySet = this.attributeMap.keySet();
		return keySet;
	}

	public String getEventAdditionalId() {
		return eventAdditionalId;
	}

	public void setEventAdditionalId(String eventAdditionalId) {
		this.eventAdditionalId = eventAdditionalId;
	}
	
}
