package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.wfm.api.InsuranceCoverageAware;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingPolicy;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingRuleConfig;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;
import com.hcentive.billing.wfm.domain.contract.ContractInfo;
import com.hcentive.billing.wfm.domain.types.BillRunDataType;

@Entity
@Table(name = "bill_run_context")
public class BillRunContext extends ReferenceableDomainEntity<BillRunContext, String> {

	private static final long serialVersionUID = 1L;

	@Embedded
	private Period coveragePeriod;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "billing_contract_run_id")
	private BillingContractRun billingContractRun;

	@Column(name = "bill_run_data_mongo_id")
	@Convert(converter = BillRunDataType.class)
	private BillRunData billRunData;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "original_run_context_id")
	private BillRunContext originalBillRunContext;

	@Column(name = "retro")
	private boolean retro;

	@Column(name = "rerun")
	private boolean rerun;

	@Column(name = "active")
	private boolean active = true;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "bill_run_context_contract_amounts", joinColumns = @JoinColumn(name = "bill_run_context_id"), inverseJoinColumns = @JoinColumn(
	        name = "contract_amounts_id"))
	private Set<BillAmount> contractAmounts;

	@Transient
	private boolean initialized;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "bill_run_context_plan_amounts", joinColumns = @JoinColumn(name = "bill_run_context_id"), inverseJoinColumns = @JoinColumn(
	        name = "plan_amounts_id"))
	@MapKeyColumn(name = "plan_id", table = "bill_run_context_plan_amounts")
	private Map<Long, InsuranceCoverageBillAmount> planAmounts;

	public BillRunContext(final Period billingPeriod) {
		this.coveragePeriod = billingPeriod;
		this.contractAmounts = new HashSet<>();
		this.planAmounts = new HashMap<>();
	}

	protected BillRunContext() {
	}

	public void addBillAmount(final BillAmount billAmt) {
		if (billAmt instanceof InsuranceCoverageAware) {
			this.addPlanLevelAmount(((InsuranceCoverageAware) billAmt).insuranceCoverage(), billAmt);
		} else {
			this.addContractLevelAmount(billAmt);
		}
	}

	public void addContractLevelAmount(final BillAmount billAmount) {
		this.contractAmounts.add(billAmount);
	}

	public void addPlanLevelAmount(final Long planId, final BillAmount billAmount) {

		InsuranceCoverageBillAmount planBillAmt = getPlanAmounts().get(planId);

		if (planBillAmt == null) {
			planBillAmt = new InsuranceCoverageBillAmount();
			planBillAmt.setPlanId(planId);

			this.getPlanAmounts().put(planId, planBillAmt);
		}

		planBillAmt.addBillAmount(billAmount);
	}

	@SuppressWarnings("unchecked")
	public AbstractFinancialContract<ContractInfo> contract() {
		return this.getBillRunData().getContract();
	}

	public BillingPolicy contractBillingPolicy() {
		return this.getBillRunData().getContractBillingPolicy();
	}

	public Period getCoveragePeriod() {
		return this.coveragePeriod;
	}

	public BillRunData getBillRunData() {
		return this.billRunData;
	}

	public void setBillRunData(final BillRunData billRunData) {
		this.billRunData = billRunData;
	}

	public Set<BillAmount> getContractAmounts() {
		return this.contractAmounts;
	}

	public Map<Long, InsuranceCoverageBillAmount> getPlanAmounts() {
		return this.planAmounts;
	}

	public Set<BillAmount> getPlanAmounts(final Long planId) {
		final InsuranceCoverageBillAmount billAmounts = this.planAmounts.get(planId);
		return billAmounts != null ? billAmounts.getBillAmounts() : null;
	}

	public Set<BillingRuleConfig> getPolicyConfigsByType(final ConfigType type) {
		return this.getBillRunData().getContractBillingPolicy().getPolicyConfigsByType(type);
	}

	/**
	 * @return the retro
	 */
	public boolean isRetro() {
		return this.retro;
	}

	/**
	 * @param retro the retro to set
	 */
	public void setRetro(final boolean retro) {
		this.retro = retro;
	}

	public void initRun(final BillRunData billRunData) {
		this.billRunData = billRunData;
		this.initialized = true;
		this.planAmounts.clear();
		this.contractAmounts.clear();
	}

	public boolean isEffective(final Effectivity effObj) {
		return effObj.effectivePeriod().hasIntersection(this.coveragePeriod);
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setCoveragePeriod(final Period billingPeriod) {
		this.coveragePeriod = billingPeriod;
	}

	/**
	 * @return the originalBillRunContext
	 */
	public BillRunContext getOriginalBillRunContext() {
		return this.originalBillRunContext;
	}

	public boolean isBillable() {
		return this.originalBillRunContext == null;
	}

	/**
	 * @param originalBillRunContext the originalBillRunContext to set
	 */
	public void setOriginalBillRunContext(final BillRunContext originalBillRunContext) {
		this.originalBillRunContext = originalBillRunContext;
		originalBillRunContext.setActive(false);
		this.setRetro(true);
		this.setActive(false);
	}

	@Override
	public String typeName() {
		return "BillRunContext";
	}

	/**
	 * @return the billingContractRun
	 */
	public BillingContractRun getBillingContractRun() {
		return this.billingContractRun;
	}

	/**
	 * @param billingContractRun the billingContractRun to set
	 */
	public void setBillingContractRun(final BillingContractRun billingContractRun) {
		this.billingContractRun = billingContractRun;
	}

	public boolean isRerun() {
		return rerun;
	}

	public void setRerun(boolean rerun) {
		this.rerun = rerun;
	}

	/**
	 * @return the active
	 */
	public boolean isActive() {
		return this.active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(final boolean active) {
		this.active = active;
	}

	/*
	 * public BillingContractRun getBillingContractRun() { return this.billingContractRun; }
	 * 
	 * public void setBillingContractRun( final BillingContractRun billingContractRun) { this.billingContractRun = billingContractRun; }
	 */

}
