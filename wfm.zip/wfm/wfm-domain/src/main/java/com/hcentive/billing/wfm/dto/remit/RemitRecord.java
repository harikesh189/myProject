package com.hcentive.billing.wfm.dto.remit;

import java.io.Serializable;

import com.hcentive.billing.wfm.dto.AbstractSettlementRecord;

public class RemitRecord extends AbstractSettlementRecord<RemitRecord> implements Serializable {

	private static final long serialVersionUID = 1L;

	private String paymentRecordIdentity;
	private String partnerIdentity;

	public String getPaymentRecordIdentity() {
		return paymentRecordIdentity;
	}

	public void setPaymentRecordIdentity(String paymentRecordIdentity) {
		this.paymentRecordIdentity = paymentRecordIdentity;
	}

	@Override
	public String toString() {
		return "RemitRecord [paymentRecordIdentity=" + paymentRecordIdentity + ", " + "partnerIdentity=" + partnerIdentity + ", " + super.toString() + "]";
	}

	@Override
	public RemitRecord clone() {
		RemitRecord cloneObj = new RemitRecord();
		copyValues(this, cloneObj);
		cloneObj.setPaymentRecordIdentity(getPaymentRecordIdentity());
		cloneObj.setPartnerIdentity(getPartnerIdentity());
		return cloneObj;
	}

	public String getPartnerIdentity() {
		return partnerIdentity;
	}

	public void setPartnerIdentity(String partnerIdentity) {
		this.partnerIdentity = partnerIdentity;
	}
	
}
