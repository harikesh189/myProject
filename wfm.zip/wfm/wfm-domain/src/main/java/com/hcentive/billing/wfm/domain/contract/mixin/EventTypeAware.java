package com.hcentive.billing.wfm.domain.contract.mixin;


public interface EventTypeAware {
	String getEventType();
}
