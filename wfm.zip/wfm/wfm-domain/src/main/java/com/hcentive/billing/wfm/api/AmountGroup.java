package com.hcentive.billing.wfm.api;

public enum AmountGroup {

	DEFAULT, RETRO, CANCELLED;

	/**
	 * @param type
	 * @return
	 */
	public static AmountGroup parse(String type) {
		return AmountGroup.valueOf(type);
	}
}
