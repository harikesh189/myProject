package com.hcentive.billing.wfm.domain.contract;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

public class AmountFinancialTerm extends AbstractFinancialTerm<Amount> {

	private Amount amount;

	protected AmountFinancialTerm() {
		// DO NOT DELETE required by mongo
	}
	
	public AmountFinancialTerm(String type, String code, String name,
			Amount amount, Period effectivePeriod, String description) {
		super(type, code, name, effectivePeriod, description);
		this.amount = amount;
	}

	@Override
	public Amount value() {
		return amount;
	}

}
