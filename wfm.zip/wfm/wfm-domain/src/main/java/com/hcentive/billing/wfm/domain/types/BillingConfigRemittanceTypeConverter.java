/**
 * 
 */
package com.hcentive.billing.wfm.domain.types;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.hcentive.billing.core.commons.domain.converter.MongoFacadeFactory;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigRemittance;

@Converter
public class BillingConfigRemittanceTypeConverter implements
		AttributeConverter<BillingConfigRemittance, String> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(BillingConfigRemittanceTypeConverter.class);

	@Override
	public String convertToDatabaseColumn(
			BillingConfigRemittance billingConfigRemittance) {
		MongoTemplate mongoTemplate = MongoFacadeFactory.getMongoTemplate();
		if (billingConfigRemittance != null) {
			mongoTemplate.save(billingConfigRemittance);
			return billingConfigRemittance.getId();
		}
		return null;
	}

	@Override
	public BillingConfigRemittance convertToEntityAttribute(String mongoId) {
		LOGGER.debug("Converter Get operation for BillingConfigRemittance");
		MongoTemplate mongoTemplate = MongoFacadeFactory.getMongoTemplate();
		if (null != mongoTemplate) {
			return mongoTemplate.findById(mongoId,
					BillingConfigRemittance.class);
		} else {
			LOGGER.error("mongoTemplate was found as null");
			return null;
		}
	}

}
