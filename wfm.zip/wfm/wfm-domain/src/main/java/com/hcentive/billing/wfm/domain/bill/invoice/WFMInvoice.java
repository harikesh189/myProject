package com.hcentive.billing.wfm.domain.bill.invoice;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.BillRunType;
import com.hcentive.billing.wfm.api.FTEntryAware;
import com.hcentive.billing.wfm.domain.bill.BillArtifact;
import com.hcentive.billing.wfm.domain.contract.ContractMaintenanceUpdate;
import com.hcentive.billing.wfm.domain.contract.mixin.AdjustmentAmountAware;
import com.hcentive.billing.wfm.domain.contract.mixin.InvoiceTypeAware;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;

@Entity
@Table(name = "wfm_invoice")
public class WFMInvoice extends BillArtifact<WFMInvoiceSummary> implements InvoiceTypeAware, AdjustmentAmountAware {

	private static final long serialVersionUID = -4598514265071327666L;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "wfm_invoice_contract_bill_amounts", joinColumns = @JoinColumn(name = "wfm_invoice_id"), inverseJoinColumns = @JoinColumn(name = "contract_bill_amounts_id"))
	private final Set<ContractBillAmount> contractBillAmounts = new HashSet<ContractBillAmount>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "wfm_invoice_generic_amounts", joinColumns = @JoinColumn(name = "wfm_invoice_id"), inverseJoinColumns = @JoinColumn(name = "generic_amounts_id"))
	private final Set<BillAmount> genericAmounts = new HashSet<BillAmount>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "wfm_invoice_line_items", joinColumns = @JoinColumn(name = "wfm_invoice_id"), inverseJoinColumns = @JoinColumn(name = "line_items_id"))
	private final Set<WFMInvoiceLineItem> lineItems = new HashSet<WFMInvoiceLineItem>();

	@Column(name = "invoice_review_rule_identity")
	private String invoiceReviewRuleIdentity;

	@ElementCollection(fetch = FetchType.EAGER)
	@Column(name = "contract_maintenance_update_id")
	@CollectionTable(name = "contract_maintenance_update_ids", joinColumns = @JoinColumn(name = "wfm_invoice_id"))
	private Set<String> contractMaintenanceUpdateIds;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "invoice_review_end_date")) })
	private DateTime invoiceReviewEndDate;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private Status status;

	@Column(name = "latest")
	private boolean latest;
	
	@Column(name = "runout")
	private Boolean runout;

	public Boolean isRunout() {
		return runout;
	}

	public void setRunout(Boolean runout) {
		this.runout = runout;
	}

	@Enumerated(EnumType.STRING)
	@Column(name = "invoice_type")
	private BillRunType invoiceType = BillRunType.REGULAR;

	public WFMInvoice(final String identity, final WFMInvoiceSummary summary) {
		super(identity, summary);
		status = Status.REVIEW;
	}

	protected WFMInvoice() {
	}

	public void addContractBillAmount(final ContractBillAmount contractBillAmount) {

		final ContractBillAmount existingGrpBillAmt = findContractBillAmount(contractBillAmount.getContractId());

		for (final BillAmount billAmt : contractBillAmount.getBillAmounts()) {
			existingGrpBillAmt.addBillAmount(billAmt);
			categorizeBillAmount(billAmt);
		}

	}

	public void addContractMaintenanceUpdateIds(final Set<ContractMaintenanceUpdate> contractMaintenanceUpdateIds) {
		if (this.contractMaintenanceUpdateIds == null) {
			this.contractMaintenanceUpdateIds = new HashSet<>();
		}
		for (final ContractMaintenanceUpdate contractMaintenanceUpdate : contractMaintenanceUpdateIds) {
			this.contractMaintenanceUpdateIds.add(contractMaintenanceUpdate.getId());
		}
	}

	public void addGenericAmount(final BillAmount amount) {
		this.genericAmounts.add(amount);
		categorizeBillAmount(amount);
	}

	public Set<String> generationFTEntries() {

		final Set<String> ftEntryIds = new HashSet<>();

		for (final BillAmount billAmt : genericAmounts) {
			if (billAmt instanceof FTEntryAware) {
				ftEntryIds.addAll(((FTEntryAware) billAmt).ftEntryIds());
			}
		}

		for (final ContractBillAmount billAmt : contractBillAmounts) {
			ftEntryIds.addAll(billAmt.ftEntryIds());
		}

		return ftEntryIds;
	}

	@Override
	public Amount getAdjustmentAmount() {
		Amount adjAmt = Amount.newAmount(BigDecimal.ZERO);
		for (final WFMInvoiceLineItem lineItem : getLineItems()) {
			if (isAdjustmentLineItem(lineItem)) {
				adjAmt = adjAmt.add(lineItem.getTotalAmount());
			}
		}
		return adjAmt;
	}

	public Set<ContractBillAmount> getContractBillAmounts() {
		return contractBillAmounts;
	}

	public Set<String> getContractMaintenanceUpdateIds() {
		if (contractMaintenanceUpdateIds != null) {
			return Collections.unmodifiableSet(contractMaintenanceUpdateIds);
		}
		return Collections.unmodifiableSet(new HashSet<String>());
	}

	public Set<String> getFTEntries() {
		return generationFTEntries();
	}

	public Set<BillAmount> getGenericAmounts() {
		return genericAmounts;
	}

	public DateTime getInvoiceReviewEndDate() {
		return invoiceReviewEndDate;
	}

	public String getInvoiceReviewRuleIdentity() {
		return invoiceReviewRuleIdentity;
	}

	public BillRunType getInvoiceType() {
		return invoiceType;
	}

	@Override
	public Collection<String> getInvoiceTypes() {
		return CollectionUtil.asList(invoiceType.toString());
	}

	public Set<WFMInvoiceLineItem> getLineItems() {
		return Collections.unmodifiableSet(lineItems);
	}

	public Status getStatus() {
		return status;
	}

	@Override
	public WFMInvoiceSummary getSummary() {
		return super.getSummary();
	}

	public boolean isLatest() {
		return latest;
	}

	public boolean isRejected() {
		return this.status != null ? this.status == Status.REJECTED : false;
	}

	@Override
	public String refValue() {
		return getIdentity();
	}

	public void setInvoiceReviewEndDate(final DateTime invoiceReviewEndDate) {
		this.invoiceReviewEndDate = invoiceReviewEndDate;
	}

	public void setInvoiceReviewRuleIdentity(final String invoiceReviewRuleIdentity) {
		this.invoiceReviewRuleIdentity = invoiceReviewRuleIdentity;
	}

	public void setInvoiceType(final BillRunType invoiceType) {
		this.invoiceType = invoiceType;
	}

	public void setLatest(final boolean latest) {
		this.latest = latest;
	}

	public void setStatus(final Status status) {
		this.status = status;
	}

	@Override
	public String typeName() {
		return "WFMInvoice";
	}

	private void categorizeBillAmount(final BillAmount billAmt) {
		final WFMInvoiceLineItem lineItem = findLineItem(billAmt);
		lineItem.addBillAmount(billAmt);
	}

	private ContractBillAmount findContractBillAmount(final String contractId) {

		ContractBillAmount returnValue = null;

		for (final ContractBillAmount contractBillAmt : contractBillAmounts) {
			if (contractBillAmt.getContractId().equals(contractId)) {
				returnValue = contractBillAmt;
				break;
			}
		}

		if (returnValue == null) {
			returnValue = new ContractBillAmount(contractId);
			contractBillAmounts.add(returnValue);
		}

		return returnValue;
	}

	private WFMInvoiceLineItem findLineItem(final BillAmount billAmt) {

		for (final WFMInvoiceLineItem item : lineItems) {
			if (isMatching(item, billAmt)) {
				return item;
			}
		}

		final WFMInvoiceLineItem lineItem = new WFMInvoiceLineItem(billAmt.getAmountCategory(), billAmt.getAmountGroup());
		lineItems.add(lineItem);

		return lineItem;
	}

	private boolean isAdjustmentLineItem(final WFMInvoiceLineItem lineItem) {
		return AmountGroup.RETRO.equals(lineItem.getAmountGroup()) || AmountCategory.CREDIT.equals(lineItem.getCategory())
				|| AmountCategory.REFUND.equals(lineItem.getCategory()) || AmountCategory.WRITEOFF.equals(lineItem.getCategory())
				|| AmountCategory.WRITEON.equals(lineItem.getCategory());
	}

	private boolean isMatching(final WFMInvoiceLineItem lineItem, final BillAmount billAmt) {
		return lineItem.getCategory() == billAmt.getAmountCategory() && lineItem.getAmountGroup() == billAmt.getAmountGroup();
	}

	public static enum Status {
		REVIEW("REVIEW"), OPEN("OPEN"), SETTLED("SETTLED"), VOID("VOID"), 
		PARTIAL_PAYMENT("PARTIAL_PAYMENT"), REJECTED("REJECTED"), INITIATED("INITIATED"),
		REVERSAL_INITIATED("REVERSAL_INITIATED"), REJECTION_INITIATED("REJECTION_INITIATED");

		public static Status parse(final String value) {
			switch (value) {
			case "REVIEW":
				return REVIEW;
			case "OPEN":
				return OPEN;
			case "SETTLED":
				return SETTLED;
			case "PARTIAL_PAYMENT":
				return PARTIAL_PAYMENT;
			case "REJECTED":
				return REJECTED;
			case "INITIATED":
				return INITIATED;
			case "REVERSAL_INITIATED":
				return REVERSAL_INITIATED;
			case "REJECTION_INITIATED":
				return REJECTION_INITIATED;
			default:
				return VOID;
			}
		}

		private Status(final String name) {
		}
	}
}
