package com.hcentive.billing.wfm.domain.billingpolicy;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BufferPeriodStrategyType;
import com.hcentive.billing.wfm.dto.DatesHolder;
import com.hcentive.billing.wfm.dto.DatesHolder.DateType;

public class NumberOfDaysBufferPeriodStrategy extends BufferPeriodStrategy {

	private final static Logger logger = LoggerFactory
			.getLogger(NumberOfDaysBufferPeriodStrategy.class);

	private int bufferDays;

	public NumberOfDaysBufferPeriodStrategy(int bufferDays) {
		super(BufferPeriodStrategyType.NUMBER_OF_DAYS);
		this.bufferDays = bufferDays;
	}

	public int getBufferDays() {
		return bufferDays;
	}

	public void setBufferDays(int bufferDays) {
		this.bufferDays = bufferDays;
	}

	@Override
	public Date resolveBufferEndDate(DatesHolder dates) {
		Date billDate = dates.getDateByType(DateType.GENERATION_DATE);
		if (billDate == null) {
			logger.error("Bill generation date not found. Required to calculate buffer end date");
			throw new RuntimeException(
					"Bill generation date not found. Required to calculate buffer end date");
		}
		Date bufferEndDate = DateUtility.offsetDays(billDate, bufferDays);
		return DateUtility.roundAtDayEnd(bufferEndDate);

	}
}
