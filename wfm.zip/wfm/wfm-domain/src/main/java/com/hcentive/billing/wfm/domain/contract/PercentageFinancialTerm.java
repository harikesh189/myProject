package com.hcentive.billing.wfm.domain.contract;

import com.hcentive.billing.core.commons.domain.Period;

public class PercentageFinancialTerm extends
		AbstractFinancialTerm<PercentageAmount> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6859259521190949297L;
	private PercentageAmount percentage;

	public PercentageFinancialTerm(String type, String code, String name,
			Period effectivePeriod, PercentageAmount percentage, String description) {
		super(type, code, name, effectivePeriod, description);
		this.percentage = percentage;
	}

	@Override
	public PercentageAmount value() {
		return this.percentage;
	}

}
