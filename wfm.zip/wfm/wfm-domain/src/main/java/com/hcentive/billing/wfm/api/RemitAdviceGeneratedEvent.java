package com.hcentive.billing.wfm.api;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.wfm.domain.bill.BillArtifact;
import com.hcentive.billing.wfm.domain.bill.remit.RemitAdviceSummary;
import com.hcentive.billing.wfm.domain.remit.RemitAdviceRun;

public class RemitAdviceGeneratedEvent implements Serializable {

	private static final long serialVersionUID = 3642663447145188233L;

	private final Reference<String, BillArtifact<RemitAdviceSummary>, String> remitAdviceReference;

	private final RemitAdviceRun remitAdviceRun;

	public RemitAdviceGeneratedEvent(
			Reference<String, BillArtifact<RemitAdviceSummary>, String> remitAdvice,
			RemitAdviceRun request) {
		remitAdviceReference = remitAdvice;
		remitAdviceRun = request;
	}

	public Reference<String, BillArtifact<RemitAdviceSummary>, String> getRemitAdviceReference() {
		return remitAdviceReference;
	}

	public RemitAdviceRun getRemitAdviceRun() {
		return remitAdviceRun;
	}

}
