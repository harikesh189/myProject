/**
 * 
 */
package com.hcentive.wfm.checkpoint.rule;

import java.io.Serializable;

import org.springframework.util.Assert;

/**
 * 
 * Container class for {@link CheckpointRule} &
 * {@link DelinquencyCycleException}
 * 
 * @author Kumar Sambhav Jain
 *
 */
public class CheckpointCycleConfiguration implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4598955255851948450L;

	private CheckpointRule cycleRule;

	private DelinquencyCycleException cycleException;

	/**
	 * Does nothing
	 */
	public CheckpointCycleConfiguration() {
	}

	/**
	 * Parameterized Constructor.
	 * 
	 * @param cycleRule
	 *            Must not be null
	 * @param cycleException
	 *            Can be null
	 */
	public CheckpointCycleConfiguration(CheckpointRule cycleRule,
			DelinquencyCycleException cycleException) {
		Assert.notNull(cycleRule);
		this.cycleRule = cycleRule;
		this.cycleException = cycleException;
	}

	/**
	 * Parameterized Constructor.
	 * 
	 * @param cycleRule
	 */
	public CheckpointCycleConfiguration(CheckpointRule cycleRule) {
		this(cycleRule, null);
	}

	public CheckpointRule getCycleRule() {
		return cycleRule;
	}

	/**
	 * @param cycleRule
	 *            the cycleRule to set
	 */
	public void setCycleRule(CheckpointRule cycleRule) {
		this.cycleRule = cycleRule;
	}

	/**
	 * @return the cycleException
	 */
	public DelinquencyCycleException getCycleException() {
		return cycleException;
	}

	/**
	 * @param cycleException
	 *            the cycleException to set
	 */
	public void setCycleException(DelinquencyCycleException cycleException) {
		this.cycleException = cycleException;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DelinquencyCycleConfiguration [cycleRule=" + cycleRule
				+ ", cycleException=" + cycleException
				+ ", billingConfigTolerance=" + "]";
	}
}
