package com.hcentive.billing.wfm.domain.remit;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.eighttwenty.GeneratedThirdPartyPaymentRecord;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

@Entity
@Table(name = "payment_info")
public class PaymentInfo extends BaseEntity {

	private static final long serialVersionUID = 1915244268118815451L;
	
	@OneToOne
	@JoinColumn(name = "payment_record_id")
	private GeneratedThirdPartyPaymentRecord paymentRecord;
	
	@Column(name = "payment_method_type")
	@Access(AccessType.FIELD)
	private String paymentMethod;

	@Column(name = "identification_number")
	@Access(AccessType.FIELD)
	private String identificationNumber;
	
	@Column(name = "account_type")
	@Access(AccessType.FIELD)
	private String accountType;
	
	@Column(name = "account_number")
	@Access(AccessType.FIELD)
	private String accountNum;
	
	@Column(name = "outbound_payment_id")
	@Access(AccessType.FIELD)
	private String outboundPaymentId;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "payment_effective_date")) })
	@Access(AccessType.FIELD)
	private DateTime paymentEffDate;
	
	
	
	@Column(name = "routing_number")
	@Access(AccessType.FIELD)
	private String routingNumber;
	
	
	

	
	public String getOutboundPaymentId() {
		return outboundPaymentId;
	}


	public void setOutboundPaymentId(String outboundPaymentId) {
		this.outboundPaymentId = outboundPaymentId;
	}


	public String getPaymentMethod() {
		return paymentMethod;
	}


	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}


	public String getIdentificationNumber() {
		return identificationNumber;
	}


	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	public DateTime getPaymentEffDate() {
		return paymentEffDate;
	}


	public void setPaymentEffDate(DateTime paymentEffDate) {
		this.paymentEffDate = paymentEffDate;
	}


	public String getRoutingNumber() {
		return routingNumber;
	}


	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}


	public GeneratedThirdPartyPaymentRecord getPaymentRecord() {
		return paymentRecord;
	}


	public void setPaymentRecord(GeneratedThirdPartyPaymentRecord paymentRecord) {
		this.paymentRecord = paymentRecord;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public String getAccountNum() {
		return accountNum;
	}


	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}




	

}