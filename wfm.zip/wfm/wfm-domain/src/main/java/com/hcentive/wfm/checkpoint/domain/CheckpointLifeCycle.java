/**
 *
 */
package com.hcentive.wfm.checkpoint.domain;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.wfm.checkpoint.rule.Checkpoint;
import com.hcentive.wfm.checkpoint.rule.CheckpointCycleConfiguration;
import com.hcentive.wfm.checkpoint.rule.CheckpointRule;
import com.hcentive.wfm.checkpoint.rule.DelinquencyCycleException;

/**
 *
 * Captures state and other details for invoice checkpoint cycle.
 *
 * @author Kumar Sambhav Jain
 *
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_checkpoint_life_cycle")
public class CheckpointLifeCycle<T extends DomainEntity> extends AbstractMongoEntity {

	public static enum CheckPointLifeCycleType {
		DELINQUENCY, REINSTATEMENT
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(CheckpointLifeCycle.class);

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1722032632417619850L;

	
	private CheckPointLifeCycleType lifecycleType;

	@NotNull
	private CheckpointLifeCycleMetadata<T, ?> lifecycleMetadata;

	protected List<T> monitoredObjectHistory;

	@NotNull
	@Valid
	protected CheckpointCycleConfiguration checkpointCycleConfiguration;

	protected String currentCheckpointId;

	protected Checkpoint lastCheckpoint;

	protected Checkpoint nextCheckpoint;

	protected Date graceStartDate;

	/**
	 * Estimated grace end date of the grace period.
	 */
	private Date projectedGraceEndDate;

	private Date nextCheckpointDate;

	private Date currentCheckpointDate;

	private Date effectiveTerminationDate;

	protected long nextCheckpointDateMillis;

	/**
	 * Status of cycle.
	 */
	@NotNull
	private CHECKPOINT_LIFECYCLE_STATUS status;

	private int executableCheckpointIndex;

	private List<DelinquencyCycleException> applicableExceptions = new ArrayList<>();

	/**
	 * default no arguments constructor - does nothing
	 */
	public CheckpointLifeCycle() {
	}

	public CheckpointLifeCycle(CheckpointCycleConfiguration delinquencyLifeCycleConfig) {
		super();
		this.checkpointCycleConfiguration = delinquencyLifeCycleConfig;
	}

	public void addExceptions(List<DelinquencyCycleException> applicableExceptions) {
		this.applicableExceptions.addAll(applicableExceptions);
	}

	public List<DelinquencyCycleException> getApplicableExceptions() {
		DelinquencyCycleException.sortByEndDate(applicableExceptions);
		return applicableExceptions;
	}

	/**
	 * @return the checkpointCycleConfiguration
	 */
	public CheckpointCycleConfiguration getCheckpointCycleConfiguration() {
		return checkpointCycleConfiguration;
	}

	/**
	 * @return the currentCheckpointDate
	 */
	public Date getCurrentCheckpointDate() {
		return currentCheckpointDate;
	}

	/**
	 * @return the currentCheckpointId
	 */
	public String getCurrentCheckpointId() {
		return currentCheckpointId;
	}

	public Date getDateToLastSecond(Date dateToMove) {
		final Calendar car = Calendar.getInstance();
		car.setTime(dateToMove);
		car.set(Calendar.HOUR_OF_DAY, 23);
		car.set(Calendar.MINUTE, 59);
		car.set(Calendar.SECOND, 59);
		car.set(Calendar.MILLISECOND, 999);
		return car.getTime();
	}

	@JsonIgnore
	public DelinquencyCycleException getDelinquencyCycleException() {
		if (checkpointCycleConfiguration != null) {
			return checkpointCycleConfiguration.getCycleException();
		} else {
			return null;
		}
	}

	@JsonIgnore
	public CheckpointRule getDelinquencyCycleRule() {
		if (checkpointCycleConfiguration != null) {
			return checkpointCycleConfiguration.getCycleRule();
		} else {
			return null;
		}
	}

	/**
	 * @return the delinquencyLifeCycleConfig
	 */
	public CheckpointCycleConfiguration getDelinquencyLifeCycleConfig() {
		return checkpointCycleConfiguration;
	}

	public Date getEffectiveTerminationDate() {
		return effectiveTerminationDate;
	}

	public int getExecutableCheckpointIndex() {
		return executableCheckpointIndex;
	}

	public Date getGraceEndDate() {
		// for notifications to work, without changing template.
		return projectedGraceEndDate;
	}

	/**
	 * @return the graceStartDate
	 */
	public Date getGraceStartDate() {
		return graceStartDate;
	}

	/**
	 * @return the lastCheckpoint
	 */
	public Checkpoint getLastCheckpoint() {
		return lastCheckpoint;
	}

	public CheckpointLifeCycleMetadata<T, ?> getLifecycleMetadata() {
		return lifecycleMetadata;
	}

	/**
	 * @return the lifecycleType
	 */
	public CheckPointLifeCycleType getLifecycleType() {
		return lifecycleType;
	}

	/**
	 * @return the monitoredObjectHistory
	 */
	public List<T> getMonitoredObjectHistory() {
		return monitoredObjectHistory;
	}

	/**
	 * @return the nextCheckpoint
	 */
	public Checkpoint getNextCheckpoint() {
		return nextCheckpoint;
	}

	/*
	 * public void pushNewObject(T t) { if (null != t) { if
	 * (monitoredObjectHistory == null) { monitoredObjectHistory = new
	 * ArrayList<>(); } monitoredObjectHistory.add(monitoredObject);
	 * monitoredObject = t; } }
	 */
	/**
	 * @return the nextCheckpointDate
	 */
	public Date getNextCheckpointDate() {
		return nextCheckpointDate;
	}

	/**
	 * @return the nextCheckpointDateMillis
	 */
	public long getNextCheckpointDateMillis() {
		nextCheckpointDateMillis = nextCheckpointDate != null ? nextCheckpointDate.getTime() : 0l;

		return nextCheckpointDateMillis;
	}

	/**
	 * @return the graceEndDate
	 */
	public Date getProjectedGraceEndDate() {
		return projectedGraceEndDate;
	}

	/**
	 * @return the status
	 */
	public CHECKPOINT_LIFECYCLE_STATUS getStatus() {
		return status;
	}

	public boolean held() {
		LOGGER.debug("check if life cycle object with identity {} is held", getIdentity());
		return this.getStatus() == CHECKPOINT_LIFECYCLE_STATUS.CANDIDATE_HELD || this.getStatus() == CHECKPOINT_LIFECYCLE_STATUS.MONITORED_HELD;
	}

	public void hold() {
		CHECKPOINT_LIFECYCLE_STATUS heldStatus;
		if (CHECKPOINT_LIFECYCLE_STATUS.CANDIDATE == this.getStatus()) {
			heldStatus = CHECKPOINT_LIFECYCLE_STATUS.CANDIDATE_HELD;
		} else {
			heldStatus = CHECKPOINT_LIFECYCLE_STATUS.MONITORED_HELD;
		}
		this.setStatus(heldStatus);
	}

	public void incrementExecutableCheckpointIndex() {
		++this.executableCheckpointIndex;
	}

	public void release() {
		CHECKPOINT_LIFECYCLE_STATUS releasedStatus;
		if (CHECKPOINT_LIFECYCLE_STATUS.CANDIDATE_HELD == this.getStatus()) {
			releasedStatus = CHECKPOINT_LIFECYCLE_STATUS.CANDIDATE_RELEASED;
		} else {
			releasedStatus = CHECKPOINT_LIFECYCLE_STATUS.MONITORED_RELEASED;
		}
		this.setStatus(releasedStatus);
	}

	public void setApplicableExceptions(List<DelinquencyCycleException> applicableExceptions) {
		this.applicableExceptions = applicableExceptions;
	}

	/**
	 * @param checkpointCycleConfiguration
	 *            the checkpointCycleConfiguration to set
	 */
	public void setCheckpointCycleConfiguration(CheckpointCycleConfiguration checkpointCycleConfiguration) {
		this.checkpointCycleConfiguration = checkpointCycleConfiguration;
	}

	/**
	 * @param currentCheckpointDate
	 *            the currentCheckpointDate to set
	 */
	public void setCurrentCheckpointDate(Date currentCheckpointDate) {
		this.currentCheckpointDate = currentCheckpointDate;
	}

	/**
	 * @param currentCheckpointId
	 *            the currentCheckpointId to set
	 */
	public void setCurrentCheckpointId(String currentCheckpointId) {
		this.currentCheckpointId = currentCheckpointId;
	}

	/**
	 * @param delinquencyLifeCycleConfig
	 *            the delinquencyLifeCycleConfig to set
	 */
	public void setDelinquencyLifeCycleConfig(CheckpointCycleConfiguration delinquencyLifeCycleConfig) {
		this.checkpointCycleConfiguration = delinquencyLifeCycleConfig;
	}

	public void setEffectiveTerminationDate(Date effectiveTerminationDate) {
		this.effectiveTerminationDate = effectiveTerminationDate;
	}

	public void setExecutableCheckpointIndex(int executableCheckpointIndex) {
		this.executableCheckpointIndex = executableCheckpointIndex;
	}

	/**
	 * @param graceStartDate
	 *            the graceStartDate to set
	 */
	public void setGraceStartDate(Date graceStartDate) {
		this.graceStartDate = graceStartDate;
	}

	/**
	 * @param lastCheckpoint
	 *            the lastCheckpoint to set
	 */
	public void setLastCheckpoint(Checkpoint lastCheckpoint) {
		this.lastCheckpoint = lastCheckpoint;
	}

	public void setLifecycleMetadata(CheckpointLifeCycleMetadata<T, ?> lifecycleMetadata) {
		this.lifecycleMetadata = lifecycleMetadata;
	}

	/**
	 * @param lifecycleType
	 *            the lifecycleType to set
	 */
	public void setLifecycleType(CheckPointLifeCycleType lifecycleType) {
		this.lifecycleType = lifecycleType;
	}

	/**
	 * @param monitoredObjectHistory
	 *            the monitoredObjectHistory to set
	 */
	public void setMonitoredObjectHistory(List<T> monitoredObjectHistory) {
		this.monitoredObjectHistory = monitoredObjectHistory;
	}

	/**
	 * @param nextCheckpoint
	 *            the nextCheckpoint to set
	 */
	public void setNextCheckpoint(Checkpoint nextCheckpoint) {
		this.nextCheckpoint = nextCheckpoint;
	}

	/**
	 * @param nextCheckpointDate
	 *            the nextCheckpointDate to set
	 */
	protected void setNextCheckpointDate(Date nextCheckpointDate) {
		this.nextCheckpointDate = nextCheckpointDate;
		if (nextCheckpointDate != null) {
			nextCheckpointDateMillis = nextCheckpointDate.getTime();
		} else {
			nextCheckpointDateMillis = 0l;
		}
	}

	public void setProjectedEndDate(final Date executionDate, int remainingGraceDays) {
		final Date graceEndDate = DateUtils.addDays(executionDate, remainingGraceDays);
		this.setProjectedGraceEndDate(graceEndDate);
	}

	/**
	 * @param graceEndDate
	 *            the graceEndDate to set
	 */
	public void setProjectedGraceEndDate(Date graceEndDate) {
		this.projectedGraceEndDate = graceEndDate;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(CHECKPOINT_LIFECYCLE_STATUS status) {
		this.status = status;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DelinquencyLifeCycle [ monitoredObjectHistory=" + monitoredObjectHistory + ", delinquencyLifeCycleConfig=" + checkpointCycleConfiguration
				+ ", graceStartDate=" + graceStartDate + ", nextCheckpointDate=" + nextCheckpointDate + ", status=" + status + "]";
	}

	public <M extends MonitoredObjectMeta> void updateLifecycleMetadata(CheckpointLifeCycleMetadata<T, M> newLifecycleMetadata) {
		@SuppressWarnings("unchecked")
		final CheckpointLifeCycleMetadata<T, M> prevLifecycleMetadata = (CheckpointLifeCycleMetadata<T, M>) this.getLifecycleMetadata();

		if (prevLifecycleMetadata != null) {
			prevLifecycleMetadata.setMonitoredObjectMetadata(newLifecycleMetadata.getMonitoredObjectMetadata());
			prevLifecycleMetadata.setTriggerObjectType(newLifecycleMetadata.getTriggerObjectType());
		}
	}

	public void updateNextCheckpointDate(Date nextCheckpointDate, DateTime todayDate) {
		setNextCheckpointDate(nextCheckpointDate);
		if (null != todayDate && null != nextCheckpointDate && todayDate.isAfter(new DateTime(nextCheckpointDate))) {
			this.nextCheckpointDateMillis = DateUtils.truncate(todayDate.getDate(), Calendar.DAY_OF_MONTH).getTime();
		}

	}
}
