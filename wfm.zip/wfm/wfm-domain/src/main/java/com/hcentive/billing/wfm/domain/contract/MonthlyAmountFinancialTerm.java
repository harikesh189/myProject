package com.hcentive.billing.wfm.domain.contract;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

public class MonthlyAmountFinancialTerm extends AbstractFinancialTerm<Amount> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7039709543173959563L;
	private Amount amount;

	public MonthlyAmountFinancialTerm(String type, String code, String name,
			Period effectivePeriod, Amount amount, String description) {
		super(type, code, name, effectivePeriod, description);
		this.amount = amount;
	}

	@Override
	public Amount value() {
		return amount;
	}

}
