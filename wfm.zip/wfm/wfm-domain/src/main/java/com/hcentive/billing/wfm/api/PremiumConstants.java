package com.hcentive.billing.wfm.api;

public class PremiumConstants {

	public static final String ACCUMULATION_TYPE_SUM = "SUM";

}
