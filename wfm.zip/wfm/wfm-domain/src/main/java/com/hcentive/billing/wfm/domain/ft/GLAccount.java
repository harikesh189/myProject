package com.hcentive.billing.wfm.domain.ft;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.Operator;
import com.hcentive.billing.wfm.api.enumeration.ft.AccountType;
import com.hcentive.billing.wfm.api.enumeration.ft.GLAccountStatus;

@Entity
@Table(name = "gl_account", uniqueConstraints = { @UniqueConstraint(columnNames = { "identity" }), @UniqueConstraint(columnNames = { "account_id" }) })
public class GLAccount extends DomainEntity {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "account_id", nullable = false)
	@Access(AccessType.FIELD)
	private String accountId;

	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	@Column(name = "account_type", nullable = false)
	private AccountType accountType;

	@Access(AccessType.FIELD)
	@Column(name = "holding_account", nullable = false)
	private boolean holdingAccount;

	@JoinColumn(name = "operator_id", nullable = true)
	@OneToOne(fetch = FetchType.EAGER)
	private Operator operator;

	@OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinColumn(name = "parent_id")
	@Access(AccessType.FIELD)
	private GLAccount parent;

	@Embedded
	private GLAccountQualifier qualifier;

	@OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@Access(AccessType.FIELD)
	@JoinColumn(name = "realized_account_id")
	private GLAccount realizedAccount;

	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false)
	private GLAccountStatus status = GLAccountStatus.ACTIVE;

	@Column(name = "tenant_id")
	private String tenantId;

	public GLAccount() {

	}

	public GLAccount(final String accountId, final AccountType accountType, final GLAccountQualifier accountQualifier) {
		this.setAccountId(accountId);
		this.setAccountType(accountType);
		this.setHoldingAccount(false);
		this.setQualifier(accountQualifier);
		this.setStatus(GLAccountStatus.ACTIVE);
	}

	public String getAccountId() {
		return this.accountId;
	}

	public AccountType getAccountType() {
		return this.accountType;
	}

	public Operator getOperator() {
		return this.operator;
	}

	public GLAccount getParent() {
		return this.parent;
	}

	public GLAccountQualifier getQualifier() {
		return this.qualifier;
	}

	public GLAccount getRealizedAccount() {
		return this.realizedAccount;
	}

	public GLAccountStatus getStatus() {
		return this.status;
	}

	public boolean isHoldingAccount() {
		return this.holdingAccount;
	}

	public void setAccountId(final String accountId) {
		this.accountId = accountId;
	}

	public void setAccountType(final AccountType accountType) {
		this.accountType = accountType;
	}

	public void setHoldingAccount(final boolean holdingAccount) {
		this.holdingAccount = holdingAccount;
	}

	public void setOperator(final Operator operator) {
		this.operator = operator;
	}

	public void setParent(final GLAccount parent) {
		this.parent = parent;
	}

	public void setQualifier(final GLAccountQualifier qualifier) {
		this.qualifier = qualifier;
	}

	public void setRealizedAccount(final GLAccount realizedAccount) {
		this.realizedAccount = realizedAccount;
	}

	public void setStatus(final GLAccountStatus status) {
		this.status = status;
	}

	public void setTenantId(final String tenantId) {
		this.tenantId = tenantId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("\nGLAccount [accountId=");
		builder.append(this.accountId);
		builder.append(", accountType=");
		builder.append(this.accountType);
		builder.append(", fundingAccount=");
		builder.append(", holdingAccount=");
		builder.append(this.holdingAccount);
		builder.append(", parent=");
		builder.append(this.parent);
		builder.append(", qualifier=");
		builder.append(this.qualifier);
		builder.append(", realizedAccount=");
		builder.append(this.realizedAccount);
		builder.append(", status=");
		builder.append(this.status);
		builder.append("]");
		return builder.toString();
	}
}
