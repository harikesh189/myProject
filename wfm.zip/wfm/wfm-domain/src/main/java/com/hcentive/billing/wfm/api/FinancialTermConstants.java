package com.hcentive.billing.wfm.api;

public class FinancialTermConstants {

	public static final String FIN_TERM_TYPE_FEE = "FEE";

	public static final String FIN_TERM_TYPE_DISCOUNT = "DISCOUNT";

}
