package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "disability")
public class Disability extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 859349412401781927L;

	@Access(AccessType.FIELD)
	@Column(name = "type_code")
	private String typeCode;

	@Access(AccessType.FIELD)
	@Column(name = "icd_code")
	private String icdCode;

	@Access(AccessType.FIELD)
	@Column(name = "medical_code")
	private String medicalCode;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "effective_date")) })
	@Access(AccessType.FIELD)
	private DateTime effectiveDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "termination_date")) })
	@Access(AccessType.FIELD)
	private DateTime terminationDate;

	public Disability() {
		super();
	}

	public Disability(final String typeCode, final String icdCode,
			final String medicalCode, final DateTime effectiveDate) {
		super();
		this.typeCode = typeCode;
		this.icdCode = icdCode;
		this.medicalCode = medicalCode;
		this.effectiveDate = effectiveDate;
	}

	public DateTime getEffectiveDate() {
		return effectiveDate;
	}

	public String getIcdCode() {
		return icdCode;
	}

	public String getMedicalCode() {
		return medicalCode;
	}

	public DateTime getTerminationDate() {
		return terminationDate;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setEffectiveDate(final DateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public void setIcdCode(final String icdCode) {
		this.icdCode = icdCode;
	}

	public void setMedicalCode(final String medicalCode) {
		this.medicalCode = medicalCode;
	}

	public void setTerminationDate(final DateTime terminationDate) {
		this.terminationDate = terminationDate;
	}

	public void setTypeCode(final String typeCode) {
		this.typeCode = typeCode;
	}

}
