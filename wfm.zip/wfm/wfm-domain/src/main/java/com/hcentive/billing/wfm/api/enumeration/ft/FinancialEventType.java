package com.hcentive.billing.wfm.api.enumeration.ft;

import java.util.LinkedList;
import java.util.List;

public enum FinancialEventType {

	BILLING_RUN, WRITEON, PAYMENT, WRITEOFF, INVOICE_SETTLEMENT, REMIT, VOID, RETRO, UNHOLD_PAYMENT, HOLD_PAYMENT, REFUND, CREDIT, REFUND_PAYOUT, PAYMENT_CANCEL, PAYMENT_FAILURE, INVOICE_SETTLEMENT_REVERSAL, LIABILITY_TRANSFER,MONEY_TRANSFER;

	public static List<String> getFTEventList() {

		final List<String> typeList = new LinkedList<String>();

		typeList.add(FinancialEventType.BILLING_RUN.toString());
		typeList.add(FinancialEventType.PAYMENT.toString());

		return typeList;
	}
}
