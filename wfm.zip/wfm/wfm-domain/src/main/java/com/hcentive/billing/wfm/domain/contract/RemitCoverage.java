package com.hcentive.billing.wfm.domain.contract;

import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.HealthPlanProvider;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType;
import com.hcentive.billing.wfm.domain.contract.mixin.HealthPlanAware;
import com.hcentive.billing.wfm.domain.contract.mixin.LOBAware;

@Entity
@DiscriminatorValue("REMIT_COVERAGE")
public class RemitCoverage extends InsuranceCoverage implements HealthPlanAware,LOBAware{

	private static final String REMIT_COVERAGE = "RemitCoverage";

	/**
	 *
	 */
	private static final long serialVersionUID = -2730028288037444198L;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "third_party_member_coverage_id")
	@Access(AccessType.FIELD)
	private ThirdPartyMemberCoverage memberCoverage;

	@SuppressWarnings("rawtypes")
	@OneToOne
	@JoinColumn(name = "group_customer_id")
	private BusinessEntity groupCustomer;

	@Column(name = "ftEntryIdentity")
	private String ftEntryIdentity;

	@Enumerated(EnumType.STRING)
	@Column(name = "event_type")
	private FinancialEventType eventType;

	public static Period infiniteEffectivePeriod() {
		final Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(0);
		final Date epochStartDate = cal.getTime();
		cal.add(Calendar.YEAR, 100);
		final Date epochEndDate = cal.getTime();
		return new Period(epochStartDate, epochEndDate);

	}

	@Override
	public Period effectivePeriod() {
		/*
		 * Period effPeriod = this.getTotalCoverage(); if (null == effPeriod) { effPeriod = new Period(); // remit coverage is always effective for // billing }
		 * return effPeriod;
		 */

		/*
		 * Ajay: Returning a period which starts to epoch time and ends after 100 yrs
		 */

		return infiniteEffectivePeriod();
	}

	public FinancialEventType getEventType() {
		return eventType;
	}

	public String getFtEntryIdentity() {
		return ftEntryIdentity;
	}

	public BusinessEntity getGroupCustomer() {
		return groupCustomer;
	}

	@Override
	public InsuredMember getInsuredSubscriber() {
		if (null != memberCoverage) {
			return memberCoverage.getInsuredMember();
		}
		return null;
	}

	public ThirdPartyMemberCoverage getMemberCoverage() {
		return memberCoverage;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setEventType(final FinancialEventType eventType) {
		this.eventType = eventType;
	}

	public void setFtEntryIdentity(final String ftEntryIdentity) {
		this.ftEntryIdentity = ftEntryIdentity;
	}

	public void setGroupCustomer(final BusinessEntity groupCustomer) {
		this.groupCustomer = groupCustomer;
	}

	public void setMemberCoverage(final ThirdPartyMemberCoverage memberCoverage) {
		this.memberCoverage = memberCoverage;
	}

	@Override
	public String typeName() {
		return REMIT_COVERAGE;
	}
	
	public HealthPlan getHealthPlan(){
		return (HealthPlan) this.healthPlan;
	}
	
	@Override
	public Collection<String> getHealthPlanProducts() {
		final Collection<String> result = new LinkedList<>();
		final String productType = this.getHealthPlan().getProductType();
		if (productType != null) {
			result.add(productType);
		}
		return result;
	}
	
	@Override
	public Collection<String> getLineOfBusiness() {
		final Collection<String> result = new LinkedList<>();
		final String lob = this.getHealthPlan().getLineOfBusiness();
		if (lob != null) {
			result.add(lob);
		}
		return result;
	}

	@Override
	public Collection<HealthPlanProvider> getHealthPlanProviders() {
		if (getHealthPlan().getCarrier() instanceof HealthPlanProvider) {
			return CollectionUtil.asList((HealthPlanProvider) this.getHealthPlan().getCarrier());
		}
		return Collections.EMPTY_LIST;
	}

}
