package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "insurance_plan_bill_amount")
public class InsuranceCoverageBillAmount extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Column(name="plan_id")
	private Long planId;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "insurance_plan_bill_amount_bill_amounts", joinColumns = @JoinColumn(name = "insurance_plan_bill_amount_id"), inverseJoinColumns = @JoinColumn(name = "bill_amounts_id"))
	private Set<BillAmount> billAmounts = new HashSet<>();

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public Set<BillAmount> getBillAmounts() {
		return billAmounts;
	}

	public void setBillAmounts(Set<BillAmount> billAmounts) {
		this.billAmounts = billAmounts;
	}

	public void addBillAmount(BillAmount billAmt) {
		billAmounts.add(billAmt);
	}

}
