package com.hcentive.billing.wfm.api;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.bill.BillArtifact;
import com.hcentive.billing.wfm.domain.bill.invoice.WFMInvoiceSummary;

public class InvoiceGeneratedEvent implements Serializable {

	private static final long serialVersionUID = 3642663447145188233L;

	private Reference<String, BillArtifact<WFMInvoiceSummary>, String> invoiceReference;

	private String invoiceGenerationRequestIdentity;
	
	private Amount currentInvoiceAmount;
	
	private Amount netInvoiceAmount;
	
	private String invoiceExternalId;

	public InvoiceGeneratedEvent(
			Reference<String, BillArtifact<WFMInvoiceSummary>, String> invoice,
			String identity, Amount currentInvoiceAmount,
			Amount netInvoiceAmount, String invoiceExternalId) {
		this.invoiceReference = invoice;
		this.invoiceGenerationRequestIdentity = identity;
		this.currentInvoiceAmount = currentInvoiceAmount;
		this.netInvoiceAmount = netInvoiceAmount;
		this.invoiceExternalId = invoiceExternalId;
	}

	public Reference<String, BillArtifact<WFMInvoiceSummary>, String> getInvoiceReference() {
		return invoiceReference;
	}

	public Amount getCurrentInvoiceAmount() {
		return currentInvoiceAmount;
	}

	public Amount getNetInvoiceAmount() {
		return netInvoiceAmount;
	}

	public String getInvoiceExternalId() {
		return invoiceExternalId;
	}

	public String getInvoiceGenerationRequestIdentity() {
		return invoiceGenerationRequestIdentity;
	}
	

}
