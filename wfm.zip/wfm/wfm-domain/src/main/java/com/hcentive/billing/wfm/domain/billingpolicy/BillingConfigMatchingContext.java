package com.hcentive.billing.wfm.domain.billingpolicy;

import static com.hcentive.billing.core.commons.tags.StringTagBuilder.CARRIER_ID;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.COVERAGE_TYPE;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.GROUP_CATEGORY;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.GROUP_ID;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.PLAN_ID;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.PLAN_TYPE;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.PRODUCT_TYPE;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.SMOKER_FL;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.SMOKING_CLASS;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.SUBSCRIBER_ID;
import static com.hcentive.billing.core.commons.tags.StringTagBuilder.SUB_GROUP_ID;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.tags.StringTagBuilder;
import com.hcentive.billing.core.commons.tags.TagAware;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BillingConfigCoverageType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BillingConfigPlanType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BillingConfigProductType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.GroupCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.SmokingClassification;

@Entity
@Table(name = "billing_config_matching_context")
public class BillingConfigMatchingContext extends BaseEntity implements
		TagAware<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "carrier_id")
	private String carrierId;

	@Enumerated(EnumType.STRING)
	@Column(name = "coverage_type")
	private BillingConfigCoverageType coverageType;

	@Enumerated(EnumType.STRING)
	@Column(name = "group_category")
	private GroupCategory groupCategory;

	@Column(name = "group_id")
	private String groupId;

	@Column(name = "plan_id")
	private String planId;

	@Enumerated(EnumType.STRING)
	@Column(name = "plan_type")
	private BillingConfigPlanType planType;

	@Enumerated(EnumType.STRING)
	@Column(name = "product_type")
	private BillingConfigProductType productType;

	@Column(name = "smoker")
	private boolean smoker;

	@Enumerated(EnumType.STRING)
	@Column(name = "smoking_classification")
	private SmokingClassification smokingClassification;

	@Column(name = "sub_group_id")
	private String subGroupId;

	@Column(name = "subscriber_id")
	private String subscriberId;

	public String getCarrierId() {
		return this.carrierId;
	}

	public BillingConfigCoverageType getCoverageType() {
		return this.coverageType;
	}

	public GroupCategory getGroupCategory() {
		return this.groupCategory;
	}

	public String getGroupId() {
		return this.groupId;
	}

	public String getPlanId() {
		return this.planId;
	}

	public BillingConfigPlanType getPlanType() {
		return this.planType;
	}

	public BillingConfigProductType getProductType() {
		return this.productType;
	}

	public SmokingClassification getSmokingClassification() {
		return this.smokingClassification;
	}

	public String getSubGroupId() {
		return this.subGroupId;
	}

	public String getSubscriberId() {
		return this.subscriberId;
	}

	public boolean isSmoker() {
		return this.smoker;
	}

	public void setCarrierId(final String carrierId) {
		this.carrierId = carrierId;
	}

	public void setCoverageType(final BillingConfigCoverageType coverageType) {
		this.coverageType = coverageType;
	}

	public void setGroupCategory(final GroupCategory groupCategory) {
		this.groupCategory = groupCategory;
	}

	public void setGroupId(final String groupId) {
		this.groupId = groupId;
	}

	public void setPlanId(final String planId) {
		this.planId = planId;
	}

	public void setPlanType(final BillingConfigPlanType planType) {
		this.planType = planType;
	}

	public void setProductType(final BillingConfigProductType productType) {
		this.productType = productType;
	}

	public void setSmoker(final boolean smoker) {
		this.smoker = smoker;
	}

	public void setSmokingClassification(
			final SmokingClassification smokingClassification) {
		this.smokingClassification = smokingClassification;
	}

	public void setSubGroupId(final String subGroupId) {
		this.subGroupId = subGroupId;
	}

	public void setSubscriberId(final String subscriberId) {
		this.subscriberId = subscriberId;
	}

	@Override
	public Collection<String> tags() {
		Collection<String> tags = new HashSet<>();
		addTagIfNotNull(tags, CARRIER_ID, getCarrierId());
		addTagIfNotNull(tags, COVERAGE_TYPE, getCoverageType());
		addTagIfNotNull(tags, GROUP_CATEGORY, getGroupCategory());
		addTagIfNotNull(tags, GROUP_ID, getGroupId());
		addTagIfNotNull(tags, PLAN_TYPE, getPlanType());
		addTagIfNotNull(tags, PLAN_ID, getPlanId());
		addTagIfNotNull(tags, PRODUCT_TYPE, getProductType());
		addTagIfNotNull(tags, SMOKER_FL, isSmoker());
		addTagIfNotNull(tags, SMOKING_CLASS, getSmokingClassification());
		addTagIfNotNull(tags, SUB_GROUP_ID, getSubGroupId());
		addTagIfNotNull(tags, SUBSCRIBER_ID, getSubscriberId());
		return tags;
	}

	void addTagIfNotNull(Collection<String> tags, String tagPrefix,
			Object tagValue) {
		if (tagValue != null) {
			tags.add(StringTagBuilder.createTag(tagPrefix, tagValue.toString()));
		}
	}

}
