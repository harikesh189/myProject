package com.hcentive.billing.wfm.domain.ft;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable
public class GLAccountQualifier implements Serializable {

	private static final long serialVersionUID = 1L;

	public static enum Type {
		PEND_PAY, PEND_REV, PEND_RX, ACCT_PAY, ACCT_RX, BAD_DEBT, CASH, OTHER, REVENUE, UNAPPLIED_CASH
	}

	@Column(name = "name", nullable = false)
	private String name;

	@Enumerated(EnumType.STRING)
	@Column(name = "type", nullable = false)
	private Type type;

	public GLAccountQualifier() {

	}

	public GLAccountQualifier(final String name, final Type type) {
		this.name = name;
		this.type = type;
	}

	public String getName() {
		return this.name;
	}

	public Type getType() {
		return this.type;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public void setType(final Type type) {
		this.type = type;
	}

}
