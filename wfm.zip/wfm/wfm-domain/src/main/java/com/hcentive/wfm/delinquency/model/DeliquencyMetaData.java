package com.hcentive.wfm.delinquency.model;

import com.hcentive.billing.core.commons.vo.Amount;

public class DeliquencyMetaData extends BillingAccountMetaData{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4903420924025032322L;
	private final Amount totalOutstanding;
	
	public DeliquencyMetaData(Amount totalOutstanding, String billingAccountIdentity) {
		super(billingAccountIdentity);
		this.totalOutstanding=totalOutstanding;
	}

	public Amount getTotalOutstanding() {
		return totalOutstanding;
	}

	@Override
	public Amount getNetBalance() {
		return this.totalOutstanding;
	}
	

}
