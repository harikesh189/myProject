/**
 * 
 */
package com.hcentive.wfm.checkpoint.domain;

/**
 * 
 * Various statuses during delinquency life cycle.
 * 
 * @author Kumar Sambhav Jain
 *
 */
public enum CHECKPOINT_LIFECYCLE_STATUS {

	/**
	 * Might become delinquent in future.
	 */
	CANDIDATE, /**
				 * Currently undergoing delinquency life cycle.
				 */
	MONITORED, /**
				 * An update in the monitored object resulted in ending the
				 * monitoring. The monitored object will not go through the
				 * checkpoints.
				 */
	DO_NOT_MONITOR, /**
					 * Termination was triggered for the monitored object at the
					 * end of grace period when all checkpoints were crossed.
					 */
	LIFECYCLE_ENDED,

	/**
	 * Exception was applicable and the candidate has been held until exception
	 * terminates.
	 */
	CANDIDATE_HELD,

	/**
	 * Exception was applicable and the monitored object has been held until
	 * exception terminates.
	 */
	MONITORED_HELD,

	/**
	 * Exception has terminated and the candidate has been released.
	 */
	CANDIDATE_RELEASED,

	/**
	 * Exception has terminated and the monitored has been released.
	 */
	MONITORED_RELEASED, 
	
	/***
	 * Exit Gracefully from CANDIDATE
	 */
	NOT_CANDIDATE;

	/**
	 * @return Array of statuses that needs to be watched by delinquency batch
	 *         cycle..
	 */
	public static CHECKPOINT_LIFECYCLE_STATUS[] delinquentStatus() {
		return new CHECKPOINT_LIFECYCLE_STATUS[] { CANDIDATE, MONITORED };
	}
}
