package com.hcentive.billing.wfm.domain.manualadjustment;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;



/**
 * Class to represent Write-On Adjustment.
 * 
 * @author ajay.saxena
 *
 */
@Entity
@Table(name = "manual_adjustment")
@DiscriminatorValue("Write-On")
public class WriteOn extends ManualAdjustment{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3346528397628485534L;

	@Override
	public String typeName() {
		return "Write-On";
	}

}
