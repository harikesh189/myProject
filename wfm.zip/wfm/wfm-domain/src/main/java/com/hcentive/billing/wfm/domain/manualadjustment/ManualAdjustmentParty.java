package com.hcentive.billing.wfm.domain.manualadjustment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@Entity
@Table(name = "manual_adj_party")
public class ManualAdjustmentParty extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = -8182527647758933665L;

	@Enumerated(EnumType.STRING)
	@Column(name = "party_category")
	private ManualAdjustmentPartyCategory partyCategory;

	@SuppressWarnings("rawtypes")
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "party_id", unique = true)
	private BusinessEntity party;

	@SuppressWarnings("rawtypes")
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "party_account_id")
	private BillingAccount partyBillingAccount;

	public ManualAdjustmentParty() {

	}

	public ManualAdjustmentParty(final ManualAdjustmentPartyCategory partyCategory, final BillingAccount partyBillingAccount) {
		this(partyCategory, partyBillingAccount.getOwner(), partyBillingAccount);
	}

	public ManualAdjustmentParty(final ManualAdjustmentPartyCategory partyCategory, final BusinessEntity party, final BillingAccount partyBillingAccount) {
		super();
		this.partyCategory = partyCategory;
		this.party = party;
		this.partyBillingAccount = partyBillingAccount;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final ManualAdjustmentParty other = (ManualAdjustmentParty) obj;
		if (this.party == null) {
			if (other.party != null) {
				return false;
			}
		} else if (!this.party.equals(other.party)) {
			return false;
		}
		if (this.partyCategory != other.partyCategory) {
			return false;
		}
		return true;
	}

	public BusinessEntity getParty() {
		return this.party;
	}

	/*
	 * @ManyToOne(cascade=CascadeType.PERSIST)
	 * 
	 * @JoinColumn(name="manaual_adj_id")
	 * 
	 * @Access(AccessType.FIELD) private ManualAdjustment manualAdjustment;
	 */

	public BillingAccount getPartyBillingAccount() {
		return this.partyBillingAccount;
	}

	public ManualAdjustmentPartyCategory getPartyCategory() {
		return this.partyCategory;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (this.party == null ? 0 : this.party.hashCode());
		result = prime * result + (this.partyCategory == null ? 0 : this.partyCategory.hashCode());
		return result;
	}

	public void setParty(final BusinessEntity party) {
		this.party = party;
	}

	public void setPartyBillingAccount(final BillingAccount partyBillingAccount) {
		this.partyBillingAccount = partyBillingAccount;
	}

	public void setPartyCategory(final ManualAdjustmentPartyCategory partyCategory) {
		this.partyCategory = partyCategory;
	}

}
