package com.hcentive.billing.wfm.domain.bill.remit;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.bill.BillArtifactSummary;

@Entity
@Table(name = "remit_advice_summary")
public class RemitAdviceSummary extends BillArtifactSummary {

	private static final long serialVersionUID = 7635421336195039810L;

	// @Type(type = "amount")
	// @Columns(columns = { @Column(name = "currReceivableAmtValue"),
	// @Column(name = "currReceivableAmtName"),
	// @Column(name = "currReceivableAmtSymbol"), @Column(name =
	// "currReceivableAmtShortName") })
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "curr_receivable_amt_value")),
			@AttributeOverride(name = "name", column = @Column(name = "curr_receivable_amt_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "curr_receivable_amt_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "currReceivableAmtShortName")) })
	@Access(AccessType.FIELD)
	private Amount currentReceivable;

	/*
	 * @Type(type = "amount")
	 * 
	 * @Columns(columns = { @Column(name = "currPayableAmtValue"), @Column(name
	 * = "currPayableAmtName"),
	 * 
	 * @Column(name = "currPayableAmtSymbol"), @Column(name =
	 * "currPayableAmtShortName") })
	 */
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "currPayableAmtValue")),
			@AttributeOverride(name = "name", column = @Column(name = "currPayableAmtName")),
			@AttributeOverride(name = "symbol", column = @Column(name = "currPayableAmtSymbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "currPayableAmtShortName")) })
	@Access(AccessType.FIELD)
	private Amount currentPayable;

	public RemitAdviceSummary() {

	}

	public Amount getCurrentReceivable() {
		return currentReceivable;
	}

	public void setCurrentReceivable(Amount currentReceivables) {
		this.currentReceivable = currentReceivables;
	}

	public Amount getCurrentPayable() {
		return currentPayable;
	}

	public void setCurrentPayable(Amount currentPayables) {
		this.currentPayable = currentPayables;
	}

}
