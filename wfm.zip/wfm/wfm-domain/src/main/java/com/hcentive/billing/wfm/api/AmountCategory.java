package com.hcentive.billing.wfm.api;

public enum AmountCategory {
	PREMIUM, FEE, DISCOUNT, TAX, SUBSIDY, OTHER_CHARGE, PAYMENT, WRITEOFF, OUTSTANDING_BALANCE, WRITE_ON, WRITEON, REFUND, CREDIT,PRIOR_DUE;

	/**
	 * @param type
	 * @return
	 */
	public static AmountCategory parse(String type) {
		return AmountCategory.valueOf(type);
	}
}
