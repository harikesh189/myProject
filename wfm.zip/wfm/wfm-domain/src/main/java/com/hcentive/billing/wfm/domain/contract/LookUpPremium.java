package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "premium")
@DiscriminatorValue("LookUp")
public class LookUpPremium extends DynamicPremium {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2603751455121000989L;

	public LookUpPremium() {

	}

}
