/**
 *
 */
package com.hcentive.billing.wfm.domain.manualadjustment;

import static com.hcentive.billing.core.commons.util.CollectionUtil.nullSafe;

import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.util.ManualAdjustmentStatus;

/**
 *
 * Captures money transferred from one billing account to other.
 *
 * @author sambhav.jain
 *
 */
@Entity
@Table(name = "manual_adjustment")
@DiscriminatorValue("Money-Transfer")
public class MoneyTransferRecord extends ManualAdjustment {

	private static final long serialVersionUID = 1L;
	
	public static final String MONEY_TRANSFER_RECORD_TYPE = "Money-Transfer";
	public static final String AUTO_MONEY_TRANSFER_RECORD_TYPE = "Auto-Money-Transfer";

	public MoneyTransferRecord() {

	}

	public MoneyTransferRecord(final BillingAccount from, final BillingAccount paymentFor, final Amount amount, final String type, MoneyTransferRecord moneyTransfer) {
		
		this.setPayerSubscription(from);
		this.setPaymentFor(paymentFor);
		this.setAmountPaid(amount);
		this.setStatus(ManualAdjustmentStatus.INITIATED);
		this.setName(moneyTransfer.getName());
		this.setDescription(moneyTransfer.getDescription());
		this.setInitDate(moneyTransfer.getInitDate());
		if(StringUtils.isBlank(type)) {
			this.setType(this.typeName());
		} else {
			this.setType(type);
		}
	}
	
public MoneyTransferRecord(final BillingAccount from, final BillingAccount paymentFor, final Amount amount, final String type) {
		
		this.setPayerSubscription(from);
		this.setPaymentFor(paymentFor);
		this.setAmountPaid(amount);
		this.setStatus(ManualAdjustmentStatus.INITIATED);
		if(StringUtils.isBlank(type)) {
			this.setType(this.typeName());
		} else {
			this.setType(type);
		}
	}

	public Amount getAmountPaid() {
		return this.getManualAdjAmount();
	}

	/**
	 * @return the targetAccount
	 */
	public BillingAccount getPayerSubscription() {
		final List<ManualAdjustmentParty> partiesInvolved = nullSafe(this.getParties());
		for (final ManualAdjustmentParty manualAdjustmentParty : partiesInvolved) {
			if (manualAdjustmentParty != null && manualAdjustmentParty.getPartyCategory() == ManualAdjustmentPartyCategory.PRIMARY) {
				return manualAdjustmentParty.getPartyBillingAccount();
			}
		}
		return null;
	}

	public BillingAccount getPaymentFor() {
		final List<ManualAdjustmentParty> partiesInvolved = nullSafe(this.getParties());
		for (final ManualAdjustmentParty manualAdjustmentParty : partiesInvolved) {
			if (manualAdjustmentParty != null && manualAdjustmentParty.getPartyCategory() == ManualAdjustmentPartyCategory.SECONDARY) {
				return manualAdjustmentParty.getPartyBillingAccount();
			}
		}
		return null;
	}

	public DateTime getTxnDate() {
		return this.getEffectiveDate();
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setAmountPaid(final Amount amountPaid) {
		this.setManualAdjAmount(amountPaid);
	}

	public void setPayerSubscription(final BillingAccount billingAccount) {
		this.addParty(new ManualAdjustmentParty(ManualAdjustmentPartyCategory.PRIMARY, billingAccount));
	}

	public void setPaymentFor(final BillingAccount paymentFor) {
		if(paymentFor!=null)
		this.addParty(new ManualAdjustmentParty(ManualAdjustmentPartyCategory.SECONDARY, paymentFor));
	}

	public void setTxnDate(final DateTime txnDate) {
		this.setEffectiveDate(txnDate);
	}

	@Override
	public String typeName() {
		return MONEY_TRANSFER_RECORD_TYPE;
	}
}
