package com.hcentive.billing.wfm.domain.ft;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.domain.enumtype.FinancialTrxnStatus;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountAttribute;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.ft.FTEntryAssociationType;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventQualifier;
import com.hcentive.billing.wfm.api.enumeration.ft.GLEntryCategory;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.InsuranceCoverage;
import com.hcentive.billing.wfm.domain.contract.InsuredMember;
import com.hcentive.billing.wfm.domain.ft.rule.GLEntryTemplate;

@Entity
@Table(name = "financial_trxn_entry")
@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("rawtypes")
public class FinancialTrxnEntry extends ReferenceableDomainEntity<FinancialTrxnEntry, String> {

	private static final long serialVersionUID = 1L;

	@Enumerated(EnumType.STRING)
	@Column(name = "event_qualifier")
	private FinancialEventQualifier eventQualifier = FinancialEventQualifier.DEFAULT;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "amount_category")
	private AmountCategory amountCategory;

	@Access(AccessType.FIELD)
	@Column(name = "amount_code")
	private String amountCode;

	@Access(AccessType.FIELD)
	@Column(name = "amount_name")
	private String amountName;

	@ManyToOne
	@JoinColumn(name = "associated_entity_account_id", nullable = false)
	private BillingAccount associatedEntityBillingAccount;

	@OneToMany(mappedBy = "parentFTEntry", cascade = CascadeType.ALL, orphanRemoval = true)
	@Access(AccessType.FIELD)
	@JsonIgnore
	@PrimaryKeyJoinColumn
	// @JoinTable(name="financial_trxn_entry_associations")
	private final Set<FTEntryAssociation> associations = new HashSet<>();

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "billing_begins_on", nullable = false)),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "billing_ends_on", nullable = false)) })
	@Access(AccessType.FIELD)
	private Period billingPeriod;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "coverage_begins_on", nullable = false)),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "coverage_ends_on", nullable = false)) })
	@Access(AccessType.FIELD)
	private Period coveragePeriod;

	@Column(name = "description")
	private String description;

	@JoinColumn(name = "financial_trxn_id")
	@ManyToOne
	private FinancialTransaction financialTransaction;

	@ManyToOne
	@JoinColumn(name = "insured_member_id", nullable = false)
	private InsuredMember ftFor;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "gl_entry_id")
	@Access(AccessType.FIELD)
	private GLEntry glEntry;

	@ManyToOne
	@JoinColumn(name = "insurance_plan_id", nullable = false)
	private InsuranceCoverage insurancePlan;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "settled_amount_value")),
	        @AttributeOverride(name = "name", column = @Column(name = "settled_amount_name")),
	        @AttributeOverride(name = "symbol", column = @Column(name = "settled_amount_symbol")),
	        @AttributeOverride(name = "shortName", column = @Column(name = "settled_amount_short_name")) })
	private Amount settledAmount;

	@Column(name = "status", nullable = false)
	@Enumerated(EnumType.STRING)
	@Access(AccessType.FIELD)
	private FinancialTrxnStatus status;

	public FinancialTrxnEntry(final String identity) {
		super(identity);
	}

	public FinancialTrxnEntry(final String identity, final String externalId) {
		super(identity);
		this.externalId = externalId;
	}

	protected FinancialTrxnEntry() {

	}

	public void addAllAssocsByType(final Collection<FinancialTrxnEntry> associatedEntries, final FTEntryAssociationType assocType) {
		for (final FinancialTrxnEntry assocEntry : associatedEntries) {
			this.addAssocByType(assocEntry, assocType);
		}
	}

	public void addAssocByType(final FinancialTrxnEntry associatedEntry, final FTEntryAssociationType assocType) {
		this.associations.add(new FTEntryAssociation(this, associatedEntry, assocType));
	}

	public void addFTEntryAssociation(final FTEntryAssociation assoc) {
		this.associations.add(assoc);
	}

	public Set<FinancialTrxnEntry> getAllAssocEntriesByType(final FTEntryAssociationType assocType) {
		final Set<FinancialTrxnEntry> associatedEntries = new HashSet<>();
		for (final FTEntryAssociation assoc : this.associations) {
			if (assocType.equals(assoc.getAssocType())) {
				associatedEntries.add(assoc.getAssociatedFTEntry());
			}
		}
		return associatedEntries;
	}

	public AmountCategory getAmountCategory() {
		return this.amountCategory;
	}

	public String getAmountCode() {
		return this.amountCode;
	}

	public String getAmountName() {
		return this.amountName;
	}

	public BillingAccount getAssociatedEntityBillingAccount() {
		return this.associatedEntityBillingAccount;
	}

	public Set<FTEntryAssociation> getAssociations() {
		return this.associations;
	}

	public Period getBillingPeriod() {
		return this.billingPeriod;
	}

	public Period getCoveragePeriod() {
		return this.coveragePeriod;
	}

	public String getDescription() {
		return this.description;
	}

	public FinancialTransaction getFinancialTransaction() {
		return this.financialTransaction;
	}

	public InsuredMember getFtFor() {
		return this.ftFor;
	}

	public GLEntry getGlEntry() {
		return this.glEntry;
	}

	public InsuranceCoverage getInsurancePlan() {
		return this.insurancePlan;
	}

	public Amount getRemainingAmount() {
		if (null == settledAmount) {
			return this.glEntry.getAmount();
		}
		return this.glEntry.getAmount().subtract(this.settledAmount);
	}

	public Amount getSettledAmount() {
		return settledAmount;
	}

	public FinancialTrxnStatus getStatus() {
		return status;
	}

	public boolean isHolding() {
		return this.getGlEntry().getGlAccount().isHoldingAccount();
	}

	public boolean isCompletelySettled() {
		if (null != this.status && this.status.equals(FinancialTrxnStatus.SETTLED)) {
			return true;
		}
		return false;
	}
	
	public boolean isPartiallyOrCompletelySettled() {
		return null != this.status && (FinancialTrxnStatus.SETTLED.equals(getStatus())
				|| FinancialTrxnStatus.PARTIAL_SETTLED.equals(getStatus()));
	}

	@Override
	public String refValue() {
		return this.getIdentity();
	}

	public void removeAllAssocsByType(final FTEntryAssociationType assocType) {
		for (final FTEntryAssociation assoc : this.associations) {
			if (assocType.equals(assoc.getAssocType())) {
				assoc.setActive(false);
			}
		}
	}

	public void setAmountCategory(final AmountCategory amountCategory) {
		this.amountCategory = amountCategory;
	}

	public void setAmountCode(final String amountCode) {
		this.amountCode = amountCode;
	}

	public void setAmountName(final String amountName) {
		this.amountName = amountName;
	}

	public void setAssociatedEntityBillingAccount(final BillingAccount associatedEntityBillingAccount) {
		this.associatedEntityBillingAccount = associatedEntityBillingAccount;
	}

	public void setBillingPeriod(final Period billingPeriod) {
		this.billingPeriod = billingPeriod;
	}

	public void setCoveragePeriod(final Period coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public void setFinancialTransaction(final FinancialTransaction financialTransaction) {
		this.financialTransaction = financialTransaction;
	}

	public void setFtFor(final InsuredMember ftFor) {
		this.ftFor = ftFor;
	}

	public void setGlEntry(final GLEntry glEntry) {
		this.glEntry = glEntry;
	}

	public void setInsurancePlan(final InsuranceCoverage insurancePlan) {
		this.insurancePlan = insurancePlan;
	}

	public void setSettledAmount(Amount settledAmount) {
		this.settledAmount = settledAmount;
	}

	public void setStatus(FinancialTrxnStatus status) {
		this.status = status;
	}

	// Do no delete this method. It is used in logs.
	@Override
	public String toString() {
		final StringBuilder builder2 = new StringBuilder();
		builder2.append("FinancialTrxnEntry [identity=");
		builder2.append(identity);
		builder2.append(", externalId=");
		builder2.append(externalId);
		builder2.append(", amountCategory=");
		builder2.append(amountCategory);
		builder2.append(", amountCode=");
		builder2.append(amountCode);
		builder2.append(", eventQualifier=");
		builder2.append(eventQualifier);
		builder2.append(", glEntry=");
		builder2.append(glEntry);
		builder2.append(", financialTransaction=");
		builder2.append(null != financialTransaction? financialTransaction.getIdentity(): null);
		builder2.append(", associations=");
		builder2.append(associations);
		builder2.append(", status=");
		builder2.append(status);
		builder2.append(", amountName=");
		builder2.append(amountName);
		builder2.append(", associatedEntityBillingAccount=");
		builder2.append(null !=associatedEntityBillingAccount? associatedEntityBillingAccount.getIdentity():null);
		builder2.append(", ftFor=");
		builder2.append(ftFor);
		builder2.append(", insurancePlan=");
		builder2.append(null != insurancePlan ? insurancePlan.getIdentity(): null);
		builder2.append(", billingPeriod=");
		builder2.append(billingPeriod);
		builder2.append(", coveragePeriod=");
		builder2.append(coveragePeriod);
		builder2.append(", description=");
		builder2.append(description);
		builder2.append(", settledAmount=");
		builder2.append(settledAmount);
		builder2.append("]");
		return builder2.toString();
	}

	@Override
	public String typeName() {
		return "FinancialTrxnEntry";
	}

	public Set<FinancialTrxnEntry> reverse(boolean reverseRLine, 
			FinancialEventQualifier eventQualifier, Map<String, BillingAccount> swapBAs) {
		
		final Set<FinancialTrxnEntry> reversedEntries = new LinkedHashSet<>();
		if (this.getGlEntry().isReversible()) {
			final FinancialTrxnEntry reversedResult = new FinancialTrxnEntry(RandomGenerator.randomString());
			reversedResult.setAmountCategory(this.getAmountCategory());
			reversedResult.setAmountCode(this.getAmountCode());
			reversedResult.setGlEntry(this.getGlEntry().reverse());
			reversedResult.setExternalId(this.getExternalId());
			reversedResult.setStatus(FinancialTrxnStatus.NEW);
			reversedResult.setOperator(this.getOperator());

			BillingAccount glBillingAcct = this.getGlEntry().getBillingAccount();
			if(swapBAs !=  null && swapBAs.containsKey(glBillingAcct.getIdentity())) {
				BillingAccount swappedBA = swapBAs.get(glBillingAcct.getIdentity());
				if (swappedBA != null) {
					reversedResult.getGlEntry().setBillingAccount(swappedBA);
				}
			} 
			
			reversedResult.setAssociatedEntityBillingAccount(this.getAssociatedEntityBillingAccount());
			reversedResult.setInsurancePlan(this.getInsurancePlan());
			reversedResult.setFtFor(this.getFtFor());
			reversedResult.setBillingPeriod(this.getBillingPeriod());
			reversedResult.setCoveragePeriod(this.getCoveragePeriod());
			reversedResult.setDescription(this.getDescription());

			reversedResult.setEventQualifier(eventQualifier);
			
			reversedResult.setAmountName(this.getAmountName());

			reversedResult.addReferences(getReferenceSet().getReferences());

			reversedEntries.add(reversedResult);

			if (reverseRLine && this.associations != null && reverseRLine) {
				reversedEntries.addAll(reverseRLineEntries(false, eventQualifier, swapBAs));
			}
		}
		return reversedEntries;
	}
	
	public Set<FinancialTrxnEntry> reverseRLineEntries(boolean deactivateAssociation, 
			FinancialEventQualifier eventQualifier, Map<String, BillingAccount> swapBAs) {
		
		final Set<FinancialTrxnEntry> reversedEntries = new LinkedHashSet<>();
		
		for (final FTEntryAssociation assoc : this.associations) {
			if (assoc.getAssocType() == FTEntryAssociationType.R_LINE && assoc.isActive()) {
				reversedEntries.addAll(assoc.getAssociatedFTEntry().reverse(false, eventQualifier, swapBAs));
				if (deactivateAssociation) {
					assoc.setActive(false);
				}
			}
		}
		
		return reversedEntries;
	}

	public static class Builder {
		private static Logger logger = LoggerFactory.getLogger(Builder.class);

		private Amount amount;
		private AmountCategory amountCategory;
		private String amountCode;
		private String amountName;
		private final BillingAccount associatedEntityBillingAccount;
		private final BillingAccount billingAccount;
		private final Period billingPeriod;
		private final Period coveragePeriod;
		private String description = null;
		private final InsuredMember ftFor;
		private final GLEntryCategory glCategory;
		private final GLEntryTemplate glEntryTemplate;
		private final InsuranceCoverage insurancePlan;
		private final Collection<Reference> references = new ArrayList<>();
		private final FinancialTrxnStatus status;
		private final FinancialEventQualifier eventQualifier;

		public Builder(final GLEntryTemplate glEntryTemplate, final BillingAccount billingAccount, final AmountAttribute amountAttr,
		        final BillingAccount associatedEntityBillingAccount, final InsuranceCoverage insurancePlan, final InsuredMember ftFor,
		        final Period billingPeriod, final Period coveragePeriod, final FinancialEventQualifier eventQualifier) {
			this.glEntryTemplate = glEntryTemplate;
			this.billingAccount = billingAccount;

			this.associatedEntityBillingAccount = associatedEntityBillingAccount;
			this.insurancePlan = insurancePlan;
			this.billingPeriod = billingPeriod;
			this.coveragePeriod = coveragePeriod;
			this.ftFor = ftFor;
			this.glCategory = glEntryTemplate.getCategory();
			this.eventQualifier = eventQualifier;

			if (amountAttr != null) {
				this.amountCategory = amountAttr.getCategory() == null ? glEntryTemplate.getAmountCategory() : amountAttr.getCategory();
				this.amount = amountAttr.getValue();
				this.amountName = amountAttr.getAmountName();
				this.amountCode = amountAttr.getCode();
				this.description = amountAttr.getDescription();
				if (isNotEmpty(amountAttr.getReferences())) {
					this.references.addAll(amountAttr.getReferences());
				}
			}
			this.status = glEntryTemplate.getStatus();
		}

		public Builder(final GLEntryTemplate glEntryTemplate, final FinancialTrxnEntry financialTrxnEntry, final Amount remainingAmount) {

			this(glEntryTemplate, financialTrxnEntry.getGlEntry().getBillingAccount(), financialTrxnEntry.getAssociatedEntityBillingAccount(),
			        financialTrxnEntry.getInsurancePlan(), financialTrxnEntry.getFtFor(), financialTrxnEntry.getBillingPeriod(), financialTrxnEntry
			                .getCoveragePeriod(), financialTrxnEntry.getAmountCategory(), financialTrxnEntry.getAmountCode(), remainingAmount,
			        financialTrxnEntry.getAmountName(), financialTrxnEntry.getGlEntry().getCategory(), financialTrxnEntry.getReferenceSet().getReferences(),
			        financialTrxnEntry.getDescription(), financialTrxnEntry.getEventQualifier());
		}

		private Builder(final GLEntryTemplate glEntryTemplate, final BillingAccount billingAccount, final BillingAccount associatedEntityBiilingAccount,
		        final InsuranceCoverage insurancePlan, final InsuredMember ftFor, final Period billingPeriod, final Period coveragePeriod,
		        final AmountCategory amountCategory, final String amountCode, final Amount amount, final String amountName, final GLEntryCategory glCategory,
		        final Collection<Reference> references, final String description, final FinancialEventQualifier eventQualifier) {

			this.glEntryTemplate = glEntryTemplate;
			this.billingAccount = billingAccount;

			this.status = glEntryTemplate.getStatus();
			this.associatedEntityBillingAccount = associatedEntityBiilingAccount;
			this.insurancePlan = insurancePlan;
			this.ftFor = ftFor;
			this.billingPeriod = billingPeriod;
			this.coveragePeriod = coveragePeriod;
			this.eventQualifier = eventQualifier;

			this.amountCategory = glEntryTemplate.getAmountCategory() == null ? amountCategory : glEntryTemplate.getAmountCategory();
			this.glCategory = glEntryTemplate.getCategory() == null ? glCategory : glEntryTemplate.getCategory();
			this.amount = amount;
			this.amountName = amountName;
			this.amountCode = glEntryTemplate.getEventAmountCode() == null ? amountCode : glEntryTemplate.getEventAmountCode();
			this.description = description;
			if (isNotEmpty(references)) {
				this.references.addAll(references);
			}
		}

		public FinancialTrxnEntry build() {
			final FinancialTrxnEntry ftTrxnEntry = new FinancialTrxnEntry(RandomGenerator.randomString());
			logger.debug("Create GL Entry for using template {}", this.glEntryTemplate);

			ftTrxnEntry.setGlEntry(new GLEntry(this.amount, this.billingAccount, this.glCategory, this.glEntryTemplate.getGlAccount(), this.glEntryTemplate
			        .getPostingType(), !this.glEntryTemplate.isNonReversible()));

			ftTrxnEntry.setAssociatedEntityBillingAccount(this.associatedEntityBillingAccount);
			ftTrxnEntry.setInsurancePlan(this.insurancePlan);
			ftTrxnEntry.setFtFor(this.ftFor);
			ftTrxnEntry.setBillingPeriod(this.billingPeriod);
			ftTrxnEntry.setCoveragePeriod(this.coveragePeriod);
			ftTrxnEntry.setDescription(this.description);
			ftTrxnEntry.setEventQualifier(this.eventQualifier);

			ftTrxnEntry.setAmountCode(amountCode);
			if (isNotEmpty(this.references)) {
				ftTrxnEntry.addReferences(this.references);
			}
			ftTrxnEntry.setAmountCategory(this.amountCategory);
			ftTrxnEntry.setAmountName(this.amountName);
			ftTrxnEntry.setStatus(this.status);
			return ftTrxnEntry;
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			final StringBuilder builder = new StringBuilder();
			builder.append("Builder [amount=");
			builder.append(this.amount);
			builder.append(", eventQualifier=");
			builder.append(this.eventQualifier);
			builder.append(", amountCategory=");
			builder.append(this.amountCategory);
			builder.append(", amountCode=");
			builder.append(this.amountCode);
			builder.append(", amountName=");
			builder.append(this.amountName);
			builder.append(", billingAccount=");
			builder.append(this.billingAccount);
			builder.append(", glEntryTemplate=");
			builder.append(this.glEntryTemplate);
			builder.append(", associatedEntityBillingAccount=");
			builder.append(this.associatedEntityBillingAccount);
			builder.append(", insurancePlan=");
			builder.append(this.insurancePlan);
			builder.append(", ftFor=");
			builder.append(this.ftFor);
			builder.append(", billingPeriod=");
			builder.append(this.billingPeriod);
			builder.append(", coveragePeriod=");
			builder.append(this.coveragePeriod);
			builder.append(", references=");
			builder.append(this.references);
			builder.append("]");
			return builder.toString();
		}
	}

	public FinancialEventQualifier getEventQualifier() {
		return eventQualifier;
	}

	public void setEventQualifier(FinancialEventQualifier eventQualifier) {
		this.eventQualifier = eventQualifier;
	}
}