package com.hcentive.billing.wfm.api;

import java.util.Set;

import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventQualifier;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType;

public interface FinancialEvent {

	DateTime getEventDate();

	String getEventId();
	
	String getEventAdditionalId();

	Set<FinancialEventRecord> getEventRecords();

	FinancialEventType getType();

	FinancialEventQualifier getQualifier();

}
