package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.Address;
import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "contract_info")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "info_type")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class ContractInfo extends BaseEntity implements TenantAware, Effectivity {

	/**
	 *
	 */
	private static final long serialVersionUID = 6394556324127304276L;

	@Access(AccessType.FIELD)
	@Column(name = "contract_title")
	private String contractTitle;

	@Access(AccessType.FIELD)
	@Column(name = "contract_id")
	private String contractId;

	@Embedded
	@AttributeOverride(name = "type", column = @Column(name = "type"))
	private ContractType type;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "created_on")) })
	@Access(AccessType.FIELD)
	private DateTime createdOn;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "renewal_date")) })
	@Access(AccessType.FIELD)
	private DateTime renewalDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "terminated_on")) })
	@Access(AccessType.FIELD)
	private DateTime terminatedOn;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "coverage_begins_on")),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "coverage_ends_on")) })
	@Access(AccessType.FIELD)
	private Period coveragePeriod;

	@Access(AccessType.FIELD)
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "billing_start_date")) })
	private DateTime billingStartDate;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "create_address_id")
	@Access(AccessType.FIELD)
	private Address createLocation;

	@Access(AccessType.FIELD)
	@Column(name = "description")
	private String description;

	@Column(name = "subscriber_id")
	@Access(AccessType.FIELD)
	private String subscriberExtId;

	@Access(AccessType.FIELD)
	@Column(name = "subscriber_name")
	private String subscriberName;

	@Access(AccessType.FIELD)
	@Column(name = "employer_group_id")
	private String employerGroupId;

	@Access(AccessType.FIELD)
	@Column(name = "employer_group_name")
	private String employerGroupName;

	@Access(AccessType.FIELD)
	@Column(name = "contract_record_id")
	private String contractRecordId;

	@Access(AccessType.FIELD)
	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;
	
	@Access(AccessType.FIELD)
	@Column(name = "has_family_coverage")
	private Boolean hasFamilyCoverage;
	
	@Access(AccessType.FIELD)
	@Column(name = "subscription_external_id")
	private String subscriptionExternalId;
	
	@Access(AccessType.FIELD)
	@Column(name = "subscription_identity")
	private String subscriptionIdentity;
	

	// protected ContractInfo(){
	//
	// }

	
	public ContractInfo() {
	}

	protected ContractInfo(String contractId, String title) {

	}

	

	public String getSubscriptionExternalId() {
		return subscriptionExternalId;
	}

	public void setSubscriptionExternalId(String subscriptionExternalId) {
		this.subscriptionExternalId = subscriptionExternalId;
	}

	public String getSubscriptionIdentity() {
		return subscriptionIdentity;
	}

	public void setSubscriptionIdentity(String subscriptionIdentity) {
		this.subscriptionIdentity = subscriptionIdentity;
	}

	public String getContractTitle() {
		return contractTitle;
	}

	public void setContractTitle(String contractTitle) {
		this.contractTitle = contractTitle;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getContractRecordId() {
		return contractRecordId;
	}

	public DateTime getCreatedOn() {
		return createdOn;
	}

	public Address getCreateLocation() {
		return createLocation;
	}

	public String getDescription() {
		return description;
	}

	public Period getCoveragePeriod() {
		return coveragePeriod;
	}

	public DateTime getBillingStartDate() {
		return billingStartDate;
	}

	public String getEmployerGroupId() {
		return employerGroupId;
	}

	public String getEmployerGroupName() {
		return employerGroupName;
	}

	public String getSubscriberExtId() {
		return subscriberExtId;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public DateTime getTerminatedOn() {
		return terminatedOn;
	}

	public ContractType getType() {
		return type;
	}

	public void setContractRecordId(String contractRecordId) {
		this.contractRecordId = contractRecordId;
	}

	public void setCreatedOn(DateTime createdOn) {
		this.createdOn = createdOn;
	}

	public void setCreateLocation(Address createLocation) {
		this.createLocation = createLocation;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setCoveragePeriod(Period coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}

	public void setBillingStartDate(DateTime billingStartDate) {
		this.billingStartDate = billingStartDate;
	}

	public void setEmployerGroupId(String employerGroupId) {
		this.employerGroupId = employerGroupId;
	}

	public void setEmployerGroupName(String employerGroupName) {
		this.employerGroupName = employerGroupName;
	}

	public void setSubscriberExtId(String subscriberExtId) {
		this.subscriberExtId = subscriberExtId;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public void setTerminatedOn(DateTime terminatedOn) {
		this.terminatedOn = terminatedOn;
	}

	public void setType(ContractType type) {
		this.type = type;
	}

	public Period getEffectivePeriod() {
		if (billingStartDate == null || billingStartDate.isBeforeOrEquals(coveragePeriod.getBeginsOn())) {
			return coveragePeriod;
		} else if (billingStartDate.isAfter(coveragePeriod.getEndsOn())) {
			return null;
		}
		return new Period(billingStartDate, coveragePeriod.getEndsOn());
	}

	@Override
	public String getTenantId() {
		return this.tenantId;
	}

	
	@Override
	public Period effectivePeriod() {
		return getEffectivePeriod();
	}
	
	public Boolean hasFamilyCoverage() {
		return hasFamilyCoverage;
	}

	public void setHasFamilyCoverage(boolean hasFamilyCoverage) {
		this.hasFamilyCoverage = hasFamilyCoverage;
	}

	/**
	 * @return the renewalDate
	 */
	public DateTime getRenewalDate() {
		return renewalDate;
	}

	/**
	 * @param renewalDate the renewalDate to set
	 */
	public void setRenewalDate(DateTime renewalDate) {
		this.renewalDate = renewalDate;
	}
	
	
	
}
