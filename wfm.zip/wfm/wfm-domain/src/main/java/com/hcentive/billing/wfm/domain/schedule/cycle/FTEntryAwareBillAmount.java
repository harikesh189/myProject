package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.FTEntryAware;

@Entity
@DiscriminatorValue("FT_BILL_AMT")
public class FTEntryAwareBillAmount extends BillAmount implements FTEntryAware {

	private static final long serialVersionUID = 2642544743874769687L;

	@ElementCollection(fetch = FetchType.EAGER)
	@Column(name = "ft_entry_id")
	@CollectionTable(name = "bill_amount_ft_entry_ids", joinColumns = @JoinColumn(name = "bill_amount_id"))
	private Set<String> ftEntryIds;
	


	protected FTEntryAwareBillAmount() {
	}

	public FTEntryAwareBillAmount(final String amountCode, final String name,
			final AmountCategory type, final Amount amount,
			final Set<String> ftEntryIds, AmountGroup amtGrp, String desc, 
			Period period, DateTime associatedDate) {
		super(amountCode, name, amount, type, amtGrp, desc, period, associatedDate);
		this.ftEntryIds = ftEntryIds;
		
	
	}

	@Override
	public Set<String> ftEntryIds() {
		return this.ftEntryIds;
	}

	@Override
	public String toString() {
		return super.toString() + ", FT entries: " + this.ftEntryIds;
	}

}
