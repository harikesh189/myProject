package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "eligibility_factor")
@DiscriminatorValue("GeoLocation")
public class GeoLocationFactor extends EligibilityFactor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5279123781341440495L;

	@Access(AccessType.FIELD)
	@Column(name = "county")
	private String county;

	@Access(AccessType.FIELD)
	@Column(name = "msa")
	private String msa; // Metropolitan Statistical Area

	@Access(AccessType.FIELD)
	@Column(name = "zipcode")
	private String zipcode;

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getMsa() {
		return msa;
	}

	public void setMsa(String msa) {
		this.msa = msa;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipCode) {
		this.zipcode = zipCode;
	}

}
