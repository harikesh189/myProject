package com.hcentive.billing.wfm.domain.contract.mixin;

import java.util.Collection;

public interface InvoiceTypeAware {
	Collection<String> getInvoiceTypes();
}
