package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum BillingConfigCoverageType {
	FAMILY, SELF, SELF_PLUS_ONE, SELF_PLUS_THREE, SELF_PLUS_TWO;
}
