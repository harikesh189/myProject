package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.FeeClass;

/**
 * It represent the bill configuration related to calculation of fee.
 *
 * @author nitin.singla
 */
public abstract class BillingConfigFee<V> extends FinancialCharge<V> {

	private static final long serialVersionUID = 1L;
	@NotNull
	@Column(name = "fee_type")
	private String type;


	public BillingConfigFee() {
		super(ConfigType.FEE);
	}

	public void setType(final String type) {
		this.type = type;
	}

	@Override
	public String name() {
		return this.getType();
	}

	@Override
	public String getType() {
		return this.type;
	}

}
