package com.hcentive.billing.wfm.domain.event;

import java.io.Serializable;

import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

public class PaymentRecordChangePayload implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5710557844410060981L;
	private final PaymentRecord record;
	private final String oldStatus;

	public PaymentRecordChangePayload(PaymentRecord record, String oldStatus) {
		super();
		this.record = record;
		this.oldStatus = oldStatus;
	}

	public PaymentRecord getRecord() {
		return record;
	}

	public String getOldStatus() {
		return oldStatus;
	}

}
