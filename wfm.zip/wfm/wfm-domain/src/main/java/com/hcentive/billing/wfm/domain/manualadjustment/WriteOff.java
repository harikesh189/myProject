package com.hcentive.billing.wfm.domain.manualadjustment;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;



/**
 * Class to represent Write-Off Adjustment.
 * 
 * @author ajay.saxena
 *
 */
@Entity
@Table(name = "manual_adjustment")
@DiscriminatorValue("Write-Off")
public class WriteOff extends ManualAdjustment{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7522086056116985594L;

	@Override
	public String typeName() {
		// TODO Auto-generated method stub
		return "Write-Off";
	}

}
