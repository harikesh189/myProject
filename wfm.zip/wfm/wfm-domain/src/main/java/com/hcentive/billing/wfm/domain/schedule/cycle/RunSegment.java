package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.io.Serializable;
import java.util.Comparator;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "billing_account_run_segment")
public class RunSegment extends BaseEntity {

	private static final long serialVersionUID = 1L;

	public static enum RunType {
		
		VOID_ORIGINAL(1), BILL_CURRENT(2), GENERATE_INVOICE(3);
		
		private int executionOrder;
		
		private RunType(int executionOrder) {
			this.executionOrder = executionOrder;
		}

		public int getExecutionOrder() {
			return executionOrder;
		}
		 
	}
	
	public static class RunSegmentComparator implements Comparator<RunSegment>,Serializable {
		private static final long serialVersionUID = 1L;

		@Override
		public int compare(RunSegment o1, RunSegment o2) {
			return o1.getType().getExecutionOrder() - o2.getType().getExecutionOrder();
		}
		
	}
	
	public static enum Status {
		PENDING, INIT_STARTED, INIT_COMPLETE, RUNNING, RUN_COMPLETE
	}
	
	@Enumerated(EnumType.STRING)
	@Column(name = "run_type")
	private RunType type;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private Status status;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "executed_at")) })
	private DateTime executionDate;
	
	protected RunSegment() {
	}
	
	public RunSegment(RunType type) {
		super();
		this.type = type;
		this.status = Status.PENDING;
	}

	public RunType getType() {
		return type;
	}

	public void setType(RunType type) {
		this.type = type;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public boolean isInitPending() {
		return Status.PENDING.equals(status);
	}

	public DateTime getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(DateTime executionDate) {
		this.executionDate = executionDate;
	}

	public boolean isRunnable() {
		return status.equals(Status.INIT_COMPLETE);
	}
	
}
