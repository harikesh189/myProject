package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BillingToleranceStrategy;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class BillingConfigTolerance extends BillingRuleConfig implements
		AmountAware {

	private static final long serialVersionUID = -7664680485661707291L;

	private Amount amount;

	@NotNull
	private BillingToleranceStrategy toleranceStrategy;

	@Min(0)
	@Max(100)
	private double percentage;
	

	public BillingConfigTolerance() {
		super(ConfigType.TOLERANCE);
	}

	@Override
	public Amount getAmount() {
		return this.amount;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	public BillingToleranceStrategy getToleranceStrategy() {
		return toleranceStrategy;
	}

	public void setToleranceStrategy(BillingToleranceStrategy toleranceStrategy) {
		this.toleranceStrategy = toleranceStrategy;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

}
