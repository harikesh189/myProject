package com.hcentive.billing.wfm.domain.ft.rule;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "gl_entry_attr_ref")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "ref_type")
public abstract class GLEntryAttributeRef<D> extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public abstract D refData();

}
