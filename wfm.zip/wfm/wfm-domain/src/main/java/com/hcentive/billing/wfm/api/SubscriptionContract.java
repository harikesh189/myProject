package com.hcentive.billing.wfm.api;

import com.hcentive.billing.wfm.domain.contract.ContractType;

public interface SubscriptionContract<T extends ContractType, CI> extends
		FinancialContract<T, CI>, BillingFrequenceAware, ProRatingAware {

}
