package com.hcentive.billing.wfm.domain.payment;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import com.hcentive.billing.core.commons.api.BusinessEntityAware;
import com.hcentive.billing.core.commons.api.SubscriptionAware;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.EbillSubscription;
import com.hcentive.billing.core.commons.domain.LineItem;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.PaymentRecordType;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@Entity
@DiscriminatorValue("Payment_Record")
public class PaymentRecord extends AbstractPaymentRecord<PaymentRecord, String> implements BusinessEntityAware<BusinessEntity>, SubscriptionAware,
        BillingAccountAware {

	/**
	 *
	 */
	private static final long serialVersionUID = -4668604309065460574L;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "discount_value")),
	        @AttributeOverride(name = "name", column = @Column(name = "discount_name")),
	        @AttributeOverride(name = "symbol", column = @Column(name = "discount_symbol")),
	        @AttributeOverride(name = "shortName", column = @Column(name = "discount_short_name")) })
	private Amount discount;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "total_paid_value")),
	        @AttributeOverride(name = "name", column = @Column(name = "total_paid_name")),
	        @AttributeOverride(name = "symbol", column = @Column(name = "total_paid_symbol")),
	        @AttributeOverride(name = "shortName", column = @Column(name = "total_paid_short_name")) })
	private Amount invoiceDueAmount;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "payment_record_line_items", joinColumns = @JoinColumn(name = "payment_record_id"), inverseJoinColumns = @JoinColumn(
	        name = "line_item_id"))
	private final Set<LineItem> lineItems = new HashSet<>();

	@Column(name = "source")
	private String src;

	@Column(name = "payment_mode")
	private String paymentMode;

	@Column(name = "type")
	private String paymentType;

	@Column(name = "gateway_confirmation_number")
	private String gatewayConfirmationNumber;

	@Column(name = "batch_id")
	private String batchID;

	@Column(name = "batch_record_id")
	private String batchRecordId;

	@Column(name = "record_type")
	@Enumerated(EnumType.STRING)
	private PaymentRecordType recordType;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "payment_effective_date")) })
	private DateTime paymentEffectiveDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "original_payment_date")) })
	private DateTime originalPaymentDate;

	@OneToOne
	@JoinColumn(name = "billing_account_id")
	private BillingAccount paymentFor;

	@ManyToOne(targetEntity = EbillSubscription.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "subscription_id")
	@Access(AccessType.FIELD)
	private EbillSubscription subscription;

	@Transient
	private String subscriptionName;
	
	@Transient
	private String subscriptionId;

	public PaymentRecord() {
		super();
		
		this.setStatus(STATUS_INITIATED);
		this.recordType = PaymentRecordType.PAYMENT;
	}

	public PaymentRecord(final String identity) {
		super(identity);
		this.setStatus(STATUS_INITIATED);
		this.recordType = PaymentRecordType.PAYMENT;
	}

	public PaymentRecord(final String identity, final String externalId) {
		super(identity);
		this.externalId = externalId;
		this.setStatus(STATUS_INITIATED);
		this.recordType = PaymentRecordType.PAYMENT;
	}

	public void addLineItem(final LineItem lineItem) {
		this.lineItems.add(lineItem);
	}

	public void allAllLineItems(final Set<LineItem> lineItems) {
		this.lineItems.addAll(lineItems);
	}

	public String getBatchID() {
		return this.batchID;
	}

	public String getBatchRecordId() {
		return this.batchRecordId;
	}

	public Amount getDiscount() {
		return this.discount;
	}

	public String getGatewayConfirmationNumber() {
		return this.gatewayConfirmationNumber;
	}

	public Amount getInvoiceDueAmount() {
		return this.invoiceDueAmount;
	}

	public Set<LineItem> getLineItems() {
		return Collections.unmodifiableSet(this.lineItems);
	}

	public DateTime getOriginalPaymentDate() {
		return this.originalPaymentDate;
	}

	public DateTime getPaymentEffectiveDate() {
		return this.paymentEffectiveDate;
	}

	public BillingAccount getPaymentFor() {
		return this.paymentFor;
	}

	public String getPaymentMode() {
		return this.paymentMode;
	}

	public String getPaymentType() {
		return this.paymentType;
	}

	public PaymentRecordType getRecordType() {
		return this.recordType;
	}

	public String getSrc() {
		return this.src;
	}

	public EbillSubscription getSubscription() {
		return this.subscription;
	}

	public String getSubscriptionName() {
		return this.subscriptionName;
	}

	public String getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public String getType() {
		return this.paymentType;
	}

	public void refundFailed() {
		this.setStatus(STATUS_REFUND_FAILED);
	}

	public void refundInitiated() {
		this.setStatus(STATUS_REFUND_INITIATED);
	}

	public void refundSuccess() {
		this.setStatus(STATUS_REFUND_SUCCESS);
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	@Override
	public void setAmountPaid(final Amount amountPaid) {
		if (amountPaid != null && amountPaid.isNegativeOrZero()) {
			throw new IllegalArgumentException("paid amount can never be negative");
		}
		super.setAmountPaid(amountPaid);
	}

	public void setBatchID(final String batchID) {
		this.batchID = batchID;
	}

	public void setBatchRecordId(final String batchRecordId) {
		this.batchRecordId = batchRecordId;
	}

	@Override
	public void setBillingAccount(final BillingAccount billingAccount) {
		this.paymentFor = billingAccount;

	}

	@Override
	public void setBusinessEntity(final BusinessEntity businessEntity) {
		this.setPayer(businessEntity);
	}

	public void setDiscount(final Amount discount) {
		this.discount = discount;
	}

	public void setGatewayConfirmationNumber(final String gatewayConfirmationNumber) {
		this.gatewayConfirmationNumber = gatewayConfirmationNumber;
	}

	public void setInvoiceDueAmount(final Amount invoiceDueAmount) {
		this.invoiceDueAmount = invoiceDueAmount;
	}

	public void setOneTimePaymentType() {
		this.setType("OneTime_Payment_Request");

	}

	public void setOriginalPaymentDate(final DateTime originalPaymentDate) {
		this.originalPaymentDate = originalPaymentDate;
	}

	@Override
	public void setPayer(final BusinessEntity payer) {
		if (payer != null) {
			this.setOperator(payer.getOperator());
		}
		super.setPayer(payer);
	}

	public void setPaymentEffectiveDate(final DateTime paymentEffectiveDate) {
		this.paymentEffectiveDate = paymentEffectiveDate;
	}

	public void setPaymentFor(final BillingAccount paymentFor) {
		this.paymentFor = paymentFor;
	}

	public void setPaymentMode(final String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public void setPaymentType(final String paymentType) {
		this.paymentType = paymentType;
	}

	public void setRecordType(final PaymentRecordType recordType) {
		this.recordType = recordType;
	}

	public void setSrc(final String src) {
		this.src = src;
	}

	@Override
	public void setSubscription(final EbillSubscription subscription) {
		this.subscription = subscription;
	}

	/***
	 * Used Reflectively to set subscription name
	 *
	 * @param subscriptionName
	 */
	public void setSubscriptionName(final String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	@Override
	public void setTxnDate(final DateTime txnDate) {
		/*
		 * if (txnDate.isAfter(new DateTime())) { throw new
		 * IllegalArgumentException( "Can not process future payments"); }
		 */
		super.setTxnDate(txnDate);
	}

	public void setType(final String type) {
		this.paymentType = type;
	}

	@Override
	public String typeName() {
		return "Payment_Record";
	}
}