package com.hcentive.billing.wfm.dto;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class DatesHolder {

	public enum DateType {
		DUE_DATE, GENERATION_DATE, BILL_PERIOD_START_DATE, BILL_PERIOD_END_DATE
	}
	
	private Map<DateType, Date> dates;

	public DatesHolder() {
		super();
		dates = new HashMap<>();
	}
	
	public Date getDateByType(DateType type) {
		return dates.get(type);
	}
	
	public void add(DateType type, Date date) {
		dates.put(type, date);
	}
	
}
