package com.hcentive.billing.wfm.api;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.domain.Party;
import com.hcentive.billing.wfm.domain.contract.ContractType;

public interface FinancialContract<T extends ContractType, CI> extends
		Contract<T, CI>, FinancialTermAware, IdentityAware {

	FinancialContract<?, ?> getParentContract();

	Set<Party> getParties();

}
