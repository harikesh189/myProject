package com.hcentive.billing.wfm.api.enumeration.ft;

public enum ReasonLevel {
	MEMBER, PLAN;
}
