/**
 * 
 */
package com.hcentive.wfm.checkpoint.rule;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Transient;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingRuleConfig;

/**
 * Extension of {@link BillingRuleConfig} to capture checkpoint rules.
 * 
 * @author Kumar Sambhav Jain
 *
 */
public abstract class CheckpointRule extends BillingRuleConfig {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3956356416853272143L;

	@NotNull
	@Min(value = 0)
	protected int gracePeriod;

	@NotNull
	@Size(min = 0, max = 9999)
	protected TreeSet<Checkpoint> delinquencyCheckpoints;

	@Transient
	private Checkpoint[] delinquencyCheckpointsArray;

	/**
	 * Applicable only when grace period allowed is zero.
	 * DELINQUENCY_TERMINATION_TYPE in that case will always be
	 * LAST_DAY_OF_COVG.
	 * 
	 * Application when grace period is greater than zero.
	 */
	private Checkpoint exitCheckpoint;

	/**
	 * Always applicable.
	 */
	private Checkpoint terminationCheckpoint;

	/**
	 * @return the delinquencyCheckpointsArray
	 */
	public Checkpoint[] getDelinquencyCheckpointsArray() {
		return delinquencyCheckpointsArray;
	}

	/**
	 * @param delinquencyCheckpointsArray the delinquencyCheckpointsArray to set
	 */
	public void setDelinquencyCheckpointsArray(
			Checkpoint[] delinquencyCheckpointsArray) {
		this.delinquencyCheckpointsArray = delinquencyCheckpointsArray;
	}

	/**
	 * @return the exitCheckpoint
	 */
	public Checkpoint getExitCheckpoint() {
		return exitCheckpoint;
	}

	/**
	 * @param exitCheckpoint the exitCheckpoint to set
	 */
	public void setExitCheckpoint(Checkpoint exitCheckpoint) {
		this.exitCheckpoint = exitCheckpoint;
	}

	/**
	 * @return the terminationCheckpoint
	 */
	public Checkpoint getTerminationCheckpoint() {
		return terminationCheckpoint;
	}

	/**
	 * @param terminationCheckpoint the terminationCheckpoint to set
	 */
	public void setTerminationCheckpoint(Checkpoint terminationCheckpoint) {
		this.terminationCheckpoint = terminationCheckpoint;
	}

	protected TerminationCriteria terminationCriteria;

	public CheckpointRule(ConfigType type){
		super(type);
	}

	/**
	 * @return the gracePeriod
	 */
	public int getGracePeriod() {
		return gracePeriod;
	}

	/**
	 * @param gracePeriod
	 *            the gracePeriod to set
	 */
	public void setGracePeriod(int gracePeriod) {
		this.gracePeriod = gracePeriod;
	}

	/**
	 * @return the delinquencyCheckpoints
	 */
	public TreeSet<Checkpoint> getDelinquencyCheckpoints() {
		return delinquencyCheckpoints;
	}

	/**
	 * @param delinquencyCheckpoints
	 *            the delinquencyCheckpoints to set
	 */
	public void setDelinquencyCheckpoints(
			TreeSet<Checkpoint> delinquencyCheckpoints) {
		this.delinquencyCheckpoints = delinquencyCheckpoints;
	}

	public Checkpoint getCheckpointOnOrAfter(int noOfDaysPast) {
		return delinquencyCheckpoints.higher(new Checkpoint(noOfDaysPast));
	}

	public Checkpoint getCheckpointByIndex(int executedCheckpointIndex) {
		Checkpoint checkpoint = null;
		this.delinquencyCheckpointsArray = delinquencyCheckpoints
				.toArray(new Checkpoint[delinquencyCheckpoints.size()]);

		if (executedCheckpointIndex >= this.delinquencyCheckpointsArray.length) {
			// no further check points exist in the lifecycle, return term checkpoint.
			checkpoint = this.terminationCheckpoint;
		} else {
			checkpoint = this.delinquencyCheckpointsArray[executedCheckpointIndex];
		}
		return checkpoint;
	}

	public List<String> getCheckpointIds() {
		if (null == delinquencyCheckpoints) {
			return null;
		}
		List<String> ids = new ArrayList<String>(delinquencyCheckpoints.size());
		for (Checkpoint c : delinquencyCheckpoints) {
			ids.add(c.getId());
		}
		return ids;
	}

	/**
	 * @return the terminationCriteria
	 */
	public TerminationCriteria getTerminationCriteria() {
		return terminationCriteria;
	}

	/**
	 * @param terminationCriteria
	 *            the terminationCriteria to set
	 */
	public void setTerminationCriteria(TerminationCriteria terminationCriteria) {
		this.terminationCriteria = terminationCriteria;
	}

}
