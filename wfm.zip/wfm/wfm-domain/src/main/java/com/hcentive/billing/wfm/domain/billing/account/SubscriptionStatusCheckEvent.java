package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.IdentityAware;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.SubscriptionCheckEventStatus;

@Entity
@Table(name = "subscription_status_check_event")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class SubscriptionStatusCheckEvent extends BaseEntity implements TenantAware, IdentityAware {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "billing_account_identity")
	private String billingAccountIdentity;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "status_check_date")) })
	private DateTime statusCheckDate;

	@Column(name = "reason")
	private String reason;

	@Column(name = "last_invoice_settled_identity")
	private String lastInvoiceSettledIdentity;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private SubscriptionCheckEventStatus status;

	@Access(AccessType.FIELD)
	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;

	@Column(name = "identity", nullable = false, updatable = false)
	@Access(AccessType.FIELD)
	private String identity;

	public SubscriptionStatusCheckEvent(final String billingAccountIdentity, final DateTime statusCheckDate, final String reason,
	        final String lastInvoiceSettledIdentity, final SubscriptionCheckEventStatus subscriptionCheckEventStatus, final String identity) {
		super();
		this.billingAccountIdentity = billingAccountIdentity;
		this.statusCheckDate = statusCheckDate;
		this.reason = reason;
		this.lastInvoiceSettledIdentity = lastInvoiceSettledIdentity;
		this.identity = identity;
		this.setStatus(subscriptionCheckEventStatus);
	}

	protected SubscriptionStatusCheckEvent() {

	}

	public String getBillingAccountIdentity() {
		return this.billingAccountIdentity;
	}

	@Override
	public String getIdentity() {
		return this.identity;
	}

	public String getLastInvoiceSettledIdentity() {
		return this.lastInvoiceSettledIdentity;
	}

	public String getReason() {
		return this.reason;
	}

	public SubscriptionCheckEventStatus getStatus() {
		return this.status;
	}

	public DateTime getStatusCheckDate() {
		return this.statusCheckDate;
	}

	public SubscriptionCheckEventStatus getSubscriptionCheckEventStatus() {
		return this.getStatus();
	}

	@Override
	public String getTenantId() {
		return this.tenantId;
	}

	public void setBillingAccountIdentity(final String billingAccountIdentity) {
		this.billingAccountIdentity = billingAccountIdentity;
	}

	@Override
	public void setIdentity(final String identity) {
		this.identity = identity;
	}

	public void setLastInvoiceSettledIdentity(final String lastInvoiceSettledIdentity) {
		this.lastInvoiceSettledIdentity = lastInvoiceSettledIdentity;
	}

	public void setReason(final String reason) {
		this.reason = reason;
	}

	public void setStatus(final SubscriptionCheckEventStatus status) {
		this.status = status;
	}
}
