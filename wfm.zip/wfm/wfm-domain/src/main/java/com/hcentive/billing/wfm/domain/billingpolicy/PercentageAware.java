package com.hcentive.billing.wfm.domain.billingpolicy;

public interface PercentageAware {
	double getPercentage();
}
