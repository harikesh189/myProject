package com.hcentive.billing.wfm.api;

public interface InsuranceCoverageAwareFinancialTerm<V> extends
		FinancialTerm<V>, InsuranceCoverageAware {

}
