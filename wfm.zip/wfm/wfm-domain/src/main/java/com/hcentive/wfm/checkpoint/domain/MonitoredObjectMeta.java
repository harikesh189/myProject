/**
 * 
 */
package com.hcentive.wfm.checkpoint.domain;

import java.io.Serializable;

/**
 * @author Dikshit.Vaid
 *
 *         Marker interface for monitored object meta data.
 *
 */
public interface MonitoredObjectMeta extends Serializable {
}
