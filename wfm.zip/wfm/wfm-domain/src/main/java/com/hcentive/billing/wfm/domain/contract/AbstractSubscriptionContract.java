package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.Customer;
import com.hcentive.billing.core.commons.domain.Party;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.SubscriptionContract;
import com.hcentive.billing.wfm.api.enumeration.eligibility.MaintenanceCode;
import com.hcentive.billing.wfm.api.enumeration.eligibility.MaintenanceReasonCode;

@Entity
@DiscriminatorValue("contract")
public abstract class AbstractSubscriptionContract<CI extends ContractInfo> extends AbstractFinancialContract<CI> implements
        SubscriptionContract<ContractType, CI> {

	/**
	 *
	 */
	private static final long serialVersionUID = 2128196840098606396L;

	@Column(name = "maintenance_code")
	@Enumerated(EnumType.STRING)
	private MaintenanceCode maintenanceCode;

	
	@Column(name = "maintenance_reason")
	@Enumerated(EnumType.STRING)
	private MaintenanceReasonCode maintenanceReason;
	
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "plan_year_start_date")),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "plan_year_end_date")) })
	@Access(AccessType.FIELD)
	private Period planPeriod;
	
	public AbstractSubscriptionContract() {
	}

	protected AbstractSubscriptionContract(final ContractType type, final ContractInfo contractInfo) {
		this.type = type;
		this.contractInfo = contractInfo;
		this.contractInfo.setContractId(this.contractId());
	}

	protected AbstractSubscriptionContract(final String identity) {
		super(identity);
	}
	

	public Collection<BusinessEntity<?>> getBrokers() {
		final Collection<BusinessEntity<?>> brokers = new LinkedList<>();
		final Set<Party> parties = this.getParties();
		for (final Party party : parties) {
			final BusinessEntity businessEntity = party.getParty();
			if (BusinessEntityTypes.BROKER.equals(businessEntity.getType())) {
				brokers.add(businessEntity);
			}
		}
		return brokers;
	}

	public BusinessEntity getExchange() {
		final Set<Party> parties = this.getParties();
		for (final Party party : parties) {
			final BusinessEntity businessEntity = party.getParty();
			if (BusinessEntityTypes.EXCHANGE.equals(businessEntity.getType())) {
				return businessEntity;
			}
		}
		return null;
	}

	public MaintenanceCode getMaintenanceCode() {
		return maintenanceCode;
	}

	public Customer<Profile> groupCustomer() {
		for (final Party party : this.getParties()) {
			final BusinessEntity<Profile> partyEntity = party.getParty();
			if (partyEntity.getType().equals(BusinessEntityTypes.GROUP_CUSTOMER) && partyEntity instanceof Customer) {
				return (Customer) partyEntity;
			}
		}
		return null;
	}

	public boolean isReinstated() {
		return MaintenanceCode.REIN == this.getMaintenanceCode();
	}

	public Customer<Profile> primaryCustomer() {

		final boolean indvCustContract = this.getType().getType().equals(ContractType.INDIVIDUAL_ELIGIBILITY_CONTRACT.getType());

		Customer<Profile> customer = null;

		for (final Party party : this.getParties()) {

			final BusinessEntity<Profile> partyEntity = party.getParty();

			if (indvCustContract && partyEntity.getType().equals(BusinessEntityTypes.INDIVIDUAL_CUSTOMER) || !indvCustContract
			        && partyEntity.getType().equals(BusinessEntityTypes.GROUP_CUSTOMER)) {

				if (partyEntity instanceof Customer) {
					customer = (Customer) partyEntity;
					break;
				}
			}
		}

		return customer;
	}

	public void setMaintenanceCode(MaintenanceCode maintenanceCode) {
		this.maintenanceCode = maintenanceCode;
	}

	public Customer<Profile> subscriber() {

		for (final Party party : this.getParties()) {

			final BusinessEntity<Profile> partyEntity = party.getParty();

			if (partyEntity.getType().equals(BusinessEntityTypes.INDIVIDUAL_CUSTOMER)) {

				if (partyEntity instanceof Customer) {
					return (Customer) partyEntity;
				}
			}
		}

		return null;
	}

	public MaintenanceReasonCode getMaintenanceReason() {
		return maintenanceReason;
	}

	public void setMaintenanceReason(MaintenanceReasonCode maintenanceReason) {
		this.maintenanceReason = maintenanceReason;
	}

	public Period getplanPeriod() {
		return planPeriod;
	}

	public void setplanPeriod(Period planPeriod) {
		this.planPeriod = planPeriod;
	}
	
}
