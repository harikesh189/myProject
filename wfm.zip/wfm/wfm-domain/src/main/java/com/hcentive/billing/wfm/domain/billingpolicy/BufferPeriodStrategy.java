package com.hcentive.billing.wfm.domain.billingpolicy;

import java.io.Serializable;
import java.util.Date;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BufferPeriodStrategyType;
import com.hcentive.billing.wfm.dto.DatesHolder;

public abstract class BufferPeriodStrategy implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	protected BufferPeriodStrategyType bufferPeriodStrategyType;
	
	public BufferPeriodStrategy(BufferPeriodStrategyType bufferPeriodStrategyType) {
		super();
		this.bufferPeriodStrategyType = bufferPeriodStrategyType;
	}
	
	public BufferPeriodStrategy() {}

	public abstract Date resolveBufferEndDate(DatesHolder dates);
	
	public BufferPeriodStrategyType getBufferPeriodType() {
		return bufferPeriodStrategyType;
	}

	public void setBufferPeriodType(BufferPeriodStrategyType bufferPeriodType) {
		this.bufferPeriodStrategyType = bufferPeriodType;
	}
}
