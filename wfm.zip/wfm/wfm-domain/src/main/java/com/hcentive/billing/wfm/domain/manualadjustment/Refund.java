package com.hcentive.billing.wfm.domain.manualadjustment;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;



/**
 * Class to represent Refund Adjustment.
 * 
 * @author ajay.saxena
 *
 */
@Entity
@Table(name = "manual_adjustment")
@DiscriminatorValue("Refund")
public class Refund extends ManualAdjustment{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6986007625475538294L;

	@Override
	public String typeName() {
		// TODO Auto-generated method stub
		return "Refund";
	}

}
