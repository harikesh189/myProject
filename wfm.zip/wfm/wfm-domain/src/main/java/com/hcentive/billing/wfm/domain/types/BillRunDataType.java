package com.hcentive.billing.wfm.domain.types;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.hcentive.billing.core.commons.domain.converter.MongoFacadeFactory;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunData;

@Converter
public class BillRunDataType implements AttributeConverter<BillRunData, String> {

	private BillRunData convertToEntityAttributeFromMongo(final String dbData) {
		if (dbData == null) {
			return null;
		}
		final BillRunData billRunData = MongoFacadeFactory.getMongoFacade()
				.findByIdentity(dbData, BillRunData.class);
		return billRunData;
	}

	@Override
	public String convertToDatabaseColumn(final BillRunData value) {
		if (value == null) {
			return null;
		}
		final BillRunData saveObject = (BillRunData) MongoFacadeFactory
				.getMongoFacade().saveObject(value);
		value.setId(saveObject.getId());
		return saveObject.getId();
	}

	@Override
	public BillRunData convertToEntityAttribute(final String billRunDataMongoId) {
		return this.convertToEntityAttributeFromMongo(billRunDataMongoId);
	}

}
