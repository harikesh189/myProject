package com.hcentive.billing.wfm.domain;

public enum ServiceType {
	BILLING, COVERAGE, REMITTANCE
}
