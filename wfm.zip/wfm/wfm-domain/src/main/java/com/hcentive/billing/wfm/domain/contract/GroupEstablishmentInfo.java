package com.hcentive.billing.wfm.domain.contract;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class GroupEstablishmentInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9202819274906465052L;

	@Column(name = "establishment_id")
	private String establishmentId;

	@Column(name = "establishment_name")
	private String establishmentName;

	public String getEstablishmentId() {
		return establishmentId;
	}

	public void setEstablishmentId(String establishmentId) {
		this.establishmentId = establishmentId;
	}

	public String getEstablishmentName() {
		return establishmentName;
	}

	public void setEstablishmentName(String establishmentName) {
		this.establishmentName = establishmentName;
	}

}
