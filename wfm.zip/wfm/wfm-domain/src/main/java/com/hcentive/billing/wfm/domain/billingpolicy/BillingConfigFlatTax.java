package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

/**
 * It represent the billing configuration to calculate tax based on flat tax.
 * 
 * @author nitin.singla
 * 
 */
public class BillingConfigFlatTax extends BillingConfigTax<Amount> implements
		AmountAware {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * A flat dollar tax amount
	 */
	private Amount amount;

	/**
	 * Gets the flat dollar tax amount.
	 * 
	 * @return The flat dollar tax amount.
	 */
	@Override
	public Amount getAmount() {
		return this.amount;
	}

	/**
	 * Sets the flat dollar tax amount.
	 * 
	 * @param amount
	 *            The flat dollar tax amount to set.
	 */
	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	@Override
	public Amount value() {
		return this.getAmount();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.core.commons.api.Effectivity#effectivePeriod()
	 */
	@Override
	public Period effectivePeriod() {
		return period;
	}

}
