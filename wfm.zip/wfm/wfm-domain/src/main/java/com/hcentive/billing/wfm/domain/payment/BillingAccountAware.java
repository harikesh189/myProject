package com.hcentive.billing.wfm.domain.payment;

import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

public interface BillingAccountAware {
	
	void setBillingAccount(BillingAccount billingAccount);

}
