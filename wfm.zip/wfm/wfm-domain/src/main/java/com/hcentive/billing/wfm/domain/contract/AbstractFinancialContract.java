package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.ItemRecordAwareEntity;
import com.hcentive.billing.core.commons.domain.Party;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.domain.contract.mixin.EntityAware;

import static com.hcentive.billing.core.commons.util.CollectionUtil.nullSafe;

@Entity
@Table(name = "contract")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "contract_type")
public abstract class AbstractFinancialContract<CI extends ContractInfo> extends ItemRecordAwareEntity<AbstractFinancialContract<CI>, String> implements
FinancialContract<ContractType, CI>, EntityAware {

	private static final long serialVersionUID = 1L;

	public static final String COLUMN_CONTRACT_CLASS_TYPE = "contract_type";

	public static final String COLUMN_CONTRACT_TYPE = "type";
	public static final String FIELD_CONTRACT_TYPE = "type";

	public static final String CONTRACT_REF_TYPE = "Contract";

	@Embedded
	protected ContractType type;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = ContractInfo.class)
	@JoinColumn(name = "contract_info_id")
	@Access(AccessType.FIELD)
	protected ContractInfo contractInfo;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = Party.class, orphanRemoval = true)
	@Access(AccessType.FIELD)
	@JoinTable(name = "contract_parties", joinColumns = @JoinColumn(name = "contract_id"), inverseJoinColumns = @JoinColumn(name = "parties_id"))
	private final Set<Party> parties = new HashSet<>();

	@ManyToOne(cascade = { CascadeType.REFRESH })
	@JoinColumn(name = "parent_contract_id")
	private AbstractFinancialContract parentContract;

	public AbstractFinancialContract() {
		super();
	}

	public AbstractFinancialContract(final Long id, final String identity) {
		super(id, identity);
	}

	public AbstractFinancialContract(final Long id, final String identity, final String externalId) {
		super(id, identity, externalId);
	}

	public AbstractFinancialContract(final String identity) {
		super(identity);
	}

	public AbstractFinancialContract(final String identity, final String externald) {
		super(identity, externald);
	}

	public void add(final Party party) {
		this.parties.add(party);
		if (party != null && party.getParty() != null) {
			this.addReference(party.getParty().toReference());
			this.addReference(party.getParty().extIdReference());
		}
	}

	public void addAllParties(final Collection<Party> parties) {
		if (parties != null) {
			for (final Party party : parties) {
				this.add(party);
			}
		}
	}

	public void cleanParties() {
		if (this.parties == null || this.parties.isEmpty()) {
			return;
		}

		this.parties.clear();
	}

	@Override
	public String contractId() {
		return this.externalId;
	}

	public AbstractFinancialContract getBillableContract() {
		return this.getParentContract() != null ? this.getParentContract() : this;
	}

	@Override
	public ContractInfo getContractInfo() {
		return this.contractInfo;
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Collection<BusinessEntity<Profile>> getEntities() {
		final Collection<BusinessEntity<Profile>> result = new LinkedList<>();
		for (final Party party : nullSafe(this.getParties())) {
			if (!this.isIndividualPartyInGroupEligibility(party)) {
				result.add(party.getParty());
			}
		}
		return result;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Collection<String> getEntitieTypes() {
		final Collection<String> result = new LinkedList<>();
		for (final Party party : nullSafe(this.getParties())) {
			if (!this.isIndividualPartyInGroupEligibility(party)) {
				result.add(party.getParty().getType());
			}
		}
		return result;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public AbstractFinancialContract getParentContract() {
		return this.parentContract;
	}

	@Override
	public Set<Party> getParties() {
		return this.parties;
	}

	@Override
	public ContractType getType() {
		return this.type;
	}

	public boolean isValidForPeriod(final Period period) {
		return this.getContractInfo().getEffectivePeriod()
				.hasIntersection(period);
	}

	public void setContractInfo(final CI contractInfo) {
		this.contractInfo = contractInfo;
	}

	public void setParentContract(final AbstractFinancialContract<ContractInfo> parentContract) {
		this.parentContract = parentContract;

	}

	public void setType(final ContractType type) {
		if (null != this.contractInfo) {
			this.contractInfo.setType(type);
		}
		this.type = type;
	}

	@Override
	public final String typeName() {
		return CONTRACT_REF_TYPE;
	}

	private boolean isIndividualPartyInGroupEligibility(final Party party) {
		// Individual customer should not be returned as a type when contract is
		// a
		// group eligibility contract. Ideally, the subscriber should not be
		// individual
		// when it is a part of a shop. This check has been added to avoid
		// matching
		// rules defined for subscriber in case of group eligibility
		return BusinessEntityTypes.INDIVIDUAL_CUSTOMER.equals(party.getParty().getType())
				&& ContractType.GROUP_ELIGIBILITY_CONTRACT.equals(this.contractInfo.getType());
	}

}