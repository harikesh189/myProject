package com.hcentive.billing.wfm.api.enumeration;

public enum SubscriptionStatus {
	PRIMARY, SECONDARY, INACTIVE
}
