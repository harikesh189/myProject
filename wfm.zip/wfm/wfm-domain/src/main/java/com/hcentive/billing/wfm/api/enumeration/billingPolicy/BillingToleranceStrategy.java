package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum BillingToleranceStrategy {
	PERCENTAGE,FLAT
}
