/**
 * 
 */
package com.hcentive.billing.wfm.api;


/**
 * @author Dikshit.Vaid
 * 
 */
public class MemberAwareFinancialTermImpl<V> extends FinancialTermDecorator<V>
		implements MemberAwareFinancialTerm<V> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long insuredMemberId;

	/**
	 * @param finTerm
	 */
	public MemberAwareFinancialTermImpl(FinancialTerm<V> finTerm,
			Long insuredMemberId) {
		super(finTerm);
		this.insuredMemberId = insuredMemberId;
	}

	public Long getInsuredMemberId() {
		return insuredMemberId;
	}

}
