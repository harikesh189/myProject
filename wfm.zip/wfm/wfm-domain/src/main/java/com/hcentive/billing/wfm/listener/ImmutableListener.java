/*
 * Copyright (c) Welue Strategic Alliances.  All rights reserved.
 * 
 * This code and information is the exclusive property of Welue
 * Strategic Alliances, a company registered under The Companies
 * Act of India, 1956.  No part of this code can be distributed,
 * copied, transmitted, transferred or disclosed to any party
 * outside of Welue Strategic Alliances through any means.  Any
 * act of distribution, copying, transmission, transfer or
 * disclosure of this code to a party outside of Welue Strategic
 * Alliances will be deemed to be an act of criminal intent and
 * will attract strict legal action.
 */

package com.hcentive.billing.wfm.listener;

import javax.persistence.PrePersist;

import com.hcentive.billing.core.commons.domain.DomainEntity;

/**
 * 
 * @author nitin.singla
 * 
 */
public final class ImmutableListener {

	/**
	 * Assigns a unique system-code to the entity.
	 * 
	 * @param entity
	 *            The entity being persisted.
	 */
	@PrePersist
	public void beforeSave(final DomainEntity entity) {
	}
}
