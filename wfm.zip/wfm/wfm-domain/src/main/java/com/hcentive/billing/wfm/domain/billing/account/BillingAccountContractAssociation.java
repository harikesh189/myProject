package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.enumeration.BillingAccountAssociationType;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;

@Entity
@DiscriminatorValue("contract_association")
public class BillingAccountContractAssociation extends BillingAccountAssociation {

	private static final long serialVersionUID = -7965166017241437861L;

	@OneToOne(targetEntity = AbstractFinancialContract.class)
	@JoinColumn(name = "related_contract_id")
	private FinancialContract relatedContract;

	@Access(AccessType.FIELD)
	@Column(name = "billable")
	protected boolean billable = false;

	public BillingAccountContractAssociation() {
		super();
		this.setAssociationName(BillingAccountAssociationType.CONTRACT_ASSOCIATION);
	}
	
	public FinancialContract getRelatedContract() {
		return relatedContract;
	}

	public void setRelatedContract(FinancialContract relatedContract) {
		this.relatedContract = relatedContract;
	}

	public boolean isBillable() {
		return billable;
	}

	public void setBillable(boolean billable) {
		this.billable = billable;
	}

}
