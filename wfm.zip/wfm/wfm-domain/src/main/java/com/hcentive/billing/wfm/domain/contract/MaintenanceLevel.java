package com.hcentive.billing.wfm.domain.contract;

public enum MaintenanceLevel {
	CONTRACT, MEMBER, PLAN;
}
