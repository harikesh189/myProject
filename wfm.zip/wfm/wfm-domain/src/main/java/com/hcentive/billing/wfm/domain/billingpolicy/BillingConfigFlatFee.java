package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

/**
 * It represent the billing configuration to calculate fee based on flat fee..
 * 
 * @author nitin.singla
 */
public class BillingConfigFlatFee extends BillingConfigFee<Amount> implements
		AmountAware {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * A flat dollar Fee amount
	 */
	@NotNull
	private Amount amount;

	/**
	 * Gets the flat dollar Fee amount.
	 * 
	 * @return The flat dollar Fee amount.
	 */
	@Override
	public Amount getAmount() {
		return this.amount;
	}

	/**
	 * Sets the flat dollar Fee amount.
	 * 
	 * @param amount
	 *            The flat dollar Fee amount to set.
	 */
	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	@Override
	public Amount value() {
		return this.getAmount();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.core.commons.api.Effectivity#effectivePeriod()
	 */
	@Override
	public Period effectivePeriod() {
		return this.period;
	}

}
