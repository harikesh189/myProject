package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.FTEntryAware;

@Entity
@Table(name = "bill_amount")
@DiscriminatorValue("FT_MEM_AND_PLAN_AWARE_BILL_AMT")
public class FTEntryMemberAndPlanAwareBillAmount extends
		MemberAndPlanAwareBillAmount implements FTEntryAware {

	private static final long serialVersionUID = 1L;

	@ElementCollection(fetch = FetchType.EAGER)
	@Column(name = "ft_entry_id")
	@CollectionTable(name = "bill_amount_ft_entry_ids", joinColumns = @JoinColumn(name = "bill_amount_id"))
	private Set<String> ftEntryIds;

	public FTEntryMemberAndPlanAwareBillAmount(Long planId,
			String amountCode, String amountName, Amount amount,
			AmountCategory type, Set<MemberBreakUp> memberBreakUps,
			Set<String> ftEntryIds, AmountGroup amtGrp, String desc,
			Period coveragePeriod, DateTime associatedDate) {
		
		super(planId, amountCode, amountName, amount, type, desc, coveragePeriod, 
				amtGrp, memberBreakUps, associatedDate);
		
		this.ftEntryIds = ftEntryIds;
	}

	@Override
	public Set<String> ftEntryIds() {
		return this.ftEntryIds;
	}

	@Override
	public String toString() {
		return super.toString() + ", FT entries: " + this.ftEntryIds;
	}

	protected FTEntryMemberAndPlanAwareBillAmount() {

	}

}
