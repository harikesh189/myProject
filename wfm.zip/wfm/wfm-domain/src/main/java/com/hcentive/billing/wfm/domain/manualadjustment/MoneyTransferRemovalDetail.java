package com.hcentive.billing.wfm.domain.manualadjustment;

import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.payment.AmountRemovalDetail;

public class MoneyTransferRemovalDetail extends AmountRemovalDetail {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1183801398462842044L;

	private String moneyTransferIdentity;

	private String moneyTransferExternalId;

	private DateTime effectiveDate;

	@SuppressWarnings("unused")
	private MoneyTransferRemovalDetail() {
		super();
		// For ORMs
	}

	public MoneyTransferRemovalDetail(RemovalReason reason) {
		super(reason);
	}

	public String getMoneyTransferIdentity() {
		return moneyTransferIdentity;
	}

	public void setMoneyTransferIdentity(String moneyTransferIdentity) {
		this.moneyTransferIdentity = moneyTransferIdentity;
	}

	public String getMoneyTransferExternalId() {
		return moneyTransferExternalId;
	}

	public void setMoneyTransferExternalId(String moneyTransferExternalId) {
		this.moneyTransferExternalId = moneyTransferExternalId;
	}

	public DateTime getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(DateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Override
	public String toString() {
		return "MoneyTransferRemovalDetail [moneyTransferIdentity=" + moneyTransferIdentity
				+ ", moneyTransferExternalId=" + moneyTransferExternalId + ", reason=" + reason + "]";
	}
}
