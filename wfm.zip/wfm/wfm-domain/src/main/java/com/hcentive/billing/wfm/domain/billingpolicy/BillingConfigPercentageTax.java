package com.hcentive.billing.wfm.domain.billingpolicy;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.contract.PercentageAmount;

/**
 * @author nitin.singla
 */
public class BillingConfigPercentageTax extends
		BillingConfigTax<PercentageAmount> implements PercentageAware {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@Min(0)
	@Max(100)
	private double percentage;

	private String refAmountCode;

	@Override
	public double getPercentage() {
		return this.percentage;
	}

	public String getRefAmountCode() {
		return this.refAmountCode;
	}

	public void setPercentage(final double percentage) {
		this.percentage = percentage;
	}

	public void setRefAmountCode(final String refAmountCode) {
		this.refAmountCode = refAmountCode;
	}

	@Override
	public PercentageAmount value() {
		return new PercentageAmount(this.getPercentage(),
				this.getRefAmountCode());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.core.commons.api.Effectivity#effectivePeriod()
	 */
	@Override
	public Period effectivePeriod() {
		return this.period;
	}

}
