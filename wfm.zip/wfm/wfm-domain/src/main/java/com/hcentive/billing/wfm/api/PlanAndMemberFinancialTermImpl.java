/**
 * 
 */
package com.hcentive.billing.wfm.api;

import java.util.HashSet;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialTerm;

/**
 * @author Dikshit.Vaid
 * 
 */
public class PlanAndMemberFinancialTermImpl<V> extends
		AbstractFinancialTerm<Set<MemberAwareFinancialTerm<V>>> implements
		PlanAndMemberAwareFinancialTerm<V> {

	private static final long serialVersionUID = 1L;
	
	private final Long planId;
	private Set<MemberAwareFinancialTerm<V>> memberBreakUpFinancialTerms = new HashSet<>();

	/**
	 * @param type
	 * @param code
	 * @param name
	 */
	public PlanAndMemberFinancialTermImpl(String type, String code,
			String name, Period effectivePeriod, Long planId,
			Set<MemberAwareFinancialTerm<V>> memberBreakUpFinancialTerms, String description) {
		super(type, code, name, effectivePeriod, description);
		this.planId = planId;
		this.memberBreakUpFinancialTerms = memberBreakUpFinancialTerms;
	}

	@Override
	public String toString() {
		StringBuilder value = new StringBuilder("plan=" + planId
				+ ", memberBreakUpFinancialTerms=[");
		for (MemberAwareFinancialTerm<?> mft : memberBreakUpFinancialTerms) {
			value.append(mft);
		}
		value.append("]");
		return value.toString();
	}

	@Override
	public Long insuranceCoverage() {
		return planId;
	}

	@Override
	public Period effectivePeriod() {
		return null;
	}

	@Override
	public Set<MemberAwareFinancialTerm<V>> value() {
		return memberBreakUpFinancialTerms;
	}

	@Override
	public Set<MemberAwareFinancialTerm<V>> memberBreakUpFinancialTerms() {
		return memberBreakUpFinancialTerms;
	}

	@Override
	public Class<V> termValueType() {
		if (memberBreakUpFinancialTerms.isEmpty()) {
			return null;
		} else {
			return (Class<V>) memberBreakUpFinancialTerms.iterator().next()
					.value().getClass();
		}
	}

}
