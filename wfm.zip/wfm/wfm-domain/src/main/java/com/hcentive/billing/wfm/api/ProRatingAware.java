package com.hcentive.billing.wfm.api;

import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

public interface ProRatingAware {

	BillingConfigProRate getProRatingConfig();

}
