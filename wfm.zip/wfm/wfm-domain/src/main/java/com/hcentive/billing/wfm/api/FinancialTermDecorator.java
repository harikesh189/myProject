package com.hcentive.billing.wfm.api;

import com.hcentive.billing.core.commons.domain.Period;

public abstract class FinancialTermDecorator<V> implements FinancialTerm<V> {

	private final FinancialTerm<V> finTerm;

	public FinancialTermDecorator(final FinancialTerm<V> finTerm) {
		this.finTerm = finTerm;
	}

	@Override
	public Period effectivePeriod() {
		return this.finTerm.effectivePeriod();
	}

	@Override
	public String type() {
		return this.finTerm.type();
	}

	@Override
	public String code() {
		return this.finTerm.code();
	}

	@Override
	public V value() {
		return this.finTerm.value();
	}

	@Override
	public String name() {
		return this.finTerm.name();
	}
	
	@Override
	public String description() {
		return this.finTerm.description();
	}
	
	public FinancialTerm<?> getWrappedFinancialTerm() {
		return finTerm;
	}

	@Override
	public String toString() {
		return "FinancialTermDecorator [finTerm=" + finTerm + "]";
	}

}
