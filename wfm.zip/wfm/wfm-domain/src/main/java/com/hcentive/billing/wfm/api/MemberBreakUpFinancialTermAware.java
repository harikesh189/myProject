/**
 * 
 */
package com.hcentive.billing.wfm.api;

import java.util.Set;

/**
 * @author Dikshit.Vaid
 * 
 */
public interface MemberBreakUpFinancialTermAware<V> {

	Set<MemberAwareFinancialTerm<V>> memberBreakUpFinancialTerms();

}
