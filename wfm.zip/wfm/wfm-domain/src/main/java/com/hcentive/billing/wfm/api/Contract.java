package com.hcentive.billing.wfm.api;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.Party;
import com.hcentive.billing.wfm.domain.contract.ContractInfo;
import com.hcentive.billing.wfm.domain.contract.ContractType;

public interface Contract<T extends ContractType, CI> {

	String contractId();

	T getType();

	ContractInfo getContractInfo();

	Set<? extends Party> getParties();

}
