package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;



@Entity
@DiscriminatorValue("BENEFIT_PLAN")
public class BenefitPlan extends BillingPlan{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8176097967681965242L;
	
	@Access(AccessType.FIELD)
	@Column(name = "benefit_id")
	private String benefitId;
	
	
	protected BenefitPlan() {

	}

	public BenefitPlan(String identity, String externalId) {
		super();
		this.identity = identity;
		this.externalId = externalId;

	}
	

	@Override
	public String typeName() {
		return "BenefitPlan";
	}

}
