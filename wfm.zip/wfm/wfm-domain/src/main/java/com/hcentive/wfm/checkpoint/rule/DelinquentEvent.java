/**
 * 
 */
package com.hcentive.wfm.checkpoint.rule;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
public class DelinquentEvent<D> implements Serializable{

	private static final long serialVersionUID = 5421295470295569723L;

	private D candidate;

	private DateTime eventEffectiveDate;

	private String currentCheckPoint;

	private String previousCheckPoint;

	public DelinquentEvent(String previousCheckPoint, String currentCheckPoint,
			DateTime checkPointTransitionDate, D candidate) {
		super();
		this.previousCheckPoint = previousCheckPoint;
		this.currentCheckPoint = currentCheckPoint;
		this.eventEffectiveDate = checkPointTransitionDate;
		this.candidate = candidate;
	}

	/**
	 * 
	 */
	public DelinquentEvent() {
		// TODO Auto-generated constructor stub
	}

	public D getCandidate() {
		return candidate;
	}

	public DateTime getEventEffectiveDate() {
		return eventEffectiveDate;
	}

	public String getCurrentCheckPoint() {
		return currentCheckPoint;
	}

	public String getPreviousCheckPoint() {
		return previousCheckPoint;
	}

	public void setCandidate(D candidate) {
		this.candidate = candidate;
	}

	public void setEventEffectiveDate(DateTime checkPointTransitionDate) {
		this.eventEffectiveDate = checkPointTransitionDate;
	}

	public void setCurrentCheckPoint(String currentCheckPoint) {
		this.currentCheckPoint = currentCheckPoint;
	}

	public void setPreviousCheckPoint(String previousCheckPoint) {
		this.previousCheckPoint = previousCheckPoint;
	}

	@Override
	public String toString() {
		return "DelinquentEvent [previousCheckPoint=" + previousCheckPoint
				+ ", currentCheckPoint=" + currentCheckPoint
				+ ", checkPointTransitionDate=" + eventEffectiveDate
				+ ", candidate=" + candidate + "]";
	}


}
