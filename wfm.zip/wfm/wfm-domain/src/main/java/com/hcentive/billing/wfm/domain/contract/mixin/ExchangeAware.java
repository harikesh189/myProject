package com.hcentive.billing.wfm.domain.contract.mixin;

import java.util.Collection;

import com.hcentive.billing.core.commons.domain.Exchange;


public interface ExchangeAware {

	Collection<Exchange> getExchangeName();
}
