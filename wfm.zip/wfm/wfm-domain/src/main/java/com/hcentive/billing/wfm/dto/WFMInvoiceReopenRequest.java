package com.hcentive.billing.wfm.dto;

import java.io.Serializable;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillingRunCycle.BillCycleType;
import com.hcentive.billing.wfm.dto.SettlementReversalRequest.PostReversalAction;

public class WFMInvoiceReopenRequest implements Serializable {

	public static enum WFMInvoiceRegnerationReason {
		
		MANUAL_INVOICE_REGENERATION(BillCycleType.REGENERATE), MANUAL_INVOICE_REBILL(BillCycleType.MANUAL_REBILL),
		PAYMENT_FAILURE(BillCycleType.AUTO_REGENERATE), GROUP_CONTRACT_UPDATED(BillCycleType.AUTO_REBILL),
		ELIGIBILITY_CONTRACT_UPDATED(BillCycleType.AUTO_REBILL);
		
		private BillCycleType billCycleType;
		
		private WFMInvoiceRegnerationReason(BillCycleType type) {
			this.billCycleType = type;
		}
		
		public BillCycleType getBillCycleType() {
			return billCycleType;
		}
	}
	
	private static final long serialVersionUID = 1L;

	private String invoiceIdentity;
	
	private String billingAccountIdentity;
	
	private WFMInvoiceRegnerationReason invoiceRegnerationReason;
	
	public WFMInvoiceReopenRequest(String invoiceIdentity,
			String billingAccountIdentity, PostReversalAction postReopenAction, WFMInvoiceRegnerationReason invoiceRegnerationReason ) {
		super();
		this.invoiceIdentity = invoiceIdentity;
		this.billingAccountIdentity = billingAccountIdentity;
		this.postReopenAction = postReopenAction;
		this.setInvoiceRegnerationReason(invoiceRegnerationReason);
	}

	private PostReversalAction postReopenAction;

	public String getInvoiceIdentity() {
		return invoiceIdentity;
	}

	public void setInvoiceIdentity(String invoiceIdentity) {
		this.invoiceIdentity = invoiceIdentity;
	}

	public String getBillingAccountIdentity() {
		return billingAccountIdentity;
	}

	public void setBillingAccountIdentity(String billingAccountIdentity) {
		this.billingAccountIdentity = billingAccountIdentity;
	}

	public PostReversalAction getPostReopenAction() {
		return postReopenAction;
	}

	public void setPostReopenAction(PostReversalAction postReopenAction) {
		this.postReopenAction = postReopenAction;
	}

	public WFMInvoiceRegnerationReason getInvoiceRegnerationReason() {
		return invoiceRegnerationReason;
	}

	public void setInvoiceRegnerationReason(WFMInvoiceRegnerationReason invoiceRegnerationReason) {
		this.invoiceRegnerationReason = invoiceRegnerationReason;
	}
	
}
