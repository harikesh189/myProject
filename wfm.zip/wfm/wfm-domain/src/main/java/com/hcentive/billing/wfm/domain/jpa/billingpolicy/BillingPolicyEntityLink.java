package com.hcentive.billing.wfm.domain.jpa.billingpolicy;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.domain.VersionableEntity;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingPolicy;
import com.hcentive.billing.wfm.domain.types.BillingPolicyTypeConverter;

@Entity
@Table(name = "billing_policy_entity_link")
@SuppressWarnings("rawtypes")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class BillingPolicyEntityLink extends DomainEntity implements VersionableEntity, TenantAware {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "active")
	private boolean active = true;

	@Column(name = "billing_account_identity")
	private String billingAccountIdentity;

	@Column(name = "billing_policy_id")
	@Convert(converter = BillingPolicyTypeConverter.class)
	private BillingPolicy billingPolicy;

	@ManyToOne(optional = false)
	@JoinColumn(name = "business_entity_id", nullable = false)
	private BusinessEntity businessEntity;

	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
		@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period period;

	public BillingPolicyEntityLink() {

	}

	public BillingPolicyEntityLink(final BillingPolicy billingPolicy, final BusinessEntity businessEntity, final String billingAccountIdentity,
			final Period period) {
		this.billingPolicy = billingPolicy;
		this.businessEntity = businessEntity;
		this.billingAccountIdentity = billingAccountIdentity;
		this.period = period;
		this.active = true;
	}

	public String getBillingAccountIdentity() {
		return this.billingAccountIdentity;
	}

	public BillingPolicy getBillingPolicy() {
		return this.billingPolicy;
	}

	public BusinessEntity getBusinessEntity() {
		return this.businessEntity;
	}

	public Period getPeriod() {
		return this.period;
	}

	@Override
	public String getTenantId() {
		return tenantId;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(final boolean active) {
		this.active = active;
	}

	public void setBillingAccountIdentity(final String billingAccountIdentity) {
		this.billingAccountIdentity = billingAccountIdentity;
	}

	/**
	 * @return the type
	 */
	/*
	 * public String getType() { return this.type; }
	 *//**
	 * @param type the type to set
	 */
	/*
	 * public void setType(final String type) { this.type = type; }
	 */

	public void setBillingPolicy(final BillingPolicy billingPolicy) {
		this.billingPolicy = billingPolicy;
	}

	public void setBusinessEntity(final BusinessEntity businessEntity) {
		this.businessEntity = businessEntity;
	}

	public void setPeriod(final Period period) {
		this.period = period;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("BillingPolicyEntityLink [billingPolicy=");
		builder.append(this.billingPolicy);
		builder.append(", businessEntity=");
		builder.append(this.businessEntity);
		builder.append(", type=");
		// builder.append(this.type);
		builder.append("]");
		return builder.toString();
	}
}
