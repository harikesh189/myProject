package com.hcentive.billing.wfm.domain.contract;

public enum SubsidyType {

	APTC, LICS, CSR;

	public static SubsidyType parse(final String val) {
		for (SubsidyType type : SubsidyType.values()) {
			if (type.toString().equalsIgnoreCase(val)) {
				return type;
			}
		}
		return null;
	}

}
