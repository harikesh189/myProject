package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.condition.Condition;
import com.hcentive.billing.condition.ConditionContextResolver;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class InvoiceReviewRule extends BillingRuleConfig{
	
	
	public static enum PostReviewAction {	
		
		REJECT("REJECT") , AUTO_APPROVAL("AUTO_APPROVAL");
		
		private PostReviewAction(final String name) {
		
		}
		
		public static PostReviewAction parse(final String value) {
			switch (value) {
				case "REJECT":
					return REJECT;
				case "AUTO_APPROVAL":
					return AUTO_APPROVAL;
				default:
					return AUTO_APPROVAL;
			}
		}
	}

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	public InvoiceReviewRule() {
		super(ConfigType.INVOICE_REVIEW);
	}
	
	private Condition matchingCondition;
	
	private int daysAfterGenerationDate=0;
	
	private PostReviewAction prAction;
	
	private boolean isLinkedWithInvoice;

	public Condition getMatchingCondition() {
		return matchingCondition;
	}

	public void setMatchingCondition(Condition matchingCondition) {
		this.matchingCondition = matchingCondition;
	}

	public int getDaysAfterGenerationDate() {
		return daysAfterGenerationDate;
	}

	public void setDaysAfterGenerationDate(int daysAfterGenerationDate) {
		this.daysAfterGenerationDate = daysAfterGenerationDate;
	}

	public PostReviewAction getPrAction() {
		return prAction;
	}

	public void setPrAction(PostReviewAction prAction) {
		this.prAction = prAction;
	}
	
	public boolean matchWith(
			final ConditionContextResolver conditionValueResolver) {
		return this.getMatchingCondition() != null ? this
				.getMatchingCondition().evaluate(conditionValueResolver) : true;
	}

	public boolean isLinkedWithInvoice() {
		return isLinkedWithInvoice;
	}
	
	public boolean getLinkedWithInvoice() {
		return isLinkedWithInvoice;
	}

	public void setLinkedWithInvoice(boolean isLinkedWithInvoice) {
		this.isLinkedWithInvoice = isLinkedWithInvoice;
	}
	
}
