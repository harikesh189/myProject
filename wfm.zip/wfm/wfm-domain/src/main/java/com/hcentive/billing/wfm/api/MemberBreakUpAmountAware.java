package com.hcentive.billing.wfm.api;

import java.util.Set;

import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;

public interface MemberBreakUpAmountAware {

	Set<MemberBreakUp> memberBreakUpAmounts();

}
