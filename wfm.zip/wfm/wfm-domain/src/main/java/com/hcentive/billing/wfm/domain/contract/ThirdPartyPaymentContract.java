package com.hcentive.billing.wfm.domain.contract;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.domain.Exchange;
import com.hcentive.billing.core.commons.domain.HealthPlanProvider;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.InsuranceCoverageAwareContract;
import com.hcentive.billing.wfm.domain.contract.mixin.EventTypeAware;
import com.hcentive.billing.wfm.domain.contract.mixin.ExchangeAware;
import com.hcentive.billing.wfm.domain.contract.mixin.HealthPlanAware;
import com.hcentive.billing.wfm.domain.contract.mixin.LOBAware;
import com.hcentive.billing.wfm.domain.eighttwenty.ThirdPartyPaymentRecord;
import com.hcentive.billing.wfm.util.ContractPartyUtil;

@Entity
@DiscriminatorValue("THIRD_PARTY_PAYMENT")
public class ThirdPartyPaymentContract extends AbstractOneTimeContract implements InsuranceCoverageAwareContract, HealthPlanAware,EventTypeAware,ExchangeAware,LOBAware {

	/**
	 *
	 */
	private static final long serialVersionUID = 6099807983666449814L;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "third_party_payment_record_id")
	@Access(AccessType.FIELD)
	private ThirdPartyPaymentRecord thirdPartyPaymentRecord;

	public ThirdPartyPaymentContract() {
		super();
		this.billedStatus = false;
	}

	public ThirdPartyPaymentContract(final String identity, final String externalId, final ThirdPartyPaymentRecord paymentTrxn, final ContractType contractType) {
		super(identity, externalId);
		this.thirdPartyPaymentRecord = paymentTrxn;
		this.type = contractType;
		this.billedStatus = false;
	}

	public ThirdPartyPaymentContract(final String identity, final String externalId) {
		super(identity, externalId);
		this.billedStatus = false;
	}

	@Override
	public IOU<Collection<FinancialTerm<?>>, AsyncCallback<Collection<FinancialTerm<?>>>> getFinancialTerms(final Period effectivePeriod) {/*
		final IOU<Collection<FinancialTerm<?>>, AsyncCallback<Collection<FinancialTerm<?>>>> contractFinancialTerms = ContractFinancialTermsBuilderProvider
				.get().buildFinancialTerms(this, effectivePeriod);
		return contractFinancialTerms;

	*/
		//to do : Fix how to use this method in future
				return null;}

	@Override
	public String refValue() {
		return this.identity;
	}

	public ThirdPartyPaymentRecord getThirdPartyPaymentRecord() {
		return this.thirdPartyPaymentRecord;
	}

	public void setThirdPartyPaymentRecord(final ThirdPartyPaymentRecord thirdPartyPaymentRecord) {
		this.thirdPartyPaymentRecord = thirdPartyPaymentRecord;
	}

	@Override
	public Set<InsuranceCoverage> insuranceCoverages() {
		final Set<InsuranceCoverage> insCoverages = new HashSet<>();
		for (final RemitCoverage plan : this.thirdPartyPaymentRecord.getRemits()) {
			insCoverages.add(plan);
		}
		return insCoverages;
	}

	@Override
	public Collection<String> getHealthPlanProducts() {
		final Collection<String> healthPlanProducts = new LinkedHashSet<>();
		final Set<RemitCoverage> remits = this.thirdPartyPaymentRecord.getRemits();
		if (isNotEmpty(remits)) {
			for (final RemitCoverage remitCoverage : remits) {
				healthPlanProducts.addAll(remitCoverage.getHealthPlanProducts());
			}
		}
		return healthPlanProducts;
	}
	
	@Override
	public Collection<String> getLineOfBusiness() {
		final Collection<String> lobs = new LinkedHashSet<>();
		final Set<RemitCoverage> remits = this.thirdPartyPaymentRecord.getRemits();
		if (isNotEmpty(remits)) {
			for (final RemitCoverage remitCoverage : remits) {
				lobs.addAll(remitCoverage.getLineOfBusiness());
			}
		}
		return lobs;
	}

	@Override
	public Collection<HealthPlanProvider> getHealthPlanProviders() {
		final Collection<HealthPlanProvider> healthPlanProviders = new LinkedHashSet<>();
		final Set<RemitCoverage> remits = this.thirdPartyPaymentRecord.getRemits();
		if (isNotEmpty(remits)) {
			for (final RemitCoverage remitCoverage : remits) {
				healthPlanProviders.addAll(remitCoverage.getHealthPlanProviders());
			}
		}
		return healthPlanProviders;
	}

	@Override
	public String getEventType() {

		return "THIRD_PPR";
	}
	
	@Override
	public Collection<Exchange> getExchangeName(){
		
		return ContractPartyUtil.findEntitiesByTypeInParties("Exchange", Exchange.class, this.getParties());
	}

}
