package com.hcentive.billing.wfm.domain.remit;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "remit_payable_info")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class RemitPayableInfo extends BaseEntity implements TenantAware {

	private static final long serialVersionUID = 1915244268118815451L;
	public static final String STATUS_INITIATED = "INITIATED";
	public static final String STATUS_PENDING = "PENDING";

	@Column(name = "status")
	@Access(AccessType.FIELD)
	private String status = STATUS_PENDING;

	@Column(name = "partner_billing_account_external_id")
	@Access(AccessType.FIELD)
	private String partnerBillingAccountExternalId;
	
	@Column(name = "partner_id")
	@Access(AccessType.FIELD)
	private Long partnerId;

	@Column(name = "partner_identity")
	@Access(AccessType.FIELD)
	private String partnerIdentity;

	@Column(name = "partner_external_id")
	@Access(AccessType.FIELD)
	private String partnerExternalId;

	@Column(name = "partner_name")
	@Access(AccessType.FIELD)
	private String partnerName;
	
	@Column(name = "partner_business_entity_type")
	@Access(AccessType.FIELD)
	private String partnerBusinessEntityType;
	
	@Column(name = "partner_type")
	@Access(AccessType.FIELD)
	private String partnerType;

	@Column(name = "business_entity_id")
	@Access(AccessType.FIELD)
	private Long businessEntityId;

	@Column(name = "business_entity_identity")
	@Access(AccessType.FIELD)
	private String businessEntityIdentity;

	@Column(name = "exchange_entity_id")
	@Access(AccessType.FIELD)
	private String exchangeEntityId;

	@Column(name = "issuer_entity_id")
	@Access(AccessType.FIELD)
	private String issuerEntityId;

	@Column(name = "business_entity_name")
	@Access(AccessType.FIELD)
	private String businessEntityName;

	@Column(name = "business_entity_type")
	@Access(AccessType.FIELD)
	private String businessEntityType;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "coverage_begins_on", nullable = false)),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "coverage_ends_on", nullable = false)) })
	private Period coveragePeriod;

	@Column(name = "exchange_subscriber_id")
	@Access(AccessType.FIELD)
	private String exchangeSubscriberId;

	@Column(name = "issuer_subscriber_id")
	@Access(AccessType.FIELD)
	private String issuerSubscriberId;
	
	@Column(name = "exchange_issuer_group_id")
	@Access(AccessType.FIELD)
	private String exchangeIssuerGroupId;

	@Column(name = "subscriber_name")
	@Access(AccessType.FIELD)
	private String subscriberName;

	@Column(name = "ft_entry_id")
	@Access(AccessType.FIELD)
	private String ftEntryId;

	@Column(name = "plan_id")
	@Access(AccessType.FIELD)
	private String planId;

	@Column(name = "plan_name")
	@Access(AccessType.FIELD)
	private String planName;

	@Column(name = "amount_category")
	@Access(AccessType.FIELD)
	private String amountCategory;

	@Column(name = "amount_name")
	@Access(AccessType.FIELD)
	private String amountName;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "value")),
	        @AttributeOverride(name = "name", column = @Column(name = "name")), @AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
	        @AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	@Column(name = "tenant_id", insertable = false, updatable = false)
	private String tenantId;

	
	
	public void setExchangeIssuerGroupId(String exchangeIssuerGroupId) {
		this.exchangeIssuerGroupId = exchangeIssuerGroupId;
	}
	
	public String getExchangeIssuerGroupId() {
		return exchangeIssuerGroupId;
	}
	
	public Period getCoveragePeriod() {
		return coveragePeriod;
	}

	public void setCoveragePeriod(Period coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}

	public void setBeginsOn(final Timestamp beginsOn) {
		if (this.coveragePeriod == null) {
			this.coveragePeriod = new Period();
		}
		this.coveragePeriod.setBeginsOn(new DateTime(beginsOn.getTime()));
	}

	public void setEndsOn(final Timestamp endsOn) {
		if (this.coveragePeriod == null) {
			this.coveragePeriod = new Period();
		}
		this.coveragePeriod.setEndsOn(new DateTime(endsOn.getTime()));
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public void setValue(final BigDecimal value) {
		this.amount = new Amount(value);
	}

	@Override
	public String getTenantId() {
		return tenantId;
	}

	public String getIssuerEntityId() {
		return issuerEntityId;
	}

	public void setIssuerEntityId(String issuerEntityId) {
		this.issuerEntityId = issuerEntityId;
	}

	public String getExchangeEntityId() {
		return exchangeEntityId;
	}

	public void setExchangeEntityId(String exchangeEntityId) {
		this.exchangeEntityId = exchangeEntityId;
	}

	public String getBusinessEntityName() {
		return businessEntityName;
	}

	public void setBusinessEntityName(String businessEntityName) {
		this.businessEntityName = businessEntityName;
	}

	public String getBusinessEntityType() {
		return businessEntityType;
	}

	public void setBusinessEntityType(String businessEntityType) {
		this.businessEntityType = businessEntityType;
	}

	public Long getBusinessEntityId() {
		return businessEntityId;
	}

	public void setBusinessEntityId(Long businessEntityId) {
		this.businessEntityId = businessEntityId;
	}

	public String getExchangeSubscriberId() {
		return exchangeSubscriberId;
	}

	public void setExchangeSubscriberId(String exchangeSubscriberId) {
		this.exchangeSubscriberId = exchangeSubscriberId;
	}

	public String getIssuerSubscriberId() {
		return issuerSubscriberId;
	}

	public void setIssuerSubscriberId(String issuerSubscriberId) {
		this.issuerSubscriberId = issuerSubscriberId;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public String getFtEntryId() {
		return ftEntryId;
	}

	public void setFtEntryId(String ftEntryId) {
		this.ftEntryId = ftEntryId;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getBusinessEntityIdentity() {
		return businessEntityIdentity;
	}

	public void setBusinessEntityIdentity(String businessEntityIdentity) {
		this.businessEntityIdentity = businessEntityIdentity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getAmountName() {
		return amountName;
	}

	public void setAmountName(String amountName) {
		this.amountName = amountName;
	}

	public Long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public String getPartnerIdentity() {
		return partnerIdentity;
	}

	public void setPartnerIdentity(String partnerIdentity) {
		this.partnerIdentity = partnerIdentity;
	}

	public String getPartnerExternalId() {
		return partnerExternalId;
	}

	public void setPartnerExternalId(String partnerExternalId) {
		this.partnerExternalId = partnerExternalId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public String getPartnerBusinessEntityType() {
		return partnerBusinessEntityType;
	}

	public void setPartnerBusinessEntityType(String partnerBusinessEntityType) {
		this.partnerBusinessEntityType = partnerBusinessEntityType;
	}

	public String getAmountCategory() {
		return amountCategory;
	}

	public void setAmountCategory(String amountCategory) {
		this.amountCategory = amountCategory;
	}

	public String getPartnerBillingAccountExternalId() {
		return partnerBillingAccountExternalId;
	}

	public void setPartnerBillingAccountExternalId(
			String partnerBillingAccountExternalId) {
		this.partnerBillingAccountExternalId = partnerBillingAccountExternalId;
	}

}