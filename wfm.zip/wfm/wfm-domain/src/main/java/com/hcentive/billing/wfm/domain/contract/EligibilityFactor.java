package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "eligibility_factor")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "factor_type")
public abstract class EligibilityFactor extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3667898799653585775L;

}
