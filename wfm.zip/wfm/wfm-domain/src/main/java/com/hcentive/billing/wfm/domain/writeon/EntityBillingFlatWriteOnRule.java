package com.hcentive.billing.wfm.domain.writeon;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Transient;

import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigFlatWriteOn;

@Entity
@DiscriminatorValue("Entity_Flat_Write_On_Rule")
public class EntityBillingFlatWriteOnRule extends AbstractBillingWriteOnRule {

	private static final long serialVersionUID = 1L;

	@Column(name = "flat_write_on_charge_id")
	private String flatWriteOnChargeId;
	
	@Transient
	private BillingConfigFlatWriteOn flatWriteOnFTCharge;
	
	public EntityBillingFlatWriteOnRule() {

	}

	public EntityBillingFlatWriteOnRule(final String businessEntityIdentity, final String writeOnFtRuleId, final String flatWriteOnChargeId) {
		super(businessEntityIdentity, writeOnFtRuleId);
		this.flatWriteOnChargeId = flatWriteOnChargeId;
	}

	public String getFlatWriteOnChargeId() {
		return flatWriteOnChargeId;
	}

	public void setFlatWriteOnChargeId(String flatWriteOnChargeId) {
		this.flatWriteOnChargeId = flatWriteOnChargeId;
	}

	public BillingConfigFlatWriteOn getFlatWriteOnFTCharge() {
		return flatWriteOnFTCharge;
	}

	public void setFlatWriteOnFTCharge(BillingConfigFlatWriteOn flatWriteOnFTCharge) {
		this.flatWriteOnFTCharge = flatWriteOnFTCharge;
	}

	@Override
	public String toString() {
		return "EntityBillingFlatWriteOnRule [flatWriteOnChargeId=" + flatWriteOnChargeId + ", flatWriteOnFTCharge=" + flatWriteOnFTCharge
				+ ", getBusinessEntityIdentity()=" + getBusinessEntityIdentity() + ", getWriteOnFtRuleId()=" + getWriteOnFtRuleId() + ", getWriteOnFTRule()="
				+ getWriteOnFTRule() + ", getIdentity()=" + getIdentity() + "]";
	}

}
