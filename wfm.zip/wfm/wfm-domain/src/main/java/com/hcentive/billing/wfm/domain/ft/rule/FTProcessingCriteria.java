package com.hcentive.billing.wfm.domain.ft.rule;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.hcentive.billing.wfm.api.enumeration.ft.PostingType;
import com.hcentive.billing.wfm.domain.ft.FinancialTrxnEntry;
import com.hcentive.billing.wfm.domain.ft.GLAccount;

public class FTProcessingCriteria implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5564300049481291395L;

	@NotNull
	private PostingType postingType;

	@NotNull
	private GLAccount glAccount;

	@NotNull
	@Size(min = 1)
	@Valid
	private final Set<GLEntryTemplate> glEntryTemplates = new HashSet<>();

	public boolean addGLEntryTemplate(final GLEntryTemplate glEntryTemplate) {
		return this.glEntryTemplates.add(glEntryTemplate);
	}

	public Set<GLEntryTemplate> getGLEntryTemplates() {
		return Collections.unmodifiableSet(this.glEntryTemplates);
	}

	public boolean matchWith(final FinancialTrxnEntry financialTrxnEntry) {
		return financialTrxnEntry.getGlEntry().getPostingType().equals(this.postingType)
		        && financialTrxnEntry.getGlEntry().getGlAccount().equals(this.glAccount);
	}

	/**
	 * @return the postingType
	 */
	public PostingType getPostingType() {
		return postingType;
	}

	/**
	 * @param postingType the postingType to set
	 */
	public void setPostingType(PostingType postingType) {
		this.postingType = postingType;
	}

	/**
	 * @return the glAccount
	 */
	public GLAccount getGlAccount() {
		return glAccount;
	}

	/**
	 * @param glAccount the glAccount to set
	 */
	public void setGlAccount(GLAccount glAccount) {
		this.glAccount = glAccount;
	}

	/**
	 * @return the glEntryTemplates
	 */
	public Set<GLEntryTemplate> getGlEntryTemplates() {
		return glEntryTemplates;
	}

}
