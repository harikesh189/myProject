package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public abstract class BillingConfigWriteOn<V> extends FinancialCharge<V> {

	private static final long serialVersionUID = 1L;
	private String type;

	public BillingConfigWriteOn() {
		super(ConfigType.WRITE_ON);
	}

	public String getType() {
		return this.type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	@Override
	public String name() {
		return this.getType();
	}

}
