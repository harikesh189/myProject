package com.hcentive.billing.wfm.domain.bill.invoice;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.BusinessEntityTypes;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.bill.BillArtifactSummary;
import com.hcentive.billing.wfm.domain.contract.mixin.EntityAware;
import com.hcentive.billing.wfm.domain.contract.mixin.EntityIdAware;
import com.hcentive.billing.wfm.domain.contract.mixin.MarketTypeAware;
import com.hcentive.billing.wfm.domain.contract.mixin.TotalAmountDueAware;

@Entity
@Table(name = "wfm_invoice_summary")
public class WFMInvoiceSummary extends BillArtifactSummary implements EntityAware, EntityIdAware, MarketTypeAware, TotalAmountDueAware {

	private static final long serialVersionUID = 646430631730071872L;

	@Access(AccessType.FIELD)
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "due_date")) })
	private DateTime dueDate;
	
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "paid_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "paid_amount_short_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "paid_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "paid_amount_name")) })
	private Amount paidAmount;
	
	public DateTime getDueDate() {
		return this.dueDate;
	}

	public void setDueDate(final DateTime dueDate) {
		this.dueDate = dueDate;
	}

	public Amount getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Amount paidAmount) {
		this.paidAmount = paidAmount;
	}
	
	public Amount getRemainingAmount(){
		if(null != this.paidAmount){
			return  super.getCurrentBillAmount().subtract(this.paidAmount);
		}
		return super.getCurrentBillAmount();
	}

	@Override
	@SuppressWarnings("unchecked")
	public Collection<BusinessEntity<Profile>> getEntities() {
		final Collection<BusinessEntity<Profile>> result = new LinkedList<>();
		result.add(getGeneratedFor().getOwner());
		return result;
	}

	@Override
	public Collection<String> getEntitieTypes() {
		final Collection<String> result = new LinkedList<>();
		result.add(getGeneratedFor().getOwner().getType());
		return result;
	}

	@Override
	public Amount getTotalAmountDue() {
		return getNetDueAmount();
	}

	@Override
	public Collection<String> getMarketTypes() {
		String type = getGeneratedFor().getOwner().getType();
		Collection<String> marketTypes = new HashSet<>();
		if(BusinessEntityTypes.INDIVIDUAL_CUSTOMER.equals(type)) {
			marketTypes.add(BusinessEntityTypes.INDIVIDUAL_CUSTOMER);
		} else if(BusinessEntityTypes.GROUP_CUSTOMER.equals(type)) {
			marketTypes.add(BusinessEntityTypes.GROUP_CUSTOMER);
		} else {
			marketTypes.add(BusinessEntityTypes.INDIVIDUAL_CUSTOMER);
			marketTypes.add(BusinessEntityTypes.GROUP_CUSTOMER);
		}
		return marketTypes;
	}

	@Override
	public Collection<String> getEntityIds() {
		return CollectionUtil.asList(getGeneratedFor().getOwner().getExternalId());
	}
}
