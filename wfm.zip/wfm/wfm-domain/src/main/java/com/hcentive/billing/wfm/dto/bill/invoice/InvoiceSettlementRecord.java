package com.hcentive.billing.wfm.dto.bill.invoice;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.dto.AbstractSettlementRecord;

@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_invoice_settlement_record")
public class InvoiceSettlementRecord extends AbstractSettlementRecord<InvoiceSettlementRecord> {

	private static final long serialVersionUID = 1L;

	private BillingAccount billingAccount;

	public BillingAccount getBillingAccount() {
		return this.billingAccount;
	}

	public void setBillingAccount(final BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}

	@Override
	public String toString() {
		return "InvoiceSettlementRecord [billingAccount=" + billingAccount + ", " + super.toString() + "]";
	}

	@Override
	public InvoiceSettlementRecord clone() {
		InvoiceSettlementRecord cloneObj = new InvoiceSettlementRecord();
		copyValues(this, cloneObj);
		cloneObj.setBillingAccount(getBillingAccount());
		return cloneObj;
	}
}
