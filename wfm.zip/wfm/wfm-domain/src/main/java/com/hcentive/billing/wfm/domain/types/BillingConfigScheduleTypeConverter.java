/**
 * 
 */
package com.hcentive.billing.wfm.domain.types;

import java.sql.Types;

import org.eclipse.persistence.mappings.DatabaseMapping;
import org.eclipse.persistence.mappings.converters.Converter;
import org.eclipse.persistence.sessions.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.hcentive.billing.core.commons.domain.converter.MongoFacadeFactory;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigSchedule;

/**
 * JPA Converter to save and read {@link BillingConfigSchedule} rule to/from
 * Mongo database.
 * 
 * @author Kumar Sambhav Jain
 * 
 */
public class BillingConfigScheduleTypeConverter implements Converter {
	private static final Logger log = LoggerFactory
			.getLogger(BillingConfigScheduleTypeConverter.class);

	@Override
	public Object convertObjectValueToDataValue(Object objectValue,
			Session session) {
		log.debug("Converter Set operation for BillingConfigSchedule");
		String ruleId = objectValue == null ? null
				: ((BillingConfigSchedule) (objectValue)).getId();
		log.debug("\nSchedule Rule MONGO_ID for {} is {}", objectValue, ruleId);
		// st.setString(index, ruleId); //TBD
		return objectValue;
	}

	@Override
	public Object convertDataValueToObjectValue(Object dataValue,
			Session session) {
		log.debug("Converter Get operation for BillingConfigSchedule");
		MongoTemplate mongoTemplate = MongoFacadeFactory.getMongoTemplate();
		if (dataValue instanceof BillingConfigSchedule) {
			BillingConfigSchedule billingConfigSchedule = (BillingConfigSchedule) dataValue;
			final String mongoId = billingConfigSchedule.getId();
			if (null != mongoId && !mongoId.isEmpty()) {
				return mongoTemplate.findById(mongoId,
						BillingConfigSchedule.class);
			} else {
				log.error("mongoId was found as null");
				return null;
			}
		}
		return dataValue;
	}

	@Override
	public boolean isMutable() {
		return true;
	}

	@Override
	public void initialize(DatabaseMapping mapping, Session session) {
		mapping.getField().setSqlType(Types.VARCHAR);
	}/*
	 * 
	 * private static final Logger log = LoggerFactory
	 * .getLogger(BillingConfigScheduleTypeConverter.class);
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.hibernate.usertype.UserType#sqlTypes()
	 * 
	 * @Override public int[] sqlTypes() { return new int[] { Types.VARCHAR }; }
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.hibernate.usertype.UserType#returnedClass()
	 * 
	 * @Override public Class<BillingConfigSchedule> returnedClass() { return
	 * BillingConfigSchedule.class; }
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.hibernate.usertype.UserType#nullSafeGet(java.sql.ResultSet,
	 * java.lang.String[], org.hibernate.engine.spi.SessionImplementor,
	 * java.lang.Object)
	 * 
	 * @Override public Object nullSafeGet(ResultSet rs, String[] names,
	 * SessionImplementor session, Object owner) throws HibernateException,
	 * SQLException {
	 * log.debug("Converter Get operation for BillingConfigSchedule"); final
	 * String mongoId = rs.getString(names[0]); if (rs.wasNull() ||
	 * isBlank(mongoId)) { return null; } MongoTemplate mongoTemplate =
	 * MongoFacadeFactory.getMongoTemplate(); if (null != mongoTemplate) {
	 * return mongoTemplate.findById(mongoId, BillingConfigSchedule.class); }
	 * else { log.error("mongoTemplate was found as null"); return null; } }
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.hibernate.usertype.UserType#nullSafeSet(java.sql.PreparedStatement,
	 * java.lang.Object, int, org.hibernate.engine.spi.SessionImplementor)
	 * 
	 * @Override public void nullSafeSet(PreparedStatement st, Object value, int
	 * index, SessionImplementor session) throws HibernateException,
	 * SQLException {
	 * log.debug("Converter Set operation for BillingConfigSchedule"); String
	 * ruleId = value == null ? null : ((BillingConfigSchedule)(value)).getId();
	 * log.debug("\nSchedule Rule MONGO_ID for {} is {}",value,ruleId);
	 * st.setString(index, ruleId); }
	 */
}
