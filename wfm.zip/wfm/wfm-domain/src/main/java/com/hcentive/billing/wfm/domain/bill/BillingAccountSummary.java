package com.hcentive.billing.wfm.domain.bill;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.util.BillAmountCalculationHelper;

@Entity
@Table(name = "billing_account_summary")
public class BillingAccountSummary extends BaseEntity {

	private static final long serialVersionUID = -4837190370087388932L;

	// @Type(type = "periodType")
	// @Columns(columns = { @Column(name = "beginsOn"), @Column(name = "endsOn")
	// })
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period summaryPeriod;

	@Access(AccessType.FIELD)
	@OneToOne
	@JoinColumn(name = "billing_account_id", nullable = false)
	private BillingAccount billingAccount;

	// @Type(type = "amount")
	// @Columns(columns = { @Column(name = "priorReceivableValue"), @Column(name
	// = "priorReceivableName"), @Column(name = "priorReceivableSymbol"),
	// @Column(name = "priorReceivableShortName") })
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "prior_receivable_value")),
			@AttributeOverride(name = "name", column = @Column(name = "prior_receivable_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "prior_receivable_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "prior_receivable_short_name")) })
	@Access(AccessType.FIELD)
	private Amount priorReceivable;  //amount due from last invoice

	// @Type(type = "amount")
	// @Columns(columns = { @Column(name = "priorPayableValue"), @Column(name =
	// "priorPayableName"), @Column(name = "priorPayableSymbol"),
	// @Column(name = "priorPayableShortName") })
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "prior_payable_value")),
			@AttributeOverride(name = "name", column = @Column(name = "prior_payable_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "prior_payable_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "prior_payable_short_name")) })
	@Access(AccessType.FIELD)
	private Amount priorPayable;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "billing_account_summary_payments", joinColumns = @JoinColumn(name = "billing_account_summary_id"), inverseJoinColumns = @JoinColumn(name = "payments_id"))
	private final Set<BillAmount> payments = new HashSet<BillAmount>(); //iska sum = total payments neeche ka part.

	// @Type(type = "amount")
	// @Columns(columns = { @Column(name = "netOutstandingValue"), @Column(name
	// = "netOutstandingName"), @Column(name = "netOutstandingSymbol"),
	// @Column(name = "netOutstandingShortName") })
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "net_outstanding_value")),
			@AttributeOverride(name = "name", column = @Column(name = "net_outstanding_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "net_outstanding_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "net_outstanding_short_name")) })
	@Access(AccessType.FIELD)
	private Amount netOutstandingAmount;

	protected BillingAccountSummary() {

	}

	public BillingAccountSummary(BillingAccount billingAccount) {
		super();
		this.billingAccount = billingAccount;
	}

	public Period getSummaryPeriod() {
		return summaryPeriod;
	}

	public void setSummaryPeriod(Period summaryPeriod) {
		this.summaryPeriod = summaryPeriod;
	}

	public Amount getPriorDueAmount() {
		

		/**
		 * Ajay: Modified code to substract priorpayble account from priorrecievable account both in caes of
		 * REMIT_INVOICE_ACCOUNT,INVOICE_ACCOUNT.
		 * Review this with Dikshit Luthra.
		 */

		switch (billingAccount.getAccountType()) {
			case REMIT_INVOICE_ACCOUNT:
			case INVOICE_ACCOUNT:
			case INVOICE_ONLY_ACCOUNT:
				return BillAmountCalculationHelper.subtract(getPriorReceivable(),
						getPriorPayable());
			case REMIT_ACCOUNT:
				return BillAmountCalculationHelper.subtract(getPriorPayable(),
						getPriorReceivable());
			default: 
				return BillAmountCalculationHelper.subtract(getPriorReceivable(),
						getPriorPayable());
		}

	}

	public Amount getPriorReceivable() {
		return priorReceivable;
	}

	public void setPriorReceivable(Amount priorReceivable) {
		this.priorReceivable = priorReceivable;
	}

	public Amount getPriorPayable() {
		return priorPayable;
	}

	public void setPriorPayable(Amount priorPayable) {
		this.priorPayable = priorPayable;
	}

	public Set<BillAmount> getPayments() {
		return payments;
	}

	public void addPayment(BillAmount payment) {
		payments.add(payment);
	}

	public Amount getNetOutstandingAmount() {
		return netOutstandingAmount;
	}

	public void setNetOutstandingAmount(Amount outstandingAmount) {
		netOutstandingAmount = outstandingAmount;
	}

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

}
