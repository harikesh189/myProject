/**
 * 
 */
package com.hcentive.wfm.checkpoint.domain;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * @author Dikshit.Vaid
 *
 */
public class CheckpointLifeCycleMetadata<T extends DomainEntity, M extends MonitoredObjectMeta> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3030575019668497109L;
	private Class<?> triggerObjectType;
	private M monitoredObjectMetadata;
	private T monitoredObject;
	private DateTime dueDate;
	private Period billingPeriod;
	private String ruleType;

	public CheckpointLifeCycleMetadata(Class<?> triggerObjectType, M monitoredObjectMetadata, T monitoredObject) {
		super();
		this.triggerObjectType = triggerObjectType;
		this.monitoredObjectMetadata = monitoredObjectMetadata;
		this.monitoredObject = monitoredObject;
	}


	public Period getBillingPeriod() {
		return billingPeriod;
	}


	public void setBillingPeriod(Period billingPeriod) {
		this.billingPeriod = billingPeriod;
	}


	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public Class<?> getTriggerObjectType() {
		return triggerObjectType;
	}

	public void setTriggerObjectType(Class<?> triggerObjectType) {
		this.triggerObjectType = triggerObjectType;
	}

	public M getMonitoredObjectMetadata() {
		return monitoredObjectMetadata;
	}

	public void setMonitoredObjectMetadata(M monitoredObjectMetadata) {
		this.monitoredObjectMetadata = monitoredObjectMetadata;
	}

	public T getMonitoredObject() {
		return monitoredObject;
	}

	public void setMonitoredObject(T monitoredObject) {
		this.monitoredObject = monitoredObject;
	}

	public DateTime getDueDate() {
		return dueDate;
	}

	public void setDueDate(DateTime dueDate) {
		this.dueDate = dueDate;
	}

}
