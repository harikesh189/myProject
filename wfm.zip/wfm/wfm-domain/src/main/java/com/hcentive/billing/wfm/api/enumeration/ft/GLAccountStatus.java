package com.hcentive.billing.wfm.api.enumeration.ft;

public enum GLAccountStatus {
	ACTIVE, CLOSED
}
