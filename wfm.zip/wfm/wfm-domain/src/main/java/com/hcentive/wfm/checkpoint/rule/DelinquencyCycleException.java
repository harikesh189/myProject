/**
 * 
 */
package com.hcentive.wfm.checkpoint.rule;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.condition.Condition;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfiguration;

/**
 * Exceptions for delinquency cycle.
 * 
 * @author Kumar Sambhav Jain
 *
 */
@Document(collection = "#{T(com.hcentive.billing.core.commons.tenant.util.TenantUtil).getTenantId()}_delinquency_cycle_exception")
public class DelinquencyCycleException extends BillingConfiguration {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4237919322449280513L;

	private static final Comparator<? super DelinquencyCycleException> END_DATE_COMPARATOR = new EndDateComparator();
	private static final Comparator<? super DelinquencyCycleException> START_DATE_COMPARATOR = new StartDateComparator();

	private Condition condition;

	/**
	 * @return the condition
	 */
	public Condition getCondition() {
		return condition;
	}

	/**
	 * @param condition
	 *            the condition to set
	 */
	public void setCondition(Condition condition) {
		this.condition = condition;
	}

	/**
	 * Default no argument constructor.
	 */
	public DelinquencyCycleException() {
	}

	public static void sortByEndDate(List<DelinquencyCycleException> exceptions) {
		Collections.sort(exceptions,
				DelinquencyCycleException.END_DATE_COMPARATOR);
	}

	public static void sortByStartDate(List<DelinquencyCycleException> exceptions) {
		Collections.sort(exceptions,
				DelinquencyCycleException.START_DATE_COMPARATOR);
	}

	private static class EndDateComparator implements
			Comparator<DelinquencyCycleException> {

		@Override
		public int compare(final DelinquencyCycleException arg0,
				final DelinquencyCycleException arg1) {
			// sort descending
			return arg1.getPeriod().getEndsOn()
					.compareTo(arg0.getPeriod().getEndsOn());
		}

	}

	private static class StartDateComparator implements
			Comparator<DelinquencyCycleException> {

		@Override
		public int compare(final DelinquencyCycleException arg0,
				final DelinquencyCycleException arg1) {
			// sort ascending
			return arg0.getPeriod().getBeginsOn()
					.compareTo(arg1.getPeriod().getBeginsOn());
		}

	}

	@Override
	public String type() {
		return "Delinquency Exception";
	}

}
