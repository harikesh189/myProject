package com.hcentive.billing.wfm.domain.manualadjustment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.hcentive.billing.core.commons.domain.FinancialEventContext;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.util.ManualAdjustmentStatus;

/**
 * Base class for Manual Adjustments.
 *
 * @author ajay.saxena
 *
 */
@Entity
@Table(name = "manual_adjustment")
@SuppressWarnings("rawtypes")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "manual_adjustment_type")
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "manual_adjustment_type")
@JsonSubTypes({ @JsonSubTypes.Type(value = WriteOff.class, name = "Write-Off"), @JsonSubTypes.Type(value = WriteOn.class, name = "Write-On"),
	@JsonSubTypes.Type(value = CreditAdjustment.class, name = "Credit"), @JsonSubTypes.Type(value = Refund.class, name = "Refund") ,@JsonSubTypes.Type(value = MoneyTransferRecord.class, name = "Money-Transfer") })
public abstract class ManualAdjustment extends ReferenceableDomainEntity<ManualAdjustment, String> implements FinancialEventContext {
	/**
	 *
	 */
	private static final long serialVersionUID = 8095239426423479017L;

	@Access(AccessType.FIELD)
	@Column(name = "name")
	protected String name;

	@Access(AccessType.FIELD)
	@Column(name = "description")
	protected String description;

	@Access(AccessType.FIELD)
	@Column(name = "type")
	protected String type;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "manual_adj_value")),
		@AttributeOverride(name = "name", column = @Column(name = "manual_adj_name")),
		@AttributeOverride(name = "symbol", column = @Column(name = "manual_adj_symbol")),
		@AttributeOverride(name = "shortName", column = @Column(name = "manual_adj_short_name")) })
	@Access(AccessType.FIELD)
	protected Amount manualAdjAmount;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	protected ManualAdjustmentStatus status;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "init_date")) })
	@Access(AccessType.FIELD)
	private DateTime initDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "effective_date")) })
	@Access(AccessType.FIELD)
	protected DateTime effectiveDate;

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = ManualAdjustmentParty.class)
	@JoinTable(name = "manual_adj_parties", joinColumns = @JoinColumn(name = "manaual_adj_id"), inverseJoinColumns = @JoinColumn(name = "parties_id"))
	protected List<ManualAdjustmentParty> parties = new ArrayList<>();

	@Transient
	private Period billingPeriod;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = ManualAdjustmentAdditionalInfo.class)
	@Access(AccessType.FIELD)
	@JoinTable(name = "manual_adj_add_info_set", joinColumns = @JoinColumn(name = "manaual_adj_id", referencedColumnName = "ID"),
	inverseJoinColumns = @JoinColumn(name = "manual_adj_add_info_id", referencedColumnName = "ID"))
	protected final Set<ManualAdjustmentAdditionalInfo> additionalInfoSet = new HashSet<>();

	public ManualAdjustment() {
	}

	public ManualAdjustment(final String identity) {
		super(identity);
	}

	public ManualAdjustment(final String identity, final String externalId) {
		super(identity);
		this.externalId = externalId;
	}

	public void addAdditionalInf(final ManualAdjustmentAdditionalInfo additionalInfo) {
		this.additionalInfoSet.add(additionalInfo);
	}

	public void addAdditionalInfos(final Set<ManualAdjustmentAdditionalInfo> addInfos) {
		if (null != addInfos) {
			this.additionalInfoSet.addAll(addInfos);
		}
	}

	public void addParties(final List<ManualAdjustmentParty> partiesToAdd) {
		if (null != partiesToAdd) {
			this.parties.addAll(partiesToAdd);

		}
	}

	public void addParty(final ManualAdjustmentParty manualAdjustmentParty) {
		this.parties.add(manualAdjustmentParty);
	}

	public Set<ManualAdjustmentAdditionalInfo> getAdditionalInfoSet() {
		return Collections.unmodifiableSet(this.additionalInfoSet);
	}

	public Period getBillingPeriod() {
		return this.billingPeriod;
	}

	public String getDescription() {
		return this.description;
	}

	public DateTime getEffectiveDate() {
		return this.effectiveDate;
	}

	public DateTime getInitDate() {
		return this.initDate;
	}

	public Amount getManualAdjAmount() {
		return this.manualAdjAmount;
	}

	public String getName() {
		return this.name;
	}

	public List<ManualAdjustmentParty> getParties() {
		return Collections.unmodifiableList(this.parties);
	}

	public ManualAdjustmentStatus getStatus() {
		return this.status;
	}

	public String getType() {
		return this.type;
	}

	public ManualAdjustmentParty primary() {
		if (this.parties.isEmpty()) {
			return null;
		}

		for (final ManualAdjustmentParty party : this.parties) {
			if (party.getPartyCategory().equals(ManualAdjustmentPartyCategory.PRIMARY)) {
				return party;
			}
		}
		return null;

	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public ManualAdjustmentParty secondary() {
		if (this.parties.isEmpty()) {
			return null;
		}

		for (final ManualAdjustmentParty party : this.parties) {
			if (party.getPartyCategory().equals(ManualAdjustmentPartyCategory.SECONDARY)) {
				return party;
			}
		}
		return null;

	}

	public void setBillingPeriod(final Period billingPeriod) {
		this.billingPeriod = billingPeriod;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public void setEffectiveDate(final DateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public void setInitDate(final DateTime initDate) {
		this.initDate = initDate;
	}

	public void setManualAdjAmount(final Amount manualAdjAmount) {
		this.manualAdjAmount = manualAdjAmount;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public void setParties(final List<ManualAdjustmentParty> parties) {
		this.parties = parties;
	}

	public void setStatus(final ManualAdjustmentStatus status) {
		this.status = status;
	}

	public void setType(final String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "ManualAdjustment [name=" + this.name + ", description=" + this.description + ", type=" + this.type + ", manualAdjAmount="
		        + this.manualAdjAmount + ", status=" + this.status + ", initDate=" + this.initDate + ", effectiveDate=" + this.effectiveDate + ", parties="
		        + this.parties + ", additionalInfoSet=" + this.additionalInfoSet + "]";
	}

}
