package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import org.springframework.data.mongodb.core.mapping.Document;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.eligibility.MaintenanceCode;
import com.hcentive.billing.wfm.api.enumeration.eligibility.MaintenanceReasonCode;

@Document
public class MaintenanceInfo extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Enumerated(EnumType.STRING)
	private MaintenanceLevel level;

	private DateTime effectiveDate;

	private MaintenanceReasonCode reasonCode;

	private MaintenanceCode maintenanceCode;

	private String contractId;

	private String memberId;

	private String planId;

	private boolean forSubscriber;

	private String description;

	public MaintenanceInfo(MaintenanceLevel level, MaintenanceCode maintenanceCode, MaintenanceReasonCode reasonCode, String contractId) {
		this.level = level;
		this.maintenanceCode = maintenanceCode;
		this.reasonCode = reasonCode;
		this.contractId = contractId;
	}

	public MaintenanceInfo(MaintenanceLevel level, String contractId) {
		this.level = level;
		this.contractId = contractId;
	}

	protected MaintenanceInfo() {
	}

	public String getContractId() {
		return contractId;
	}

	public String getDescription() {
		return description;
	}

	public DateTime getEffectiveDate() {
		return effectiveDate;
	}

	public MaintenanceLevel getLevel() {
		return level;
	}

	public MaintenanceCode getMaintenanceCode() {
		return maintenanceCode;
	}

	public String getMemberId() {
		return memberId;
	}

	public String getPlanId() {
		return planId;
	}

	public MaintenanceReasonCode getReasonCode() {
		return reasonCode;
	}

	public boolean isForSubscriber() {
		return forSubscriber;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setEffectiveDate(DateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public void setForSubscriber(boolean forSubscriber) {
		this.forSubscriber = forSubscriber;
	}

	public void setLevel(MaintenanceLevel level) {
		this.level = level;
	}

	public void setMaintenanceCode(MaintenanceCode maintenanceCode) {
		this.maintenanceCode = maintenanceCode;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public void setReasonCode(MaintenanceReasonCode reasonCode) {
		this.reasonCode = reasonCode;
	}
	
	public String constructDescription() {
		if (maintenanceCode != null) {
			StringBuffer desc = new StringBuffer(level.name() + " "
					+ maintenanceAction(maintenanceCode));
			if (reasonCode != null) {
				desc.append(" due to ").append(reasonCode.name());
			}
			return desc.toString().toLowerCase();
		}
		return null;
	}
	
	private String maintenanceAction(MaintenanceCode maintenanceCode) {
		switch (maintenanceCode) {
		case NEW:
		case ADD: 
			return "added";
		case CHG: 
			return "updated";
		case CAN:
			return "cancelled";
		case TERM: 
			return "terminated";
		case REIN: 
			return "reinstated";
		case DELETE: 
			return "deleted";
		default:
			return maintenanceCode.name();
		}
	}
}
