package com.hcentive.billing.wfm.domain.ft.rule;

public abstract class FixedValueAttrRef<T> extends GLEntryAttributeRef<T> {

	public T getValue() {
		return refData();
	}

}
