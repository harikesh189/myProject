package com.hcentive.billing.wfm.api.enumeration.eligibility;

import javax.persistence.Embeddable;

@Embeddable
public enum MaintenanceCode {
	ADD, CHG, CAN, TERM, REIN, DELETE, AUDIT, CORRECTION, CAN_TERM , NEW;
}
