package com.hcentive.billing.wfm.domain.eighttwenty;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.payment.AbstractPaymentRecord;

@Entity
@DiscriminatorValue("Refund_Payment_Record")
public class RefundPaymentRecord extends AbstractPaymentRecord<RefundPaymentRecord, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9169407767192310938L;

	public RefundPaymentRecord() {
		super();
		setStatus(STATUS_INITIATED);
	}
	
	public RefundPaymentRecord(String identity) {
		super(identity);
		setStatus(STATUS_INITIATED);
	}

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "total_paid_value")),
			@AttributeOverride(name = "name", column = @Column(name = "total_paid_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "total_paid_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "total_paid_short_name")) })
	private Amount totalPayableAmount;
	
	@OneToOne
	@JoinColumn(name = "billing_account_id")
	private BillingAccount payeeBillingAccount;
	
	@Override
	public String typeName() {
		return "Refund_Payment_Record";
	}

	public Amount getTotalPayableAmount() {
		return totalPayableAmount;
	}

	public void setTotalPayableAmount(Amount totalPayableAmount) {
		this.totalPayableAmount = totalPayableAmount;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public BillingAccount getPayeeBillingAccount() {
		return payeeBillingAccount;
	}

	public void setPayeeBillingAccount(BillingAccount payeeBillingAccount) {
		this.payeeBillingAccount = payeeBillingAccount;
	}
	
}
