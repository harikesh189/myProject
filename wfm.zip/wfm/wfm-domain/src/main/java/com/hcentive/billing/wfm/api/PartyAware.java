package com.hcentive.billing.wfm.api;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Profile;

public interface PartyAware<T extends BusinessEntity<Profile>> {

	T party();

}
