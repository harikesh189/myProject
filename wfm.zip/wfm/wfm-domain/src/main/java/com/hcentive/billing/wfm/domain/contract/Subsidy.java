package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.SubsidyProvider;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "subsidy")
public class Subsidy extends BaseEntity implements Effectivity {

	private static final long serialVersionUID = 1736724647259770885L;

	@Access(AccessType.FIELD)
	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	private SubsidyType type;

	@OneToOne
	@JoinColumn(name = "provider_id")
	@Access(AccessType.FIELD)
	private SubsidyProvider provider;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "effective_date")) })
	@Access(AccessType.FIELD)
	private DateTime effectiveDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "termination_date")) })
	@Access(AccessType.FIELD)
	private DateTime terminationDate;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "value")),
	        @AttributeOverride(name = "name", column = @Column(name = "name")), @AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
	        @AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	public SubsidyType getType() {
		return type;
	}

	public void setType(SubsidyType type) {
		this.type = type;
	}

	public SubsidyProvider getProvider() {
		return provider;
	}

	public void setProvider(SubsidyProvider provider) {
		this.provider = provider;
	}

	public DateTime getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(DateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public DateTime getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(DateTime terminationDate) {
		this.terminationDate = terminationDate;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	@Override
	public Period effectivePeriod() {
		return new Period(getEffectiveDate(), getTerminationDate());
	}

}
