package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "eligibility_factor")
@DiscriminatorValue("Smoking")
public class SmokingFactor extends EligibilityFactor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2248228158483749961L;

	protected SmokingFactor() {
	}

	public SmokingFactor(boolean smokingStatus) {
		this.smokingStatus = smokingStatus;
	}

	@Access(AccessType.FIELD)
	@Column(name = "smoking_status")
	private boolean smokingStatus;

	public boolean isSmokingStatus() {
		return smokingStatus;
	}

	public void setSmokingStatus(boolean smokingStatus) {
		this.smokingStatus = smokingStatus;
	}

}
