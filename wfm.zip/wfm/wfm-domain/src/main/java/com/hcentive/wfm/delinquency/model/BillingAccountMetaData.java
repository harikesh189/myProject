/**
 * 
 */
package com.hcentive.wfm.delinquency.model;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.wfm.checkpoint.domain.MonitoredObjectMeta;

/**
 * @author Dikshit.Vaid
 *
 */
public abstract class BillingAccountMetaData implements MonitoredObjectMeta {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4310262964100645335L;
	private final String billingAccountIdentity;
	
	public BillingAccountMetaData(final String billingAccountIdentity) {
		super();
		this.billingAccountIdentity=billingAccountIdentity;
	}

	public String getBillingAccountIdentity() {
		return billingAccountIdentity;
	}
	public abstract Amount getNetBalance();
	
}
