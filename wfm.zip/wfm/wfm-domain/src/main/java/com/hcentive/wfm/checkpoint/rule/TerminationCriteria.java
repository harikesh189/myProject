/**
 * 
 */
package com.hcentive.wfm.checkpoint.rule;

import java.io.Serializable;

import com.hcentive.billing.wfm.api.DELINQUENCY_TERMINATION_TYPE;

/**
 * @author harikesh.kumar
 *
 */
public class TerminationCriteria implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5165251765165951090L;

	public DELINQUENCY_TERMINATION_TYPE type;

	public int day;

	/**
	 * @return the type
	 */
	public DELINQUENCY_TERMINATION_TYPE getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(DELINQUENCY_TERMINATION_TYPE type) {
		this.type = type;
	}

	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}

	/**
	 * @param day
	 *            the day to set
	 */
	public void setDay(int day) {
		this.day = day;
	}

}
