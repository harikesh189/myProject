package com.hcentive.billing.wfm.domain.ft;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.wfm.api.enumeration.ft.EventDataType;

@Entity
@Table(name = "event_data_ref")
public class EventDataRef extends BaseEntity{

	private static final long serialVersionUID = 3577424944009353839L;

	@Enumerated(EnumType.STRING)
	@Column(name = "event_data_type")
	private EventDataType dataType;

	@Column(name = "data_identity")
	private String dataIdentity;
	
	@Column(name = "data_display_id")
	private String dataDisplayId;
	
	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "event_meta_data_info", joinColumns = @JoinColumn(name = "id"))
	@Column(name = "meta_data_info_value")
	@MapKeyColumn(name = "meta_data_info_key")
	@Access(AccessType.FIELD)
	private Map<String, String> metaDataInfo;
	
	protected EventDataRef(){
		
	}
	
	public EventDataRef(String dataIdentity,String dataDisplayId,EventDataType dataType){
		this.dataDisplayId = dataDisplayId;
		this.dataIdentity = dataIdentity;
		this.dataType = dataType;
	}

	public EventDataType getDataType() {
		return dataType;
	}

	public void setDataType(EventDataType dataType) {
		this.dataType = dataType;
	}

	public String getDataIdentity() {
		return dataIdentity;
	}

	public void setDataIdentity(String dataIdentity) {
		this.dataIdentity = dataIdentity;
	}

	public String getDataDisplayId() {
		return dataDisplayId;
	}

	public void setDataDisplayId(String dataDisplayId) {
		this.dataDisplayId = dataDisplayId;
	}
	
	public Map<String, String> getMetaDataInfo() {
		return metaDataInfo;
	}

	public void setMetaDataInfo(Map<String, String> metaDataInfo) {
		this.metaDataInfo = metaDataInfo;
	}
	
	public void addMetaData(String metaDataKey,String metaDataValue){
		
		if(this.metaDataInfo == null){
			this.metaDataInfo = new HashMap<>();
		}
		
		if(null != metaDataKey && null != metaDataValue){
			this.metaDataInfo.put(metaDataKey, metaDataValue);
		}
	}

	@Override
	public String toString() {
		return "EventDataRef [dataType=" + dataType + ", dataIdentity="
				+ dataIdentity + ", dataDisplayId=" + dataDisplayId
				+ ", metaDataInfo=" + metaDataInfo + "]";
	}
	
}
