package com.hcentive.billing.wfm.domain.billingpolicy;

import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.wfm.api.BillRunType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.RunCycleType;
import com.hcentive.billing.wfm.dto.DatesHolder;
import com.hcentive.billing.wfm.dto.DatesHolder.DateType;

/**
 * It represent the configuration details related to billing cycle scheduling of
 * an billing policy.
 *
 * @author nitin.singla
 */
public class BillingConfigSchedule extends BillingRuleConfig implements BufferPeriodEndDateAware{

	/**
	 * serialVersionUID
	 */
	public static final long serialVersionUID = 1L;

	/**
	 * Binder Invoice specific
	 */
	public BillingScheduleStrategy binderInvoice;

	/**
	 * Regular Invoice specific
	 */
	@NotNull
	public BillingScheduleStrategy regularInvoice;

	/**
	 * Reinstatement Invoice specific
	 */

	public BillingScheduleStrategy reinstatementInvoice;

	@NotNull
	private RunCycleType periodType;

	@Min(0)
	@Max(31)
	@Deprecated
	private int bufferPeriod;

	/**
	 * Defaule No argument constructor.
	 */
	public BillingConfigSchedule() {
		this(null, null, null);
	}

	/**
	 *
	 */
	public BillingConfigSchedule(final BillingScheduleStrategy binderInvoice, final BillingScheduleStrategy regularInvoice, final RunCycleType periodType) {
		super(ConfigType.BILLING_CYCLE);
		this.binderInvoice = binderInvoice;
		this.regularInvoice = regularInvoice;
		this.periodType = periodType;
	}

	public BillingScheduleStrategy getBinderInvoice() {
		return this.binderInvoice;
	}

	public int getBufferPeriod() {
		return this.bufferPeriod;
	}

	/**
	 * Gets the type of billing period.
	 *
	 * @return The type of billing period.
	 */
	public RunCycleType getPeriodType() {
		return this.periodType;
	}

	public BillingScheduleStrategy getRegularInvoice() {
		return this.regularInvoice;
	}

	public BillingScheduleStrategy getReinstatementInvoice() {
		return this.reinstatementInvoice;
	}

	public void setBinderInvoice(final BillingScheduleStrategy binderInvoice) {
		this.binderInvoice = binderInvoice;
	}

	public void setBufferPeriod(final int bufferPeriod) {
		this.bufferPeriod = bufferPeriod;
	}

	/**
	 * Sets the type of billing period.
	 *
	 * @param periodType
	 *            The type of billing period to set.
	 */
	public void setPeriodType(final RunCycleType periodType) {
		this.periodType = periodType;
	}

	public void setRegularInvoice(final BillingScheduleStrategy regularInvoice) {
		this.regularInvoice = regularInvoice;
	}

	public void setReinstatementInvoice(final BillingScheduleStrategy reinstatementInvoice) {
		this.reinstatementInvoice = reinstatementInvoice;
	}
	
	public boolean isBufferApplicable(BillRunType runType) {
		return (getBufferStrategy(runType) != null || bufferPeriod != 0);
	}

	@Override
	public Date resolveBufferEndDate(DatesHolder dates, BillRunType runType) {
		BufferPeriodStrategy bufferStrategy = getBufferStrategy(runType);
		if (bufferStrategy != null) {
			return bufferStrategy.resolveBufferEndDate(dates);
		} else {
			return getBufferEndDate(dates);
		}
	}

	private BufferPeriodStrategy getBufferStrategy(BillRunType runType) {
		switch (runType) {
		case REGULAR: {
			if (regularInvoice.getRegenBufferPeriodStrategy() != null) {
				return regularInvoice.getRegenBufferPeriodStrategy();
			}
		}
		case BINDER: {
			if (binderInvoice != null && binderInvoice.getRegenBufferPeriodStrategy() != null) {
				return binderInvoice.getRegenBufferPeriodStrategy();
			} else if (regularInvoice.getRegenBufferPeriodStrategy() != null) {
				return regularInvoice.getRegenBufferPeriodStrategy();
			}
		}
		default:
			return null;
		}
	}
	
	// method need to be removed
	// included only to honour
	// deprecated buffer period
	private Date getBufferEndDate(DatesHolder dates) {
		Date bufferEndDate = DateUtility.offsetDays(
				dates.getDateByType(DateType.GENERATION_DATE), bufferPeriod);
		return DateUtility.roundAtDayEnd(bufferEndDate);
	}

}
