package com.hcentive.billing.wfm.api.enumeration.reinstatement;

import java.util.Collection;

import com.hcentive.billing.core.commons.util.CollectionUtil;

public enum ReinstatementStatus {
	IN_PROCESS, TERMINATED, REINSTATED;
	
	
	public boolean in(Collection<ReinstatementStatus> statusCollection) {
		return CollectionUtil.nullSafe(statusCollection).contains(this);
	}
	
	public boolean in(ReinstatementStatus... statusColl) {
		return CollectionUtil.asList(statusColl).contains(this);
	}
}
