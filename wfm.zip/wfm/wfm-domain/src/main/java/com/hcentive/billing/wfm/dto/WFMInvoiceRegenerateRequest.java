package com.hcentive.billing.wfm.dto;

import java.io.Serializable;

public class WFMInvoiceRegenerateRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String billingAccountIdentity;
	
	private String invoiceRegnerationReason;
	
	private boolean regenerateRequired;
	
	private boolean rebillRequired;
	
	public WFMInvoiceRegenerateRequest(String billingAccountIdentity, String invoiceRegnerationReason, boolean regenerateRequired, boolean rebillRequired) {
		super();
		this.billingAccountIdentity = billingAccountIdentity;
		this.invoiceRegnerationReason = invoiceRegnerationReason;
		this.regenerateRequired = regenerateRequired;
		this.rebillRequired = rebillRequired;
	}

	public String getBillingAccountIdentity() {
		return billingAccountIdentity;
	}

	public void setBillingAccountIdentity(String billingAccountIdentity) {
		this.billingAccountIdentity = billingAccountIdentity;
	}

	public String getInvoiceRegnerationReason() {
		return invoiceRegnerationReason;
	}

	public void setInvoiceRegnerationReason(String invoiceRegnerationReason) {
		this.invoiceRegnerationReason = invoiceRegnerationReason;
	}

	public boolean isRegenerateRequired() {
		return regenerateRequired;
	}

	public void setRegenerateRequired(boolean regenerateRequired) {
		this.regenerateRequired = regenerateRequired;
	}

	public boolean isRebillRequired() {
		return rebillRequired;
	}

	public void setRebillRequired(boolean rebillRequired) {
		this.rebillRequired = rebillRequired;
	}

}
