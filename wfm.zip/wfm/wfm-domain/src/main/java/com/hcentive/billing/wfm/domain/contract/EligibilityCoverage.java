package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.domain.Period;

@Entity
public abstract class EligibilityCoverage extends InsuranceCoverage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4321166891308298602L;

	@OneToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "insured_subscriber_id")
	protected InsuredMember<EligibleMember> insuredSubscriber;
	
	@Override
	public InsuredMember<EligibleMember> getInsuredSubscriber() {
		return insuredSubscriber;
	}
	
	public void setInsuredSubscriber(InsuredMember<EligibleMember> insuredSubscriber) {
		this.insuredSubscriber = insuredSubscriber;
	}

	public EligibilityCoverage(){
	}

	public EligibilityCoverage(BillingPlan plan) {
		super(plan);
	}

	public EligibilityCoverage(BillingPlan plan, Period coverage) {
		super(plan, coverage);
	}

	@Override
	public Period effectivePeriod() {
		return this.getTotalCoverage();
	}

	@Override
	public String typeName() {
		return "EnrolledPlan";
	}

	@Override
	public String refValue() {
		return this.getHealthPlan().getExternalId();
	}


}
