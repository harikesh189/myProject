package com.hcentive.billing.wfm.api.enumeration;

public enum PaymentRecordType {
	PAYMENT, MONEY_TRANSFER, OUTBOUND_PAYMENT
}
