package com.hcentive.billing.wfm.api;


public class InsuranceCoverageAwareFinancialTermImpl<V> extends
		FinancialTermDecorator<V> implements
		InsuranceCoverageAwareFinancialTerm<V> {

	private static final long serialVersionUID = 1L;

	private Long planId;

	public InsuranceCoverageAwareFinancialTermImpl(FinancialTerm<V> finTerm,
			Long planId) {
		super(finTerm);
		this.planId = planId;
	}

	@Override
	public Long insuranceCoverage() {
		return planId;
	}

}
