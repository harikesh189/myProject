package com.hcentive.billing.wfm.domain.ft.rule;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "event_rec_attr_ref_data")
public class EventRecordAttrRefData extends BaseEntity {

	@Access(AccessType.FIELD)
	@Column(name = "code")
	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
