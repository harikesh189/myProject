package com.hcentive.billing.wfm.domain.ft.rule;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.hcentive.billing.wfm.api.enumeration.ft.PostingType;

@Entity
@DiscriminatorValue("FixedPostingType")
public class PostingTypeFixedValueRef extends FixedValueAttrRef<PostingType> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Access(AccessType.FIELD)
	@Column(name = "posting_type")
	private PostingType postingType;

	@SuppressWarnings("unused")
	private PostingTypeFixedValueRef() {
	}

	public PostingTypeFixedValueRef(final PostingType postingType) {
		this.postingType = postingType;
	}

	@Override
	public PostingType refData() {
		return this.postingType;
	}

}
