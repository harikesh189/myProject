package com.hcentive.wfm.delinquency.model;

import com.hcentive.billing.core.commons.vo.Amount;

public class ReinstatementMetaData extends BillingAccountMetaData{
/**
	 * 
	 */
	private static final long serialVersionUID = 2850485163829750744L;
private final Amount reinstatementCharges;
private final Amount totalOutstanding;
	
	public ReinstatementMetaData(Amount reinstatementCharges, Amount totalOutstanding,
			String billingAccountIdentity) {
		super(billingAccountIdentity);
		this.reinstatementCharges=reinstatementCharges;
		this.totalOutstanding=totalOutstanding;
	}

	public Amount getReinstatementCharges() {
		return reinstatementCharges;
	}

	public Amount getTotalOutstanding() {
		return totalOutstanding;
	}

	@Override
	public Amount getNetBalance() {
		if(this.totalOutstanding!=null && this.reinstatementCharges!=null){
			return totalOutstanding.add(reinstatementCharges);
		}
		return new Amount();
	}

}
