package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

@Entity
@DiscriminatorValue("GROUP_CONTRACT")
public class GroupContract extends AbstractSubscriptionContract<ContractInfo> {

	private static final long serialVersionUID = 50151834708014552L;

	public GroupContract(final String identity) {
		super(identity);
	}
	
	
	@Column(name = "previous_contract_identity")
	protected String previousContractIdentity;

	public GroupContract(final String identity, final String exterIld) {
		super(identity);
		this.externalId = exterIld;
	}

	public GroupContract() {
	}

	/**
	 * @return the previousContractIdentity
	 */
	public String getPreviousContractIdentity() {
		return previousContractIdentity;
	}

	/**
	 * @param previousContractIdentity the previousContractIdentity to set
	 */
	public void setPreviousContractIdentity(String previousContractIdentity) {
		this.previousContractIdentity = previousContractIdentity;
	}

	@Override
	public BillingConfigProRate getProRatingConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.hcentive.billing.wfm.api.FinancialTermAware#getFinancialTerms(com .hcentive.billing.core.commons.domain.Period)
	 */
	@Override
	public IOU<Collection<FinancialTerm<?>>, AsyncCallback<Collection<FinancialTerm<?>>>> getFinancialTerms(final Period effectivePeriod) {
		// TODO Auto-generated method stub
		return null;
	}

}
