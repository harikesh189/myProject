package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.api.Effectivity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

@Entity
@Table(name = "insurance_coverage")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "insurance_coverage_type")
public abstract class InsuranceCoverage extends ReferenceableDomainEntity<InsuranceCoverage, String> implements Effectivity {

	private static final long serialVersionUID = 1L;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "health_plan_id")
	@Access(AccessType.FIELD)
	protected BillingPlan healthPlan;

	// in case of enrolled plan totalCoverage is the accumulation of individual member coverage periods
	// it will be adjusted every time a member coverage is added in the collection of MemebrCoverageInfo
	@Embedded
	private Period totalCoverage;

	@Access(AccessType.FIELD)
	@Column(name = "exchange_grp_id")
	private String exchangeGroupId;

	@Access(AccessType.FIELD)
	@Column(name = "issuer_grp_id")
	private String issuerGroupId;

	@Access(AccessType.FIELD)
	@Column(name = "coverage_type")
	private String coverageType;

	/**
	 * It represent an external_id of eligibility contract
	 */
	@Access(AccessType.FIELD)
	@Column(name = "enrollment_id")
	private String enrollmentId;

	public InsuranceCoverage(final BillingPlan plan) {
		this.healthPlan = plan;
	}

	public InsuranceCoverage(final BillingPlan plan, final Period coverage) {
		this.healthPlan = plan;
		this.totalCoverage = coverage;
	}

	protected InsuranceCoverage() {

	}

	public String getCoverageType() {
		return this.coverageType;
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}

	public String getExchangeGroupId() {
		return exchangeGroupId;
	}

	public abstract InsuredMember getInsuredSubscriber();

	public String getIssuerGroupId() {
		return issuerGroupId;
	}

	public Period getTotalCoverage() {
		return this.totalCoverage;
	}

	public void setCoverageType(final String coverageType) {
		this.coverageType = coverageType;
	}

	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public void setExchangeGroupId(String exchangeGroupId) {
		this.exchangeGroupId = exchangeGroupId;
	}

	public void setHealthPlan(final BillingPlan healthPlan) {
		this.healthPlan = healthPlan;
	}

	public void setIssuerGroupId(String issuerGroupId) {
		this.issuerGroupId = issuerGroupId;
	}

	public void setTotalCoverage(final Period totalCoverage) {
		this.totalCoverage = totalCoverage;
	}

	public abstract BillingPlan getHealthPlan();

}
