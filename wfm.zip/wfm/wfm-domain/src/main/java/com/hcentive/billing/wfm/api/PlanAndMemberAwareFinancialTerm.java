/**
 * 
 */
package com.hcentive.billing.wfm.api;

import java.util.Set;

/**
 * @author Dikshit.Vaid
 * 
 */
public interface PlanAndMemberAwareFinancialTerm<V> extends
		InsuranceCoverageAwareFinancialTerm<Set<MemberAwareFinancialTerm<V>>>,
		MemberBreakUpFinancialTermAware<V> {

	Class<V> termValueType();

}
