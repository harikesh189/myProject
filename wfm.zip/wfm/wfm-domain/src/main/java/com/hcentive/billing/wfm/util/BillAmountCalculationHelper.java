/**
 *
 */
package com.hcentive.billing.wfm.util;

import java.math.BigDecimal;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.bill.invoice.ContractBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;

/**
 * @author Dikshit.Vaid
 * 
 */
public class BillAmountCalculationHelper {

	private static final Logger logger = LoggerFactory
			.getLogger(BillAmountCalculationHelper.class);

	public static Amount calculateValue(Set<BillAmount> amounts) {
		logger.debug("Calculating value for bill amounts: {}", amounts);
		Amount value = Amount.newAmount(BigDecimal.ZERO);
		for (final BillAmount genericAmount : amounts) {
			/*
			 * if (genericAmount.getAmountCategory() == AmountCategory.PREMIUM
			 * || genericAmount.getAmountCategory() == AmountCategory.FEE ||
			 * genericAmount.getAmountCategory() == AmountCategory.TAX ||
			 * genericAmount.getAmountCategory() == AmountCategory.OTHER_CHARGE)
			 * { value = value.add(genericAmount.getAmount().getValue()); } else
			 * { value = value.subtract(genericAmount.getAmount().getValue()); }
			 */
			value = value.add(genericAmount.getAmount());
		}
		logger.debug("Value: {}", value);
		return value;
	}

	/**
	 * @param currentBillAmountBuilder
	 * @param genericAmounts
	 * @param contractAmounts
	 * @return
	 */
	public static Amount add(Set<BillAmount> genericAmounts,
			Set<ContractBillAmount> contractAmounts) {

		logger.debug("Adding bill amounts: generic amounts: {}", genericAmounts);
		Amount value = Amount.newAmount(BigDecimal.ZERO);

		value = value.add(BillAmountCalculationHelper
				.calculateValue(genericAmounts));
		for (final ContractBillAmount contractBillAmount : contractAmounts) {

			logger.debug("Adding bill amount for contract: {}",
					contractBillAmount.getContractId());
			value = value.add(BillAmountCalculationHelper
					.calculateValue(contractBillAmount.getBillAmounts()));

		}

		logger.debug("Sum of generic and contract amounts: {}", value);
		return value;
	}

	/**
	 * @param amount1
	 * @param amount2
	 * @return
	 */
	public static Amount add(Amount amount1, Amount amount2) {

		if (amount1 == null) {
			amount1 = Amount.newAmount(BigDecimal.ZERO);
		}

		if (amount2 == null) {
			amount2 = Amount.newAmount(BigDecimal.ZERO);
		}

		return amount1.add(amount2);
	}

	/**
	 * @param amount1
	 * @param amount2
	 * @return
	 */
	public static Amount subtract(Amount amount1, Amount amount2) {

		if (amount1 == null) {
			amount1 = Amount.newAmount(BigDecimal.ZERO);
		}

		if (amount2 == null) {
			amount2 = Amount.newAmount(BigDecimal.ZERO);
		}

		return amount1.subtract(amount2);
	}
}
