package com.hcentive.billing.wfm.domain.writeon;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.hcentive.billing.core.commons.domain.DomainEntity;
import com.hcentive.billing.core.commons.domain.VersionableEntity;
import com.hcentive.billing.wfm.domain.ft.rule.FTRule;

@Entity
@Table(name = "write_on_rule")
@DiscriminatorColumn(name = "rule_type")
public abstract class AbstractBillingWriteOnRule extends DomainEntity implements VersionableEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "business_entity_identity")
	private String businessEntityIdentity;

	@Column(name = "write_on_ft_rule_id")
	private String writeOnFtRuleId;
	
	@Transient
	private FTRule writeOnFTRule;
	
	public AbstractBillingWriteOnRule() {

	}

	public AbstractBillingWriteOnRule(final String businessEntityIdentity, final String writeOnFtRuleId) {
		this.businessEntityIdentity = businessEntityIdentity;
		this.writeOnFtRuleId = writeOnFtRuleId;
	}

	public String getBusinessEntityIdentity() {
		return businessEntityIdentity;
	}

	public void setBusinessEntityIdentity(String businessEntityIdentity) {
		this.businessEntityIdentity = businessEntityIdentity;
	}

	public String getWriteOnFtRuleId() {
		return writeOnFtRuleId;
	}

	public void setWriteOnFtRuleId(String writeOnFtRuleId) {
		this.writeOnFtRuleId = writeOnFtRuleId;
	}

	public FTRule getWriteOnFTRule() {
		return writeOnFTRule;
	}

	public void setWriteOnFTRule(FTRule writeOnFTRule) {
		this.writeOnFTRule = writeOnFTRule;
	}
}
