package com.hcentive.billing.wfm.domain.bill.invoice;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.util.BillAmountCalculationHelper;

@Entity
@Table(name = "wfm_invoice_line_item")
public class WFMInvoiceLineItem extends BaseEntity {

	private static final long serialVersionUID = -154223451607723727L;

	@Embedded
	private Amount totalAmount;

	@Enumerated(EnumType.STRING)
	@Column(name = "category")
	private AmountCategory category;

	@Enumerated(EnumType.STRING)
	@Column(name = "amount_group")
	private AmountGroup amountGroup;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "wfm_invoice_line_item_bill_amounts", joinColumns = @JoinColumn(name = "wfm_invoice_line_item_id"), inverseJoinColumns = @JoinColumn(name = "bill_amounts_id"))
	private Set<BillAmount> billAmounts;

	protected WFMInvoiceLineItem() {
	}

	public WFMInvoiceLineItem(final AmountCategory category,
			final AmountGroup amtGrp) {
		this.category = category;
		this.amountGroup = amtGrp;
		this.totalAmount = Amount.newAmount(BigDecimal.ZERO);
		this.billAmounts = new HashSet<>();
	}

	public Amount getTotalAmount() {
		return this.totalAmount;
	}

	public AmountCategory getCategory() {
		return this.category;
	}

	public Set<BillAmount> getBillAmounts() {
		return Collections.unmodifiableSet(this.billAmounts);
	}

	public void addBillAmount(final BillAmount billAmount) {
		this.billAmounts.add(billAmount);
		this.totalAmount = BillAmountCalculationHelper.add(this.totalAmount,
				billAmount.getAmount());
	}

	public AmountGroup getAmountGroup() {
		return amountGroup;
	}

	public void setAmountGroup(AmountGroup amountGroup) {
		this.amountGroup = amountGroup;
	}

}
