package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum BufferPeriodStrategyType {

	/**
	 * Here, the declared number of days will be added to some other date
	 * to derive the buffer end date
	 */
	NUMBER_OF_DAYS, 
	
	
	/**
	 * Here, buffer duration will be provided as a combination of
	 * the month duration forward or backward and
	 * the day in a particular month
	 */
	DAYS_AND_MONTH_VARIANT
}
