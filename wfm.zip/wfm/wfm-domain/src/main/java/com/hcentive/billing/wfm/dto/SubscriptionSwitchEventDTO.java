package com.hcentive.billing.wfm.dto;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.DateTime;

/**
 * DTO for invoice status change processing.
 *
 * @author sambhav.jain
 *
 */
public class SubscriptionSwitchEventDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * It contains the identity of the subscription marked as inactive
	 */
	private String inavtiveBillingAccountIdentity;

	/**
	 * It contains the external id of the subscription marked as inactive
	 */
	private String inavtiveBillingAccountExternalId;

	/**
	 * It contains the identity of the subscription marked as primary
	 */
	private String primaryBillingAccountIdentity;

	/**
	 * It contains the external id of the subscription marked as primary
	 */
	private String primaryBillingAccountExternalId;

	private DateTime eventDate;

	public SubscriptionSwitchEventDTO() {
	}

	public SubscriptionSwitchEventDTO(final String inavtiveBillingAccountIdentity, final String inavtiveBillingAccountExternalId,
	        final String primaryBillingAccountIdentity, final String primaryBillingAccountExternalId, final DateTime eventDate) {
		super();
		this.inavtiveBillingAccountIdentity = inavtiveBillingAccountIdentity;
		this.inavtiveBillingAccountExternalId = inavtiveBillingAccountExternalId;
		this.primaryBillingAccountIdentity = primaryBillingAccountIdentity;
		this.primaryBillingAccountExternalId = primaryBillingAccountExternalId;
		this.eventDate = eventDate;
	}

	public DateTime getEventDate() {
		return this.eventDate;
	}

	public String getInavtiveBillingAccountExternalId() {
		return this.inavtiveBillingAccountExternalId;
	}

	public String getInavtiveBillingAccountIdentity() {
		return this.inavtiveBillingAccountIdentity;
	}

	public String getPrimaryBillingAccountExternalId() {
		return this.primaryBillingAccountExternalId;
	}

	public String getPrimaryBillingAccountIdentity() {
		return this.primaryBillingAccountIdentity;
	}

	public void setEventDate(final DateTime eventDate) {
		this.eventDate = eventDate;
	}

	public void setInavtiveBillingAccountExternalId(final String inavtiveBillingAccountExternalId) {
		this.inavtiveBillingAccountExternalId = inavtiveBillingAccountExternalId;
	}

	public void setInavtiveBillingAccountIdentity(final String inavtiveBillingAccountIdentity) {
		this.inavtiveBillingAccountIdentity = inavtiveBillingAccountIdentity;
	}

	public void setPrimaryBillingAccountExternalId(final String primaryBillingAccountExternalId) {
		this.primaryBillingAccountExternalId = primaryBillingAccountExternalId;
	}

	public void setPrimaryBillingAccountIdentity(final String primaryBillingAccountIdentity) {
		this.primaryBillingAccountIdentity = primaryBillingAccountIdentity;
	}

	@Override
	public String toString() {
		return "SubscriptionSwitchEventDTO [inavtiveBillingAccountIdentity=" + this.inavtiveBillingAccountIdentity + ", inavtiveBillingAccountExternalId="
		        + this.inavtiveBillingAccountExternalId + ", primaryBillingAccountIdentity=" + this.primaryBillingAccountIdentity
		        + ", primaryBillingAccountExternalId=" + this.primaryBillingAccountExternalId + ", eventDate=" + this.eventDate + "]";
	}

}
