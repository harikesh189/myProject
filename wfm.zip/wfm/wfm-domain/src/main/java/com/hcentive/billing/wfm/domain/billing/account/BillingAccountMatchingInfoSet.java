package com.hcentive.billing.wfm.domain.billing.account;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "billing_account_matching_info_set")
public class BillingAccountMatchingInfoSet extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 8996638100214397670L;
	@Access(AccessType.FIELD)
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "billing_account_matching_info_set_item", joinColumns = @JoinColumn(name = "billing_account_matching_info_set_id",
	referencedColumnName = "ID"), inverseJoinColumns = @JoinColumn(name = "billing_account_matching_info_id", referencedColumnName = "ID"))
	private final Set<BillingAccountMatchingInfo> matchingInfoSet = new HashSet<>();

	public void add(final BillingAccountMatchingInfo baMatchingInfo) {
		this.matchingInfoSet.add(baMatchingInfo);
	}

	public void addAll(final BillingAccountMatchingInfoSet billingAccountMatchingInfoSet) {
		this.matchingInfoSet.addAll(billingAccountMatchingInfoSet.getMatchingInfoSet());
	}

	@Override
	public boolean equals(final Object obj) {
		if (obj == null) {
			return false;
		}
		if (this == obj) {
			return true;
		}

		/*
		 * if (!super.equals(obj)) --Ajay : No need to check super return false;
		 */

		if (this.getClass() != obj.getClass()) {
			return false;
		}

		final BillingAccountMatchingInfoSet other = (BillingAccountMatchingInfoSet) obj;

		if (this.matchingInfoSet == null) {
			if (other.matchingInfoSet != null) {
				return false;
			}

		} else if (this.matchingInfoSet.size() == other.getMatchingInfoSet().size()) {
			// now compare individual values in the set

			for (final BillingAccountMatchingInfo matchInfo : this.matchingInfoSet) {

				boolean matched = false;
				for (final BillingAccountMatchingInfo oMatchInfo : other.getMatchingInfoSet()) {
					if (matchInfo.equals(oMatchInfo)) {
						matched = true;
						break;
					}
				}

				if (!matched) {
					return false;
				}
			}
		} else {
			return false;
		}

		return true;
	}

	public Set<BillingAccountMatchingInfo> getMatchingInfoSet() {
		return Collections.unmodifiableSet(this.matchingInfoSet);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (this.matchingInfoSet == null ? 0 : this.matchingInfoSet.hashCode());
		return result;
	}

}
