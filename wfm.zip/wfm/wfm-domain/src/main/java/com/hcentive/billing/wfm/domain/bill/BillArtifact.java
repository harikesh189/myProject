package com.hcentive.billing.wfm.domain.bill;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;

@MappedSuperclass
public abstract class BillArtifact<S extends BillArtifactSummary> extends ReferenceableDomainEntity<BillArtifact<S>, String> {

	private static final long serialVersionUID = -1476603789935843677L;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "bill_summary_id")
	@Access(AccessType.FIELD)
	private S summary;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "billing_account_summary_id")
	private BillingAccountSummary billingAccountSummary;

	protected BillArtifact() {
	}

	protected BillArtifact(S summary) {
		this.summary = summary;
	}

	protected BillArtifact(String identity, S summary) {
		super(identity);
		this.summary = summary;
	}

	public S getSummary() {
		return summary;
	}

	public BillingAccountSummary getBillingAccountSummary() {
		return billingAccountSummary;
	}

	public void setBillingAccountSummary(BillingAccountSummary billingAccountSummary) {
		this.billingAccountSummary = billingAccountSummary;
	}

}
