package com.hcentive.billing.wfm.domain.ft;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.wfm.api.enumeration.ft.FTEntryAssociationType;

@Entity
@Table(name = "ft_entry_associations")
public class FTEntryAssociation extends BaseEntity {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "active")
	private boolean active = true;

	@ManyToOne(optional = false, fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "associated_entry_id")
	private FinancialTrxnEntry associatedFTEntry;

	@Enumerated(EnumType.STRING)
	@Column(name = "assoc_type")
	@NotNull
	private FTEntryAssociationType assocType;

	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "parent_entry_id")
	private FinancialTrxnEntry parentFTEntry;

	public FTEntryAssociation(final FinancialTrxnEntry parentFTEntry, final FinancialTrxnEntry associatedFTEntry, final FTEntryAssociationType assocType) {
		super();
		this.parentFTEntry = parentFTEntry;
		this.associatedFTEntry = associatedFTEntry;
		this.assocType = assocType;
	}

	protected FTEntryAssociation() {
	}

	public FinancialTrxnEntry getAssociatedFTEntry() {
		return this.associatedFTEntry;
	}

	public FTEntryAssociationType getAssocType() {
		return this.assocType;
	}

	public FinancialTrxnEntry getParentFTEntry() {
		return this.parentFTEntry;
	}

	public boolean isActive() {
		return this.active;
	}

	public void setActive(final boolean active) {
		this.active = active;
	}

	public void setAssociatedFTEntry(final FinancialTrxnEntry associatedFTEntry) {
		this.associatedFTEntry = associatedFTEntry;
	}

	public void setAssocType(final FTEntryAssociationType assocType) {
		this.assocType = assocType;
	}

	public void setParentFTEntry(final FinancialTrxnEntry parentFTEntry) {
		this.parentFTEntry = parentFTEntry;
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("FTEntryAssociation [active=");
		builder.append(active);
		builder.append(", associatedFTEntry=");
		builder.append(associatedFTEntry.getIdentity());
		builder.append(", assocType=");
		builder.append(assocType);
		builder.append(", parentFTEntry=");
		builder.append(parentFTEntry.getIdentity());
		builder.append("]");
		return builder.toString();
	}
}
