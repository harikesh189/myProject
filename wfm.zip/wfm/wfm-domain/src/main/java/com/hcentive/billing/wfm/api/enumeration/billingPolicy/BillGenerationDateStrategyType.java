package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * It represent the type of strategy to use to calculate the bill generation
 * date w.r.t billing due date.
 * 
 * @author nitin.singla
 * 
 */
public enum BillGenerationDateStrategyType {

	/**
	 * It means bill generation date will be calculated by adding specified
	 * number of days from bill due date. <br/>
	 * <br/>
	 * Example : If bill due date is defined as 1st of every month and bill
	 * generation date is defined as 20 days after the bill due date. WFM will
	 * determine the bill generation date for the May coverage period as 21 May
	 * i.e. 20 days after 1st May.
	 */
	DAYS_AFTER_DUE_DATE,

	/**
	 * It means bill generation date will be calculated by subtracting specified
	 * number of days from bill due date. <br/>
	 * <br/>
	 * Example : If bill due date is defined as 1st of every month and bill
	 * generation date is defined as 20 days before the bill due date. WFM will
	 * determine the bill generation date for the May coverage period as 10
	 * April i.e. 20 days before 1st May.
	 */
	DAYS_BEFORE_DUE_DATE,
	
	/**
	 * It means a particular day of the month in the month 
	 * derived after adding month variant to the reference date
	 * For ex. dayOfMonth = 5, monthVariance = -2 and refDate = April 3rd
	 * Month will be calculated as -2 months from April which comes as February.
	 * Day of month should be set as 5th of the month
	 * Result = February 5th
	 */
	DAYS_AND_MONTH_VARIANT,
	
	/**
	 * Bill generation should happen immediately.
	 * Should return current dateTime when calculated.
	 */
	IMMEDIATE
}
