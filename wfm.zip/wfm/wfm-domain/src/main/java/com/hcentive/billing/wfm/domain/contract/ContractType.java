package com.hcentive.billing.wfm.domain.contract;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Embeddable;

@Embeddable
public class ContractType implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final ContractType GROUP_CONTRACT = new ContractType(
			"GroupContract");

	public static final ContractType GROUP_ELIGIBILITY_CONTRACT = new ContractType(
			"GroupEligibilityContract");

	public static final ContractType INDIVIDUAL_ELIGIBILITY_CONTRACT = new ContractType(
			"IndividualEligibilityContract");

	public static final ContractType THIRD_PARTY_PAYMENT_CONTRACT = new ContractType(
			"ThirdPartyPaymentContract");

	@Access(AccessType.FIELD)
	private String type;

	protected ContractType() {
	}

	private ContractType(final String code) {
		this.type = code;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final ContractType other = (ContractType) obj;
		if (this.type == null) {
			if (other.type != null) {
				return false;
			}
		} else if (!this.type.equals(other.type)) {
			return false;
		}
		return true;
	}

	public String getType() {
		return this.type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ (this.type == null ? 0 : this.type.hashCode());
		return result;
	}

}
