package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;

import com.hcentive.billing.core.commons.domain.Member;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

@DiscriminatorValue("THIRD_PARTY")
@Entity
public class ThirdPartyMemberCoverage extends
		AbstractMemberCoverageInfo<Member> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1155194040875855563L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "payment_amount_value")),
			@AttributeOverride(name = "name", column = @Column(name = "payment_amount_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "payment_amount_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "payment_amount_shortName")) })
	private Amount paymentAmount;

	@Access(AccessType.FIELD)
	@Column(name = "amount_code")
	private String amountCode;

	@Override
	public Period effectivePeriod() {
		return getCoverage();
	}

	public Amount getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Amount paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getAmountCode() {
		return amountCode;
	}

	public void setAmountCode(String amountCode) {
		this.amountCode = amountCode;
	}

}
