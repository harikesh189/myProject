package com.hcentive.billing.wfm.domain.contract;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.domain.Subscriber;
import com.hcentive.billing.core.commons.domain.enumtype.MarketIndicator;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "eligibility")
// @QueryEntity
public class Eligibility extends ReferenceableDomainEntity<Eligibility, String> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = EligibilityCoverage.class)
	@Access(AccessType.FIELD)
	@JoinTable(name = "eligibility_enrolled_plans", joinColumns = @JoinColumn(name = "eligibility_id"), inverseJoinColumns = @JoinColumn(name = "enrolled_plans_id"))
	private Set<EligibilityCoverage> enrolledPlans = new HashSet<EligibilityCoverage>();

	@Access(AccessType.FIELD)
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "update_date")) })
	private DateTime updateDate;

	@Access(AccessType.FIELD)
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "source_update_date")) })
	private DateTime sourceUpdateDate;

	@Enumerated(value = EnumType.STRING)
	@Column(name = "market_type")
	private MarketIndicator marketType;

	@Embedded
	private GroupEstablishmentInfo establishmentInfo;

	public Eligibility(final String identity) {
		super(identity);
	}

	protected Eligibility() {
	}

	public Set<EligibilityCoverage> getEnrolledPlans() {
		return enrolledPlans;
	}

	public DateTime getUpdateDate() {
		DateTime updateDate = getAuditInfo().getModifiedAt();
		if (sourceUpdateDate != null) {
			updateDate = sourceUpdateDate;
		}
		return updateDate;
	}

	@Override
	public String refValue() {
		return identity;
	}

	public void setEnrolledPlans(final Set<EligibilityCoverage> enrolledPlans) {
		this.enrolledPlans = enrolledPlans;
	}

	public void setUpdateDate(DateTime updateDate) {
		this.updateDate = updateDate;
	}

	@Override
	public String typeName() {
		return "Eligibility";
	}

	/**
	 * @return the sourceUpdateDate
	 */
	public DateTime getSourceUpdateDate() {
		return sourceUpdateDate;
	}

	/**
	 * @param sourceUpdateDate
	 *            the sourceUpdateDate to set
	 */
	public void setSourceUpdateDate(DateTime sourceUpdateDate) {
		this.sourceUpdateDate = sourceUpdateDate;
	}

	public MarketIndicator getMarketType() {
		return marketType;
	}

	public void setMarketType(MarketIndicator marketType) {
		this.marketType = marketType;
	}

	public GroupEstablishmentInfo getEstablishmentInfo() {
		return establishmentInfo;
	}

	public void setEstablishmentInfo(GroupEstablishmentInfo establishmentInfo) {
		this.establishmentInfo = establishmentInfo;
	}

	public void setSubscriber(Subscriber subscriber) {
		// TODO Auto-generated method stub

	}

}
