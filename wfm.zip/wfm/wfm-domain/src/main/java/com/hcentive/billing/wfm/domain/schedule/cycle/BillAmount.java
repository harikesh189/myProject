package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;

@Entity
@Table(name = "bill_amount")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "amount_type")
@DiscriminatorValue("BILL_AMT")
public class BillAmount extends ReferenceableDomainEntity<BillAmount, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7420089433323222088L;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "value")),
			@AttributeOverride(name = "name", column = @Column(name = "name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	@Enumerated(EnumType.STRING)
	@Column(name = "amount_category")
	private AmountCategory amountCategory;

	@Access(AccessType.FIELD)
	@Column(name = "code")
	private String code;

	@Column(name = "amount_name")
	private String name;

	@Enumerated(EnumType.STRING)
	@Column(name = "amount_group")
	private AmountGroup amountGroup;
	
	@Column(name = "description")
	private String description;
	
	
	@Access(AccessType.FIELD)
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "associated_date", updatable = false)) })
	private DateTime associatedDate;
	
	
	public DateTime getAssociatedDate() {
		return associatedDate;
	}

	public void setAssociatedDate(DateTime associatedDate) {
		this.associatedDate = associatedDate;
	}

	@Embedded
	private Period coveragePeriod;

	public BillAmount(final String code, final String name,
			final Amount amount, final AmountCategory type) {
		this(code, name, amount, type, AmountGroup.DEFAULT);
	}

	public BillAmount(final String code, final String name,
			final Amount amount, final AmountCategory type,
			final AmountGroup amtGrp) {
		this(code, name, amount, type, amtGrp, null, null,null);
	}
	
	public BillAmount(final String code, final String name,
			final Amount amount, final AmountCategory type,
			final AmountGroup amtGrp, final String desc, final Period period,
			DateTime  associatedDate) {
		this.identity = RandomGenerator.randomString();
		this.code = code;
		this.amount = amount;
		this.name = name;
		this.amountCategory = type;
		this.amountGroup = amtGrp;
		this.description = desc;
		this.coveragePeriod = period;
		this.associatedDate = associatedDate;
	}
	
	protected BillAmount() {
	}

	public Amount getAmount() {
		return this.amount;
	}

	public AmountCategory getAmountCategory() {
		return this.amountCategory;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setAmount(final Amount amount) {
		this.amount = amount;
	}

	@Override
	public String typeName() {
		return "BillAmount";
	}

	public AmountGroup getAmountGroup() {
		return amountGroup;
	}

	public void setAmountGroup(AmountGroup amountGroup) {
		this.amountGroup = amountGroup;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Period getCoveragePeriod() {
		return coveragePeriod;
	}

	public void setCoveragePeriod(Period coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}

	/*public BillAmount makeFTEntryAwareBillAmount(final Set<String> ftEntryIds,
			AmountGroup amtGrp,final DateTime associatedDate) {
		return new FTEntryAwareBillAmount(this.getCode(), this.getName(),
				this.getAmountCategory(), this.getAmount(), ftEntryIds, amtGrp,
				this.description, this.coveragePeriod,associatedDate);
	}*/
	public BillAmount makeFTEntryAwareBillAmount(final Set<String> ftEntryIds,
			AmountGroup amtGrp, DateTime associatedDate) {
		return new FTEntryAwareBillAmount(this.getCode(), this.getName(),
				this.getAmountCategory(), this.getAmount(), ftEntryIds, amtGrp,
				this.description, this.coveragePeriod, associatedDate);
	}

	@Override
	public String toString() {
		return "BillAmount [amount=" + amount + ", amountCategory=" + amountCategory + ", code=" + code + ", name="
				+ name + ", amountGroup=" + amountGroup + ", description=" + description + ", coveragePeriod="
				+ coveragePeriod + "]";
	}

}
