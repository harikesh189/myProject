package com.hcentive.billing.wfm.api;

import java.util.Set;

public interface FTEntryAware {

	Set<String> ftEntryIds();

}
