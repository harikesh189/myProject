package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;

@Entity
@Table(name = "billing_run_cycle")
public class BillingRunCycle extends
		ReferenceableDomainEntity<BillingRunCycle, String> {

	private static final long serialVersionUID = 1420896333088403323L;
	
	public static enum BillCycleType {
		REGULAR, MANUAL_REBILL, AUTO_REBILL, OFF_SCHEDULE, REJECT, REGENERATE, AUTO_REGENERATE
	}

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
			@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period billingPeriod;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "due_date")) })
	private DateTime dueDate;

	@Column(name = "entities_count")
	private int entitiesCount;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "invoice_amount_value")),
			@AttributeOverride(name = "currency.name", column = @Column(name = "invoice_amount_name")),
			@AttributeOverride(name = "currency.symbol", column = @Column(name = "invoice_amount_symbol")),
			@AttributeOverride(name = "currency.shortName", column = @Column(name = "invoice_amount_short_name")) })
	private Amount invoiceAmount;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "run_date")) })
	private DateTime runDate;

	@Column(name = "bill_schedule_config_id")
	private String scheduleConfigIdentity;

	@Column(name = "bill_schedule_config_external_id")
	private String scheduleConfigExternalId;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private RunStatus status;

	@Enumerated(EnumType.STRING)
	@Column(name = "bill_cycle_type")
	private BillCycleType billCycleType;
	
	public BillingRunCycle() {
		super();
	}

	public BillingRunCycle(final DateTime billingPeriodStartDate,
			final DateTime billingPeriodEndDate, final Date dueDate,
			final Date runDate, final String scheduleConfigIdentity,
			final String scheduleConfigExternalId,
			final RunStatus status, BillCycleType billCycleType) {
		super();
		this.billingPeriod = new Period(billingPeriodStartDate,
				billingPeriodEndDate);
		this.dueDate = new DateTime(dueDate);
		this.runDate = new DateTime(runDate);
		this.scheduleConfigIdentity = scheduleConfigIdentity;
		this.status = status;
		this.billCycleType = billCycleType;
		this.scheduleConfigExternalId = scheduleConfigExternalId;
	}

	public BillingRunCycle(final String referenceId) {
		super(referenceId);
	}

	public Period getBillingPeriod() {
		return this.billingPeriod;
	}

	public DateTime getDueDate() {
		return this.dueDate;
	}

	public int getEntitiesCount() {
		return this.entitiesCount;
	}

	public Amount getInvoiceAmount() {
		return this.invoiceAmount;
	}

	public DateTime getRunDate() {
		return this.runDate;
	}

	public String getScheduleConfigIdentity() {
		return this.scheduleConfigIdentity;
	}

	public RunStatus getStatus() {
		return this.status;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setBillingPeriod(final Period billingPeriod) {
		this.billingPeriod = billingPeriod;
	}

	public void setDueDate(final DateTime dueDate) {
		this.dueDate = dueDate;
	}

	public void setEntitiesCount(final int entitiesCount) {
		this.entitiesCount = entitiesCount;
	}

	public void setInvoiceAmount(final Amount invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public void setRunDate(final DateTime runDate) {
		this.runDate = runDate;
	}

	public void setScheduleConfigIdentity(final String scheduleConfig) {
		this.scheduleConfigIdentity = scheduleConfig;
	}

	public void setStatus(final RunStatus status) {
		this.status = status;
	}

	public BillCycleType getBillCycleType() {
		return billCycleType;
	}

	public void setBillCycleType(BillCycleType billCycleType) {
		this.billCycleType = billCycleType;
	}

	public String getScheduleConfigExternalId() {
		return scheduleConfigExternalId;
	}

	public void setScheduleConfigExternalId(String scheduleConfigExternalId) {
		this.scheduleConfigExternalId = scheduleConfigExternalId;
	}

	@Override
	public String typeName() {
		return "BillingRunCycle";
	}

}
