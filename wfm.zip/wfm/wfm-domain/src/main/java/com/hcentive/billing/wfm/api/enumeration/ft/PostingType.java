package com.hcentive.billing.wfm.api.enumeration.ft;

public enum PostingType {

	CR, DR;

	public PostingType reverse() {
		if (this == CR) {
			return DR;
		}
		return CR;
	}
}
