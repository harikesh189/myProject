package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.condition.Condition;
import com.hcentive.billing.condition.ConditionContextResolver;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public abstract class FinancialCharge<V> extends BillingRuleConfig implements
		FinancialTerm<V> {

	private static final long serialVersionUID = 1L;
	

	// do not delete this constructor. It is used by Json using reflection at
	// the time of save billing policy operation.
	public FinancialCharge() {

	}

	/**
	 * Initialize the billing policy configuration,
	 * 
	 * @param type
	 *            The type of billing policy to initialize.
	 */
	public FinancialCharge(final ConfigType type) {
		super(type);
	}

	private Condition matchingCondition;

	public boolean matchWith(
			final ConditionContextResolver conditionValueResolver) {
		if (null == this.getMatchingCondition())
			return true;
		return this.getMatchingCondition() != null
				&& this.getMatchingCondition().evaluate(conditionValueResolver);
	}

	public Condition getMatchingCondition() {
		return this.matchingCondition;
	}

	public void setMatchingCondition(final Condition matchingCondition) {
		this.matchingCondition = matchingCondition;
	}

	public abstract String getType();

	@Override
	public String type() {
		return this.getConfigType().toString();
	}

	@Override
	public String code() {
		return getIdentity();
	}
	
	@Override
	public String description() {
		return getDescription();
	}

}
