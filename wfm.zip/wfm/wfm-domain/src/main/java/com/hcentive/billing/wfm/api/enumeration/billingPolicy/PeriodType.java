package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * It defines how to define the retroactivity period. It tells WFM when to do
 * retroactivity and for what coverage period retroactivity is allowed, which
 * should not be beyond WFM activation date
 * 
 * @author nitin.singla
 * 
 */
public enum PeriodType {
	/**
	 * It represent that retroactivity period is defined in terms of days.
	 */
	DAYS,

	/**
	 * It represent that retroactivity period is defined in terms of months.
	 */
	MONTHS
}