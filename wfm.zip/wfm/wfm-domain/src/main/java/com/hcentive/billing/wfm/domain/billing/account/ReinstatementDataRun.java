package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.vo.DateTime;

@Entity
@Table(name = "reinstatement_data_run")
public class ReinstatementDataRun extends BaseEntity {

	private static final long serialVersionUID = -1656564961447987058L;

	public static enum Status {
		PENDING, COMPLETED, FAILED;
	}

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "run_date")) })
	private DateTime runDate;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private Status status = Status.PENDING;

	public ReinstatementDataRun() {
		super();
	}

	public DateTime getRunDate() {
		return runDate;
	}

	public void setRunDate(DateTime runDate) {
		this.runDate = runDate;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ReinstatementDataRun [runDate=" + runDate + "]";
	}
}
