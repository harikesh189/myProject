package com.hcentive.billing.wfm.domain.manualadjustment;

public enum ManualAdjustmentPartyCategory {
	
	PRIMARY,SECONDARY

}
