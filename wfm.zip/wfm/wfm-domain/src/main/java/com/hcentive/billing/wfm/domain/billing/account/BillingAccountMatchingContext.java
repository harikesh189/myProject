package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;

@Entity
@Table(name = "billing_account_matching_context")
public class BillingAccountMatchingContext extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 2168172081918239920L;

	@Column(name = "billing_account_id")
	@Access(AccessType.FIELD)
	private Long billingAccountID;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ba_matching_info_set_id")
	private BillingAccountMatchingInfoSet baMatchingInfoSet;

	@Override
	public boolean equals(final Object obj) {
		if (obj == null) {
			return false;
		}
		if (this == obj) {
			return true;
		}
		/*
		 * if (!super.equals(obj)) -- Ajay : No need to check super return
		 * false;
		 */
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final BillingAccountMatchingContext other = (BillingAccountMatchingContext) obj;
		if (this.baMatchingInfoSet == null) {
			if (other.baMatchingInfoSet != null) {
				return false;
			}
		} else if (!this.baMatchingInfoSet.equals(other.baMatchingInfoSet)) {
			return false;
		}
		return true;
	}

	public Long getBillingAccountID() {
		return this.billingAccountID;
	}

	public BillingAccountMatchingInfoSet getMatchingInfoSet() {
		return this.baMatchingInfoSet;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (this.baMatchingInfoSet == null ? 0 : this.baMatchingInfoSet.hashCode());
		return result;
	}

	public void setBaMatchingInfoSet(final BillingAccountMatchingInfoSet baMatchingInfoSet) {
		this.baMatchingInfoSet = baMatchingInfoSet;
	}

	public void setBillingAccountID(final Long billingAccountID) {
		this.billingAccountID = billingAccountID;
	}

}
