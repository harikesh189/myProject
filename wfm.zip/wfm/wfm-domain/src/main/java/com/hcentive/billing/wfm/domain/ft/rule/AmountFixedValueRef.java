package com.hcentive.billing.wfm.domain.ft.rule;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;

import com.hcentive.billing.core.commons.vo.Amount;

@Entity
@DiscriminatorValue("FixedAmount")
public class AmountFixedValueRef extends FixedValueAttrRef<Amount> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1575837513190331649L;
	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "value")),
			@AttributeOverride(name = "name", column = @Column(name = "name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "short_name")) })
	@Access(AccessType.FIELD)
	private Amount amount;

	public AmountFixedValueRef(final Amount amount) {
		this.amount = amount;
	}

	public AmountFixedValueRef() {
	}

	@Override
	public Amount refData() {
		return this.amount;
	}

}
