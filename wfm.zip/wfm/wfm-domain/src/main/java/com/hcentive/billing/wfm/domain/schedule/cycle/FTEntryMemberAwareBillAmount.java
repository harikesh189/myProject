package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.FTEntryAware;

@Entity
@Table(name = "bill_amount")
@DiscriminatorValue("FT_MEM_AWARE_BILL_AMT")
public class FTEntryMemberAwareBillAmount extends MemberAwareBillAmount implements FTEntryAware {

	private static final long serialVersionUID = -3424432042594856615L;

	@ElementCollection(fetch = FetchType.EAGER)
	@Column(name = "ft_entry_id")
	@CollectionTable(name = "bill_amount_ft_entry_ids_1", joinColumns = @JoinColumn(name = "bill_amount_id"))
	private Set<String> ftEntryIds;

	protected FTEntryMemberAwareBillAmount() {
	}

	public FTEntryMemberAwareBillAmount(final String amountCode, final String amountName, final AmountCategory type, final Amount amount,
	        final Set<String> ftEntryIds, final Set<MemberBreakUp> memBreakUpAmts, AmountGroup amtGrp, final String desc, 
	        final Period coveragePeriod, final DateTime associatedDate) {
		super(amountCode, amountName, amount, type, memBreakUpAmts, amtGrp, desc, coveragePeriod,associatedDate);
		this.ftEntryIds = ftEntryIds;
		this.setAmountGroup(amtGrp);
	}

	@Override
	public Set<String> ftEntryIds() {
		return this.ftEntryIds;
	}

	@Override
	public String toString() {
		return super.toString() + ", FT entries: " + this.ftEntryIds;
	}

}
