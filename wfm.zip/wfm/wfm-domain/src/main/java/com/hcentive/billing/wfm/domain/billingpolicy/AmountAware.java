package com.hcentive.billing.wfm.domain.billingpolicy;

import com.hcentive.billing.core.commons.vo.Amount;

public interface AmountAware {
	Amount getAmount();
}
