package com.hcentive.billing.wfm.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.hcentive.billing.wfm.domain.bill.invoice.WFMInvoice.Status;

public class LastInvoiceSettledEventDTO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String billingAccountId;
	private String invoiceIdentity;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private Status status;

	public String getBillingAccountId() {
		return billingAccountId;
	}

	public String getInvoiceIdentity() {
		return invoiceIdentity;
	}

	public Status getStatus() {
		return status;
	}

	public void setBillingAccountId(String billingAccountId) {
		this.billingAccountId = billingAccountId;
	}

	public void setInvoiceIdentity(String invoiceIdentity) {
		this.invoiceIdentity = invoiceIdentity;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

}
