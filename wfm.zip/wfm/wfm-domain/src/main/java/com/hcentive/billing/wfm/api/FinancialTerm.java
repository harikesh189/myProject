package com.hcentive.billing.wfm.api;

import java.io.Serializable;

import com.hcentive.billing.core.commons.api.Effectivity;

public interface FinancialTerm<V> extends Effectivity, Serializable {

	String type();

	String code();

	V value();

	String name();

	String description();

}
