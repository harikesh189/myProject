package com.hcentive.billing.wfm.domain.billingpolicy;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.hcentive.billing.wfm.dto.DatesHolder;

/**
 *
 *
 * @author manish.bothiyal
 *
 */
public class BillingScheduleStrategy<BPS extends BufferPeriodStrategy> implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	private BillDueDateStrategy billDueDateStrategy;

	@NotNull
	private BillGenerationDateStrategy billGenerationDateStrategy;
	
	//@NotNull
	private BPS regenBufferPeriodStrategy;
	
	public BillingScheduleStrategy() {

	}

	public BillingScheduleStrategy(final BillDueDateStrategy billDueDateStrategy, final BillGenerationDateStrategy billGenerationDateStrategy) {
		super();
		this.billDueDateStrategy = billDueDateStrategy;
		this.billGenerationDateStrategy = billGenerationDateStrategy;
	}

	public BillingScheduleStrategy(BillDueDateStrategy billDueDateStrategy,
			BillGenerationDateStrategy billGenerationDateStrategy,
			BPS bufferPeriodStrategy) {
		super();
		this.billDueDateStrategy = billDueDateStrategy;
		this.billGenerationDateStrategy = billGenerationDateStrategy;
		this.regenBufferPeriodStrategy = bufferPeriodStrategy;
	}

	public BillDueDateStrategy getBillDueDateStrategy() {
		return this.billDueDateStrategy;
	}

	public BillGenerationDateStrategy getBillGenerationDateStrategy() {
		return this.billGenerationDateStrategy;
	}

	public void setBillDueDateStrategy(final BillDueDateStrategy billDueDateStrategy) {
		this.billDueDateStrategy = billDueDateStrategy;
	}

	public void setBillGenerationDateStrategy(final BillGenerationDateStrategy billGenerationDateStrategy) {
		this.billGenerationDateStrategy = billGenerationDateStrategy;
	}

	public BPS getRegenBufferPeriodStrategy() {
		return regenBufferPeriodStrategy;
	}

	public void setRegenBufferPeriodStrategy(
			BPS regenBufferPeriodStrategy) {
		this.regenBufferPeriodStrategy = regenBufferPeriodStrategy;
	}

}
