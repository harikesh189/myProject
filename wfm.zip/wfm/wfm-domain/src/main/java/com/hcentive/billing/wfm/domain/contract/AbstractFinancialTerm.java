package com.hcentive.billing.wfm.domain.contract;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialTerm;

public abstract class AbstractFinancialTerm<V> implements FinancialTerm<V> {

	private String type;

	private String code;

	private String description;

	private String name;

	private Period effectivePeriod;

	protected AbstractFinancialTerm() {
		// DO NOT delete: required by mongo
	}
	
	public AbstractFinancialTerm(String type, String code, String name,
			Period effectivePeriod, String description) {
		this.type = type;
		this.code = code;
		this.name = name;
		this.effectivePeriod = effectivePeriod;
		this.description = description;
	}

	public String type() {
		return type;
	}

	public String code() {
		return code;
	}

	public String name() {
		return name;
	}

	public String description() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Period effectivePeriod() {
		return effectivePeriod;
	}

	public void setEffectivePeriod(Period effectivePeriod) {
		this.effectivePeriod = effectivePeriod;
	}

	@Override
	public String toString() {
		return "AbstractFinancialTerm [type=" + type + ", code=" + code
				+ ", description=" + description + ", name=" + name
				+ ", effectivePeriod=" + effectivePeriod + "]";
	}

}
