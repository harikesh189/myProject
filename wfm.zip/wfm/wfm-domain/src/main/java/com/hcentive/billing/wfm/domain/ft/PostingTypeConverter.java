/**
 * 
 */
package com.hcentive.billing.wfm.domain.ft;

import javax.persistence.AttributeConverter;

import com.hcentive.billing.wfm.api.enumeration.ft.PostingType;

/**
 * 
 * Coverts {@link PostingType} to either 1 or -1. DR --> -1 , CR --> +1
 * 
 * @author Kumar Sambhav Jain
 * 
 */
public class PostingTypeConverter implements
		AttributeConverter<PostingType, Short> {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.persistence.AttributeConverter#convertToDatabaseColumn(java.lang
	 * .Object)
	 */
	@Override
	public Short convertToDatabaseColumn(PostingType attribute) {
		switch (attribute) {
		case CR:
			return 1;
		case DR:
			return -1;
		default:
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.persistence.AttributeConverter#convertToEntityAttribute(java.lang
	 * .Object)
	 */
	@Override
	public PostingType convertToEntityAttribute(Short dbData) {
		if (dbData == 1) {
			return PostingType.CR;
		} else if (dbData == -1) {
			return PostingType.DR;
		}
		return null;
	}

}
