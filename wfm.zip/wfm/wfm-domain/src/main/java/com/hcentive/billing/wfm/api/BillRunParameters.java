package com.hcentive.billing.wfm.api;

import java.io.Serializable;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigRunOut;

public class BillRunParameters implements Serializable {

	private static final long serialVersionUID = -3752752659006611449L;

	private String billingAccountId;

	private Period billingPeriod;

	private BillingConfigRunOut runOut;

	public String getBillingAccountId() {
		return this.billingAccountId;
	}

	public BillRunParameters(String billingAccountId, Period billingPeriod, BillingConfigRunOut runOut) {
		super();
		this.billingAccountId = billingAccountId;
		this.billingPeriod = billingPeriod;
		this.runOut = runOut;
	}

	public BillRunParameters(final BillingAccount billingAccount) {
		this(billingAccount.getIdentity(), null);
	}

	public BillRunParameters(final String billingAccountId) {
		this(billingAccountId, null);
	}

	public BillRunParameters(final String billingAccountId, final Period billingPeriod) {
		super();
		this.billingAccountId = billingAccountId;
		this.billingPeriod = billingPeriod;
	}

	public void setBillingAccountId(final String billingAccountId) {
		this.billingAccountId = billingAccountId;
	}

	public Period getBillingPeriod() {
		return this.billingPeriod;
	}

	public void setBillingPeriod(final Period billingPeriod) {
		this.billingPeriod = billingPeriod;
	}

	public BillingConfigRunOut getRunOut() {
		return runOut;
	}

	public void setRunOut(BillingConfigRunOut runOut) {
		this.runOut = runOut;
	}

	@Override
	public String toString() {
		return "BillRunParameters [billingAccountId=" + billingAccountId + ", billingPeriod=" + billingPeriod
				+ ", runOut=" + runOut + "]";
	}

}
