package com.hcentive.billing.wfm.api;

import java.util.Collection;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.domain.Period;

public interface FinancialTermAware {

	IOU<Collection<FinancialTerm<?>>, AsyncCallback<Collection<FinancialTerm<?>>>> getFinancialTerms(Period effectivePeriod);

}
