package com.hcentive.billing.wfm.domain.billingpolicy;

import java.util.Date;
import java.util.Map;

import com.hcentive.billing.wfm.api.BillRunType;
import com.hcentive.billing.wfm.dto.DatesHolder;

public interface BufferPeriodEndDateAware {
	
	public Date resolveBufferEndDate(DatesHolder dates, BillRunType runType);

}
