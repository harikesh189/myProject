package com.hcentive.billing.wfm.domain.billing.account;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantDiscriminatorColumn;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.TenantAware;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.wfm.api.AmountCategory;

@Entity
@Table(name = "reinstatement_base_amount_breakup")
@TenantDiscriminatorColumn(name = "tenant_id")
@Multitenant(MultitenantType.SINGLE_TABLE)
public class BaseAmountBreakups extends BaseEntity implements TenantAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3587664975751450435L;

	@Access(AccessType.FIELD)
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "base_period_begins_on")),
	        @AttributeOverride(name = "endsOn.date", column = @Column(name = "base_period_period_ends")) })
	@Embedded
	private Period basePeriod;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "reinstatement_base_period_breakup", joinColumns = @JoinColumn(name = "base_amount_breakup_id"), inverseJoinColumns = @JoinColumn(name = "line_item_id"))
	private List<LapsePeriodAmountBreakup> basePeriodBreakups;
	
	protected BaseAmountBreakups(){}
	public BaseAmountBreakups(Period basePeriod,	Map<AmountCategory,Amount> basePeriodAmountBreakups) {
		super();
		this.basePeriod = basePeriod;
		
		this.basePeriodBreakups = new ArrayList<LapsePeriodAmountBreakup>();
		for(Entry<AmountCategory,Amount> baseAmount : basePeriodAmountBreakups.entrySet())  {
			LapsePeriodAmountBreakup breakUp = new LapsePeriodAmountBreakup(baseAmount.getValue(), baseAmount.getKey(), basePeriod);
			basePeriodBreakups.add(breakUp);
		}
	}
	public Period getBasePeriod() {
		return basePeriod;
	}
	public void setBasePeriod(Period basePeriod) {
		this.basePeriod = basePeriod;
	}
	public List<LapsePeriodAmountBreakup> getBasePeriodBreakups() {
		return Collections.unmodifiableList(this.basePeriodBreakups);
	}
	
	@Override
	public String getTenantId() {
		return ProcessContext.get().getTenantId();
	}
	
	
	

}
