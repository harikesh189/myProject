package com.hcentive.billing.wfm.api.enumeration.ft;


public enum ContractType {
	ELIGIBILITY, THIRD_PPR;
}
