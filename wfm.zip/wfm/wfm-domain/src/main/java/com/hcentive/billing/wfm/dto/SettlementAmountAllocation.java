package com.hcentive.billing.wfm.dto;

import java.io.Serializable;

import com.hcentive.billing.core.commons.vo.Amount;

public class SettlementAmountAllocation implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String ftEntry;
	
	private boolean partialSettlement;
	
	private Amount allocatedAmount;

	private SettlementAmountAllocation(String ftEntry, Amount allocatedAmount, boolean partialSettlement) {
		super();
		this.ftEntry = ftEntry;
		this.allocatedAmount = allocatedAmount;
		this.partialSettlement = partialSettlement;
	}
	
	public SettlementAmountAllocation(){
		
	}

	public String getFtEntry() {
		return ftEntry;
	}

	public Amount getAllocatedAmount() {
		return allocatedAmount;
	}

	public void setAllocatedAmount(Amount allocatedAmount) {
		this.allocatedAmount = allocatedAmount;
	}

	public boolean isPartialSettlement() {
		return partialSettlement;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ftEntry == null) ? 0 : ftEntry.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SettlementAmountAllocation other = (SettlementAmountAllocation) obj;
		if (ftEntry == null) {
			if (other.ftEntry != null)
				return false;
		} else if (!ftEntry.equals(other.ftEntry))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SettlementAmountAllocation [ftEntry=" + ftEntry
				+ ", allocatedAmount=" + allocatedAmount + "]";
	}

	
	public static SettlementAmountAllocation createCompleteSettlementAllocation(String ftEntry) {
		return new SettlementAmountAllocation(ftEntry, null, false);
	}
	
	public static SettlementAmountAllocation createPartialSettlementAllocation(String ftEntryId, Amount allocatedAmount) {
		return new SettlementAmountAllocation(ftEntryId, allocatedAmount, true);
	}
	
}
