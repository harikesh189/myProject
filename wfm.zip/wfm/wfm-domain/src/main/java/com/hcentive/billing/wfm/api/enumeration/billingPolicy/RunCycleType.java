package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

/**
 * It represent the possible types of remittance schedule.
 * 
 * @author nitin.singla
 * 
 */
public enum RunCycleType {
	ANNUALLY, BIWEEKLY, MONTHLY, QUARTERLY, SEMI_ANNUALLY, WEEKLY ,DAILY
}
