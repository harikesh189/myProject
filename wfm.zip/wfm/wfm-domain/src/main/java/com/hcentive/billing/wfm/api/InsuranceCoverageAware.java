package com.hcentive.billing.wfm.api;


public interface InsuranceCoverageAware {

	Long insuranceCoverage();

}
