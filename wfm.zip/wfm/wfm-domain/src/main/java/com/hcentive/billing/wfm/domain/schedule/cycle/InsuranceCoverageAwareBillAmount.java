package com.hcentive.billing.wfm.domain.schedule.cycle;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.InsuranceCoverageAware;

@Entity
@Table(name = "bill_amount")
@DiscriminatorValue("PLAN_AWARE_BILL_AMT")
public class InsuranceCoverageAwareBillAmount extends BillAmount implements
		InsuranceCoverageAware {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "plan_id")
	private Long insuranceCoverageId;

	protected InsuranceCoverageAwareBillAmount() {
	}

	public InsuranceCoverageAwareBillAmount(Long planId,
			String amountCode, String name, AmountCategory type, Amount amount,
			AmountGroup amtGrp, String desc, Period coveragePeriod,DateTime associatedDate) {
		super(amountCode, name, amount, type, amtGrp, desc, coveragePeriod, associatedDate);
		this.insuranceCoverageId = planId;
	}

	@Override
	public Long insuranceCoverage() {
		return insuranceCoverageId;
	}

	public BillAmount makeFTEntryAwareBillAmount(Set<String> ftEntryIds,
			AmountGroup amtGrp,DateTime associatedDate) {
		return new FTEntryPlanAwareBillAmount(getCode(), getName(),
				getAmountCategory(), getAmount(), ftEntryIds,
				insuranceCoverage(), amtGrp, getDescription(), getCoveragePeriod(),associatedDate);
	}

	public String toString() {
		return super.toString() + ", plan: " + insuranceCoverageId;
	}

}
