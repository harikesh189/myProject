package com.hcentive.billing.wfm.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Party;
import com.hcentive.billing.core.commons.domain.Profile;

public class ContractPartyUtil {

	public static <T> T findEntityByTypeInParties(String beType,
			Class<T> expectedType, Set<Party> parties) {
		for (final Party party : parties) {
			final BusinessEntity<Profile> partyEntity = party.getParty();
			if (partyEntity.getType().equals(beType)
					&& expectedType.isInstance(partyEntity)) {
				return expectedType.cast(partyEntity);
			}
		}
		return null;
	}

	public static <T> Collection<T> findEntitiesByTypeInParties(String beType,
			Class<T> expectedType, Set<Party> parties) {
		Collection<T> entities = new ArrayList<>();
		for (final Party party : parties) {
			final BusinessEntity<Profile> partyEntity = party.getParty();
			if (partyEntity.getType().equals(beType)
					&& expectedType.isInstance(partyEntity)) {
				entities.add(expectedType.cast(partyEntity));
			}
		}
		return entities;
	}
}
