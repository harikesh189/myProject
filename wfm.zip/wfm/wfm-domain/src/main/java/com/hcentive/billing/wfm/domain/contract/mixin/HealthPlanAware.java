package com.hcentive.billing.wfm.domain.contract.mixin;

import java.util.Collection;

import com.hcentive.billing.core.commons.domain.HealthPlanProvider;

public interface HealthPlanAware {

	Collection<String> getHealthPlanProducts();

	Collection<HealthPlanProvider> getHealthPlanProviders();
}
