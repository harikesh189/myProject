package com.hcentive.billing.wfm.dto;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.FinancialEventContext;
import com.hcentive.billing.core.commons.domain.mongo.AbstractMongoEntity;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType;

public abstract class AbstractSettlementRecord<T extends AbstractSettlementRecord<T>> 
		extends AbstractMongoEntity implements FinancialEventContext, Cloneable {

	private static final long serialVersionUID = 1L;
	
	private Set<SettlementAmountAllocation> settlementAllocations;
	
	private Set<String> settlementFtEntryIds;
	
	private String settlementFtId;
	
	private boolean settlementComplete;
	
	private Amount settleAmount;
	
	private FinancialEventType eventType;
	
	private String settlementFor; // wfmInvoiceIdentity in case of invoice settlement and partner id in case of remit.
	
	private String settlementForDisplayId;

	private String failureReason;
	
	private double settlementRatio;

	private Amount settledFTAmount;
		
	public Set<SettlementAmountAllocation> getSettlementAllocations() {
		return settlementAllocations;
	}

	public void setSettlementAllocations(Set<SettlementAmountAllocation> ftEntryIds) {
		this.settlementAllocations = ftEntryIds;
	}

	public Set<String> getSettlementFtEntryIds() {
		return settlementFtEntryIds;
	}

	public void setSettlementFtEntryIds(Set<String> settlementFtEntryIds) {
		this.settlementFtEntryIds = settlementFtEntryIds;
	}

	public String getSettlementFtId() {
		return settlementFtId;
	}

	public void setSettlementFtId(String settlementFtId) {
		this.settlementFtId = settlementFtId;
	}

	public boolean isSettlementComplete() {
		return settlementComplete;
	}

	public void setSettlementComplete(boolean settlementComplete) {
		this.settlementComplete = settlementComplete;
	}

	public Amount getSettleAmount() {
		return settleAmount;
	}

	public void setSettleAmount(Amount settleAmount) {
		this.settleAmount = settleAmount;
	}

	public FinancialEventType getEventType() {
		return eventType;
	}

	public void setEventType(FinancialEventType eventType) {
		this.eventType = eventType;
	}

	public String getSettlementFor() {
		return settlementFor;
	}

	public void setSettlementFor(String settlementFor) {
		this.settlementFor = settlementFor;
	}

	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	
	public double getSettlementRatio() {
		return settlementRatio;
	}

	public void setSettlementRatio(double distributionRatio) {
		this.settlementRatio = distributionRatio;
	}

	public String getSettlementForDisplayId() {
		return settlementForDisplayId;
	}

	public void setSettlementForDisplayId(String settlementForDisplayId) {
		this.settlementForDisplayId = settlementForDisplayId;
	}

	public Amount getSettledFTAmount() {
		return settledFTAmount;
	}

	public void setSettledFTAmount(Amount settledFTAmount) {
		this.settledFTAmount = settledFTAmount;
	}

	@Override
	public String toString() {
		return "AbstractSettlementRecord [settlementAllocations="
				+ settlementAllocations + ", settlementFtEntryIds="
				+ settlementFtEntryIds + ", settlementFtId=" + settlementFtId
				+ ", settlementComplete=" + settlementComplete
				+ ", settleAmount=" + settleAmount + ", eventType=" + eventType
				+ ", settlementFor=" + settlementFor
				+ ", settlementForDisplayId=" + settlementForDisplayId
				+ ", failureReason=" + failureReason + ", settlementRatio="
				+ settlementRatio + ", settledFTAmount=" + settledFTAmount
				+ "]";
	}

	public abstract T clone();
	
	public static <T extends AbstractSettlementRecord<T>> void 
			copyValues(AbstractSettlementRecord<T> from, AbstractSettlementRecord<T> to) {
		to.setSettleAmount(from.getSettleAmount());
		to.setSettledFTAmount(from.getSettledFTAmount());
		to.setEventType(from.getEventType());
		to.setFailureReason(from.getFailureReason());
		to.setSettlementAllocations(from.getSettlementAllocations());
		to.setSettlementComplete(from.isSettlementComplete());
		to.setSettlementFor(from.getSettlementFor());
		to.setSettlementForDisplayId(from.getSettlementForDisplayId());
		to.setSettlementFtEntryIds(from.getSettlementFtEntryIds());
		to.setSettlementFtId(from.getSettlementFtId());
		to.setSettlementRatio(from.getSettlementRatio());
	}

}
