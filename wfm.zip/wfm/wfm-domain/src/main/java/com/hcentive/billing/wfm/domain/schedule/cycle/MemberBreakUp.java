package com.hcentive.billing.wfm.domain.schedule.cycle;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;

@Entity
@Table(name = "member_amount_breakup")
public class MemberBreakUp extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "member_id")
	private Long insuredMemberId;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "value", column = @Column(name = "breakup_value")),
	        @AttributeOverride(name = "name", column = @Column(name = "breakup_currency_name")),
	        @AttributeOverride(name = "symbol", column = @Column(name = "breakup_currency_symbol")),
	        @AttributeOverride(name = "shortName", column = @Column(name = "breakup_currency_short_name")) })
	private Amount amount;

	@Embedded
	private Period coveragePeriod;

	protected MemberBreakUp() {
	}

	public MemberBreakUp(Long insuredMemberId, Amount amount, Period coveragePeriod) {
		this.insuredMemberId = insuredMemberId;
		this.amount = amount;
		this.coveragePeriod = coveragePeriod;
	}

	public Long getInsuredMemberId() {
		return insuredMemberId;
	}

	public Amount getAmount() {
		return amount;
	}

	public Period getCoveragePeriod() {
		return coveragePeriod;
	}

	@Override
	public String toString() {
		return "member: " + insuredMemberId + ", amount: " + amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

}