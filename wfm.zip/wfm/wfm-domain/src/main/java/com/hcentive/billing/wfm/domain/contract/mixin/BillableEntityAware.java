package com.hcentive.billing.wfm.domain.contract.mixin;

public interface BillableEntityAware {
	String getBillableEntityId();
}
