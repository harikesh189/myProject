package com.hcentive.billing.wfm.domain.payment;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.FinancialEventContext;
import com.hcentive.billing.core.commons.domain.ItemRecordAwareEntity;
import com.hcentive.billing.core.commons.domain.PaymentMethod;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;


@Entity
@Table(name = "payment_record")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "payment_record_type")
public abstract class AbstractPaymentRecord<R extends ReferenceableDomainEntity<R, V>, V> extends
		ItemRecordAwareEntity<R,V> implements FinancialEventContext {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5338701731124852748L;
	
	public static final String STATUS_INITIATED = "PAYMENT_REQUEST_INITIATED";
	public static final String STATUS_FAILED = "PAYMENT_REQUEST_FAILED";
	public static final String STATUS_SUCCESS = "PAYMENT_REQUEST_SUCCESSFULL";
	public static final String STATUS_UNKNOWN = "PAYMENT_REQUEST_UNKNOWN";
	public static final String STATUS_UNKNOWN_PENDING = "PAYMENT_REQUEST_UNKNOWN_PENDING";
	
	public static final String STATUS_REFUND_INITIATED ="STATUS_REFUND_INITIATED";
	public static final String STATUS_REFUND_FAILED ="STATUS_REFUND_INITIATED";
	public static final String STATUS_REFUND_SUCCESS ="STATUS_REFUND_INITIATED";

	public static final String STATUS_PENDING = "PAYMENT_REQUEST_PENDING";
	
	@SuppressWarnings("rawtypes")
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "payer_id")
	private BusinessEntity payer;

	@SuppressWarnings("rawtypes")
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "payee_id")
	private BusinessEntity payee;

	@Embedded
	@AttributeOverrides({
			@AttributeOverride(name = "value", column = @Column(name = "paid_value")),
			@AttributeOverride(name = "name", column = @Column(name = "paid_name")),
			@AttributeOverride(name = "symbol", column = @Column(name = "paid_symbol")),
			@AttributeOverride(name = "shortName", column = @Column(name = "paid_short_name")) })
	private Amount amountPaid;

	@Access(AccessType.FIELD)
	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "txn_date")) })
	private DateTime txnDate;
	

	@OneToOne(targetEntity = PaymentMethod.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "payment_instrument_id")
	@Access(AccessType.FIELD)
	private PaymentMethod paymentInstrument;
	
	@Column(name = "status")
	private String status;
	
	public AbstractPaymentRecord(String identity) {
		super(identity);
	}

	public AbstractPaymentRecord() {
		super();
	}

	public AbstractPaymentRecord(String identity, String externalId) {
		super(identity, externalId);
	}

	public BusinessEntity getPayer() {
		return payer;
	}

	public void setPayer(BusinessEntity payer) {
		this.payer = payer;
	}

	public Amount getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(Amount amountPaid) {
		this.amountPaid = amountPaid;
	}

	public DateTime getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(DateTime txnDate) {
		this.txnDate = txnDate;
	}

	public PaymentMethod getPaymentInstrument() {
		return paymentInstrument;
	}

	public void setPaymentInstrument(PaymentMethod paymentInstrument) {
		this.paymentInstrument = paymentInstrument;
	}

	public BusinessEntity getPayee() {
		return payee;
	}

	public void setPayee(BusinessEntity payee) {
		this.payee = payee;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public void failed() {
		this.setStatus(STATUS_FAILED);
	}
	public void sucessful() {
		this.setStatus(STATUS_SUCCESS);
	}
	public void unknown() {
		this.setStatus(STATUS_UNKNOWN);
	}
	
	public void unknownPending() {
		this.setStatus(STATUS_UNKNOWN_PENDING);
	}

	public boolean isSuccess() {
		return STATUS_SUCCESS.equals(this.getStatus());
	}
	public boolean isUnknown() {
		return STATUS_UNKNOWN.equals(this.getStatus());
	}
	

}
