package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.domain.BaseEntity;
import com.hcentive.billing.wfm.api.enumeration.BillingAccountAssociationType;

@Entity
@Table(name = "billing_account_association")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "association_type")
public class BillingAccountAssociation extends BaseEntity {

	private static final long serialVersionUID = 2649346580970432281L;

	@ManyToOne
	@JoinColumn(name = "billing_account_id")
	private BillingAccount billingAccount;

	@Enumerated(EnumType.STRING)
	@Column(name = "association_name")
	private BillingAccountAssociationType associationName;

	protected BillingAccountAssociation() {
	}

	public BillingAccountAssociationType getAssociationName() {
		return this.associationName;
	}

	public void setAssociationName(final BillingAccountAssociationType associationName) {
		this.associationName = associationName;
	}

	public BillingAccount getBillingAccount() {
		return this.billingAccount;
	}

	public void setBillingAccount(final BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}

}
