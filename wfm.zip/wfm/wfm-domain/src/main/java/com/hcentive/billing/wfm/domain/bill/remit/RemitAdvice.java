package com.hcentive.billing.wfm.domain.bill.remit;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.hcentive.billing.wfm.domain.bill.BillArtifact;

@Entity
@Table(name = "remit_advice")
public class RemitAdvice extends BillArtifact<RemitAdviceSummary> {

	private static final long serialVersionUID = -8821652324687518605L;

	protected RemitAdvice() {
	}

	public RemitAdvice(RemitAdviceSummary summary) {
		super(summary);
	}

	public RemitAdviceSummary getSummary() {
		return super.getSummary();
	}

	@Override
	public String typeName() {
		return "RemitAdvice";
	}

	@Override
	public String refValue() {
		return getIdentity();
	}

}
