package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum FeeClass {
	PMPM, LATE_FEE,NSF,REINSURANCE_FEE,REINSTATEMENT
}
