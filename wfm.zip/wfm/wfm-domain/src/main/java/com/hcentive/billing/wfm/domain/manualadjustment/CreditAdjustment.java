package com.hcentive.billing.wfm.domain.manualadjustment;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * Class to represent Credit Adjustment.
 * 
 * @author ajay.saxena
 *
 */
@Entity
@Table(name = "manual_adjustment")
@DiscriminatorValue("Credit")
public class CreditAdjustment extends ManualAdjustment{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8313242712603463399L;

	@Override
	public String typeName() {
		// TODO Auto-generated method stub
		return "Discount";
	}

}
