package com.hcentive.billing.wfm.dto;

import java.io.Serializable;

public class LiablityTransfer implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String sourceSubscriptionIdentity;
	private String targetSubscriptionIdentity;

	public LiablityTransfer() {
	}

	/**
	 * @param sourceSubscriptionIdentity
	 * @param targetSubscriptionIdentity
	 */
	public LiablityTransfer(String sourceSubscriptionIdentity, String targetSubscriptionIdentity) {
		super();
		this.sourceSubscriptionIdentity = sourceSubscriptionIdentity;
		this.targetSubscriptionIdentity = targetSubscriptionIdentity;
	}

	/**
	 * @return the sourceSubscriptionIdentity
	 */
	public String getSourceSubscriptionIdentity() {
		return sourceSubscriptionIdentity;
	}

	/**
	 * @param sourceSubscriptionIdentity
	 *            the sourceSubscriptionIdentity to set
	 */
	public void setSourceSubscriptionIdentity(String sourceSubscriptionIdentity) {
		this.sourceSubscriptionIdentity = sourceSubscriptionIdentity;
	}

	/**
	 * @return the targetSubscriptionIdentity
	 */
	public String getTargetSubscriptionIdentity() {
		return targetSubscriptionIdentity;
	}

	/**
	 * @param targetSubscriptionIdentity
	 *            the targetSubscriptionIdentity to set
	 */
	public void setTargetSubscriptionIdentity(String targetSubscriptionIdentity) {
		this.targetSubscriptionIdentity = targetSubscriptionIdentity;
	}

}
