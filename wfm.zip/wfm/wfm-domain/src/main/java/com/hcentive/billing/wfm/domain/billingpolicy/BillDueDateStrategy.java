package com.hcentive.billing.wfm.domain.billingpolicy;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.BillingDueDateStrategyType;

/**
 * It represent the strategy to be used to calculate the bill due date.
 * 
 * @author nitin.singla
 * 
 */
public class BillDueDateStrategy implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	private BillingDueDateStrategyType dueDateStrategyType;

	private int marginDays;
	
	private int monthVariance;
	
	private int dayOfMonth;
	
	public BillDueDateStrategy() {

	}

	public BillDueDateStrategy(
			final BillingDueDateStrategyType dueDateStrategyType,
			final int marginDays) {
		this.dueDateStrategyType = dueDateStrategyType;
		this.marginDays = marginDays;
	}

	/**
	 * Gets the type of strategy to use to calculate the bill due date.
	 * 
	 * @return The type of strategy to use to calculate the bill due date.
	 */
	public BillingDueDateStrategyType getDueDateStrategyType() {
		return this.dueDateStrategyType;
	}

	/**
	 * Gets the offset value in terms of number of days to calculate the billing
	 * due date.
	 * 
	 * @return The offset value in terms of number of days to calculate the
	 *         billing due date.
	 */
	public int getMarginDays() {
		return this.marginDays;
	}

	/**
	 * Sets the type of strategy to use to calculate the bill due date.
	 * 
	 * @param dueDateStrategyType
	 *            The type of strategy to use to calculate the bill due date.
	 */
	public void setDueDateStrategyType(
			final BillingDueDateStrategyType dueDateStrategyType) {
		this.dueDateStrategyType = dueDateStrategyType;
	}

	/**
	 * Sets the offset value in terms of number of days to calculate the billing
	 * due date.
	 * 
	 * @param marginDays
	 *            The offset value in terms of number of days to calculate the
	 *            billing due date.
	 */
	public void setMarginDays(final int marginDays) {
		this.marginDays = marginDays;
	}

	public int getMonthVariant() {
		return monthVariance;
	}

	public void setMonthVariant(int monthVariant) {
		this.monthVariance = monthVariant;
	}

	public int getDayOfMonth() {
		return dayOfMonth;
	}

	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}
	
}
