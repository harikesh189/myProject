package com.hcentive.billing.wfm.domain.contract;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

import com.hcentive.billing.core.commons.domain.BenefitVendor;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.wfm.domain.contract.mixin.BenefitVendorAware;


@Entity
@DiscriminatorValue("BENEFIT_COVERAGE")
public class BenefitCoverage extends EligibilityCoverage implements BenefitVendorAware{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8763082352099930836L;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval=true)
	@Access(AccessType.FIELD)
	@JoinTable(name = "benefit_member_coverages",
			joinColumns = @JoinColumn(name = "benefit_id"),
			inverseJoinColumns = @JoinColumn(name = "benefit_member_coverages_id"))
	private final Set<BenefitMemberCoverage> benefitCoverages = new HashSet<BenefitMemberCoverage>();
	
	public BenefitCoverage() {
	}
	
	public BenefitCoverage(final BenefitPlan plan) {
		super(plan);
	}

	
	public BenefitPlan getHealthPlan(){
		return (BenefitPlan) this.healthPlan;
	}

	public Set<BenefitMemberCoverage> getBenefitCoverages() {
		return benefitCoverages;
	}
	
	public void addMemberCoverage(final BenefitMemberCoverage memberCoverage) {
		this.benefitCoverages.add(memberCoverage);
		if (this.getTotalCoverage() == null) {
			this.setTotalCoverage(new Period());
		}
		this.getTotalCoverage().populateWithUnion(memberCoverage.getCoverage());
	}

	@Override
	public Collection<BenefitVendor> getBenefitVendors() {
		if (getHealthPlan().getCarrier() instanceof BenefitVendor) {
			return CollectionUtil.asList((BenefitVendor) this.getHealthPlan().getCarrier());
		}
		return Collections.EMPTY_LIST;
	}

	@Override
	public Collection<String> getBenefitProducts() {
		final Collection<String> result = new LinkedList<>();
		final String productType = this.getHealthPlan().getProductType();
		if (productType != null) {
			result.add(productType);
		}
		return result;
	}

}
