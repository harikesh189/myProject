package com.hcentive.billing.wfm.api.enumeration.ft;

public enum GLEntryCategory {
	ADJUSTMENT, CHARGE, LIABILITY, PAYOFF, REVENUE, SUBSIDY, REMIT, WRITEOFF, PAYMENT_REVERSAL,REFUND_PAYOUT,TRANSFER
}
