package com.hcentive.billing.wfm.domain.contract;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "eligibility_factor")
@DiscriminatorValue("WorkIndustry")
public class WorkIndustryFactor extends EligibilityFactor {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1089947328804435053L;

	@Access(AccessType.FIELD)
	@Column(name = "naic")
	private String naic; // North America Industry Class

	@Access(AccessType.FIELD)
	@Column(name = "sic")
	private String sic; // standard industry class

	public String getNaic() {
		return naic;
	}

	public void setNaic(String naic) {
		this.naic = naic;
	}

	public String getSic() {
		return sic;
	}

	public void setSic(String sic) {
		this.sic = sic;
	}

}
