package com.hcentive.billing.wfm.domain.billing.account;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcentive.billing.core.commons.constant.BillingConstant;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.Profile;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.domain.enumtype.BillingAccountType;
import com.hcentive.billing.wfm.api.enumeration.SubscriptionStatus;

@Entity
@Table(name = "billing_account")
@SuppressWarnings("rawtypes")
public class BillingAccount extends ReferenceableDomainEntity<BillingAccount, String> {

	private static final long serialVersionUID = 4567949335170372900L;

	@Enumerated(EnumType.STRING)
	@Column(name = "account_type")
	private BillingAccountType accountType;

	// Spring fails to create repository with findByBusinessEntityIdentity
	// method
	// if we add <Profile> to BusinessEntity. Hence keeping it raw.
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "owner_business_entity_id")
	private BusinessEntity owner;

	@Column(name = "subscription_status")
	@Enumerated(EnumType.STRING)
	private SubscriptionStatus subscriptionstatus;
	
	@Column(name= "billing")
	private boolean billing;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "beginsOn.date", column = @Column(name = "begins_on")),
		@AttributeOverride(name = "endsOn.date", column = @Column(name = "ends_on")) })
	@Access(AccessType.FIELD)
	private Period billingAccountPeriod;

	/*
	 * @OneToMany(mappedBy = "billingAccount",fetch=FetchType.EAGER)
	 *
	 * @JsonIgnore private List<ReinstatementInfo> reinstatementInfos;
	 */

	public BillingAccount(final BusinessEntity<Profile> owner) {
		this.owner = owner;
		this.billing = true;
	}

	protected BillingAccount() {
		this.billing = true;
	}

	public BillingAccountType getAccountType() {
		return this.accountType;
	}

	/**
	 * @return the billingAccountPeriod
	 */
	public Period getBillingAccountPeriod() {
		return this.billingAccountPeriod == null ? new Period() : this.billingAccountPeriod;
	}

	/*
	 * @Override
	 *
	 * @JsonIgnore public ReinstatementInfo getReinstatementInfo() { final
	 * List<ReinstatementInfo> allReinstateInfos =
	 * nullSafe(this.reinstatementInfos); for (final ReinstatementInfo temp :
	 * allReinstateInfos) { if (ReinstatementStatus.IN_PROCESS ==
	 * temp.getReinstatementStatus()) { return temp; } } return null; }
	 */

	/*
	 * @Override
	 *
	 * @JsonIgnore public boolean isInReinstatementWindow() { return
	 * getReinstatementInfo() != null; }
	 */

	public BusinessEntity getOwner() {
		return this.owner;
	}

	public SubscriptionStatus getSubscriptionstatus() {
		return this.subscriptionstatus;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public void setAccountType(final BillingAccountType accountType) {
		this.accountType = accountType;
	}

	/**
	 * @param billingAccountPeriod
	 *            the billingAccountPeriod to set
	 */
	public void setBillingAccountPeriod(final Period billingAccountPeriod) {
		this.billingAccountPeriod = billingAccountPeriod;
	}

	public void setOwner(final BusinessEntity owner) {
		this.owner = owner;
	}

	public void setSubscriptionstatus(final SubscriptionStatus subscriptionstate) {
		this.subscriptionstatus = subscriptionstate;
	}

	@Override
	public String typeName() {
		return BillingConstant.BillingAccount;
	}

	public boolean isBilling() {
		return billing;
	}

	public void setBilling(boolean billing) {
		this.billing = billing;
	}
	
	

}
