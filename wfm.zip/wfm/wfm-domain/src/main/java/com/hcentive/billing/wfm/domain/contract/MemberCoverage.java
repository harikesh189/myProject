package com.hcentive.billing.wfm.domain.contract;

public class MemberCoverage {

}
