package com.hcentive.billing.wfm.api;

import com.hcentive.billing.wfm.domain.billing.account.ReinstatementInfo;

public interface Reinstatable {

	ReinstatementInfo getReinstatementInfo();

	boolean isInReinstatementWindow();

}
