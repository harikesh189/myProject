package com.hcentive.billing.wfm.api.enumeration.ft;

public enum FTEntryAssociationType {
	R_LINE, L_LINE
}
