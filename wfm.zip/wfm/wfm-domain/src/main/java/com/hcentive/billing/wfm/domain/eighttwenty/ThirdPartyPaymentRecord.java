package com.hcentive.billing.wfm.domain.eighttwenty;

import java.util.Collections;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

import com.hcentive.billing.wfm.domain.contract.RemitCoverage;
import com.hcentive.billing.wfm.domain.payment.AbstractPaymentRecord;

/**
 * @author ajay.saxena
 * 
 *         This domain represents 820 contract
 * 
 */
@Entity
public abstract class ThirdPartyPaymentRecord extends AbstractPaymentRecord<ThirdPartyPaymentRecord, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4120191987617756456L;

	public ThirdPartyPaymentRecord() {
		super();
	}
	
	public ThirdPartyPaymentRecord(String identity) {
		super(identity);
	}
	
	public ThirdPartyPaymentRecord(String identity, String externalId) {
		super(identity, externalId);
	}

	@Access(AccessType.FIELD)
	@Column(name = "txn_handling_code")
	private String txnHandlingCode;

	@Access(AccessType.FIELD)
	private Boolean credit;
	
	@Access(AccessType.FIELD)
	@Column(name = "is_eighttwenty_generated")
	private boolean isEightTwentyGenerated;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Access(AccessType.FIELD)
	@PrimaryKeyJoinColumn
	@JoinTable(name = "third_party_payment_remit_coverage", joinColumns = @JoinColumn(name = "third_party_payment_id"), inverseJoinColumns = @JoinColumn(name = "remit_coverage_id"))
	private Set<RemitCoverage> remits;

	public Set<RemitCoverage> getRemits() {
		if (null == this.remits)
			return Collections.EMPTY_SET;
		return Collections.unmodifiableSet(remits);
	}

	public void setRemits(Set<RemitCoverage> remits) {
		this.remits = remits;
	}


	@Override
	public String refValue() {
		return this.identity;
	}

	public String getTxnHandlingCode() {
		return txnHandlingCode;
	}

	public void setTxnHandlingCode(String txnHandlingCode) {
		this.txnHandlingCode = txnHandlingCode;
	}

	public Boolean getCredit() {
		return credit;
	}

	public void setCredit(Boolean credit) {
		this.credit = credit;
	}

	public boolean isEightTwentyGenerated() {
		return isEightTwentyGenerated;
	}

	public void setEightTwentyGenerated(boolean isEightTwentyGenerated) {
		this.isEightTwentyGenerated = isEightTwentyGenerated;
	}

}
