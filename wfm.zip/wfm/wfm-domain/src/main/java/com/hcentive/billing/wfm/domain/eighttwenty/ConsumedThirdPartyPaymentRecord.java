package com.hcentive.billing.wfm.domain.eighttwenty;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("Consumed_Third_Party_Payment_Record")
public class ConsumedThirdPartyPaymentRecord extends ThirdPartyPaymentRecord {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7878052493959680335L;

	public ConsumedThirdPartyPaymentRecord(String identity, String externalId) {
		super(identity, externalId);
		setStatus(STATUS_SUCCESS);
	}

	public ConsumedThirdPartyPaymentRecord() {
		super();
		setStatus(STATUS_SUCCESS);
	}

	@Override
	public String typeName() {
		return "Consumed_Third_Party_Record";
	}

}
