package com.hcentive.billing.wfm.domain.contract.mixin;

import com.hcentive.billing.core.commons.vo.Amount;


public interface TotalAmountDueAware {

	Amount getTotalAmountDue();
}
