package com.hcentive.billing.wfm.domain.payment;

import com.hcentive.billing.core.commons.vo.DateTime;

public class PaymentRemovalDetail extends AmountRemovalDetail {

	private static final long serialVersionUID = -9203472717776374672L;

	private String paymentIdentity;
	
	private String paymentExternalId;
	
	private DateTime paymentDate;
	
	@SuppressWarnings("unused")
	private PaymentRemovalDetail() {
		super();
		// For ORMs
	}
	
	public PaymentRemovalDetail(RemovalReason reason) {
		super(reason);
	}

	public String getPaymentIdentity() {
		return paymentIdentity;
	}

	public void setPaymentIdentity(String paymentIdentity) {
		this.paymentIdentity = paymentIdentity;
	}

	public String getPaymentExternalId() {
		return paymentExternalId;
	}

	public void setPaymentExternalId(String paymentExternalId) {
		this.paymentExternalId = paymentExternalId;
	}

	public DateTime getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(DateTime paymentDate) {
		this.paymentDate = paymentDate;
	}

	@Override
	public String toString() {
		return "PaymentRemovalDetail [paymentIdentity=" + paymentIdentity
				+ ", paymentExternalId=" + paymentExternalId + ", reason="
				+ reason + "]";
	}
}
