package com.hcentive.billing.wfm.domain.ft;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hcentive.billing.core.commons.domain.ReferenceableDomainEntity;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.ft.FTEntryAssociationType;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventQualifier;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;

@Entity
@Table(name = "financial_trxn")
@JsonIgnoreProperties(ignoreUnknown = true)
public class FinancialTransaction extends
		ReferenceableDomainEntity<FinancialTransaction, String> {

	/**
	 * Logger
	 */
	private static final Logger log = LoggerFactory
			.getLogger(FinancialTransaction.class);

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "financialTransaction")
	private final Set<FinancialTrxnEntry> ftEntries = new HashSet<>();

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "date", column = @Column(name = "event_date")) })
	private DateTime eventDate;

	@Column(name = "event_id")
	private String eventId;
	
	/*
	 * This id will contain additional id of the event as per the table below:
	 * Billing Run 		:	Billing Run Cycle -> External Id
	 * Payment			: 	Payment Record -> External
	 */
	@Column(name = "event_additional_id")
	private String eventAdditionalId;

	@Enumerated(EnumType.STRING)
	@Column(name = "event_type")
	private FinancialEventType eventType;

	@Enumerated(EnumType.STRING)
	@Column(name = "event_qualifier")
	private FinancialEventQualifier eventQualifier = FinancialEventQualifier.DEFAULT;

	@Column(name = "ft_rule_identity")
	private String ftRuleIdentity;
	
	@Column(name = "ft_rule_external_id")
	private String ftRuleExternalId;
	
	@Column(name = "reversed_from_ft_identity")
	private String reversedFromFtIdentity;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "event_data_ref_id")
	@Access(AccessType.FIELD)
	private EventDataRef eventDataRef;
	
	protected FinancialTransaction() {
	}

	public FinancialTransaction(final String identity) {
		super(identity);
		this.eventDate = new DateTime(Calendar.getInstance().getTime());
	}

	public void addFTEntries(final Collection<FinancialTrxnEntry> ftEntries) {
		if (isNotEmpty(ftEntries)) {
			for (final FinancialTrxnEntry ftEntry : ftEntries) {
				this.addFTEntry(ftEntry);
			}
		}
	}

	public void addFTEntry(final FinancialTrxnEntry ftEntry) {
		ftEntry.setFinancialTransaction(this);
		this.ftEntries.add(ftEntry);
	}

	@JsonIgnore
	public Collection<FinancialTrxnEntry> getEntries() {
		return this.ftEntries;
	}

	public DateTime getEventDate() {
		return this.eventDate;
	}

	public String getEventId() {
		return this.eventId;
	}

	public FinancialEventType getEventType() {
		return this.eventType;
	}

	public Set<FinancialTrxnEntry> getFtEntries() {
		return this.ftEntries;
	}

	@Override
	public String refValue() {
		return this.identity;
	}

	public FinancialTransaction reverse(FinancialEventQualifier eventQualifier,
			String eventId, String eventAdditionalId, DateTime eventDateTime, 
			FinancialEventType eventType, boolean reverseRLine, Map<String, BillingAccount> swapBAs) {
		final FinancialTransaction reversedResult = new FinancialTransaction(
				RandomGenerator.randomString());
		reversedResult.setEventDate(eventDateTime);
		reversedResult.setEventId(eventId);
		reversedResult.setEventAdditionalId(eventAdditionalId);
		reversedResult.setEventType(eventType);
		reversedResult.setEventQualifier(eventQualifier);
		reversedResult.setOperator(this.getOperator());
		reversedResult.setEventDataRef(this.eventDataRef);

		final Map<String, FinancialTrxnEntry> reversedAndNewFTEntryMap = new HashMap<>();
		for (final FinancialTrxnEntry toBeReversedFTEntry : this.getFtEntries()) {
			final Set<FinancialTrxnEntry> reversedFTEntries = toBeReversedFTEntry
					.reverse(reverseRLine, eventQualifier, swapBAs);
			if (!reversedFTEntries.isEmpty()) {
				reversedAndNewFTEntryMap.put(toBeReversedFTEntry.getIdentity(), 
						(new ArrayList<>(reversedFTEntries)).get(0));
			}
			reversedResult.addFTEntries(reversedFTEntries);
		}

		log.debug("\n\nReversed Transaction result is {}", reversedResult);
		
		log.debug("\nCreate FT entry associations similar to old FT.");
		createFTEntryAssociation(reversedResult, reversedAndNewFTEntryMap);
		
		if (isNotEmpty(reversedResult.getFtEntries())) {
			reversedResult.setReversedFromFtIdentity(this.getIdentity());
			return reversedResult;
		}

		return null;
	}
	
	private void createFTEntryAssociation(FinancialTransaction newFT, Map<String, FinancialTrxnEntry> reversedAndNewFTEntryMap) {
		log.debug("\n Mapping of old And New FT Entries are {}", reversedAndNewFTEntryMap);
		FinancialTrxnEntry parentFTEntry;
		FinancialTrxnEntry associatedFTEntry;
		for (final FinancialTrxnEntry ftEntry : this.getFtEntries()) {
			if (ftEntry.getAssociations() != null) {
				for (final FTEntryAssociation assoc : ftEntry.getAssociations()) {
					if (assoc.getAssocType() == FTEntryAssociationType.L_LINE) {
						parentFTEntry = reversedAndNewFTEntryMap.get(ftEntry.getIdentity());
						associatedFTEntry = reversedAndNewFTEntryMap.get(assoc.getAssociatedFTEntry().getIdentity());
						
						if(parentFTEntry != null && associatedFTEntry != null) {
							parentFTEntry.addAssocByType(associatedFTEntry, assoc.getAssocType());
						} else {
							log.debug("\n New FT entries not found to form association for FT entry [{}], associated FT Entry [{}].", 
									ftEntry.getIdentity(), assoc.getAssociatedFTEntry().getIdentity());
						}
					}
				}
			} else {
				log.debug("\n No FT entry association exists for FT entry [{}].", ftEntry.getIdentity());
			}
		}
	}

	public void setEventDate(final DateTime eventDate) {
		this.eventDate = eventDate;
	}

	public void setEventId(final String eventId) {
		this.eventId = eventId;
	}

	public void setEventType(final FinancialEventType eventType) {
		this.eventType = eventType;
	}

	public FinancialEventQualifier getEventQualifier() {
		return eventQualifier;
	}

	public void setEventQualifier(FinancialEventQualifier eventQualifier) {
		this.eventQualifier = eventQualifier;
	}

	public String getFtRuleIdentity() {
		return ftRuleIdentity;
	}

	public void setFtRuleIdentity(String ftRuleIdentity) {
		this.ftRuleIdentity = ftRuleIdentity;
	}

	@Override
	public String typeName() {
		return "FinancialTransaction";
	}

	public String getReversedFromFtIdentity() {
		return reversedFromFtIdentity;
	}

	public void setReversedFromFtIdentity(String reversedFromFtIdentity) {
		this.reversedFromFtIdentity = reversedFromFtIdentity;
	}

	public String getEventAdditionalId() {
		return eventAdditionalId;
	}

	public void setEventAdditionalId(String eventAdditionalId) {
		this.eventAdditionalId = eventAdditionalId;
	}

	public String getFtRuleExternalId() {
		return ftRuleExternalId;
	}

	public void setFtRuleExternalId(String ftRuleExternalId) {
		this.ftRuleExternalId = ftRuleExternalId;
	}
	
	public EventDataRef getEventDataRef() {
		return eventDataRef;
	}

	public void setEventDataRef(EventDataRef eventDataRef) {
		this.eventDataRef = eventDataRef;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("FinancialTransaction [identity=");
		builder.append(this.identity);
		builder.append(", externalId=");
		builder.append(this.externalId);
		builder.append(", ftEntries=");
		builder.append(this.ftEntries);
		builder.append(", eventDate=");
		builder.append(this.eventDate);
		builder.append(", eventId=");
		builder.append(this.eventId);
		builder.append(", eventType=");
		builder.append(this.eventType);
		builder.append(", ftRuleIdentity=");
		builder.append(this.ftRuleIdentity);
		builder.append(", reversedFromFtIdentity=");
		builder.append(this.reversedFromFtIdentity);
		builder.append("]");
		return builder.toString();
	}

}
