package com.hcentive.billing.wfm.api.enumeration.billingPolicy;

public enum BillingConfigProductType {
	DENTAL, MEDICAL, VISION;
}
