package com.hcentive.billing.wfm.services.bill.artifact.generation.vo;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.ft.AccountType;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventQualifier;
import com.hcentive.billing.wfm.api.enumeration.ft.GLEntryCategory;
import com.hcentive.billing.wfm.api.enumeration.ft.PostingType;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier.Type;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;

public class FTEntryDTO {

	private Long insuranceCoverageId;
	
	private AmountCategory amountCategory;
	
	private String amountCode;
	
	private String amountName;
	
	private Period coveragePeriod;
	
	private String ftEntryIdentity;
	
	private String description;
	
	private String planExternalId;
	
	private String contractId;
	
	private FinancialEventQualifier financialEventQualifier;
	
	private GLAccountQualifier.Type glAccountQualifierType;
	
	private AccountType glAccountType;
	
	private GLEntryCategory glEntryCategory;
	
	private PostingType postingType;
	
	private Amount amount;
	
	private String referenceBillAmountIdentity;
	
	private BillAmount referenceBillAmount;
	
	private DateTime eventDate;

	public DateTime getEventDate() {
		return eventDate;
	}

	public void setEventDate(DateTime eventDate) {
		this.eventDate = eventDate;
	}

	protected FTEntryDTO() { }
	
	public FTEntryDTO(Long insuranceCoverageId, AmountCategory amountCategory,
			String amountCode, String amountName, Period coveragePeriod,
			String ftEntryIdentity, String description, String planExternalId,
			String contractId, String financialEventQualifier,
			Type glAccountQualifierType, AccountType glAccountType,
			GLEntryCategory glEntryCategory, PostingType postingType,
			Amount amount, String referenceBillAmountIdentity, DateTime eventDate) {
		super();
		this.insuranceCoverageId = insuranceCoverageId;
		this.amountCategory = amountCategory;
		this.amountCode = amountCode;
		this.amountName = amountName;
		this.coveragePeriod = coveragePeriod;
		this.ftEntryIdentity = ftEntryIdentity;
		this.description = description;
		this.planExternalId = planExternalId;
		this.contractId = contractId;
		this.financialEventQualifier = 
				financialEventQualifier == null || financialEventQualifier.isEmpty() 
					? FinancialEventQualifier.DEFAULT 
					: FinancialEventQualifier.valueOf(financialEventQualifier);
		this.glAccountQualifierType = glAccountQualifierType;
		this.glAccountType = glAccountType;
		this.glEntryCategory = glEntryCategory;
		this.postingType = postingType;
		this.amount = amount;
		this.referenceBillAmountIdentity = referenceBillAmountIdentity;
		this.eventDate = eventDate;
	}
	
	public Long getInsuranceCoverageId() {
		return insuranceCoverageId;
	}

	public void setInsuranceCoverageId(Long insuranceCoverageId) {
		this.insuranceCoverageId = insuranceCoverageId;
	}

	public AmountCategory getAmountCategory() {
		return amountCategory;
	}

	public void setAmountCategory(AmountCategory amountCategory) {
		this.amountCategory = amountCategory;
	}

	public String getAmountCode() {
		return amountCode;
	}

	public void setAmountCode(String amountCode) {
		this.amountCode = amountCode;
	}

	public String getAmountName() {
		return amountName;
	}

	public void setAmountName(String amountName) {
		this.amountName = amountName;
	}

	public Period getCoveragePeriod() {
		return coveragePeriod;
	}

	public void setCoveragePeriod(Period coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}

	public String getFtEntryIdentity() {
		return ftEntryIdentity;
	}

	public void setFtEntryIdentity(String ftEntryIdentity) {
		this.ftEntryIdentity = ftEntryIdentity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String desc) {
		this.description = desc;
	}

	public String getPlanExternalId() {
		return planExternalId;
	}

	public void setPlanExternalId(String planExternalId) {
		this.planExternalId = planExternalId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public void setFinancialEventQualifier(FinancialEventQualifier financialEventQualifier) {
		this.financialEventQualifier = financialEventQualifier;
	}

	public FinancialEventQualifier getFinancialEventQualifier() {
		return financialEventQualifier;
	}

	public GLAccountQualifier.Type getGlAccountQualifierType() {
		return glAccountQualifierType;
	}

	public void setGlAccountQualifierType(GLAccountQualifier.Type glAccountType) {
		this.glAccountQualifierType = glAccountType;
	}

	public GLEntryCategory getGlEntryCategory() {
		return glEntryCategory;
	}

	public void setGlEntryCategory(GLEntryCategory glEntryCategory) {
		this.glEntryCategory = glEntryCategory;
	}

	public AccountType getGlAccountType() {
		return glAccountType;
	}

	public void setGlAccountType(AccountType glAccountType) {
		this.glAccountType = glAccountType;
	}

	public PostingType getPostingType() {
		return postingType;
	}

	public void setPostingType(PostingType postingType) {
		this.postingType = postingType;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public String getReferenceBillAmountIdentity() {
		return referenceBillAmountIdentity;
	}

	public void setReferenceBillAmountIdentity(String referenceBillAmountId) {
		this.referenceBillAmountIdentity = referenceBillAmountId;
	}

	public void setReferenceBillAmount(BillAmount referenceBillAmount) {
		this.referenceBillAmount = referenceBillAmount;
	}

	public BillAmount getReferenceBillAmount() {
		return referenceBillAmount;
	}
	
}
