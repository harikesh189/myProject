package com.hcentive.billing.wfm.services.bill.artifact.generation.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;


public interface BillAmountRepository extends JpaRepository<BillAmount, Long> {

	BillAmount findByIdentity(String identity);
	
	@Query("select b from BillAmount b where b.identity IN ?1")
	List<BillAmount> findByIdentityIn(Collection<String> identities);
	
}
