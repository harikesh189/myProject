package com.hcentive.billing.wfm.services.bill.artifact.generation.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.bill.BillArtifact;
import com.hcentive.billing.wfm.domain.bill.BillArtifactSummary;
import com.hcentive.billing.wfm.domain.bill.BillingAccountSummary;

public class AbstractNetDueAmountBuilder {

	private static final Logger logger = LoggerFactory
			.getLogger(AbstractNetDueAmountBuilder.class);

	public AbstractNetDueAmountBuilder() {
		super();
	}

	/**
	 * @param billCtx
	 */
	protected void buildNetDueAmount(BillArtifact<?> billArtifact) {

		final BillArtifactSummary summary = billArtifact.getSummary();
		final BillingAccountSummary billingAccountSummary = billArtifact
				.getBillingAccountSummary();

		if (null != summary && null != billingAccountSummary
				&& summary.getCurrentBillAmount() != null) {

			logger.debug(
					"calculating net due - current amt: {}, net outstanding: {}",
					summary.getCurrentBillAmount(),
					billingAccountSummary.getNetOutstandingAmount());

			summary.setNetDueAmount(add(summary.getCurrentBillAmount(),
					billingAccountSummary.getNetOutstandingAmount()));
		}

	}

	/**
	 * @param currentBillAmount
	 * @param netOutstandingAmount
	 * @return
	 */
	Amount add(Amount currentBillAmount, Amount netOutstandingAmount) {
		Amount amount = new Amount(currentBillAmount.getValue());
		if (netOutstandingAmount != null) {
			amount = amount.add(netOutstandingAmount);
		}
		return amount;
	}

}