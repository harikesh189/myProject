package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import java.util.Collection;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier.Type;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTQueryCriteria;

public interface FTDataProvider {

	/**
	 * @param input
	 * @return
	 */
	Collection<FTEntryDTO> fetchFTEntries(FTQueryCriteria input);

	/**
	 * @param billingAccountId
	 * @param fromDate
	 * @param tillDate
	 * @param glAccountType
	 * @return
	 */
	Amount getAccountBalance(String billingAccountId, DateTime fromDate,
			DateTime tillDate, Type glAccountType);

	/**
	 * @param billingAccountId
	 * @param tillDate
	 * @param glAccountType
	 * @return
	 */
	Amount getAccountBalance(String billingAccountId, DateTime tillDate,
			Type glAccountType);
	
	Amount getAccountBalance(String billingAccountId, Type glAccountType);

}
