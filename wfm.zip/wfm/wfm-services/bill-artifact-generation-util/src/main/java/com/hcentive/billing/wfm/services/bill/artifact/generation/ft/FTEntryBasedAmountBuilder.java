package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import static com.hcentive.billing.core.commons.util.CollectionUtil.isNotEmpty;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.MemberBreakUpAmountAware;
import com.hcentive.billing.wfm.api.enumeration.ft.GLEntryCategory;
import com.hcentive.billing.wfm.domain.bill.invoice.ContractBillAmount;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.InsuranceCoverageAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.InsuranceCoverageBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAndPlanAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;
import com.hcentive.billing.wfm.services.bill.artifact.generation.repository.BillAmountRepository;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;

public abstract class FTEntryBasedAmountBuilder {

	private static final Logger logger = LoggerFactory.getLogger(FTEntryBasedAmountBuilder.class);

	private static class AmountId {
		private final String amountCode;
		private final Period coveragePeriod;
		private final AmountGroup amountGroup;

		AmountId(String amountCode, Period coveragePeriod, AmountGroup amtGrp) {
			this.amountCode = amountCode;
			this.amountGroup = amtGrp;
			this.coveragePeriod = coveragePeriod;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + (amountCode == null ? 0 : amountCode.hashCode());
			result = prime * result + (amountGroup == null ? 0 : amountGroup.hashCode());
			result = prime * result + (coveragePeriod == null ? 0 : coveragePeriod.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			final AmountId other = (AmountId) obj;
			if (amountCode == null) {
				if (other.amountCode != null) {
					return false;
				}
			} else if (!amountCode.equals(other.amountCode)) {
				return false;
			}
			if (amountGroup != other.amountGroup) {
				return false;
			}
			if (coveragePeriod == null) {
				if (other.coveragePeriod != null) {
					return false;
				}
			} else if (!coveragePeriod.equals(other.coveragePeriod)) {
				return false;
			}
			return true;
		}

	}

	class AmountCodeFTEntries {

		private final AmountId id;

		private String amountName;

		private AmountCategory amountCategory;

		private String desc;

		private final Set<FTEntryDTO> ftEntries = new HashSet<>();

		public DateTime associatedDate;

		AmountCodeFTEntries(AmountId id) {
			this.id = id;

		}
		void addFtEntry(FTEntryDTO ftEntry) {
			ftEntries.add(ftEntry);
		}

		BillAmount toBillAmount() {
			return toBillAmount(null);
		}

		BillAmount toBillAmount(Long planId) {

			final Set<String> ftEntryIds = new HashSet<>();

			Amount totalFtAmt = Amount.newAmount(BigDecimal.ZERO);

			// Assuming that all ft entries will have same GLAccount since
			// the amount code and amount category is same
			final Map<GLAccountQualifier.Type, Amount> glAcctAmt = FTCalculationHelper.calculateAccountBalance(ftEntries);
			if (glAcctAmt != null && !glAcctAmt.isEmpty()) {
				totalFtAmt = glAcctAmt.values().iterator().next();
			}

			final Set<MemberBreakUp> memberBreakUpAmounts = new HashSet<>();

			@SuppressWarnings("rawtypes")
			final Collection<Reference> billAmtReferences = new HashSet<>();

			// figure out member break up amounts from FT entries
			for (final FTEntryDTO ftEntry : ftEntries) {
				ftEntryIds.add(ftEntry.getFtEntryIdentity());
				final String billAmtRef = ftEntry.getReferenceBillAmountIdentity();

				if (billAmtRef != null) {

					//final BillAmount billAmt = getBillAmountRepository().findByIdentity(billAmtRef);
					final BillAmount billAmt = ftEntry.getReferenceBillAmount();

					if (billAmt instanceof MemberBreakUpAmountAware) {
						final Set<MemberBreakUp> memberBreakAmts = ((MemberBreakUpAmountAware) billAmt).memberBreakUpAmounts();
						memberBreakUpAmounts.addAll(createCopy(memberBreakAmts));
					}

					billAmtReferences.addAll(billAmt.getReferenceSet().getReferences());
				}
			}

			BillAmount billAmount = null;

			if (memberBreakUpAmounts.isEmpty()) {
				if (planId == null) {
					billAmount = new BillAmount(id.amountCode, amountName, totalFtAmt, amountCategory, id.amountGroup, desc, id.coveragePeriod, associatedDate);
				} else {
					billAmount = new InsuranceCoverageAwareBillAmount(planId, id.amountCode, amountName, amountCategory, totalFtAmt, id.amountGroup, desc,
					        id.coveragePeriod, associatedDate);
				}

			} else {
				if (planId == null) {
					billAmount = new MemberAwareBillAmount(id.amountCode, amountName, totalFtAmt, amountCategory, memberBreakUpAmounts, id.amountGroup, desc,
					        id.coveragePeriod, associatedDate);
				} else {
					billAmount = new MemberAndPlanAwareBillAmount(planId, id.amountCode, amountName, totalFtAmt, amountCategory, desc, id.coveragePeriod,
					        id.amountGroup, memberBreakUpAmounts, associatedDate);
				}
			}

			final BillAmount ftAwareBillAmt = billAmount.makeFTEntryAwareBillAmount(ftEntryIds, id.amountGroup, associatedDate);
			ftAwareBillAmt.addReferences(billAmtReferences);

			logger.debug("Created FT entry aware bill amount: {} ", ftAwareBillAmt);

			return ftAwareBillAmt;
		}
		
		private Set<MemberBreakUp> createCopy(Set<MemberBreakUp> memBreakUp) {
			Set<MemberBreakUp> copies = new HashSet<>();
			for (MemberBreakUp orig : memBreakUp) {
				MemberBreakUp copy = new MemberBreakUp(orig.getInsuredMemberId(), 
						orig.getAmount(), orig.getCoveragePeriod());
				copies.add(copy);
			}
			return copies;
		}
	}

	class PlanAmountCodeFTEntries {

		String planId;
		Long insuranceCoverageId;

		final Map<AmountId, AmountCodeFTEntries> amountCodeFtEntries = new HashMap<>();

		public PlanAmountCodeFTEntries(String planId, Long insuranceCoverageId) {
			this.insuranceCoverageId = insuranceCoverageId;
			this.planId = planId;
		}

		void addFtEntry(FTEntryDTO ftEntry, FTAmountGroupResolver amtGrpResolver) {
			addFtEntryToAmountCodeFTEntries(ftEntry, amountCodeFtEntries, amtGrpResolver);
		}

		private InsuranceCoverageBillAmount toBillAmount() {

			final InsuranceCoverageBillAmount epBillAmount = new InsuranceCoverageBillAmount();
			epBillAmount.setPlanId(insuranceCoverageId);

			for (final AmountCodeFTEntries amtCodeFTs : amountCodeFtEntries.values()) {
				epBillAmount.addBillAmount(amtCodeFTs.toBillAmount(epBillAmount.getPlanId()));
			}

			return epBillAmount;
		}

	}

	class ContractFTEntries {

		String contractId;

		// planId -> {amountCode -> {ftEntries}}
		Map<String, PlanAmountCodeFTEntries> planFtEntries = new HashMap<>();

		// amountCode -> {ftEntries}
		Map<AmountId, AmountCodeFTEntries> genericFtEntries = new HashMap<>();

		void addFtEntry(FTEntryDTO ftEntry, FTAmountGroupResolver amtGrpResolver) {
			addFtEntryToAmountCodeFTEntries(ftEntry, genericFtEntries, amtGrpResolver);
		}

		void addFtEntry(String planId, FTEntryDTO ftEntry, FTAmountGroupResolver amtGrpResolver) {
			addFtEntryToPlanAmountCodeFTEntries(planId, ftEntry, planFtEntries, amtGrpResolver);
		}

		ContractBillAmount toBillAmount() {

			final ContractBillAmount contractBillAmt = new ContractBillAmount(contractId);
			for (final AmountCodeFTEntries amtCodeFTs : genericFtEntries.values()) {
				contractBillAmt.addBillAmount(amtCodeFTs.toBillAmount());
			}

			for (final PlanAmountCodeFTEntries planFTs : planFtEntries.values()) {
				final InsuranceCoverageBillAmount epBillAmt = planFTs.toBillAmount();
				contractBillAmt.addBillAmount(epBillAmt);
			}

			return contractBillAmt;
		}

	}

	protected static class FTAmountBuilderResponse {

		private final Set<BillAmount> genericBillAmounts;

		private final Set<ContractBillAmount> contractBillAmounts;

		protected FTAmountBuilderResponse(Set<BillAmount> genericBillAmounts, Set<ContractBillAmount> contractBillAmounts) {
			this.genericBillAmounts = genericBillAmounts;
			this.contractBillAmounts = contractBillAmounts;
		}

		public Set<BillAmount> getGenericBillAmounts() {
			return genericBillAmounts;
		}

		public Set<ContractBillAmount> getContractBillAmounts() {
			return contractBillAmounts;
		}
	}

	public FTEntryBasedAmountBuilder() {
		super();
	}

	public FTAmountBuilderResponse buildBillAmounts(Set<FTEntryDTO> ftEntries, FTAmountGroupResolver amtGrpResolver) {

		logger.debug("Building FT Entry based amounts using ft entries - size: {}", ftEntries != null ? ftEntries.size() : 0);

		// separate plan aware ft entries and contract entries

		// planId -> {amountCode -> {ftEntries}}
		final Map<String, ContractFTEntries> contractFtEntries = new HashMap<>();

		final Map<AmountId, AmountCodeFTEntries> genericFtEntries = new HashMap<>();

		if (isNotEmpty(ftEntries)) {
			for (final FTEntryDTO ftEntry : ftEntries) {
				logger.debug("Ft entry id: {}", ftEntry.getFtEntryIdentity());
				final String contractId = ftEntry.getContractId();
				final String planId = ftEntry.getPlanExternalId();

				if (contractId == null) {
					addFtEntryToAmountCodeFTEntries(ftEntry, genericFtEntries, amtGrpResolver);
				} else {
					addFtEntryToGroupFTEntries(contractId, planId, ftEntry, contractFtEntries, amtGrpResolver);
				}
			}
		}

		final Set<BillAmount> genericBillAmts = new HashSet<>();
		for (final AmountCodeFTEntries amtCodeFTEntry : genericFtEntries.values()) {
			genericBillAmts.add(amtCodeFTEntry.toBillAmount());
		}

		final Set<ContractBillAmount> contractBillAmts = new HashSet<>();
		for (final ContractFTEntries grpFTs : contractFtEntries.values()) {
			contractBillAmts.add(grpFTs.toBillAmount());
		}

		return new FTAmountBuilderResponse(genericBillAmts, contractBillAmts);
	}

	protected void addFtEntryToAmountCodeFTEntries(FTEntryDTO ftEntry, Map<AmountId, AmountCodeFTEntries> amountCodeFtEntries,
	        FTAmountGroupResolver amtGrpResolver) {

		logger.debug("Adding ft entry to amount code entries - id: {}, code: {}, category: {}", 
				ftEntry.getFtEntryIdentity(), ftEntry.getAmountCode(),
		        ftEntry.getAmountCategory());

		final AmountGroup amountGrp = amtGrpResolver.determineAmountGroup(ftEntry);

		logger.debug("Resolve Amount group for ft entry : {}", amountGrp);

		if (amountGrp != AmountGroup.CANCELLED) {

			final AmountId id = buildAmountId(ftEntry, amountGrp);
			AmountCodeFTEntries amtFtEntries = amountCodeFtEntries.get(id);

			if (amtFtEntries == null) {
				amtFtEntries = new AmountCodeFTEntries(id);
				amtFtEntries.amountCategory = determineAmountCategory(ftEntry);
				amtFtEntries.amountName = ftEntry.getAmountName();
				amtFtEntries.desc = ftEntry.getDescription();
				amtFtEntries.associatedDate = ftEntry.getEventDate();
				amountCodeFtEntries.put(id, amtFtEntries);
			}

			amtFtEntries.addFtEntry(ftEntry);
		}
	}

	private AmountCategory determineAmountCategory(FTEntryDTO ftEntry) {
		return ftEntry.getGlEntryCategory() == GLEntryCategory.SUBSIDY ? AmountCategory.DISCOUNT : ftEntry.getAmountCategory();
	}

	private AmountId buildAmountId(FTEntryDTO ftEntry, AmountGroup amtGrp) {
		return new AmountId(ftEntry.getAmountCode(), ftEntry.getCoveragePeriod(), amtGrp);
	}

	protected void addFtEntryToPlanAmountCodeFTEntries(String planId, FTEntryDTO ftEntry, Map<String, PlanAmountCodeFTEntries> planFtEntries,
	        FTAmountGroupResolver amtGrpResolver) {

		logger.debug("Adding ft entry to plan code entries - id: {}, plan: {}", ftEntry.getFtEntryIdentity(), planId);

		PlanAmountCodeFTEntries planEntrySet = planFtEntries.get(planId);

		if (planEntrySet == null) {
			planEntrySet = new PlanAmountCodeFTEntries(planId, ftEntry.getInsuranceCoverageId());
			planFtEntries.put(planId, planEntrySet);
		}

		planEntrySet.addFtEntry(ftEntry, amtGrpResolver);
	}

	private void addFtEntryToGroupFTEntries(String contractId, String planId, FTEntryDTO ftEntry, Map<String, ContractFTEntries> contractFtEntries,
	        FTAmountGroupResolver amtGrpResolver) {

		logger.debug("Adding ft entry to contract entries - id: {}, contract: {}", ftEntry.getFtEntryIdentity(), contractId);

		ContractFTEntries grpFTs = contractFtEntries.get(contractId);

		if (grpFTs == null) {
			grpFTs = new ContractFTEntries();
			grpFTs.contractId = contractId;
			contractFtEntries.put(contractId, grpFTs);
		}

		if (planId == null) {
			grpFTs.addFtEntry(ftEntry, amtGrpResolver);

		} else {
			grpFTs.addFtEntry(planId, ftEntry, amtGrpResolver);
		}
	}

	public abstract BillAmountRepository getBillAmountRepository();

}