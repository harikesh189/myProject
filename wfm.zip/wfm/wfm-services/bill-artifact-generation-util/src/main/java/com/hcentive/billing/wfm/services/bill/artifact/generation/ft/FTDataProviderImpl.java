/**
 *
 */
package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.api.enumeration.ft.AccountType;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier.Type;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.services.bill.artifact.generation.repository.BillAmountRepository;
import com.hcentive.billing.wfm.services.bill.artifact.generation.repository.FTEntryRepository;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTQueryCriteria;

/**
 * @author Dikshit.Vaid
 */
@Component
public class FTDataProviderImpl implements FTDataProvider {

	private static final Logger logger = LoggerFactory.getLogger(FTDataProviderImpl.class);

	/**
	 * Map to keep account type (DR/CR) for a given account category.
	 */
	private static final Map<GLAccountQualifier.Type, AccountType> accountTypeMap;

	static {
		accountTypeMap = new HashMap<>();
		accountTypeMap.put(GLAccountQualifier.Type.PEND_PAY, AccountType.CR);
		accountTypeMap.put(GLAccountQualifier.Type.ACCT_PAY, AccountType.CR);
		accountTypeMap.put(GLAccountQualifier.Type.PEND_RX, AccountType.DR);
		accountTypeMap.put(GLAccountQualifier.Type.ACCT_RX, AccountType.DR);
		accountTypeMap.put(GLAccountQualifier.Type.PEND_REV, AccountType.CR);
		accountTypeMap.put(GLAccountQualifier.Type.REVENUE, AccountType.CR);
		accountTypeMap.put(GLAccountQualifier.Type.BAD_DEBT, AccountType.DR);
		accountTypeMap.put(GLAccountQualifier.Type.CASH, AccountType.DR);
		accountTypeMap.put(GLAccountQualifier.Type.UNAPPLIED_CASH, AccountType.CR);
	}

	@Autowired
	private FTEntryRepository ftEntryRepo;
	
	@Autowired
	private BillAmountRepository billAmtRepo;

	@Override
	public Collection<FTEntryDTO> fetchFTEntries(final FTQueryCriteria input) {
		
		List<FTEntryDTO> ftEntryDTOs = ftEntryRepo.getFTEntryDTOs(input.getBillingAccountId(), 
				input.getTransactionPeriod().getBeginsOn().getDate(), 
				input.getTransactionPeriod().getEndsOn().getDate());
		
		if (CollectionUtil.isNotEmpty(ftEntryDTOs)) {
			Collection<String> refBillAmountIdentities = new ArrayList<>();
			for (FTEntryDTO ftEntry : ftEntryDTOs) {
				refBillAmountIdentities.add(ftEntry.getReferenceBillAmountIdentity());
			}
			
			// fetch reference bill Amounts
			List<BillAmount> billAmounts = billAmtRepo.findByIdentityIn(refBillAmountIdentities);

			// set the bill amounts in FT Entry DTO
			if (CollectionUtil.isNotEmpty(billAmounts)) {
				
				// create a map of bill amount identity -> bill amount
				Map<String, BillAmount> billAmountsMap = new HashMap<>();
				for (BillAmount billAmt : billAmounts) {
					billAmountsMap.put(billAmt.getIdentity(), billAmt);
				}
				
				// set it in FTEntryDTO
				for (FTEntryDTO dto : ftEntryDTOs) {
					dto.setReferenceBillAmount(billAmountsMap.get(dto.getReferenceBillAmountIdentity()));
				}
				
			}
			
		}
		
		return ftEntryDTOs;
	}

	@Override
	public Amount getAccountBalance(final String billingAccountId, final DateTime fromDate, final DateTime tillDate, final Type glAccountType) {
		final Amount accountBalance = new Amount();
		accountBalance.setValue(this.getBillingAccountBalance(billingAccountId, fromDate, tillDate, glAccountType));
		return accountBalance;
	}

	@Override
	public Amount getAccountBalance(final String billingAccountId, final DateTime tillDate, final Type glAccountType) {
		// TODO - make interservice call to FT service to fetch FTEntries by
		// criteria
		// account balance obtained for tillDate-1
		final Amount balance = Amount.newAmount(BigDecimal.ZERO);
		final BigDecimal billingAccountBalance = this.getBillingAccountBalance(billingAccountId, tillDate, glAccountType);
		if (null != billingAccountBalance) {
			balance.setValue(billingAccountBalance);
		}
		return balance;
	}

	/**
	 * @param billingAccountId
	 * @param fromDate
	 * @param tillDate
	 * @param glAccountType
	 * @return
	 */
	private BigDecimal getBillingAccountBalance(final String billingAccountId, final DateTime fromDate, final DateTime tillDate, final Type glAccountType) {

		BigDecimal billingAccountBalance = this.ftEntryRepo.getBillingAccountBalance(billingAccountId, fromDate.getDate(), tillDate.getDate(), glAccountType);

		if (billingAccountBalance == null) {
			billingAccountBalance = BigDecimal.ZERO;
		}

		final AccountType accountType = accountTypeMap.get(glAccountType);
		if (accountType == AccountType.CR) {
			billingAccountBalance = billingAccountBalance.multiply(new BigDecimal(-1));
		}
		return billingAccountBalance;
	}

	private BigDecimal getBillingAccountBalance(final String billingAccountID, final DateTime tillDate, final GLAccountQualifier.Type accountQualifier) {
		BigDecimal billingAccountBalance = this.ftEntryRepo.getBillingAccountBalance(billingAccountID, tillDate.getDate(), accountQualifier);
		logger.debug("Account balance calculated from db = {}", billingAccountBalance);
		if (billingAccountBalance == null) {
			billingAccountBalance = BigDecimal.ZERO;
		}

		final AccountType accountType = accountTypeMap.get(accountQualifier);
		if (accountType == AccountType.CR) {
			billingAccountBalance = billingAccountBalance.multiply(new BigDecimal(-1));
		}

		logger.debug("Account balance calculated after account type consideration = {}", billingAccountBalance);
		return billingAccountBalance;
	}

	private BigDecimal getBillingAccountBalance(String billingAccountId, Type accountQualifier) {
		BigDecimal billingAccountBalance = this.ftEntryRepo.getBillingAccountBalance(billingAccountId, accountQualifier);
		logger.debug("Account balance calculated from db = {}", billingAccountBalance);
		if (billingAccountBalance == null) {
			billingAccountBalance = BigDecimal.ZERO;
		}

		final AccountType accountType = accountTypeMap.get(accountQualifier);
		if (accountType == AccountType.CR) {
			billingAccountBalance = billingAccountBalance.multiply(new BigDecimal(-1));
		}

		logger.debug("Account balance calculated after account type consideration = {}", billingAccountBalance);
		return billingAccountBalance;
	}
	
	@Override
	public Amount getAccountBalance(final String billingAccountId, final Type glAccountType) {
		final Amount balance = Amount.newAmount(BigDecimal.ZERO);
		final BigDecimal billingAccountBalance = this.getBillingAccountBalance(billingAccountId, glAccountType);
		if (null != billingAccountBalance) {
			balance.setValue(billingAccountBalance);
		}
		return balance;
	}

}
