package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;

public interface FTAmountGroupResolver {

	AmountGroup determineAmountGroup(FTEntryDTO fte);

}
