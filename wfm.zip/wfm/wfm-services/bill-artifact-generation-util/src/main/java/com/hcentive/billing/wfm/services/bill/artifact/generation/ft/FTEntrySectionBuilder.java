package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import java.util.Set;

import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;

public interface FTEntrySectionBuilder<T> {

	void buildSection(Set<FTEntryDTO> ftEntries, T billCtx);

	boolean isFTEntryRequired(FTEntryDTO ftEntry, T billCtx);

	String name();

}
