package com.hcentive.billing.wfm.services.bill.artifact.generation.repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.hcentive.billing.core.commons.persistence.factory.repository.VersionAwareJpaRepository;
import com.hcentive.billing.wfm.domain.ft.FinancialTrxnEntry;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;


public interface FTEntryRepository extends VersionAwareJpaRepository<FinancialTrxnEntry, Long> {

	/**
	 * @param billingAccountId
	 * @param fromDate
	 * @param tillDate
	 * @param glAccountType
	 * @return
	 */
	@Query("select sum(gle.amount.value * gle.postingTypeValue) from FinancialTransaction ft," + " FinancialTrxnEntry fte, GLEntry gle,BillingAccount ba where"
	        + " ft.auditInfo.createdAt.date>= ?2 and ft.auditInfo.createdAt.date<= ?3 and gle.glAccount.qualifier.type= ?4 "
	        + " and ba.identity = ?1 and gle.billingAccount.id=ba.id and" + " fte.glEntry = gle and fte MEMBER OF ft.ftEntries")
	public BigDecimal getBillingAccountBalance(String billingAccountId, Date fromDate, Date tillDate, GLAccountQualifier.Type glAccountType);

	@Query("select sum(gle.amount.value * gle.postingTypeValue) from FinancialTransaction ft, FinancialTrxnEntry fte, GLEntry gle"
	        + " where ft.auditInfo.createdAt.date< ?2 and fte.financialTransaction = ft and fte.glEntry = gle and "
	        + " gle.glAccount.qualifier.type= ?3 and gle.billingAccount.identity = ?1")
	public BigDecimal getBillingAccountBalance(String billingAccountIdentity, Date tillDate, GLAccountQualifier.Type accountQualifier);
	
	@Query("select sum(gle.amount.value * gle.postingTypeValue) from GLEntry gle"
	        + " where gle.glAccount.qualifier.type= ?2 and gle.billingAccount.identity = ?1")
	public BigDecimal getBillingAccountBalance(String billingAccountIdentity, GLAccountQualifier.Type accountQualifier);

	@Query("select fte from FinancialTransaction ft, FinancialTrxnEntry fte, GLEntry gle " + "where ft.auditInfo.createdAt.date >= ?2 and ft.auditInfo.createdAt.date <= ?3 and "
	        + "gle.billingAccount.identity = ?1 and " + "fte.glEntry = gle and fte MEMBER OF ft.ftEntries")
	public List<FinancialTrxnEntry> getFinancialTrxnEntries(String billingAccountID, Date from, Date to);

	//Commented find by reference code - TO DO
	@Query("select new com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO(" + "ic.id, fte.amountCategory, fte.amountCode, "
	        + "fte.amountName, fte.coveragePeriod, fte.identity, fte.description, hp.externalId, "
	        + "(select r1.referenceId from ReferenceSet rs1, Reference r1 where rs1.id = fte.referenceSet.id "
	        + "and r1 MEMBER OF rs1.references and r1.typeName = 'Contract'), "
	        + "(CASE WHEN exists(select rft.identity from FinancialTransaction rft where rft.reversedFromFtIdentity = fte.financialTransaction.identity "
	        					+ "and rft.eventQualifier = com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventQualifier.CANCEL) "
	        	+ "THEN 'CANCEL' "
	        	+ "ELSE fte.financialTransaction.eventQualifier END), "
	        + "fte.glEntry.glAccount.qualifier.type, "
	        + "fte.glEntry.glAccount.accountType, fte.glEntry.category, fte.glEntry.postingType, " + "fte.glEntry.amount, "
	        + "(select r2.referenceId from ReferenceSet rs2, Reference r2 where rs2.id = fte.referenceSet.id "
	        + "and r2 MEMBER OF rs2.references and r2.typeName = 'BillAmount'), "
	        + "fte.financialTransaction.eventDate) from FinancialTrxnEntry fte "
	        + "left join fte.insurancePlan ic left join ic.healthPlan hp "
	        + "where fte.financialTransaction.auditInfo.createdAt.date >= ?2 and fte.financialTransaction.auditInfo.createdAt.date <= ?3 and "
	        + "fte.glEntry.billingAccount.identity = ?1")
	public List<FTEntryDTO> getFTEntryDTOs(String billingAccountID, Date from, Date to);
	
}
