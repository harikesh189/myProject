package com.hcentive.billing.wfm.services.bill.artifact.generation.builder;

import com.hcentive.billing.wfm.services.bill.artifact.generation.api.BillContext;

public interface BillSectionBuilder<T extends BillContext> {

	void buildSection(T billCtx);

	String name();

}