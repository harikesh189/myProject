package com.hcentive.billing.wfm.services.bill.artifact.generation.vo;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier;

public class FTQueryCriteria {

	private GLAccountQualifier.Type glAccountType;

	private String billingAccountId;

	private Period transactionPeriod;

	public GLAccountQualifier.Type getGlAccountType() {
		return glAccountType;
	}

	public void setGlAccountType(GLAccountQualifier.Type glAccountType) {
		this.glAccountType = glAccountType;
	}

	public String getBillingAccountId() {
		return billingAccountId;
	}

	public void setBillingAccountId(String billingAccountId) {
		this.billingAccountId = billingAccountId;
	}

	public Period getTransactionPeriod() {
		return transactionPeriod;
	}

	public void setTransactionPeriod(Period transactionPeriod) {
		this.transactionPeriod = transactionPeriod;
	}

}
