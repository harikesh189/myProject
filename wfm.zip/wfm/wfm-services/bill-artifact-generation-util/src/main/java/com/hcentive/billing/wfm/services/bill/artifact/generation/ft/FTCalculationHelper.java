package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.enumeration.ft.AccountType;
import com.hcentive.billing.wfm.api.enumeration.ft.PostingType;
import com.hcentive.billing.wfm.domain.ft.GLAccountQualifier.Type;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;

public class FTCalculationHelper {

	public static Map<Type, Amount> calculateAccountBalance(final Collection<FTEntryDTO> ftEntries) {

		final Map<Type, Amount> glAccountBalance = new HashMap<>();

		final Map<Type, Set<FTEntryDTO>> glAcctEntries = new HashMap<>();

		final Map<Type, AccountType> glAccountTypes = new HashMap<>();

		for (final FTEntryDTO ftEntry : ftEntries) {

			final Type glAcct = ftEntry.getGlAccountQualifierType();

			Set<FTEntryDTO> glFTs = glAcctEntries.get(glAcct);

			if (glFTs == null) {
				glFTs = new HashSet<>();
				glAcctEntries.put(glAcct, glFTs);
			}

			glFTs.add(ftEntry);
			glAccountTypes.put(ftEntry.getGlAccountQualifierType(), ftEntry.getGlAccountType());
		}

		for (final Map.Entry<Type, Set<FTEntryDTO>> entry : glAcctEntries.entrySet()) {
			glAccountBalance.put(entry.getKey(), calculateAccountBalance(glAccountTypes.get(entry.getKey()), entry.getValue()));
		}

		return glAccountBalance;
	}

	private static Amount calculateAccountBalance(final AccountType glAccountType, final Set<FTEntryDTO> glFtEntries) {

		Amount totalAmt = Amount.newAmount(BigDecimal.ZERO);

		final boolean isDRAccount = glAccountType == AccountType.DR;

		for (final FTEntryDTO ftEntry : glFtEntries) {

			if (ftEntry.getPostingType() == PostingType.DR && isDRAccount || ftEntry.getPostingType() == PostingType.CR && !isDRAccount) {

				// add amount
				totalAmt = totalAmt.add(ftEntry.getAmount());

			} else {
				// subtract amount
				totalAmt = totalAmt.subtract(ftEntry.getAmount());
			}
		}

		return totalAmt;
	}

}
