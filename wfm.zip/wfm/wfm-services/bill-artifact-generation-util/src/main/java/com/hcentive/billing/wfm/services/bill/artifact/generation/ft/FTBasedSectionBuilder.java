package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.services.bill.artifact.generation.api.BillContext;
import com.hcentive.billing.wfm.services.bill.artifact.generation.builder.BillSectionBuilder;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTQueryCriteria;

public abstract class FTBasedSectionBuilder<T extends BillContext> implements BillSectionBuilder<T> {

	private static final Logger logger = LoggerFactory.getLogger(FTBasedSectionBuilder.class);

	@Autowired
	private FTDataProvider ftDataProvider;

	@Override
	public void buildSection(T billCtx) {

		final Collection<FTEntryDTO> ftEntries = ftDataProvider.fetchFTEntries(getFTQueryCriteria(billCtx));

		for (final FTEntrySectionBuilder<T> sectionBuilder : getFtEntrySectionBuilders()) {

			logger.debug("Running FT entry section builder: {} ", sectionBuilder.name());

			// build a set of FT entries required by this section builder
			final Set<FTEntryDTO> sectionFtEntries = new HashSet<>();
			for (final FTEntryDTO ftEntry : ftEntries) {
				if (sectionBuilder.isFTEntryRequired(ftEntry, billCtx)) {
					sectionFtEntries.add(ftEntry);
				}
			}

			// build the section
			sectionBuilder.buildSection(sectionFtEntries, billCtx);

		}

	}

	protected abstract Collection<FTEntrySectionBuilder<T>> getFtEntrySectionBuilders();

	protected abstract FTQueryCriteria getFTQueryCriteria(T billCtx);

}
