/**
 * 
 */
package com.hcentive.billing.wfm.services.bill.artifact.generation.api;

/**
 * @author Dikshit.Vaid
 * 
 */
public interface BillContext {

}
