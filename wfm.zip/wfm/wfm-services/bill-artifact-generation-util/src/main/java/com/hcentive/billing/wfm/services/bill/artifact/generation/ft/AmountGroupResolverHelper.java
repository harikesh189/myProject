package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventQualifier;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;

public class AmountGroupResolverHelper {

	public static AmountGroup determineAmountGroup(FTEntryDTO fte) {

		FinancialEventQualifier eventQualifier = fte.getFinancialEventQualifier();

		switch (eventQualifier) {

		case RERUN:
			return AmountGroup.DEFAULT;
		case CANCEL:
			return AmountGroup.CANCELLED;

		case RETRO:
		case VOID:
			return AmountGroup.RETRO;

		default:
			break;
		}

		return AmountGroup.DEFAULT;
	}

}
