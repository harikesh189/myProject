package com.hcentive.billing.wfm.services.bill.artifact.generation.ft;

import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.services.bill.artifact.generation.vo.FTEntryDTO;

public class DefaultFTAmountGroupResolver implements FTAmountGroupResolver {

	@Override
	public AmountGroup determineAmountGroup(FTEntryDTO fte) {
		return AmountGroup.DEFAULT;
	}

}
