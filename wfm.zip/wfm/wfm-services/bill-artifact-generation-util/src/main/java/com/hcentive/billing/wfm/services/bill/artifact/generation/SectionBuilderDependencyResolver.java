package com.hcentive.billing.wfm.services.bill.artifact.generation;

import java.util.Set;

public interface SectionBuilderDependencyResolver {

	Set<String> getDependentSectionBuilders(String sectionBuilder);

}
