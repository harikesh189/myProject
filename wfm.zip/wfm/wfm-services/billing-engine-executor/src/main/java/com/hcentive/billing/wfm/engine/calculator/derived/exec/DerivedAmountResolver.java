package com.hcentive.billing.wfm.engine.calculator.derived.exec;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmountDefinition;
import com.hcentive.billing.wfm.engine.multipass.MultipassTask;

public class DerivedAmountResolver implements
		MultipassTask<BillRunContext, BillRunContext, DerivedAmount<?>> {

	private DerivedAmountDefinition<?> definition;
	private BillAmountDependencyResolver amountDependencyResolver;
	private Map<String, BillAmount> resolvedDerivedFrom;
	private boolean complete;

	public DerivedAmountResolver(DerivedAmountDefinition<?> definition,
			BillAmountDependencyResolver resolver) {
		this.definition = definition;
		this.amountDependencyResolver = resolver;
		this.resolvedDerivedFrom = new HashMap<>();
		this.complete = false;
	}

	@Override
	public boolean isReadyToRun(BillRunContext state) {

		boolean ready = false;

		if (checkAllResolved()) {
			ready = true;

		} else {
			Set<BillAmount> resolvedAmounts = amountDependencyResolver
					.findBillAmounts(definition, state);
			for (BillAmount resolvedAmt : resolvedAmounts) {
				resolvedDerivedFrom.put(resolvedAmt.getCode(), resolvedAmt);
			}
			ready = checkAllResolved();
		}

		return ready;
	}

	private boolean checkAllResolved() {
		return resolvedDerivedFrom.keySet().containsAll(
				definition.getDerivedFrom());
	}

	@Override
	public DerivedAmount<?> execute(BillRunContext input) {

		DerivedAmount<?> derivedAmt = null;

		if (checkAllResolved()) {
			Set<BillAmount> deriveFrom = new HashSet<>();
			deriveFrom.addAll(resolvedDerivedFrom.values());
			derivedAmt = definition.toDerivedAmount(deriveFrom, input.getCoveragePeriod());
			complete = true;
		}

		return derivedAmt;
	}

	@Override
	public boolean isDone() {
		return complete;
	}

	@Override
	public String taskName() {
		return "Derived Amount Resolver";
	}

}
