package com.hcentive.billing.wfm.engine;

public class BillRunConstants {

	public static final String AMT_CODE_TOTAL_PREMIUM = "TOTAL_PREMIUM";

	public static final String AMT_CODE_PREMIUM_AFTER_SUBSIDY = "PREMIUM_AFTER_SUBSIDY";

}
