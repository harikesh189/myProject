package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class PercentageChargeResolver extends PercentageFinancialTermResolver {

	@Override
	public String name() {
		return "Percentage Charge Derived Amount Resolver";
	}

	@Override
	protected String financialTermType() {
		return ConfigType.OTHER_CHARGE.toString();
	}

	@Override
	public float executionOrder() {
		return ResolverExecutionOrder.CHARGE_RESOLVER_ORDER;
	}

	@Override
	protected AmountCategory getAmountType() {
		return AmountCategory.OTHER_CHARGE;
	}

}
