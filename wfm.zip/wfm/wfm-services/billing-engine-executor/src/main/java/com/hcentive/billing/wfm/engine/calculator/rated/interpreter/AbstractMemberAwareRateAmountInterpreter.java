package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;
import com.hcentive.billing.wfm.engine.calculator.vo.MemberAwareRateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.MemberRateAmount;

public abstract class AbstractMemberAwareRateAmountInterpreter extends AbstractRateAmountInterpreter {

	private static final Logger logger = LoggerFactory.getLogger(AbstractMemberAwareRateAmountInterpreter.class);

	public MemberAwareBillAmount calculateAmount(MemberAwareRateAmount rateAmount, Period billingPeriod, BillingConfigProRate proRateConfig) {

		logger.debug("Calculating bill amount for member aware rate amount: {}, period: {}", rateAmount, billingPeriod);

		MemberAwareBillAmount billAmount = new MemberAwareBillAmount(rateAmount.getAmountCode(), rateAmount.getAmountName(), Amount.newAmount(BigDecimal.ZERO),
		        rateAmount.getAmountCategory(), rateAmount.getDescription(), billingPeriod);

		Amount billAmtValue = billAmount.getAmount();

		final Period amountCalcPeriod = Period.getIntersection(rateAmount.getApplicableFor(), billingPeriod);

		final Amount amt = calculateAmountValue(rateAmount, amountCalcPeriod, proRateConfig);
		billAmount = rateAmount.toBillAmount(amt, billingPeriod);

		if (rateAmount.getMemberRateAmounts() != null) {

			for (final MemberRateAmount memRateAmt : rateAmount.getMemberRateAmounts()) {

				final Period memCalcPeriod = Period.getIntersection(amountCalcPeriod, memRateAmt.getApplicableFor());

				logger.debug("Calculating amount for member rate amount: {}, period: {}", memRateAmt, memCalcPeriod);

				if (memCalcPeriod != null) {
					final Amount memAmt = calculateAmountValue(memRateAmt, memCalcPeriod, proRateConfig);
					billAmount.addMemberBreakUp(new MemberBreakUp(memRateAmt.getInsuredMemberId(), memAmt, memCalcPeriod));
					billAmtValue = billAmtValue.add(memAmt);
				}
			}
		}

		billAmount.setAmount(billAmtValue);

		return billAmount;
	}

}
