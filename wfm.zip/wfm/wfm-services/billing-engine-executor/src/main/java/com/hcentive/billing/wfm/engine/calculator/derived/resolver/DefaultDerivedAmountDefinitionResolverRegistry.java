package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedBeanRegistry;
import com.hcentive.billing.wfm.services.billingrun.service.ExecutionOrderComparator;

@Component
public class DefaultDerivedAmountDefinitionResolverRegistry extends
		SpringBackedBeanRegistry<DerivedAmountDefinitionResolver> implements
		DerivedAmountDefinitionResolverRegistry {

	private Set<DerivedAmountDefinitionResolver> registry = new TreeSet<>(
			new ExecutionOrderComparator());

	@Override
	public Collection<DerivedAmountDefinitionResolver> registeredResolvers() {
		return Collections.unmodifiableCollection(registry);
	}

	@Override
	protected Class<DerivedAmountDefinitionResolver> lookupForType() {
		return DerivedAmountDefinitionResolver.class;
	}

	@Override
	protected void registerBean(DerivedAmountDefinitionResolver bean) {
		registry.add(bean);
	}

}
