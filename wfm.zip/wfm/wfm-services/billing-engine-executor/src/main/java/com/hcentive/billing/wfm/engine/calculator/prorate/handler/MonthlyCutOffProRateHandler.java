package com.hcentive.billing.wfm.engine.calculator.prorate.handler;

import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

/**
 * 
 * @author Dikshit.Luthra
 * 
 */
@Component
public class MonthlyCutOffProRateHandler extends AbstractProRateHandler {

	@Override
	protected double calcPartialMonthAmountMultiplier(
			Date monthCoverageStartDt, Date monthCoverageEndDt,
			BillingConfigProRate proRateConfig) {

		boolean startCheck = true;
		boolean endCheck = true;
		
		if (monthCoverageStartDt == null && 
				monthCoverageEndDt == null) {
			startCheck = false;
			endCheck = false;
		}

		if (monthCoverageStartDt != null) {

			Calendar startCalDt = Calendar.getInstance();
			startCalDt.setTime(monthCoverageStartDt);

			startCheck = startCalDt.get(Calendar.DAY_OF_MONTH) <= proRateConfig
					.getStartMonthlyCutoff();
			
		} 
		
		if (monthCoverageEndDt != null) {

			Calendar endCalDt = Calendar.getInstance();
			endCalDt.setTime(monthCoverageEndDt);

			endCheck = endCalDt.get(Calendar.DAY_OF_MONTH) >= proRateConfig
					.getEndMonthlyCutoff();
		}

		return (startCheck && endCheck) ? 1 : 0;
	}

	@Override
	public ProRateStrategy supportedStrategy() {
		return ProRateStrategy.MONTHLY_THRESHOLD;
	}

}
