package com.hcentive.billing.wfm.engine.calculator.prorate;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

public class ProRateHelper {

	private static final Logger logger = LoggerFactory.getLogger(ProRateHandler.class);

	private static ProRateHandlerFactory factory;

	public static void registerFactory(ProRateHandlerFactory proRateHandlerFactory) {
		factory = proRateHandlerFactory;
	}

	public static Amount proRateAmount(BillingConfigProRate proRateConfig, Period applicablePeriod, Amount monthlyAmt) {

		logger.debug("Pro-rating - applicable period: {}, monthly amount: {}", applicablePeriod, monthlyAmt);

		Amount amt = null;

		if (applicablePeriod != null) {
			ProRateHandler handler = proRateConfig == null ? factory.getNullConfigHandler() : factory
					.getHandler(proRateConfig.getProRateStrategy());

			logger.debug("using pro-rate handler: {}", handler.getClass());

			amt = handler.proRate(proRateConfig, monthlyAmt, applicablePeriod);
		}

		return amt == null ? Amount.newAmount(BigDecimal.ZERO) : amt;
	}

}
