package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.util.EffectivityUtil;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTermImpl;
import com.hcentive.billing.wfm.api.PlanAndMemberFinancialTermImpl;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.AmountFinancialTerm;
import com.hcentive.billing.wfm.domain.contract.BenefitCoverage;
import com.hcentive.billing.wfm.domain.contract.BenefitMemberCoverage;
import com.hcentive.billing.wfm.domain.contract.ContractType;
import com.hcentive.billing.wfm.domain.contract.Eligibility;
import com.hcentive.billing.wfm.domain.contract.EligibilityContract;
import com.hcentive.billing.wfm.domain.contract.EligibilityCoverage;
import com.hcentive.billing.wfm.domain.contract.FinancialTermBuilder;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.BillRunConstants;

@Component
public class EligibilityBenefitFinancialTermBuilder implements FinancialTermBuilder {

	private static final Logger LOGGER = LoggerFactory.getLogger(EligibilityBenefitFinancialTermBuilder.class);

	@SuppressWarnings("unchecked")
	@Override
	public Collection<FinancialTerm<?>> build(BillingAccount billingAccount,
			FinancialContract<ContractType, ?> eligibilityContract, Period effectivePeriod) {
		
		final Set<FinancialTerm<?>> benefitFinancialTerms = new HashSet<FinancialTerm<?>>();

		if (eligibilityContract instanceof EligibilityContract) {
			final EligibilityContract elgContract = (EligibilityContract) eligibilityContract;
			final Eligibility eligibility = elgContract.getEligibility();

			for (final EligibilityCoverage eligibilityCoverage : eligibility.getEnrolledPlans()) {

				if (eligibilityCoverage instanceof BenefitCoverage) {

					final BenefitCoverage benefitCoverage = (BenefitCoverage) eligibilityCoverage;

					LOGGER.debug("Checking plan {} effectivitiy, bill period: {}, and plan period: {}",
							benefitCoverage.getHealthPlan().getExternalId(), effectivePeriod,
							benefitCoverage.effectivePeriod());

					if (EffectivityUtil.isCoverageEffective(benefitCoverage, effectivePeriod)) {
						
						for (final BenefitMemberCoverage benefitMemCov : benefitCoverage.getBenefitCoverages()) {
							
							final Period applicablePeriod = Period.getIntersection(
									elgContract.getContractInfo().getEffectivePeriod(), Period.getIntersection(
											benefitCoverage.effectivePeriod(), benefitMemCov.getCoverage()));
							
							if (EffectivityUtil.isCoverageEffective(benefitMemCov, effectivePeriod)) {
								final Amount benefitAmount = benefitMemCov.getBenefitAmount();
								
								final FinancialTerm<Amount> amountTerm = new AmountFinancialTerm(
										AmountCategory.PREMIUM.name(), BillRunConstants.AMT_CODE_TOTAL_PREMIUM,
										"TOTAL_PREMIUM", benefitAmount, effectivePeriod, "Premium");
								
								final MemberAwareFinancialTermImpl memberBenefitFinTerm = new MemberAwareFinancialTermImpl(
										amountTerm, benefitMemCov.getInsuredMember().getId());
								
								final Set<MemberAwareFinancialTerm<?>> memberAwareFinancialTerms = new HashSet<>();
								memberAwareFinancialTerms.add(memberBenefitFinTerm);

								benefitFinancialTerms.add(new PlanAndMemberFinancialTermImpl(
										AmountCategory.PREMIUM.name(), BillRunConstants.AMT_CODE_TOTAL_PREMIUM,
										"TOTAL_PREMIUM", benefitCoverage.effectivePeriod(), benefitCoverage.getId(),
										memberAwareFinancialTerms, "Premium"));
							}
						}
						LOGGER.debug("Fetched premimum financial term : {}", benefitFinancialTerms);
					}
				}
			}
		}

		return benefitFinancialTerms;
	}

	@Override
	public boolean canHandle(BillRunContext runContext) {
		return runContext != null && runContext.getBillingContractRun().getContract() instanceof EligibilityContract;
	}

}
