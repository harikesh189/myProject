package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

@Component
public class RateTypeInterpreterFactoryImpl extends SpringBackedAbstractFactory<RateTypeInterpreter> implements RateTypeInterpreterFactory {

	@Override
	public RateTypeInterpreter getInterpreter(RateAmount rateAmount) {
		for (RateTypeInterpreter interpreter : registeredInstances()) {
			if (interpreter.canHandle(rateAmount.getRateType())) {
				return interpreter;
			}
		}
		return null;
	}

	@Override
	protected Class<RateTypeInterpreter> lookupForType() {
		return RateTypeInterpreter.class;
	}

}
