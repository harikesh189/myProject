package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

@SuppressWarnings("rawtypes")
@Component
public class DefaultRateAmountInterpreterFactory extends
		SpringBackedAbstractFactory<RateAmountInterpreter> implements
		RateAmountInterpreterFactory {

	@Override
	public <T extends RateAmount> RateAmountInterpreter getInterpreter(
			Class<T> rateAmountType) {

		for (RateAmountInterpreter intrprtr : registeredInstances()) {
			if (intrprtr.interpretedType() == rateAmountType) {
				return intrprtr;
			}
		}
		throw new IllegalStateException(
				"No rate amount interpreter found for [" + rateAmountType + "]");
	}

	@Override
	protected Class<RateAmountInterpreter> lookupForType() {
		return RateAmountInterpreter.class;
	}

}
