package com.hcentive.billing.wfm.engine.calculator.prorate;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

public interface ProRateHandler {

	Amount proRate(BillingConfigProRate proRateConfig, Amount monthlyAmt,
			Period applicablePeriod);

	ProRateStrategy supportedStrategy();

}
