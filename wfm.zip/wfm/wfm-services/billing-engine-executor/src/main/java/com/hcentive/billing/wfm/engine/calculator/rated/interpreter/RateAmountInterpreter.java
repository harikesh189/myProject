package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public interface RateAmountInterpreter<T extends RateAmount, B extends BillAmount> {

	B interpretAmount(T rateAmount, Period billingPeriod,
			BillingConfigProRate proRateConfig);

	Class<T> interpretedType();

}
