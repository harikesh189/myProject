package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.PlanAndMemberAwareFinancialTerm;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.financial.term.FinancialTermResolver;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public abstract class MonthlyFlatFinancialTermResolver extends FinancialTermResolver implements RateAmountResolver {

	@Autowired
	private FinancialTermToRateAmountTxFactory factory;

	@Override
	public Set<RateAmount> resolveRateAmount(BillRunContext runCtx) {

		final Set<RateAmount> rateAmounts = new HashSet<>();

		for (final FinancialTerm<?> finTerm : resolveFinancialTerm(runCtx)) {

			if (finTerm.value() instanceof Amount || finTerm instanceof PlanAndMemberAwareFinancialTerm<?>
			        && ((PlanAndMemberAwareFinancialTerm<?>) finTerm).termValueType() == Amount.class) {

				final RateAmount rateAmt = factory.getTransformer(finTerm).transform(finTerm);
				rateAmounts.add(rateAmt);
			}
		}

		return rateAmounts;
	}

	protected abstract AmountCategory getAmountType();

}
