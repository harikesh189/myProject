package com.hcentive.billing.wfm.engine.calculator;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.services.billingrun.service.ExecutionOrderAware;

public interface AmountCalculator extends ExecutionOrderAware {

	String name();

	void calculateAndAddAmounts(BillRunContext runCtx);

}
