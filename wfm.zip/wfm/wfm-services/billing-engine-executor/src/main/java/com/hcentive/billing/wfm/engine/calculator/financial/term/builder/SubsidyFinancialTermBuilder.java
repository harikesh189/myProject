/**
 *
 */
package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.util.EffectivityUtil;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTermImpl;
import com.hcentive.billing.wfm.api.PlanAndMemberFinancialTermImpl;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.ContractInfo;
import com.hcentive.billing.wfm.domain.contract.ContractType;
import com.hcentive.billing.wfm.domain.contract.Eligibility;
import com.hcentive.billing.wfm.domain.contract.EligibilityContract;
import com.hcentive.billing.wfm.domain.contract.EligibilityCoverage;
import com.hcentive.billing.wfm.domain.contract.EligibleMemberCoverage;
import com.hcentive.billing.wfm.domain.contract.EnrolledPlan;
import com.hcentive.billing.wfm.domain.contract.FinancialTermBuilder;
import com.hcentive.billing.wfm.domain.contract.MonthlyAmountFinancialTerm;
import com.hcentive.billing.wfm.domain.contract.Subsidy;
import com.hcentive.billing.wfm.domain.contract.SubsidyType;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;

/**
 * @author Dikshit.Vaid
 *
 */
@Component(value = "subsidyFinancialTermBuilder")
public class SubsidyFinancialTermBuilder implements FinancialTermBuilder {

	private static final Logger LOGGER = LoggerFactory.getLogger(SubsidyFinancialTermBuilder.class);

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Collection<FinancialTerm<?>> build(final BillingAccount billingAccount, final FinancialContract<ContractType, ?> eligibilityContract,
			final Period effectivePeriod) {

		final Collection<FinancialTerm<?>> subsidyFinancialTerms = new HashSet<FinancialTerm<?>>();

		if (eligibilityContract instanceof EligibilityContract) {
			final Eligibility eligibility = ((EligibilityContract) eligibilityContract).getEligibility();
			for (final EligibilityCoverage plan : eligibility.getEnrolledPlans()) {
				if (plan instanceof EnrolledPlan) {
					subsidyFinancialTerms.addAll(constructSubsidyFinancialTerm((EnrolledPlan) plan,
							(EligibilityContract) eligibilityContract, effectivePeriod));
				}
			}
		}

		return subsidyFinancialTerms;
	}

	@Override
	public boolean canHandle(final BillRunContext runContext) {
		return runContext != null && runContext.getBillingContractRun().getContract() instanceof EligibilityContract;
	}

	private Set<FinancialTerm<?>> constructSubsidyFinancialTerm(final EnrolledPlan plan, final EligibilityContract<ContractInfo> contract,
			final Period effectivePeriod) {

		final Set<FinancialTerm<?>> subsidyFinancialTerms = new HashSet<>();

		LOGGER.debug("Checking plan [{}] effectivitiy, bill period: {}, and plan period: {}", plan.getHealthPlan().getExternalId(), effectivePeriod,
				plan.effectivePeriod());

		if (EffectivityUtil.isCoverageEffective(plan, effectivePeriod)) {

			final Map<SubsidyType, Set<MemberAwareFinancialTerm<Amount>>> memberPremiumBreakUpsMap = new HashMap<>();
			final Map<SubsidyType, Subsidy> subsidyMap = new HashMap<>();

			final Period planEffPeriod = Period.getIntersection(contract.getContractInfo().getEffectivePeriod(), plan.effectivePeriod());

			for (final EligibleMemberCoverage memCoverage : plan.getMemberCoverages()) {

				if (EffectivityUtil.isCoverageEffective(memCoverage, effectivePeriod)) {

					final Period memberEffCoverage = Period.getIntersection(planEffPeriod, memCoverage.getCoverage());
					final Set<Subsidy> subsidies = memCoverage.getOptInSubsidies();

					if (subsidies != null && !subsidies.isEmpty()) {
						for (final Subsidy subsidy : subsidies) {

							if (EffectivityUtil.isCoverageEffective(subsidy, memberEffCoverage)) {

								subsidyMap.put(subsidy.getType(), subsidy);

								final Period subsidyEffectivePeriod = subsidyEffectivePeriod(subsidy.effectivePeriod(), memberEffCoverage);

								if (subsidyEffectivePeriod != null) {

									final FinancialTerm<Amount> monthlyAmountFinancialTerm = new MonthlyAmountFinancialTerm(AmountCategory.SUBSIDY.name(),
											String.valueOf(subsidy.getType()), String.valueOf(subsidy.getType()), subsidyEffectivePeriod, subsidy.getAmount(),
											"Subsidy - " + String.valueOf(subsidy.getType()));

									Set<MemberAwareFinancialTerm<Amount>> memberAwareFinancialTerms = memberPremiumBreakUpsMap.get(subsidy.getType());
									if (memberAwareFinancialTerms == null) {
										memberAwareFinancialTerms = new HashSet<MemberAwareFinancialTerm<Amount>>();
										memberPremiumBreakUpsMap.put(subsidy.getType(), memberAwareFinancialTerms);
									}

									final MemberAwareFinancialTerm<Amount> memberPremiumBreakUp = new MemberAwareFinancialTermImpl<Amount>(
											monthlyAmountFinancialTerm, memCoverage.getInsuredMember().getId());
									memberAwareFinancialTerms.add(memberPremiumBreakUp);
								}
							}
						}
					}
				}
			}

			for (final Entry<SubsidyType, Set<MemberAwareFinancialTerm<Amount>>> memberPremiumBreakUp : memberPremiumBreakUpsMap.entrySet()) {

				final Subsidy subsidy = subsidyMap.get(memberPremiumBreakUp.getKey());

				final FinancialTerm<Set<MemberAwareFinancialTerm<Amount>>> subsidyFinTerm = new PlanAndMemberFinancialTermImpl<Amount>(
						AmountCategory.SUBSIDY.name(), memberPremiumBreakUp.getKey().name(), memberPremiumBreakUp.getKey().name(), subsidy.effectivePeriod(),
						plan.getId(), memberPremiumBreakUp.getValue(), "Subsidy - " + memberPremiumBreakUp.getKey().name());
				subsidyFinancialTerms.add(subsidyFinTerm);
			}

			LOGGER.debug("Fetched subsidy financial terms : {}", subsidyFinancialTerms);
		}

		return subsidyFinancialTerms;
	}

	private Period subsidyEffectivePeriod(final Period subsidyEffective, final Period planEffective) {
		LOGGER.debug("Calculating subsidy effective period: subsidy applicable for [{}], " + "plan/member coverage: [{}]", subsidyEffective, planEffective);
		return Period.getIntersection(subsidyEffective, planEffective);
	}

}
