package com.hcentive.billing.wfm.engine.calculator;

public class CalculatorExecutionOrder {

	public static final float RATED_AMT_CALC_ORDER = 10;

	public static final float DERIVED_AMT_CALC_ORDER = 20;

}
