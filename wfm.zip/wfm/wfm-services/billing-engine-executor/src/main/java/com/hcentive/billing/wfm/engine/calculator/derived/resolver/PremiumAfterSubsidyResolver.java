package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.domain.schedule.cycle.InsuranceCoverageBillAmount;
import com.hcentive.billing.wfm.engine.BillRunConstants;
import com.hcentive.billing.wfm.engine.calculator.derived.interpreter.AdditiveLogic;
import com.hcentive.billing.wfm.engine.calculator.derived.interpreter.AdditiveLogic.AdditiveType;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmountDefinition;
import com.hcentive.billing.wfm.engine.calculator.vo.PlanAwareDerivedAmountDefinition;

public class PremiumAfterSubsidyResolver implements
		DerivedAmountDefinitionResolver {

	@Override
	public float executionOrder() {
		return ResolverExecutionOrder.PREMIUM_AFTER_SUBSIDY_RESOLVER_ORDER;
	}

	@Override
	public Set<DerivedAmountDefinition<?>> resolveDefinitions(
			BillRunContext billRunCtx) {

		Set<DerivedAmountDefinition<?>> derivedAmounts = new HashSet<>();

		for (Map.Entry<Long, InsuranceCoverageBillAmount> planAmount : billRunCtx
				.getPlanAmounts().entrySet()) {

			InsuranceCoverageBillAmount epBillAmt = planAmount.getValue();

			Map<String, AdditiveType> additiveTypeInfo = new HashMap<>();
			Set<String> derivedFrom = new HashSet<>();

			additiveTypeInfo.put(BillRunConstants.AMT_CODE_TOTAL_PREMIUM,
					AdditiveType.PLUS);
			derivedFrom.add(BillRunConstants.AMT_CODE_TOTAL_PREMIUM);

			for (BillAmount billAmt : epBillAmt.getBillAmounts()) {

				if (billAmt.getAmountCategory() == AmountCategory.SUBSIDY) {
					additiveTypeInfo.put(billAmt.getCode(), AdditiveType.MINUS);
					derivedFrom.add(billAmt.getCode());
				}
			}

			AdditiveLogic logic = new AdditiveLogic(additiveTypeInfo);
			derivedAmounts
					.add(new PlanAwareDerivedAmountDefinition<AdditiveLogic>(
							BillRunConstants.AMT_CODE_PREMIUM_AFTER_SUBSIDY,
							BillRunConstants.AMT_CODE_PREMIUM_AFTER_SUBSIDY,
							AmountCategory.PREMIUM, derivedFrom, logic,
							epBillAmt.getPlanId(), "Premium"));

		}

		return derivedAmounts;
	}

	@Override
	public String name() {
		return "Enrolled Plan Premium without Subsidy resolver";
	}

}
