package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class PercentageWriteOnResolver extends PercentageFinancialTermResolver {

	@Override
	public String name() {
		return "Percentage Write On Derived Amount Resolver";
	}

	@Override
	public float executionOrder() {
		return ResolverExecutionOrder.WRITE_ON_RESOLVER_ORDER;
	}

	@Override
	protected AmountCategory getAmountType() {
		return AmountCategory.WRITE_ON;
	}

	@Override
	protected String financialTermType() {
		return ConfigType.WRITE_ON.toString();
	}

}
