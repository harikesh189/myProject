package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

public class ResolverExecutionOrder {

	public static final float PREMIUM_AFTER_SUBSIDY_RESOLVER_ORDER = 5;
	public static final float FEE_RESOLVER_ORDER = 10;
	public static final float CHARGE_RESOLVER_ORDER = 20;
	public static final float DISCOUNT_RESOLVER_ORDER = 30;
	public static final float TAX_RESOLVER_ORDER = 40;
	public static final float WRITE_ON_RESOLVER_ORDER = 50;

}
