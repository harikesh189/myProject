package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

public class PercentageLogic {

	private double percentage;

	public PercentageLogic(double percentage) {
		this.percentage = percentage;
	}

	public double getPercentage() {
		return percentage;
	}

	public String toString() {
		return "percentage: " + percentage;
	}

}
