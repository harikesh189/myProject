package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import java.util.Collection;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.ContractType;
import com.hcentive.billing.wfm.domain.contract.EligibilityContract;
import com.hcentive.billing.wfm.domain.contract.FinancialTermBuilder;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;

public class AbstractEligibilityFinancialTermBuilder implements FinancialTermBuilder{

	@Override
	public Collection<FinancialTerm<?>> build(BillingAccount billingAccount,
			FinancialContract<ContractType, ?> contract, Period effectivePeriod) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean canHandle(BillRunContext runContext) {
		return runContext != null && runContext.getBillingContractRun().getContract() instanceof EligibilityContract;
	}

}
