package com.hcentive.billing.wfm.engine.calculator.rated.resolver.subsidy;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.FinancialTermToRateAmountTxFactory;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.RateAmountResolver;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public class SubsidyAmountResolver implements RateAmountResolver {

	private static final Logger LOGGER = LoggerFactory.getLogger(SubsidyAmountResolver.class);

	@Autowired
	private FinancialTermToRateAmountTxFactory factory;

	@Override
	public Set<RateAmount> resolveRateAmount(BillRunContext billRunCtx) {

		LOGGER.debug("finding subsidy rate amounts");
		
		Set<RateAmount> rateAmounts = new HashSet<>();

		RateAmount rateAmt = null;
		
		Collection<FinancialTerm<?>> financialTerms = billRunCtx.getBillRunData().financialTerms();
		
		for (FinancialTerm<?> financialTerm : financialTerms) {
			if (AmountCategory.SUBSIDY.name().equals(financialTerm.type())) {
				rateAmt = factory.getTransformer(financialTerm).transform(financialTerm);
				rateAmounts.add(rateAmt);
			}
		}

		return rateAmounts;
	}

	@Override
	public String name() {
		return "Subsidy Amount Resolver";
	}

}
