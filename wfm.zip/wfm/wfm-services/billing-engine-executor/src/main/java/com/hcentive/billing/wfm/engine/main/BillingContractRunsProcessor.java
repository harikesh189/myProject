/**
 * 
 */
package com.hcentive.billing.wfm.engine.main;

import java.util.ArrayList;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;
import com.hcentive.billing.wfm.domain.contract.OneTimeContract;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillingContractRun;
import com.hcentive.billing.wfm.services.billingrun.repository.BillingContractRunRepository;
import com.hcentive.billing.wfm.services.billingrun.service.BillContractRunCalculator;
import com.hcentive.wfm.ft.event.handler.FinancialEventHandlingService;

/**
 * @author sambhav.jain
 *
 */
public class BillingContractRunsProcessor
		implements ItemProcessor<Collection<BillingContractRun>, Collection<BillingContractRun>> {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(BillingContractRunsProcessor.class);

	@Autowired
	private BillContractRunCalculator billContractRunCalculator;

	@Autowired
	private BillingContractRunRepository billingContractRunRepository;

	@Autowired
	private FinancialEventHandlingService financialEventService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
	 */
	@Override
	public Collection<BillingContractRun> process(Collection<BillingContractRun> item) throws Exception {
		if (item != null && !item.isEmpty()) {
			LOGGER.info("Processing BillingContractRun");
			for (BillingContractRun bcr : item) {
				LOGGER.info("Processing BillingContract Run for identity {}", bcr.getIdentity());
				bcr = billContractRunCalculator.calculator(bcr);
				
				// step createBillingFinancialTrxns
				financialEventService.handle(bcr);
				bcr.setBillRunStatus(RunStatus.COMPLETED);
				final AbstractFinancialContract<?> contract = bcr.getContract();
				if (contract instanceof OneTimeContract) {
					((OneTimeContract) contract).setBilledStatus(true);
				}
				LOGGER.info("Completed BillingContract Run for identity {}", bcr.getIdentity());
			}
			billingContractRunRepository.save(item);
			LOGGER.info("Processing completed");
			// TODO : Sambhav - First time policy usage flag to be set here.
			return item;
		}
		
		return new ArrayList<BillingContractRun>();
	}

}
