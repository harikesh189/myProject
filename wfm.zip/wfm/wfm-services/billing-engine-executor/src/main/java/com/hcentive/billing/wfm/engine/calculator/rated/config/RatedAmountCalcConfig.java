package com.hcentive.billing.wfm.engine.calculator.rated.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.wfm.engine.calculator.rated.resolver.FlatChargeResolver;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.FlatDiscountResolver;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.FlatFeeResolver;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.FlatTaxResolver;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.FlatWriteOnResolver;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.PremiumResolver;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.subsidy.SubsidyAmountResolver;

@Configuration
public class RatedAmountCalcConfig {

	@Bean
	public FlatFeeResolver feeResolver() {
		return new FlatFeeResolver();
	}

	@Bean
	public FlatTaxResolver taxResolver() {
		return new FlatTaxResolver();
	}

	@Bean
	public FlatDiscountResolver discountResolver() {
		return new FlatDiscountResolver();
	}

	@Bean
	public FlatChargeResolver chargeResolver() {
		return new FlatChargeResolver();
	}

	@Bean
	public PremiumResolver premiumResolver() {
		return new PremiumResolver();
	}

	@Bean
	public SubsidyAmountResolver subsidyResolver() {
		return new SubsidyAmountResolver();
	}
	
	@Bean 
	public FlatWriteOnResolver writeResolver() {
		return new FlatWriteOnResolver();
	}

}
