package com.hcentive.billing.wfm.engine.calculator;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedBeanRegistry;
import com.hcentive.billing.wfm.services.billingrun.service.ExecutionOrderComparator;

@Component
public class DefaultAmountCalculatorRegistry extends
		SpringBackedBeanRegistry<AmountCalculator> implements
		AmountCalculatorRegistry {

	private Set<AmountCalculator> calculators = new TreeSet<>(
			new ExecutionOrderComparator());

	@Override
	protected Class<AmountCalculator> lookupForType() {
		return AmountCalculator.class;
	}

	@Override
	public Collection<AmountCalculator> registeredCalculators() {
		return Collections.unmodifiableCollection(calculators);
	}

	@Override
	protected void registerBean(AmountCalculator bean) {
		calculators.add(bean);
	}

}
