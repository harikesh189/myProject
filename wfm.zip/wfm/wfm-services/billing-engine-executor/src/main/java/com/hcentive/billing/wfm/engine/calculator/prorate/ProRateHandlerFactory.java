package com.hcentive.billing.wfm.engine.calculator.prorate;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;

public interface ProRateHandlerFactory {

	ProRateHandler getHandler(ProRateStrategy proRateStrategy);

	ProRateHandler getNullConfigHandler();

}
