package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billingpolicy.FinancialCharge;
import com.hcentive.billing.wfm.domain.contract.MonthlyAmountFinancialTerm;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount.RateType;

@Component
public class MonthlyAmountFinTermToRateAmountTx implements FinancialTermToRateAmountTransformer {

	private static final Logger LOGGER = LoggerFactory.getLogger(MonthlyAmountFinTermToRateAmountTx.class);

	@Override
	public RateAmount transform(FinancialTerm<?> finTerm) {

		if (canHandle(finTerm)) {

			RateAmount rateAmount = new RateAmount((Amount) finTerm.value(), RateType.MONTHLY, finTerm.code(),
					finTerm.name(), AmountCategory.parse(finTerm.type()), finTerm.effectivePeriod(),
					finTerm.description());
			return rateAmount;

		}

		LOGGER.error("Cannot handle financial term of type [{}] :: {}", finTerm.getClass().getName(), finTerm);
		throw new IllegalArgumentException("Can not handle financial term of type ["
				+ finTerm.getClass().getName() + "]");
	}

	@Override
	public boolean canHandle(FinancialTerm<?> finTerm) {
		return (finTerm instanceof MonthlyAmountFinancialTerm || finTerm instanceof FinancialCharge) 
						&& finTerm.value() instanceof Amount;
	}

}
