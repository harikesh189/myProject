package com.hcentive.billing.wfm.engine.calculator.rated.premium;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.Premium;
import com.hcentive.billing.wfm.domain.contract.FixedPremium;
import com.hcentive.billing.wfm.domain.contract.MonthlyAmountFinancialTerm;

@Component
public class FixedPremiumInterpreter implements PremiumInterpreter<FixedPremium> {

	private static final Logger logger = LoggerFactory.getLogger(FixedPremiumInterpreter.class);

	@Override
	public FinancialTerm<?> determinePremiumFinancialTerm(Premium premium, Period applicableFor) {

		if (!(premium instanceof FixedPremium)) {
			logger.error("[" + premium.getClass().getName() + "] not supported by FixedPremiumInterpreter");
			throw new UnsupportedOperationException("[" + premium.getClass().getName() + "] not supported");
		}

		logger.debug("creating fixed premium rate amount, applicable period: {}", applicableFor);

		final FixedPremium fixedPremium = (FixedPremium) premium;

		final FinancialTerm<?> monthlyAmountFinancialTerm = new MonthlyAmountFinancialTerm(AmountCategory.PREMIUM.name(), premium.getCode().name(),
		        premium.getPremiumName(), applicableFor, fixedPremium.getAmount(), "Premium");

		return monthlyAmountFinancialTerm;
	}

	@Override
	public Class<FixedPremium> interpretedType() {
		return FixedPremium.class;
	}
}
