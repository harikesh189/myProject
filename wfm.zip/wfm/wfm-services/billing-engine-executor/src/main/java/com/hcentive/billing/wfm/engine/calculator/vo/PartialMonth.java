package com.hcentive.billing.wfm.engine.calculator.vo;

public class PartialMonth {

	private int year;

	private int month;

	private int startDate;

	private int endDate;

	public PartialMonth(int year, int month, int startDate, int endDate) {
		this.year = year;
		this.month = month;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public int getYear() {
		return year;
	}

	public int getMonth() {
		return month;
	}

	public int getStartDate() {
		return startDate;
	}

	public int getEndDate() {
		return endDate;
	}

}
