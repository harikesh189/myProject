package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import java.util.Set;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public interface RateAmountResolver {

	Set<RateAmount> resolveRateAmount(BillRunContext billRunCtx);

	String name();

}
