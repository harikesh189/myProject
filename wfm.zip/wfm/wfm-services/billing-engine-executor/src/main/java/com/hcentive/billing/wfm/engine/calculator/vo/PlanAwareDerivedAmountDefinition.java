package com.hcentive.billing.wfm.engine.calculator.vo;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.InsuranceCoverageAware;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;

public class PlanAwareDerivedAmountDefinition<DL> extends
		DerivedAmountDefinition<DL> implements InsuranceCoverageAware {

	private Long planId;

	public PlanAwareDerivedAmountDefinition(String amountCode,
			String amountName, AmountCategory type, Set<String> derivedFrom,
			DL derivationLogic, Long planId, String desc) {

		super(amountCode, type, derivedFrom, derivationLogic, amountName, desc);
		this.planId = planId;
	}

	@Override
	public Long insuranceCoverage() {
		return planId;
	}

	@Override
	public DerivedAmount<DL> toDerivedAmount(Set<BillAmount> derivedFromAmts, 
			Period coveragePeriod) {
		return new PlanAwareDerivedAmount<>(this, derivedFromAmts, planId, coveragePeriod);
	}

}
