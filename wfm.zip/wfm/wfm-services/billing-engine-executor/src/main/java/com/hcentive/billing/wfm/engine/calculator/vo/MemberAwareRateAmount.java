package com.hcentive.billing.wfm.engine.calculator.vo;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAwareBillAmount;

public class MemberAwareRateAmount extends RateAmount {

	private Set<MemberRateAmount> memberRateAmounts;

	public MemberAwareRateAmount(Amount monthlyRate, RateType rateType, String amountCode, String amountName,
			Period applicableFor, AmountCategory type, String desc) {
		
		super(monthlyRate, rateType, amountCode, amountName, type, applicableFor, desc);
		this.memberRateAmounts = new HashSet<>();
	}

	public void addMemberRateAmount(RateAmount rateAmount, Long insuredMemberId) {
		memberRateAmounts.add(new MemberRateAmount(rateAmount, insuredMemberId));
	}

	public Set<MemberRateAmount> getMemberRateAmounts() {
		return Collections.unmodifiableSet(memberRateAmounts);
	}

	public MemberAwareBillAmount toBillAmount(Amount finalAmt, Period coveragePeriod) {
		return new MemberAwareBillAmount(getAmountCode(), getAmountName(),
				finalAmt == null ? Amount.newAmount(BigDecimal.ZERO) : finalAmt, getAmountCategory(), getDescription(),
				coveragePeriod);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.toString()).append("\n").append(memberRateAmounts);
		return sb.toString();
	}

}
