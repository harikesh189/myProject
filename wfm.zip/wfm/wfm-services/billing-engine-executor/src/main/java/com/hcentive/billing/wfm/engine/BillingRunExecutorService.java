package com.hcentive.billing.wfm.engine;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillingContractRun;

public interface BillingRunExecutorService {

	BillingContractRun executeBillingRun(String contractRunIdentity);

}
