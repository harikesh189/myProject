/**
 * 
 */
package com.hcentive.billing.wfm.engine.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillingAccountRunCycle;
import com.hcentive.billing.wfm.services.billingrun.service.BillingAccountRunCycleExecutor;

/**
 * 
 * 
 * <p>
 * initBillingAccountRunCycle workflow step
 * </p>
 * 
 * @author sambhav.jain
 *
 */
public class BillingAccountRunCyclePolicyProcessor
		implements ItemProcessor<BillingAccountRunCycle, BillingAccountRunCycleAndBillingPolicy> {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(BillingAccountRunCyclePolicyProcessor.class);
	
	@Autowired
	private BillingAccountRunCycleExecutor billingAccountRunCycleExecutor;
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
	 */
	@Override
	public BillingAccountRunCycleAndBillingPolicy process(BillingAccountRunCycle item) throws Exception {
		LOGGER.info("Processing barc for {} for billing account {}", item.getId(), item.getBillingAccount().getIdentity());
		BillingAccountRunCycle initializedBarc = billingAccountRunCycleExecutor.initBillingAccountRunCycle(item);
		BillingAccountRunCycleAndBillingPolicy barp = new BillingAccountRunCycleAndBillingPolicy();
		barp.setCycle(initializedBarc);
		return barp;
	}

}
