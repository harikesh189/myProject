package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public interface RateTypeInterpreter {

	Amount calculateAmount(BillingConfigProRate proRateConfig, Period applicablePeriod, RateAmount rateAmount);
	
	boolean canHandle(RateAmount.RateType rateType);
	
}
