package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAndPlanAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAwareBillAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.BillAmountBuilder;
import com.hcentive.billing.wfm.engine.calculator.vo.MemberAndPlanAwareRateAmount;

@Component
public class MemberAndPlanAwareRateAmountInterpreter extends AbstractMemberAwareRateAmountInterpreter implements
        RateAmountInterpreter<MemberAndPlanAwareRateAmount, MemberAndPlanAwareBillAmount> {

	@Override
	public MemberAndPlanAwareBillAmount interpretAmount(MemberAndPlanAwareRateAmount rateAmount, Period billingPeriod, BillingConfigProRate proRateConfig) {

		final MemberAwareBillAmount amount = calculateAmount(rateAmount, billingPeriod, proRateConfig);

		return BillAmountBuilder.makePlanAware(amount, rateAmount.insuranceCoverage());
	}

	@Override
	public Class<MemberAndPlanAwareRateAmount> interpretedType() {
		return MemberAndPlanAwareRateAmount.class;
	}

}
