package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

import java.util.Map;

public class AdditiveLogic {

	public enum AdditiveType {
		PLUS, MINUS
	}

	private Map<String, AdditiveType> additiveTypeInfo;

	public AdditiveLogic(Map<String, AdditiveType> additiveTypeInfo) {

		if (additiveTypeInfo == null) {
			throw new IllegalArgumentException("Additive type info map is null");
		}

		this.additiveTypeInfo = additiveTypeInfo;
	}

	public AdditiveType getAdditiveType(String amountCode) {
		return additiveTypeInfo.get(amountCode);
	}

	public String toString() {
		return "additive info: " + additiveTypeInfo;
	}

}
