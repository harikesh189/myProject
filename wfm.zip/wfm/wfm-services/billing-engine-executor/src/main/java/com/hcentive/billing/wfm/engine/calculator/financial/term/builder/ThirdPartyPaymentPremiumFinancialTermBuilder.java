package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTermImpl;
import com.hcentive.billing.wfm.api.PlanAndMemberFinancialTermImpl;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.AmountFinancialTerm;
import com.hcentive.billing.wfm.domain.contract.ContractType;
import com.hcentive.billing.wfm.domain.contract.FinancialTermBuilder;
import com.hcentive.billing.wfm.domain.contract.RemitCoverage;
import com.hcentive.billing.wfm.domain.contract.ThirdPartyMemberCoverage;
import com.hcentive.billing.wfm.domain.contract.ThirdPartyPaymentContract;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.BillRunConstants;

@Component
public class ThirdPartyPaymentPremiumFinancialTermBuilder implements FinancialTermBuilder {

	private static final Logger LOGGER = LoggerFactory.getLogger(ThirdPartyPaymentPremiumFinancialTermBuilder.class);

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Collection<FinancialTerm<?>> build(final BillingAccount billingAccount,
	        FinancialContract<ContractType, ?> contract, Period effectivePeriod) {

		LOGGER.debug("building financial Terms for contract with id {}", contract.getIdentity());

		final ThirdPartyPaymentContract ptContract = (ThirdPartyPaymentContract) contract;
		final Set<RemitCoverage> remits = ptContract.getThirdPartyPaymentRecord().getRemits();

		final Set<FinancialTerm<?>> thirdPartyPremiumFinTerms = new HashSet<>();

		for (final RemitCoverage remitCoverage : remits) {

			if (!isPremiumAmountCoverage(remitCoverage.getMemberCoverage())) {
				LOGGER.debug("Not premium amount type coverage. Skip and continue to the next element.");
				continue;
			}

			final Amount premiumAmount = remitCoverage.getMemberCoverage().getPaymentAmount();

			final FinancialTerm<Amount> amountTerm = new AmountFinancialTerm(AmountCategory.PREMIUM.name(), BillRunConstants.AMT_CODE_TOTAL_PREMIUM,
			        "TOTAL_PREMIUM", premiumAmount, effectivePeriod, "Premium");

			final MemberAwareFinancialTermImpl memberPremiumFinTerm = new MemberAwareFinancialTermImpl(amountTerm, remitCoverage.getMemberCoverage()
			        .getInsuredMember().getId());

			final Set<MemberAwareFinancialTerm<?>> memberAwareFinancialTerms = new HashSet<>();
			memberAwareFinancialTerms.add(memberPremiumFinTerm);

			thirdPartyPremiumFinTerms.add(new PlanAndMemberFinancialTermImpl(AmountCategory.PREMIUM.name(), BillRunConstants.AMT_CODE_TOTAL_PREMIUM,
			        "TOTAL_PREMIUM", remitCoverage.effectivePeriod(), remitCoverage.getId(), memberAwareFinancialTerms, "Premium"));

		}

		LOGGER.debug("Total size of finTerms for Premium amount is {}", thirdPartyPremiumFinTerms.size());

		return thirdPartyPremiumFinTerms;
	}

	private boolean isPremiumAmountCoverage(ThirdPartyMemberCoverage memberCoverage) {
		return memberCoverage.getAmountCode().equalsIgnoreCase("PREM");
	}

	@Override
	public boolean canHandle(BillRunContext runContext) {
		return runContext != null && runContext.getBillingContractRun().getContract() instanceof ThirdPartyPaymentContract && !runContext.isRetro();
	}

}
