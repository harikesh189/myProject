package com.hcentive.billing.wfm.engine.main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.eclipse.persistence.config.EntityManagerProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.listener.ChunkListenerSupport;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.skip.AlwaysSkipItemSkipPolicy;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.retry.policy.NeverRetryPolicy;

import com.hcentive.billing.core.commons.service.util.SystemConfig;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillingAccountRunCycle;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillingContractRun;
import com.hcentive.commons.batch.process.MultiTenantSupportItemReader;
import com.hcentive.commons.batch.process.RoundRobbinTenantDataReadStrategy;
import com.hcentive.commons.batch.process.SpringBeanNameBasedReaderFactory;
import com.hcentive.commons.batch.process.TenantProvider;

@Configuration
public class BillingAccountRunCycleAndBillingPolicyConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(BillingAccountRunCycleAndBillingPolicyConfig.class);

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private EntityManager em;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private TenantProvider tenantProvider;

	/**
	 * Name of the Bill run job.
	 */
	public static final String BILLING_JOB = "BILLING_JOB";

	public static final String BILLING_ACCOUNT_PROCESSOR_STEP = "BILLING_ACCOUNT_PROCESSOR_STEP";

	@Value("${billing.accounting.chunksize:10}")
	private int CHUNK_SIZE;
	
	@Value("${billing.accounting.pagesize:10}")
	private int PAGE_SIZE;

	@Bean
	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public ItemReader<BillingAccountRunCycle> billingAccountRunCycleReader() {
		JpaPagingItemReader<BillingAccountRunCycle> billingAccountRunCyclesReader = new JpaPagingItemReader<>();
		LOGGER.debug("Executing billing for page size {} and chunk size {} ", PAGE_SIZE , CHUNK_SIZE);
		billingAccountRunCyclesReader.setPageSize(PAGE_SIZE);
		billingAccountRunCyclesReader.setEntityManagerFactory(entityManagerFactory);
		billingAccountRunCyclesReader.setTransacted(false);

		Map<String, Object> parameterValues = new java.util.HashMap<>(1);
		final DateTime theDate = SystemConfig.INSTANCE.currentDate();
		parameterValues.put("theDate", theDate.getDate());
		billingAccountRunCyclesReader.setParameterValues(parameterValues);
		billingAccountRunCyclesReader
				.setQueryString("select r from BillingAccountRunCycle r , r.billingAccount rBA where "
						+ "r.billingRunCycle.runDate.date <= :theDate and "
						+ "r.status = com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus.PENDING "
						+ "and not exists (select i from WFMInvoice i where "
						+ "(i.status = com.hcentive.billing.wfm.domain.bill.invoice.WFMInvoice.Status.REVIEW or i.status = "
						+ "com.hcentive.billing.wfm.domain.bill.invoice.WFMInvoice.Status.REVERSAL_INITIATED)  "
						+ "and i.summary.generatedFor = rBA) and "
						+ "not exists (select rr from BillingAccountRunCycle rr where " + "rr.billingAccount = rBA and "
						+ "(rr.status = com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus.INITIATED or "
						+ "rr.status = com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus.INIT_STARTED or "
						+ "rr.status = com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus.FAILED))");

		LOGGER.debug(" Reading BARC for date {}", theDate);

		return billingAccountRunCyclesReader;
	}

	@Bean
	public SpringBeanNameBasedReaderFactory<BillingAccountRunCycle> barcJPADelegateReaderFactory() {
		return new SpringBeanNameBasedReaderFactory<BillingAccountRunCycle>("billingAccountRunCycleReader");
	}

	@Bean
	public ItemReader<BillingAccountRunCycle> billAccountRunAndPolicyTenantBasedItemReaderForJPA() {
		final SpringBeanNameBasedReaderFactory<BillingAccountRunCycle> readerFactory = barcJPADelegateReaderFactory();
		MultiTenantSupportItemReader<BillingAccountRunCycle> reader = new MultiTenantSupportItemReader<BillingAccountRunCycle>(
				this.tenantProvider, readerFactory, RoundRobbinTenantDataReadStrategy.factory());
		return reader;
	}

	@Bean
	public ItemProcessor<BillingAccountRunCycle, BillingAccountRunCycleAndBillingPolicy> billingAccountRunCyclePolicyProcessor() {
		return new BillingAccountRunCyclePolicyProcessor();
	}

	@Bean
	public ItemProcessor<BillingAccountRunCycleAndBillingPolicy, Collection<BillingContractRun>> initBillingContractRunProcessor() {
		return new InitBillingContractRunProcessor();
	}

	@Bean
	public ItemProcessor<Collection<BillingContractRun>, Collection<BillingContractRun>> billingContractRunsProcessor() {
		return new BillingContractRunsProcessor();
	}

	/**
	 * 
	 * @param billingAccountRunCyclePolicyProcessor
	 *            {@link BillingAccountRunCyclePolicyProcessor}
	 * @param initBillingContractRunProcessor
	 *            {@link InitBillingContractRunProcessor}
	 * @param billingContractRunsProcessor
	 *            {@link BillingContractRunsProcessor}
	 * @return {@link CompositeItemProcessor}
	 */
	@Bean
	public CompositeItemProcessor<BillingAccountRunCycle, Collection<BillingContractRun>> compositeBillRunProcessor(
			ItemProcessor<BillingAccountRunCycle, BillingAccountRunCycleAndBillingPolicy> billingAccountRunCyclePolicyProcessor,
			ItemProcessor<BillingAccountRunCycleAndBillingPolicy, Collection<BillingContractRun>> initBillingContractRunProcessor,
			ItemProcessor<Collection<BillingContractRun>, Collection<BillingContractRun>> billingContractRunsProcessor) {
		CompositeItemProcessor<BillingAccountRunCycle, Collection<BillingContractRun>> compositeBillRunProcessor = new CompositeItemProcessor<>();
		List<ItemProcessor<?, ?>> delegates = new ArrayList<>();
		delegates.add(billingAccountRunCyclePolicyProcessor);
		delegates.add(initBillingContractRunProcessor);
		delegates.add(billingContractRunsProcessor);
		compositeBillRunProcessor.setDelegates(delegates);
		return compositeBillRunProcessor;
	}

	@Bean
	public ItemProcessListener<BillingAccountRunCycle, Collection<BillingContractRun>> billRunProcessListener() {
		ItemProcessListener<BillingAccountRunCycle, Collection<BillingContractRun>> listener = new ItemProcessListener<BillingAccountRunCycle, Collection<BillingContractRun>>() {
			@Override
			public void beforeProcess(BillingAccountRunCycle item) {
				LOGGER.info("Starting bill process for {}", item.getTenantId());
				ProcessContext.clear();
				ProcessContext.initializer().forTenant(item.getTenantId()).initialize();
				em.setProperty(EntityManagerProperties.MULTITENANT_PROPERTY_DEFAULT,
						ProcessContext.get().getTenantId());
			}

			@Override
			public void afterProcess(BillingAccountRunCycle item, Collection<BillingContractRun> result) {
				LOGGER.info("Process ran for barc {} for tenant {}", item.getIdentity(), item.getTenantId());
			}
			
			@Override
			public void onProcessError(BillingAccountRunCycle item, Exception e) {
				LOGGER.error("\n\nERROR WHILE PROCESSING BARC " + item.getId(), e);
			}
		};
		return listener;
	}

	@Bean
	public ChunkListener billingAccountRunCycleChunkListner() {
		return new ChunkListenerSupport() {
			@Override
			public void afterChunkError(ChunkContext context) {
				LOGGER.error("\n\nERROR while processing BARC chunk - Step execution context {} at step {}",
						context.getStepContext().getStepExecutionContext(), context.getStepContext().getStepName());
			}
//			
//			@Override
//			public void afterChunk(ChunkContext context) {
//				EntityTransaction tx = em.getTransaction();
//				if (tx != null) {
//					if (tx.isActive() && !tx.getRollbackOnly()) tx.commit(); 
//				}
//			}
		};
	}
	
	@Bean
	public SkipListener<BillingAccountRunCycle, Collection<BillingContractRun>> billingSkipListener() {
		return new SkipListener<BillingAccountRunCycle, Collection<BillingContractRun>>() {

			@Override
			public void onSkipInRead(Throwable t) {
				LOGGER.error("SKIPPING READ... Unable to read", t);
			}

			@Override
			public void onSkipInWrite(Collection<BillingContractRun> item, Throwable t) {
				LOGGER.error("SKIPPING WRITE... Unable to write items .. THIS SHOULD NOT SHOW UP AS THERE IS NO WRITE", t);
				
			}

			@Override
			public void onSkipInProcess(BillingAccountRunCycle item, Throwable t) {
				LOGGER.error("SKIPPING PROCESS... Unable to process item {}", item.getIdentity(), t);
			}

		};
	}

	@Bean
	public Step billingAccountRunSegmentStep(ItemReader<BillingAccountRunCycle> billAccountRunAndPolicyTenantBasedItemReaderForJPA,
			CompositeItemProcessor<BillingAccountRunCycle, Collection<BillingContractRun>> compositeBillRunProcessor,
			ItemProcessListener<BillingAccountRunCycle, Collection<BillingContractRun>> billRunProcessListener,
			ChunkListener billingAccountRunCycleChunkListner, SkipListener<BillingAccountRunCycle, Collection<BillingContractRun>> billingSkipListener) {
		//@formatter:off
		//TODO HACK for skipping on error
			return stepBuilderFactory
					.get(BILLING_ACCOUNT_PROCESSOR_STEP) // name of the Step
					.<BillingAccountRunCycle,Collection<BillingContractRun>> chunk(CHUNK_SIZE)
					.reader(billAccountRunAndPolicyTenantBasedItemReaderForJPA)
					.processor(compositeBillRunProcessor)
					.faultTolerant()
					.skipPolicy(new AlwaysSkipItemSkipPolicy())
					.processorNonTransactional()
					.retryPolicy(new NeverRetryPolicy())
					.listener(billRunProcessListener)
					.listener(billingAccountRunCycleChunkListner)
					.build();
		//@formatter:on
	}

	@Bean
	public Job billingJob(Step billingAccountRunSegmentStep) {
		//@formatter:off
			return jobBuilderFactory
					.get(BILLING_JOB)
					.start(billingAccountRunSegmentStep)
					.build();
		//@formatter:on
	}

}