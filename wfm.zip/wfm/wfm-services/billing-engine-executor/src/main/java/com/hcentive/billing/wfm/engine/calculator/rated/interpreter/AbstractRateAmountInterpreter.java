package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public abstract class AbstractRateAmountInterpreter {

	@Autowired
	private RateTypeInterpreterFactory rateTypeInterpreterFactory;

	protected BillAmount calculateAmount(RateAmount rateAmount,
			Period billingPeriod, BillingConfigProRate proRateConfig) {

		Period calculationPeriod = Period.getIntersection(
				rateAmount.getApplicableFor(), billingPeriod);

		Amount amt = calculateAmountValue(rateAmount, calculationPeriod, proRateConfig);

		return rateAmount.toBillAmount(amt, billingPeriod);
	}
	
	protected Amount calculateAmountValue(RateAmount rateAmount, Period amtCalPeriod, BillingConfigProRate proRate) {
		Amount amt = Amount.newAmount(BigDecimal.ZERO);
		RateTypeInterpreter rateInterpreter = rateTypeInterpreterFactory.getInterpreter(rateAmount);
		if (rateInterpreter != null && rateAmount.getAmount() != null) {
			amt = rateInterpreter.calculateAmount(proRate, amtCalPeriod, rateAmount);
		}
		return amt;
	}

}
