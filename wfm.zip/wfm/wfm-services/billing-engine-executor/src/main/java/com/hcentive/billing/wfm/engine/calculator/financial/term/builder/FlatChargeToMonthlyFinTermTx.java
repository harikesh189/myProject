package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billingpolicy.FinancialCharge;
import com.hcentive.billing.wfm.domain.contract.MonthlyAmountFinancialTerm;

@Component
public class FlatChargeToMonthlyFinTermTx implements FinancialChargeToFinancialTermTransformer<Amount, Amount> {

	@Override
	public FinancialTerm<Amount> transform(
			FinancialCharge<Amount> fc, Period effectivePeriod) {
		return new MonthlyAmountFinancialTerm(fc.type(), fc.code(), 
				fc.name(), effectivePeriod, fc.value(), fc.description());
	}

	@Override
	public FinancialTerm<Amount> transform(
			FinancialCharge<Amount> financialCharge) {
		return transform(financialCharge, financialCharge.effectivePeriod());
	}

	@Override
	public boolean canHandle(FinancialCharge<Amount> fc) {
		return fc.value() instanceof Amount;
	}

}
