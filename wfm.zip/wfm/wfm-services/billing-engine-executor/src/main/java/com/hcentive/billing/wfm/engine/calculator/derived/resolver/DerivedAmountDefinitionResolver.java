package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import java.util.Set;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmountDefinition;
import com.hcentive.billing.wfm.services.billingrun.service.ExecutionOrderAware;

public interface DerivedAmountDefinitionResolver extends ExecutionOrderAware {

	Set<DerivedAmountDefinition<?>> resolveDefinitions(BillRunContext billRunCtx);

	String name();

}
