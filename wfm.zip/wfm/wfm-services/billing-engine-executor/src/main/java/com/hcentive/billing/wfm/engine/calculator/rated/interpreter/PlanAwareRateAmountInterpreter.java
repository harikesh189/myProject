package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.InsuranceCoverageAwareBillAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.BillAmountBuilder;
import com.hcentive.billing.wfm.engine.calculator.vo.PlanAwareRateAmount;

@Component
public class PlanAwareRateAmountInterpreter extends
		AbstractRateAmountInterpreter
		implements
		RateAmountInterpreter<PlanAwareRateAmount, InsuranceCoverageAwareBillAmount> {

	@Override
	public InsuranceCoverageAwareBillAmount interpretAmount(
			PlanAwareRateAmount rateAmount, Period billingPeriod,
			BillingConfigProRate proRateConfig) {

		BillAmount amount = calculateAmount(rateAmount, billingPeriod,
				proRateConfig);

		return BillAmountBuilder.makePlanAware(amount,
				rateAmount.insuranceCoverage());
	}

	@Override
	public Class<PlanAwareRateAmount> interpretedType() {
		return PlanAwareRateAmount.class;
	}

}
