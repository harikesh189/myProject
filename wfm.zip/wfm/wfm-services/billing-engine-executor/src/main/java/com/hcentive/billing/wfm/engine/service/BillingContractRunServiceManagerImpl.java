package com.hcentive.billing.wfm.engine.service;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;
import com.hcentive.billing.wfm.domain.contract.OneTimeContract;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillingContractRun;
import com.hcentive.billing.wfm.services.billingrun.repository.AbstractFinancialContractRepository;
import com.hcentive.billing.wfm.services.billingrun.repository.BillingContractRunRepository;

@Component
public class BillingContractRunServiceManagerImpl implements BillingContractRunServiceManager {

	private static final Logger logger = LoggerFactory.getLogger(BillingContractRunServiceManagerImpl.class);

	@Autowired
	private BillingContractRunRepository repository;

	@Autowired
	private AbstractFinancialContractRepository abstractFinancialContractRepository;

	@Override
	@RequiresPermissions(value = Permission.COMPLETE_BILLING_CONTRACT_RUN)
	public void completeBillingContractRun(String contractRunIdentity) {
		final BillingContractRun contractRun = repository.findByIdentity(contractRunIdentity);

		if (contractRun == null) {
			logger.error("BillingContractRun not found for identity: {}", contractRunIdentity);
			throw new IllegalStateException("BillingContractRun not found for identity: " + contractRunIdentity);
		}

		contractRun.setBillRunStatus(RunStatus.COMPLETED);

		// mark the one time contracts as billed = true
		final AbstractFinancialContract<?> contract = contractRun.getContract();
		if (contract instanceof OneTimeContract) {
			((OneTimeContract) contract).setBilledStatus(true);
		}
		abstractFinancialContractRepository.save(contract);
		repository.save(contractRun);
	}

	@Override
	@RequiresPermissions(value = Permission.FAIL_BILLING_CONTRACT_RUN)
	public void failBillingContractRun(String contractRunIdentity) {
		final BillingContractRun contractRun = repository.findByIdentity(contractRunIdentity);

		if (contractRun == null) {
			logger.error("BillingContractRun not found for identity: {}", contractRunIdentity);

			throw new IllegalStateException("BillingContractRun not found for identity: " + contractRunIdentity);
		}

		contractRun.setBillRunStatus(RunStatus.FAILED);

		repository.save(contractRun);
	}

}
