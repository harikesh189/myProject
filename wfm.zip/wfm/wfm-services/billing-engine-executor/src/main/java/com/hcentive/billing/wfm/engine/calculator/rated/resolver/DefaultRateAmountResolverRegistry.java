package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import java.util.Collection;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;

@Component
public class DefaultRateAmountResolverRegistry extends
		SpringBackedAbstractFactory<RateAmountResolver> implements
		RateAmountResolverRegistry {

	@Override
	public Collection<RateAmountResolver> registeredResolvers() {
		return registeredInstances();
	}

	@Override
	protected Class<RateAmountResolver> lookupForType() {
		return RateAmountResolver.class;
	}

}
