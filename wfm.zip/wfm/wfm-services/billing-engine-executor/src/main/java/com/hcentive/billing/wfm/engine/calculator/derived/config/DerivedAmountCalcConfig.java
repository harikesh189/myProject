package com.hcentive.billing.wfm.engine.calculator.derived.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.wfm.engine.calculator.derived.resolver.PercentageChargeResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.resolver.PercentageDiscountResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.resolver.PercentageFeeResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.resolver.PercentageTaxResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.resolver.PercentageWriteOnResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.resolver.PremiumAfterSubsidyResolver;
import com.hcentive.billing.wfm.engine.multipass.impl.SimpleMultipassExecutor;

@Configuration
public class DerivedAmountCalcConfig {

	@Bean
	public PremiumAfterSubsidyResolver premiumWithoutSubsidyDefinitionResolver() {
		return new PremiumAfterSubsidyResolver();
	}

	@Bean
	public PercentageFeeResolver percentageFeeDerviedAmountDefinitinResolver() {
		return new PercentageFeeResolver();
	}

	@Bean
	public PercentageChargeResolver percentageChargeDerviedAmountDefinitinResolver() {
		return new PercentageChargeResolver();
	}

	@Bean
	public PercentageDiscountResolver percentageDiscountDerviedAmountDefinitinResolver() {
		return new PercentageDiscountResolver();
	}

	@Bean
	public PercentageTaxResolver percentageTaxDerviedAmountDefinitinResolver() {
		return new PercentageTaxResolver();
	}
	
	@Bean
	public PercentageWriteOnResolver percentageWriteOnDerviedAmountDefinitinResolver() {
		return new PercentageWriteOnResolver();
	}

	@Bean
	public <I, S, R> SimpleMultipassExecutor<I, S, R> simpleMultipassExecutor() {
		return new SimpleMultipassExecutor<>();
	}

}
