package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billingpolicy.FinancialCharge;

public interface FinancialChargeToFinancialTermTransformer<CV, TV> {

	FinancialTerm<TV> transform(FinancialCharge<CV> financialCharge);

	FinancialTerm<TV> transform(FinancialCharge<CV> fc, Period effectivePeriod);

	boolean canHandle(FinancialCharge<CV> fc);

}
