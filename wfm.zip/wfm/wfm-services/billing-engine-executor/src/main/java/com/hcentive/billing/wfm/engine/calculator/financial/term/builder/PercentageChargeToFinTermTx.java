package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billingpolicy.FinancialCharge;
import com.hcentive.billing.wfm.domain.contract.PercentageAmount;
import com.hcentive.billing.wfm.domain.contract.PercentageFinancialTerm;

@Component
public class PercentageChargeToFinTermTx implements FinancialChargeToFinancialTermTransformer<PercentageAmount, PercentageAmount> {

	@Override
	public FinancialTerm<PercentageAmount> transform(
			FinancialCharge<PercentageAmount> financialCharge) {
		return transform(financialCharge, financialCharge.effectivePeriod());
	}

	@Override
	public FinancialTerm<PercentageAmount> transform(FinancialCharge<PercentageAmount> fc,
			Period effectivePeriod) {
		return new PercentageFinancialTerm(fc.type(), fc.code(), 
				fc.name(), effectivePeriod, fc.value(), fc.description());
	}

	@Override
	public boolean canHandle(FinancialCharge<PercentageAmount> fc) {
		return fc.value() instanceof PercentageAmount;
	}

}
