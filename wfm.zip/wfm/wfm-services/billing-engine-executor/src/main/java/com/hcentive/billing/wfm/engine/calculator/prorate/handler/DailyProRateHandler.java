package com.hcentive.billing.wfm.engine.calculator.prorate.handler;

import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

@Component
public class DailyProRateHandler extends AbstractProRateHandler {

	@Override
	protected double calcAmountMultiplier(Period premiumApplicablePeriod,
			BillingConfigProRate proRateConfig) {

		double chargeableMonths = 0.0;

		// determine full months and partial months
		// then for partial months, determine the multiplying factor

		Date beginsOn = premiumApplicablePeriod.getBeginsOn().getDate();
		Date endsOn = premiumApplicablePeriod.getEndsOn().getDate();

		Calendar startDate = Calendar.getInstance();
		startDate.setTime(premiumApplicablePeriod.getBeginsOn().getDate());

		Calendar endDate = Calendar.getInstance();
		endDate.setTime(premiumApplicablePeriod.getEndsOn().getDate());

		int noOfMonths = DateUtility.numberOfMonths(beginsOn, endsOn);

		if (DateUtility.isMonthStartDate(beginsOn)
				&& DateUtility.isMonthEndDate(endsOn)) {
			chargeableMonths = noOfMonths;

		} else {

			if (noOfMonths > 1) {

				// check if the start month is partial
				if (!DateUtility.isMonthStartDate(beginsOn)) {
					// partial start month
					chargeableMonths += calcMonthPremiumFactor(beginsOn, null);

				} else {
					chargeableMonths++;
				}

				// check if the end month is partial
				if (!DateUtility.isMonthEndDate(endsOn)) {
					chargeableMonths += calcMonthPremiumFactor(null, endsOn);
				} else {
					chargeableMonths++;
				}

				// add the months in between the start month and end month
				chargeableMonths += (noOfMonths - 2); // subtract 2 to exclude
														// start and end month

			} else if (noOfMonths == 1) {
				// find multiplying factor for coverage days
				chargeableMonths += calcMonthPremiumFactor(beginsOn, endsOn);
			}
		}

		return chargeableMonths;
	}

	protected double calcMonthPremiumFactor(Date startDate, Date endDate) {

		double monthPremiumFactor = 0.0;

		if (startDate != null && endDate != null) {

			Calendar calStartDt = Calendar.getInstance();
			calStartDt.setTime(startDate);

			Calendar calEndDt = Calendar.getInstance();
			calEndDt.setTime(endDate);

			if (calStartDt.get(Calendar.MONTH) != calEndDt.get(Calendar.MONTH)) {
				throw new IllegalArgumentException("Start month [" + calStartDt
						+ "] and end month [" + calEndDt + "] should be same");
			}

			monthPremiumFactor = (double) DateUtility.numberOfDays(startDate,
					endDate)
					/ (double) calStartDt
							.getActualMaximum(Calendar.DAY_OF_MONTH);

		} else if (startDate != null) {

			Calendar calStartDt = Calendar.getInstance();
			calStartDt.setTime(startDate);

			monthPremiumFactor = (double) DateUtility.daysInMonthAfter(
					startDate, true)
					/ (double) calStartDt
							.getActualMaximum(Calendar.DAY_OF_MONTH);

		} else if (endDate != null) {
			Calendar calEndDt = Calendar.getInstance();
			calEndDt.setTime(endDate);

			monthPremiumFactor = (double) DateUtility.daysInMonthBefore(
					endDate, true)
					/ (double) calEndDt.getActualMaximum(Calendar.DAY_OF_MONTH);
		}

		return monthPremiumFactor;
	}

	@Override
	protected double calcPartialMonthAmountMultiplier(
			Date monthCoverageStartDt, Date monthCoverageEndDt,
			BillingConfigProRate proRateConfig) {

		double monthPremiumFactor = 0.0;

		if (monthCoverageStartDt != null && monthCoverageEndDt != null) {

			Calendar calStartDt = Calendar.getInstance();
			calStartDt.setTime(monthCoverageStartDt);

			Calendar calEndDt = Calendar.getInstance();
			calEndDt.setTime(monthCoverageEndDt);

			if (calStartDt.get(Calendar.MONTH) != calEndDt.get(Calendar.MONTH)) {
				throw new IllegalArgumentException("Start month [" + calStartDt
						+ "] and end month [" + calEndDt + "] should be same");
			}

			monthPremiumFactor = (double) DateUtility.numberOfDays(
					monthCoverageStartDt, monthCoverageEndDt)
					/ (double) calStartDt
							.getActualMaximum(Calendar.DAY_OF_MONTH);

		} else if (monthCoverageStartDt != null) {

			Calendar calStartDt = Calendar.getInstance();
			calStartDt.setTime(monthCoverageStartDt);

			monthPremiumFactor = (double) DateUtility.daysInMonthAfter(
					monthCoverageStartDt, true)
					/ (double) calStartDt
							.getActualMaximum(Calendar.DAY_OF_MONTH);

		} else if (monthCoverageEndDt != null) {
			Calendar calEndDt = Calendar.getInstance();
			calEndDt.setTime(monthCoverageEndDt);

			monthPremiumFactor = (double) DateUtility.daysInMonthBefore(
					monthCoverageEndDt, true)
					/ (double) calEndDt.getActualMaximum(Calendar.DAY_OF_MONTH);
		}

		return monthPremiumFactor;
	}

	@Override
	public ProRateStrategy supportedStrategy() {
		return ProRateStrategy.DAILY_PROROATE;
	}

}
