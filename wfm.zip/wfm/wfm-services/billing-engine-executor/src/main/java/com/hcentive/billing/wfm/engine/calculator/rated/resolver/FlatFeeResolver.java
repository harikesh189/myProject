package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class FlatFeeResolver extends MonthlyFlatFinancialTermResolver {

	@Override
	public String name() {
		return "Flat Fee Rated Amount Resolver";
	}

	@Override
	protected String financialTermType() {
		return ConfigType.FEE.toString();
	}

	@Override
	protected AmountCategory getAmountType() {
		return AmountCategory.FEE;
	}

}
