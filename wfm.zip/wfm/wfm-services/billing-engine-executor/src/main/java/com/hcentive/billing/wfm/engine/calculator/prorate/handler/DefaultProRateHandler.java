package com.hcentive.billing.wfm.engine.calculator.prorate.handler;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

@Component
public class DefaultProRateHandler extends AbstractProRateHandler {

	@Override
	protected double calcPartialMonthAmountMultiplier(
			Date monthCoverageStartDt, Date monthCoverageEndDt,
			BillingConfigProRate proRateConfig) {
		return 1;
	}

	@Override
	public ProRateStrategy supportedStrategy() {
		return null;
	}

}
