package com.hcentive.billing.wfm.engine.service;

public interface BillingContractRunServiceManager {
	
	public void completeBillingContractRun(final String contractRunIdentity);
	
	public void failBillingContractRun(final String contractRunIdentity);

}
