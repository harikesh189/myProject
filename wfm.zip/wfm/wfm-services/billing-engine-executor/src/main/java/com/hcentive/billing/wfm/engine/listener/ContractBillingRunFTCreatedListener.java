package com.hcentive.billing.wfm.engine.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.commons.workflow.annotation.Activity;
import com.hcentive.billing.core.commons.event.EventHandler;
import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.wfm.engine.service.BillingContractRunServiceManager;

@Component
public class ContractBillingRunFTCreatedListener implements EventHandler {

	private static final Logger logger = LoggerFactory.getLogger(ContractBillingRunFTCreatedListener.class);

	@Autowired
	private BillingContractRunServiceManager billingContractRunServiceManager;

	@EventSubscription(eventName = EventType.BILLING_RUN_FT_CREATED, recieveOfflineEvents = true)
	@Activity(stepName = "updateContractRunAfterFTCreation")
	public void handleContractBillingRunFTCreatedEvent(String contractRunIdentity) {

		logger.debug("Processing FT created event for contract run : {}", contractRunIdentity);
		billingContractRunServiceManager.completeBillingContractRun(contractRunIdentity);
		logger.debug("Billing Contract Run Completed successfully for contactRunIdentity: {}", contractRunIdentity);

	}

	@EventSubscription(eventName = EventType.BILLING_RUN_FT_CREATE_FAILED, recieveOfflineEvents = true)
	public void handleContractBillingRunFTCreateFailedEvent(String contractRunIdentity) {

		logger.debug("Processing FT create failed event for contract run : {}", contractRunIdentity);

		billingContractRunServiceManager.failBillingContractRun(contractRunIdentity);
		logger.debug("Billing Contract marked as failed for contract run : {}", contractRunIdentity);
	}

}