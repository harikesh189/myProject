package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import com.hcentive.billing.wfm.api.FinancialTerm;

public interface FinancialTermToRateAmountTxFactory {

	FinancialTermToRateAmountTransformer getTransformer(FinancialTerm<?> finTerm);
	
}
