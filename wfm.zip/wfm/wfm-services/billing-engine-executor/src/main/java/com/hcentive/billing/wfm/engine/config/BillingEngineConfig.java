package com.hcentive.billing.wfm.engine.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.wfm.engine.calculator.BillAmountCalculators;

@Configuration
public class BillingEngineConfig {

	@Bean
	public BillAmountCalculators billAmountCalculatorsOperation() {
		return new BillAmountCalculators();
	}

}
