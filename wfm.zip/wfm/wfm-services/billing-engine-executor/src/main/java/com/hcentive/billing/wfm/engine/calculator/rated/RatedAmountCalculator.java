package com.hcentive.billing.wfm.engine.calculator.rated;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.domain.billingpolicy.BillingPolicy;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;
import com.hcentive.billing.wfm.domain.contract.ContractInfo;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.AmountCalculator;
import com.hcentive.billing.wfm.engine.calculator.CalculatorExecutionOrder;
import com.hcentive.billing.wfm.engine.calculator.rated.interpreter.RateAmountInterpreter;
import com.hcentive.billing.wfm.engine.calculator.rated.interpreter.RateAmountInterpreterFactory;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.RateAmountResolver;
import com.hcentive.billing.wfm.engine.calculator.rated.resolver.RateAmountResolverRegistry;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public class RatedAmountCalculator implements AmountCalculator {

	private static final Logger logger = LoggerFactory.getLogger(RatedAmountCalculator.class);

	@Autowired
	private RateAmountResolverRegistry registry;

	@Autowired
	private RateAmountInterpreterFactory interpreterFactory;

	@Override
	public String name() {
		return "Rated Amount Calculator";
	}

	@Override
	public float executionOrder() {
		return CalculatorExecutionOrder.RATED_AMT_CALC_ORDER;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void calculateAndAddAmounts(final BillRunContext runCtx) {

		final AbstractFinancialContract<ContractInfo> contract = runCtx.contract();
		final BillingPolicy bp = runCtx.contractBillingPolicy();

		logger.debug("Running rated amount resolvers for contract: {}", contract.getIdentity());

		// Determine the list of rate amounts from each resolver
		// Compute the bill amount for each rate amount and add it to context
		for (final RateAmountResolver resolver : this.registry.registeredResolvers()) {

			final Set<RateAmount> rateAmounts = resolver.resolveRateAmount(runCtx);

			if (rateAmounts != null) {
				logger.debug("Resolver : {}, resolved amount count: {}", resolver.name(), rateAmounts.size());
				for (final RateAmount rateAmt : rateAmounts) {
					logger.debug("Processing rate amount: {}", rateAmt);
					final RateAmountInterpreter intrprtr = this.interpreterFactory.getInterpreter(rateAmt.getClass());
					final BillAmount billAmt = intrprtr.interpretAmount(rateAmt, runCtx.getCoveragePeriod(), bp.getBillingConfigProRating());
					if (billAmt != null) {
						logger.debug("Adding bill amount: {}, value: {}", billAmt.getCode(), billAmt.getAmount().getValue());
						runCtx.addBillAmount(billAmt);
					} else {
						logger.info("Bill amount null for amount code: ", rateAmt.getAmountCode());
					}
				}
			} else {
				logger.debug("Resolver : {}, resolved amount count: {}", 0);
			}

		}

	}

}
