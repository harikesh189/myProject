/**
 * 
 */
package com.hcentive.billing.wfm.engine.main;

import java.util.ArrayList;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillingContractRun;
import com.hcentive.billing.wfm.services.billingrun.service.impl.BillRunSegmentExecutor;

/**
 *
 * <p>
 * </p>
 * 
 * @author sambhav.jain
 */
public class InitBillingContractRunProcessor
		implements ItemProcessor<BillingAccountRunCycleAndBillingPolicy, Collection<BillingContractRun>> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(InitBillingContractRunProcessor.class);

	@Autowired
	private BillRunSegmentExecutor segmentExecutor;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
	 */
	@Override
	public Collection<BillingContractRun> process(BillingAccountRunCycleAndBillingPolicy item) throws Exception {
		if (item.getCycle() != null) {
			LOGGER.info("Starting run segements for billing account run cycle id {} and billing account {}", item.getCycle().getBillingRunCycle().getId(), 
					item.getCycle().getBillingAccount().getIdentity());
			Collection<BillingContractRun> contractRuns = segmentExecutor.executeRunSegments(item.getCycle());
			LOGGER.info("End run segment execution");
			return contractRuns;
		}

		return new ArrayList<BillingContractRun>();
	}

}
