package com.hcentive.billing.wfm.engine.calculator.vo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;

public class DerivedAmount<DL> {

	private DerivedAmountDefinition<DL> definition;

	private Set<BillAmount> deriveFrom;
	
	private Period coveragePeriod;

	public DerivedAmount(DerivedAmountDefinition<DL> definition,
			Set<BillAmount> deriveFrom, Period coveragePeriod) {
		this.definition = definition;
		this.deriveFrom = deriveFrom;
		this.coveragePeriod = coveragePeriod;
	}

	public String getAmountCode() {
		return definition.getAmountCode();
	}

	public AmountCategory getAmountType() {
		return definition.getAmountCategory();
	}

	public String getAmountName() {
		return definition.getName();
	}

	public Set<BillAmount> getDeriveFrom() {
		return deriveFrom;
	}

	public DL getDerivationLogic() {
		return definition.getDerivationLogic();
	}

	public String getDescription() {
		return definition.getDescription();
	}
	
	public Period getCoveragePeriod() {
		return coveragePeriod;
	}

	public void setCoveragePeriod(Period coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}

	public BillAmount toBillAmount(Amount amount) {
		
		BillAmount amt = new BillAmount(definition.getAmountCode(), definition.getName(),
				amount, definition.getAmountCategory(), AmountGroup.DEFAULT,
				getDescription(), coveragePeriod, null);
		
		amt.addReferences(deriveFromBillAmountReferences());
		
		return amt;
	}
	
	protected Collection<Reference<String, BillAmount, String>> deriveFromBillAmountReferences() {
		Collection<Reference<String, BillAmount, String>> references = new ArrayList<>();
		for (BillAmount deriveFromAmt : deriveFrom) {
			references.add(deriveFromAmt.toReference());
		}
		return references;
	}

	public BillAmount toBillAmount(Amount amount, Set<MemberBreakUp> memberBreakUp) {

		BillAmount amt = new MemberAwareBillAmount(definition.getAmountCode(),
				definition.getName(), amount, definition.getAmountCategory(),
				memberBreakUp, AmountGroup.DEFAULT, getDescription(), coveragePeriod, null);
		
		amt.addReferences(deriveFromBillAmountReferences());
		
		return amt;

	}

}
