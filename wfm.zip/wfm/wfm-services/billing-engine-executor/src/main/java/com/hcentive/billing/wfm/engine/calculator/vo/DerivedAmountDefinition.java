package com.hcentive.billing.wfm.engine.calculator.vo;

import java.util.Collections;
import java.util.Set;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;

public class DerivedAmountDefinition<DL> {

	private String amountCode;

	private Set<String> derivedFrom;

	private DL derivationLogic;

	private AmountCategory amountCategory;

	private String name;
	
	private String description;
	
	public DerivedAmountDefinition(String amountCode, AmountCategory type,
			Set<String> derivedFrom, DL derivationLogic, String name, 
			String description) {
		this.amountCode = amountCode;
		this.derivedFrom = derivedFrom;
		this.derivationLogic = derivationLogic;
		this.amountCategory = type;
		this.name = name;
		this.description = description;
	}

	public String getAmountCode() {
		return amountCode;
	}

	public AmountCategory getAmountCategory() {
		return amountCategory;
	}

	public String getName() {
		return name;
	}

	public Set<String> getDerivedFrom() {
		return Collections.unmodifiableSet(derivedFrom);
	}

	public DL getDerivationLogic() {
		return derivationLogic;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public DerivedAmount<DL> toDerivedAmount(Set<BillAmount> derivedFromAmts,
			Period coveragePeriod) {
		return new DerivedAmount<DL>(this, derivedFromAmts, coveragePeriod);
	}

	public String toString() {
		return "amount code: " + amountCode + ", category: " + amountCategory
				+ ", derive from: " + derivedFrom + ", logic: "
				+ derivationLogic;
	}

}
