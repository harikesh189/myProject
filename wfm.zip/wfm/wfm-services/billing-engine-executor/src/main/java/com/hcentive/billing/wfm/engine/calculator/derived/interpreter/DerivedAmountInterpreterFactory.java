package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

public interface DerivedAmountInterpreterFactory {

	<DL> DerivedAmountInterpreter<DL> getInterpreter(
			Class<DL> derivationLogicType);

}
