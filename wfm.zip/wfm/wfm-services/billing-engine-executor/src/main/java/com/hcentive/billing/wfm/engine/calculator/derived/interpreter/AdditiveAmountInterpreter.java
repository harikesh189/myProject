package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.MemberBreakUpAmountAware;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;
import com.hcentive.billing.wfm.engine.calculator.derived.interpreter.AdditiveLogic.AdditiveType;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmount;

@Component
public class AdditiveAmountInterpreter extends AbstractDerivedAmountInterpreter
		implements DerivedAmountInterpreter<AdditiveLogic> {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AdditiveAmountInterpreter.class);

	@Override
	public Set<BillAmount> interpretDerivedAmount(
			DerivedAmount<AdditiveLogic> derivedAmt) {

		Amount finalAmt = Amount.newAmount(BigDecimal.ZERO);
		AdditiveLogic logic = derivedAmt.getDerivationLogic();

		// Insured member id -> Amount map
		Map<Long, MemberBreakUp> memberBreakUpAmts = new HashMap<>();

		for (BillAmount billAmt : derivedAmt.getDeriveFrom()) {

			AdditiveType type = logic.getAdditiveType(billAmt.getCode());

			if (billAmt instanceof MemberBreakUpAmountAware) {

				Set<MemberBreakUp> memberBreakUps = ((MemberBreakUpAmountAware) billAmt)
						.memberBreakUpAmounts();

				for (MemberBreakUp memBreakUp : memberBreakUps) {

					Long memberId = memBreakUp.getInsuredMemberId();

					MemberBreakUp memberAmt = memberBreakUpAmts.get(memberId);
					if (memberAmt == null) {
						memberAmt = new MemberBreakUp(memberId, 
							Amount.newAmount(BigDecimal.ZERO), derivedAmt.getCoveragePeriod());
						memberBreakUpAmts.put(memberId, memberAmt);
					}

					memberAmt.setAmount(processAmount(memberAmt.getAmount(), type,
							memBreakUp.getAmount()));
				}
			}

			finalAmt = processAmount(finalAmt, type, billAmt.getAmount());
		}

		Set<BillAmount> billAmts = new HashSet<>();
		billAmts.add(memberBreakUpAmts.isEmpty() ? createBillAmount(finalAmt,
				derivedAmt) : createBillAmount(finalAmt,
				createMemberBreakUpSet(memberBreakUpAmts), derivedAmt));

		return billAmts;
	}

	private Amount processAmount(Amount currentAmt, AdditiveType type,
			Amount newAmt) {
		Amount finalAmt = currentAmt;
		if (type == AdditiveType.MINUS) {
			finalAmt = finalAmt.subtract(newAmt);

		} else {
			finalAmt = finalAmt.add(newAmt);
		}
		return finalAmt;
	}

	@Override
	public Class<AdditiveLogic> interpretedType() {
		return AdditiveLogic.class;
	}

}
