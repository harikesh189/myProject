package com.hcentive.billing.wfm.engine.main;

import java.util.Date;
import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hcentive.billing.account.repository.BillingAccountRunCycleRepository;
import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.security.SystemUserOperation;
import com.hcentive.billing.core.commons.service.cluster.job.ClusteredJob;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;
import com.hcentive.billing.core.commons.vo.ProcessContext;
import com.hcentive.billing.core.commons.vo.ProcessContextUtil;
import com.hcentive.common.inter.service.annotation.EnableInterServiceCall;
import com.hcentive.commons.batch.process.TenantProvider;

@EnableAutoConfiguration
@Configuration
@PropertySources({ @PropertySource("file:${baseDir}/config/properties/db.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"),
		@PropertySource("file:${baseDir}/config/properties/cronJob.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties"),
		@PropertySource("file:${baseDir}/config/properties/log4j.properties"),
		@PropertySource("file:${baseDir}/config/properties/amqp.properties"),
		@PropertySource("file:${baseDir}/config/properties/mongodb.properties") })
@ComponentScan(basePackages = { "com.hcentive.billing", "com.hcentive.billing.core.commons.mongo" })
@EnableJpaRepositories(basePackages = { "com.hcentive.billing.wfm.engine",
		"com.hcentive.billing.core.commons.starter.persistence.repository",
		"com.hcentive.billing.wfm.services.billingrun.repository", "com.hcentive.billing.configuration.repository",
		"com.hcentive.billing.configuration.jpa.repository" }, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EntityScan({ "com.hcentive.billing.core.commons", "com.hcentive.billing.wfm.domain" })
@EnableMongoRepositories(basePackages = { "com.hcentive.billing.core.commons.starter.persistence.repository" })
@EnableInterServiceCall(basePackagesToScan = { "com.hcentive.billing.wfm.service" })
@EnableBatchProcessing
@EnableScheduling
public class BillingEngineInit {

	@Autowired
	private JobStarter jobStarter;

	/**
	 * @param args
	 */
	public static void main(final String[] args) {
		SpringApplication.run(BillingEngineInit.class, args);
	}

	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor() {
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}

	//@Scheduled(fixedDelay = 9000)
	@Scheduled(cron = "${billing.job.run.interval}")
	@SystemUserOperation
	public void triggerBillingJob() throws JobExecutionAlreadyRunningException, JobRestartException,
			JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		jobStarter.triggerJob();
	}
	
}

@Component
class JobStarter {
	
	@Autowired
	private TenantProvider tenantProvider;
	
	@Autowired
	private BillingAccountRunCycleRepository repository;
	
	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	private Job billingJob;
	
	@ClusteredJob(jobName = "Billing Account Run Cycle execution")
	public void triggerJob() throws JobExecutionAlreadyRunningException, JobRestartException,
			JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		//mark all cycles completed
		updateCompletedCycles();
		//initiate job
		JobParametersBuilder builder = new JobParametersBuilder();
		JobParameters jobParameters = builder.addDate("jobDate", new Date(), true).toJobParameters();
		jobLauncher.run(billingJob, jobParameters);
	}
	
	private void updateCompletedCycles() {
		final List<String> tenants = tenantProvider.findAllTenant();
		if (tenants != null) {
			for (String tenent : tenants) {
				if (ProcessContext.get() != null) {
					ProcessContext.clear();
				}

				ProcessContextUtil.buildProcessContext(null, null, tenent,
						null, null);

				repository.updateCompletedCycleStatus();
				repository.updateWaitingCycleStatus();
			}
			if (ProcessContext.get() != null) {
				ProcessContext.clear();
			}
		}
	}
	
}