package com.hcentive.billing.wfm.engine.calculator.vo;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;

public class MemberRateAmount extends RateAmount {

	// Insured MemberId
	private Long insuredMemberId;

	public MemberRateAmount(Amount amount, RateType rateType, String amountCode,
			String amountName, AmountCategory type, Period applicableFor,
			Long insuredMemberId, String desc) {

		super(amount, rateType, amountCode, amountName, type, applicableFor, desc);
		this.insuredMemberId = insuredMemberId;
	}

	public MemberRateAmount(RateAmount rateAmount, Long insuredMemberId) {
		this(rateAmount.getAmount(), rateAmount.getRateType(), rateAmount.getAmountCode(),
				rateAmount.getAmountName(), rateAmount.getAmountCategory(),
				rateAmount.getApplicableFor(), insuredMemberId, rateAmount.getDescription());
	}

	public Long getInsuredMemberId() {
		return insuredMemberId;
	}

	public String toString() {
		return "member: " + insuredMemberId + ", "
				+ super.toString();
	}

}
