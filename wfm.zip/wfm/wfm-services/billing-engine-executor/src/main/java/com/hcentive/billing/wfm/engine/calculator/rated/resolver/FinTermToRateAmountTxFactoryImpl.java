package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.wfm.api.FinancialTerm;

@Component
public class FinTermToRateAmountTxFactoryImpl extends SpringBackedAbstractFactory<FinancialTermToRateAmountTransformer>
		implements FinancialTermToRateAmountTxFactory {

	private static final Logger LOGGER = LoggerFactory.getLogger(FinTermToRateAmountTxFactoryImpl.class);

	@Override
	public FinancialTermToRateAmountTransformer getTransformer(FinancialTerm<?> finTerm) {

		for (FinancialTermToRateAmountTransformer tx : registeredInstances()) {
			if (tx.canHandle(finTerm)) {
				return tx;
			}
		}

		LOGGER.error("No Financial Term to Rate Amount transformer found for financial term type [{}] :: {}", 
				finTerm.getClass().getName(), finTerm);
		
		throw new IllegalStateException("No Financial Term to Rate Amount transformer found for financial term type ["
				+ finTerm.getClass().getName() + "]");
	}

	@Override
	protected Class<FinancialTermToRateAmountTransformer> lookupForType() {
		return FinancialTermToRateAmountTransformer.class;
	}

}
