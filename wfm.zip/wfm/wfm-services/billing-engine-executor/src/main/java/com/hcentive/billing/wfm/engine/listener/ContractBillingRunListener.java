package com.hcentive.billing.wfm.engine.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.hcentive.billing.commons.workflow.annotation.Activity;
import com.hcentive.billing.core.commons.event.EventHandler;
import com.hcentive.billing.core.commons.exception.BillingException;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillingContractRun;
import com.hcentive.billing.wfm.engine.BillingRunExecutorService;

@Component
public class ContractBillingRunListener implements EventHandler {

	@Autowired
	private BillingRunExecutorService executor;
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ContractBillingRunListener.class);

	@Activity(stepName = "runCalculatorsOnBillingContractRun")
	public String handleContractRunEvent(String contractRunIdentity) {
		
		BillingContractRun executedContractRun = executor.executeBillingRun(contractRunIdentity);
		if (executedContractRun == null || executedContractRun.getBillRunStatus() == RunStatus.FAILED) {
			throw new BillingException("Failed to run calculators on billing contract run: " + contractRunIdentity);
		}
		return executedContractRun.getIdentity();
	}

}
