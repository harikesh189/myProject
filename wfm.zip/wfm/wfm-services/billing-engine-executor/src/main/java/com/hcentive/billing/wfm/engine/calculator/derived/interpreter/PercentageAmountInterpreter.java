package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.MemberBreakUpAmountAware;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmount;

@Component
public class PercentageAmountInterpreter extends
		AbstractDerivedAmountInterpreter implements
		DerivedAmountInterpreter<PercentageLogic> {

	@Override
	public Set<BillAmount> interpretDerivedAmount(
			DerivedAmount<PercentageLogic> amount) {

		double percentage = amount.getDerivationLogic().getPercentage();

		Set<BillAmount> deriveFrom = amount.getDeriveFrom();
		Set<BillAmount> derivedAmounts = new HashSet<>();

		for (BillAmount deriveFromAmt : deriveFrom) {

			Set<MemberBreakUp> derivedMemBreakUp = new HashSet<>();

			if (deriveFromAmt instanceof MemberBreakUpAmountAware) {
				Set<MemberBreakUp> memBreakUps = ((MemberBreakUpAmountAware) deriveFromAmt)
						.memberBreakUpAmounts();
				for (MemberBreakUp memBreakUp : memBreakUps) {
					derivedMemBreakUp.add(new MemberBreakUp(memBreakUp.getInsuredMemberId(), 
							processAmount(memBreakUp.getAmount(), percentage), 
							memBreakUp.getCoveragePeriod()));
				}
			}

			Amount finalAmt = processAmount(deriveFromAmt.getAmount(),
					percentage);
			derivedAmounts.add(derivedMemBreakUp.isEmpty() ? createBillAmount(
					finalAmt, amount) : createBillAmount(finalAmt,
					derivedMemBreakUp, amount));
		}

		return derivedAmounts;
	}

	private Amount processAmount(Amount amount, double percentage) {
		return amount.multiply(percentage / 100);
	}

	@Override
	public Class<PercentageLogic> interpretedType() {
		return PercentageLogic.class;
	}

}
