package com.hcentive.billing.wfm.engine.calculator.vo;

import java.math.BigDecimal;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;

public class RateAmount {
	
	public static enum RateType { MONTHLY, FIXED }

	private RateType rateType;
	
	private Amount amount;

	private String amountCode;

	private String amountName;

	private AmountCategory amountCategory;

	private Period applicableFor;
	
	private String description;

	public RateAmount(Amount amount, RateType rateType, String amountCode, String amountName,
			AmountCategory amtCategory, Period applicableFor, String description) {
		this.amount = amount;
		this.rateType = rateType;
		this.amountCode = amountCode;
		this.amountName = amountName;
		this.applicableFor = applicableFor;
		this.amountCategory = amtCategory;
		this.description = description;
	}

	public Amount getAmount() {
		return amount;
	}

	public String getAmountCode() {
		return amountCode;
	}

	public RateType getRateType() {
		return rateType;
	}

	public String getAmountName() {
		return amountName;
	}

	public AmountCategory getAmountCategory() {
		return amountCategory;
	}

	public Period getApplicableFor() {
		return applicableFor;
	}

	public void setAmount(Amount monthlyRate) {
		this.amount = monthlyRate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setApplicableFor(Period applicableFor) {
		this.applicableFor = applicableFor;
	}

	public BillAmount toBillAmount(Amount finalAmt, Period coveragePeriod) {
		return new BillAmount(amountCode, amountName,
				finalAmt == null ? Amount.newAmount(BigDecimal.ZERO) : finalAmt,
				amountCategory, AmountGroup.DEFAULT, description, coveragePeriod, null);
	}

	public String toString() {
		return "amount code: " + amountCode + ", monthly rate: " + amount
				+ ", category: " + amountCategory + ", applicable for: "
				+ applicableFor;
	}
}
