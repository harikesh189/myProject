package com.hcentive.billing.wfm.engine.calculator.derived;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.AmountCalculator;
import com.hcentive.billing.wfm.engine.calculator.CalculatorExecutionOrder;
import com.hcentive.billing.wfm.engine.calculator.derived.exec.BillAmountDependencyResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.exec.DerivedAmountResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.interpreter.DerivedAmountInterpreter;
import com.hcentive.billing.wfm.engine.calculator.derived.interpreter.DerivedAmountInterpreterFactory;
import com.hcentive.billing.wfm.engine.calculator.derived.resolver.DerivedAmountDefinitionResolver;
import com.hcentive.billing.wfm.engine.calculator.derived.resolver.DerivedAmountDefinitionResolverRegistry;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmountDefinition;
import com.hcentive.billing.wfm.engine.multipass.MultipassExecutor;
import com.hcentive.billing.wfm.engine.multipass.MultipassTask;
import com.hcentive.billing.wfm.engine.multipass.StateUpdater;
import com.hcentive.billing.wfm.engine.multipass.TaskResultAggregator;

public class DerivedAmountCalculator implements AmountCalculator {

	private static final Logger logger = LoggerFactory.getLogger(DerivedAmountCalculator.class);

	@Autowired
	private DerivedAmountDefinitionResolverRegistry registry;

	@Autowired
	private DerivedAmountInterpreterFactory interpreterFactory;

	@Autowired
	private BillAmountDependencyResolver billAmountDependencyResolver;

	@Autowired
	private MultipassExecutor<BillRunContext, BillRunContext, DerivedAmount<?>> multipassExecutor;

	@Override
	public String name() {
		return "Derived Amount Calculator";
	}

	@Override
	public float executionOrder() {
		return CalculatorExecutionOrder.DERIVED_AMT_CALC_ORDER;
	}

	@Override
	public void calculateAndAddAmounts(BillRunContext runCtx) {

		final Set<DerivedAmountDefinition<?>> resolvedDefs = buildDerivedAmountDefinitions(runCtx);

		final Set<MultipassTask<BillRunContext, BillRunContext, DerivedAmount<?>>> derivedAmtResolvers = new HashSet<>();

		for (final DerivedAmountDefinition<?> definition : resolvedDefs) {
			final DerivedAmountResolver resolver = new DerivedAmountResolver(definition, billAmountDependencyResolver);
			derivedAmtResolvers.add(resolver);
		}

		final DerivedAmountResultAggregator resultAggregator = new DerivedAmountResultAggregator(runCtx, interpreterFactory);

		multipassExecutor.execute(runCtx, runCtx, derivedAmtResolvers, resultAggregator, new StateUpdater<BillRunContext, DerivedAmount<?>>() {

			@Override
			public BillRunContext update(BillRunContext currentState, DerivedAmount<?> result) {
				// updates happen in result aggregator, hence state
				// updater does nothing
				return currentState;
			}

		});

	}

	private Set<DerivedAmountDefinition<?>> buildDerivedAmountDefinitions(BillRunContext billRunCtx) {

		logger.debug("Resolving derived amount definitions for contract: {}", billRunCtx.contract().getIdentity());

		final Set<DerivedAmountDefinition<?>> definitions = new HashSet<>();

		for (final DerivedAmountDefinitionResolver resolver : registry.registeredResolvers()) {

			final Set<DerivedAmountDefinition<?>> resolvedDefs = resolver.resolveDefinitions(billRunCtx);

			if (resolvedDefs != null && !resolvedDefs.isEmpty()) {
				logger.debug("Resolver: {}, derived amount defs: {}", resolver.name(), resolvedDefs);
				definitions.addAll(resolvedDefs);

			} else {
				logger.debug("Resolver: {}, definition count: {}", resolver.name(), 0);
			}
		}

		return definitions;
	}

	private static class DerivedAmountResultAggregator implements TaskResultAggregator<DerivedAmount<?>, BillRunContext> {

		private static final Logger logger = LoggerFactory.getLogger(DerivedAmountResultAggregator.class);

		private final BillRunContext runCtx;

		private final DerivedAmountInterpreterFactory factory;

		private DerivedAmountResultAggregator(BillRunContext runCtx, DerivedAmountInterpreterFactory factory) {

			this.runCtx = runCtx;
			this.factory = factory;
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		@Override
		public void aggregateResult(DerivedAmount<?> result) {

			final DerivedAmountInterpreter interpreter = factory.getInterpreter(result.getDerivationLogic().getClass());

			final Set<BillAmount> billAmounts = interpreter.interpretDerivedAmount(result);

			for (final BillAmount billAmt : billAmounts) {
				logger.debug("Adding derived Bill Amount: {}, value: {}", billAmt.getCode(), billAmt.getAmount().getValue());
				runCtx.addBillAmount(billAmt);
			}

		}

		@Override
		public BillRunContext output() {
			return runCtx;
		}

	}

}
