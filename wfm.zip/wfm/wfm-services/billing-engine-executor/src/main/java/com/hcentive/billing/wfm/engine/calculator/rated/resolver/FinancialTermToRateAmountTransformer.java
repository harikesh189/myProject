package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public interface FinancialTermToRateAmountTransformer {

	RateAmount transform(FinancialTerm<?> financialTerm);
	
	boolean canHandle(FinancialTerm<?> finTerm);
	
}
