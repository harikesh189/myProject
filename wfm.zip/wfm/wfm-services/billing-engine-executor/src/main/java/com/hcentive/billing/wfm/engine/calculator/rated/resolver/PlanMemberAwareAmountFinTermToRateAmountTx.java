package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTermImpl;
import com.hcentive.billing.wfm.api.PlanAndMemberAwareFinancialTerm;
import com.hcentive.billing.wfm.engine.calculator.vo.MemberAndPlanAwareRateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.MemberRateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount.RateType;

@Component
public class PlanMemberAwareAmountFinTermToRateAmountTx implements FinancialTermToRateAmountTransformer {

	private static final Logger LOGGER = LoggerFactory.getLogger(PlanMemberAwareAmountFinTermToRateAmountTx.class);

	@Autowired
	private FinancialTermToRateAmountTxFactory factory;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public RateAmount transform(FinancialTerm<?> finTerm) {

		if (canHandle(finTerm)) {

			final PlanAndMemberAwareFinancialTerm<Amount> financialTerm = (PlanAndMemberAwareFinancialTerm<Amount>) finTerm;

			final List<MemberRateAmount> memberRateAmts = new ArrayList<>();

			RateType amountRateType = RateType.MONTHLY;

			for (final MemberAwareFinancialTerm<Amount> memberAwareFinancialTerm : financialTerm.value()) {

				final RateAmount genericRateAmount = factory.getTransformer(memberAwareFinancialTerm).transform(memberAwareFinancialTerm);
				genericRateAmount.setApplicableFor(Period.getIntersection(financialTerm.effectivePeriod(), genericRateAmount.getApplicableFor()));

				final MemberRateAmount memberRateAmount = new MemberRateAmount(genericRateAmount,
				        ((MemberAwareFinancialTermImpl) memberAwareFinancialTerm).getInsuredMemberId());

				memberRateAmts.add(memberRateAmount);

				amountRateType = genericRateAmount.getRateType();
			}

			final MemberAndPlanAwareRateAmount rateAmount = new MemberAndPlanAwareRateAmount(null, amountRateType, financialTerm.code(), financialTerm.name(),
			        AmountCategory.parse(financialTerm.type()), financialTerm.effectivePeriod(), financialTerm.insuranceCoverage(), financialTerm.description());

			for (final MemberRateAmount memRateAmt : memberRateAmts) {
				rateAmount.addMemberRateAmount(memRateAmt, memRateAmt.getInsuredMemberId());
			}

			return rateAmount;
		}

		LOGGER.error("Cannot handle financial term of type [{}] :: {}", finTerm.getClass().getName(), finTerm);
		throw new IllegalArgumentException("Can not handle financial term of type [" + finTerm.getClass().getName() + "]");

	}

	@Override
	public boolean canHandle(FinancialTerm<?> finTerm) {

		return finTerm instanceof PlanAndMemberAwareFinancialTerm<?>

		&& ((PlanAndMemberAwareFinancialTerm<?>) finTerm).termValueType() == Amount.class;
	}

}
