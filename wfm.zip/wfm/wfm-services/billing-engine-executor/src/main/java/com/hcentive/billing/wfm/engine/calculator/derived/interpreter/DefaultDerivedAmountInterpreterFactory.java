package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;

@SuppressWarnings("rawtypes")
@Component
public class DefaultDerivedAmountInterpreterFactory extends
		SpringBackedAbstractFactory<DerivedAmountInterpreter> implements
		DerivedAmountInterpreterFactory {

	@SuppressWarnings("unchecked")
	@Override
	public <DL> DerivedAmountInterpreter<DL> getInterpreter(
			Class<DL> derivationLogicType) {
		for (DerivedAmountInterpreter<DL> intrptr : registeredInstances()) {
			if (intrptr.interpretedType() == derivationLogicType) {
				return intrptr;
			}
		}
		throw new IllegalStateException(
				"No derived amount interpreter found for ["
						+ derivationLogicType + "]");
	}

	@Override
	protected Class<DerivedAmountInterpreter> lookupForType() {
		return DerivedAmountInterpreter.class;
	}

}
