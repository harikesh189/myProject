package com.hcentive.billing.wfm.engine.calculator.rated.premium;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.Premium;

public interface PremiumInterpreter<T extends Premium> {

	FinancialTerm<?> determinePremiumFinancialTerm(Premium premium,
			Period premiumApplicablePeriod);

	Class<T> interpretedType();

}
