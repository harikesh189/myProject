package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class FlatWriteOnResolver extends MonthlyFlatFinancialTermResolver {

	@Override
	public String name() {
		return "Flat Write On Rated Amount Resolver";
	}

	@Override
	protected String financialTermType() {
		return ConfigType.WRITE_ON.toString();
	}

	@Override
	protected AmountCategory getAmountType() {
		return AmountCategory.WRITE_ON;
	}

}
