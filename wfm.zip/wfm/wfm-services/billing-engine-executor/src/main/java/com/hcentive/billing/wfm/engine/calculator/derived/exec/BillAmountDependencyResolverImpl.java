package com.hcentive.billing.wfm.engine.calculator.derived.exec;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmountDefinition;
import com.hcentive.billing.wfm.engine.calculator.vo.PlanAwareDerivedAmountDefinition;

@Component
public class BillAmountDependencyResolverImpl implements
		BillAmountDependencyResolver {

	private static final Logger logger = LoggerFactory
			.getLogger(BillAmountDependencyResolverImpl.class);

	@Override
	public Set<BillAmount> findBillAmounts(
			DerivedAmountDefinition<?> definition, BillRunContext billRunContext) {

		Set<BillAmount> deriveFromBillAmts = new HashSet<>();

		Set<BillAmount> allAmounts = findAllBillAmounts(billRunContext,
				definition);

		for (String deriveFromAmtCode : definition.getDerivedFrom()) {

			logger.debug("Find bill amount for code: {}", deriveFromAmtCode);

			boolean found = false;

			if (allAmounts != null) {

				for (BillAmount billAmt : allAmounts) {

					if (billAmt.getCode().equals(deriveFromAmtCode)) {
						deriveFromBillAmts.add(billAmt);
						found = true;
						break;
					}
				}
			}

			if (!found) {
				logger.info("Bill amount not found for code: {}",
						deriveFromAmtCode);
			}

		}

		return deriveFromBillAmts;
	}

	protected Set<BillAmount> findAllBillAmounts(BillRunContext billRunContext,
			DerivedAmountDefinition<?> definition) {

		if (definition instanceof PlanAwareDerivedAmountDefinition<?>) {
			return findAllBillAmounts(billRunContext,
					(PlanAwareDerivedAmountDefinition<?>) definition);
		}

		logger.debug("Retrieving all contract amounts for derived "
				+ "amount code: {}", definition.getAmountCode());

		return billRunContext.getContractAmounts();
	}

	protected Set<BillAmount> findAllBillAmounts(BillRunContext billRunContext,
			PlanAwareDerivedAmountDefinition<?> definition) {

		Long planId = definition.insuranceCoverage();

		logger.debug("Retrieving all amounts for plan: {}, and derived amount "
				+ "code: {}", planId, definition.getAmountCode());

		return billRunContext.getPlanAmounts(planId);
	}
}
