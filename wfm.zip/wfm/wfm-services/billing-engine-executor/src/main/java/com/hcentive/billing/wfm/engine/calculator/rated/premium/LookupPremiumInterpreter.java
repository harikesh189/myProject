package com.hcentive.billing.wfm.engine.calculator.rated.premium;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.Premium;
import com.hcentive.billing.wfm.domain.contract.LookUpPremium;

@Component
public class LookupPremiumInterpreter implements
		PremiumInterpreter<LookUpPremium> {

	@Override
	public FinancialTerm<?> determinePremiumFinancialTerm(Premium premium,
			Period applicableFor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<LookUpPremium> interpretedType() {
		return LookUpPremium.class;
	}

}
