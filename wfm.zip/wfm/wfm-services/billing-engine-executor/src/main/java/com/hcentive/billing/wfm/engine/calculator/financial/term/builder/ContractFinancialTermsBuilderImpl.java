/**
 *
 */
package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import java.util.Collection;
import java.util.LinkedList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.ContractFinancialTermsBuilder;
import com.hcentive.billing.wfm.domain.contract.ContractFinancialTermsBuilderProvider;
import com.hcentive.billing.wfm.domain.contract.FinancialTermBuilder;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.domain.schedule.cycle.RunSegment.RunType;

@Component
public class ContractFinancialTermsBuilderImpl extends SpringBackedAbstractFactory<FinancialTermBuilder> implements ContractFinancialTermsBuilder {
	private static final Logger LOGGER = LoggerFactory.getLogger(ContractFinancialTermsBuilderImpl.class);

	public ContractFinancialTermsBuilderImpl() {
		ContractFinancialTermsBuilderProvider.registerFinancialTermsBuilder(this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Collection<FinancialTerm<?>> buildFinancialTerms(final BillRunContext billRunContext) {

		final Collection<FinancialTerm<?>> finTerms = new LinkedList<FinancialTerm<?>>();

		for (final FinancialTermBuilder financialTermBuilder : this.registeredInstances()) {

			if (financialTermBuilder.canHandle(billRunContext)) {

				final BillingAccount billingAccount = billRunContext.getBillingContractRun().getBillingAccountRunCycle().getBillingAccount();
				final BillingAccount associatedbillingAccount = billRunContext.getBillingContractRun().getAssociatedBillingAccount();
				LOGGER.debug("Building financial terms for billing account {}, associated billing account {} and billRunContext {}", billingAccount.getIdentity(), associatedbillingAccount.getIdentity(),billRunContext.getIdentity());
				if(billRunContext.getBillingContractRun().getRunType() == RunType.VOID_ORIGINAL)
					finTerms.addAll(financialTermBuilder.build(associatedbillingAccount, billRunContext.getBillingContractRun().getContract(),
						billRunContext.getCoveragePeriod()));
				else
					finTerms.addAll(financialTermBuilder.build(billingAccount, billRunContext.getBillingContractRun().getContract(),
							billRunContext.getCoveragePeriod()));
			}
		}

		return finTerms;
	}

	@Override
	protected Class<FinancialTermBuilder> lookupForType() {
		return FinancialTermBuilder.class;
	}
}
