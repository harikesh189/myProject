package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class FlatTaxResolver extends MonthlyFlatFinancialTermResolver {

	@Override
	public String name() {
		return "Flat Tax Rated Amount Resolver";
	}

	@Override
	protected String financialTermType() {
		return ConfigType.TAX.toString();
	}

	@Override
	protected AmountCategory getAmountType() {
		return AmountCategory.TAX;
	}

}
