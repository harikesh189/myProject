package com.hcentive.billing.wfm.engine.calculator.prorate.handler;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.engine.calculator.prorate.ProRateHandler;

public abstract class AbstractProRateHandler implements ProRateHandler {

	private static final Logger logger = LoggerFactory
			.getLogger(AbstractProRateHandler.class);

	public AbstractProRateHandler() {
		super();
	}

	@Override
	public Amount proRate(BillingConfigProRate proRateConfig,
			Amount monthlyAmt, Period applicablePeriod) {

		double multiplier = calcAmountMultiplier(applicablePeriod,
				proRateConfig);

		BigDecimal proRatedPremium = monthlyAmt.getValue().multiply(
				new BigDecimal(multiplier));
		Amount proRatedAmt = new Amount(proRatedPremium,
				monthlyAmt.getCurrency());

		logger.debug(
				"pro-rating - monthly amount: {}, applicable period: {}, multiplier: {}, "
						+ "pro-rated amount: {}", monthlyAmt, applicablePeriod,
				multiplier, proRatedAmt);

		return proRatedAmt;
	}

	protected double calcAmountMultiplier(Period amtApplicablePeriod,
			BillingConfigProRate proRateConfig) {

		double chargeableMonths = 0.0;

		// determine full months and partial months
		// then for partial months, determine the multiplying factor

		Date beginsOn = amtApplicablePeriod.getBeginsOn().getDate();
		Date endsOn = amtApplicablePeriod.getEndsOn().getDate();

		int noOfMonths = DateUtility.numberOfMonths(beginsOn, endsOn);

		if (DateUtility.isMonthStartDate(beginsOn)
				&& DateUtility.isMonthEndDate(endsOn)) {
			chargeableMonths = noOfMonths;

		} else {

			if (noOfMonths > 1) {

				// check if the start month is partial
				if (!DateUtility.isMonthStartDate(beginsOn)) {
					// partial start month
					chargeableMonths += calcPartialMonthAmountMultiplier(
							beginsOn, null, proRateConfig);

				} else {
					chargeableMonths++;
				}

				// check if the end month is partial
				if (!DateUtility.isMonthEndDate(endsOn)) {
					chargeableMonths += calcPartialMonthAmountMultiplier(null,
							endsOn, proRateConfig);
				} else {
					chargeableMonths++;
				}

				// add the months in between the start month and end month
				chargeableMonths += (noOfMonths - 2); // subtract 2 to exclude
														// start and end month

			} else if (noOfMonths == 1) {
				// find multiplying factor for coverage days
				chargeableMonths += calcPartialMonthAmountMultiplier(beginsOn,
						endsOn, proRateConfig);
			}
		}

		return chargeableMonths;
	}

	protected abstract double calcPartialMonthAmountMultiplier(
			Date monthCoverageStartDt, Date monthCoverageEndDt,
			BillingConfigProRate proRateConfig);

}