package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import com.hcentive.billing.wfm.domain.billingpolicy.FinancialCharge;

public interface FinChargeToFinTermTxFactory {

	@SuppressWarnings("rawtypes")
	FinancialChargeToFinancialTermTransformer getTransformer(FinancialCharge fc);
	
}
