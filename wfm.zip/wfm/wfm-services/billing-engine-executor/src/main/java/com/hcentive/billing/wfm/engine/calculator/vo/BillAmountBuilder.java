package com.hcentive.billing.wfm.engine.calculator.vo;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.InsuranceCoverageAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAndPlanAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAwareBillAmount;

public class BillAmountBuilder {

	public static InsuranceCoverageAwareBillAmount makePlanAware(
			BillAmount amount, Long planId) {
		return new InsuranceCoverageAwareBillAmount(planId, amount.getCode(),
				amount.getName(), amount.getAmountCategory(),
				amount.getAmount(), amount.getAmountGroup(), 
				amount.getDescription(), amount.getCoveragePeriod(),
				amount.getAssociatedDate());
	}

	public static MemberAndPlanAwareBillAmount makePlanAware(
			MemberAwareBillAmount amount, Long planId) {

		MemberAndPlanAwareBillAmount billAmount = new MemberAndPlanAwareBillAmount(
				planId, amount.getCode(), amount.getName(), amount.getAmount(),
				amount.getAmountCategory(), amount.getDescription(), amount.getCoveragePeriod(),
				amount.getAmountGroup(), amount.memberBreakUpAmounts(), null);

		return billAmount;
	}

}
