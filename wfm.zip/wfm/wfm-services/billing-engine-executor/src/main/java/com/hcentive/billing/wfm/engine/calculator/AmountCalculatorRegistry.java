package com.hcentive.billing.wfm.engine.calculator;

import java.util.Collection;

public interface AmountCalculatorRegistry {

	Collection<AmountCalculator> registeredCalculators();

}
