package com.hcentive.billing.wfm.engine;

import javax.transaction.Transactional;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.util.Permission;
import com.hcentive.billing.wfm.api.enumeration.runcycle.RunStatus;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillingContractRun;
import com.hcentive.billing.wfm.services.billingrun.repository.BillingContractRunRepository;
import com.hcentive.billing.wfm.services.billingrun.service.BillContractRunCalculator;

@Component
public class BillingRunExecutorServiceImpl implements BillingRunExecutorService {

	private static final Logger logger = LoggerFactory.getLogger(BillingRunExecutorServiceImpl.class);

	@Autowired
	private BillingContractRunRepository contractRunRepository;

	@Autowired
	private BillContractRunCalculator billContractRunCalculator;

	@RequiresPermissions(value = Permission.EXECUTE_BILL_RUN)
	@Override
	@Transactional
	public BillingContractRun executeBillingRun(String contractRunIdentity) {

		logger.debug("starting billing contract run: {}", contractRunIdentity);

		BillingContractRun contractRun = null;
		
		try {
			
			contractRun = contractRunRepository.findByIdentity(contractRunIdentity);
			
			contractRun = billContractRunCalculator.calculator(contractRun);
			contractRun = saveAndPostProcessCalcResult(contractRun);
			
		} catch (Throwable t) {
			logger.error("Error in bill amount calculators", t);
			if (contractRun != null) {
				contractRun.setBillRunStatus(RunStatus.FAILED);
				contractRunRepository.save(contractRun);
			}
		}

		return contractRun;
		
	}

	public BillingContractRun saveAndPostProcessCalcResult(BillingContractRun contractRun) {
		
		contractRun = contractRunRepository.save(contractRun);

		logger.debug("Billing Run Execution completed for contract: {}", contractRun.getContract().getIdentity());

		//EventUtils.publish(new Event<BillingContractRun>(EventType.CONTRACT_BILLING_CALC_COMPLETED, contractRun));

		for (final BillRunContext brc : contractRun.getBillRunContexts()) {
			
			if (brc.getBillRunData() != null && brc.getBillRunData().getContractBillingPolicy() != null) {
			
				if (!brc.getBillRunData().getContractBillingPolicy().isBillRunExecuted()) {
					EventUtils.publish(new Event<String>(EventType.BILLING_POLICY_FIRST_TIME_USAGE, 
							brc.getBillRunData().getContractBillingPolicy().getIdentity()));
					break;
				}
			}
		}
		
		return contractRun;
	}

}