package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.FinancialTermDecorator;
import com.hcentive.billing.wfm.api.InsuranceCoverageAware;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.engine.calculator.vo.MemberAwareRateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.MemberRateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.PlanAwareRateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

@Component
public class FinTermDecoratorToRateAmountTx implements FinancialTermToRateAmountTransformer {

	private static final Logger LOGGER = LoggerFactory.getLogger(FinTermDecoratorToRateAmountTx.class);

	@Autowired
	private FinancialTermToRateAmountTxFactory factory;

	@Override
	public RateAmount transform(FinancialTerm<?> finTerm) {

		if (canHandle(finTerm)) {
			FinancialTermDecorator<?> finTermDecorator = (FinancialTermDecorator<?>) finTerm;
			FinancialTerm<?> wrappedFinTerm = finTermDecorator.getWrappedFinancialTerm();
			FinancialTermToRateAmountTransformer tx = factory.getTransformer(wrappedFinTerm);
			RateAmount rateAmount = tx.transform(wrappedFinTerm);
			rateAmount = decorateRateAmount(finTermDecorator, rateAmount);
			return rateAmount;
		}

		LOGGER.error("Cannot handle financial term of type [{}] :: {}", finTerm.getClass().getName(), finTerm);
		throw new IllegalArgumentException("Can not handle financial term of type [" + finTerm.getClass().getName()
				+ "]");
	}

	@Override
	public boolean canHandle(FinancialTerm<?> finTerm) {
		return finTerm instanceof FinancialTermDecorator;
	}

	@SuppressWarnings("unchecked")
	private RateAmount decorateRateAmount(FinancialTerm<?> decoratedFinTerm, RateAmount rateAmount) {
		
		if (decoratedFinTerm instanceof InsuranceCoverageAware && !(rateAmount instanceof InsuranceCoverageAware)) {
			return new PlanAwareRateAmount(rateAmount.getAmount(), rateAmount.getRateType(),
					rateAmount.getAmountCode(), rateAmount.getAmountName(), rateAmount.getAmountCategory(),
					rateAmount.getApplicableFor(), ((InsuranceCoverageAware) decoratedFinTerm).insuranceCoverage(),
					rateAmount.getDescription());
		}

		if (decoratedFinTerm instanceof MemberAwareFinancialTerm && !(rateAmount instanceof MemberAwareRateAmount)) {
			return new MemberRateAmount(rateAmount, ((MemberAwareFinancialTerm<?>) decoratedFinTerm).getInsuredMemberId());
		}
		return rateAmount;
	}

}
