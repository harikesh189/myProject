/**
 *
 */
package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.util.EffectivityUtil;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTermImpl;
import com.hcentive.billing.wfm.api.PlanAndMemberFinancialTermImpl;
import com.hcentive.billing.wfm.domain.Premium;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.contract.ContractType;
import com.hcentive.billing.wfm.domain.contract.Eligibility;
import com.hcentive.billing.wfm.domain.contract.EligibilityContract;
import com.hcentive.billing.wfm.domain.contract.EligibilityCoverage;
import com.hcentive.billing.wfm.domain.contract.EligibleMemberCoverage;
import com.hcentive.billing.wfm.domain.contract.EnrolledPlan;
import com.hcentive.billing.wfm.domain.contract.FinancialTermBuilder;
import com.hcentive.billing.wfm.domain.contract.PremiumCode;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.rated.premium.PremiumInterpreter;
import com.hcentive.billing.wfm.engine.calculator.rated.premium.PremiumInterpreterFactory;

/**
 * @author Dikshit.Vaid
 */
@Component
public class EligibilityPremiumFinancialTermBuilder implements FinancialTermBuilder {

	private static final Logger LOGGER = LoggerFactory.getLogger(EligibilityPremiumFinancialTermBuilder.class);

	@Autowired
	private PremiumInterpreterFactory factory;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Collection<FinancialTerm<?>> build(BillingAccount billingAccount,
	        final FinancialContract<ContractType, ?> eligibilityContract, final Period effectivePeriod) {

		final Collection<FinancialTerm<?>> premiumFinancialTerms = new HashSet<FinancialTerm<?>>();

		if (eligibilityContract instanceof EligibilityContract) {
			final EligibilityContract elgContract = (EligibilityContract) eligibilityContract;
			final Eligibility eligibility = elgContract.getEligibility();

			for (final EligibilityCoverage eligibilityCoverage : eligibility.getEnrolledPlans()) {
				
				if (eligibilityCoverage instanceof EnrolledPlan) {
					
					final EnrolledPlan enrolledPlan = (EnrolledPlan)eligibilityCoverage;

					LOGGER.debug("Checking plan {} effectivitiy, bill period: {}, and plan period: {}",
							enrolledPlan.getHealthPlan().getExternalId(), effectivePeriod,
							enrolledPlan.effectivePeriod());

					if (EffectivityUtil.isCoverageEffective(enrolledPlan, effectivePeriod)) {

						final Map<PremiumCode, String> premiumCodeToNameMap = new HashMap<>();
						final Map<PremiumCode, Set<MemberAwareFinancialTerm<?>>> memberPremiumBreakUpsMap = new HashMap<>();

						for (final EligibleMemberCoverage memCoverage : enrolledPlan.getMemberCoverages()) {

							if (EffectivityUtil.isCoverageEffective(memCoverage, effectivePeriod)) {

								for (final Premium premium : memCoverage.getAllPremiums()) {
									final PremiumInterpreter<?> premiumIntrprtr = this.factory
											.getInterpreter(premium.getClass());

									final Period applicablePeriod = Period.getIntersection(
											elgContract.getContractInfo().getEffectivePeriod(), Period.getIntersection(
													enrolledPlan.effectivePeriod(), memCoverage.getCoverage()));

									final FinancialTerm<?> memberPremiumFinTerm = premiumIntrprtr
											.determinePremiumFinancialTerm(premium, applicablePeriod);

									Set<MemberAwareFinancialTerm<?>> memberAwareFinancialTerms = memberPremiumBreakUpsMap
											.get(premium.getCode());
									if (memberAwareFinancialTerms == null) {
										memberAwareFinancialTerms = new HashSet<MemberAwareFinancialTerm<?>>();
										memberPremiumBreakUpsMap.put(premium.getCode(), memberAwareFinancialTerms);
										premiumCodeToNameMap.put(premium.getCode(), premium.getPremiumName());
									}
									memberAwareFinancialTerms.add(new MemberAwareFinancialTermImpl(memberPremiumFinTerm,
											memCoverage.getInsuredMember().getId()));
								}
							}
						}

						final Period finTermEffPeriod = Period.getIntersection(
								elgContract.getContractInfo().getEffectivePeriod(), enrolledPlan.effectivePeriod());
						for (final Entry<PremiumCode, Set<MemberAwareFinancialTerm<?>>> memberPremiumBreakUp : memberPremiumBreakUpsMap
								.entrySet()) {
							final FinancialTerm<?> premiumFinancialTerm = new PlanAndMemberFinancialTermImpl(
									AmountCategory.PREMIUM.name(), memberPremiumBreakUp.getKey().name(),
									premiumCodeToNameMap.get(memberPremiumBreakUp.getKey()), finTermEffPeriod,
									enrolledPlan.getId(), memberPremiumBreakUp.getValue(), "Premium");
							premiumFinancialTerms.add(premiumFinancialTerm);
						}

						LOGGER.debug("Fetched premimum financial term : {}", premiumFinancialTerms);
					}
				}
			}
		}

		return premiumFinancialTerms;
	}

	@Override
	public boolean canHandle(BillRunContext runContext) {
		return runContext != null && runContext.getBillingContractRun().getContract() instanceof EligibilityContract;
	}

}
