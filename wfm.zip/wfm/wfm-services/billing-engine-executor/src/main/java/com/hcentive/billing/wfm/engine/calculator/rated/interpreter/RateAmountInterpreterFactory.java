package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public interface RateAmountInterpreterFactory {

	@SuppressWarnings("rawtypes")
	<T extends RateAmount> RateAmountInterpreter getInterpreter(
			Class<T> rateAmountType);

}
