package com.hcentive.billing.wfm.engine.calculator.financial.term;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.policies.api.FinancialChargeResolver;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;

public abstract class FinancialTermResolver {

	@Autowired
	private FinancialChargeResolver financialChargeResolver;

	public Set<FinancialTerm<?>> resolveFinancialTerm(final BillRunContext runCtx) {

		final Set<FinancialTerm<?>> finTerms = new HashSet<>();

		final Collection<FinancialTerm<?>> financialTerms = runCtx.getBillRunData().financialTerms();

		for (final FinancialTerm<?> financialTerm : financialTerms) {
			if (financialTerm.type().equals(this.financialTermType())) {
				finTerms.add(financialTerm);
			}
		}

		return finTerms;
	}

	protected abstract String financialTermType();

}
