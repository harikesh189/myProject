package com.hcentive.billing.wfm.engine.calculator.vo;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.InsuranceCoverageAware;

public class PlanAwareRateAmount extends RateAmount implements
		InsuranceCoverageAware {

	private Long planId;

	public PlanAwareRateAmount(Amount amount, RateType rateType, String amountCode,
			String amountName, AmountCategory type, Period applicableFor,
			Long planId, String desc) {
		super(amount, rateType, amountCode, amountName, type, applicableFor, desc);
		this.planId = planId;
	}

	@Override
	public Long insuranceCoverage() {
		return planId;
	}

	public String toString() {
		return "plan: " + planId + ", " + super.toString();
	}
}
