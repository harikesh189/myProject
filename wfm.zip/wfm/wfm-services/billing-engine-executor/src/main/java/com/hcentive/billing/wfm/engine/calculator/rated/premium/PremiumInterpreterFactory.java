package com.hcentive.billing.wfm.engine.calculator.rated.premium;

import com.hcentive.billing.wfm.domain.Premium;

public interface PremiumInterpreterFactory {

	<T extends Premium> PremiumInterpreter<T> getInterpreter(
			Class<T> premiumType);

}
