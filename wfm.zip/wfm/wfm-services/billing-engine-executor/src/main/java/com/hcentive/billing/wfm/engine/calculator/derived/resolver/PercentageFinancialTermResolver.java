package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.InsuranceCoverageAwareFinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.api.PlanAndMemberAwareFinancialTerm;
import com.hcentive.billing.wfm.domain.contract.PercentageAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.derived.interpreter.PercentageLogic;
import com.hcentive.billing.wfm.engine.calculator.financial.term.FinancialTermResolver;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmountDefinition;
import com.hcentive.billing.wfm.engine.calculator.vo.PlanAwareDerivedAmountDefinition;

public abstract class PercentageFinancialTermResolver extends FinancialTermResolver implements
		DerivedAmountDefinitionResolver {

	private static final Logger logger = LoggerFactory.getLogger(PercentageFinancialTermResolver.class);

	@Override
	public Set<DerivedAmountDefinition<?>> resolveDefinitions(BillRunContext billRunCtx) {

		Set<DerivedAmountDefinition<?>> rateAmounts = new HashSet<>();

		for (FinancialTerm<?> finTerm : resolveFinancialTerm(billRunCtx)) {

			PercentageAmount finTermValue = null;
			
			if (finTerm.value() instanceof PercentageAmount) {
				finTermValue = (PercentageAmount) finTerm.value();
				
			} else if (finTerm instanceof PlanAndMemberAwareFinancialTerm<?> 
						&& ((PlanAndMemberAwareFinancialTerm<?>) finTerm).termValueType()
									== PercentageAmount.class) {
				
				PlanAndMemberAwareFinancialTerm<?> planMemFinTerm = (PlanAndMemberAwareFinancialTerm<?>) finTerm;
				
				// Percentage value will be same for all members. Use first members percentage amount
				for (MemberAwareFinancialTerm<?> memFinTerm : planMemFinTerm.memberBreakUpFinancialTerms()) {
					if (memFinTerm.value() instanceof PercentageAmount) {
						finTermValue = (PercentageAmount) memFinTerm.value();
						break;
					}
				}
				
			}
			
			if (finTermValue != null) {
				rateAmounts.add(createDerivedAmountDefinition(finTermValue, finTerm));
			}
		}

		return rateAmounts;
	}

	protected DerivedAmountDefinition<PercentageLogic> createDerivedAmountDefinition(PercentageAmount percentageAmt,
			FinancialTerm<?> finTerm) {

		logger.debug("creating percentage derived amount def for fin term: {}, " + "percentage amt: {}",
				finTerm.code(), percentageAmt);

		Set<String> deriveFrom = new HashSet<>();
		deriveFrom.add(percentageAmt.getRefAmountCode());

		if (finTerm instanceof InsuranceCoverageAwareFinancialTerm<?>) {
			return createDerivedAmountDefinition(percentageAmt, (InsuranceCoverageAwareFinancialTerm<?>) finTerm);
		}

		return new DerivedAmountDefinition<PercentageLogic>(finTerm.code(), getAmountType(), deriveFrom,
				new PercentageLogic(percentageAmt.getPercentage()), finTerm.name(), finTerm.description());
	}

	protected DerivedAmountDefinition<PercentageLogic> createDerivedAmountDefinition(PercentageAmount percentageAmt,
			InsuranceCoverageAwareFinancialTerm<?> finTerm) {

		Set<String> deriveFrom = new HashSet<>();
		deriveFrom.add(percentageAmt.getRefAmountCode());
		return new PlanAwareDerivedAmountDefinition<PercentageLogic>(finTerm.code(), finTerm.name(), getAmountType(),
				deriveFrom, new PercentageLogic(percentageAmt.getPercentage()), finTerm.insuranceCoverage(),
				finTerm.description());
	}

	protected abstract AmountCategory getAmountType();

}
