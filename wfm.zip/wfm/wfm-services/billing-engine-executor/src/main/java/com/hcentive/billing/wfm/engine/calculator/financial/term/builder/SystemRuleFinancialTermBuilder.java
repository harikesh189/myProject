/**
 *
 */
package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import static com.hcentive.billing.core.commons.util.CollectionUtil.filterAndTransform;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.condition.ConditionContextResolver;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.util.EffectivityUtil;
import com.hcentive.billing.core.commons.util.IFilter;
import com.hcentive.billing.core.commons.util.ITransformer;
import com.hcentive.billing.policies.api.FinancialChargeResolver;
import com.hcentive.billing.wfm.api.FinancialContract;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.api.InsuranceCoverageAwareContract;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTerm;
import com.hcentive.billing.wfm.api.MemberAwareFinancialTermImpl;
import com.hcentive.billing.wfm.api.PlanAndMemberFinancialTermImpl;
import com.hcentive.billing.wfm.domain.billing.account.BillingAccount;
import com.hcentive.billing.wfm.domain.billingpolicy.FinancialCharge;
import com.hcentive.billing.wfm.domain.contract.AbstractFinancialContract;
import com.hcentive.billing.wfm.domain.contract.ContractType;
import com.hcentive.billing.wfm.domain.contract.EligibilityCoverage;
import com.hcentive.billing.wfm.domain.contract.FinancialTermBuilder;
import com.hcentive.billing.wfm.domain.contract.InsuranceCoverage;
import com.hcentive.billing.wfm.domain.contract.mixin.BenefitVendorAware;
import com.hcentive.billing.wfm.domain.contract.mixin.BillableEntityAware;
import com.hcentive.billing.wfm.domain.contract.mixin.EntityAware;
import com.hcentive.billing.wfm.domain.contract.mixin.EventTypeAware;
import com.hcentive.billing.wfm.domain.contract.mixin.ExchangeAware;
import com.hcentive.billing.wfm.domain.contract.mixin.HealthPlanAware;
import com.hcentive.billing.wfm.domain.contract.mixin.MarketTypeAware;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.util.MatchingConditionContextResolver;

/**
 * @author Dikshit.Vaid
 */
@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class SystemRuleFinancialTermBuilder implements FinancialTermBuilder {

	private static final Logger LOGGER = LoggerFactory.getLogger(SystemRuleFinancialTermBuilder.class);

	@Autowired
	private FinancialChargeResolver financialChargeResolver;

	@Autowired
	private FinChargeToFinTermTxFactory finChargeTxFactory;

	@Override
	public Collection<FinancialTerm<?>> build(final BillingAccount billingAccount,
	        final FinancialContract<ContractType, ?> contract, final Period effectivePeriod) {

		Collection<FinancialTerm<?>> financialTerms = Collections.EMPTY_SET;

		if (contract instanceof InsuranceCoverageAwareContract && contract instanceof AbstractFinancialContract) {

			final Collection<FinancialCharge> finCharges = this.financialChargeResolver.findByEffectiveDate(effectivePeriod.getBeginsOn());

			financialTerms = buildFinancialTerms(billingAccount, (AbstractFinancialContract) contract, effectivePeriod, finCharges);
			LOGGER.debug("financialTerms found size/>"+financialTerms.size());
		}

		return financialTerms;
	}

	@Override
	public boolean canHandle(BillRunContext runContext) {
		return runContext != null && runContext.getBillingContractRun().getContract() instanceof InsuranceCoverageAwareContract;
	}

	private Collection<FinancialTerm<?>> buildFinancialTerms(final BillingAccount billingAccount, AbstractFinancialContract contract, Period effectivePeriod,
	        Collection<FinancialCharge> financialTerms) {

		Collection<FinancialTerm> finTerms = new HashSet<>();
		if (contract instanceof InsuranceCoverageAwareContract) {
			final InsuranceCoverageAwareContract eligContract = (InsuranceCoverageAwareContract) contract;
			for (final InsuranceCoverage inCoverage : eligContract.insuranceCoverages()) {
				if (inCoverage instanceof EligibilityCoverage) {
					final EligibilityCoverage eligibilityCoverage = (EligibilityCoverage) inCoverage;
					if (EffectivityUtil.isCoverageEffective(eligibilityCoverage, effectivePeriod)) {
						final Period planEffPeriod = Period.getIntersection(effectivePeriod, eligibilityCoverage.effectivePeriod());
						if (financialTerms != null) {
							finTerms.addAll(filterAndTransform(financialTerms,
									new FinancialTermFilter(planEffPeriod, billingAccount, contract, eligibilityCoverage),
									new FinancialChargeToFinancialTermTrasnformer(eligibilityCoverage, planEffPeriod)));
						}
					}
				}
			}
		}
		return (Collection<FinancialTerm<?>>) (Object) finTerms;
	}

	private class FinancialTermFilter implements IFilter<FinancialCharge> {
		public BillingAccount billingAccount;
		public AbstractFinancialContract contract;
		public Period planEffPeriod;
		public EligibilityCoverage eligibilityCoverage;

		public FinancialTermFilter(Period planEffPeriod, BillingAccount billingAccount, AbstractFinancialContract contract, EligibilityCoverage eligibilityCoverage) {
			this.planEffPeriod = planEffPeriod;
			this.billingAccount = billingAccount;
			this.contract = contract;
			this.eligibilityCoverage = eligibilityCoverage;
		}

		@Override
		public boolean apply(FinancialCharge ruleConfig) {
			/*LOGGER.debug("Checking financial charge for applicability - {} for plan {}, billing account {}, contract {}, plan effective period {} ",
			        ruleConfig.name(), plan.getHealthPlan().getName(), billingAccount.getIdentity(), this.contract.getIdentity(), planEffPeriod);*/
			final boolean matchWithConditionContext = ruleConfig.matchWith(getConditionContextResolver(this.billingAccount, this.contract, this.eligibilityCoverage));
			LOGGER.debug("matchWithConditionContext/>"+matchWithConditionContext);
			final boolean effectiveForPlanEffectivePeriod = EffectivityUtil.isEffective(ruleConfig, this.planEffPeriod);
			LOGGER.debug("effectiveForPlanEffectivePeriod/period>"+effectiveForPlanEffectivePeriod+"/"+this.planEffPeriod);
			//final boolean reinstatedBillingAccount = this.billingAccount.isInReinstatementWindow();
			//LOGGER.debug("reinstatedBillingAccount>"+reinstatedBillingAccount);
			final boolean isReinstatementFee = false;
			
			/*ruleConfig instanceof BillingConfigFee && --Reinstatement fee not applicable
					((BillingConfigFee) ruleConfig).getFeeClass().equals(FeeClass.REINSTATEMENT);*/
			LOGGER.debug("isReinstatementFee>"+isReinstatementFee);
			final boolean matchingResult = matchWithConditionContext && effectiveForPlanEffectivePeriod;
			      //  && (!isReinstatementFee || isReinstatementFee && reinstatedBillingAccount);
			if (matchingResult) {
//				LOGGER.debug("{} applicable for plan {} .matchWithConditionContext/effectiveForPlanEffectivePeriod/reinstatedBillingAccount/isReinstatementFee", ruleConfig.name(),matchWithConditionContext,effectiveForPlanEffectivePeriod,isReinstatementFee, plan.getHealthPlan().getName());
			} else {
//				LOGGER.debug("{} not applicable for plan {} .matchWithConditionContext/effectiveForPlanEffectivePeriod/reinstatedBillingAccount/isReinstatementFee", ruleConfig.name(),matchWithConditionContext,effectiveForPlanEffectivePeriod,isReinstatementFee, plan.getHealthPlan().getName());
			}

			return matchingResult;
		}

		private ConditionContextResolver getConditionContextResolver(final BillingAccount billingAccount, AbstractFinancialContract contract,
				EligibilityCoverage eligibilityCoverage) {
			final EntityAware entityAware = contract;
			final MarketTypeAware marketTypeAware = contract instanceof MarketTypeAware ? (MarketTypeAware) contract : null;
			final EventTypeAware eventTypeAware = contract instanceof EventTypeAware ? (EventTypeAware) contract : null;
			final BillableEntityAware customerAware = new BillableEntityAware() {
				@Override
				public String getBillableEntityId() {
					return billingAccount.getOwner().getExternalId();
				}
			};
			final ExchangeAware exchangeAware = contract instanceof ExchangeAware ? (ExchangeAware) contract : null;
			final BenefitVendorAware benefitVendorAware = eligibilityCoverage instanceof BenefitVendorAware ? (BenefitVendorAware) eligibilityCoverage : null;
			final HealthPlanAware plan = eligibilityCoverage instanceof HealthPlanAware ? (HealthPlanAware) eligibilityCoverage : null;

			final ConditionContextResolver conditionContextResolver = new MatchingConditionContextResolver(entityAware, marketTypeAware, plan, eventTypeAware,
			        customerAware, exchangeAware, null, null, null, null,null,benefitVendorAware);
			return conditionContextResolver;
		}
	}

	private class FinancialChargeToFinancialTermTrasnformer implements ITransformer<FinancialCharge, FinancialTerm> {

		private final InsuranceCoverage plan;
		private final Period planEffPeriod;

		public FinancialChargeToFinancialTermTrasnformer(InsuranceCoverage plan, Period planEffPeriod) {
			super();
			this.plan = plan;
			this.planEffPeriod = planEffPeriod;
		}

		@Override
		public FinancialTerm transform(FinancialCharge ruleConfig) {
			final Period finTermEffPeriod = Period.getIntersection(ruleConfig.effectivePeriod(), planEffPeriod);
			LOGGER.debug("FinancialChargeToFinancialTermTrasnformer rule found/>"+ruleConfig.getName());
			final FinancialChargeToFinancialTermTransformer<?, ?> finChargeTx = finChargeTxFactory.getTransformer(ruleConfig);
			final FinancialTerm<?> memFinTerm = finChargeTx.transform(ruleConfig, finTermEffPeriod);

			final Set<MemberAwareFinancialTerm<?>> memberBreakUps = new HashSet<>();
			final MemberAwareFinancialTerm<?> memberFinTerm = new MemberAwareFinancialTermImpl<>(memFinTerm, plan.getInsuredSubscriber().getId());
			memberBreakUps.add(memberFinTerm);

			return new PlanAndMemberFinancialTermImpl(ruleConfig.type(), ruleConfig.code(), ruleConfig.name(), finTermEffPeriod, plan.getId(), memberBreakUps,
			        ruleConfig.description());

		}
	}

}