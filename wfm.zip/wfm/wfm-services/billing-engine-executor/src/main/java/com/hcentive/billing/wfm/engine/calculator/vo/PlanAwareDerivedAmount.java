package com.hcentive.billing.wfm.engine.calculator.vo;

import java.util.Set;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountGroup;
import com.hcentive.billing.wfm.api.InsuranceCoverageAware;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.InsuranceCoverageAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberAndPlanAwareBillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;

public class PlanAwareDerivedAmount<DL> extends DerivedAmount<DL> implements
		InsuranceCoverageAware {

	private Long planId;

	public PlanAwareDerivedAmount(DerivedAmountDefinition<DL> definition,
			Set<BillAmount> deriveFrom, Long planId, Period coveragePeriod) {
		super(definition, deriveFrom, coveragePeriod);
		this.planId = planId;
	}

	@Override
	public Long insuranceCoverage() {
		return planId;
	}

	@Override
	public BillAmount toBillAmount(Amount amount) {
		BillAmount amt = new InsuranceCoverageAwareBillAmount(insuranceCoverage(),
				getAmountCode(), getAmountName(), getAmountType(), amount,
				AmountGroup.DEFAULT, getDescription(), getCoveragePeriod(), null);
		
		amt.addReferences(deriveFromBillAmountReferences());
		return amt;
	}

	@Override
	public BillAmount toBillAmount(Amount amount,  
			Set<MemberBreakUp> memberBreakUp) {
		BillAmount amt = new MemberAndPlanAwareBillAmount(insuranceCoverage(),
				getAmountCode(), getAmountName(), amount, getAmountType(),
				getDescription(), getCoveragePeriod(), AmountGroup.DEFAULT, 
				memberBreakUp, null);
		
		amt.addReferences(deriveFromBillAmountReferences());
		return amt;
	}

}
