package com.hcentive.billing.wfm.engine.calculator.prorate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;

@Component
public class DefaultProRateHandlerFactory extends SpringBackedAbstractFactory<ProRateHandler> implements
		ProRateHandlerFactory {

	private static final Logger logger = LoggerFactory.getLogger(DefaultProRateHandlerFactory.class);

	private ProRateHandler nullConfigHandler;

	public DefaultProRateHandlerFactory() {
		ProRateHelper.registerFactory(this);
	}

	@Override
	public ProRateHandler getHandler(ProRateStrategy proRateStrategy) {

		for (ProRateHandler handler : registeredInstances()) {
			if (handler.supportedStrategy() == proRateStrategy) {
				return handler;
			}
		}

		logger.error("No pro-rate handler found for strategy: {}", proRateStrategy);

		throw new IllegalStateException("No pro-rate handler found for strategy [" + proRateStrategy + "]");

	}

	@Override
	public ProRateHandler getNullConfigHandler() {
		return nullConfigHandler;
	}

	@Override
	protected void registerBean(ProRateHandler bean) {
		super.registerBean(bean);
		if (bean.supportedStrategy() == null) {
			nullConfigHandler = bean;
		}
	}

	@Override
	protected Class<ProRateHandler> lookupForType() {
		return ProRateHandler.class;
	}

}
