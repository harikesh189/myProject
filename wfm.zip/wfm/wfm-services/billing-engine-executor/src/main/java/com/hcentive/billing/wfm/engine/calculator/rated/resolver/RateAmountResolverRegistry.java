package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import java.util.Collection;

public interface RateAmountResolverRegistry {

	Collection<RateAmountResolver> registeredResolvers();

}
