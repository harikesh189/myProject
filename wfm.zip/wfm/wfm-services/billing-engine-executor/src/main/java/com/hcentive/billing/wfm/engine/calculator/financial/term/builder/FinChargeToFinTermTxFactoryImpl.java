package com.hcentive.billing.wfm.engine.calculator.financial.term.builder;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.wfm.domain.billingpolicy.FinancialCharge;

@Component
@SuppressWarnings("rawtypes")
public class FinChargeToFinTermTxFactoryImpl extends
		SpringBackedAbstractFactory<FinancialChargeToFinancialTermTransformer>
		implements FinChargeToFinTermTxFactory {

	@SuppressWarnings("unchecked")
	@Override
	public FinancialChargeToFinancialTermTransformer getTransformer(
			FinancialCharge fc) {
		for (FinancialChargeToFinancialTermTransformer tx : registeredInstances()) {
			if (tx.canHandle(fc)) {
				return tx;
			}
		}

		throw new IllegalArgumentException(
				"No Financial Term transformer found for Financial charge ["
						+ fc + "]");
	}

	@Override
	protected Class<FinancialChargeToFinancialTermTransformer> lookupForType() {
		return FinancialChargeToFinancialTermTransformer.class;
	}

}
