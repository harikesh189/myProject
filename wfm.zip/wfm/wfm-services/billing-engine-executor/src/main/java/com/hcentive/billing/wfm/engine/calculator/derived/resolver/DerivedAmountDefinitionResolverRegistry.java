package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import java.util.Collection;

public interface DerivedAmountDefinitionResolverRegistry {

	Collection<DerivedAmountDefinitionResolver> registeredResolvers();

}
