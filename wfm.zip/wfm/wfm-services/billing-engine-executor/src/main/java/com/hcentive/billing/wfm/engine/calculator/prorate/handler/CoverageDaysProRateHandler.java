package com.hcentive.billing.wfm.engine.calculator.prorate.handler;

import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.util.DateUtility;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ProRateStrategy;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;

/**
 * @author Dikshit.Luthra
 */
@Component
public class CoverageDaysProRateHandler extends AbstractProRateHandler {

	@Override
	protected double calcPartialMonthAmountMultiplier(final Date monthCoverageStartDt, final Date monthCoverageEndDt, final BillingConfigProRate proRateConfig) {

		int monthChargeableDays = 0;

		if (monthCoverageStartDt != null && monthCoverageEndDt != null) {

			final Calendar calStartDt = Calendar.getInstance();
			calStartDt.setTime(monthCoverageStartDt);

			final Calendar calEndDt = Calendar.getInstance();
			calEndDt.setTime(monthCoverageEndDt);

			if (calStartDt.get(Calendar.MONTH) != calEndDt.get(Calendar.MONTH)) {
				throw new IllegalArgumentException("Start month [" + calStartDt + "] and end month [" + calEndDt + "] should be same");
			}

			monthChargeableDays = DateUtility.numberOfDays(monthCoverageStartDt, monthCoverageEndDt);

		} else if (monthCoverageStartDt != null) {

			monthChargeableDays = DateUtility.daysInMonthAfter(monthCoverageStartDt, true);

		} else if (monthCoverageEndDt != null) {

			monthChargeableDays = DateUtility.daysInMonthBefore(monthCoverageEndDt, true);
		}

		return this.chargePremium(monthChargeableDays, proRateConfig) ? 1 : 0;
	}

	private boolean chargePremium(final int chargeableDaysInMonth, final BillingConfigProRate proRateConfig) {
		return chargeableDaysInMonth >= proRateConfig.getCoverageDays();
	}

	@Override
	public ProRateStrategy supportedStrategy() {
		return ProRateStrategy.COVERAGE_DAYS;
	}

}
