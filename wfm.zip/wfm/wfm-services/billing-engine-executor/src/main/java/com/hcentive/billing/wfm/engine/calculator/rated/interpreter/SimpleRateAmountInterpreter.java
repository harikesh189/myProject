package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

@Component
public class SimpleRateAmountInterpreter extends AbstractRateAmountInterpreter
		implements RateAmountInterpreter<RateAmount, BillAmount> {

	@Override
	public Class<RateAmount> interpretedType() {
		return RateAmount.class;
	}

	@Override
	public BillAmount interpretAmount(RateAmount rateAmount,
			Period billingPeriod, BillingConfigProRate proRateConfig) {
		return calculateAmount(rateAmount, billingPeriod, proRateConfig);
	}

}
