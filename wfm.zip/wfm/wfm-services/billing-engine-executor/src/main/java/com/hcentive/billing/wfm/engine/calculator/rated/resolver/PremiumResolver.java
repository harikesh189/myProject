package com.hcentive.billing.wfm.engine.calculator.rated.resolver;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;

public class PremiumResolver implements RateAmountResolver {

	private static final Logger logger = LoggerFactory.getLogger(PremiumResolver.class);

	@Autowired
	private FinancialTermToRateAmountTxFactory factory;

	@Override
	public Set<RateAmount> resolveRateAmount(BillRunContext billRunCtx) {
		final Set<RateAmount> rateAmounts = new HashSet<>();
		final Collection<FinancialTerm<?>> financialTerms = billRunCtx.getBillRunData().financialTerms();
		for (final FinancialTerm<?> financialTerm : financialTerms) {
			if (financialTerm.type().equals(AmountCategory.PREMIUM.name())) {
				final RateAmount rateAmt = factory.getTransformer(financialTerm).transform(financialTerm);
				logger.debug("Adding rate amount: {}", rateAmt);
				rateAmounts.add(rateAmt);
			}
		}
		return rateAmounts;
	}

	@Override
	public String name() {
		return "Enrolled Plan Premium resolver";
	}

}
