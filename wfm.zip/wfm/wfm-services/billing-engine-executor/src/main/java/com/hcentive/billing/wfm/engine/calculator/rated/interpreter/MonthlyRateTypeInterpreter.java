package com.hcentive.billing.wfm.engine.calculator.rated.interpreter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.billingpolicy.BillingConfigProRate;
import com.hcentive.billing.wfm.engine.calculator.prorate.ProRateHelper;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.RateAmount.RateType;

@Component
public class MonthlyRateTypeInterpreter implements RateTypeInterpreter {

	private static final Logger LOGGER = LoggerFactory.getLogger(MonthlyRateTypeInterpreter.class);

	@Override
	public Amount calculateAmount(BillingConfigProRate proRateConfig, Period applicablePeriod, RateAmount rateAmount) {

		if (rateAmount.getRateType() == RateType.MONTHLY) {
			return ProRateHelper.proRateAmount(proRateConfig, applicablePeriod, rateAmount.getAmount());
		}

		LOGGER.error("MonthlyRateTypeInterpreter can not handle rate type [{}]", rateAmount.getRateType());
		throw new IllegalArgumentException("Can not handle rate type [" + rateAmount.getRateType() + "]");
	}

	@Override
	public boolean canHandle(RateType rateType) {
		return rateType == RateType.MONTHLY;
	}

}
