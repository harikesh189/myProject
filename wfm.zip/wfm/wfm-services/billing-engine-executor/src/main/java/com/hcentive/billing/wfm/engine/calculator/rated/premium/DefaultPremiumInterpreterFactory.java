package com.hcentive.billing.wfm.engine.calculator.rated.premium;

import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.beans.SpringBackedAbstractFactory;
import com.hcentive.billing.wfm.domain.Premium;

@SuppressWarnings("rawtypes")
@Component
public class DefaultPremiumInterpreterFactory extends
		SpringBackedAbstractFactory<PremiumInterpreter> implements
		PremiumInterpreterFactory {

	@SuppressWarnings("unchecked")
	@Override
	public <T extends Premium> PremiumInterpreter<T> getInterpreter(
			Class<T> premiumType) {

		for (PremiumInterpreter<T> intrprtr : registeredInstances()) {
			if (intrprtr.interpretedType() == premiumType) {
				return intrprtr;
			}
		}

		throw new IllegalStateException(
				"No premium interpreter found for premium type [" + premiumType
						+ "]");
	}

	@Override
	protected Class<PremiumInterpreter> lookupForType() {
		return PremiumInterpreter.class;
	}

}
