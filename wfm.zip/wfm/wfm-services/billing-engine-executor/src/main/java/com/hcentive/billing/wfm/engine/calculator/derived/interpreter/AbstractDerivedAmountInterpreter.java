package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.MemberBreakUp;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmount;

public class AbstractDerivedAmountInterpreter {

	protected BillAmount createBillAmount(Amount amount,
			DerivedAmount<?> derivedAmt) {
		return derivedAmt.toBillAmount(amount);
	}

	protected BillAmount createBillAmount(Amount amount,
			Set<MemberBreakUp> memberBreakUp, DerivedAmount<?> derivedAmt) {
		return derivedAmt.toBillAmount(amount, memberBreakUp);
	}

	protected Set<MemberBreakUp> createMemberBreakUpSet(
			Map<Long, MemberBreakUp> memberBreakUpAmts) {
		
		Set<MemberBreakUp> memBreakUps = new HashSet<>();
		for (Map.Entry<Long, MemberBreakUp> entry : memberBreakUpAmts.entrySet()) {
			memBreakUps.add(entry.getValue());
		}
		return memBreakUps;
	}

}
