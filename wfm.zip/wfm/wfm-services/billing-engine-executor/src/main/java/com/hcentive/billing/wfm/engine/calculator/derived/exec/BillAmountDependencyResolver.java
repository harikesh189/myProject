package com.hcentive.billing.wfm.engine.calculator.derived.exec;

import java.util.Set;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmountDefinition;

public interface BillAmountDependencyResolver {

	Set<BillAmount> findBillAmounts(DerivedAmountDefinition<?> definition,
			BillRunContext billRunContext);

}
