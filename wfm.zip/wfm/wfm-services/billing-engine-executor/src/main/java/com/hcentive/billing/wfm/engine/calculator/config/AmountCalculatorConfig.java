package com.hcentive.billing.wfm.engine.calculator.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.wfm.engine.calculator.derived.DerivedAmountCalculator;
import com.hcentive.billing.wfm.engine.calculator.rated.RatedAmountCalculator;

@Configuration
public class AmountCalculatorConfig {

	@Bean
	public RatedAmountCalculator ratedAmountCalculator() {
		return new RatedAmountCalculator();
	}

	@Bean
	public DerivedAmountCalculator derivedAmountCalculator() {
		return new DerivedAmountCalculator();
	}

}
