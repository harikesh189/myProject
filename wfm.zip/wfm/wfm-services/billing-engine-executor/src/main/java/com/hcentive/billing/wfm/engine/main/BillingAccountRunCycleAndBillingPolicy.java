package com.hcentive.billing.wfm.engine.main;

import com.hcentive.billing.wfm.domain.billingpolicy.BillingPolicy;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillingAccountRunCycle;

public class BillingAccountRunCycleAndBillingPolicy {

	
	private BillingAccountRunCycle cycle;
	
	private BillingPolicy policy;

	/**
	 * @return the cycle
	 */
	public BillingAccountRunCycle getCycle() {
		return cycle;
	}

	/**
	 * @param cycle the cycle to set
	 */
	public void setCycle(BillingAccountRunCycle cycle) {
		this.cycle = cycle;
	}

	/**
	 * @return the policy
	 */
	public BillingPolicy getPolicy() {
		return policy;
	}

	/**
	 * @param policy the policy to set
	 */
	public void setPolicy(BillingPolicy policy) {
		this.policy = policy;
	}
	
	
	
}
