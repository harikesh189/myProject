package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class PercentageTaxResolver extends PercentageFinancialTermResolver {

	@Override
	public String name() {
		return "Percentage Tax Derived Amount Resolver";
	}

	@Override
	protected String financialTermType() {
		return ConfigType.TAX.toString();
	}

	@Override
	public float executionOrder() {
		return ResolverExecutionOrder.TAX_RESOLVER_ORDER;
	}

	@Override
	protected AmountCategory getAmountType() {
		return AmountCategory.TAX;
	}

}
