package com.hcentive.billing.wfm.engine.calculator.derived.resolver;

import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.enumeration.billingPolicy.ConfigType;

public class PercentageDiscountResolver extends PercentageFinancialTermResolver {

	@Override
	public String name() {
		return "Percentage Discount Derived Amount Resolver";
	}

	@Override
	protected String financialTermType() {
		return ConfigType.DISCOUNT.toString();
	}

	@Override
	public float executionOrder() {
		return ResolverExecutionOrder.DISCOUNT_RESOLVER_ORDER;
	}

	@Override
	protected AmountCategory getAmountType() {
		return AmountCategory.DISCOUNT;
	}

}
