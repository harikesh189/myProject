package com.hcentive.billing.wfm.engine.calculator.vo;

import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.wfm.api.AmountCategory;
import com.hcentive.billing.wfm.api.InsuranceCoverageAware;

public class MemberAndPlanAwareRateAmount extends MemberAwareRateAmount implements InsuranceCoverageAware {

	private Long planId;

	public MemberAndPlanAwareRateAmount(Amount amount, RateType rateType, String amountCode, String amountName,
			AmountCategory type, Period applicableFor, Long planId, String desc) {
		super(amount, rateType, amountCode, amountName, applicableFor, type, desc);
		this.planId = planId;
	}

	@Override
	public Long insuranceCoverage() {
		return planId;
	}

	public String toString() {
		return "plan: " + planId + ", " + super.toString();
	}

}
