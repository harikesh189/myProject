package com.hcentive.billing.wfm.engine.calculator;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcentive.billing.core.commons.util.CollectionUtil;
import com.hcentive.billing.wfm.api.FinancialTerm;
import com.hcentive.billing.wfm.domain.contract.ContractFinancialTermsBuilderProvider;
import com.hcentive.billing.wfm.domain.schedule.cycle.BillRunContext;
import com.hcentive.billing.wfm.services.billingrun.service.BillRunOperation;
import com.hcentive.billing.wfm.services.billingrun.service.OperationExecutionOrder;

public class BillAmountCalculators implements BillRunOperation {

	private static final Logger logger = LoggerFactory.getLogger(BillAmountCalculators.class);

	@Autowired
	private AmountCalculatorRegistry calcRegistry;

	@Override
	public float executionOrder() {
		return OperationExecutionOrder.BILL_AMOUNT_CALCULATORS_EXEC_ORDER;
	}

	@Override
	public String name() {
		return "Bill Amount Calculators";
	}

	@Override
	public void run(final BillRunContext billRunContext) {

		logger.info("Start BillRunOperation {} for BillRunContext {}", this.name(), billRunContext.getIdentity());

		final Collection<FinancialTerm<?>> contractFinancialTerms = ContractFinancialTermsBuilderProvider.get().buildFinancialTerms(billRunContext);

		onSuccessExecute(contractFinancialTerms, billRunContext);

	}

	protected void onSuccessExecute(final Collection<FinancialTerm<?>> finTerms, final BillRunContext billRunContext) {

		billRunContext.getBillRunData().addFinancialTerms(CollectionUtil.nullSafe(finTerms));

		for (final AmountCalculator calc : BillAmountCalculators.this.calcRegistry.registeredCalculators()) {

			logger.debug("Start {} calculator for eligibility contract {} and billRunContext {} ", calc.name(), billRunContext.contract().getIdentity(),
					billRunContext.getIdentity());

			calc.calculateAndAddAmounts(billRunContext);

			logger.debug("Completed {} calculator for eligibility contract {} and billRunContext {} ", calc.name(), billRunContext.contract().getIdentity(),
					billRunContext.getIdentity());
		}

		logger.info("Completed BillRunOperation {} for BillRunContext {}", name(), billRunContext.getIdentity());
	}

}
