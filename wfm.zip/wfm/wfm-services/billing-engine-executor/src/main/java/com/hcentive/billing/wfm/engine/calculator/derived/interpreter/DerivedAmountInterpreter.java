package com.hcentive.billing.wfm.engine.calculator.derived.interpreter;

import java.util.Set;

import com.hcentive.billing.wfm.domain.schedule.cycle.BillAmount;
import com.hcentive.billing.wfm.engine.calculator.vo.DerivedAmount;

public interface DerivedAmountInterpreter<DL> {

	Set<BillAmount> interpretDerivedAmount(DerivedAmount<DL> amount);

	Class<DL> interpretedType();

}
