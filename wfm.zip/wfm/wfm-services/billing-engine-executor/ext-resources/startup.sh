#!/bin/bash
clear
echo "Launching Billing Engine Executor service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/billing-engine-executor -Xloggc:/var/log/wfm/billing-engine-executor/GC_`date '+%y%m%d_%H%M%S'`.log -Xms512m -Xmx2048m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar billing-engine-executor-1.0.0-SNAPSHOT.jar --server.port=8127