package com.hcentive.billing.core.commons.service.ebill.auto.payment.batch;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AutoPaymentVo {
	@Id
	private long id;
	private String invsumidentity;
	private String invsumrefid;
	private String recsetidentity;
	private String customer;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getInvsumidentity() {
		return invsumidentity;
	}

	public void setInvsumidentity(String invsumidentity) {
		this.invsumidentity = invsumidentity;
	}

	public String getInvsumrefid() {
		return invsumrefid;
	}

	public void setInvsumrefid(String invsumrefid) {
		this.invsumrefid = invsumrefid;
	}

	public String getRecsetidentity() {
		return recsetidentity;
	}

	public void setRecsetidentity(String recsetidentity) {
		this.recsetidentity = recsetidentity;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

}
