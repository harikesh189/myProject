/**
 * 
 */
package com.hcentive.billing.core.commons.service.ebill.auto.payment.init;

import java.util.HashMap;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.MongoItemReader;
import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.hcentive.billing.core.commons.domain.EbillSchedulePayment;
import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.batch.AutoPaymentJobItemReaderListener;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.batch.AutoPaymentJpaReader;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.batch.AutoPaymentProcessor;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.batch.AutoPaymentReconciliationProcessor;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.batch.AutoPaymentReconciliationWriter;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.batch.AutoPaymentWriter;
import com.hcentive.billing.core.commons.vo.ItemRecord;
import com.hcentive.commons.batch.process.MultiTenantSupportItemReader;
import com.hcentive.commons.batch.process.RoundRobbinTenantDataReadStrategy;
import com.hcentive.commons.batch.process.SpringBeanNameBasedReaderFactory;
import com.hcentive.commons.batch.process.TenantProvider;

/**
 * @author Mohit Gupta
 * 
 */
@Configuration
public class AutoPaymentConfigBean {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private FilterSupportRepository filterSupportRepository;
	
	@Autowired
	private TenantProvider tenantProvider;
	
	@Autowired
	private ConfigurableApplicationContext context;
	
	@Value("${auto.payment.jpaquery}")
	private String queryStr;

	@Value("${autopayment.chunk.size}")
	private int chunkSize;

	@Value("${autopayment.page.size}")
	private int pageSize;
	
	@Autowired
	private MongoTemplate mongoTemplate;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AutoPaymentConfigBean.class);

	@Bean
	public Job autoPaymentJob() throws Exception {

		final JobBuilder jobBuilder = jobBuilderFactory.get("autoPaymentJob");
		return jobBuilder.start(autoPaymentStep()).build();
	}

	@Bean
	public Step autoPaymentStep() throws Exception {
		return stepBuilderFactory.get("autoPaymentNewStep")
				.<Object, Object> chunk(chunkSize)
				.reader(autoPaymentTenantBasedItemReaderForJPA())
				.processor(getAutoPaymentProcessor())
				.writer(getAutoPaymentWriter())
				.listener(getAutoPaymentJobItemReaderListener()).build();
	}

	@Bean
	public Job autoPaymentReconciliationJob() throws Exception {
		final JobBuilder jobBuilder = jobBuilderFactory
				.get("autoPaymentReconciliationJob");
		return jobBuilder.start(autoPaymentReconciliationStep()).build();
	}

	@Bean
	public Step autoPaymentReconciliationStep() throws Exception {
		return stepBuilderFactory.get("autoPaymentReconciliationStep")
				.<Object, Object> chunk(chunkSize)
				.reader(autoPaymentTenantBasedItemReaderForMongo())
				.processor(getAutoPaymentReconciliationProcessor())
				.writer(getAutoPaymentReconciliationWriter()).build();
	}

	
	
	
	@Bean
	public SpringBeanNameBasedReaderFactory<ItemRecord> autoPaymentMongoDelegateReaderFactory(){
		return new SpringBeanNameBasedReaderFactory<ItemRecord>("getMongoPagingItemReader");
	}
	
	@Bean
	public ItemReader<ItemRecord> autoPaymentTenantBasedItemReaderForMongo(){
		
		SpringBeanNameBasedReaderFactory<ItemRecord> readerFactory = (SpringBeanNameBasedReaderFactory<ItemRecord>)context.getBean("autoPaymentMongoDelegateReaderFactory");
		MultiTenantSupportItemReader<ItemRecord> reader = new MultiTenantSupportItemReader<ItemRecord>(tenantProvider,readerFactory , RoundRobbinTenantDataReadStrategy.factory());
		return reader;
		
		//return new MultiTenantSupportItemReader<ItemRecord>(tenantProvider,autoPaymentMongoDelegateReaderFactory() , RoundRobbinTenantDataReadStrategy.factory());
	}
	
	@Bean
	public SpringBeanNameBasedReaderFactory<EbillSchedulePayment> autoPaymentJPADelegateReaderFactory(){
		return new SpringBeanNameBasedReaderFactory<EbillSchedulePayment>("getJpaPagingItemReader");
	}
	
	@Bean
	public ItemReader<EbillSchedulePayment> autoPaymentTenantBasedItemReaderForJPA(){
		SpringBeanNameBasedReaderFactory<EbillSchedulePayment> readerFactory = (SpringBeanNameBasedReaderFactory<EbillSchedulePayment>)context.getBean("autoPaymentJPADelegateReaderFactory");
		MultiTenantSupportItemReader<EbillSchedulePayment> reader = new MultiTenantSupportItemReader<EbillSchedulePayment>(tenantProvider,readerFactory , RoundRobbinTenantDataReadStrategy.factory());
		return reader;
	}
	
	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	@Bean
	public ItemReader<ItemRecord> getMongoPagingItemReader()
			throws Exception {
		MongoItemReader<ItemRecord> reader = new MongoItemReader<ItemRecord>();
		reader.setTemplate(mongoTemplate);
		reader.setQuery("{'item.status':'PAYMENT_REQUEST_INITIATED'}");
		reader.setTargetType(ItemRecord.class);
		reader.setName("autoPaymentRecordReader");
		HashMap<String, Direction> sort = new HashMap<String, Direction>();
		sort.put("item.startTime.date", Direction.ASC);
		reader.setSort(sort);
		reader.setCollection(AutoPaymentUtil.resolveCollectionName());
		reader.afterPropertiesSet();
		return reader;
	}

	@Bean
	public ItemProcessor getAutoPaymentReconciliationProcessor() {
		return new AutoPaymentReconciliationProcessor(filterSupportRepository);
	}

	@Bean
	public ItemWriter getAutoPaymentReconciliationWriter()
			throws Exception {

		AutoPaymentReconciliationWriter autoPaymentReconciliationWriter = new AutoPaymentReconciliationWriter();
		autoPaymentReconciliationWriter.setMongoTemplate(mongoTemplate);
		return autoPaymentReconciliationWriter;
	}

	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	@Bean
	public ItemReader<EbillSchedulePayment> getJpaPagingItemReader() {
		AutoPaymentJpaReader<EbillSchedulePayment> reader = new AutoPaymentJpaReader<EbillSchedulePayment>();
		reader.setEntityManagerFactory(entityManagerFactory);
		reader.setQueryString(queryStr);
		reader.setPageSize(pageSize);
		return reader;
	}

	@Bean
	public ItemProcessor getAutoPaymentProcessor() {
		AutoPaymentProcessor autoPaymentProcessor = new AutoPaymentProcessor(
				filterSupportRepository);
		try {
			autoPaymentProcessor.setMongoTemplate(mongoTemplate);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return autoPaymentProcessor;
	}

	@Bean
	public ItemReadListener getAutoPaymentJobItemReaderListener() {
		return new AutoPaymentJobItemReaderListener();
	}

	@Bean
	public ItemWriter getAutoPaymentWriter() {
		
		
		
		AutoPaymentWriter autoPaymentWriter = context.getBean(AutoPaymentWriter.class);

		try {
			autoPaymentWriter.setMongoTemplate(mongoTemplate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return autoPaymentWriter;
	}


}
