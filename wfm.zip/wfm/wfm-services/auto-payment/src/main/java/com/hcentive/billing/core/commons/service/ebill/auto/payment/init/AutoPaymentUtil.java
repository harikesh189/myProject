package com.hcentive.billing.core.commons.service.ebill.auto.payment.init;

import com.hcentive.billing.core.commons.tenant.util.TenantUtil;

public class AutoPaymentUtil {
	
	public static final String AUTOPAYMENT_RECORD_COLLECTION_AFFIX = "autoPayment";
	
	public static String resolveCollectionName() {
		return TenantUtil.getBuilderWithTenantIdPrefixed().append(AUTOPAYMENT_RECORD_COLLECTION_AFFIX).toString();
	}


}
