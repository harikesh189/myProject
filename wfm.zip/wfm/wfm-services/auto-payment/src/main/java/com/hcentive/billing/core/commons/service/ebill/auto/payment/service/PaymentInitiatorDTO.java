package com.hcentive.billing.core.commons.service.ebill.auto.payment.service;

import com.hcentive.billing.core.commons.xsdtopojo.PaymentEnhancedRequestType;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

public class PaymentInitiatorDTO {
	
	private PaymentEnhancedRequestType paymentEnhancedRequestType;
	private PaymentRecord paymentRecord;
	public PaymentEnhancedRequestType getPaymentEnhancedRequestType() {
		return paymentEnhancedRequestType;
	}
	public void setPaymentEnhancedRequestType(
			PaymentEnhancedRequestType paymentEnhancedRequestType) {
		this.paymentEnhancedRequestType = paymentEnhancedRequestType;
	}
	public PaymentRecord getPaymentRecord() {
		return paymentRecord;
	}
	public void setPaymentRecord(PaymentRecord paymentRecord) {
		this.paymentRecord = paymentRecord;
	}

}
