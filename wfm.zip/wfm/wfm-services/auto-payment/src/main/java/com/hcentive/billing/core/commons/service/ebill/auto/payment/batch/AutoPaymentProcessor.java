/**
 * 
 */
package com.hcentive.billing.core.commons.service.ebill.auto.payment.batch;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.data.domain.Page;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.hcentive.billing.core.commons.domain.EbillSubscription;
import com.hcentive.billing.core.commons.domain.EbillSchedulePayment;
import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.domain.InvoiceStatus;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.vo.AutoPaymentDto;
import com.hcentive.billing.core.commons.vo.CriteriaOperator;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.SearchCriteria;

/**
 * @author Mohit Gupta
 * 
 */

public class AutoPaymentProcessor implements
		ItemProcessor<Object, AutoPaymentDto> {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(AutoPaymentProcessor.class);

	protected MongoTemplate mongoTemplate;

	private FilterSupportRepository filterSupportRepository;

	public AutoPaymentProcessor() {
		super();
	}

	public AutoPaymentProcessor(FilterSupportRepository filterSupportRepository) {
		super();
		this.filterSupportRepository = filterSupportRepository;
	}

	@Override
	public AutoPaymentDto process(Object obj) throws Exception {
		logger.debug("AutoPaymentProcessor is called");
		AutoPaymentDto autoPaymentDto = null;
		if (null != obj && obj instanceof EbillSchedulePayment) {
			EbillSchedulePayment ebillSchedulePayment = (EbillSchedulePayment) obj;
			logger.debug("Schedule Payment with ID "+ebillSchedulePayment.getId()+ " is being processed.");
			Invoice invoice = getCurrentInvoiceOfSubscription(ebillSchedulePayment.getSubscription());
			autoPaymentDto = new AutoPaymentDto(
					ebillSchedulePayment.getIdentity(), invoice != null?invoice.getIdentity():null,
							ebillSchedulePayment.getSubscription().getIdentity() , 
							ebillSchedulePayment.getSavedFor()
							.getIdentity(), "PAYMENT_REQUEST_INITIATED",
					new DateTime(),
					ebillSchedulePayment.getPaymentReferenceId());
		}
		if (null != autoPaymentDto) {
			logger.debug("Auto Payment Request is initiated with Recuring Setup:"
					+ autoPaymentDto.getEbillRecurringSetup());
			logger.debug("Auto Payment Request is initiated with Invoice Summary:"
					+ autoPaymentDto.getInvoiceSummary());
			logger.debug("Auto Payment Request is initiated with SubscriptionId:"
					+ autoPaymentDto.getSubscriptionId());
		} else {
			logger.debug("autoPaymentDto is null");
		}
		return autoPaymentDto;

	}

	@SuppressWarnings("deprecation")
	private Invoice getCurrentInvoiceOfSubscription(EbillSubscription subscription) {

		SearchCriteria criteria = new SearchCriteria();

		List<String> stausList = new ArrayList<String>();
		stausList.add(InvoiceStatus.OPEN.getStatus());
		criteria.addMultiValueCriteria("status", CriteriaOperator.IN,
				stausList);

		criteria.addSingleValueCriteria("subscription.identity", CriteriaOperator.EQUALS, subscription.getIdentity());
		Page<Invoice> invoices = filterSupportRepository
				.findDomainByFilterCriteria(Invoice.class, criteria);

		if (invoices != null && invoices.hasContent())
			return invoices.getContent().get(0);

		return null;
	}

	public void setMongoTemplate(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}

}
