/**
 * 
 */
package com.hcentive.billing.core.commons.service.ebill.auto.payment.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.vo.CriteriaOperator;
import com.hcentive.billing.core.commons.vo.ItemRecord;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

/**
 * @author Mohit Gupta
 */
@Component
public class AutoPaymentReconciliationProcessor implements ItemProcessor<Object, ItemRecord> {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(AutoPaymentReconciliationProcessor.class);

	private FilterSupportRepository filterSupportRepository;

	public AutoPaymentReconciliationProcessor() {
		super();
	}

	public AutoPaymentReconciliationProcessor(final FilterSupportRepository filterSupportRepository) {
		super();
		this.filterSupportRepository = filterSupportRepository;
	}

	@Override
	public ItemRecord process(final Object obj) throws Exception {

		logger.debug("AutoPaymentProcessor is called");

		final ItemRecord item = (ItemRecord) obj;

		final SearchCriteria criteria = new SearchCriteria();

		criteria.addSingleValueCriteria("itemRecordId", CriteriaOperator.EQUALS, item.getId());

		final Page<PaymentRecord> paymentRecords = this.filterSupportRepository.findDomainByFilterCriteria(PaymentRecord.class, criteria);

		String status = null;
		if (paymentRecords != null && paymentRecords.hasContent()) {

			status = paymentRecords.getContent().get(0).getStatus();

		} else {
			status = null;
		}

		item.getItem().setStatus(status);

		return item;
	}
}
