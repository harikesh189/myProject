package com.hcentive.billing.core.commons.service.ebill.auto.payment.batch;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.service.ebill.auto.payment.init.AutoPaymentUtil;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.service.AutoPaymentInitiate;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.service.PaymentInitiatorDTO;
import com.hcentive.billing.core.commons.vo.AutoPaymentDto;
import com.hcentive.billing.core.commons.vo.ItemRecord;
import com.hcentive.billing.core.commons.xsdtopojo.PaymentEnhancedRequestType;
import com.hcentive.billing.payment.service.XPGServiceRequestDelegate;

@Component
public class AutoPaymentWriter implements ItemWriter<Object> {

	private static final Logger logger = LoggerFactory
			.getLogger(AutoPaymentWriter.class);

	protected MongoTemplate mongoTemplate;
	
	@Autowired
	private AutoPaymentInitiate autoPaymentInitiate;
	
	@Autowired
	private XPGServiceRequestDelegate xpgServiceRequestDelegate;

	@Override
	public void write(List<? extends Object> items) throws Exception {

		logger.debug("Getting auto payment Dto object in Writer");
		for (Iterator iterator = items.iterator(); iterator.hasNext();) {
			AutoPaymentDto autoPaymentDto = (AutoPaymentDto) iterator.next();

			// write in mongo

			logger.debug("Recuring Setup:"
					+ autoPaymentDto.getEbillRecurringSetup());
			logger.debug("Invoice Summary:"
					+ autoPaymentDto.getInvoiceSummary());
			logger.debug("SubscriptionId:" + autoPaymentDto.getSubscriptionId());
			
			ItemRecord itemRecord = mongoTemplate.findOne(
					Query.query(Criteria.where("item.paymentRefId").is(
							autoPaymentDto.getPaymentRefId())),
					ItemRecord.class, AutoPaymentUtil.resolveCollectionName());
			if (itemRecord == null) {
				itemRecord = new ItemRecord(autoPaymentDto,
						autoPaymentDto.getPaymentRefId());
				autoPaymentDto.setRetryCount(autoPaymentDto.getRetryCount());

				logger.info("Saving Auto Payment Record in Mongo.");
				mongoTemplate.save(itemRecord, AutoPaymentUtil.resolveCollectionName());
			} else {

				if ("PAYMENT_REQUEST_INITIATED".equals(itemRecord.getItem()
						.getStatus())
						|| "PAYMENT_REQUEST_SUCCESSFULL".equals(itemRecord
								.getItem().getStatus())) {

					logger.error("Auto Payment is already initiated for this paymentReference id so skipping this:"
							+ itemRecord.getId());
					continue;
				}

				final Update update = new Update();
				update.set("item.retryCount", itemRecord.getItem()
						.getRetryCount() + 1);
				update.set("item.status", autoPaymentDto.getStatus());
				logger.info("Updating Auto Payment Record in Mongo[Retry Count]:"
						+ itemRecord.getItem().getRetryCount() + 1);
				mongoTemplate.updateFirst(
						fetchQueryForRecordId(itemRecord.getId()), update,
						ItemRecord.class, AutoPaymentUtil.resolveCollectionName());
			}
			PaymentInitiatorDTO paymentInitiatorDTO  = autoPaymentInitiate.initiatePayment(autoPaymentDto);
			
			if(paymentInitiatorDTO != null){
			
				logger.debug("Calling PG WEB service for payment for Schedule Payment "+ autoPaymentDto.getEbillRecurringSetup());
				try{
					xpgServiceRequestDelegate.processXPGServiceRequest(paymentInitiatorDTO.getPaymentEnhancedRequestType(),"EBILL");
					
				}catch(Exception e){
					
					logger.error("Payment Failed due to reason: "+e.getMessage());
					e.printStackTrace();
					
					autoPaymentInitiate.failedPayment(paymentInitiatorDTO.getPaymentRecord());
				}
			}
		}
	
	}

	private Query fetchQueryForRecordId(final String recordId) {
		logger.debug("Fetching the record with recordId" + recordId);
		final Query query = Query.query(Criteria.where("id").is(recordId));
		return query;
	}

	public void setMongoTemplate(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}
}
