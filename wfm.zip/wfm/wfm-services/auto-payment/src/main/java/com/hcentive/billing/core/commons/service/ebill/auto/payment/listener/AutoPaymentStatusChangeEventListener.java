package com.hcentive.billing.core.commons.service.ebill.auto.payment.listener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationConstant;
import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.domain.EbillSchedulePayment;
import com.hcentive.billing.core.commons.domain.Invoice;
import com.hcentive.billing.core.commons.domain.InvoiceStatus;
import com.hcentive.billing.core.commons.domain.Period;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.enumtype.SchedulePaymentType;
import com.hcentive.billing.core.commons.domain.enumtype.SchedulerType;
import com.hcentive.billing.core.commons.domain.enumtype.SheduleAmountType;
import com.hcentive.billing.core.commons.dto.AutoPaymentPeriodWindow;
import com.hcentive.billing.core.commons.event.Event;
import com.hcentive.billing.core.commons.event.EventHandler;
import com.hcentive.billing.core.commons.event.EventSubscription;
import com.hcentive.billing.core.commons.event.EventType;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.persistence.repository.SchedulePaymentRepository;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.init.AutoPaymentUtil;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.CriteriaOperator;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.vo.ItemRecord;
import com.hcentive.billing.core.commons.vo.SearchCriteria;
import com.hcentive.billing.payment.support.period.strategy.FixedDayOfMonthStrategy;
import com.hcentive.billing.payment.support.period.strategy.LastDayOfMonthStrategy;
import com.hcentive.billing.payment.support.period.strategy.SchedulePaymentPeriodStrategy;
import com.hcentive.billing.wfm.domain.event.PaymentRecordChangeEvent;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

@Component
public class AutoPaymentStatusChangeEventListener implements EventHandler {
	private static final Logger logger = LoggerFactory
			.getLogger(AutoPaymentStatusChangeEventListener.class);

	@Autowired
	protected MongoTemplate mongoTemplate;

	@Autowired
	private FilterSupportRepository filterSupportRepository;

	@Autowired
	private SchedulePaymentRepository schedulePaymentRepository;

	@EventSubscription(eventName = EventType.PAYMENT_RECORD_STATUS_CHANGE)
	@Transactional
	public void handlePaymentStatusChange(
			final PaymentRecordChangeEvent paymentRecordChangeEvent)
			throws InterruptedException, ExecutionException {
		logger.debug("Received Payment Status Changed Event for Payment Record:"
				+ paymentRecordChangeEvent.getRecord().getIdentity());
		
		LinkedHashMap maxRetryAttempts = null;
		LinkedHashMap cutOffHour = null;
		LinkedHashMap retryIntreval = null;
		
		String paymentStatus = paymentRecordChangeEvent.getRecord().getStatus();

		ItemRecord itemRecord = mongoTemplate.findOne(
				fetchQueryForRecordId(paymentRecordChangeEvent.getRecord()
						.getItemRecordId()), ItemRecord.class,
						AutoPaymentUtil.resolveCollectionName());

		if (itemRecord != null) {

			final Update update = new Update();
			update.set("item.status", paymentStatus);

			mongoTemplate.updateFirst(
					fetchQueryForRecordId(paymentRecordChangeEvent.getRecord()
							.getItemRecordId()), update, ItemRecord.class,
							AutoPaymentUtil.resolveCollectionName());

			logger.debug("Payment Record item updated for record ID:"
					+ itemRecord.getId());

			Set<Reference<String, EbillSchedulePayment, String>> schedulePaymentRefs = paymentRecordChangeEvent
					.getRecord().referencesByType(EbillSchedulePayment.class,
							String.class, String.class);
			if (!schedulePaymentRefs.isEmpty()) {
				AutoPaymentPeriodWindow autoPaymentPeriodWindow = new AutoPaymentPeriodWindow();
				@SuppressWarnings("rawtypes")
				Reference ref = schedulePaymentRefs.iterator().next();

				logger.debug("Retrieving Schedule Payment Setup Reference from Payment Record");
				EbillSchedulePayment schedulePaymentSetup = schedulePaymentRepository
						.findByIdentity((String) ref.getReferenceId());
				String frequencyType = schedulePaymentSetup.getFrequencyType();

				logger.debug("Get Schedule Payment Setup for Auto Payment Shift: "
						+ schedulePaymentSetup.getIdentity());

				autoPaymentPeriodWindow
						.setRecurringSetupId(schedulePaymentSetup.getIdentity());

				autoPaymentPeriodWindow.setEndsOn(schedulePaymentSetup
						.getPaymentWindowPeriod().getEndsOn());
				
				if (paymentStatus.equals(PaymentRecord.STATUS_FAILED)) {

					logger.debug("Get Auto payment configurations from Cache");

					 cutOffHour =
					 ConfigurationUtil.get(ConfigurationConstant.AUTOPAYMENT_CUTOFF_HOUR);
					 maxRetryAttempts =
					 ConfigurationUtil.get(ConfigurationConstant.AUTOPAYMENT_MAX_RETRY);
					 retryIntreval =
					 ConfigurationUtil.get(ConfigurationConstant.AUTOPAYMENT_RETRY_INTREVAL);

					 int maxRetry =0;
					 float retryIntv = 0;
					 
					logger.debug("##################################################################################");
					logger.debug("##################################################################################");
					logger.debug("##################################################################################");
					if(cutOffHour != null){
						logger.debug("Cut of hour for auto payment" + cutOffHour.get("value"));
					}
					if(maxRetryAttempts != null){
						logger.debug("Max retry for auto payment"
							+ maxRetryAttempts.get("value"));
						maxRetry = Integer.parseInt((String)maxRetryAttempts.get("value"));
					}
					if(retryIntreval != null){
						logger.debug("Retry intreval for auto payment"
							+ retryIntreval.get("value"));
						retryIntv = Float.parseFloat((String)retryIntreval.get("value"));
					}
					logger.debug("##################################################################################");
					logger.debug("##################################################################################");
					logger.debug("##################################################################################");

					if (itemRecord.getItem().getRetryCount() < maxRetry) {
						logger.debug("Setting next retry window for Auto Payment:"
								+ retryIntreval);


						int retryMinute = (int) Math.floor(retryIntv * 60);

						autoPaymentPeriodWindow.setBeginsOn(DateTime
								.getCurrentTime().plusMinutes(retryMinute));

					} else {
						logger.debug("Auto Payment retry count exhausted."
								+ itemRecord.getItem().getRetryCount());
						autoPaymentPeriodWindow = reschedule(
								autoPaymentPeriodWindow, schedulePaymentSetup,
								frequencyType);

						autoPaymentPeriodWindow.setPaymentRefId(RandomGenerator
								.randomReadableString());
					}

					EventUtils.publish(new Event<AutoPaymentPeriodWindow>(
							EventType.AUTO_PAYMENT_WINDOW_SHIFT,
							autoPaymentPeriodWindow));
				} else {
					// payment success

					if (SchedulePaymentType.RECURRINGSETUP.getName().equals(
							schedulePaymentSetup.getType().getName())) {

						autoPaymentPeriodWindow = reschedule(
								autoPaymentPeriodWindow, schedulePaymentSetup,
								frequencyType);
						// need to update the payment_ref_id
						autoPaymentPeriodWindow.setPaymentRefId(RandomGenerator
								.randomReadableString());

					} else {
						autoPaymentPeriodWindow
								.setBeginsOn(schedulePaymentSetup
										.getPaymentWindowPeriod().getEndsOn()
										.plusDays(1));
					}

					EventUtils.publish(new Event<AutoPaymentPeriodWindow>(
							EventType.AUTO_PAYMENT_WINDOW_SHIFT,
							autoPaymentPeriodWindow));
				}
			} else {
				logger.debug("No Recurring Setup Reference found from Payment Record");
			}

		} else {

			logger.debug("Request is not initiated from auto payment");
		}
	}

	private AutoPaymentPeriodWindow reschedule(
			AutoPaymentPeriodWindow autoPaymentPeriodWindow,
			EbillSchedulePayment schedulePaymentSetup, String frequencyType) {

		if (SchedulerType.DAYBEFOREDUEDATE.getName().equals(frequencyType)
				|| SchedulerType.ONDUEDATE.getName().equals(frequencyType)
				|| SchedulerType.ONRECEIPT.getName().equals(frequencyType)
				|| SchedulerType.FIXEDDATE.getName().equals(frequencyType)) {
			autoPaymentPeriodWindow.setBeginsOn(schedulePaymentSetup
					.getPaymentWindowPeriod().getEndsOn().plusDays(1));
		} else {

			SchedulePaymentPeriodStrategy schedulePaymentPeriodStrategy = null;

			if (SchedulerType.DAYOFMONTH.getName().equals(frequencyType)) {
				schedulePaymentPeriodStrategy = new FixedDayOfMonthStrategy();
			} else if (SchedulerType.LASTDAYOFMONTH.getName().equals(
					frequencyType)) {
				schedulePaymentPeriodStrategy = new LastDayOfMonthStrategy();
			}
			
			if (schedulePaymentPeriodStrategy != null) {
				Period paymentPeriod = schedulePaymentPeriodStrategy
						.resolveSchedulePaymentPeriod(schedulePaymentSetup,
								null, null, schedulePaymentSetup.getSchedulePaymentWindowPeriod().getStartDate());
				paymentPeriod.setBeginsOn(paymentPeriod.getBeginsOn().plusMonths(1));
				paymentPeriod.setEndsOn(paymentPeriod.getEndsOn().plusMonths(1));

				autoPaymentPeriodWindow = new AutoPaymentPeriodWindow(
						schedulePaymentSetup.getIdentity(),
						paymentPeriod.getBeginsOn(), paymentPeriod.getEndsOn());
			}
		}
		return autoPaymentPeriodWindow;
	}

	@EventSubscription(eventName = EventType.NEW_RECURRING_SETUP_ADDED)
	public void handleRecurringSetupaddedListener(
			final EbillSchedulePayment schedulePayment)
			throws InterruptedException, ExecutionException {
		processSchedulePaymentSetup(schedulePayment);
	}

	@EventSubscription(eventName = EventType.NEW_SCHEDULE_PAYMENT_ADDED)
	public void handleschedulePaymentSetupaddedListener(
			final EbillSchedulePayment schedulePayment)
			throws InterruptedException, ExecutionException {
		processSchedulePaymentSetup(schedulePayment);
	}
	
	private void processSchedulePaymentSetup(
			final EbillSchedulePayment schedulePayment)
			throws InterruptedException, ExecutionException {
		logger.debug("Received NEW_SCHEDULE_PAYMENT_ADDED Event for Payment Record:"
				+ schedulePayment.getIdentity());

		final String frequencyType = schedulePayment.getFrequencyType();
		final SchedulerType scheduleType = SchedulerType.parse(frequencyType);
		SchedulePaymentPeriodStrategy schedulePaymentPeriodStrategy = getStrategy(scheduleType);
		AutoPaymentPeriodWindow autoPaymentPeriodWindow = null;
		Period paymentPeriod = null;
		Invoice currentInvoice = null;
		LinkedHashMap cutOffHour = null;
		Integer cutOfHour =0;
		
		cutOffHour = ConfigurationUtil
				.get(ConfigurationConstant.AUTOPAYMENT_CUTOFF_HOUR);

		if(cutOffHour != null){
			logger.debug("Cut of Hour from configuration is: " + cutOffHour.get("value"));
			
			cutOfHour = Integer.parseInt(cutOffHour.get("value") != null?(String)cutOffHour.get("value"):"0");
		}
		if (scheduleAssociatedWithInvoiceOrBillCycle(scheduleType)) {
			currentInvoice = identifyCurrentInvoice(schedulePayment);
		}
		
		if (null != schedulePaymentPeriodStrategy) {
			paymentPeriod = schedulePaymentPeriodStrategy
					.resolveSchedulePaymentPeriod(schedulePayment,
							currentInvoice, cutOfHour, schedulePayment.getSchedulePaymentWindowPeriod().getStartDate());
		}
		if (paymentPeriod != null) {
			
			autoPaymentPeriodWindow = new AutoPaymentPeriodWindow(
					schedulePayment.getIdentity(), paymentPeriod.getBeginsOn(),
					paymentPeriod.getEndsOn());

			EventUtils.publish(new Event<AutoPaymentPeriodWindow>(
					EventType.AUTO_PAYMENT_WINDOW_SHIFT,
					autoPaymentPeriodWindow));
		}
	}

	@SuppressWarnings({ "deprecation" })
	private Invoice identifyCurrentInvoice(
			final EbillSchedulePayment schedulePayment) {
		Invoice currentInvoice = null;
		
		SearchCriteria criteria = new SearchCriteria();

		List<String> stausList = new ArrayList<String>();
		stausList.add(InvoiceStatus.OPEN.getStatus());
		criteria.addMultiValueCriteria("status", CriteriaOperator.IN,
				stausList);
		
		criteria.addSingleValueCriteria("subscription.identity", CriteriaOperator.EQUALS, 
				schedulePayment.getSubscription().getIdentity());

		Page<Invoice> currentInvoiceList = filterSupportRepository
				.findDomainByFilterCriteria(Invoice.class, criteria);

		if (currentInvoiceList.hasContent()) {
			currentInvoice = currentInvoiceList.getContent().get(0);
		}
		return currentInvoice;
	}

	private SchedulePaymentPeriodStrategy getStrategy(SchedulerType type) {
		if (null != type) {
			return (SchedulePaymentPeriodStrategy) Factories.INSTANCE.factory(
					SchedulePaymentPeriodStrategy.class).get(type);
		}
		return null;
	}

	private boolean scheduleAssociatedWithInvoiceOrBillCycle(SchedulerType type) {
		if (null != type) {
			switch (type) {
			case DAYBEFOREDUEDATE:
			case ONDUEDATE:
			case DAYOFCYCLE:
			case ONRECEIPT:
				return true;
			case DAYOFMONTH:
			case FIXEDDATE:
			case LASTDAYOFMONTH:
			case DAYOFFORTNIGHT:
			case DAYOFQUARTER:
			case DAYOFSEMIANNUAL:
			case DAYOFWEEK:
			case PAYNOW:
					
				return false;
			}
		}
		return false;
	}
	
	private boolean scheduleAmountAssociatedWithInvoiceOrFlat(SheduleAmountType type) {
		if (null != type) {
			
			switch (type) {
			case INVOICE_AMOUNT:
			case MINIMUM_AMOUNT_DUE:
			case CURRENT_OUTSTANDING:
				return true;
			case FLAT_AMOUNT:
					
				return false;
			}
		}
		return false;
	}

	private Query fetchQueryForRecordId(final String recordId) {
		logger.debug("Fetching the record with recordId" + recordId);
		final Query query = Query.query(Criteria.where("id").is(recordId));
		return query;
	}
}
