package com.hcentive.billing.core.commons.service.ebill.auto.payment.service;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.ebill.auto.payment.repository.PaymentRecordRepository;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

@Component
public class PaymentRecordServiceImpl implements PaymentRecordService{
	
	@Autowired
	PaymentRecordRepository paymentRecordRepository;
	
	
	@Transactional(value=TxType.REQUIRES_NEW)
	public PaymentRecord savePaymentRecord(PaymentRecord pr) {
		return paymentRecordRepository.save(pr);
		
	};

}
