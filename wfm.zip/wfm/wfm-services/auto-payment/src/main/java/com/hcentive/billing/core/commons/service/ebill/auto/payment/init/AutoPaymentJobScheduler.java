/**
 * 
 */
package com.hcentive.billing.core.commons.service.ebill.auto.payment.init;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.service.cluster.job.ClusteredJob;

/**
 * @author Mohit Gupta
 * 
 */
@Component
public class AutoPaymentJobScheduler {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(AutoPaymentJobScheduler.class);

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	private Job autoPaymentReconciliationJob;
	
	@Autowired
	private Job autoPaymentJob;
	
	@Autowired
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplate;
	
	public static final String queryToInsert = "insert into schedule_payment_candidate  (id, tenant_id)  select id, tenant_id from schedule_payment WHERE status = 'Active' AND begins_on <= CURRENT_TIMESTAMP AND CURRENT_TIMESTAMP <= ends_on and start_date <= CURRENT_TIMESTAMP and (end_date is null or end_date >= CURRENT_TIMESTAMP)";

	public static final String queryToDelete = "delete from schedule_payment_candidate";
	
	@ClusteredJob(jobName="autoPaymentJob")
	public void triggerAutoPaymentJob() throws JobExecutionAlreadyRunningException,
	JobRestartException, JobInstanceAlreadyCompleteException,
	JobParametersInvalidException{
		
		
		jdbcTemplate = new JdbcTemplate(dataSource);
		
		jdbcTemplate.update(queryToDelete);
		
		jdbcTemplate.update(queryToInsert);
		try{
			JobParameters jobParameters = new JobParametersBuilder().addLong(
					"time", System.currentTimeMillis()).toJobParameters();
			logger.debug("Launching Auto Payment Job");
			jobLauncher.run(autoPaymentJob, jobParameters);
		}catch (Exception e){
			logger.error("Exception occured:"+e.getMessage());
			e.printStackTrace();
		}
		//jdbcTemplate.update(queryToDelete);
		
		logger.debug("Exit Auto Payment Job");
		
	}
	
	@ClusteredJob(jobName="autoPaymentReconciliationJob")
	public void triggerAutoPaymentReconcileJob() throws JobExecutionAlreadyRunningException,
	JobRestartException, JobInstanceAlreadyCompleteException,
	JobParametersInvalidException{
		
		logger.debug("Launching Auto Payment Reconciliation Job");

		JobParameters jobParameters = new JobParametersBuilder().addLong(
				"time", System.currentTimeMillis() + 3).toJobParameters();

		jobLauncher.run(autoPaymentReconciliationJob, jobParameters);
		logger.debug("Exit Auto Payment Reconciliation Job");
	}
	
}
