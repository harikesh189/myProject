package com.hcentive.billing.core.commons.service.ebill.auto.payment.repository;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;


@Transactional
public interface PaymentRecordRepository extends
JpaRepository<PaymentRecord, Long> {

	Collection<PaymentRecord> findByStatusAndTxnDateLessThan(
			final String status, final DateTime paymentDate);

	PaymentRecord findByIdentity(final String transactionId);

	public PaymentRecord getByIdentity(final String identity);
}