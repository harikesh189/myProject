package com.hcentive.billing.core.commons.service.ebill.auto.payment.batch;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.transaction.annotation.Transactional;

import com.hcentive.billing.core.commons.service.ebill.auto.payment.init.AutoPaymentUtil;
import com.hcentive.billing.core.commons.vo.ItemRecord;

@Transactional
public class AutoPaymentReconciliationWriter implements ItemWriter<Object> {

	protected MongoTemplate mongoTemplate;

	final private static Logger logger = LoggerFactory
			.getLogger(AutoPaymentReconciliationWriter.class);

	@Override
	public void write(List<? extends Object> items) throws Exception {

		for (Iterator iterator = items.iterator(); iterator.hasNext();) {
			ItemRecord itemRecord = (ItemRecord) iterator.next();

			if (itemRecord != null) {

				if (itemRecord.getItem().getStatus() != null) {
					final Update update = new Update();
					update.set("item.status", itemRecord.getItem().getStatus());

					mongoTemplate.updateFirst(
							fetchQueryForRecordId(itemRecord.getId()), update,
							ItemRecord.class, AutoPaymentUtil.resolveCollectionName());

					logger.debug("Payment Record item updated for record ID:"
							+ itemRecord.getId());
				} else {

					mongoTemplate.remove(itemRecord, AutoPaymentUtil.resolveCollectionName());
				}
			}
		}
	}

	public void setMongoTemplate(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}

	private Query fetchQueryForRecordId(final String recordId) {
		logger.debug("Fetching the record with recordId" + recordId);
		final Query query = Query.query(Criteria.where("id").is(recordId));
		return query;
	}

}
