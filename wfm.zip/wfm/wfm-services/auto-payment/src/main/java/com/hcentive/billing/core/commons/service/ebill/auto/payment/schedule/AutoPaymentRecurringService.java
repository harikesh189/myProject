package com.hcentive.billing.core.commons.service.ebill.auto.payment.schedule;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hcentive.billing.core.commons.factory.Factories;
import com.hcentive.billing.core.commons.factory.TaskAwareFactory;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.batch.AutoPaymentBatchJobExecutionListener;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.init.AutoPaymentConfigBean;
import com.hcentive.billing.payment.support.period.strategy.SchedulePaymentPeriodStrategy;

/***
 * 
 * @author Prateek.Bansal
 * @Scheduled Job fetch all the due Invoices and send Amount,Customer Id to
 *            Payment service
 * 
 */

@Configuration
public class AutoPaymentRecurringService{

	@Bean
	public AutoPaymentConfigBean autoPaymentConfigBean() {
		AutoPaymentConfigBean autoPaymentConfigBean = new AutoPaymentConfigBean();
		return autoPaymentConfigBean;
	}
	
	@Bean
	public AutoPaymentBatchJobExecutionListener autoPaymentBatchJobExecutionListener() {
		AutoPaymentBatchJobExecutionListener autoPaymentBatchJobExecutionListener = new AutoPaymentBatchJobExecutionListener();
		return autoPaymentBatchJobExecutionListener;
	}
	
	@Bean
	public TaskAwareFactory<SchedulePaymentPeriodStrategy> schedulePaymentPeriodStrategyFactory(){
		TaskAwareFactory<SchedulePaymentPeriodStrategy> paymentInstrumentValidateFactory = new TaskAwareFactory(
				SchedulePaymentPeriodStrategy.class);
		Factories.INSTANCE.registerBean(paymentInstrumentValidateFactory);
		
		
		return paymentInstrumentValidateFactory;
	}
}
