package com.hcentive.billing.core.commons.service.ebill.auto.payment.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.security.SystemUserOperation;


@Component
public class AutoPaymentCronRunner {
	

	private static final Logger logger = LoggerFactory
			.getLogger(AutoPaymentCronRunner.class);
	
	@Autowired
	private AutoPaymentJobScheduler jobLauncher;
	
	@Scheduled(cron = "${autopayment.frequency.prop}")
	@SystemUserOperation
	public void launchAutoPayment() throws JobExecutionAlreadyRunningException,
			JobRestartException, JobInstanceAlreadyCompleteException,
			JobParametersInvalidException {
		logger.debug("Auto Payment Scheduler bigins");
		jobLauncher.triggerAutoPaymentJob();
		logger.debug("Auto Payment Scheduler ends");
		
	}
	
	@Scheduled(cron = "${autopayment.reconciliation.prop}")
	@SystemUserOperation
	public void launchAutoPaymentReconciliation()
		throws JobExecutionAlreadyRunningException, JobRestartException,
				JobInstanceAlreadyCompleteException, JobParametersInvalidException {
			
		logger.debug("Auto Payment Reconcilation bigins");
		jobLauncher.triggerAutoPaymentReconcileJob();
		logger.debug("Auto Payment Reconcilation ends");
	}
}