/**
 * 
 */
package com.hcentive.billing.core.commons.service.ebill.auto.payment.batch;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

/**
 * @author Mohit Gupta
 * 
 */
public class AutoPaymentBatchJobExecutionListener implements
		JobExecutionListener {

	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(AutoPaymentBatchJobExecutionListener.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.batch.core.JobExecutionListener#beforeJob(org.
	 * springframework.batch.core.JobExecution)
	 */
	@Override
	public void beforeJob(JobExecution jobExecution) {
		logger.debug("Before Job Execution -  Status =  {}", jobExecution
				.getStatus().toString());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.batch.core.JobExecutionListener#afterJob(org.
	 * springframework.batch.core.JobExecution)
	 */
	@Override
	public void afterJob(JobExecution jobExecution) {
		logger.debug("AFter Job Execution -  Status =  {}", jobExecution
				.getStatus().toString());

		List<Throwable> failureExceptions = jobExecution.getFailureExceptions();
		if (failureExceptions != null && failureExceptions.size() > 0) {
			for (Throwable throwable : failureExceptions) {
				logger.error("Error while job execution", throwable);
				throwable.printStackTrace();
			}
		}

	}

}
