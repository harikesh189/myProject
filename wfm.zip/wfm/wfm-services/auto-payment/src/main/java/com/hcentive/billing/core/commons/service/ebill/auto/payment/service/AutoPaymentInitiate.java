package com.hcentive.billing.core.commons.service.ebill.auto.payment.service;

import com.hcentive.billing.core.commons.vo.AutoPaymentDto;
import com.hcentive.billing.core.commons.xsdtopojo.PaymentEnhancedRequestType;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

public interface AutoPaymentInitiate {
	
	PaymentInitiatorDTO initiatePayment(AutoPaymentDto autoPaymentDto);
	
	PaymentRecord failedPayment(PaymentRecord paymentRecord);

}
