package com.hcentive.billing.core.commons.service.ebill.auto.payment.init;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.hcentive.billing.core.commons.event.EventInterceptor;
import com.hcentive.billing.core.commons.event.EventUtils;
import com.hcentive.billing.core.commons.persistence.factory.VersionAwareJpaRepositoryFactoryBean;
import com.hcentive.billing.core.commons.service.event.EventHistoryLoggerInterceptor;

@PropertySources({
		@PropertySource("file:${baseDir}/config/properties/mongodb.properties"),
		@PropertySource("file:${baseDir}/config/properties/db.properties"),
		@PropertySource("file:${baseDir}/config/properties/app.properties"),
		@PropertySource("file:${baseDir}/config/properties/security.properties"),
		@PropertySource("file:${baseDir}/config/properties/cronJob.properties"),
		@PropertySource("file:${baseDir}/config/properties/payment.properties"),
		@PropertySource("file:${baseDir}/config/properties/amqp.properties") })
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.hcentive.billing" })
@EnableJpaRepositories(basePackages = {
		"com.hcentive.billing.core.commons.persistence.repository",
		"com.hcentive.billing.core.commons.starter.persistence.repository",
		"com.hcentive.billing.core.commons.service.ebill.configuration.repository",
		"com.hcentive.billing.core.commons.persistence.factory.repository",
		"com.hcentive.billing.core.commons.batch.repository",
		"com.hcentive.billing.core.commons.service.ebill.auto.payment.repository"}, repositoryFactoryBeanClass = VersionAwareJpaRepositoryFactoryBean.class)
@EnableMongoRepositories(basePackages = {"com.hcentive.billing.core.commons.starter.persistence.repository"})
@EntityScan({ "com.hcentive.billing.core.commons",
		"com.hcentive.billing.wfm.domain" })
@EnableBatchProcessing
@EnableScheduling
public class AutoPaymentInit {
	public static void main(String[] args) throws Exception {
		SpringApplication.run(AutoPaymentInit.class, args);
	}
	
	@Bean
	public EventInterceptor eventHistoryLoggerInterceptor(){
		EventInterceptor interceptor = new EventHistoryLoggerInterceptor();
		EventUtils.eventBus().addInterceptors(interceptor);
		return interceptor;
	}
}