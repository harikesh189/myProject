package com.hcentive.billing.core.commons.service.ebill.auto.payment.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcentive.billing.core.commons.configuration.util.ConfigurationConstant;
import com.hcentive.billing.core.commons.configuration.util.ConfigurationUtil;
import com.hcentive.billing.core.commons.constant.PaymentInitiator;
import com.hcentive.billing.core.commons.domain.BusinessEntity;
import com.hcentive.billing.core.commons.domain.EbillPaymentMethod;
import com.hcentive.billing.core.commons.domain.EbillSchedulePayment;
import com.hcentive.billing.core.commons.domain.EbillSubscription;
import com.hcentive.billing.core.commons.domain.InvoiceSummary;
import com.hcentive.billing.core.commons.domain.PaymentMethod;
import com.hcentive.billing.core.commons.domain.Reference;
import com.hcentive.billing.core.commons.domain.TokenPaymentMethod;
import com.hcentive.billing.core.commons.domain.enumtype.ReferenceCategory;
import com.hcentive.billing.core.commons.domain.enumtype.SchedulePaymentType;
import com.hcentive.billing.core.commons.id.ExternalIdGenerator;
import com.hcentive.billing.core.commons.persistence.factory.repository.EbillPaymentMethodRepository;
import com.hcentive.billing.core.commons.persistence.factory.repository.FilterSupportRepository;
import com.hcentive.billing.core.commons.persistence.factory.repository.OperatorRepository;
import com.hcentive.billing.core.commons.persistence.repository.InvoiceSummaryRepository;
import com.hcentive.billing.core.commons.persistence.repository.SchedulePaymentRepository;
import com.hcentive.billing.core.commons.persistence.repository.SubscriptionRepository;
import com.hcentive.billing.core.commons.request.transformers.builder.PaymentRequestTypeBuilder;
import com.hcentive.billing.core.commons.service.ebill.auto.payment.repository.PaymentRecordRepository;
import com.hcentive.billing.core.commons.util.RandomGenerator;
import com.hcentive.billing.core.commons.vo.Amount;
import com.hcentive.billing.core.commons.vo.AutoPaymentDto;
import com.hcentive.billing.core.commons.vo.Currency;
import com.hcentive.billing.core.commons.vo.DateTime;
import com.hcentive.billing.core.commons.xsdtopojo.ItemType;
import com.hcentive.billing.core.commons.xsdtopojo.LineItemType;
import com.hcentive.billing.core.commons.xsdtopojo.MarketType;
import com.hcentive.billing.core.commons.xsdtopojo.OneTimePaymentInfoType;
import com.hcentive.billing.core.commons.xsdtopojo.PaymentEnhancedRequestType;
import com.hcentive.billing.payment.service.XPGServiceRequestDelegate;
import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

@Component
public class AutoPaymentInitiateImpl implements AutoPaymentInitiate {

	private static final Logger LOGGER = LoggerFactory.getLogger(AutoPaymentInitiateImpl.class);
	
	@Autowired
	private InvoiceSummaryRepository invoiceSummaryRepository;
	
	@Autowired
	private EbillPaymentMethodRepository ebillPaymentMethodRepository;
	
	@Autowired 
	SchedulePaymentRepository schedulePaymentRepository;
	
	@Autowired
	FilterSupportRepository filterSupportRepository;
	
	@Autowired
	private PaymentRequestTypeBuilder instrumentToPaymentRequestsTransformer;
	
	@Autowired
	SubscriptionRepository subscriptionRepository;
	
	@Autowired
	private OperatorRepository operatorRepository;
	
	@Autowired
	private ExternalIdGenerator externalIdGenerator;
	
	

	@Autowired
	PaymentRecordRepository paymentRecordRepository;
	
	@Override
	@Transactional(value=TxType.REQUIRES_NEW)
	public PaymentInitiatorDTO initiatePayment(AutoPaymentDto autoPaymentDto) {
		
		LOGGER.info("In AutoPaymentInitiateImpl ");

		PaymentInitiatorDTO paymentInitiatorDTO = new PaymentInitiatorDTO();
		
		InvoiceSummary invoiceSummary = invoiceSummaryRepository.getByIdentity(autoPaymentDto.getInvoiceSummary());
		
		EbillSchedulePayment schedulePaymentSetup = schedulePaymentRepository.findByIdentity(autoPaymentDto.getEbillRecurringSetup());
		
		EbillSubscription subscription = subscriptionRepository.findByIdentity(autoPaymentDto.getSubscriptionId());
		
		TokenPaymentMethod tokenPaymentMethod = null;
		
		if(schedulePaymentSetup != null){
		
			tokenPaymentMethod = (TokenPaymentMethod)schedulePaymentSetup.getPaymentInstrument().getTokenInstrument();
			
			String identifier = tokenPaymentMethod.getTokenizedMethod().getIdentifier();
			
			String requestPaymentMethod = resolvePaymentMethod(identifier);
			
			String marketType = schedulePaymentSetup.getSavedFor().getType();
			Amount paybleAmount = schedulePaymentSetup.getSchedulePaymentAmount().getAmount(invoiceSummary);
			Amount discountAmount = Amount.newAmount(new BigDecimal(0));
			String discountStr = getDiscountFromConfigs(schedulePaymentSetup,
					requestPaymentMethod, marketType);
			
			if(discountStr != null){
				int dicountPercentage = Integer.parseInt(discountStr);
				
				BigDecimal discount = (paybleAmount.getValue().multiply( new BigDecimal(dicountPercentage)).divide(new BigDecimal(100)));
				
				discountAmount.setValue(discount);
				paybleAmount = paybleAmount.subtract(discountAmount);
				
			}
			
			LOGGER.debug("Amount to be Paid: "+paybleAmount.getValue());
			LOGGER.debug("Discount Amount  : "+discountAmount.getValue());
			
			Set<Reference> references = new HashSet<Reference>();
			
			Reference autoPaymentReqRef = Reference.newExternalReference(RandomGenerator.randomString(), "AUTO_PAYMENT", "AUTO_PAYMENT", "SYSTEM");
			autoPaymentReqRef.setCategory(ReferenceCategory.RELATED_ITEM);
			references.add(autoPaymentReqRef);
			
			if(subscription!=null) {
				references.add(Reference.newInternalReference(subscription));
				references.add(subscription.extIdReference());
				Reference groupIdReference = subscription.groupIdReference();
				if(groupIdReference != null) {
					references.add(groupIdReference);
				}
			}
			references.add(Reference.newInternalReference(schedulePaymentSetup));
			
			if(invoiceSummary != null){
				references.add(Reference.newInternalReference(invoiceSummary.getInvoice()));
			}
			
			MarketType marketType2 = null;
			String billingAccountId=null;
			BusinessEntity subscriber = null;
			
			if(subscription!=null){
				billingAccountId = subscription.getSubscriber().externalId();
				marketType2 = MarketType.fromValue(subscription.getSubscriber()
						.getType().toUpperCase());
				subscriber = subscription.getSubscriber();
			}
			
			EbillPaymentMethod paymentMethod = ebillPaymentMethodRepository.findByTokenInstrument(tokenPaymentMethod);
			
			BusinessEntity payer = schedulePaymentSetup.getSavedFor();
			
			final PaymentEnhancedRequestType paymentEnhancedRequest = this.instrumentToPaymentRequestsTransformer.
					transformEnhanced(tokenPaymentMethod, null,payer, paybleAmount,
					discountAmount, paybleAmount.add(discountAmount), RandomGenerator.randomReadableString(),marketType2, billingAccountId,
					paymentMethod, subscriber);
			
			instrumentToPaymentRequestsTransformer.addReferences(paymentEnhancedRequest, references, PaymentInitiator.AUTO);
			
			PaymentRecord paymentRecord = this.transformToPaymentRecord(paymentEnhancedRequest, references, tokenPaymentMethod, subscriber);
			paymentRecord.setPaymentInstrument(tokenPaymentMethod);
			paymentRecord.setItemRecordId(autoPaymentDto.getPaymentRefId());
			paymentRecord.setSubscription(subscription);
			if(schedulePaymentSetup != null && schedulePaymentSetup.getType().equals(SchedulePaymentType.RECURRINGSETUP))
				paymentRecord.setType("Recurring_Payment_Request");
			else
				paymentRecord.setType("OneTime_Payment_Request");
			
			paymentRecord = paymentRecordRepository.save(paymentRecord);
			
			paymentInitiatorDTO.setPaymentRecord(paymentRecord);
			paymentInitiatorDTO.setPaymentEnhancedRequestType(paymentEnhancedRequest);
			
			return paymentInitiatorDTO;
		}
		LOGGER.error("Recurring setup is null.");
		return null;
	}

	private String getDiscountFromConfigs(
				EbillSchedulePayment schedulePaymentSetup,
				String requestPaymentMethod, String marketType) {
			LinkedHashMap payment_configs = null;
			String discountStr;
			if("Individual".equalsIgnoreCase(marketType)){
				//get configurations from individual
				
				payment_configs =  ConfigurationUtil.get(ConfigurationConstant.INDIVIDUAL_PAYMENT_CONFIGURATION);
				
				if(schedulePaymentSetup.getType() == SchedulePaymentType.ONETIMEPAYMENTSETUP ){
					discountStr = resolveDiscountPercentage(payment_configs,"onetimepayment", requestPaymentMethod);
					
				}else{
					discountStr = resolveDiscountPercentage(payment_configs,"automaticpaymentsetup", requestPaymentMethod);
				}
				
				
			}else{
				//get configurations from group
				payment_configs =  ConfigurationUtil.get(ConfigurationConstant.GROUP_PAYMENT_CONFIGURATION);
				
				if(schedulePaymentSetup.getType() == SchedulePaymentType.ONETIMEPAYMENTSETUP ){
					discountStr = resolveDiscountPercentage(payment_configs,"onetimepayment", requestPaymentMethod);
					
				}else{
					discountStr = resolveDiscountPercentage(payment_configs,"automaticpaymentsetup", requestPaymentMethod);
				}
			}
			return discountStr;
		}

		@SuppressWarnings("rawtypes")
		private String resolveDiscountPercentage(LinkedHashMap payment_configs, String task, String requestPaymentMethod) {
			
			String discountPercentage = null;
			
			if(payment_configs != null && payment_configs.get("data") != null){
				
				LinkedHashMap paymentConfigs = (LinkedHashMap) ((LinkedHashMap)payment_configs.get("data")).get(task);
				
				if(paymentConfigs != null){
					List discountList = (ArrayList)paymentConfigs.get("discount");
					if(discountList != null){
						for (Iterator iterator = discountList.iterator(); iterator
								.hasNext();) {
							LinkedHashMap object = (LinkedHashMap) iterator.next();
							if(object != null && object.get("discountDef") != null){
								String paymentMethod = (String)((LinkedHashMap)object.get("discountDef")).get("paymentMethod");
								
								if(requestPaymentMethod != null && requestPaymentMethod.equalsIgnoreCase(paymentMethod)){
									discountPercentage = (String)((LinkedHashMap)object.get("discountDef")).get("percentage");
									return discountPercentage;
								}
							}
						}
					}
				}
			}
			
			return discountPercentage;
		}
		
		private String resolvePaymentMethod(String pm){
			
			switch(pm){
				case "BankAccount" : return "eft"; 
				case "Token-BankAccount" : return "eft";
				case "Card" : return "cc";
				case "Token-Card" : return "cc";
				default : return "eft";
			
			}
			
			
		}
		
		private PaymentRecord transformToPaymentRecord(final PaymentEnhancedRequestType paymentEnhancedRequestType, final Set<Reference> references,
				final PaymentMethod paymentInstrument, final BusinessEntity payFor) {

			PaymentRecord paymentRecord = this.transformPaymentRequestTypeToPaymentRecord(paymentEnhancedRequestType, payFor);
			paymentRecord.setSrc("EBILL");
			paymentEnhancedRequestType.getOneTimePaymentInfo().setTransactionId(paymentRecord.externalId());
			paymentRecord.setPaymentMode(paymentInstrument.getIdentifier());
			LOGGER.debug("Payment Record saving in DB for Ebill");
			paymentRecord.addReferences(references);
			paymentRecord.setOperator(this.operatorRepository.findByExternalId(payFor.getTenantId()));

			return paymentRecord;
		}

		private PaymentRecord transformPaymentRequestTypeToPaymentRecord(final PaymentEnhancedRequestType paymentEnhancedRequestType, final BusinessEntity customer) {
			final PaymentRecord paymentRecord = new PaymentRecord(RandomGenerator.randomString());
			final OneTimePaymentInfoType paymentRequestDetails = paymentEnhancedRequestType.getOneTimePaymentInfo();
			final Amount discountAmount = new Amount();
			final List<LineItemType> lines = paymentRequestDetails.getLineItems().getLineItem();
			for (final LineItemType lineItemType : lines) {
				if (ItemType.DISCOUNT.equals(lineItemType.getType())) {
					discountAmount.setValue(lineItemType.getAmount());
				}
			}
			paymentRecord.setDiscount(discountAmount);
			
			paymentRecord.setAmountPaid(new Amount(paymentRequestDetails.getAmount(), new Currency()));
			paymentRecord.setInvoiceDueAmount(new Amount(paymentRequestDetails.getAmountDue(), new Currency()));
			paymentRecord.setPayer(customer);
			paymentRecord.setTxnDate(new DateTime(new Date()));
			paymentRecord.setType("OneTime_Payment_Request");
			paymentRecord.setExternalId(externalIdGenerator.generateID(paymentRecord));
			return paymentRecord;
		}

		@Override
		@Transactional(value=TxType.REQUIRES_NEW)
		public PaymentRecord failedPayment(PaymentRecord paymentRecord) {
			
			paymentRecord = paymentRecordRepository.findByIdentity(paymentRecord.getIdentity());
			
			paymentRecord.failed();
			paymentRecord = paymentRecordRepository.save(paymentRecord);
			
			return paymentRecord;
		}

}
