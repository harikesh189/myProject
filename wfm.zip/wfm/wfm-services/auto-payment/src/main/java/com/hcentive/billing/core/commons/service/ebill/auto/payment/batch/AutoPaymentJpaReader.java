package com.hcentive.billing.core.commons.service.ebill.auto.payment.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaPagingItemReader;

public class AutoPaymentJpaReader<T> extends JpaPagingItemReader<T>{
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(AutoPaymentJpaReader.class);
	
	@Override
	protected void doReadPage() {
		try {
			super.doReadPage();
		} catch (Exception e) {
			LOGGER.error("Processing error in reading"+e.getMessage());
		}
	}
}
