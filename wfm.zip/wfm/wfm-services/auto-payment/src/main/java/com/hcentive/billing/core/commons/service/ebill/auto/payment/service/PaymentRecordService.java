package com.hcentive.billing.core.commons.service.ebill.auto.payment.service;

import com.hcentive.billing.wfm.domain.payment.PaymentRecord;

public interface PaymentRecordService {
	
	PaymentRecord savePaymentRecord(PaymentRecord pr);

}
