package com.hcentive.billing.core.commons.service.ebill.auto.payment;

import java.util.List;

import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = { AutoPaymentConfigBean.class,
//	AutoPaymentRecurringService.class })
public class AutoPaymentTest {

	@Autowired
	private JobRepository jobRepository;

	@Autowired
	private Job autoPaymentReconciliationJob;

	@Autowired
	private Job autoPaymentJob;

	@Autowired
	private JobLauncher jobLauncher;

	@Test
	public void test() {

		JobLauncherTestUtils jobLauncherTestUtils = new JobLauncherTestUtils();
		jobLauncherTestUtils.setJobRepository(jobRepository);
		jobLauncherTestUtils.setJob(autoPaymentJob);
		jobLauncherTestUtils.setJobLauncher(jobLauncher);

		JobExecution execution = null;
		try {
			execution = jobLauncherTestUtils.launchJob();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Throwable> failureExceptions = execution.getFailureExceptions();
		System.out.println(failureExceptions);

	}

	public static void main(String[] args) {

		String st = "0.5566";
		float rI = Float.parseFloat(st);

		int retryMinute = (int) Math.floor(rI * 60);

		System.out.println("Minute:" + retryMinute);

	}

}
