INSERT INTO ebill_user(
            dtype, id, external_id, identity, version)
    VALUES ('Administrator', 1, 1, 1, 1);



INSERT INTO permission(
            id, external_id, identity, version, description, operationcode, 
            operationname)
    VALUES (1, 1, 1, 1, 'Read', 'Read', 
            'Read');


INSERT INTO permission(
            id, external_id, identity, version, description, operationcode, 
            operationname)
    VALUES (2, 2, 2, 1, 'Write', 'Write', 
            'Write');


INSERT INTO role(
            id, external_id, identity, version, code, description, name)
    VALUES (1, 1, 1, 1, 'Admin', 'Admin', 'Admin');

INSERT INTO role_permissions(
            role, permissions)
    VALUES (1, 1);
INSERT INTO role_permissions(
            role, permissions)
    VALUES (1, 2);


INSERT INTO ebill_user_roles(
            ebill_user, roles)
    VALUES (1, 1);

INSERT INTO usercredential(
            id, external_id, identity, version, password, username)
    VALUES (1, 1, 1, 1, 'password', 'Admin');

