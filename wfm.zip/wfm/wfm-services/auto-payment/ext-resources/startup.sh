#!/bin/sh
clear
echo "Launching Auto payment Service."
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/log/wfm/auto-payment -Xloggc:/var/log/wfm/auto-payment/GC_`date '+%y%m%d_%H%M%S'`.log -Xms128m -Xmx256m -DbaseDir=. -Dlog4j.configuration=file:"./config/properties/log4j.properties" -jar auto-payment-1.0.RELEASE.jar --server.port=8104
