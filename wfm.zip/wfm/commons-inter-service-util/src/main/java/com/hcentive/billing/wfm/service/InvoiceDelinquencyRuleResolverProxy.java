/**
 * 
 */
package com.hcentive.billing.wfm.service;

import com.hcentive.billing.wfm.domain.bill.invoice.WFMInvoice;
import com.hcentive.common.inter.service.annotation.InterService;

/**
 * @author Dikshit.Vaid
 *
 */
@InterService
public interface InvoiceDelinquencyRuleResolverProxy extends
		DelinquencyRuleResolverProxy<WFMInvoice> {
}
