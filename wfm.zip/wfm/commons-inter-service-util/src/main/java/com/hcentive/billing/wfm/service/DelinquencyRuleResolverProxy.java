/**
 * 
 */
package com.hcentive.billing.wfm.service;

import com.hcentive.billing.core.commons.concurrent.promise.AsyncCallback;
import com.hcentive.billing.core.commons.concurrent.promise.IOU;
import com.hcentive.billing.core.commons.util.ServiceComm;
import com.hcentive.common.inter.service.annotation.InterServiceCall;
import com.hcentive.wfm.checkpoint.rule.CheckpointCycleConfiguration;

/**
 * @author Dikshit.Vaid
 *
 */

public interface DelinquencyRuleResolverProxy<D> {

	@InterServiceCall(service = ServiceComm.DELINQUENCY_CYCLE_CONFIGURATION)
	IOU<CheckpointCycleConfiguration, AsyncCallback<CheckpointCycleConfiguration>> findDelinquencyCycleConfiguration(
			D candidate);

}
