function checkValidate1() {

    var username = $('#username').val();
    var password = $('#password').val();
    if (username == "" && password == "") {
        alert("Pleas Enter the Username and Password");
        return false;
    }
    if (username == "operator" && password == "operator") {
        window.location = 'index.html';
        return false;
    }
    else {
        alert('Please check your username and password');
    }
    return true;
}