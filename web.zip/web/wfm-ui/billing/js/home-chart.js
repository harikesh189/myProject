showSingleReport('ReportPlanRevenueSummaryReport', ReportPlanRevenueSummaryReportXAxis, ReportPlanRevenueSummaryReportYAxis, ReportPlanRevenueSummaryReportData);
showSingleByCountReport('newEnrollmentStatusReport', newEnrollmentStatusReportXAxis, newEnrollmentStatusReportYAxis, newEnrollmentStatusReportData);
showSingleReport('customersInvoiceStatusReport', customersInvoiceStatusReportXAxis, customersInvoiceStatusReportYAxis, customersInvoiceStatusReportData);
showSingleReport('paymentsBySourceReport', paymentsBySourceReportXAxis, paymentsBySourceReportYAxis, paymentsBySourceReportData);
showSingleReport('remitReport', remitReportXAxis, remitReportYAxis, remitReportData);
showSingleReport('refundReport', refundByAmountReportXAxis, refundByAmountReportYAxis, refundByAmountReportData);
/*showSingleReport('paymentByMethodsReport', paymentByMethodsReportXAxis, paymentByMethodsReportYAxis, paymentByMethodsReportData);*/
showMultipleByCountReport('paymentsErrorReport', paymentsErrorReportXAxis, paymentsErrorReportYAxis, paymentsErrorReportData);
showSingleReport('partnerRevenueInvoiceReport', partnerRevenueInvoiceReportXAxis, partnerRevenueInvoiceReportYAxis, partnerRevenueInvoiceReportData);

jQuery(document).ready(function (e) {


});