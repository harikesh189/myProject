/*=======================OPerator Search=======================*/
$(function () {

    // Rules home table - delete and assign & unassign functionality
    $('table tr td .icon-remove').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Are You Sure",
                content: "This will remove the record.",
                type: "confirm",
                buttons: [
                    { value: "Yes" },
                    { value: "Cancel"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        },
    });

    $('.mainArticle .table-striped tbody tr:odd td, .mainArticle .table-striped tbody tr td tr:odd td').css('backgroundColor', '#ffffff');
    $('.mainArticle .table-striped tbody tr:even td, .mainArticle .table-striped tbody tr td tr:even td').css('backgroundColor', '#f8f8f8');

    $('#js-sideBarBtn').on('click', function () {
        var self, sideBar, content;

        self = $(this);
        sideBar = $('.mainSidebar');
        content = $('.contentContainer');

        if (self.hasClass('collapseBtn')) {
            sideBar.animate({
                width: 200
            }, function () {
                sideBar.find('.text').show();
            });

            content.animate({
                'margin-left': 200
            });

            self.removeClass('collapseBtn').addClass('expandBtn');
        }

        else if (self.hasClass('expandBtn')) {
            sideBar.find('.text').hide();
            $('.searchOperator').hide();
            $('.js-searchBtn-operator').show();
            sideBar.animate({
                width: 70
            });

            self.removeClass('expandBtn').addClass('collapseBtn');

            content.animate({
                'margin-left': 70
            });
        }
    });

    if ($('#js-sideBarBtn').hasClass('expandBtn')) {
        sideBar = $('.mainSidebar');
        content = $('.contentContainer');
        sideBar.animate({
            width: 200
        }, function () {
            sideBar.find('.text').show();
        });

        content.animate({
            'margin-left': 200
        });

    }

});
$(document).on('click', '.js-searchBtn-operator', function () {
    var className = $(this).parent().parent().prev().attr('class');
    if (className == 'expandBtn') {
        $(this).hide();
        $('.searchOperator').show();
    }
});
//end
$(document).ready(function () {
    //$('.profile').on('click',function(){
    //	$('.profileAccountBox').slideToggle('2000', "jswing", function () { });
    //});

    $('.profile').click(function (e) { // <----you missed the '.' here in your selector.
        e.stopPropagation();
        $('.profileAccountBox').slideToggle();
    });
    $('.profileAccountBox').click(function (e) {
        e.stopPropagation();
    });
    $(document).click(function () {
        $('.profileAccountBox').slideUp();
    });

    // Notification page
    $('.js-notificationSetting').on('click', function () {
        $('.js-changePasswordBox').hide();
        $(this).hide();
        $('.js-changePassword').show();
        $('.js-notificationBox').show();
    });
    $('.js-changePassword').on('click', function () {
        $('.js-notificationBox').hide();
        $(this).hide();
        $('.js-changePasswordBox').show();
        $('.js-notificationSetting').show();
    });


    // For Notify
    $('.billMe').on('click', function () {
        $('.cnfArea').slideDown();
    });
    $('.payBtnClk').on('click', function () {
        $('.jumptothanks').hide();
        $('.paidPage').show();

    });

    //to delete row
    $('.detLnk').on('click', function () {
        $(this).parents(".cardRow").hide();
    });


    $('table.tableNotification tr td img').hide();
    $('table.tableNotification tr').bind({
        mouseenter: function () {
            $(this).find("img").show();
        },
        mouseleave: function () {
            $(this).find("img").hide();
        }
    });


    $('table.tableNotification tr td img').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Are You Sure",
                content: "This will remove the selected notification",
                type: "confirm",
                buttons: [
                    { value: "Yes" },
                    { value: "Cancel"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        },
        mouseenter: function () {
            $(this).attr('src', '../images/delRowIcnClk.png');
        },
        mouseleave: function () {
            $(this).attr('src', '../images/delRowIcn.png');
        }
    });


    $('li.notify1').bind({
        mouseenter: function () {
            $(this).find(".topNote").show();
        },
        mouseleave: function () {
            $(this).find(".topNote").hide();
        }
    });


    $(".slideArea p").slideUp();
    $(".slideArea h3").click(function () {
        $(this).next("p").slideToggle('fast', function () {
        });
        $(this).find("span").toggleClass("active");
    });

    //Search Button
    $('.js-search').on('click', function () {
        $(this).hide();
        $('.searchInput').slideDown();
    });

    //Keep Track
    /*------------For Table*/
    $('#sortTable').dataTable(
        {
            "aaSorting": [
                [ 1, "desc" ]
            ],
            "sPaginationType": "full_numbers",
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": [
                    "copy",
                    "print",
                    "csv",
                    "xls",
                    "pdf"

                ]
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 6, 0 ] }
            ]
        }
    );

    $('#sortTableNoSearch').dataTable(
        {
            "sPaginationType": "full_numbers",
            "bFilter": false,
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": [
                    "copy",
                    "print",
                    "csv",
                    "xls",
                    "pdf"

                ]
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 5 ] }
            ]
        }
    );
    $('#egar').dataTable(
        {
            "sPaginationType": "full_numbers",
            "bFilter": false,
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": []
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 6 ] }
            ]
        }
    );
    $('#sortTable1').dataTable(
        {
            "sPaginationType": "full_numbers",
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": [
                    "copy",
                    "print",
                    "csv",
                    "xls",
                    "pdf"

                ]
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 7 ] }
            ]
        }
    );
    $('#sortTable2').dataTable(
        {
            "sPaginationType": "full_numbers",
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": [
                    "copy",
                    "print",
                    "csv",
                    "xls",
                    "pdf"

                ]
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 6 ] }
            ]
        }
    );
    $('#sortTable3').dataTable(
        {
            "sPaginationType": "full_numbers",
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": [
                    "copy",
                    "print",
                    "csv",
                    "xls",
                    "pdf"

                ]
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 4 ] }
            ]
        }
    );

    $('#sortTable4').dataTable(
        {
            "sPaginationType": "full_numbers",
            "bAutoWidth": false,
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": [
                    "copy",
                    "print",
                    "csv",
                    "xls",
                    "pdf"

                ]
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 0, 8 ] }
            ]
        }
    );
    $('#sortTable5').dataTable(
        {
            "sPaginationType": "full_numbers",
            "bAutoWidth": false,
            "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
            "oTableTools": {
                "sSwfPath": "../images/copy_csv_xls_pdf.swf",
                "aButtons": [
                    "copy",
                    "print",
                    "csv",
                    "xls",
                    "pdf"

                ]
            },
            "aoColumnDefs": [
                { 'bSortable': false, 'aTargets': [ 0, 6 ] }
            ]
        }
    );
    // add multiple select / deselect functionality
    $("#selectall").click(function () {
        if ($(this).prop('checked') == true) {
            $('.case').prop('checked', true);
        }
        if ($(this).prop('checked') == false) {
            $('.case').prop('checked', false);
        }

    })
    $(".case").click(function () {
        if ($(".case").length == $(".case:checked").length) {
            $("#selectall").attr("checked", "checked");
        } else {
            $("#selectall").removeAttr("checked");
        }
    });


    // if all checkbox are selected, check the selectall checkbox
    // and viceversa

    $("#addEmail").click(function () {
        if ($(this).prop('checked') == true) {
            $('.addEmail').slideDown();
        }
        if ($(this).prop('checked') == false) {
            $('.addEmail').slideUp();
        }

    })


});
/*=============Tipsy=================*/
$('.replaceInvoice, .deleteInvoice, .showTitle').tipsy({gravity: 'n', });
$('.graphtips').tipsy({gravity: 'w', });
$('.invoiceDetailsBtn').tipsy({gravity: 'w', });
/*$('#setting-tips, #search-tips, #reports-tips, #add-customer-tips, #groups-tips, #individuals-tips, #invoice-tips, #payment-tips, #batchqueue-tips, #announcement-tips, #track-user-tips, #manage-user-tips, #profile-info-tips, #preferences-tips, #message-tips, #rules-tips').tipsy({gravity: 'w',});
 */

// for checkbox and radio button
/*;(function(){
 $.fn.customRadioCheck = function() {
 return this.each(function() {

 var $this = $(this);
 var $span = $('<span/>');

 $span.addClass('custom-'+ ($this.is(':checkbox') ? 'check' : 'radio'));
 $this.is(':checked') && $span.addClass('checked'); // init
 $span.insertAfter($this);

 $this.parent('label').addClass('custom-label')
 .attr('onclick', ''); // Fix clicking label in iOS
 // hide by shifting left
 $this.css({ position: 'absolute', left: '-9999px' });

 // Events
 $this.on({
 change: function() {
 if ($this.is(':radio')) {
 $this.parent().siblings('label')
 .find('.custom-radio').removeClass('checked');
 }
 $span.toggleClass('checked', $this.is(':checked'));
 },
 focus: function() { $span.addClass('focus'); },
 blur: function() { $span.removeClass('focus'); }
 });
 });
 };

 }());*/
// UK Date Sorting 
jQuery.fn.dataTableExt.oSort['uk_date-asc'] = function (a, b) {

    var ukDatea = a.split('-');
    var ukDateb = b.split('-');

    var x = (ukDatea[2] + ukDatea[0] + ukDatea[1]) * 1;
    var y = (ukDateb[2] + ukDateb[0] + ukDateb[1]) * 1;
    return ((x < y) ? -1 : ((x > y) ? 1 : 0));
};

jQuery.fn.dataTableExt.oSort['uk_date-desc'] = function (a, b) {
    var ukDatea = a.split('-');
    var ukDateb = b.split('-');

    var x = (ukDatea[2] + ukDatea[0] + ukDatea[1]) * 1;
    var y = (ukDateb[2] + ukDateb[0] + ukDateb[1]) * 1;

    return ((x < y) ? 1 : ((x > y) ? -1 : 0));
}

jQuery.fn.dataTableExt.oSort['currency-asc'] = function (a, b) {
    /* Remove any commas (assumes that if present all strings will have a fixed number of d.p) */
    var x = a == "-" ? 0 : a.replace(/,/g, "");
    var y = b == "-" ? 0 : b.replace(/,/g, "");

    /* Remove the currency sign */
    x = x.substring(1);
    y = y.substring(1);

    /* Parse and return */
    x = parseFloat(x);
    y = parseFloat(y);
    return x - y;
};

jQuery.fn.dataTableExt.oSort['currency-desc'] = function (a, b) {
    /* Remove any commas (assumes that if present all strings will have a fixed number of d.p) */
    var x = a == "-" ? 0 : a.replace(/,/g, "");
    var y = b == "-" ? 0 : b.replace(/,/g, "");

    /* Remove the currency sign */
    x = x.substring(1);
    y = y.substring(1);

    /* Parse and return */
    x = parseFloat(x);
    y = parseFloat(y);
    return y - x;
};

$('#sortTableFull').dataTable(
    {
        "aaSorting": [
            [ 1, "desc" ]
        ],
        "sPaginationType": "full_numbers",
        "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
        "oTableTools": {
            "sSwfPath": "../images/copy_csv_xls_pdf.swf",
            "aButtons": [
                "copy",
                "print",
                "csv",
                "xls",
                "pdf"

            ]
        },
        "aoColumnDefs": [
            { 'bSortable': false, 'aTargets': [ 0, 6 ] },

            { "aTargets": ["uk-date-column"], "sType": "uk_date"},
            { "aTargets": ["uk-currency-column"], "sType": "currency"}
        ],


    }
);


$('.dropArrow').on('click', function () {
    $(this).toggleClass('dropArrow-active');
    $('.more-option').toggleClass('openMoreOption');

});
$('.cancel, .moreOptionsSave').on('click', function () {
    $('.more-option').removeClass('openMoreOption');
    $('.dropArrow').toggleClass('dropArrow-active');
});

$('.uploadButton').on('click', function () {
    $('.upload-option').toggleClass('openUploadOption');
    $(this).toggleClass('uploadButton-active');

});
$('.cancel, .uploadOptionsSave').on('click', function () {
    $('.upload-option').removeClass('openUploadOption');
    $('.uploadButton').toggleClass('uploadButton-active');
});


// RMHP Reports
$('#sortTableNoSearchNoIcons').dataTable(
    {

        "aaSorting": [
            [ 0, "asc" ]
        ],
        "sPaginationType": "full_numbers",
        "bFilter": false,
        "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
        "oTableTools": {
            "sSwfPath": "../images/copy_csv_xls_pdf.swf",
            "aButtons": false
        },
        "aoColumnDefs": [
            { 'bSortable': false, 'aTargets': [ 3 ] }
        ]
    }
);
// Broker - Homepage
$('#sortTableNoBrokerHome').dataTable(
    {

        "aaSorting": [
            [ 0, "asc" ]
        ],
        "sPaginationType": "full_numbers",
        "bFilter": false,
        "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
        "oTableTools": {
            "sSwfPath": "../images/copy_csv_xls_pdf.swf",
            "aButtons": false
        },
        "aoColumnDefs": [
            { 'bSortable': false, 'aTargets': [ 7 ] }
        ]
    }
);

$('#sortTableNoSearchClients').dataTable(
    {

        "aaSorting": [
            [ 0, "asc" ]
        ],
        "sPaginationType": "full_numbers",
        "bFilter": false,
        "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
        "oTableTools": {
            "sSwfPath": "../images/copy_csv_xls_pdf.swf",
            "aButtons": false
        },
        "aoColumnDefs": [
            { 'bSortable': false, 'aTargets': [ 6 ] }
        ]
    }
);
$('#sortTableNoSearchClientsgrp').dataTable(
    {

        "aaSorting": [
            [ 0, "asc" ]
        ],
        "sPaginationType": "full_numbers",
        "bFilter": false,
        "sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
        "oTableTools": {
            "sSwfPath": "../images/copy_csv_xls_pdf.swf",
            "aButtons": false
        },
        "aoColumnDefs": [
            { 'bSortable': false, 'aTargets': [ 7 ] }
        ]
    }
);