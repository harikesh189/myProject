/**
 *Common utility code required for JS is kept here
 *@Manish Bothiyal 
 */
var isEmptyStr = function(str) {
		return (!str || 0 === str.length);
}