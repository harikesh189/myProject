hcentive.WFM.reportConfiguration = {

			"WfmInvoiceSummaryPie" : {
				"from_date" : "MONTH_TO_DATE", // MONTH_TO_DATE e.g. 05/01/2014, Format : "MM/DD/YYYY"
				"to_date" : "CURRENT_DATE",   // CURRENT_DATE e.g. 05/15/2014, Format : "MM/DD/YYYY"
				"customer_type" : "All"
			   },
			
		    "WfmInvoiceSummaryBar" : {
				"from_date" : "MONTH_TO_DATE",
				"to_date" : "CURRENT_DATE",  
				"customer_type" : "All"
			   },
			   
		   "WfmInvoiceSummaryBarMonthly" : {
				"from_date" : "YEAR_TO_DATE",
				"to_date" : "CURRENT_DATE",  
				"customer_type" : "All"
			   },
			   
			  "wfminvoicestatus" : {
				"from_date" : "MONTH_TO_DATE", 
				"to_date" : "CURRENT_DATE",
				"customer_type" : "All"
			   },
			   
              "WfmInvoiceDetailsReport" : {
				"from_date" : "MONTH_TO_DATE", 
				"to_date" : "CURRENT_DATE",
				"customer_type" : "All"
			   },
			   
              "WfmInvoiceAgingSummaryPie" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE"
			  },
			
              "WfmInvoiceAgingReport" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "customer_type" : "All"
			  },
			  
			  "WfmInvoiceForecastAgingReport" : {
			    "forecast_date" : "CURRENT_DATE",
				 "customer_type" : "All"
			  },
			  
			  "WfmInvoiceForecastAgingSummaryBar" : {
			    "forecast_date" : "CURRENT_DATE"
			  },


			 "WfmPaymentSummaryReport" : {
			    "from_date" : "MONTH_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "customer_type" : "All"
			  },

			  "WfmPaymentSummaryBarReport" : {
			    "from_date" : "MONTH_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "customer_type" : "All"
			  },

			  "WfmPaymentsFailureReportBar" : {
			    "from_date" : "MONTH_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
				 "customer_type" : "All"
			  },

			  "WfmPaymentFailureReport" : {
			    "from_date" : "MONTH_TO_DATE", 
			    "to_date" : "CURRENT_DATE"
			  },

			  "WfmPaymentBySourceBar" : {
			    "from_date" : "MONTH_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
				"customer_type" : "All"
			  },

			  "WfmNewEnrollmentStatusBar" : {
			    "from_date" : "MONTH_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
				"customer_type" : "All"
			 },
			  
			  "WfmInvoiceSummaryTabReport" : {
			    "from_date" : "MONTH_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "customer_type" : "All"
			  },
			  "PartnerFinancialSummaryOutstanding" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "Select_Chart" : "Bar"
			  },
			  "PartnerFinancialSummaryInvoiced" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "Select_Chart" : "Pie"
			  },
			  "PartnerFinancialSummaryCollected" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "Select_Chart" : "Pie"
			  },
			  
			  "PartnerFinancialSummaryRemitted" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "Select_Chart" : "Pie"
			  },
			   "PartnerFinancialSummaryMembers" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "Select_Chart" : "Line"
			  } ,
			  
			   "PartnerFinancialSummaryPendingRemits" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "Select_Chart" : "Bar"
			  } ,
			  
			  "WfmPartnerRevenueSummarryTabularReport" : {
			    "from_date" : "YEAR_TO_DATE", 
			    "to_date" : "CURRENT_DATE",
			    "customer_type":"All"
			  },
			  "WfmReceivablesAgingCustomersReport" : {
				   "forecast_date" : "CURRENT_DATE",
				    "customer_type":"All"
			},
			  
			  "RemitHistoryReport" : {
			    "created_at" : "CURRENT_DATE"
			},
			  
			  "RemitHistoryForPartnerReport" : {
			    "created_at" : "CURRENT_DATE"
			},

			  
			  "RemitHistoryDetailForPartnerReport" : {
			    "created_at" : "CURRENT_DATE"
			},
			  
			  "CustomerRefundReport" : {
			    "created_at" : "CURRENT_DATE"
			},
			  
			  "CustomerRefundDetailsReport" : {
			    "created_at" : "CURRENT_DATE"
			},
			"BrokerBookOfBusiness":{
				"from_date" : "MONTH_TO_DATE", 
			    "to_date" : "MONTH_END_DATE"
			},
			"EnrollmentSummaryMainReport":{
				"from_date" : "MONTH_TO_DATE", 
			    "to_date" : "MONTH_END_DATE"
			}
			
};
