hcentive.WFM.retryCount=3;
hcentive.WFM.landingPage = "/home/dashboard";
hcentive.WFM.client_id="billing";
hcentive.WFM.clientConfigurations = [
    {
        "interestingEvents": [
            'delinquencyExceptionId',
            'DelinquencyExceptionRuleData',
            'beTypeFromInvoiceListing',
			'delinquencyIdentity',
			'delinquencyIdentityAndlifecycleMetadataObject',
			'saveCheckPointID',
			'delqEventName',
			'reinstatementEventName',
            'fetchFTEntry',
            'contractIdentity',
            'userLoggedIn',
            'customerSummaryObtained',
            'paymentMethodFetched',
            'paymentAmount',
            'totalOutStdng',
            'paymentMode',
            'paymentMethod',
            'prefferedPaymentMode',
            'amountStatus',
            'paymentMade',
            'discountAmount',
            'currentInvoiceIdentity',
            'paymentForm',
            'transactionId',
            'customerInfo',
            'contractUpdated',
            'invoiceIdentityBroker',
            'customerObjectBroker',
            'notificationRead',
            'rolesJson',
            'roleForUpdate',
            'permissionIds',
            'selectedPermissionIds',
            'ui_permissionIds',
            'clientType',
            'userIdentityOperator',
            'isPayOnlineBckCall',
            'brokerObjFromOperator',
            'brokerDetails',
            'healthPlanProviderDetails',
            'exchangeDetails',
            'vendorDetails',
            'clientDetails',
            'operatorDetails',
            'subsidyDetails',
            'otherEntityDetails',
            'contractRecordId',
            'memberDetails',
            'individualDetails',
            'groupDetails',
			'itemRecordId',
			'billCycleIdentity',
			'billCycleExternalId',
			'invoiceDetail',
            'contractType',
            'groupPolicyDetails',
            'issuerPolicyDetails',
            'individualPolicyDetails',
			'addPolicyEntityDetails',
			'goToRelatedBEIdentity',
			'beIdentity',
			'groupCustExtId' ,
			'billingAccountIdentity',
			'groupCustItemRecordId' ,
			'goToRelatedBAExternalId',
			'fetchIdentityForAssociatedEntity',
			'fetchBillCycleData',
			'pageBackURL',
			'subscriberId',
			'groupId',
			'WriteOffParameters',
			'remitPartnerDetails',
			'refundCustomerDetails',
			'remitDetails',
			'selectedCoveragePeriod',
			'eligibilityDetails',
			'goToRelatedBEExternalId',
			'writeOnDetails',
			'eventType',
			'beExternalId',
			'billingAccountRunCycles',
			'futureDateForInvoiceGenerationEntered',
			'addPaymentControllerTenantId',
			'addPaymentProcessCompletedSuccess',
			'addPaymentSelectedBeId',
			'addPaymentGeneralOrEntity',
			'isContractDetailFromHistory',
			'addWriteoffProcessCompletedSuccess',
			'adjustmentDetails',
			'EntityType',
			'addManualAdjustmentSelectedBeId',
			'manualAdjustmentExtId',
			'billable',
			'eventAdditionalId',
			'BEmetaInfo',
			'EntityParams',
			'ftEventData',
			'beAuditInfo',
			'invoiceExternalId',
			'paymentExternalId',
			'pageBackFilters',
			'billCycleExternalId',
			'onHoldEventType',
			'remitDetailsData',
			'remitId',
			'billingAccountExternalId'
        ],
        "Notifications": {
            "leftNav": [
                {
                    'labelDescription': 'DASHBOARD',
                    'labelPath': '/home/dashboard',
                    'labelIcon': 'icon-dashboard',
                    'labelClass': 'description'
                },
                { 'labelDescription': 'REPORTS',
                    'labelPath': '/reports/revenue',
                    'labelIcon': 'icon-reports',
                    'labelClass': 'description'}
            ]
        },
        "Profile": {
            "leftNav": [
                {
                    'labelDescription': 'PROFILE',
                    'labelPath': '/home/dashboard',
                    'labelIcon': 'icon-profile',
                    'labelClass': 'description'
                },
                { 'labelDescription': 'preferences',
                    'labelPath': '/reports/revenue',
                    'labelIcon': 'icon-preferences',
                    'labelClass': 'description'}
            ]
        },
        "Preferences": {
            "leftNav": [
                {
                    'labelDescription': 'PROFILE',
                    'labelPath': '/home/dashboard',
                    'labelIcon': 'icon-profile',
                    'labelClass': 'description'
                },
                { 'labelDescription': 'preferences',
                    'labelPath': '/reports/revenue',
                    'labelIcon': 'icon-preferences',
                    'labelClass': 'description'}
            ]
        },

        "breadCrumb": {
            "home": "Home",
            "notifications": "Notifications",
            "profile": "Profile",
            "preferences": "Preferences",
            "entities": "Entities",
            "entitiesPath": "#/entities/group",
            "eligibility": "Eligibility",
            "eligibilityPath": "#/entity/eligibility/individual",
            "individual": "Individual",
            "group": "Groups",
            "add-billing-item": "Add Write on",
            "individual": "Individuals",
            "broker": "Brokers",
            "health-plans": "Health Plans",
            "others": "Others",
            "financials": "Financial",
            "delinquency": "Delinquency Rules",
            "financialsPath": "#/financials/invoices",
            "invoices": "Invoices",
            "payments": "Payments",
            "accounts-and-ledgers": "Accounts",
            "rules": "Rules",
            "rulesPath": "#/rules/exceptionPolicies",
            "exceptionPolicies": "Policies",
            "policy-rule-view": "Policies",
            "policy-entity-view": "Policies",
            "bill-schedule": "Bill Schedule",
            "schedule-view": "Bill Schedule",
            "schedule-rule": "Bill Schedule",
            "billing-rule": "Billing Rule",
            "view": "Billing Rule",
            "add": "Billing Rule",
            "financials": "Financials",
            "financialRuleView": "Financials",
            "financialRule": "Financials",
            "financials-calculators": "Financials",
            "view-financial-charges": "Financials",
            "add-financial-charges": "Financials",
            "remittance-rules": "Remits",
            "invoice-review" :  "Invoice Review",
            "add-invoice-review-rule" :  "Invoice Review",
            "invoiceReviewRuleView" :"Invoice Review",
            "reports": "Reports",
            "reportsPath": "#/reports/revenue",
            "revenue": "Financial",
            "report-partner-revenue-flow-details": "Financial",
            "contract": "Contracts",
            "account": "Accounts",
            "invoices": "Invoices",
            "report-invoice-status":"Invoices",
            "report-invoice-aging-details":"Invoices",
            "report-invoice-forecast-aging-details":"Invoices",
            "payments": "Inbound Payments",
            "payment-summary": "Inbound Payments",
            "payment-failure": "Inbound Payments",
            "report-remittance-details": "Remits",
            "report-remit-details":"Remits",
            "remit-history-coverage-detail-report":"Remits",
            "remit-history-subscriber-detail-report":"Remits",
			"report-customer-refunds":"Customer Refunds",
            "broker-book-of-business": "ACA",
            "enrollment-summary": "ACA",
            "system": "Others",
            "systemPath": "#/system/eligibility/group",
            "bill-cycle": "Bill Cycles",
            "manage-users": "Users",
            "manage-permissions": "User Roles",
            "messaging": "Messaging",
            "processing": "Processing",
            "api-diagnostic": "API Diagnostics",
            "reinstatement": "Reinstatement Rules",
            "report-reinstatement" : "Reinstatement",
            "delinquency-status-report" : "Delinquency",
            "delinquency-history-report" : "Delinquency",
            "audit-log":"Audit",
			"delinquency-history-report-details" : "Delinquency",
			"outboundPayment" : "Outbound Payments"
        },
        "topNav": {
            "menus": [
                {
                    "mainMenu": "Home",
                    "href": "#/home/dashboard"
                },
                {
                    "mainMenu": "Entities",
                    "href": "#/entities/group",
                    "leftNav": [
                       
                        {
                            'labelDescription': 'Groups',
                            'labelPath': '/entities/group',
                            'labelIcon': 'icon-groups',
                            'labelClass': 'groups',
                            'key':'EntityGroup'	
                        },
                        {
                            'labelDescription': 'Subscribers',
                            'labelPath': '/entities/individual',
                            'labelIcon': 'icon-individuals',
                            'labelClass': 'individuals',
                            'key':'EntityIndividual'
                        },
                        {
                            'labelDescription': 'Brokers',
                            'labelPath': '/entities/broker',
                            'labelIcon': 'icon-broker',
                            'labelClass': 'individuals',
                            'key':'EntityBroker'
                        },
                        {
                            'labelDescription': 'Health Plans',
                            'labelPath': '/entities/health-plans',
                            'labelIcon': 'icon-health-plan',
                            'labelClass': 'individuals',
                            'key':'EntityHealthPlan'
                        },
                        {
                            'labelDescription': 'Others',
                            'labelPath': '/entities/others',
                            'labelIcon': 'icon-employee-report',
                            'labelClass': 'individuals',
                            'key':'EntityOthers'
                        }
                    ],
                    'key':'EntityHeader'
                } ,

                {
                    "mainMenu": "Financials",
                    "href": "#/financials/invoices/groups",
                    "leftNav": [
                        {
                            'labelDescription': 'Invoices',
                            'labelPath': '/financials/invoices/groups',
                            'labelIcon': 'icon-reports-invoices',
                            'labelClass': 'individuals',
                            'key':'FinancialsInvoices'
                        },
                        {
                            'labelDescription': 'Payments',
                            'labelPath': '/financials/payments',
                            'labelIcon': 'icon-reports-payments',
                            'labelClass': 'individuals',
                            'key':'FinancialsPayments'
                        },
						{
                            'labelDescription': 'Accounts',
                            'labelPath': '/financials/accounts-and-ledgers',
                            'labelIcon': 'icon-reports-accounts',
                            'labelClass': 'individuals',
                            'key':'FinancialsAccounts'
                        },
                       /* {
                            'labelDescription': 'Write offs',
                            'labelPath': '/financials/writeoff',
                            'labelIcon': 'icon-write-off',
                            'labelClass': 'individuals',
                            'key':'FinancialsWriteOff'
                        },*/
						{
                            'labelDescription': 'Remits',
                            'labelPath': '/financials/remits',
                            'labelIcon': 'icon-remit-notes',
                            'labelClass': 'individuals',
                            'key':'FinancialsRemits'
                        },
                        {
                            'labelDescription': 'Manual Adjustments',
                            'labelPath': '/financials/manual-adjustments/refunds-payments',
                            'labelIcon': 'icon-manual-adjustments',
                            'labelClass': 'individuals',
                            'key':'FinancialsManualAdjustment'
                           
                        }

                    ],
                    'key':'FinancialsHeader'
                },

                {
                    "mainMenu": "Rules",
                    "href": "#/rules/exceptionPolicies",
                    "leftNav": [
                        {
                            'labelDescription': 'Policies',
                            'labelPath': '/rules/exceptionPolicies',
                            'labelIcon': 'icon-entity',
                            'labelClass': 'individuals',
                            'key':'RulesPolicies'
                        },
                        {
                            'labelDescription': 'Bill schedule',
                            'labelPath': '/rules/bill-schedule',
                            'labelIcon': 'icon-billingCycleLarge',
                            'labelClass': 'individuals',
                            'key':'RulesBillSchedule'
                        },
                        {
                            'labelDescription': 'Billing',
                            'labelPath': '/rules/billing-rule',
                            'labelIcon': 'icon-billing-rule',
                            'labelClass': 'individuals',
                            'key':'RulesBilling'
                        },
                        {
                            'labelDescription': 'Financials',
                            'labelPath': '/rules/financials',
                            'labelIcon': 'icon-financial',
                            'labelClass': 'individuals',
                            'key':'RulesFinancials'
                        },
                        {
                            'labelDescription': 'Reinstatement Rule',
                            'labelPath': '/rules/reinstatement/reinstatement-rules',
                            'labelIcon': 'icon-reinstatement',
                            'labelClass': 'individuals',
                            'key':'ViewReinstatementRulesTab'
                        },
                        {
                            'labelDescription': 'Invoice Review Rule',
                            'labelPath': '/rules/invoice-review',
                            'labelIcon': 'icon-invoice-review-rule',
                            'labelClass': 'individuals',
                            'key':'RulesInvoiceReviews'
                        },
                        {
                            'labelDescription': 'Delinquency',
                            'labelPath': '/rules/delinquency/delinquency-cycle',
                            'labelIcon': 'icon-delinquency-exception',
                            'labelClass': 'individuals',
                            'key':'ViewDelinquencyRulesTab'
                        }
                    ],
                    'key':'RulesHeader'
                },

                {
                    "mainMenu": "Reports",
                    "href": "#/reports/revenue",
                    "leftNav": [
                        {
                            'labelDescription': 'Financials',
                            'labelPath': '/reports/revenue',
                            'labelIcon': 'icon-reports-revenue',
                            'labelClass': 'individuals',
                            'key':'RevenueReports'
                        }
						,
						 {
                            'labelDescription': 'Accounts',
                            'labelPath': '/reports/account',
                            'labelIcon': 'icon-reports-accounts',
                            'labelClass': 'individuals',
                            'key':'AccountsReports'
                        },
                        /*{
                            'labelDescription': 'Contracts',
                            'labelPath': '/reports/contract',
                            'labelIcon': 'icon-reports-entities',
                            'labelClass': 'individuals'
                        },
                        */
                        {
                            'labelDescription': 'Invoices',
                            'labelPath': '/reports/invoices',
                            'labelIcon': 'icon-reports-invoices',
                            'labelClass': 'individuals',
                            'key':'InvoicesReports'
                        },
                        {
                            'labelDescription': 'Inbound Payments',
                            'labelPath': '/reports/payment-summary',
                            'labelIcon': 'icon-reports-payments',
                            'labelClass': 'individuals',
                            'key':'PaymentsReports'
                        },
                        {
                            'labelDescription': 'Remits',
                            'labelPath': '/reports/report-remittance-details',
                            'labelIcon': 'icon-reports-remittance',
                            'labelClass': 'individuals',
                            'key':'RemitsReports'
                        },
						
                        {
                            'labelDescription': 'Reinstatement',
                            'labelPath': '/reports/report-reinstatement',
                            'labelIcon': 'icon-reinstatement',
                            'labelClass': 'individuals',
                            'key':'ViewReinstatementReportsTab'
                        },
                        {
                            'labelDescription': 'Delinquency',
                            'labelPath': '/reports/delinquency-status-report',
                            'labelIcon': 'icon-operator-trans',
                            'labelClass': 'individuals',
                            'key':'ViewDelinquencyReportsTab'
                        },
                        {
                            'labelDescription': 'ACA',
                            'labelPath': '/reports/broker-book-of-business',
                            'labelIcon': 'icon-reports-revenue',
                            'labelClass': 'individuals',
                            'key':'ACAReports'
                        }
                    ],
                    'key':'ReportsHeader'
                },

                {
                    "mainMenu": "Others",
                    "href": "#/system/eligibility/group",
                    "leftNav": [
{
    'labelDescription': 'Eligibility',
    'labelPath': '/system/eligibility/group',
    'labelIcon': 'icon-individuals',
    'labelClass': 'individuals',
    'key':'SystemEligibility'
},
                        {
                            'labelDescription': 'Bill Cycles',
                            'labelPath': '/system/bill-cycle',
                            'labelIcon': 'icon-delinquency-cycle',
                            'labelClass': 'individuals',
                            'key':'SystemBillCycle'
                        },
						{
                        	'labelDescription': 'On Hold',
                            'labelPath': '/system/on-hold/eligibility',
                            'labelIcon': 'icon-hold-rejections',
                            'labelClass': 'individuals',
                            'key':'SystemOnHold'
                            	
                        	
                        },
                        {
                        	'labelDescription': 'Rejected Payment',
                            'labelPath': '/system/rejected/rejectedlockboxpayment',
                            'labelIcon': 'icon-rejected-payment',
                            'labelClass': 'individuals',
                            'key':'RejectedLockBox'
                            	
                        	
                        }
                        
                        
                        /*,
						{
                        	'labelDescription': 'Audit',
                            'labelPath': '/system/audit/audit-log',
                            'labelIcon': 'icon-audit-log',
                            'labelClass': 'individuals',
                            'key':'AuditLog'
                            	
                        	
                        }*/
                        
                        
                        
                        /*,
                        {
                            'labelDescription': 'Users',
                            'labelPath': '/system/manage-users',
                            'labelIcon': 'icon-user-groups',
                            'labelClass': 'individuals'
                        },
                        {
                            'labelDescription': 'User Roles',
                            'labelPath': '/system/manage-permissions',
                            'labelIcon': 'icon-user-groups',
                            'labelClass': 'individuals'
                        },
                        {
                            'labelDescription': 'Messages',
                            'labelPath': '/system/messaging',
                            'labelIcon': 'icon-operator-messaging',
                            'labelClass': 'individuals'
                        },
                        {
                            'labelDescription': 'Processing',
                            'labelPath': '/system/processing',
                            'labelIcon': 'icon-operator-job-queue',
                            'labelClass': 'individuals'
                        },
                        {
                            'labelDescription': 'API Diagnostics',
                            'labelPath': '/system/api-diagnostic',
                            'labelIcon': 'icon-configuration',
                            'labelClass': 'individuals'
                        }*/
                    ],
                    'key':'SystemHeader'
                }
            ]
        },
        "dateFormat": {
            "format": "MM/dd/yyyy"
        },
        "currencyFormat": {
            "format": "$"
        },
        "numberRoundOffFormat": {
            "format": 4
        },
        "dateTimeFormat": {
            "format": "'yyyy-MM-dd HH:mm:ss Z"
        },
        "ddMonthyyyydateFormat": {
            "format": "'dd MMM,yyyy"
        },
        "beTimeFormat": {
            "format": "yyyy-MM-dd"
        }

    }
];