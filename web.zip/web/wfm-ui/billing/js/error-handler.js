/**
 * Created by Dikshit.Vaid on 6/7/2014.
 */
(function () {
    'use strict';
    var errorHandlerModule = angular.module('wfm-http-error-handling', []);
    var elementsList = [];

    // this message will appear for a defined amount of time and then vanish again
    var showMessage = function (content, cl, time) {
        time = 60000;
        $('<div>')
            .addClass(cl)
            .hide()
            .fadeIn('fast')
            .delay(time)
            .fadeOut('fast', function () {
                $(this).remove();
            })
            .appendTo(elementsList)
            .text(content);
    };
    errorHandlerModule.factory('httpErrorInterceptor', ['$q', '$location','$injector', function ($q, $location,$injector) {
        var httpErrorInterceptor = {
            request: function (config) {
                return config || $q.when(config);
            },
            response: function (response) {
                return response || $q.when(response);
            },
            requestError: function (request) {
                console.log("error sending request: ");
                return $q.reject(request);
            },
            responseError: function (rejection) {
                switch (rejection.status) {
                    case 400: // if the status is 400 we return the error
                        showMessage(rejection.data.message, 'wfm-http-error-message');
                        break;
                    case 401: // if the status is 401 we return access denied
						window.location.reload(true);
                        //window.location.href = "https://"+window.location.hostname+ "/security/default/oAuth2/initiate?client_id="+hcentive.WFM.client_id+"&response_type=token&errorCode=504#/login/login";
                        break;
                    case 403: // if the status is 403 we tell the user that authorization was denied
						showMessage('You have insufficient privileges to do what you want to do!',
                            'wfm-http-error-message')
						window.location.reload(true);
                        break;
                    case 405: // if the status is 405 we tell the user that method is not allowed
                        showMessage('Method not allowed',
                            'wfm-http-error-message');
                        break;
                    case 500: // if the status is 500 we return an internal server error message
                        showMessage('Internal server error: ' + rejection.data.message,
                            'wfm-http-error-message');
                        break;
                    case 504:{
                    	var NotifySrvc = $injector.get('NotifySrvc');
						NotifySrvc({
						    id: 'simpleDialog',
						    template: '<div class="row-fluid">' + ' <p>' + 'Session Timed Out, Please Login again.'
						        + '</p>' + '</div>',
						    title: 'Session Timed Out.',
						    backdrop: true,
						    closeButton : false,
						    backdropCancel: false,
						    success: {
						        label: 'Ok',
						        fn: function () {
						    		window.location.reload();
						        }
						    }
						});
                        break;
					}
                    default:
                        showMessage('Error ' + rejection.status + ': ' + rejection.data.message,
                            'wfm-http-error-message');
                }
                return $q.reject(rejection);
            }
        };
      //  $location.path("/home/error");
        return httpErrorInterceptor;
    }]);

    errorHandlerModule.config(['$httpProvider', '$compileProvider', function ($httpProvider, $compileProvider) {
        // push function to the interceptors which will intercept
        // the http responses of the whole application
        $httpProvider.interceptors.push('httpErrorInterceptor');
        // this will display the message if there was a http return status
        $compileProvider.directive('httpErrorMessages', function () {
            return {
                link: function (scope, element, attrs) {
                    elementsList.push(element[0]);
                }
            };
        });
    }]);
})();