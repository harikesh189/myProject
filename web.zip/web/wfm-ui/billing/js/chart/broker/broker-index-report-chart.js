$(function () {

    $('#pieChart').on('click', function () {
        drawFirstLevel('brokerReport');
        $('#premiumBy').text('Distribution by Client Type');
        $('.premiumTimeFrame').text('From 01-01-2013 to 11-14-2013');
        $(this).addClass('active');
        $('#barChart').removeClass('active');
    });
    $('#barChart').on('click', function () {
        /*rmhpDrawBarReport('rmhpPremiumByProductsReport',rmhpPremiumByProductsBarCatagories,rmhpPremiumByProductsBarData,10000);*/
        drawFirstLevelBar('brokerReport');
        $('#premiumBy').text('Distribution by Client Type');
        $('.premiumTimeFrame').text('From 01-01-2013 to 11-14-2013');
        $('#pieChart').removeClass('active');
        $(this).addClass('active');
    });
    /*$('#back').on('click', function(){
     $(this).hide();
     });*/
    $('table tr td a.nextData').hover(function () {
        $(this).parents("tr").find($('.nextDataText')).show();
    }, function () {
        $(this).parents("tr").find($('.nextDataText')).hide();
    });


    $(".showItemsDate").click(function () {
        $(this).find(".dropItems").toggle();
    });
});