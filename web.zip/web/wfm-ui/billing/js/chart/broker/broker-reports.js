var chart, chart1, chart2, chart3;
$(document).ready(function () {
    drawFirstLevel();
    $('#back').click(function () {
        chart1.destroy();
        drawFirstLevel();
    });

});


function drawFirstLevel(name) {

    // Build the chart
    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'brokerReport',
            height: 235,
            width: 700
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                center: [300, 90],
                shadow: false,
                innerSize: '50%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                },

                cursor: 'pointer',

                point: {
                    events: {
                        click: function () {
                            drawSecondLevel(this.name);
                            changeTitle();

                        }
                    }
                }
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 200,
            borderWidth: 0,
            symbolWidth: 15,
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 15,
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '200px'
            }

        },

        series: [
            {
                type: 'pie',
                name: ' ',
                data: [
                    {name: 'Individual', y: 75, color: colors[0]},
                    {name: 'Group', y: 25, color: colors[2]}
                ]
            }
        ]
    });
}
function drawFirstLevelBar(name) {

    // Build the chart
    chart3 = new Highcharts.Chart({
        chart: {
            renderTo: 'brokerReport',
            type: 'column',
            width: 823,
            hieght: 50
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + this.y;
            }
        },
        plotOptions: {
            column: {
                dataLabels: {
                    enabled: false,
                    connectorColor: '#000000',
                    formatter: function () {
                        return this.point.y;
                    }
                }
            },
            series: {
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            drawSecondLevel(this.name);
                            changeTitle();
                        }
                    }
                }
            }

        },
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false,
            layout: 'vertical',
            align: 'right',
            width: 200,
            borderWidth: 0,
            symbolWidth: 15,
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 15
        },
        xAxis: {
            categories: ['Individual ', 'Group', '', ' ', ' ', ' ', ' '],
            min: 0
        },
        yAxis: {
            tickInterval: 250,
            labels: {
                style: {
                    fontWeight: 'bold'
                },
                format: '{value}'
            }
        },
        scrollbar: {
            enabled: true,
            height: 20
        },

        series: [
            {
                name: ' ',

                data: [
                    {
                        y: 750,
                        color: colors[0]

                    },
                    {
                        y: 250,
                        color: colors[1]

                    },
                    {
                        y: 0,
                        color: colors[2]

                    },
                    {
                        y: 0,
                        color: colors[3]

                    },
                    {
                        y: ' ',
                        color: colors[3]

                    },
                    {
                        y: ' ',
                        color: colors[3]

                    },
                    ,
                    {
                        y: ' ',
                        color: colors[3]

                    },
                    {
                        y: ' ',
                        color: colors[3]

                    }
                ],
            }
        ]
    });
}
function drawSecondLevel(name) {
    chart.destroy();

    chart1 = new Highcharts.Chart({
        chart: {
            renderTo: 'brokerReport',
            type: 'column',
            width: 823,
            hieght: 50
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + this.y;
            }
        },
        plotOptions: {
            column: {
                dataLabels: {
                    enabled: false,
                    color: '#000000',
                    connectorColor: '#000000',
                    formatter: function () {
                        return this.point.y;
                    }


                },

            },
            series: {
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            drawThirdLevel(this.name);
                            changeTitle1();
                        }
                    }
                }
            }
        },
        exporting: {
            enabled: false

        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 200,
            borderWidth: 0,
            symbolWidth: 15,
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 15
        },
        xAxis: {
            categories: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            min: 0
        },
        yAxis: {
            tickInterval: 100,
            labels: {
                style: {
                    fontWeight: 'bold'
                },
                format: '{value}'
            }
        },
        scrollbar: {
            enabled: true,
            height: 20
        },

        series: [
            {
                name: 'Individual',
                data: [100.00, 125.00, 175.00, 200.00, 250.00, 275.00, 300.00, 350.00, 450.00, 550.00, 650.00, 750.00]
            },
            {
                name: 'Group',
                data: [45.00, 75.00, 100.00, 105.00, 125.00, 150.00, 170.00, 180.00, 200.00, 215.00, 235.00, 250.00]
            }
        ],
        legend: {
            enabled: true
        }
    });


}

function drawThirdLevel(name) {
    chart1.destroy();

    chart2 = new Highcharts.Chart({
        chart: {
            renderTo: 'brokerReport',
            type: 'column',
            width: 823,
            hieght: 50
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + this.y;
            }
        },
        plotOptions: {
            column: {
                dataLabels: {
                    enabled: false,
                    color: '#000000',
                    connectorColor: '#000000',
                    formatter: function () {
                        return this.point.y;
                    }

                },

            }
        },
        exporting: {
            enabled: false
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 200,
            borderWidth: 0,
            symbolWidth: 15,
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 15
        },
        xAxis: {
            categories: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            min: 0
        },
        yAxis: {
            tickInterval: 100,
            labels: {
                style: {
                    fontWeight: 'bold'
                },
                format: '{value}'
            }
        },
        scrollbar: {
            enabled: true,
            height: 20
        },

        series: [
            {
                name: ' ',
                data: [100.00, 125.00, 175.00, 200.00, 250.00, 275.00, 300.00, 350.00, 450.00, 550.00, 650.00, 750.00]
            }
        ],
        legend: {
            enabled: false
        }
    });


}

function changeTitle() {
    $('#premiumBy').text('Distribution by Client Type');
    $('.premiumTimeFrame').text(' ');
    $("#timeFrame1").val('1');
    /*$('#back').show();*/

};
function changeTitle1() {
    $('#premiumBy').text('Distribution by Client Type');
    $('.premiumTimeFrame').text(' ');
    $("#timeFrame1").val('1');
    //$('#back').show();
};