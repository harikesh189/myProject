function drawComparativeBar(divId, categories, data, tickIntervalValue) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'column',
            hight: 50
        },
        xAxis: {
            categories: categories,
            labels: {
                style: {
                    fontWeight: 'bold'
                }
            }
        },
        yAxis: {
            labels: {
                formatter: function () {
                    return '$' + this.value;
                },
                style: {
                    fontWeight: 'bold'
                }
            },
            tickInterval: tickIntervalValue,
            lineWidth: 1,
            plotLines: [
                {
                    value: 0,
                    width: 1,
                    color: '#808080'
                }
            ]
        },
        exporting: {
            enabled: false
        },
        series: data
    });
}

function drawPieReport(divId, data) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 265,
            width: 380

        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 180,
            borderWidth: 0,
            symbolWidth: 10,
            verticalAlign: 'middle',
            useHTML: true,
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + this.y + '%' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '170px'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                shadow: false,
                innerSize: '60%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                }
            }
        },
        series: [
            {
                type: 'pie',
                name: ' ',
                data: data
            }
        ]
    });
}

function drawBarReport(divId, catagories, data, tickIntervalValue) {

    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: 380,
            hieght: 50

        },
        xAxis: {
            categories: catagories,
            labels: {
                style: {
                    fontWeight: 'bold'
                }
            }

        },
        yAxis: {
            min: 0,
            lineWidth: 1,
            tickInterval: tickIntervalValue,
            labels: {
                style: {
                    fontWeight: 'bold'
                },
                format: '${value}'
            }
        },
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false,
        },
        series: [
            {
                name: ' ',
                data: data,
                color: 'black',
                dataLabels: {
                    enabled: true,
                    color: colors[0],
                    style: {
                        fontWeight: 'bold'
                    },
                    formatter: function () {
                        return this.y;
                    }
                }
            }
        ]
    });
}

function drawLineReport(divId, catagories, data, tickIntervalValue) {

    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'line',
            width: 380
        },
        xAxis: {
            categories: catagories,
            labels: {
                style: {
                    fontWeight: 'bold'
                }
            }
        },
        yAxis: {
            min: 0,
            lineWidth: 1,
            tickInterval: tickIntervalValue,
            labels: {
                style: {
                    fontWeight: 'bold'
                }
            }
        },
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        series: [
            {
                name: '',
                data: data,
                dataLabels: {
                    enabled: true,
                    color: colors[0],
                    style: {
                        fontWeight: 'bold'
                    },
                    formatter: function () {
                        return this.y;
                    }
                }
            }
        ]
    });
}

function drawComarativeLineReport(divId, catagories, data, tickIntervalValue) {

    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'line',
            width: 380
        },
        xAxis: {
            categories: catagories,
            labels: {
                style: {
                    fontWeight: 'bold'
                }
            }
        },
        yAxis: {
            min: 0,
            lineWidth: 1,
            tickInterval: tickIntervalValue,
            labels: {
                formatter: function () {
                    return '$' + this.value;
                },
                style: {
                    fontWeight: 'bold'
                }
            }
        },
        exporting: {
            enabled: false
        },
        legend: {
            enabled: true
        },
        series: data
    });
}
 
 
 