// RMHP Reports


function rmhpDrawPieReport(divId, data, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 235,
            width: chartWidth

        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 200,
            borderWidth: 0,
            symbolWidth: 15,
            symbolStyle: 'circle',
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 15,
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '16px',
                lineHeight: '18px',
                width: '200px'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                shadow: false,
                innerSize: '40%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                },
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            rmhpDrawBar();
                        }
                    }
                }
            }
        },
        series: [
            {
                type: 'pie',
                name: ' ',
                data: data
            }
        ]
    });
}

function rmhpDrawBarReport(divId, catagories, data, tickIntervalValue, chartWidth) {

    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth

        }, tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + '$' + this.y;
            }
        },
        xAxis: {
            categories: catagories,
            labels: {
                style: {
                    fontWeight: 'bold'
                }
            }

        },
        yAxis: {
            min: 0,
            lineWidth: 1,
            tickInterval: tickIntervalValue,
            labels: {
                style: {
                    fontWeight: 'bold'
                },
                format: '${value}'
            }
        },
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        series: [
            {
                name: ' ',
                data: data,
                color: 'black',
                dataLabels: {
                    enabled: false,
                    color: colors[0],
                    style: {
                        fontWeight: 'bold'
                    },
                    formatter: function () {
                        return this.y;
                    }
                }
            }
        ],
        plotOptions: {
            series: {
                cursor: 'pointer',
                events: {
                    click: function (event) {
                        drawSecondLevel();
                        changeTitle();
                    }
                }
            }
        },
    });
}


function changeTitle() {
    $('#premiumBy').text('Monthly Premium for Medical Plans');
    $('.premiumTimeFrame').text(' ');
    $("#timeFrame1").val('1');
    /*$('#back').show();*/

};
function changeTitle1() {
    $('#premiumBy').text('HMO Silver Premium');
    $('.premiumTimeFrame').text(' ');
    $("#timeFrame1").val('1');
    //$('#back').show();
};


function showMultipleReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    var obj = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        series: data,
        plotOptions: {
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });

}


// Drill Downs

function drawPieReportWithDrillDown(divId, data, chartWidth) {
    $('#' + divId).empty();
    var chart = $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 235,
            width: chartWidth

        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 250,
            borderWidth: 0,
            symbolWidth: 15,
            symbolStyle: 'circle',
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 5,
            /*borderWidth: 0,
             itemMarginBottom: 5,*/
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '250'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                shadow: false,
                innerSize: '40%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                },
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            var drilldown = this.drilldown;
                            var newName;
                            var newData;

                            if (drilldown) { // drill down
                                newName = drilldown.name;
                                newData = drilldown.data;
                                var titleName = drilldown.name;
                                $('#premiumBy').text(titleName);
                                firstStepGraph();
                            } else { // restore
                                newName = name;
                                newData = data;
                                $('#premiumBy').text('By Products');
                                secondStepGraph();
                            }

                            chart.series[0].remove(false);
                            chart.addSeries({
                                name: newName,
                                data: newData
                            }, false);
                            chart.redraw();

                        }
                    }
                }
            }
        },
        series: [
            {
                type: 'pie',
                name: ' ',
                data: data
            }
        ]
    }).highcharts();
}

function setChart(chart, name, categories, data, color) {
    chart.xAxis[0].setCategories(categories, false);
    chart.series[0].remove(false);
    chart.addSeries({
        name: name,
        data: data,
        color: color || 'white'
    }, false);
    chart.redraw();
}
var chart;
function showSingleReportWithDrillDown(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    chart = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            column: {
                colorByPoint: true,
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            var drilldown = this.drilldown;
                            if (drilldown) { // drill down
                                setChart(chart, drilldown.name, drilldown.categories, drilldown.data);
                                var titleName = drilldown.name;
                                $('#premiumBy').text(titleName);
                                firstStepGraph();
                            } else { // restore
                                setChart(chart, name, xAxisData, data);
                                $('#premiumBy').text('By Products');
                                secondStepGraph();
                            }
                        }
                    }
                },
                dataLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold'
                    },
                    formatter: function () {
                        return this.y;
                    }
                }
            }
        },
        series: [
            {
                name: ' ',
                data: data
            }
        ]
    }).highcharts();
}


function showMultipleReportIndividual(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    var obj = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        series: data,
        plotOptions: {
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });

}


// Drill Downs

function drawPieReportWithDrillDownIndividual(divId, data, chartWidth) {
    $('#' + divId).empty();
    var chart = $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 235,
            width: chartWidth

        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 250,
            borderWidth: 0,
            symbolWidth: 15,
            symbolStyle: 'circle',
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 5,
            /*borderWidth: 0,
             itemMarginBottom: 5,*/
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '250'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                shadow: false,
                innerSize: '40%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                },
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            var drilldown = this.drilldown;
                            var newName;
                            var newData;

                            if (drilldown) { // drill down
                                newName = drilldown.name;
                                newData = drilldown.data;
                                var titleName = drilldown.name;
                                $('#premiumBy').text(titleName);
                                firstStepGraph();

                            } else { // restore
                                newName = name;
                                newData = data;
                                $('#premiumBy').text('By Products');
                                secondStepGraph();
                            }

                            chart.series[0].remove(false);
                            chart.addSeries({
                                name: newName,
                                data: newData
                            }, false);
                            chart.redraw();

                        }
                    }
                }
            }
        },
        series: [
            {
                type: 'pie',
                name: ' ',
                data: data
            }
        ]
    }).highcharts();
}


function showSingleReportWithDrillDownIndividual(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    var obj = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        series: data,
        plotOptions: {
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });

}

function firstStepGraph() {
    $('#tabularData').removeClass('firstStep');
    $('#exportCsv').attr('href', 'docs/premium-by-medical-plans.csv');
    $('#exportXls').attr('href', 'docs/premium-by-medical-plans.xls');
    if ($('#pieChart').hasClass("active")) {
        $('#exportPdf').attr('href', 'docs/premium-by-medical-plans-pie.pdf');
    } else if ($('#barChart').hasClass("active")) {
        $('#exportPdf').attr('href', 'docs/premium-by-medical-plans-bar.pdf');
    } else if ($('#tabularData').hasClass("active")) {
        $('#exportPdf').attr('href', 'docs/premium-by-medical-plans.pdf');
    }
}
function secondStepGraph() {
    $('#tabularData').addClass('firstStep');
    $('#exportCsv').attr('href', 'docs/premium-by-medical-plans.csv');
    $('#exportXls').attr('href', 'docs/premium-by-medical-plans.xls');
    if ($('#pieChart').hasClass("active")) {
        $('#exportPdf').attr('href', 'docs/premium-by-medical-plans-pie.pdf');
    } else if ($('#barChart').hasClass("active")) {
        $('#exportPdf').attr('href', 'docs/premium-by-medical-plans-bar.pdf');
    } else if ($('#tabularData').hasClass("active")) {
        $('#exportPdf').attr('href', 'docs/premium-by-medical-plans.pdf');
    }
}