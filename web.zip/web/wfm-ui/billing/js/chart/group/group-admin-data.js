Highcharts.setOptions({
    colors: ['#6b9851', '#af6968', '#dfb65b', '#88829E', '#87BCD9', '#6AF9C4', '#FF9655', '#24CBE5', '#FFD39B']
});

var colors = Highcharts.getOptions().colors;

var individualHomeReportData = [
    {
        name: 'MEDICAL',
        data: [65, 75, 69, 71, 55.0, 62.0, 58.6]

    },
    {
        name: 'DENTAL',
        data: [13, 11, 18, 16, 7, 10, 9]

    },
    {
        name: 'VISION',
        data: [28, 21, 48, 22, 23, 15, 19]

    },
    {
        name: 'PHARMACY',
        data: [6, 4, 11, 15, 8, 3, 4]

    }
];

var individualHomeReportDataCatagories = [
    "Nov'12",
    "Dec'12",
    "Jan'13",
    "Feb'13",
    "Mar'13",
    "Apr'13",
    "May'13"
];

var planCostPieData = [
    ['UHG CH+', 1300],
    ['Aetna Exl', 750],
    ['DD Exl', 350],
    ['Met Flexi', 600]
];

var planSubscriptionPieData = [
    ['Blue Cross of Idaho Bronze Plan', 50],
    ['BrightIdea Bronze Plan', 50]
    //['Bridge Span Exchange Bronze HAS',    22]
];


var planSubscriptionBarData = [
    {
        y: 50,
        color: colors[0]

    },
    {
        y: 17,
        color: colors[1]

    },
    {
        y: 20,
        color: colors[2]

    },
    {
        y: 13,
        color: colors[3]

    }
];
var planCostBarData = [
    {
        y: 250.00,
        color: colors[0]

    },
    {
        y: 93.75,
        color: colors[0]

    },
    {
        y: '',
        color: colors[0]

    },
    {
        y: '',
        color: colors[0]

    }
];

var planCostBarDataCatagories = ['Blue Cross of Idaho Bronze Plan', 'BrightIdea Bronze Plan', '', ''];

// Premiums Due
var premiumDueBarData = [
    {
        y: 343,
        color: colors[2]

    },
    {
        y: '',
        color: colors['']
    },
    {
        y: '',
        color: colors['']
    },
    {
        y: '',
        color: colors['']
    }
];
var premiumDueBarDataCatagories = ["Jan'15", "Feb'15", "Mar'15", "Apr'15"];


var planSubscriptionBarDataCatagories = ['UHG CH+', 'Aetna Exl', 'DD Exl', 'Met Flexi'];

var costShareReportDataCatagories = [
    "UHG CH+",
    "Aetna Exl",
    "DD Exl",
    "Met Flexi"
];

var costShareReportData = [
    {
        name: 'EMPLOYER',
        color: colors[0],
        data: [950, 400, 350, 650]

    },
    {
        name: 'Employee',
        color: colors[2],
        data: [800, 400, 250, 175]

    }
];

var comparativeStudyReportDataCatagories = [
    "Medical",
    "Dental",
    "Vision"
];

var comparativeStudyReportData = [
    {
        name: 'UHC',
        color: colors[0],
        data: [95, 62, 43]

    },
    {
        name: 'Aetna',
        color: colors[2],
        data: [63, 44, 36]

    },
    {
        name: 'Humana',
        color: colors[1],
        data: [59, 56, 22]

    }
];

// RMHP Reports

var rmhpPremiumByProductsPieData = [
    ['Medical', 68],
    ['Dental', 14],
    ['Vision', 11],
    ['Pharmacy', 07]
    //['Bridge Span Exchange Bronze HAS',    22]
];
var rmhpPremiumByProductsBarData = [
    {
        y: 50000,
        color: colors[0]

    },
    {
        y: 10000,
        color: colors[1]

    },
    {
        y: 8000,
        color: colors[2]

    },
    {
        y: 5000,
        color: colors[3]

    },
    {
        y: ' ',
        color: colors[3]

    },
    {
        y: ' ',
        color: colors[3]

    },
    ,
    {
        y: ' ',
        color: colors[3]

    },
    {
        y: ' ',
        color: colors[3]

    }
];

var rmhpPremiumByProductsBarCatagories = ['Medical', 'Dental', 'Vision', 'Pharmacy', ' ', ' ', ' ', ' '];


// Data for drilldown charts start here

// Bar Data
var groupPremiumByPlanTypeReportXAxis = [ "Medical", "Dental", "Vision", "Pharmacy", ' ', ' ', ' '];

var groupPremiumByPlanTypeReportYAxis = {
    min: 0,
    lineWidth: 1,
    tickInterval: 10000,
    lineColor: 'black',
    title: {
        text: ''
    },
    labels: {
        formatter: function () {
            return '$' + ' ' + this.value;
        }
    }
};

var groupPremiumByPlanTypeReportData = [
    {
        y: 50000.00,
        drilldown: {
            name: 'By Medical Plans',
            categories: ['HMO Silver', 'Bronze HAS', 'PPO Silver', 'PPO Gold', ' ', ' ', ' '],

            data: [
                {
                    y: 10000.00
                },
                {
                    y: 10000.00
                },
                {
                    y: 15000.00
                },
                {
                    y: 15000.00
                },
                {
                    y: ' '
                },
                {
                    y: ' '
                },
                {
                    y: ' '
                }
            ]
        }
    },
    {
        y: 10000.00
    },
    {
        y: 8000.00
    },
    {
        y: 5000.00
    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    }

];


// Pie Dada

var groupPremiumByPlanTypeReportPieData = [
    {
        y: 68,
        name: 'Medical',
        drilldown: {
            name: 'By Medical Plans',
            data: [
                {
                    name: 'HMO Silver',
                    y: 20
                },
                {
                    name: 'Bronze HAS',
                    y: 20
                },
                {
                    name: 'PPO Silver',
                    y: 30
                },
                {
                    name: 'PPO Gold',
                    y: 30
                }
            ]
        },

    },
    {
        y: 14,
        name: 'Dental'
    },
    {
        y: 11,
        name: 'Vision'
    },
    {
        y: 7,
        name: 'Pharmacy'
    }
];


// end data for drill down


var groupPremiumByPlanTypeMonthlyReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var groupPremiumByPlanTypeMonthlyReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + this.value;
        }
    }
};

var groupPremiumByPlanTypeMonthlyReportData = [
    {
        name: 'HMO Silver',
        data: [4000.00, 5000.00, 3000.00, 6000.00, 5000.00, 4000.00, 5000.00, 3000.00, 4000.00, 7000.00, 6000.00, 2000.00]
    },
    {
        name: 'Bronze HAS',
        data: [900.00, 1200.00, 1000.00, 800.00, 900.00, 800.00, 1000.00, 1300.00, 900.00, 1200.00, 1000.00, 800.00]
    },
    {
        name: 'PPO Silver',
        data: [600.00, 700.00, 800.00, 900.00, 600.00, 700.00, 800.00, 600.00, 700.00, 800.00, 900.00, 600.00]
    },
    {
        name: 'PPO Gold',
        data: [400.00, 500.00, 600.00, 400.00, 500.00, 600.00, 400.00, 400.00, 500.00, 600.00, 400.00, 500.00]
    }
];


// Individual Portal Graph Data
var individualPremiumByPlanTypeReportXAxis = [ "Nov'12", "Dec'12", "Jan'13", "Feb'13", "Mar'13", "Apr'13", "May'13"];

var individualPremiumByPlanTypeReportYAxis = {
    min: 0,
    tickInterval: 10,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var individualPremiumByPlanTypeReportData = [
    {
        name: 'Medical',
        data: [30, 20, 10, 30, 60, 40, 30]
    },
    {
        name: 'Dental',
        data: [30, 10, 30, 60, 40, 30, 35]
    },
    {
        name: 'Vision',
        data: [50, 60, 70, 80, 50, 70, 50]
    },
    {
        name: 'Pharmacy',
        data: [50, 60, 70, 80, 50, 90, 50]
    }
];


// Pie Dada

var individualPremiumByPlanTypeReportPieData = [
    {
        y: 68,
        name: 'Medical',
        drilldown: {
            name: 'By Medical Plans',
            data: [
                {
                    name: 'HMO Silver',
                    y: 20
                },
                {
                    name: 'Bronze HAS',
                    y: 20
                },
                {
                    name: 'PPO Silver',
                    y: 30
                },
                {
                    name: 'PPO Gold',
                    y: 30
                }
            ]
        },

    },
    {
        y: 14,
        name: 'Dental'
    },
    {
        y: 11,
        name: 'Vision'
    },
    {
        y: 7,
        name: 'Pharmacy'
    }
];


// end data for drill down


var individualPremiumByPlanTypeMonthlyReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var individualPremiumByPlanTypeMonthlyReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + this.value;
        }
    }
};

var individualPremiumByPlanTypeMonthlyReportData = [
    {
        name: 'HMO Silver',
        data: [4000.00, 5000.00, 3000.00, 6000.00, 5000.00, 4000.00, 5000.00, 3000.00, 4000.00, 7000.00, 6000.00, 2000.00]
    },
    {
        name: 'Bronze HAS',
        data: [900.00, 1200.00, 1000.00, 800.00, 900.00, 800.00, 1000.00, 1300.00, 900.00, 1200.00, 1000.00, 800.00]
    },
    {
        name: 'PPO Silver',
        data: [600.00, 700.00, 800.00, 900.00, 600.00, 700.00, 800.00, 600.00, 700.00, 800.00, 900.00, 600.00]
    },
    {
        name: 'PPO Gold',
        data: [400.00, 500.00, 600.00, 400.00, 500.00, 600.00, 400.00, 400.00, 500.00, 600.00, 400.00, 500.00]
    }
];