Highcharts.setOptions({
    colors: ['#6b9851', '#af6968', '#dfb65b', '#746b96', '#6dadd0', '#6AF9C4', '#FF9655', '#24CBE5', '#FFD39B']
});

function showMultipleReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    var obj = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        series: data,
        plotOptions: {
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });

}


function showSingleReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        series: data,
        plotOptions: {
            column: {colorByPoint: true},
            series: {
                name: ' ',
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            if (typeof(this.options) != 'undefined' && typeof(this.options.url) != 'undefined'
                                && this.options.url != '') {
                                location.href = this.options.url;
                            }
                        }
                    }
                },
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });
}

function setChart(chart, name, categories, data, color) {
    chart.xAxis[0].setCategories(categories, false);
    chart.series[0].remove(false);
    chart.addSeries({
        name: name,
        data: data,
        color: color || 'white'
    }, false);
    chart.redraw();
}
var chart;
function showSingleReportWithDrillDown(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    chart = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            column: {
                colorByPoint: true,
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            var drilldown = this.drilldown;
                            if (drilldown) { // drill down
                                setChart(chart, drilldown.name, drilldown.categories, drilldown.data);
                                var titleName = drilldown.name;
                                $('#premiumBy').text(titleName);
                            } else { // restore
                                setChart(chart, name, xAxisData, data);
                                $('#premiumBy').text('Products');
                            }
                        }
                    }
                },
                dataLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold'
                    },
                    formatter: function () {
                        return this.y;
                    }
                }
            }
        },
        series: [
            {
                name: ' ',
                data: data
            }
        ]
    }).highcharts();
}

function showLineReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        legend: {
            enabled: true
        },
        series: data,
        plotOptions: {
            column: {colorByPoint: true},
            series: {
                name: ' ',
                marker: {
                    fillColor: '#FFFFFF',
                    lineWidth: 2,
                    lineColor: null
                }
            }
        }
    });
}

function drawPieReport(divId, data, legendWidth, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 235,
            width: chartWidth

        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 250,
            borderWidth: 0,
            symbolWidth: 15,
            symbolStyle: 'circle',
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 15,
            /*borderWidth: 0,
             itemMarginBottom: 5,*/
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '250'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {

            pie: {
                shadow: false,
                innerSize: '40%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            if (typeof(this.options) != 'undefined' && typeof(this.options.url) != 'undefined'
                                && this.options.url != '') {
                                location.href = this.options.url;
                            }
                        }
                    }
                },
                dataLabels: {
                    enabled: false

                }

            }
        },
        series: [
            {
                data: data
            }
        ]
    });
}

function drawPieReportWithDrillDown(divId, data, chartWidth) {
    $('#' + divId).empty();
    var chart = $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 235,
            width: chartWidth

        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 250,
            borderWidth: 0,
            symbolWidth: 15,
            symbolStyle: 'circle',
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 5,
            /*borderWidth: 0,
             itemMarginBottom: 5,*/
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '250'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                shadow: false,
                innerSize: '40%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                },
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            var drilldown = this.drilldown;
                            var newName;
                            var newData;

                            if (drilldown) { // drill down
                                newName = drilldown.name;
                                newData = drilldown.data;
                                var titleName = drilldown.name;
                                $('#premiumBy').text(titleName);

                            } else { // restore
                                newName = name;
                                newData = data;
                                $('#premiumBy').text('Products');
                            }

                            chart.series[0].remove(false);
                            chart.addSeries({
                                name: newName,
                                data: newData
                            }, false);
                            chart.redraw();

                        }
                    }
                }
            }
        },
        series: [
            {
                type: 'pie',
                name: ' ',
                data: data
            }
        ]
    }).highcharts();
}


