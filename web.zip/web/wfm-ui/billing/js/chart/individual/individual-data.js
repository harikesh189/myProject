/* ============================ MESSA Reports Data =========================== */

// Data for drilldown charts start here

// Bar Data
var messaPremiumByProductAmountReportXAxis = [ "MED", "RX", "DEN", "VIS", "ADD", "LIFE", "LTD", "STD", "BTL", "STL"];

var messaPremiumByProductAmountReportYAxis = {
    min: 0,
    lineWidth: 1,
    tickInterval: 100,
    lineColor: 'black',
    title: {
        text: ''
    },
    labels: {
        formatter: function () {
            return '$' + ' ' + this.value;
        }
    }
};

var messaPremiumByProductAmountReportData = [
    {
        y: 900.00,
        drilldown: {
            name: 'MED plan',
            categories: ['ABC Plan 1', 'Choices Copay', 'Super Care 1', ' ', ' ', ' '],

            data: [
                {
                    y: 170,
                    drilldown: {
                        name: 'ABC Plan 1 by Coverage Type',
                        categories: ['Self Only', 'Two Pary', 'Family', ' ', ' ', ' '],

                        data: [
                            {
                                y: 0
                            },
                            {
                                y: 40
                            },
                            {
                                y: 30
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            }
                        ]
                    }
                },
                {
                    y: 280,
                    drilldown: {
                        name: 'Choices Copay by Coverage Type',
                        categories: ['Self Only', 'Two Pary', 'Family', ' ', ' ', ' '],

                        data: [
                            {
                                y: 40
                            },
                            {
                                y: 0
                            },
                            {
                                y: 240
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            }
                        ]
                    }
                },
                {
                    y: 450,
                    drilldown: {
                        name: 'Super Care 1 by Coverage Type',
                        categories: ['Self Only', 'Two Pary', 'Family', ' ', ' ', ' '],

                        data: [
                            {
                                y: 90
                            },
                            {
                                y: 95
                            },
                            {
                                y: 265
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            }
                        ]
                    }
                },
                {
                    y: ' '
                },
                {
                    y: ' '
                },
                {
                    y: ' '
                }
            ]
        }
    },
    {
        y: 165.00
    },
    {
        y: 226.00
    },
    {
        y: 79.50
    },
    {
        y: 0.00
    },
    {
        y: 693.25
    },
    {
        y: 230.00
    },
    {
        y: 24.00
    },
    {
        y: 2.36
    },
    {
        y: 6.00
    }
];


// Pie Dada

var messaPremiumByProductAmountReportPieData = [
    {
        y: 38,
        name: 'MED',
        drilldown: {
            name: 'MED Plan',
            data: [
                {
                    name: 'ABC Plan 1',
                    y: 19,
                    drilldown: {
                        name: 'ABC Plan 1 by Coverage Type',
                        data: [
                            {
                                name: 'Self Only',
                                y: 0,

                            },
                            {
                                name: 'Two Party',
                                y: 24
                            },
                            {
                                name: 'Full Family',
                                y: 76
                            }
                        ]
                    },
                },
                {
                    name: 'Choices Copay',
                    y: 31,
                    drilldown: {
                        name: 'Choices Copay by Coverage Type',
                        data: [
                            {
                                name: 'Self Only',
                                y: 14,

                            },
                            {
                                name: 'Two Party',
                                y: 0
                            },
                            {
                                name: 'Full Family',
                                y: 86
                            }
                        ]
                    },
                },
                {
                    name: 'Super Care 1',
                    y: 50,
                    drilldown: {
                        name: 'Super Care 1 by Coverage Type',
                        data: [
                            {
                                name: 'Self Only',
                                y: 21,

                            },
                            {
                                name: 'Two Party',
                                y: 20
                            },
                            {
                                name: 'Full Family',
                                y: 59
                            }
                        ]
                    },
                }
            ]
        },

    },
    {
        y: 7,
        name: 'RX'
    },
    {
        y: 10,
        name: 'DEN'
    },
    {
        y: 3,
        name: 'VIS'
    },
    {
        y: 0,
        name: 'ADD'
    },
    {
        y: 30,
        name: 'LIFE'
    },
    {
        y: 10,
        name: 'LTD'
    },
    {
        y: 1,
        name: 'STD'
    },
    {
        y: .3,
        name: 'BTL'
    },
    {
        y: .7,
        name: 'STL'
    }
];


// end data for drill down


var messaPremiumBySubgroupsAmountReportPieData = [
    {
        name: 'Administration',
        y: 17,
        url: 'administration-employees-list.html'
    },
    {
        name: 'Maintenance',
        y: 14
    },
    {
        name: 'Office Personnel',
        y: 36
    },
    {
        name: 'Teacher',
        y: 30
    },
    {
        name: 'Paraprofessional',
        y: 1
    }
];

var messaPremiumBySubgroupsAmountReportXAxis = [ "Administration", "Maintenance", 'Office Personnel', 'Teacher', 'Paraprofessional' ];

var messaPremiumBySubgroupsAmountReportYAxis = {
    min: 0,
    tickInterval: 100,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var messaPremiumBySubgroupsAmountReportData = [
    {
        data: [
            {
                y: 403.50,
                url: 'administration-employees-list.html'
            },
            {
                y: 336.75
            },
            {
                y: 848.50
            },
            {
                y: 705.00
            },
            {
                y: 32.36
            }
        ]
    }
];