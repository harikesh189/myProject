/*showSingleReport('InvoiceAgingSummaryReport',  InvoiceAgingSummaryReportXAxis, InvoiceAgingSummaryReportYAxis, InvoiceAgingSummaryReportData);*/

showSingleReport('ReportPlanRevenueSummaryReport', ReportPlanRevenueSummaryReportXAxis, ReportPlanRevenueSummaryReportYAxis, ReportPlanRevenueSummaryReportData);

jQuery(document).ready(function (e) {

    // Reports

    $('#barChart1').on('click', function () {
        showSingleReport('ReportPlanRevenueSummaryReport', ReportPlanRevenueSummaryReportXAxis, ReportPlanRevenueSummaryReportYAxis, ReportPlanRevenueSummaryReportData);
        $(this).addClass('active');
        $('#pieChart1').removeClass('active');
    });
    $('#pieChart1').on('click', function () {
        drawPieReport('ReportPlanRevenueSummaryReport', ReportPlanRevenueSummaryReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });


});