showSingleReport('customersInvoiceStatusReport', customersInvoiceStatusReportXAxis, customersInvoiceStatusReportYAxis, customersInvoiceStatusReportData);

jQuery(document).ready(function (e) {


    $(".fromDate,.toDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });


    $("#timeFrame1").change(function () {
        var timeFrame = $(this).val();
        if (timeFrame == '1') {
            $('.itemDate1').hide();
        } else if (timeFrame == '2') {
            $('.itemDate1').hide();
        } else if (timeFrame == '3') {
            $('.itemDate1').show();
        }
    });


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // Invoice Summary Report
    /*$('#pieChart1').on('click', function(){
     $(this).addClass('active');
     $('#barChart1').removeClass('active');
     var userType = $('select#userType').val();
     if (userType == '1'){
     drawPieReport('invoiceSummaryReport', allInvoiceSummaryReportPieData);
     }else if (userType == '2'){
     drawPieReport('invoiceSummaryReport', individualInvoiceSummaryReportPieData);
     }else if (userType == '3'){
     drawPieReport('invoiceSummaryReport', groupInvoiceSummaryReportPieData);
     }
     });
     $('#barChart1').on('click', function(){
     $('#pieChart1').removeClass('active');
     $(this).addClass('active');
     var userType = $('select#userType').val();
     if (userType == '1'){
     showSingleReport('customersInvoiceStatusReport', customersInvoiceStatusReportXAxis, customersInvoiceStatusReportYAxis, customersInvoiceStatusReportData);
     }else if (userType == '2'){
     showSingleReport('invoiceSummaryReport', individualInvoiceSummaryReportXAxis, individualInvoiceSummaryReportYAxis, individualInvoiceSummaryReportData);
     }else if (userType == '3'){
     showSingleReport('invoiceSummaryReport', groupInvoiceSummaryReportXAxis, groupInvoiceSummaryReportYAxis, groupInvoiceSummaryReportData);
     }
     });
     */

    $('select#userType').change(function () {
        var chartClick = $('.clickChart.active').attr('title');
        var userType = $(this).val();
        if (userType == '1') {
            showSingleReport('customersInvoiceStatusReport', customersInvoiceStatusReportXAxis, customersInvoiceStatusReportYAxis, customersInvoiceStatusReportData);

        }
        if (userType == '2') {
            showSingleReport('customersInvoiceStatusReport', customersInvoiceStatusIndividualReportXAxis, customersInvoiceStatusIndividualReportYAxis, customersInvoiceStatusIndividualReportData);
        }
        if (userType == '3') {
            showSingleReport('customersInvoiceStatusReport', customersInvoiceStatusGroupReportXAxis, customersInvoiceStatusGroupReportYAxis, customersInvoiceStatusGroupReportData);
        }
    });

});