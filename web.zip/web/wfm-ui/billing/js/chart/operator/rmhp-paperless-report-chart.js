showLineReport('rmhpMonthlyPaperlessUsersReport', rmhpMonthlyPaperlessUsersReportXAxis, rmhpMonthlyPaperlessUsersReportYAxis, rmhpMonthlyPaperlessUsersReportData);
showMultipleReport('rmhpMonthlyPaperlessUsersReport', rmhpMonthlyPaperlessUsersReportXAxis, rmhpMonthlyPaperlessUsersReportYAxis, rmhpMonthlyPaperlessUsersReportData);

jQuery(document).ready(function (e) {


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // RMHP Reports

    // Paperless User Summary Report
    $('#barChart1').on('click', function () {
        showMultipleReport('rmhpMonthlyPaperlessUsersReport', rmhpMonthlyPaperlessUsersReportXAxis, rmhpMonthlyPaperlessUsersReportYAxis, rmhpMonthlyPaperlessUsersReportData);
        $(this).addClass('active');
        $('#lineChart1').removeClass('active');
    });
    $('#lineChart1').on('click', function () {
        showLineReport('rmhpMonthlyPaperlessUsersReport', rmhpMonthlyPaperlessUsersReportXAxis, rmhpMonthlyPaperlessUsersReportYAxis, rmhpMonthlyPaperlessUsersReportData);

        $('#barChart1').removeClass('active');
        $(this).addClass('active');
    });


// Date Validation 
    $("#dateFrom").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        onClose: function (selectedDate) {
            $("#dateTill").datepicker("option", "minDate", selectedDate);
            var fromDateVal = $("#dateFrom").val();
            $("#dateFrom").attr('value', fromDateVal);

        }
    });


    $("#dateTill").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        onClose: function (selectedDate) {
            $("#dateFrom").datepicker("option", "maxDate", selectedDate);
            var toDateVal = $("#dateTill").val();
            $("#dateTill").attr('value', toDateVal);

        }
    });

});