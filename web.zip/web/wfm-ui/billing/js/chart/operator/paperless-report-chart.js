showMultipleReport('paperlessUsersReport', paperlessUsersReportXAxis, paperlessUsersReportYAxis, paperlessUsersReportData);

jQuery(document).ready(function (e) {


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });

    $('select#userType').change(function () {
        var userType = $(this).val();
        if (userType == '1') {
            showMultipleReport('paperlessUsersReport', paperlessUsersReportXAxis, paperlessUsersReportYAxis, paperlessUsersReportData);
        }
        if (userType == '2') {
            showSingleReport('paperlessUsersReport', individualPaperlessReportXAxis, individualPaperlessReportYAxis, individualPaperlessReportData);
        }
        if (userType == '3') {
            showSingleReport('paperlessUsersReport', groupPaperlessReportXAxis, groupPaperlessReportYAxis, groupPaperlessReportData);
        }
    });


});