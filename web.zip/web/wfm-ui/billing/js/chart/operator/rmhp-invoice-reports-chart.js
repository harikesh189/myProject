drawPieReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportPieData, 900);
showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportXAxis, rmhpInvoiceSummaryReportYAxis, rmhpInvoiceSummaryReportData);


showLineReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);
showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);


jQuery(document).ready(function (e) {


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // RMHP Reports

    // Invoice Summary Report
    $('#pieChart1').on('click', function () {
        drawPieReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportPieData, 900);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
        $("#billingFor1").val('1');
        $("#timeFrame1").val('2');
        $("#statusBy1").val('1');
    });
    $('#barChart1').on('click', function () {
        showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportXAxis, rmhpInvoiceSummaryReportYAxis, rmhpInvoiceSummaryReportData);

        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
        $("#billingFor1").val('1');
        $("#timeFrame1").val('2');
        $("#statusBy1").val('1');
    });


    $('select#billingFor1').change(function () {
        var billingForValue = $(this).val();
        if (billingForValue == '1') {
            showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportXAxis, rmhpInvoiceSummaryReportYAxis, rmhpInvoiceSummaryReportData);
            $("#timeFrame1").val('2');
            $("#statusBy1").val('1');
            $('#pieChart1').removeClass('active');
            $('#barChart1').addClass('active');
            $('.manualTimeFilter.itemDate1').hide();
        } else if (billingForValue == '2') {
            showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryIndividualReportXAxis, rmhpInvoiceSummaryIndividualReportYAxis, rmhpInvoiceSummaryIndividualReportData);
            $("#timeFrame1").val('2');
            $("#statusBy1").val('1');
            $('#pieChart1').removeClass('active');
            $('#barChart1').addClass('active');
            $('.manualTimeFilter.itemDate1').hide();
        } else if (billingForValue == '3') {
            showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryGroupReportXAxis, rmhpInvoiceSummaryGroupReportYAxis, rmhpInvoiceSummaryGroupReportData);
            $("#timeFrame1").val('2');
            $("#statusBy1").val('1');
            $('#pieChart1').removeClass('active');
            $('#barChart1').addClass('active');
            $('.manualTimeFilter.itemDate1').hide();
        }
    });

    $('select#timeFrame1').change(function () {
        var timeFrame = $(this).val();
        if (timeFrame == '1') {
            $('.manualTimeFilter.itemDate1').hide();
            /*showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);

             $("#billingFor1").val('2');
             $("#statusBy1").val('1');*/
        } else if (timeFrame == '2') {
            $('.manualTimeFilter.itemDate1').hide();
            /*	showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryBothReportXAxis, rmhpOnlineBillingSummaryBothReportYAxis, rmhpOnlineBillingSummaryBothReportData);

             $("#billingFor1").val('1');
             $("#statusBy1").val('2');*/
        } else if (timeFrame == '3') {
            $('.manualTimeFilter.itemDate1').show();
        }
    });

    /*$('select#statusBy1').change(function(){
     var statusBy = $(this).val();
     if (statusBy == '1'){
     showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);

     $("#billingFor1").val('2');
     $("#timeFrame1").val('1');
     }else if (statusBy == '2'){
     showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryBothReportXAxis, rmhpOnlineBillingSummaryBothReportYAxis, rmhpOnlineBillingSummaryBothReportData);
     $("#billingFor1").val('1');
     $("#timeFrame1").val('2');
     }
     });*/

    // Online Billing Summary Report
    $('#lineChart2').on('click', function () {
        showLineReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');

        $("#billingFor2").val('2');
        $("#timeFrame2").val('1');
        $("#statusBy2").val('1');
    });
    $('#barChart2').on('click', function () {
        showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);

        $('#lineChartIndividual').removeClass('active');
        $(this).addClass('active');
        $("#billingFor2").val('2');
        $("#timeFrame2").val('1');
        $("#statusBy2").val('1');
    });

    $('select#billingFor2').change(function () {
        var billingForValue = $(this).val();
        if (billingForValue == '1') {
            showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryBothReportXAxis, rmhpOnlineBillingSummaryBothReportYAxis, rmhpOnlineBillingSummaryBothReportData);
            $("#timeFrame2").val('2');
            $("#statusBy2").val('2');
        } else if (billingForValue == '2') {
            showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);
            $("#timeFrame2").val('1');
            $("#statusBy2").val('1');
        } else if (billingForValue == '3') {
            showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryGroupReportXAxis, rmhpOnlineBillingSummaryGroupReportYAxis, rmhpOnlineBillingSummaryGroupReportData);
            $("#timeFrame2").val('1');
            $("#statusBy2").val('1');
        }
    });

    $('select#timeFrame2').change(function () {
        var timeFrame = $(this).val();
        if (timeFrame == '1') {
            showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);
            $('.manualTimeFilter.itemDate2').hide();
            $("#billingFor2").val('2');
            $("#statusBy2").val('1');
        } else if (timeFrame == '2') {
            showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryBothReportXAxis, rmhpOnlineBillingSummaryBothReportYAxis, rmhpOnlineBillingSummaryBothReportData);
            $("#billingFor2").val('1');
            $("#statusBy2").val('2');
            $('.manualTimeFilter.itemDate2').hide();
        }
        else if (timeFrame == '3') {
            $('.manualTimeFilter.itemDate2').show();
        }

    });

    $('select#statusBy2').change(function () {
        var statusBy = $(this).val();
        if (statusBy == '1') {
            showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryIndividualReportXAxis, rmhpOnlineBillingSummaryIndividualReportYAxis, rmhpOnlineBillingSummaryIndividualReportData);

            $("#billingFor2").val('2');
            $("#timeFrame2").val('1');
            $('.manualTimeFilter.itemDate2').hide();
        } else if (statusBy == '2') {
            showMultipleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryBothReportXAxis, rmhpOnlineBillingSummaryBothReportYAxis, rmhpOnlineBillingSummaryBothReportData);
            $("#billingFor2").val('1');
            $("#timeFrame2").val('2');
            $('.manualTimeFilter.itemDate2').hide();
        }
    });
});