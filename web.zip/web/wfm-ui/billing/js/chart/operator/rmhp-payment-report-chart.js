drawPieReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportPieData);
showSingleReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportXAxis, rmhpPaymentSummaryReportYAxis, rmhpPaymentSummaryReportData);

showSingleReport('rmhpPaymentSummaryByPMReport', rmhpPaymentSummaryByPMReportXAxis, rmhpPaymentSummaryByPMReportYAxis, rmhpPaymentSummaryByPMReportData);
drawPieReport('rmhpPaymentSummaryByPMReport', rmhpPaymentSummaryByPMReportPieData);

drawPieReport('rmhpPaymentSummaryByPSReport', rmhpPaymentSummaryByPSReportPieData);
showSingleReport('rmhpPaymentSummaryByPSReport', rmhpPaymentSummaryByPSReportXAxis, rmhpPaymentSummaryByPSReportYAxis, rmhpPaymentSummaryByPSReportData);


jQuery(document).ready(function (e) {


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // RMHP Reports

    // Payment Summary by Payment Processor
    $('#pieChart1').on('click', function () {
        drawPieReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showSingleReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportXAxis, rmhpPaymentSummaryReportYAxis, rmhpPaymentSummaryReportData);
        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Payment Summary by Payment Method
    $('#pieChart2').on('click', function () {
        drawPieReport('rmhpPaymentSummaryByPMReport', rmhpPaymentSummaryByPMReportPieData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart2').on('click', function () {
        showSingleReport('rmhpPaymentSummaryByPMReport', rmhpPaymentSummaryByPMReportXAxis, rmhpPaymentSummaryByPMReportYAxis, rmhpPaymentSummaryByPMReportData);
        $('#pieChart2').removeClass('active');
        $(this).addClass('active');
    });

    // Payment Summary by Payment Source
    $('#pieChart3').on('click', function () {
        drawPieReport('rmhpPaymentSummaryByPSReport', rmhpPaymentSummaryByPSReportPieData);
        $(this).addClass('active');
        $('#barChart3').removeClass('active');
    });
    $('#barChart3').on('click', function () {
        showSingleReport('rmhpPaymentSummaryByPSReport', rmhpPaymentSummaryByPSReportXAxis, rmhpPaymentSummaryByPSReportYAxis, rmhpPaymentSummaryByPSReportData);
        $('#pieChart3').removeClass('active');
        $(this).addClass('active');
    });


});	