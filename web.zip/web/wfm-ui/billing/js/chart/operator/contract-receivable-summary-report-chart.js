drawPieReport('ContractReceivableDistributionReport', ContractReceivableSummaryReportPieData);

showMultipleReport('ContractReceivableDistributionbyPlanReport', ContractReceivableDistributionPlanReportXAxis, ContractReceivableDistributionPlanReportYAxis, ContractReceivableDistributionPlanReportData);


jQuery(document).ready(function (e) {

    // Reports

    $('#pieChart1').on('click', function () {
        drawPieReport('ContractReceivableDistributionReport', ContractReceivableSummaryReportPieData);
        $(this).addClass('active');
    });


    $('#barChart1').on('click', function () {
        showSingleReport('ContractReceivableDistributionbyPlanReport', ContractReceivableDistributionPlanReportXAxis, ContractReceivableDistributionPlanReportYAxis, ContractReceivableDistributionPlanReportData);
        $(this).addClass('active');
    });


});