// Partner Revenue
/*drawPieReport('invoicedToOutstandingReport', invoicedToOutstandingReportPieData);

 drawPieReport('pendingToRemitReport', pendingToRemitReportPieData);

 drawPieReport('invoicedToUserFeesReport', invoicedToUserFeesReportPieData);

 drawPieReport('collectedToRemittedReport', collectedToRemittedReportPieData);*/
showMultipleReport('invoicedToOutstandingReport', invoicedToOutstandingBarReportXAxis, invoicedToOutstandingBarReportYAxis, invoicedToOutstandingBarReportData);
showMultipleReport('pendingToRemitReport', pendingToRemitBarReportXAxis, pendingToRemitBarReportYAxis, pendingToRemitBarReportData);
showMultipleReport('invoicedToUserFeesReport', invoicedToUserFeesBarReportXAxis, invoicedToUserFeesBarReportYAxis, invoicedToUserFeesBarReportData);
showMultipleReport('collectedToRemittedReport', collectedToRemittedBarReportXAxis, collectedToRemittedBarReportYAxis, collectedToRemittedBarReportData);

jQuery(document).ready(function (e) {

    $(".showItems").hover(
        function () {
            $(this).find(".dropItems").show();
        }, function () {
            $(this).find(".dropItems").hide();
        }
    );


    $(".fromDate,.toDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });

    $(".showItemsDate").click(function () {
        $(this).find(".dropItems").toggle();
    });


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // Reports

    // Invoice Summary Report
    $('#pieChart1').on('click', function () {
        drawPieReport('invoicedToOutstandingReport', invoicedToOutstandingReportPieData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Invoiced to Outstanding');
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showMultipleReport('invoicedToOutstandingReport', invoicedToOutstandingBarReportXAxis, invoicedToOutstandingBarReportYAxis, invoicedToOutstandingBarReportData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Invoice/Outstanding');
        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Online Billing Summary Report
    $('#pieChart2').on('click', function () {
        drawPieReport('pendingToRemitReport', pendingToRemitReportPieData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Pending to Remit');
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart2').on('click', function () {
        showMultipleReport('pendingToRemitReport', pendingToRemitBarReportXAxis, pendingToRemitBarReportYAxis, pendingToRemitBarReportData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Pending/Remit');
        $('#pieChart2').removeClass('active');
        $(this).addClass('active');
    });

    // Pending Remits
    $('#pieChart3').on('click', function () {
        drawPieReport('invoicedToUserFeesReport', invoicedToUserFeesReportPieData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Invoiced to User Fees');
        $(this).addClass('active');
        $('#barChart3').removeClass('active');
    });
    $('#barChart3').on('click', function () {
        showMultipleReport('invoicedToUserFeesReport', invoicedToUserFeesBarReportXAxis, invoicedToUserFeesBarReportYAxis, invoicedToUserFeesBarReportData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Invoice/User Fees');
        $('#pieChart3').removeClass('active');
        $(this).addClass('active');
    });

    // User Fee
    $('#pieChart4').on('click', function () {
        drawPieReport('collectedToRemittedReport', collectedToRemittedReportPieData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Collected to Remitted');
        $(this).addClass('active');
        $('#barChart4').removeClass('active');
    });
    $('#barChart4').on('click', function () {
        showMultipleReport('collectedToRemittedReport', collectedToRemittedBarReportXAxis, collectedToRemittedBarReportYAxis, collectedToRemittedBarReportData);
        $(this).parents('.whiteBox').find('.reportTypeTitle').html('Collected/Remitted');
        $('#pieChart4').removeClass('active');
        $(this).addClass('active');
    });
});