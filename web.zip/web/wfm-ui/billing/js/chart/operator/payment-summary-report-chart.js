showSingleReport('PaymentsSummaryReport', PaymentsSummaryReportXAxis, PaymentsSummaryReportYAxis, PaymentsSummaryReportData);


jQuery(document).ready(function (e) {

    // Reports

    $('#barChart1').on('click', function () {
        showSingleReport('PaymentsSummaryReport', PaymentsSummaryReportXAxis, PaymentsSummaryReportYAxis, PaymentsSummaryReportData);
        $(this).addClass('active');
    });


});