showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportXAxis, rmhpInvoiceSummaryReportYAxis, rmhpInvoiceSummaryReportData);
drawPieReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportPieData);


jQuery(document).ready(function (e) {

    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    $('select#userType').change(function () {
        var userType = $(this).val();
        var billStatus = $('select#billStatus').val();
        var delinquent = $('select#delinquent').val();
        if (userType == '1') {
            $('.forIndividual').show();
            $('.forGroup').show();
            $('#reportTypeTitle').html('All Customers Accounts ');
            $('#exportCsv').attr('href', '../docs/customer-account-report-all.csv');
            $('#exportXls').attr('href', '../docs/customer-account-report-all.xls');

        }
        if (userType == '2') {
            $('.forIndividual').show();
            $('#reportTypeTitle').html('Individual Customer Accounts');
            $('.forGroup').hide();
            $('#exportCsv').attr('href', '../docs/customer-account-report-individual.csv');
            $('#exportXls').attr('href', '../docs/customer-account-report-individual.xls');
        }
        if (userType == '3') {
            $('.forIndividual').hide();
            $('#reportTypeTitle').html('Group Customer Accounts ');
            $('.forGroup').show();
            $('#exportCsv').attr('href', '../docs/customer-account-report-group.csv');
            $('#exportXls').attr('href', '../docs/customer-account-report-group.xls');
        }
    });

    $('select#billStatus').change(function () {
        var billStatus = $(this).val();
        if (billStatus == '1') {
            $('.paid').show();
            $('.unpaid').show();
            $('.p-paid').show();
        }
        if (billStatus == '2') {
            $('.paid').show();
            $('.unpaid').hide();
            $('.p-paid').hide();
        }
        if (billStatus == '3') {
            $('.paid').hide();
            $('.unpaid').show();
            $('.p-paid').hide();
        }
        if (billStatus == '4') {
            $('.paid').hide();
            $('.unpaid').hide();
            $('.p-paid').show();
        }
    });

    $('select#delinquent').change(function () {
        var delinquentType = $(this).val();
        if (delinquentType == '1') {
            $('.dYes').show();
            $('.dNo').show();
        }
        if (delinquentType == '2') {
            $('.dYes').show();
            $('.dNo').hide();
        }
        if (delinquentType == '3') {
            $('.dYes').hide();
            $('.dNo').show();
        }
    });


});	