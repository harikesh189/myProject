SubmittingForm = function () {
    window.location = 'change-password.html';
}
$(document).ready(function () {
    $('a.form-submit').click(function (e) {
        e.preventDefault();
        $("#changePassword").submit();
    });
    $("#changePassword").validate({
        onfocusout: function (element) {
            $(element).valid();
        },
        validClass: "success",
        submitHandler: function (form) {
            SubmittingForm();
        },
        rules: {
            current_password: {
                required: true,
                //passwordCheck: true
                pass: true

            },
            new_password: {
                required: true,
                minlength: 8,
                pass: true
            },
            confirm_new_password: {
                required: true,
                minlength: 8,
                equalTo: "#new_password"
            }
        },
        messages: {

            current_password: {
                required: "Please enter your current password"
            },
            new_password: {
                required: "Please enter new password"
            },
            confirm_new_password: {
                required: "Please confirm the password"
            }
        }

    });
    // Validate password for speacial character
    jQuery.validator.addMethod("pass", function (value, element) {
        return this.optional(element) || /[^\w\s]/.test(value);
    }, "Password should have atleast one speacial character.");
});