// Trending
showMultipleReport('trendingInvoiceReport', trendingInvoiceReportXAxis, trendingInvoiceReportYAxis, trendingInvoiceReportData);
showMultipleReport('trendingOutstandingReport', trendingOutstandingReportXAxis, trendingOutstandingReportYAxis, trendingOutstandingReportData);
showMultipleReport('trendingPendingRemitsReport', trendingPendingRemitsReportXAxis, trendingPendingRemitsReportYAxis, trendingPendingRemitsReportData);
showMultipleReport('trendingUserFeeReport', trendingUserFeeReportXAxis, trendingUserFeeReportYAxis, trendingUserFeeReportData);

jQuery(document).ready(function (e) {

    $(".showItems").hover(
        function () {
            $(this).find(".dropItems").show();
        }, function () {
            $(this).find(".dropItems").hide();
        }
    );


    $(".fromDate,.toDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });

    $(".showItemsDate").click(function () {
        $(this).find(".dropItems").toggle();
    });


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // Reports

    // Invoice Summary Report
    $('#pieChart1').on('click', function () {
        showMultiplePercentReport('trendingInvoiceReport', trendingInvoicePercentReportXAxis, trendingInvoicePercentReportYAxis, trendingInvoicePercentReportData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showMultipleReport('trendingInvoiceReport', trendingInvoiceReportXAxis, trendingInvoiceReportYAxis, trendingInvoiceReportData);
        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Online Billing Summary Report
    $('#pieChart2').on('click', function () {
        showMultiplePercentReport('trendingOutstandingReport', trendingOutstandingPercentReportXAxis, trendingOutstandingPercentReportYAxis, trendingOutstandingPercentReportData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart2').on('click', function () {
        showMultipleReport('trendingOutstandingReport', trendingOutstandingReportXAxis, trendingOutstandingReportYAxis, trendingOutstandingReportData);
        $('#pieChart2').removeClass('active');
        $(this).addClass('active');
    });

    // Pending Remits
    $('#pieChart3').on('click', function () {
        showMultiplePercentReport('trendingPendingRemitsReport', trendingPendingRemitsPercentReportXAxis, trendingPendingRemitsPercentReportYAxis, trendingPendingRemitsPercentReportData);
        $(this).addClass('active');
        $('#barChart3').removeClass('active');
    });
    $('#barChart3').on('click', function () {
        showMultipleReport('trendingPendingRemitsReport', trendingPendingRemitsReportXAxis, trendingPendingRemitsReportYAxis, trendingPendingRemitsReportData);
        $('#pieChart3').removeClass('active');
        $(this).addClass('active');
    });

    // User Fee
    $('#pieChart4').on('click', function () {
        showMultiplePercentReport('trendingUserFeeReport', trendingUserFeePercentReportXAxis, trendingUserFeePercentReportYAxis, trendingUserFeePercentReportData);
        $(this).addClass('active');
        $('#barChart4').removeClass('active');
    });
    $('#barChart4').on('click', function () {
        showMultipleReport('trendingUserFeeReport', trendingUserFeeReportXAxis, trendingUserFeeReportYAxis, trendingUserFeeReportData);

        $('#pieChart4').removeClass('active');
        $(this).addClass('active');
    });
});