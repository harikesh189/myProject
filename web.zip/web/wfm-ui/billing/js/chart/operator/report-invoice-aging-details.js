/*showSingleReport('InvoiceAgingSummaryReport',  InvoiceAgingSummaryReportXAxis, InvoiceAgingSummaryReportYAxis, InvoiceAgingSummaryReportData);*/

drawPieReport('InvoiceAgingSummaryReport', InvoiceAgingSummaryReportPieData);

jQuery(document).ready(function (e) {

    // Reports

    $('#barChart1').on('click', function () {
        showSingleReport('InvoiceAgingSummaryReport', InvoiceAgingSummaryReportXAxis, InvoiceAgingSummaryReportYAxis, InvoiceAgingSummaryReportData);
        $(this).addClass('active');
    });


});