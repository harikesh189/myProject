showSingleReport('InvoiceForecastAgingReport', InvoiceForecastAgingReportXAxis, InvoiceForecastAgingReportYAxis, InvoiceForecastAgingReportData);


jQuery(document).ready(function (e) {

    // Reports

    $('#barChart1').on('click', function () {
        showSingleReport('InvoiceForecastAgingReport', InvoiceForecastAgingReportXAxis, InvoiceForecastAgingReportYAxis, InvoiceForecastAgingReportData);
        $(this).addClass('active');
    });


});