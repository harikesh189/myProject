drawPieReport('rmhpreceivableAmountReport', rmhpreceivableAmountReportPieData);
showSingleReport('rmhpreceivableAmountReport', rmhpreceivableAmountReportXAxis, rmhpreceivableAmountReportYAxis, rmhpreceivableAmountReportData);

drawPieReport('rmhptotalPayableAmountReport', rmhptotalPayableAmountReportPieData);
showSingleReport('rmhptotalPayableAmountReport', rmhptotalPayableAmountReportXAxis, rmhptotalPayableAmountReportYAxis, rmhptotalPayableAmountReportData);


jQuery(document).ready(function (e) {


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // RMHP Reports

    //  Receivable Report
    $('#pieChart1').on('click', function () {
        drawPieReport('rmhpreceivableAmountReport', rmhpreceivableAmountReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');

    });
    $('#barChart1').on('click', function () {
        showSingleReport('rmhpreceivableAmountReport', rmhpreceivableAmountReportXAxis, rmhpreceivableAmountReportYAxis, rmhpreceivableAmountReportData);

        $('#pieChart1').removeClass('active');
        $(this).addClass('active');

    });


    // Payable Report
    $('#pieChart2').on('click', function () {
        drawPieReport('rmhptotalPayableAmountReport', rmhptotalPayableAmountReportPieData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');

    });
    $('#barChart2').on('click', function () {
        showSingleReport('rmhptotalPayableAmountReport', rmhptotalPayableAmountReportXAxis, rmhptotalPayableAmountReportYAxis, rmhptotalPayableAmountReportData);

        $('#pieChart2').removeClass('active');
        $(this).addClass('active');

    });

    $('select#timeFrame1').change(function () {
        var timeFrame = $(this).val();
        if (timeFrame == '1') {
            $('.manualTimeFilter.itemDate1').hide();

        } else if (timeFrame == '2') {
            $('.manualTimeFilter.itemDate1').hide();

        } else if (timeFrame == '3') {
            $('.manualTimeFilter.itemDate1').show();
        }
    });
    $('select#timeFrame2').change(function () {
        var timeFrame = $(this).val();
        if (timeFrame == '1') {
            $('.manualTimeFilter.itemDate2').hide();
        } else if (timeFrame == '2') {
            $('.manualTimeFilter.itemDate2').hide();
        }
        else if (timeFrame == '3') {
            $('.manualTimeFilter.itemDate2').show();
        }

    });
});	