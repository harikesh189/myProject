var barChart;
var pieChart;
var paymentSummarybyPaymentSourceChart = drawPieReportWithDrillDown('paymentSummarybyPaymentSource', paymentSummarybyPaymentSourcePieData);
function exportChartToPdf(chart, fileName) {
    exportToPdf(chart, fileName);
}
// Payment Summary
drawPieReport('paymentSummarybyPaymentSource', paymentSummaryReportPieData);
// Payment Status
showSingleReport('paymentStatusIndReport', paymentStatusIndReportXAxis, paymentStatusIndReportYAxis, paymentStatusIndReportData);
showSingleReport('paymentStatusGroupReport', paymentStatusGroupReportXAxis, paymentStatusGroupReportYAxis, paymentStatusGroupReportData);


jQuery(document).ready(function (e) {

    $('.PaymentProcessor').hide();
    $('.PaymentMethod').hide();
    $(".showItems").hover(
        function () {
            $(this).find(".dropItems").show();
        }, function () {
            $(this).find(".dropItems").hide();
        }
    );


    $(".fromDate,.toDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });

    $('#pieChart1').on('click', function () {
        drawPieReport('paymentSummarybyPaymentSource', paymentSummaryReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showSingleReport('paymentSummarybyPaymentSource', paymentSummaryReportXAxis, paymentSummaryReportYAxis, paymentSummaryReportData);
        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Payment Reports


    function chartFlowItem(userTypeText, viewByText) {
        $('#chartFlow').append('<li>' + userTypeText + ' - ' + viewByText + '<span class="close userType">X</span></li>');
        $('#chartFlow').last().addClass('last');
    }


    // Payment Summary by user types
    $("#userType").change(function () {
        var chartClick = $('.clickChart.active').attr('title');
        var userType = $('#userType').val();
        var userTypeText = $('#userType option:selected').text();
        if (userType == '1') {
            $('#exportCsv').attr('href', '../docs/payment-report-all.csv');
            $('#exportXls').attr('href', '../docs/payment-report-all.xls');
            $('#viewBy').val(0);
            $("ul#chartFlow").empty();
            $(this).removeClass('active');
            if (chartClick == 'Pie Chart') {
                drawPieReport('paymentSummarybyPaymentSource', paymentSummaryReportPieData);
                //pieChart =  drawPieReportWithDrillDown('paymentSummarybyPaymentSource', paymentSummarybyPaymentSourcePieData);
                $('#exportPdf').attr('href', 'javascript:exportChartToPdf(pieChart, "payment_Summary")');
            } else if (chartClick == 'Bar Chart') {
                barChart = showSingleReportWithDrillDown('paymentSummarybyPaymentSource', paymentSummarybyPaymentSourceXAxis, paymentSummarybyPaymentSourceYAxis, paymentSummarybyPaymentSourceData);
                $('#exportPdf').attr('href', 'javascript:exportChartToPdf(barChart, "payment_Summary")');
            }
            $('#viewBy').empty().append("<option value='0' selected>Select</option><option value='1'>Payment Source</option><option value='2'>Payment Processor</option><option value='3'>Payment Method</option>");
        } else if (userType == '2') {
            $('#exportCsv').attr('href', '../docs/payment-report-individual.csv');
            $('#exportXls').attr('href', '../docs/payment-report-individual.xls');
            $('#viewBy').empty().append("<option value='1'>Payment Source</option><option value='2'>Payment Processor</option><option value='3'>Payment Method</option>");
            $('#viewBy').val(1);
            if ($(this).hasClass('active')) {
            } else {
                $(this).addClass('active');
                var viewByText = $('#viewBy option:selected').text();
                chartFlowItem(userTypeText, viewByText);
            }


            if (chartClick == 'Pie Chart') {
                pieChart = drawPieReportWithDrillDown('paymentSummarybyPaymentSource', paymentSummarybyPaymentSourceIndividualPieData);
                $('#exportPdf').attr('href', 'javascript:exportChartToPdf(pieChart, "payment_Summary")');
            } else if (chartClick == 'Bar Chart') {
                barChart = showSingleReportWithDrillDown('paymentSummarybyPaymentSource', paymentSummarybyPaymentSourceIndividualXAxis, paymentSummarybyPaymentSourceIndividualYAxis, paymentSummarybyPaymentSourceIndividualData);
                $('#exportPdf').attr('href', 'javascript:exportChartToPdf(barChart, "payment_Summary")');
            }
        } else if (userType == '3') {
            $('#viewBy').val(1);
            if ($(this).hasClass('active')) {
            } else {
                $(this).addClass('active');
                var viewByText = $('#viewBy option:selected').text();
                chartFlowItem(userTypeText, viewByText);
            }
            $('#reportTypeSubTitle').html('Payment Source');
            $('#exportCsv').attr('href', '../docs/payment-report-group.csv');
            $('#exportXls').attr('href', '../docs/payment-report-group.xls');

            if (chartClick == 'Pie Chart') {
                pieChart = drawPieReportWithDrillDown('paymentSummarybyPaymentSource', paymentSummarybyPaymentSourceGroupPieData);
                $('#exportPdf').attr('href', 'javascript:exportChartToPdf(pieChart, "payment_Summary")');
            } else if (chartClick == 'Bar Chart') {
                barChart = showSingleReportWithDrillDown('paymentSummarybyPaymentSource', paymentSummarybyPaymentSourceGroupXAxis, paymentSummarybyPaymentSourceGroupYAxis, paymentSummarybyPaymentSourceGroupData);
                $('#exportPdf').attr('href', 'javascript:exportChartToPdf(barChart, "payment_Summary")');
            }
        }


    });

    $("#timeFrame1").change(function () {
        var timeFrame = $(this).val();
        if (timeFrame == '1') {
            $('.itemDate1').hide();
        } else if (timeFrame == '2') {
            $('.itemDate1').hide();
        } else if (timeFrame == '3') {
            $('.itemDate1').show();
        }
    });

    // Payment Status

    $("#timeFrame2").change(function () {
        var timeFrame = $(this).val();

        if (timeFrame == '1') {
            showMultipleReport('paymentStatusIndReport', monthlyPaymentStatusIndReportXAxis, monthlyPaymentStatusIndReportYAxis, monthlyPaymentStatusIndReportData);
            $("#reportTypeTimeFrame2").html('For 2014');
            $('.manualTimeFilter.itemDate2').hide();
        } else if (timeFrame == '2') {
            showSingleReport('paymentStatusIndReport', paymentStatusIndReportXAxis, paymentStatusIndReportYAxis, paymentStatusIndReportData);
            $('.manualTimeFilter.itemDate2').hide();
            $("#reportTypeTimeFrame2").html('From 01-01-2014 To 01-16-2014');
        } else if (timeFrame == '3') {
            $('.manualTimeFilter.itemDate2').show();
        }
    });

    $("#timeFrame3").change(function () {
        var timeFrame = $(this).val();

        if (timeFrame == '1') {
            showMultipleReport('paymentStatusGroupReport', monthlyPaymentStatusGroupReportXAxis, monthlyPaymentStatusGroupReportYAxis, monthlyPaymentStatusGroupReportData);
            $('.manualTimeFilter.itemDate3').hide();
            $("#reportTypeTimeFrame3").html('For 2014');
        } else if (timeFrame == '2') {
            showSingleReport('paymentStatusGroupReport', paymentStatusGroupReportXAxis, paymentStatusGroupReportYAxis, paymentStatusGroupReportData);
            $('.manualTimeFilter.itemDate3').hide();
            $("#reportTypeTimeFrame3").html('From 01-01-2014 To 01-16-2014');
        } else if (timeFrame == '3') {
            $('.manualTimeFilter.itemDate3').show();
        }
    });


});