/*Highcharts.setOptions({
 colors: ['#8FBC8F', '#CC9933', '#848484', '#64E572', '#FFF263', '#6AF9C4', '#FF9655', '#24CBE5', '#FFD39B']
 });*/

Highcharts.setOptions({
    colors: ['#6b9851', '#af6968', '#dfb65b', '#746b96', '#6dadd0', '#6AF9C4', '#FF9655', '#24CBE5', '#FFD39B']

});

function showMultipleReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    var obj = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + '$' + Highcharts.numberFormat(this.y, 2) + ' ';
            }
        },

        series: data,
        plotOptions: {
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });

}

function showMultipleByCountReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    var obj = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + this.y;
            }
        },

        series: data,
        plotOptions: {
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });
}

function showMultiplePercentReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    var obj = $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + this.y + '%';
            }
        },

        series: data,
        plotOptions: {
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });

}


function showSingleReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + '$' + Highcharts.numberFormat(this.y, 2) + ' ';
            }
        },
        legend: {
            enabled: false
        },
        series: data,
        plotOptions: {
            column: {colorByPoint: true},
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });
}

function showSingleByCountReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        tooltip: {
            formatter: function () {
                return ' ' + this.x + ' ' + this.y;
            }
        },
        legend: {
            enabled: false
        },
        series: data,
        plotOptions: {
            column: {colorByPoint: true},
            series: {
                name: ' ',
                dataLabels: {
                    enabled: false,
                    inside: false,
                    crop: false,
                    overflow: 'none',
                    /*borderRadius: 0,
                     backgroundColor: 'black',
                     borderWidth: 1,
                     borderColor: 'black',
                     color: 'white',*/
                    format: '{y}',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            }
        }
    });
}

function showLineReport(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        legend: {
            enabled: true
        },
        series: data,
        plotOptions: {
            column: {colorByPoint: true},
            series: {
                name: ' ',
                marker: {
                    fillColor: '#FFFFFF',
                    lineWidth: 2,
                    lineColor: null
                }
            }
        }
    });
}

function drawPieReport(divId, data, legendWidth, chartWidth) {
    $('#' + divId).empty();
    $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 235,
            width: chartWidth

        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 250,
            borderWidth: 0,
            symbolWidth: 15,
            symbolStyle: 'circle',
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 5,
            /*borderWidth: 0,
             itemMarginBottom: 5,*/
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '250'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                shadow: false,
                innerSize: '40%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                },
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            rmhpDrawBar();
                        }
                    }
                }
            }
        },
        series: [
            {
                type: 'pie',
                name: ' ',
                data: data
            }
        ]
    });
}


// Drill Downs

function setChart(chart, name, categories, data, color) {
    chart.xAxis[0].setCategories(categories, false);
    chart.series[0].remove(false);
    chart.addSeries({
        name: name,
        data: data,
        color: color || 'white'
    }, false);
    chart.redraw();
}
var chart;
function showSingleReportWithDrillDown(divId, xAxisData, yAxisData, data, chartWidth) {
    $('#' + divId).empty();
    chart = new $('#' + divId).highcharts({
        chart: {
            type: 'column',
            width: chartWidth
        },
        xAxis: {
            categories: xAxisData,
            maxPadding: 0.001,
            lineWidth: 1,
            lineColor: 'black'
        },
        yAxis: yAxisData,
        exporting: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            column: {
                colorByPoint: true,
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            var drilldown = this.drilldown;
                            if (drilldown) { // drill down
                                setChart(chart, drilldown.name, drilldown.categories, drilldown.data);
                                var titleName = drilldown.name;
                                var userType = $('#userType').val();
                                if (userType == '1') {
                                    //$('#exportPdf').attr('href','docs/Payment Summary by ' + titleName +' Bar.pdf');
                                } else if (userType == '2') {
                                    //$('#exportPdf').attr('href','docs/Payment Summary by ' + titleName +' Bar Individual.pdf');
                                } else if (userType == '3') {
                                    //$('#exportPdf').attr('href','docs/Payment Summary by ' + titleName +' Bar Individual.pdf');
                                }
                                $('#reportTypeSubTitle').html(titleName);
                            } else { // restore
                                setChart(chart, name, xAxisData, data);
                                //$('#exportPdf').attr('href','docs/Payment Summary by Payment Source Bar.pdf');
                                $('#reportTypeSubTitle').html('Payment Source');
                            }
                        }
                    }
                },
                dataLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold'
                    },
                    formatter: function () {
                        return this.y;
                    }
                }
            }
        },
        series: [
            {
                name: ' ',
                data: data
            }
        ]
    }).highcharts();
    return chart;
}


function drawPieReportWithDrillDown(divId, data, chartWidth) {
    $('#' + divId).empty();
    var chart = $('#' + divId).highcharts({
        chart: {
            type: 'pie',
            height: 235,
            width: chartWidth

        },
        tooltip: {
            formatter: function () {
                return ' ' + this.point.name + ' ' + this.y + '%' + ' ';
            }
        },
        legend: {
            enabled: true,
            layout: 'vertical',
            align: 'right',
            width: 250,
            borderWidth: 0,
            symbolWidth: 15,
            symbolStyle: 'circle',
            verticalAlign: 'middle',
            useHTML: true,
            itemMarginBottom: 5,
            /*borderWidth: 0,
             itemMarginBottom: 5,*/
            labelFormatter: function () {
                return '<div style="text-align: left;">' + this.name + ' - ' + '<strong>' + this.y + '%' + '</strong>' + '</div>';
            },
            itemStyle: {
                cursor: 'pointer',
                color: '#606060',
                fontSize: '13px',
                lineHeight: '18px',
                width: '250'
            }

        },

        exporting: {
            enabled: false
        },
        plotOptions: {
            pie: {
                shadow: false,
                innerSize: '40%',
                showInLegend: true,
                size: '120%',
                borderColor: '#f0f0f0',
                borderWidth: '1px',
                dataLabels: {
                    enabled: false

                },
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            var drilldown = this.drilldown;
                            var newName;
                            var newData;

                            if (drilldown) { // drill down
                                newName = drilldown.name;
                                newData = drilldown.data;
                                var titleName = drilldown.name;
                                var userType = $('#userType').val();

                                /*if (userType == '1'){
                                 //$('#exportPdf').attr('href','docs/Payment Summary by ' + titleName +'.pdf');
                                 } else if (userType == '2'){
                                 $('li.userType').addClass('hide');
                                 $('li.timeFrame1').addClass('hide');
                                 $('.'+titleName).removeClass('hide');
                                 $('.'+titleName).addClass('active');
                                 $('#viewBy').val(2);

                                 } else if (userType == '3'){
                                 //$('#exportPdf').attr('href','docs/Payment Summary by ' + titleName +'Group.pdf');
                                 } */
                                if ($('.PaymentProcessor').hasClass('active')) {
                                    /*$('.PaymentMethod').removeClass('hide');
                                     $('.PaymentProcessor').addClass('hide');*/
                                    $('.PaymentMethod').show();
                                    $('.PaymentProcessor').hide();
                                    $('.viewBy').hide();
                                    var viewByText = $('.PaymentMethod #paymentProcessor option:selected').text();
                                    $('#chartFlow').append('<span class="backArrow"> </span><li class="last">' + viewByText + '<span class="close userType">X</span></li>');
                                } else {
                                    var sourceByText = $('#sourceBy option:selected').text();
                                    var viewByText = $('#viewBy option:selected').text();
                                    $('#chartFlow').append('<span class="backArrow"> </span><li class="last">' + sourceByText + ' - ' + 'Payment Processor' + '<span class="close userType">X</span></li>');
                                }
                                /*$('li.userType').addClass('hide');
                                 $('li.timeFrame1').addClass('hide');
                                 $('.'+titleName).removeClass('hide');*/
                                $('li.userType').hide();
                                $('li.timeFrame1').hide();
                                $('.' + titleName).show();
                                $('.' + titleName).addClass('active');
                                $('#viewBy').empty().append("<option value='2'>Payment Processor</option><option value='3'>Payment Method</option>");
                                $('#viewBy').val(2);


                                $('#reportTypeSubTitle').html(titleName);
                            } else { // restore
                                newName = name;
                                newData = data;
                                //$('#exportPdf').attr('href','docs/Payment Summary by Payment Source.pdf');
                                $('#reportTypeSubTitle').html('Payment Source');
                                /*$('li.userType').removeClass('hide');
                                 $('li.timeFrame1').removeClass('hide');
                                 $('.viewBy').removeClass('hide');
                                 $('.PaymentMethod').addClass('hide');*/
                                $('li.userType').show();
                                $('li.timeFrame1').show();
                                $('.viewBy').show();
                                $('.PaymentMethod').hide();
                                $('.PaymentProcessor').removeClass('active')
                                $('#viewBy').val(1);
                                $('#chartFlow').empty().append('<li class="last">' + 'Individual - Payment Source' + '<span class="close userType">X</span> </li>');
                                $('#viewBy').empty().append("<option value='1'>Payment Source</option><option value='2'>Payment Processor</option><option value='3'>Payment Method</option>");
                            }

                            chart.series[0].remove(false);
                            chart.addSeries({
                                name: newName,
                                data: newData
                            }, false);
                            chart.redraw();

                        }
                    }
                }
            }
        },
        series: [
            {
                type: 'pie',
                name: ' ',
                data: data
            }
        ]
    }).highcharts();
    return chart;
}

function exportToPdf(chart, fileName) {

    //exportChart(chart, 'application/pdf', 'payment_Summary_by_Payment_Source');
    chart.exportChart({type: 'application/pdf', filename: fileName}, {subtitle: {text: ''}});
}
 