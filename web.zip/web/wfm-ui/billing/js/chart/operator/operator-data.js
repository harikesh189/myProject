// 1
var operatorHomeReportXAxis = [ "Medical", " ", " ", " ", " "];

var operatorHomeReportYAxis = {
    min: 0,
    tickInterval: 50,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var operatorHomeReportData = [
    {
        name: 'Blue Cross of Idaho',
        data: [250.00, '', '', '', '']
    },
    {
        name: 'PacificSource',
        data: [93.75, '', '', '', '']
    }
];


// 2
var operatorCustomerEBillReportXAxis = [ "Active eBill Customers", "Termed Customers", "Average Customers Login(month)", "" ];

var operatorCustomerEBillReportYAxis = {
    min: 0,
    tickInterval: 250,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var operatorCustomerEBillReportData = [
    {
        data: [2000, 27, 1998, '']
    }
];


// 3
var operatorOnlinePaymentReportXAxis = [ "Average Online Invoice", "Average Online Payment", '', '' ];

var operatorOnlinePaymentReportYAxis = {
    min: 0,
    tickInterval: 15,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var operatorOnlinePaymentReportData = [
    {
        data: [100, 99, '', '']
    }
];


// 4

var delinquentCustomerDetailsReportXAxis = [ "Customers within Month End Term", "Customers on 2nd Notice", "Customers on 1st Notice", "Excluded Customers", "No Due" ];

var delinquentCustomerDetailsReportYAxis = {
    min: 0,
    tickInterval: 10,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var delinquentCustomerDetailsReportData = [
    {
        data: [33, 2, 3, 10, 7]
    }
];

var delinquentCustomerDetailsReportPieData = [
    ['Customers within Month End Term', 33],
    ['Customers on 2nd Notice', 2],
    ['Customers on 1st Notice', 3],
    ['Excluded Customers', 10],
    ['No Due', 7]
];


// 5
var invoicingDetailsReportXAxis = [ "Invoice Created", "Invoice Pending", "Payment Received", "Payment Due" ];

var invoicingDetailsReportYAxis = {
    min: 0,
    tickInterval: 100,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var invoicingDetailsReportData = [
    {
        name: 'Individual',
        data: [570, 430, 500, 50]
    },
    {
        name: 'Group',
        data: [80, 40, 70, 30]
    }
];


// 6
var subscribeByPlanReportXAxis = [ "Blue Cross of Idaho Bronze Plan", "BrightIdea Bronze Plan", " ", " "/*, "Met Flexi", "DD Exl"*/ ];

var subscribeByPlanReportYAxis = {
    min: 0,
    tickInterval: 50,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var subscribeByPlanReportData = [
    {
        data: [250.00, 93.75, " ", " "]
    }
];

var subscribeByPlanReportPieData = [
    ["Blue Cross of Idaho Bronze Plan", 250.00],
    ["BrightIdea Bronze Plan", 93.750]
];


// 7
var revenueByIssuerReportXAxis = [ "Blue Cross of Idaho", /*"Metlife", "Delta Dental", */"PacificSource", ' ', ' ' ];

var revenueByIssuerReportYAxis = {
    min: 0,
    tickInterval: 50,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var revenueByIssuerReportData = [
    {
        data: [250.00, 93.75, '' , '']
    }
];

var revenueByIssuerReportPieData = [
    ["Blue Cross of Idaho", 250.00],
    // ["Metlife", 150],
    // ["Delta Dental", 100],
    ["PacificSource", 93.75],
    [" ", ''],
    [" ", ''],
];


// 8
var receivableAmountReportXAxis = [ "Individual", "Group", "US Treasury" ];

var receivableAmountReportYAxis = {
    min: 0,
    tickInterval: 50000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var receivableAmountReportData = [
    {
        data: [170000, 200000, 65000]
    }
];

var receivableAmountReportPieData = [
    ["Individual", 170000],
    ["Group", 200000],
    ["US Treasury", 65000]
];


// 9
var totalPayableAmountReportXAxis = [ "Issuers", "Brokers", "Vendor", "Operator" ];

var totalPayableAmountReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var totalPayableAmountReportData = [
    {
        data: [23000, 2000, 3000, 4000]
    }
];

var totalPayableAmountReportPieData = [
    ["Issuers", 23000],
    ["Brokers", 2000],
    ["Vendor", 3000],
    ["Operator", 4000]
];


// 10
var delinquentSubscriberReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul" ];

var delinquentSubscriberReportYAxis = {
    min: 0,
    tickInterval: 100,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var delinquentSubscriberReportData = [
    {
        data: [100, 50, 70, 255, 120, 200, 400]
    }
];

var delinquentSubscriberReportPieData = [
    ['Jan', 100],
    ['Feb', 50],
    ['Mar', 70],
    ['Apr', 255],
    ['May', 120],
    ['Jun', 200],
    ['Jul', 400]
];

// 11
var currentMonthReceivableAmountReportXAxis = [ "Individual", "Group", "US Treasury", "User Fees" ];

var currentMonthReceivableAmountReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var currentMonthReceivableAmountReportData = [
    {
        data: [17000, 20000, 6500, 500]
    }
];

var currentMonthReceivableAmountReportPieData = [
    ["Individual", 17000],
    ["Group", 20000],
    ["US Treasury", 6500],
    ["User Fees", 500]
];


// 12
var currentMonthPayableAmountReportXAxis = [ "Issuer", "Broker", "Vendor", "Operator", "Exchange" ];

var currentMonthPayableAmountReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var currentMonthPayableAmountReportData = [
    {
        data: [23000, 2000, 3000, 4000, 1000]
    }
];

var currentMonthPayableAmountReportPieData = [
    ["Issuers", 23000],
    ["Brokers", 2000],
    ["Vendor", 3000],
    ["Operator", 4000],
    ["Exchange", 4000]
];


/* ============================ RMHP Reports Data =========================== */

// Invoice Summary Report by count

var rmhpInvoiceSummaryReportPieData = [
    ['Individual', 32],
    ['Group', 68]
];

var rmhpInvoiceSummaryReportXAxis = [ "Group", "Individual", ' ', ' ', ' ' ];

var rmhpInvoiceSummaryReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var rmhpInvoiceSummaryReportData = [
    {
        data: [2000.00, 8000.00, ' ', ' ', ' ']
    }
];

// For Individual by count

var rmhpInvoiceSummaryIndividualReportPieData = [
    ['Total Invoices', 50],
    ['Paid In Full Invoices', 37.50],
    ['Outstanding Invoices', 7.5],
    ['Rolled Invoices', 5]
];

var rmhpInvoiceSummaryIndividualReportXAxis = [ "Total Invoices", "Paid In Full Invoices", 'Outstanding Invoices', 'Rolled Invoices', ' ' ];

var rmhpInvoiceSummaryIndividualReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var rmhpInvoiceSummaryIndividualReportData = [
    {
        data: [8000.00, 6000.00, 1200.00, 800.00, ' ']
    }
];

// For Group

var rmhpInvoiceSummaryGroupReportPieData = [
    ['Total Invoices', 50],
    ['Paid In Full Invoices', 25],
    ['Outstanding Invoices', 20],
    ['Rolled Invoices', 5]
];

var rmhpInvoiceSummaryGroupReportXAxis = [ "Total Invoices", "Paid In Full Invoices", 'Outstanding Invoices', 'Rolled Invoices', ' ' ];

var rmhpInvoiceSummaryGroupReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var rmhpInvoiceSummaryGroupReportData = [
    {
        data: [2000.00, 1000.00, 800.00, 200.00, ' ']
    }
];

// Invoice Summary Report by amount

var rmhpInvoiceSummaryByAmountReportPieData = [
    ['Individual', 32],
    ['Group', 68]
];

var rmhpInvoiceSummaryByAmountReportXAxis = [ "Group", "Individual", ' ', ' ', ' ' ];

var rmhpInvoiceSummaryByAmountReportYAxis = {
    min: 0,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpInvoiceSummaryByAmountReportData = [
    {
        data: [60000.00, 28000.00, ' ', ' ', ' ']
    }
];

// For Individual

var rmhpInvoiceSummaryIndividualByAmountReportPieData = [
    ['Invoice Amount', 50],
    ['Payment Received', 27],
    ['Payment Due', 9],
    ['Rolled Up Amount', 14]
];

var rmhpInvoiceSummaryIndividualByAmountReportXAxis = [ "Invoice Amount", "Payment Received", 'Payment Due', 'Rolled Up Amount', ' ', ' ', ' ' ];

var rmhpInvoiceSummaryIndividualByAmountReportYAxis = {
    min: 0,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpInvoiceSummaryIndividualByAmountReportData = [
    {
        data: [28000, 15000, 5000, 8000, ' ', ' ', ' ']
    }
];

// For Group

var rmhpInvoiceSummaryGroupByAmountReportPieData = [
    ['Invoice Amount', 50],
    ['Payment Received', 33],
    ['Payment Due', 8.5],
    ['Rolled Up Amount', 8.5]
];

var rmhpInvoiceSummaryGroupByAmountReportXAxis = [ "Invoice Amount", "Payment Received", 'Payment Due', 'Rolled Up Amount', ' ', ' ', ' ' ];

var rmhpInvoiceSummaryGroupByAmountReportYAxis = {
    min: 0,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpInvoiceSummaryGroupByAmountReportData = [
    {
        data: [60000, 40000, 10000, 10000, ' ', ' ', ' ']
    }
];

// Online Billing Summary

/*var rmhpOnlineBillingSummaryReportPieData = [
 ['Invoice Amount',   50],
 ['Payment Received',  31],
 ['Payment Due',  9],
 ['Rolled Up Amount',  10]
 ];*/

var rmhpOnlineBillingSummaryReportXAxis = [ "Invoice Amount", "Payment Received", 'Payment Due', 'Rolled Up Amount' ];

var rmhpOnlineBillingSummaryReportYAxis = {
    min: 0,
    tickInterval: 20000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpOnlineBillingSummaryReportData = [
    {
        data: [88000.00, 55000.00, 15000, 18000]
    }
];

// Online Billing Summary for Both by Amount year to date

/*var rmhpOnlineBillingSummaryBothReportXAxis = [ "Invoice Amount", "Payment Received", "Payment Due", "Rolled Up Amount", ' ', ' ', ' '];

 var rmhpOnlineBillingSummaryBothReportYAxis = {
 min : 0,
 tickInterval: 10000,
 lineWidth: 1,
 lineColor: 'black',
 labels: {
 formatter: function() {return '$' + this.value;}
 }
 };

 var rmhpOnlineBillingSummaryBothReportData = [{
 name: 'Individual',
 data: [28000, 15000, 5000, 8000, ' ', ' ', ' ']
 }, {
 name: 'Group',
 data: [60000, 40000, 10000, 10000, ' ', ' ', ' ']
 }];*/

var rmhpOnlineBillingSummaryBothReportXAxis = [ "Individual", "Group"];

var rmhpOnlineBillingSummaryBothReportYAxis = {
    min: 0,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpOnlineBillingSummaryBothReportData = [
    {
        name: 'Invoice Amount',
        data: [28000, 60000]
    },
    {
        name: 'Payment Received',
        data: [15000, 40000]
    },
    {
        name: 'Payment Due',
        data: [5000, 10000]
    },
    {
        name: 'Rolled Up Amount',
        data: [8000, 10000]
    }
];


// by both Monthly

var rmhpOnlineBillingSummaryBothAmountMonthlyReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var rmhpOnlineBillingSummaryBothAmountMonthlyReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpOnlineBillingSummaryBothAmountMonthlyReportData = [
    {
        name: 'Invoice Amount',
        data: [6000, 6000, 6000, 7000, 7500, 7500, 8000, 8000, 8000, 10000, 7000, 7000]
    },
    {
        name: 'Payment Received',
        data: [4000, 4000, 4000, 4000, 4000, 4000, 5000, 6000, 5500, 7500, 5500, 1500]
    },
    {
        name: 'Payment Due',
        data: [900, 900, 900, 1400, 1400, 900, 1400, 900, 1100, 1100, 800, 3300]
    },
    {
        name: 'Rolled Up Amount',
        data: [1100, 1100, 1100, 1600, 2100, 2600, 1600, 1100, 1400, 1400, 700, 2200]
    }
];


// Online Billing Summary for Individual by Amount

var rmhpOnlineBillingSummaryIndividualAmountReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var rmhpOnlineBillingSummaryIndividualAmountReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpOnlineBillingSummaryIndividualAmountReportData = [
    {
        name: 'Invoice Amount',
        data: [2000, 2000, 2000, 2000, 2500, 2500, 3000, 3000, 3000, 4000, 4000, 1000]
    },
    {
        name: 'Payment Received',
        data: [1000, 1000, 1000, 1000, 1000, 1000, 2000, 2000, 1500, 2500, 500, 500]
    },
    {
        name: 'Payment Due',
        data: [400, 400, 400, 400, 400, 400, 400, 400, 600, 600, 300, 300]
    },
    {
        name: 'Rolled Up Amount',
        data: [600, 600, 600, 600, 1100, 1100, 600, 600, 900, 900, 200, 200]
    }
];


// Online Billing Summary for Group by Amount

var rmhpOnlineBillingSummaryGroupAmountReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var rmhpOnlineBillingSummaryGroupAmountReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpOnlineBillingSummaryGroupAmountReportData = [
    {
        name: 'Invoice Amount',
        data: [4000, 4000, 4000, 5000, 5000, 5000, 5000, 5000, 5000, 6000, 6000, 6000]
    },
    {
        name: 'Payment Received',
        data: [3000, 3000, 3000, 3000, 3000, 3000, 3000, 4000, 4000, 5000, 5000, 1000]
    },
    {
        name: 'Payment Due',
        data: [500, 500, 500, 1000, 1000, 500, 1000, 500, 500, 500, 500, 3000]
    },
    {
        name: 'Rolled Up Amount',
        data: [500, 500, 500, 1000, 1000, 1500, 1000, 500, 500, 500, 500, 2000]
    }
];


// Online Billing Summary for Both by Count

// Year to date
var rmhpOnlineBillingSummaryBothCountReportXAxis = [  "Total Invoices", "Paid In Full Invoices", 'Outstanding Invoices', 'Rolled Invoices', ' ', ' ', ' '];

var rmhpOnlineBillingSummaryBothCountReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var rmhpOnlineBillingSummaryBothCountReportData = [
    {
        name: 'Individual',
        data: [8000, 6000, 1200, 800, ' ', ' ', ' ']
    },
    {
        name: 'Group',
        data: [2000, 1000, 800, 200, ' ', ' ', ' ']
    }
];

// by both Monthly

var rmhpOnlineBillingSummaryBothCountMonthlyReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var rmhpOnlineBillingSummaryBothCountMonthlyReportYAxis = {
    min: 0,
    tickInterval: 100,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var rmhpOnlineBillingSummaryBothCountMonthlyReportData = [
    {
        name: 'Total Online Invoices',
        data: [700, 800, 850, 950, 950, 1000, 1050, 1150, 1200, 650, 450, 250]
    },
    {
        name: 'Paid in Full Invoices',
        data: [550, 550, 550, 725, 625, 750, 750, 800, 800, 425, 325, 150]
    },
    {
        name: 'Outstanding invoices',
        data: [90, 140, 215, 135, 235, 155, 230, 245, 295, 130, 65, 65]
    },
    {
        name: 'Rolled Invoices',
        data: [60, 110, 85, 90, 90, 95, 70, 105, 105, 95, 60, 35]
    }
];

// Online Billing Summary for Individual by count Monthly

var rmhpOnlineBillingSummaryIndividualCountReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var rmhpOnlineBillingSummaryIndividualCountReportYAxis = {
    min: 0,
    tickInterval: 100,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var rmhpOnlineBillingSummaryIndividualCountReportData = [
    {
        name: 'Total Online Invoices',
        data: [600, 700, 750, 800, 800, 800, 850, 850, 900, 450, 350, 150]
    },
    {
        name: 'Paid in Full Invoices',
        data: [500, 500, 500, 650, 550, 650, 650, 650, 650, 325, 275, 100]
    },
    {
        name: 'Outstanding invoices',
        data: [50, 100, 175, 75, 175, 75, 150, 125, 175, 50, 25, 25]
    },
    {
        name: 'Rolled Invoices',
        data: [50, 100, 75, 75, 75, 75, 50, 75, 75, 75, 50, 25]
    }
];


// Online Billing Summary for Group by count Monthly

var rmhpOnlineBillingSummaryGroupCountReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

var rmhpOnlineBillingSummaryGroupCountReportYAxis = {
    min: 0,
    tickInterval: 100,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var rmhpOnlineBillingSummaryGroupCountReportData = [
    {
        name: 'Total Online Invoices',
        data: [100, 100, 100, 150, 150, 200, 200, 300, 300, 200, 100, 100]
    },
    {
        name: 'Paid in Full Invoices',
        data: [50, 50, 50, 75, 75, 100, 100, 150, 150, 100, 50, 50]
    },
    {
        name: 'Outstanding invoices',
        data: [40, 40, 40, 60, 60, 80, 80, 120, 120, 80, 40, 40]
    },
    {
        name: 'Rolled Invoices',
        data: [10, 10, 10, 15, 15, 20, 20, 30, 30, 20, 10, 10]

    }
];

// Payment Summary by Payment Processor

var rmhpPaymentSummaryReportPieData = [
    ['ACI', 45],
    ['PayPal', 36],
    ['Third Party Billing System', 19]
];

var rmhpPaymentSummaryReportXAxis = [ "ACI", "PayPal", 'Third Party Billing System', ' ', ' '];

var rmhpPaymentSummaryReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpPaymentSummaryReportData = [
    {
        data: [25000.00, 20000.00, 10000, ' ', ' ']
    }
];


// Payment Summary by Payment Method

var rmhpPaymentSummaryByPMReportPieData = [
    ['Onetime', 43],
    ['Recurring', 37],
    ['Binder', 20]
];

var rmhpPaymentSummaryByPMReportXAxis = [ "Onetime", "Recurring", 'Binder', ' ', ' ', ' ', ' '];

var rmhpPaymentSummaryByPMReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpPaymentSummaryByPMReportData = [
    {
        data: [25000.00, 20000.00, 10000, ' ', ' ', ' ', ' ']
    }
];

// Payment Summary by Payment Source

var rmhpPaymentSummaryByPSReportPieData = [
    ['COHBE', 43],
    ['Private', 37]
];

var rmhpPaymentSummaryByPSReportXAxis = [ "COHBE", "Private", ' ', ' ', ' ', ' ', ' '];

var rmhpPaymentSummaryByPSReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpPaymentSummaryByPSReportData = [
    {
        data: [35000.00, 20000.00, ' ', ' ', ' ', ' ', ' ']
    }
];


// Monthly Paperless Users

/*var rmhpMonthlyPaperlessUsersReportXAxis = [ "Jan","Feb","Mar","Apr","May", "Jun", "Jul","Aug", "Sep","Oct","Nov", "Dec"];

 var rmhpMonthlyPaperlessUsersReportYAxis = {
 min : 0,
 tickInterval: 500,
 lineWidth: 1,
 lineColor: 'black',
 labels: {
 formatter: function() {return this.value;}
 }
 };

 var rmhpMonthlyPaperlessUsersReportData = [{
 name: 'Individual',
 data: [1500, 1000, 1300, 1500, 1800,1600,1500,1400,1500,2000,1800,600]
 }, {
 name: 'Group',
 data: [150, 120, 150, 180,160,150,150,120,150,150,180,120]
 }];*/

var paperlessUsersReportXAxis = [ "Individual", "Group"];

var paperlessUsersReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var paperlessUsersReportData = [
    {
        name: 'Total Users',
        data: [2000, 200]
    },
    {
        name: 'Paperless Users',
        data: [1800, 150]
    }
];

// Individual paperless data

var individualPaperlessReportXAxis = [ "Total Users", "Paperless Users", " ", " ", " "];

var individualPaperlessReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var individualPaperlessReportData = [
    {
        data: [2000, 1800, " ", " ", " "]
    }
];

// Group paperless data

var groupPaperlessReportXAxis = [ "Total Users", "Paperless Users", " ", " ", " "];

var groupPaperlessReportYAxis = {
    min: 0,
    tickInterval: 100,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var groupPaperlessReportData = [
    {
        data: [200, 150, " ", " ", " "]
    }
];

/*--------------------------------- Diganostic Reports ----------------------------------------- */

// Payment Amount by Payment Processor

var rmhpDianosticPAByProcessorReportPieData = [
    ['ACI', 38],
    ['PayPal', 62]
];

var rmhpDianosticPAByProcessorReportXAxis = [ "ACI", "PayPal", ' ', ' ', ' ', ' ', ' '];

var rmhpDianosticPAByProcessorReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpDianosticPAByProcessorReportData = [
    {
        data: [1400.00, 2250.00, ' ', ' ', ' ', ' ', ' ']
    }
];


// Payment Amount by Payment mode

var rmhpDianosticPAByModeReportPieData = [
    ['EFT', 12],
    ['Credit Card', 88]
];

var rmhpDianosticPAByModeReportXAxis = [ "EFT", "Credit Card", ' ', ' ', ' ', ' ', ' '];

var rmhpDianosticPAByModeReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpDianosticPAByModeReportData = [
    {
        data: [450.00, 3250.00, ' ', ' ', ' ', ' ', ' ']
    }
];


// Payment by Card Type

var rmhpDianosticPByCardTypeReportPieData = [
    ['American Express', 24],
    ['Master Card', 25],
    ['Visa', 36],
    ['Discover', 15]
];

var rmhpDianosticPByCardTypeReportXAxis = [ "American Express", "Master Card", 'Visa', 'Discover', ' ', ' ', ' '];

var rmhpDianosticPByCardTypeReportYAxis = {
    min: 0,
    tickInterval: 200,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpDianosticPByCardTypeReportData = [
    {
        data: [800.00, 800.00, 1200.00, 400.00, ' ', ' ', ' ']
    }
];

// Payment by Account Type


var rmhpDianosticPByAccountTypeReportXAxis = [ "Checking", "Savings", ' ', ' ', ' ', ' ', ' '];

var rmhpDianosticPByAccountTypeReportYAxis = {
    min: 0,
    tickInterval: 50,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpDianosticPByAccountTypeReportData = [
    {
        data: [250.00, 200.00, ' ', ' ', ' ', ' ', ' ']
    }
];


// Receivable
var rmhpreceivableAmountReportXAxis = [ "Individual", "Group", "US Treasury", "User Fees", ' ', ' '];

var rmhpreceivableAmountReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpreceivableAmountReportData = [
    {
        data: [17000, 20000, 6500, 500, ' ', ' ']
    }
];

var rmhpreceivableAmountReportPieData = [
    ["Individual", 40],
    ["Group", 45],
    ["US Treasury", 14],
    ["User Fees", 1]
];


//  Payable
var rmhptotalPayableAmountReportXAxis = [ "Issuers", "Brokers", "Vendor", "Operator", ' ', ' ', ' ' ];

var rmhptotalPayableAmountReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhptotalPayableAmountReportData = [
    {
        data: [23000, 2000, 3000, 4000, ' ', ' ', ' ']
    }
];

var rmhptotalPayableAmountReportPieData = [
    ["Issuers", 72],
    ["Brokers", 6],
    ["Vendor", 9],
    ["Operator", 13]
];


//  Revenue by Vendor
var rmhpRevenueByVendorReportXAxis = [ "Delta Dental", "MI State Hospital", "Pharmacy Px", "United Brokers", ' ', ' ', ' ' ];

var rmhpRevenueByVendorReportYAxis = {
    min: 0,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpRevenueByVendorReportData = [
    {
        data: [20000.00, 40000.00, 30000.00, 20000.00, ' ', ' ', ' ']
    }
];

var rmhpRevenueByVendorReportPieData = [
    ["Delta Dental", 18],
    ["MI State Hospital", 36],
    ["Pharmacy Px", 27],
    ["United Brokers", 18]
];

//  Revenue by Entities
var rmhpRevenueByEntitiesReportXAxis = [ "Dental Vendor", "Provider", "Reinsurance Carrier", "PBM", "Broker", ' ', ' ' ];

var rmhpRevenueByEntitiesReportYAxis = {
    min: 0,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var rmhpRevenueByEntitiesReportData = [
    {
        data: [20000.00, 30000.00, 10000.00, 20000.00, 20000.00, ' ', ' ']
    }
];

var rmhpRevenueByEntitiesReportPieData = [
    ["Delta Dental", 18],
    ["MI State Hospital", 36],
    ["Pharmacy Px", 27],
    ["United Brokers", 18]
];


//***************************************************								
// Payment Tab charts - payment-reports.html

// Pie and Bar Data for Payment 
var paymentSummaryReportXAxis = [ "All", "Individual", "Group", " ", " ", ' ', ' ' ];

var paymentSummaryReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var paymentSummaryReportData = [
    {
        data: [19600.00, 3600.00, 16000.00, ' ', ' ', ' ', ' ']
    }
];

var paymentSummaryReportPieData = [
    ["Individual", 18],
    ["Group", 82]
];


// Pie Dada for All

var paymentSummarybyPaymentSourcePieData = [
    {
        y: 76,
        name: 'COHBE',
        drilldown: {
            name: 'Payment Processor',
            data: [
                {
                    name: 'ACI',
                    y: 45,
                    drilldown: {
                        name: 'Payment Mode',
                        data: [
                            {
                                name: 'EFT',
                                y: 94

                            },
                            {
                                name: 'Credit Card',
                                y: 6
                            }
                        ]
                    },
                },
                {
                    name: 'Paypal',
                    y: 55
                }
            ]
        },

    },
    {
        y: 24,
        name: 'Private'
    }
];


// Bar Data for Individual
var paymentSummarybyPaymentSourceIndividualXAxis = [ "COHBE", "Private", " ", " ", " ", " ", " ", " "];

var paymentSummarybyPaymentSourceIndividualYAxis = {
    min: 0,
    lineWidth: 1,
    tickInterval: 2000,
    lineColor: 'black',
    title: {
        text: ''
    },
    labels: {
        formatter: function () {
            return '$' + ' ' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var paymentSummarybyPaymentSourceIndividualData = [
    {
        y: 2800.00,
        drilldown: {
            name: 'Payment Processor',
            categories: ['ACI', 'Paypal', ' ', ' ', ' ', ' '],

            data: [
                {
                    y: 1600.00,
                    drilldown: {
                        name: 'Payment Mode',
                        categories: ['EFT', 'Credit Card', ' ', ' ', ' ', ' '],

                        data: [
                            {
                                y: 1200.00
                            },
                            {
                                y: 400.00
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            }
                        ]
                    }
                },
                {
                    y: 1700.00

                },
                {
                    y: ' '
                },
                {
                    y: ' '
                },
                {
                    y: ' '
                }
            ]
        }
    },
    {
        y: 800.00

    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    }
];


// Pie Dada for Individual

var paymentSummarybyPaymentSourceIndividualPieData = [
    {
        y: 78,
        name: 'COHBE',
        drilldown: {
            name: 'PaymentProcessor',
            data: [
                {
                    name: 'ACI',
                    y: 48,
                    drilldown: {
                        name: 'PaymentMode',
                        data: [
                            {
                                name: 'EFT',
                                y: 75

                            },
                            {
                                name: 'Credit Card',
                                y: 25
                            }
                        ]
                    },
                },
                {
                    name: 'Paypal',
                    y: 52
                }
            ]
        },

    },
    {
        y: 22,
        name: 'Private'
    }
];

// Bar Data for Group
var paymentSummarybyPaymentSourceGroupXAxis = [ "COHBE", "Private", " ", " ", " ", " ", " ", " "];

var paymentSummarybyPaymentSourceGroupYAxis = {
    min: 0,
    lineWidth: 1,
    tickInterval: 2000,
    lineColor: 'black',
    title: {
        text: ''
    },
    labels: {
        formatter: function () {
            return '$' + ' ' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var paymentSummarybyPaymentSourceGroupData = [
    {
        y: 12000.00,
        drilldown: {
            name: 'PaymentProcessor',
            categories: ['ACI', 'Paypal', ' ', ' ', ' ', ' '],

            data: [
                {
                    y: 5000.00,
                    drilldown: {
                        name: 'PaymentMode',
                        categories: ['EFT', 'Credit Card', ' ', ' ', ' ', ' '],

                        data: [
                            {
                                y: 5000.00
                            },
                            {
                                y: 7000.00
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            },
                            {
                                y: ' '
                            }
                        ]
                    }
                },
                {
                    y: 7000.00

                },
                {
                    y: ' '
                },
                {
                    y: ' '
                },
                {
                    y: ' '
                }
            ]
        }
    },
    {
        y: 4000.00

    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    },
    {
        y: ' '
    }
];


// Pie Dada for Group

var paymentSummarybyPaymentSourceGroupPieData = [
    {
        y: 75,
        name: 'COHBE',
        drilldown: {
            name: 'Payment Processor',
            data: [
                {
                    name: 'ACI',
                    y: 42,
                    drilldown: {
                        name: 'Payment Mode',
                        data: [
                            {
                                name: 'EFT',
                                y: 42

                            },
                            {
                                name: 'Credit Card',
                                y: 58
                            }
                        ]
                    },
                },
                {
                    name: 'Paypal',
                    y: 58
                }
            ]
        },

    },
    {
        y: 25,
        name: 'Private'
    }
];

// end data for drill down


// Payment Status Reports

//..

/*********Individual************/

var paymentStatusIndReportXAxis = [ "Invoice Amount", "Paid Amount", 'Unpaid Amount'];

var paymentStatusIndReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var paymentStatusIndReportData = [
    {
        data: [3600.00, 2300.00, 1300.00]
    }
];

// Monthly Payment Status for

var monthlyPaymentStatusIndReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];

var monthlyPaymentStatusIndReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var monthlyPaymentStatusIndReportData = [
    {
        name: 'Invoice Amount',
        data: [3600, 3800, 4000, 3500, 3600, 3800, 4000]
    },
    {
        name: 'Paid Amount',
        data: [2300, 3000, 3500, 3000, 2300, 3000, 3500]
    },
    {
        name: 'Unpaid Amount',
        data: [1300, 800, 500, 500, 1300, 800, 500]
    }
];

/*********Group************/

var paymentStatusGroupReportXAxis = [ "Invoice Amount", "Paid Amount", 'Unpaid Amount'];

var paymentStatusGroupReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var paymentStatusGroupReportData = [
    {
        data: [16000.00, 10000.00, 6000.00]
    }
];

// Monthly Payment Status for Group

var monthlyPaymentStatusGroupReportXAxis = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];

var monthlyPaymentStatusGroupReportYAxis = {
    min: 0,
    tickInterval: 2000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value;
        }
    }
};

var monthlyPaymentStatusGroupReportData = [
    {
        name: 'Invoice Amount',
        data: [16000.00, 1800.00, 16000.00, 16000.00, 1800.00, 16000.00, 2000.00]
    },
    {
        name: 'Paid Amount',
        data: [10000.00, 15000.00, 12000.00, 10000.00, 15000.00, 12000.00, 13500.00]
    },
    {
        name: 'Unpaid Amount',
        data: [6000.00, 3000.00, 4000.00, 6000.00, 3000.00, 4000.00, 6500.00]
    }
];

// Invoice Summary Reports - reports.html

var allInvoiceSummaryReportPieData = [
    ['Premium Amount', 78],
    ['Adjustment', 20],
    ['Customer Fees', 2]
];

var allInvoiceSummaryReportXAxis = [ "Total Amount Due", "Premium Amount", 'Prior Due', 'Adjustment', 'APTC', 'Credit', 'Fees'];

var allInvoiceSummaryReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var allInvoiceSummaryReportData = [
    {
        data: [19600.00, 19720.00, 2600.00, 900.00, 900.00, 1500.00, 580.00]
    }
];

// Individual

var individualInvoiceSummaryReportPieData = [
    ['Premium Amount', 68],
    ['Prior Due', 10],
    ['Adjustment', 6],
    ['APTC', 15],
    ['Fees', 1]
];

var individualInvoiceSummaryReportXAxis = [ "Total Amount Due", "Premium Amount", 'Prior Due', 'Adjustment', 'APTC', 'Fees'];

var individualInvoiceSummaryReportYAxis = {
    min: 0,
    tickInterval: 2000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var individualInvoiceSummaryReportData = [
    {
        data: [3600.00, 4220.00, 600.00, 400.00, 900.00, 80.00]
    }
];


// Group

var groupInvoiceSummaryReportPieData = [
    ['Premium Amount', 78],
    ['Prior Due', 10],
    ['Adjustment', 3],
    ['Credit', 8],
    ['Fees', 3]
];


var groupInvoiceSummaryReportXAxis = [ "Total Amount Due", "Premium Amoun", 'Prior Due', 'Adjustment', 'Credit', 'Fees'];

var groupInvoiceSummaryReportYAxis = {
    min: 0,
    tickInterval: 2000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var groupInvoiceSummaryReportData = [
    {
        data: [16000.00, 15500.00, 2000.00, 500.00, 1500.00, 500.00]
    }
];


// contract-receivable-summary.html

var ContractReceivableSummaryReportPieData = [
    ['Customer', 71.85],
    ['CMS', 28.15]
];

var ContractReceivableSummaryReportXAxis = [ "Customer", "CMS"];

var ContractReceivableSummaryReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var ContractReceivableSummaryReportData = [
    {
        data: [19600.00, 19720.00, 2600.00, 900.00, 900.00, 1500.00, 580.00]
    }
];


// second report of this page
var ContractReceivableDistributionPlanReportXAxis = [ "Medical", "Dental"];

var ContractReceivableDistributionPlanReportYAxis = {
    min: 0,
    tickInterval: 60000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var ContractReceivableDistributionPlanReportData = [
    {
        name: 'Customer',
        data: [204324.12, 87567.48]
    },
    {
        name: 'CMS',
        data: [19459.44]
    }
];


// report-invoice-aging-details.html

var InvoiceAgingSummaryReportPieData = [
    ['0-30 Days', 11.44],
    ['30-60 Days', 31.38],
    ['60-90 Days', 44.74],
    ['>90 Days', 12.42]
];

var InvoiceAgingSummaryReportXAxis = [ "0-30 Days", "30-60 Days", "60-90 Days", ">90 Days"];

var InvoiceAgingSummaryReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var InvoiceAgingSummaryReportData = [
    {
        data: [3029.08, 4621.25, 4858.76, 2784.33]
    }
];


// report-plan-revenue-details.html  InvoiceAgingSummaryReport

var ReportPlanRevenueSummaryReportPieData = [
    ['Invoiced', 34.5],
    ['Collected', 0.35],
    ['Users Fee', 31],
    ['Outstanding', 3.5],
    ['Remitted', 12],
    ['Pending', 18.6]
];

var ReportPlanRevenueSummaryReportXAxis = [ "Invoiced", "Collected", "Users Fee", "Outstanding", "Remitted", "Pending"];

var ReportPlanRevenueSummaryReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var ReportPlanRevenueSummaryReportData = [
    {
        data: [500000, 5000, 450000, 50000, 175000, 270000]
    }
];


// report-payment-summary.html

var PaymentsSummaryReportPieData = [
    ['0-30 Days', 3029.08],
    ['30-60 Days', 4621.25],
    ['60-90 Days', 4858.76],
    ['>90 Days', 2784.33]
];

var PaymentsSummaryReportXAxis = [ "Health Plan", "Group", "Individual"];

var PaymentsSummaryReportYAxis = {
    min: 0,
    tickInterval: 1000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var PaymentsSummaryReportData = [
    {
        data: [400.00, 6510.00, 4059.00]
    }
];


// report-invoice-forecast-aging-details.html

var InvoiceForecastAgingReportPieData = [
    ['0-30 Days', 3029.08],
    ['30-60 Days', 4621.25],
    ['60-90 Days', 4858.76],
    ['>90 Days', 2784.33]
];

var InvoiceForecastAgingReportXAxis = [ "0-30 Days", "30-60 Days", "60-90 Days", ">90 Days"];

var InvoiceForecastAgingReportYAxis = {
    min: 0,
    tickInterval: 1200,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var InvoiceForecastAgingReportData = [
    {
        data: [1942.03, 433.86, 1059.01, 5821.69]
    }
];


// Partner Revenue Reports - Summary 1

/* Invoiced */
var partnerRevenueInvoiceReportPieData = [
    ['Cigna', 38],
    ['Metlife', 1],
    ['UHG', 54],
    ['Delta Dental', 0],
    ['RMHP', 7]
];


var partnerRevenueInvoiceReportXAxis = [ "Cigna", "Metlife", 'UHG', 'Delta Dental', 'RMHP'];

var partnerRevenueInvoiceReportYAxis = {
    min: 0,
    tickInterval: 1000000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var partnerRevenueInvoiceReportData = [
    {
        data: [4922490.00, 95500.00, 7007610.00, 31229.00, 982300.00]
    }
];


/* Outstanding */

var partnerRevenueOutstandingReportPieData = [
    ['Cigna', 74],
    ['Metlife', 0],
    ['United Health Group', 24],
    ['Delta Dental', 0],
    ['RMHP', 2]
];


var partnerRevenueOutstandingReportXAxis = [ "Cigna", "Metlife", 'United Health Group', 'Delta Dental', 'RMHP'];

var partnerRevenueOutstandingReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var partnerRevenueOutstandingReportData = [
    {
        data: [327960.00, 970.00, 109108.00, 8.00, 8300.00]
    }
];

/* Pending Remits */

var partnerRevenuePendingRemitsReportPieData = [
    ['Cigna', 2],
    ['Metlife', 0],
    ['United Health Group', 98],
    ['Delta Dental', 0],
    ['RMHP', 0]
];


var partnerRevenuePendingRemitsReportXAxis = [ "Cigna", "Metlife", 'United Health Group', 'Delta Dental', 'RMHP'];

var partnerRevenuePendingRemitsReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var partnerRevenuePendingRemitsReportData = [
    {
        data: [10598.00, 1900.00, 576203.00, 0.00, 921.00]
    }
];


/* User Fee */

var partnerRevenueUserFeeReportPieData = [
    ['Cigna', 24],
    ['Metlife', 2],
    ['United Health Group', 69],
    ['Delta Dental', 0],
    ['RMHP', 5]
];


var partnerRevenueUserFeeReportXAxis = [ "Cigna", "Metlife", 'United Health Group', 'Delta Dental', 'RMHP'];

var partnerRevenueUserFeeReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var partnerRevenueUserFeeReportData = [
    {
        data: [10598.00, 1900.00, 576203.00, 0.00, 921.00]
    }
];

// Partner Revenue Summary 2

/* Invoiced to Outstanding */
var invoicedToOutstandingReportPieData = [
    ['Cigna', 66],
    ['Metlife', 10],
    ['United Health Group', 16],
    ['Delta Dental', 0],
    ['RMHP', 8]
];


var invoicedToOutstandingReportXAxis = [ "Cigna", "Metlife", 'United Health Group', 'Delta Dental', 'RMHP'];

var invoicedToOutstandingReportYAxis = {
    min: 0,
    tickInterval: 1000000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var invoicedToOutstandingReportData = [
    {
        data: [4922490.00, 95500.00, 7007610.00, 31229.00, 982300.00]
    }
];


/* Pending to Remit */

var pendingToRemitReportPieData = [
    ['Cigna', 20],
    ['Metlife', 19],
    ['United Health Group', 19],
    ['Delta Dental', 21],
    ['RMHP', 21]
];


var pendingToRemitReportXAxis = [ "Cigna", "Metlife", 'United Health Group', 'Delta Dental', 'RMHP'];

var pendingToRemitReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var partnerRevenueOutstandingS2ReportData = [
    {
        data: [327960.00, 970.00, 109108.00, 8.00, 8300.00]
    }
];

/* Invoiced to User Fees */

var invoicedToUserFeesReportPieData = [
    ['Cigna', 10],
    ['Metlife', 50],
    ['United Health Group', 20],
    ['Delta Dental', 10],
    ['RMHP', 10]
];


var invoicedToUserFeesReportXAxis = [ "Cigna", "Metlife", 'United Health Group', 'Delta Dental', 'RMHP'];

var invoicedToUserFeesReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var invoicedToUserFeesReportData = [
    {
        data: [10598.00, 1900.00, 576203.00, 0.00, 921.00]
    }
];


/* Collected to Remitted */

var collectedToRemittedReportPieData = [
    ['Cigna', 2],
    ['Metlife', 18],
    ['United Health Group', 79],
    ['Delta Dental', 0],
    ['RMHP', 1]
];


var collectedToRemittedReportXAxis = [ "Cigna", "Metlife", 'United Health Group', 'Delta Dental', 'RMHP'];

var collectedToRemittedReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var collectedToRemittedReportData = [
    {
        data: [10598.00, 1900.00, 576203.00, 0.00, 921.00]
    }
];

// Bar charts - Summary 2

/* Invoiced to Outstanding */

var invoicedToOutstandingBarReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var invoicedToOutstandingBarReportYAxis = {
    min: 0,
    tickInterval: 1000000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var invoicedToOutstandingBarReportData = [
    {
        name: 'Invoiced',
        data: [4922490.00, 95500.00, 7007610.00, 31229.00, 982300.00]
    },
    {
        name: 'Outstanding',
        data: [327960.00, 970.00, 109108.00, 8.00, 8300.00]
    }
];


// Pending To Remit
var pendingToRemitBarReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var pendingToRemitBarReportYAxis = {
    min: 0,
    tickInterval: 1000000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var pendingToRemitBarReportData = [
    {
        name: 'Pending Remit',
        data: [10598.00, 1900.00, 576203.00, 0.00, 921.00]
    },
    {
        name: 'Remitted',
        data: [4534707.10, 87855.00, 6182146.80, 30908.71, 963256.00]
    }
];

// Invoiced To UserFees
var invoicedToUserFeesBarReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var invoicedToUserFeesBarReportYAxis = {
    min: 0,
    tickInterval: 1000000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var invoicedToUserFeesBarReportData = [
    {
        name: 'Invoiced',
        data: [4922490.00, 95500.00, 7007610.00, 31229.00, 982300.00]
    },
    {
        name: 'User Fee',
        data: [49224.90, 4775.00, 140152.20, 312.29, 9823.00]
    }
];


// Collected To Remitted
var collectedToRemittedBarReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var collectedToRemittedBarReportYAxis = {
    min: 0,
    tickInterval: 1000000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var collectedToRemittedBarReportData = [
    {
        name: 'Collected',
        data: [4594530.00, 94530.00, 6898502.00, 31221.00, 974000.00]
    },
    {
        name: 'Remitted',
        data: [4534707.10, 87855.00, 6182146.80, 30908.71, 963256.00]
    }
];


// Partners Revenue Trending Reports

/* Trending Bar data with percentage */

// Invoiced
var trendingInvoicePercentReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingInvoicePercentReportYAxis = {
    min: 0,
    max: 100,
    tickInterval: 10,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value + '%';
        }
    }
};

var trendingInvoicePercentReportData = [
    {
        name: 'January',
        data: [37.8, 0.7, 53.7, 0.2, 7.5]
    },
    {
        name: 'February',
        data: [38.2, 0.7, 53.3, 0.3, 7.5]
    },
    {
        name: 'March',
        data: [37.4, 0.7, 54.3, 0.3, 7.3]
    }
];


// Outstanding
var trendingOutstandingPercentReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingOutstandingPercentReportYAxis = {
    min: 0,
    max: 100,
    tickInterval: 10,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value + '%';
        }
    }
};

var trendingOutstandingPercentReportData = [
    {
        name: 'January',
        data: [73.5, 0.2, 24.4, 0.0, 1.9]
    },
    {
        name: 'February',
        data: [15.5, 0.4, 72.0, 0.0, 12.1]
    },
    {
        name: 'March',
        data: [40.3, 0.3, 58.5, 0.0, 0.8]
    }
];

// Pending Remits
var trendingPendingRemitsPercentReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingPendingRemitsPercentReportYAxis = {
    min: 0,
    max: 100,
    tickInterval: 10,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value + '%';
        }
    }
};

var trendingPendingRemitsPercentReportData = [
    {
        name: 'January',
        data: [1.8, 0.3, 97.7, 0.0, 0.2]
    },
    {
        name: 'February',
        data: [1.9, 0.1, 97.8, 0.0, 0.2]
    },
    {
        name: 'March',
        data: [2.9, 0.3, 96.5, 0.1, 0.2]
    }
];


// User Fee
var trendingUserFeePercentReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingUserFeePercentReportYAxis = {
    min: 0,
    max: 100,
    tickInterval: 10,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value + '%';
        }
    }
};

var trendingUserFeePercentReportData = [
    {
        name: 'January',
        data: [24.1, 2.3, 68.3, 0.2, 4.8]
    },
    {
        name: 'February',
        data: [24.4, 2.3, 68.3, 0.2, 4.8]
    },
    {
        name: 'March',
        data: [23.8, 2.3, 69.1, 0.2, 4.7]
    }
];

/* Trending Bar data */

// Invoiced
var trendingInvoiceReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingInvoiceReportYAxis = {
    min: 0,
    tickInterval: 2000000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var trendingInvoiceReportData = [
    {
        name: 'January',
        data: [4922490.00, 95500.00, 7007610.00, 31229.00, 982300.00]
    },
    {
        name: 'February',
        data: [5168614.50, 99320.00, 7217838.30, 34039.61, 1011769.00]
    },
    {
        name: 'March',
        data: [5323672.96, 103292.80, 7723086.98, 39145.55, 1042122.07]
    }
];


// Outstanding
var trendingOutstandingReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingOutstandingReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var trendingOutstandingReportData = [
    {
        name: 'January',
        data: [327960.00, 970.00, 109108.00, 8.00, 8300.00]
    },
    {
        name: 'February',
        data: [155058.43, 3972.80, 721783.83, 340.40, 121412.28]
    },
    {
        name: 'March',
        data: [532367.30, 4131.71, 772308.70, 391.45, 10421.22]
    }
];

// Pending Remits
var trendingPendingRemitsReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingPendingRemitsReportYAxis = {
    min: 0,
    tickInterval: 100000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var trendingPendingRemitsReportData = [
    {
        name: 'January',
        data: [10598.00, 1900.00, 576203.00, 0.00, 921.00]
    },
    {
        name: 'February',
        data: [9501.00, 400.00, 498111.00, 20.00, 1059.00]
    },
    {
        name: 'March',
        data: [7320.00, 760.00, 243110.00, 290.00, 534.00]
    }
];


// User Fee
var trendingUserFeeReportXAxis = [ "Cigna", "Metlife", "United Health Group", "Delta Dental", "RMHP"];

var trendingUserFeeReportYAxis = {
    min: 0,
    tickInterval: 20000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var trendingUserFeeReportData = [
    {
        name: 'January',
        data: [49224.90, 4775.00, 140152.20, 312.30, 9823.00]
    },
    {
        name: 'February',
        data: [51686.15, 4966.00, 144356.76, 340.39, 10117.69]
    },
    {
        name: 'March',
        data: [53236.72, 5164.64, 154461.73, 391.45, 10421.22]
    }
];

//==================	APTC =============							

var aptcReportXAxis = [ "Rocky Mountain Health Plan", "Cigna"];

var aptcReportYAxis = {
    min: 0,
    tickInterval: 600,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var aptcReportReportData = [
    {
        name: 'APTC amount expected',
        data: [2278, 1382]
    },
    {
        name: 'APTC amount received ',
        data: [385, 330]
    }
];


//==================	CSR =============							

var csrReportXAxis = [ "Rocky Mountain Health Plan", "Cigna"];

var csrReportYAxis = {
    min: 0,
    tickInterval: 600,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var csrReportData = [
    {
        name: 'CSR amount expected',
        data: [2278, 1382]
    },
    {
        name: 'CSR amount received ',
        data: [385, 330]
    }
];


//==================USer Fee =============							

var userfeeReportXAxis = [ "Rocky Mountain Health Plan", "Cigna"];

var userfeeReportYAxis = {
    min: 0,
    tickInterval: 60,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var userfeeReportData = [
    {
        name: 'User Fee amount expected',
        data: [227, 137]
    },
    {
        name: 'User Fee amount received',
        data: [38.5, 33]
    }
];


/********************************************** Dashboard Reports - Home page ********************************************/

// New Enrollement Status Report

var newEnrollmentStatusReportXAxis = [ "Group", "Individual", " ", " "];

var newEnrollmentStatusReportYAxis = {
    min: 0,
    tickInterval: 500,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value
        }
    }
};

var newEnrollmentStatusReportData = [
    {
        data: [2000, 1500, ' ', ' ']
    }
];

// All Customers' Invoice Status

//All

var customersInvoiceStatusReportXAxis = [ "Invoice Amount", "Paid in Full invoices", "Partially Paid invoices", "Unpaid invoices"];

var customersInvoiceStatusReportYAxis = {
    min: 0,
    tickInterval: 30000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var customersInvoiceStatusReportData = [
    {
        data: [220000.00, 160000.00, 30000.00, 30000.00]
    }
];

// Individual

var customersInvoiceStatusIndividualReportXAxis = [ "Invoice Amount", "Paid in Full invoices", "Partially Paid invoices", "Unpaid invoices"];

var customersInvoiceStatusIndividualReportYAxis = {
    min: 0,
    tickInterval: 30000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var customersInvoiceStatusIndividualReportData = [
    {
        data: [120000.00, 90000.00, 10000.00, 20000.00]
    }
];

// Group

var customersInvoiceStatusGroupReportXAxis = [ "Invoice Amount", "Paid in Full invoices", "Partially Paid invoices", "Unpaid invoices"];

var customersInvoiceStatusGroupReportYAxis = {
    min: 0,
    tickInterval: 30000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var customersInvoiceStatusGroupReportData = [
    {
        data: [100000.00, 70000.00, 20000.00, 10000.00]
    }
];

// Payments by Entity Type

var paymentsBySourceReportXAxis = [ "Individual", "Group", "CMS", " "];

var paymentsBySourceReportYAxis = {
    min: 0,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var paymentsBySourceReportData = [
    {
        data: [70000.00, 90000.00, 30000.00, ' ']
    }
];

// Remit Report

var remitReportXAxis = [ "Carrier", "Exchange", "Broker/Agent", "Government Boby"];

var remitReportYAxis = {
    min: 0,
    tickInterval: 20000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var remitReportData = [
    {
        data: [150000.00, 25000.00, 15000.00, 30000.00]
    }
];

// Refund Report

// By Count

var refundByCountReportXAxis = [ "Group", "Individual", " ", " "];

var refundByCountReportYAxis = {
    min: 0,
    tickInterval: 10,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value
        }
    }
};

var refundByCountReportData = [
    {
        data: [180, 80, ' ', ' ']
    }
];

// By Amount

var refundByAmountReportXAxis = [ "Group", "Individual", " ", " "];

var refundByAmountReportYAxis = {
    min: 0,
    tickInterval: 5000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var refundByAmountReportData = [
    {
        data: [25000.00, 12000.00, ' ', ' ']
    }
];


// Payment By Methods Report

var paymentByMethodsReportXAxis = [ "ACH", "Credit Card", "EFT", "eCheck"];

var paymentByMethodsReportYAxis = {
    min: 5000,
    tickInterval: 10000,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return '$' + Highcharts.numberFormat(this.value, 2)
        }
    }
};

var paymentByMethodsReportData = [
    {
        data: [80000.00, 60000.00, 40000.00, 10000.00]
    }
];

// Payments Error Report

var paymentsErrorReportXAxis = [ "Credit Card", "EFT", "eCheck"];

var paymentsErrorReportYAxis = {
    min: 0,
    tickInterval: 60,
    lineWidth: 1,
    lineColor: 'black',
    labels: {
        formatter: function () {
            return this.value
        }
    }
};

var paymentsErrorReportData = [
    {
        name: 'No. of Transactions',
        data: [600, 300, 200]
    },
    {
        name: 'Error Transactions',
        data: [100, 40, 10]
    }
];