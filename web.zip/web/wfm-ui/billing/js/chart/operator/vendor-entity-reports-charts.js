drawPieReport('rmhpRevenueByVendorReport', rmhpRevenueByVendorReportPieData);
showSingleReport('rmhpRevenueByVendorReport', rmhpRevenueByVendorReportXAxis, rmhpRevenueByVendorReportYAxis, rmhpRevenueByVendorReportData);


drawPieReport('rmhpRevenueByEntitiesReport', rmhpRevenueByEntitiesReportPieData);
showSingleReport('rmhpRevenueByEntitiesReport', rmhpRevenueByEntitiesReportXAxis, rmhpRevenueByEntitiesReportYAxis, rmhpRevenueByEntitiesReportData);

jQuery(document).ready(function (e) {


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // RMHP Reports

    // Vendor Report
    $('#pieChart1').on('click', function () {
        drawPieReport('rmhpRevenueByVendorReport', rmhpRevenueByVendorReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showSingleReport('rmhpRevenueByVendorReport', rmhpRevenueByVendorReportXAxis, rmhpRevenueByVendorReportYAxis, rmhpRevenueByVendorReportData);

        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Entities Report
    $('#pieChart2').on('click', function () {
        drawPieReport('rmhpRevenueByEntitiesReport', rmhpRevenueByEntitiesReportPieData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart2').on('click', function () {
        showSingleReport('rmhpRevenueByEntitiesReport', rmhpRevenueByEntitiesReportXAxis, rmhpRevenueByEntitiesReportYAxis, rmhpRevenueByEntitiesReportData);
        $('#pieChart2').removeClass('active');
        $(this).addClass('active');
    });


});