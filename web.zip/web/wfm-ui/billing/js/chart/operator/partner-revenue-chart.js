// Partner Revenue
drawPieReport('partnerRevenueInvoiceReport', partnerRevenueInvoiceReportPieData);

drawPieReport('partnerRevenueOutstandingReport', partnerRevenueOutstandingReportPieData);

drawPieReport('partnerRevenuePendingRemitsReport', partnerRevenuePendingRemitsReportPieData);

drawPieReport('partnerRevenueUserFeeReport', partnerRevenueUserFeeReportPieData);

/*showSingleReport('partnerRevenueInvoiceReport', partnerRevenueInvoiceReportXAxis, partnerRevenueInvoiceReportYAxis, partnerRevenueInvoiceReportData);
 showSingleReport('partnerRevenueOutstandingReport', partnerRevenueOutstandingReportXAxis, partnerRevenueOutstandingReportYAxis, partnerRevenueOutstandingReportData);
 showSingleReport('partnerRevenuePendingRemitsReport', partnerRevenuePendingRemitsReportXAxis, partnerRevenuePendingRemitsReportYAxis, partnerRevenuePendingRemitsReportData);
 showSingleReport('partnerRevenueUserFeeReport', partnerRevenueUserFeeReportXAxis, partnerRevenueUserFeeReportYAxis, partnerRevenueUserFeeReportData);*/

jQuery(document).ready(function (e) {

    $(".showItems").hover(
        function () {
            $(this).find(".dropItems").show();
        }, function () {
            $(this).find(".dropItems").hide();
        }
    );


    $(".fromDate,.toDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });

    $(".showItemsDate").click(function () {
        $(this).find(".dropItems").toggle();
    });


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // Reports

    // Invoice Summary Report
    $('#pieChart1').on('click', function () {
        drawPieReport('partnerRevenueInvoiceReport', partnerRevenueInvoiceReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showSingleReport('partnerRevenueInvoiceReport', partnerRevenueInvoiceReportXAxis, partnerRevenueInvoiceReportYAxis, partnerRevenueInvoiceReportData);
        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Online Billing Summary Report
    $('#pieChart2').on('click', function () {
        drawPieReport('partnerRevenueOutstandingReport', partnerRevenueOutstandingReportPieData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart2').on('click', function () {
        showSingleReport('partnerRevenueOutstandingReport', partnerRevenueOutstandingReportXAxis, partnerRevenueOutstandingReportYAxis, partnerRevenueOutstandingReportData);
        $('#pieChart2').removeClass('active');
        $(this).addClass('active');
    });

    // Pending Remits
    $('#pieChart3').on('click', function () {
        drawPieReport('partnerRevenuePendingRemitsReport', partnerRevenuePendingRemitsReportPieData);
        $(this).addClass('active');
        $('#barChart3').removeClass('active');
    });
    $('#barChart3').on('click', function () {
        showSingleReport('partnerRevenuePendingRemitsReport', partnerRevenuePendingRemitsReportXAxis, partnerRevenuePendingRemitsReportYAxis, partnerRevenuePendingRemitsReportData);
        $('#pieChart3').removeClass('active');
        $(this).addClass('active');
    });

    // User Fee
    $('#pieChart4').on('click', function () {
        drawPieReport('partnerRevenueUserFeeReport', partnerRevenueUserFeeReportPieData);
        $(this).addClass('active');
        $('#barChart4').removeClass('active');
    });
    $('#barChart4').on('click', function () {
        showSingleReport('partnerRevenueUserFeeReport', partnerRevenueUserFeeReportXAxis, partnerRevenueUserFeeReportYAxis, partnerRevenueUserFeeReportData);

        $('#pieChart4').removeClass('active');
        $(this).addClass('active');
    });
});