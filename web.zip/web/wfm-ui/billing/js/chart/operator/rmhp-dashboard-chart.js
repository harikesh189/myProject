showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportXAxis, rmhpInvoiceSummaryReportYAxis, rmhpInvoiceSummaryReportData);
drawPieReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportPieData);
showSingleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryReportXAxis, rmhpOnlineBillingSummaryReportYAxis, rmhpOnlineBillingSummaryReportData);
/*drawPieReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryReportPieData,230);*/
showSingleReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportXAxis, rmhpPaymentSummaryReportYAxis, rmhpPaymentSummaryReportData);
drawPieReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportPieData);

showMultipleReport('rmhpMonthlyPaperlessUsersReport', invoicingDetailsReportXAxis, invoicingDetailsReportYAxis, invoicingDetailsReportData);

showLineReport('rmhpMonthlyPaperlessUsersReport', rmhpMonthlyPaperlessUsersReportXAxis, rmhpMonthlyPaperlessUsersReportYAxis, rmhpMonthlyPaperlessUsersReportData);


jQuery(document).ready(function (e) {


    $(".fromDate,.toDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });

    $(".showItemsDate").click(function () {
        $(this).find(".dropItems").toggle();
    });


    jQuery(".chartEx li").click(function () {
        var x = jQuery(this).find("span").attr('class');
        //alert(x);
        jQuery(this).parents(".showItems").find("#SelectCharts span").attr('class', '').addClass(x);
        $(".dropItems").hide();

    });


    // RMHP Reports

    // Invoice Summary Report
    $('#pieChart1').on('click', function () {
        drawPieReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showSingleReport('rmhpInvoiceSummaryReport', rmhpInvoiceSummaryReportXAxis, rmhpInvoiceSummaryReportYAxis, rmhpInvoiceSummaryReportData);

        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Online Billing Summary Report
    $('#pieChart2').on('click', function () {
        drawPieReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryReportPieData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart2').on('click', function () {
        showSingleReport('rmhpOnlineBillingSummaryReport', rmhpOnlineBillingSummaryReportXAxis, rmhpOnlineBillingSummaryReportYAxis, rmhpOnlineBillingSummaryReportData);

        $('#pieChart2').removeClass('active');
        $(this).addClass('active');
    });

    // Online Billing Summary Report
    $('#pieChart3').on('click', function () {
        drawPieReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportPieData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart3').on('click', function () {
        showSingleReport('rmhpPaymentSummaryReport', rmhpPaymentSummaryReportXAxis, rmhpPaymentSummaryReportYAxis, rmhpPaymentSummaryReportData);

        $('#pieChart3').removeClass('active');
        $(this).addClass('active');
    });

    // Monthly Paperless Users Report
    $('#lineChart4').on('click', function () {
        showLineReport('rmhpMonthlyPaperlessUsersReport', rmhpMonthlyPaperlessUsersReportXAxis, rmhpMonthlyPaperlessUsersReportYAxis, rmhpMonthlyPaperlessUsersReportData);
        $(this).addClass('active');
        $('#barChart4').removeClass('active');
    });
    $('#barChart4').on('click', function () {
        showMultipleReport('rmhpMonthlyPaperlessUsersReport', rmhpMonthlyPaperlessUsersReportXAxis, rmhpMonthlyPaperlessUsersReportYAxis, rmhpMonthlyPaperlessUsersReportData);

        $('#lineChart4').removeClass('active');
        $(this).addClass('active');
    });
});	