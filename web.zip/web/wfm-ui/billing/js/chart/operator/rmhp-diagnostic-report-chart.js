drawPieReport('rmhpDianosticPAByProcessorReport', rmhpDianosticPAByProcessorReportPieData);
showSingleReport('rmhpDianosticPAByProcessorReport', rmhpDianosticPAByProcessorReportXAxis, rmhpDianosticPAByProcessorReportYAxis, rmhpDianosticPAByProcessorReportData);

showSingleReport('rmhpDianosticPAByModeReport', rmhpDianosticPAByModeReportXAxis, rmhpDianosticPAByModeReportYAxis, rmhpPaymentSummaryByPMReportData);
drawPieReport('rmhpDianosticPAByModeReport', rmhpDianosticPAByModeReportPieData);


drawPieReport('rmhpDianosticPByCardTypeReport', rmhpDianosticPByCardTypeReportPieData);
showSingleReport('rmhpDianosticPByCardTypeReport', rmhpDianosticPByCardTypeReportXAxis, rmhpDianosticPByCardTypeReportYAxis, rmhpDianosticPByCardTypeReportData);


jQuery(document).ready(function (e) {


    $("#startDate, #endDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        changeMonth: true,
        changeYear: true,
        buttonText: "Calender"
    });
    $('table tr td a.nextData').hover(function () {
        $(this).parents("tr").find($('.nextDataText')).show();
    }, function () {
        $(this).parents("tr").find($('.nextDataText')).hide();
    });


    // RMHP Diaganostic Reports

    // Payment Amount by Payment Processor
    $('#pieChart1').on('click', function () {
        drawPieReport('rmhpDianosticPAByProcessorReport', rmhpDianosticPAByProcessorReportPieData);
        $(this).addClass('active');
        $('#barChart1').removeClass('active');
    });
    $('#barChart1').on('click', function () {
        showSingleReport('rmhpDianosticPAByProcessorReport', rmhpDianosticPAByProcessorReportXAxis, rmhpDianosticPAByProcessorReportYAxis, rmhpDianosticPAByProcessorReportData);
        $('#pieChart1').removeClass('active');
        $(this).addClass('active');
    });

    // Payment Summary by Payment Method
    $('#pieChart2').on('click', function () {
        drawPieReport('rmhpDianosticPAByModeReport', rmhpDianosticPAByModeReportPieData);
        $(this).addClass('active');
        $('#barChart2').removeClass('active');
    });
    $('#barChart2').on('click', function () {
        showSingleReport('rmhpDianosticPAByModeReport', rmhpDianosticPAByModeReportXAxis, rmhpDianosticPAByModeReportYAxis, rmhpDianosticPAByModeReportData);
        $('#pieChart2').removeClass('active');
        $(this).addClass('active');
    });

    // Payment Summary by Payment Source
    $('#pieChart3').on('click', function () {
        drawPieReport('rmhpDianosticPByCardTypeReport', rmhpDianosticPByCardTypeReportPieData);
        $(this).addClass('active');
        $('#barChart3').removeClass('active');
        $("#accType").val('2');
    });
    $('#barChart3').on('click', function () {
        showSingleReport('rmhpDianosticPByCardTypeReport', rmhpDianosticPByCardTypeReportXAxis, rmhpDianosticPByCardTypeReportYAxis, rmhpDianosticPByCardTypeReportData);
        $('#pieChart3').removeClass('active');
        $(this).addClass('active');
        $("#accType").val('2');
    });


    // Account Type
    $('select#accType').change(function () {
        var accType = $(this).val();
        if (accType == '1') {
            showSingleReport('rmhpDianosticPByCardTypeReport', rmhpDianosticPByAccountTypeReportXAxis, rmhpDianosticPByAccountTypeReportYAxis, rmhpDianosticPByAccountTypeReportData);
        } else if (accType == '2') {
            showSingleReport('rmhpDianosticPByCardTypeReport', rmhpDianosticPByCardTypeReportXAxis, rmhpDianosticPByCardTypeReportYAxis, rmhpDianosticPByCardTypeReportData);
            $('#pieChart3').removeClass('active');
            $('#barChart3').addClass('active');
        }
    });
});