SubmittingForm = function () {

    window.location = 'rule-creation-assign-payment.html';

}
$(document).ready(function () {

    $('a.form-submit').click(function (e) {
        e.preventDefault();
        $("#validate-form").submit();
    });


    $("#validate-form").validate({
        onfocusout: function (element) {
            $(element).valid();
        },
        validClass: "success",
        submitHandler: function (form) {
            SubmittingForm();
        },
        rules: {
            ruleParameterOption1: {
                required: true,
                selectcheck: true
            },
            ruleParameterOption2: {
                required: true,
                selectcheck: true
            },
            ruleParameterOption3: {
                required: true,
                selectcheck: true
            },
            ruleParameterOption4: {
                required: true,
                selectcheck: true
            },
            ruleParameterOption5: {
                required: true,
                selectcheck: true
            },
            ruleParameterOption6: {
                required: true,
                selectcheck: true
            }
        }

    });

    $.validator.addMethod('selectcheck', function (value) {
        return (value !== '0');
    }, "Please select an option");
});