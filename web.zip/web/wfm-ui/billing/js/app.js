$(document).ready(function (e) {
    $(document).on('hover', '.rightNav > li:nth-child(1), .rightNav > li:nth-child(3)', function (event) {
        $(".rightNav li:nth-child(2)").find('div').slideUp('fast');
        var hiddenContent = $(this).find('div');
        if (hiddenContent.is(":visible")) {
            hiddenContent.slideUp('fast');
        } else {
            hiddenContent.slideDown();
        }
    });

    $(document).on('click', '.rightNav > li:nth-child(2)', function () {
            var hiddenContent = $(this).find('div');
            if (hiddenContent.is(":visible")) {
                hiddenContent.slideUp('fast');
            }
            else {
                hiddenContent.slideDown();
            }
            e.stopPropagation();
        }
    );
    
    $(document).click(function(){
		$('.showLogout').slideUp();
	});

    $(".show-box").on('click', function () {
            $this = $(this);
            $this.parents('.span6').next().slideDown('2000');
        }
    );

    //for search- start
    $(".universalSearchList").hover(
        function () {
            $(".rightNav li .universalSearch").slideDown("fast");
        }, function () {
            $(".rightNav li .universalSearch").slideUp("fast");
        }
    );
    $(".universalSearch").hover(
        function () {
            $(".universalSearchList").find(".search").addClass("active");
        }, function () {
            $(".universalSearchList").find(".search").removeClass("active");
        }
    );
    $(".universalSearchInput").focus(function () {
        $(this).parents(".universalSearchList").find(".search").addClass("active");
    });
    $(".universalSearchInput").blur(function () {
        $(this).parents(".universalSearchList").find(".search").removeClass("active");
    });

    $(".removeTopTools").prev(".row-fluid").addClass("sdfdsf");


//============Customer==============
    $('body').on('click', '.closeSection', function () {
        $('.expandButton').removeClass('closeSection');
        $('.expandButton').addClass('openSection');
        $(".customerBrief").animate({"margin-left": "-210px"});
        $(".rightSection").animate({"margin-left": "10px"}, "slow");

    });
    $('body').on('click', '.openSection', function () {
        $('.expandButton').addClass('closeSection');
        $('.expandButton').removeClass('openSection');
        $(".customerBrief").animate({"margin-left": "0"}, "slow");
        $(".rightSection").animate({"margin-left": "220px"}, "slow");

    });
    var customerBriefHeight = $('.contentArea').innerHeight();
    customerBriefHeight = customerBriefHeight + 10;
    $('.customerBrief').css('height', customerBriefHeight);


    var leftNavigationHeight = $('.leftNav').height();
    var rightBoxHeight = $('.well').height();
    if (leftNavigationHeight > rightBoxHeight) {
        $('.well > .contentInner > .whiteBox').css('min-height', leftNavigationHeight - 153);
    }
    //leftNavigationHeight = leftNavigationHeight -154;
    //$('.well').css('min-height',leftNavigationHeight + 300);


    $("#addEmail").click(function () {
        if ($(this).prop('checked') == true) {
            $('.addEmail').slideDown();
        }
        if ($(this).prop('checked') == false) {
            $('.addEmail').slideUp();
        }

    })

    $("#save_card1").click(function () {
        if ($(this).prop('checked') == true) {
            $('#save_card_mesg1').show();
        }
        if ($(this).prop('checked') == false) {
            $('#save_card_mesg1').hide();
        }

    });
    $("#save_card2").click(function () {
        if ($(this).prop('checked') == true) {
            $('#save_card_mesg2').show();
        }
        if ($(this).prop('checked') == false) {
            $('#save_card_mesg2').hide();
        }
    });


    $(".showItems").hover(
        function () {
            $(this).find(".dropItems").show();
        }, function () {
            $(this).find(".dropItems").hide();
        }
    );


    $('select#userType').change(function () {
        var userType = $(this).val();
        if (userType == '1') {
            $('.forIndividual').show();
            $('.forGroup').show();
            $('.forBroker').show();
            $('#userTypeTitle').html('All');
            $('#activeBillUsers').html('10');
            $('#noOfLogin').html('59');
            $('#totalTimeSpend').html('22:55:00');
            $('#avgTimeSpend').html('00:23:18');
            $('#exportCsv').attr('href', '../docs/ebill-usage-report-all.csv');
            $('#exportXls').attr('href', '../docs/ebill-usage-report-all.xls');
        }
        if (userType == '2') {
            $('.forIndividual').show();
            $('.forGroup').hide();
            $('.forBroker').hide();
            $('#userTypeTitle').html('Individual');
            $('#activeBillUsers').html('05');
            $('#noOfLogin').html('26');
            $('#totalTimeSpend').html('10:30:00');
            $('#avgTimeSpend').html('00:24:14');
            $('#exportCsv').attr('href', '../docs/ebill-usage-report-individual.csv');
            $('#exportXls').attr('href', '../docs/ebill-usage-report-individual.xls');
        }
        if (userType == '3') {
            $('.forIndividual').hide();
            $('.forGroup').show();
            $('.forBroker').hide();
            $('#userTypeTitle').html('Group');
            $('#activeBillUsers').html('03');
            $('#noOfLogin').html('17');
            $('#totalTimeSpend').html('07:55:00');
            $('#avgTimeSpend').html('00:27:56');
            $('#exportCsv').attr('href', '../docs/ebill-usage-report-group.csv');
            $('#exportXls').attr('href', '../docs/ebill-usage-report-group.xls');
        }
        if (userType == '4') {
            $('.forIndividual').hide();
            $('.forGroup').hide();
            $('.forBroker').show();
            $('#userTypeTitle').html('Broker');
            $('#activeBillUsers').html('02');
            $('#noOfLogin').html('24');
            $('#totalTimeSpend').html('04:30:00');
            $('#avgTimeSpend').html('00:16:52');
            $('#exportCsv').attr('href', '../docs/ebill-usage-report-broker.csv');
            $('#exportXls').attr('href', '../docs/ebill-usage-report-broker.xls');
        }
    });


    $('#notificationTbl  input[type=checkbox]').change(function () {
        $('.toSave').show();
    });

    $('.toSave').bind({
        click: function () {
            $.msgBox({
                title: "Update",
                content: "Are you sure you want to update the record?",
                type: "confirm",
                buttons: [
                    { value: "Update" },
                    { value: "Cancel"}
                ],
                success: function (result) {
                    if (result == "Update") {
                        //$( this ).parents("form").find(".control-group label input").toggleClass( "disable" );
                        $('.toSave').hide();
                    } else if (result == "Cancel") {
                        $('.checkbox input').prop('disabled', false);
                        $(this).parents("form").find(".control-group label input").toggleClass("disable");
                        $('.toSave').hide();
                    }
                }
            });
        },
    });


    $('.saveBtn').bind({
        change: function () {
            $.msgBox({
                title: "Update",
                content: "Do you want to save the changes?",
                type: "confirm",
                buttons: [
                    { value: "Save" },
                    { value: "Cancel"}
                ],
                success: function (result) {
                    if (result == "Save") {
                    } else if (result == "Cancel") {
                    }
                }
            });
        },
    });


//

    $("input[name='chooseCard']").bind('click', function () {
        if ($("input[name='chooseCard']:checked").val() == 'newCard') {
            $('.cardBox').slideDown();
        } else if ($("input[name='chooseCard']:checked").val() == 'card1') {
            $('.cardBox').slideUp();

        } else if ($("input[name='chooseCard']:checked").val() == 'card2') {
            $('.cardBox').slideUp();

        }
    });

    $("input[name='chooseAccount']").bind('click', function () {
        if ($("input[name='chooseAccount']:checked").val() == 'newAccount') {
            $('.accountBox').slideDown();
        } else if ($("input[name='chooseAccount']:checked").val() == 'account1') {
            $('.accountBox').slideUp();
        } else if ($("input[name='chooseAccount']:checked").val() == 'account2') {
            $('.accountBox').slideUp();
        }
    });


    $('.js-editCard').on('click', function () {
        $this = $(this);
        $this.parent().slideUp(500);
        $this.parent().next().slideDown(1000);
    });
    $('.js-showInfo').on('click', function () {
        $this = $(this);
        $this.parents('.editAccountPremission').slideUp(500);
        $this.parent().parent().prev().slideDown(1000);
    });


    /*=====================Collopse Div=========================*/
    $('.expandButton').removeClass('openSection');
    $('.expandButton').addClass('closeSection');
    $(".customerBrief").css({"margin-left": "0px"});
    $(".rightSection").css({"margin-left": "220px"});


    /*=============Table Sorting Pagination*/
    $('.table').footable();
    $('.footable').data('page-size', 10);
    $('.footable').trigger('footable_initialized');


    /*======================Popup Box=================*/

    $("#popup-broker-profile").dialog({
        autoOpen: false,
        width: '600',
        title: 'Account Details',
        modal: true,
        position: ['center', 150]
    });
    $('.js-viewac-ind').click(function () {
        $('#popup-broker-profile').dialog('open');
        return false;
    });
    $(".closePopUp").click(function () {
        $("#popup-broker-profile").dialog('close');
    });


    $("#popup-template-view").dialog({
        autoOpen: false,
        width: '750',
        title: 'Invalid Credit Card Details',
        modal: true,
        position: ['center', 150]
    })
    $('.js-tmplView').click(function () {
        $('#popup-template-view').dialog('open');
        return false;
    });


    $('.js-payment-online-popup').click(function () {
        $("#popup-online-payment-confirmation").dialog({
            width: 600,
            title: 'Online Payment Confirmation ',
            modal: true
        });
    });

    $('.js-popup-ind-billing-history').click(function () {
        $("#popup-ind-billing-history").dialog({
            width: 600,
            title: 'Online Payment Confirmation ',
            modal: true
        });
    });

    $('.js-popup-billing-history-shannon').click(function () {
        $("#popupBox-shannon1").dialog({
            width: 600,
            title: 'Online Payment Confirmation ',
            modal: true
        });
    });

    $('.js-popup-billing-history-shannon2').click(function () {
        $("#popupBox-shannon2").dialog({
            width: 600,
            title: 'Online Payment Failed! ',
            modal: true
        });
    });


    $('.js-add-entiry').click(function () {
        $('#popup-entity-create').dialog('open');
        return false;
    });

    $("#popup-entity-create").dialog({
        autoOpen: false,
        title: 'New Entity',
        width: '960',
        modal: true,
        position: ['center', 150]
    });

    $("#popupView").dialog({
        autoOpen: false,
        title: 'View Entity',
        width: '800',
        modal: true,
        position: ['center', 150]
    });
    $("#popupEdit").dialog({
        autoOpen: false,
        title: 'Edit Entity',
        width: '950',
        modal: true,
        position: ['center', 150]
    });

    $("#popupAddPayment").dialog({
        autoOpen: false,
        title: 'Add a New Payment',
        width: '700',
        modal: true,
        position: ['center', 150]
    });
    $("#popupAddPaymentRemit").dialog({
        autoOpen: false,
        title: 'Add Remit',
        width: '700',
        modal: true,
        position: ['center', 150]
    });
    $("#popupEditPayment").dialog({
        autoOpen: false,
        title: 'Edit Payment',
        width: '700',
        modal: true,
        position: ['center', 150]
    });


    $("#popupViews-2").dialog({
        autoOpen: false,
        title: 'View Entity',
        width: '800',
        modal: true,
        position: ['center', 150]
    });
    $(".closePopUp").click(function () {
        $("#popupViews-2").dialog('close');
    })

    $('.js-icon-views-2').click(function () {
        $('#popupViews-2').dialog('open');
        $('#popupEdits-2').dialog('close');
        return false;
    });

    $("#popupEdits-2").dialog({
        autoOpen: false,
        title: 'View Entity',
        width: '950',
        modal: true,
        position: ['center', 150]
    });
    $(".closePopUp").click(function () {
        $("#popupEdits-2").dialog('close');
    })

    $('.js-icon-edits-2').click(function () {
        $('#popupEdits-2').dialog('open');
        $('#popupViews-2').dialog('close');
        return false;
    });


    $('.js-icon-view').click(function () {
        $('#popupView').dialog('open');
        $('#popupEdit').dialog('close');
        return false;
    });
    $('.js-icon-edit').click(function () {
        $('#popupEdit').dialog('open');
        $('#popupView').dialog('close');
        return false;
    });
    $('.js-icon-addPayment').click(function () {
        $('#popupAddPayment').dialog('open');
        return false;
    });
    $('.js-icon-addPaymentRemit').click(function () {
        $('#popupAddPaymentRemit').dialog('open');
        return false;
    });
    $('.js-icon-editPayment').click(function () {
        $('#popupEditPayment').dialog('open');
        return false;
    });

    $(".closePopUp").click(function () {
        $(".popupBox").dialog('close');
    })


    $("#popup-view-rule-configration").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });

    $('.js-replace1').click(function () {
        $('#popup-view-rule-configration').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup-view-rule-configration").dialog('close');
    });

    $("#popup2").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace2').click(function () {
        $('#popup2').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup2").dialog('close');
    });

    $("#popup3").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace3').click(function () {
        $('#popup3').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup3").dialog('close');
    });

    $("#popup4").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace4').click(function () {
        $('#popup4').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup4").dialog('close');
    });

    $("#popup5").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace5').click(function () {
        $('#popup5').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup5").dialog('close');
    });

    $("#popup6").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace6').click(function () {
        $('#popup6').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup6").dialog('close');
    });

    $("#popup7").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace7').click(function () {
        $('#popup7').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup7").dialog('close');
    });


    $("#popup8").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace8').click(function () {
        $('#popup8').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup8").dialog('close');
    });


    $("#popup9").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace9').click(function () {
        $('#popup9').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup9").dialog('close');
    });

    $("#popup10").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace10').click(function () {
        $('#popup10').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup10").dialog('close');
    });
    $("#popup11").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });
    $('.js-replace11').click(function () {
        $('#popup11').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup11").dialog('close');
    });


    $("#popup-rule-created, #popup2-rule,  #popup3-rule, #popup4-rule, #popup5-rule, #popup6-rule, #popup7-rule, #popup8-rule, #popup9-rule, #popup10-rule, #popup11-rule").dialog({
        autoOpen: false,
        width: '600',
        title: 'Rule Configuration',
        modal: true,
        position: ['center', 150]
    });

    $('.js-replace1').click(function () {
        $('#popup-rule-created').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup-rule-created").dialog('close');
    });


    $('.js-replace2').click(function () {
        $('#popup2-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup2-rule").dialog('close');
    });


    $('.js-replace3').click(function () {
        $('#popup3-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup3-rule").dialog('close');
    });


    $('.js-replace4').click(function () {
        $('#popup4-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup4-rule").dialog('close');
    });


    $('.js-replace5').click(function () {
        $('#popup5-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup5-rule").dialog('close');
    });


    $('.js-replace6').click(function () {
        $('#popup6-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup6-rule").dialog('close');
    });


    $('.js-replace7').click(function () {
        $('#popup7-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup7-rule").dialog('close');
    });


    $('.js-replace8').click(function () {
        $('#popup8-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup8-rule").dialog('close');
    });


    $('.js-replace9').click(function () {
        $('#popup9-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup9-rule").dialog('close');
    });


    $('.js-replace10').click(function () {
        $('#popup10-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup10-rule").dialog('close');
    });

    $('.js-replace11').click(function () {
        $('#popup11-rule').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popup11-rule").dialog('close');
    });


    $('.js-details').click(function () {
        $('#popupView').dialog('open');
        return false;
    });
    $(".closePopUp-rule").click(function () {
        $("#popupView").dialog('close');
    });


    $("#popup-health-plan").dialog({
        autoOpen: false,
        width: '600',
        height: 'auto',
        title: 'Quick Pay',
        modal: true,
        autoReposition: true,
        show: {
            effect: "fade",
            duration: 800
        },
        hide: {
            effect: "fade",
            duration: 00
        },
        position: {
            my: "center",
            at: "center",
            of: window
        }
    });

    $('.js-quickpay').click(function () {
        $('#popup-health-plan').dialog('open');
        $("#sec2").hide();
        return false;
    });
    $(".js-submitPay").click(function () {
        $("#sec1").hide();
        $("#sec2").show();
    });
    $(".closePopUp-health").click(function () {
        $("#popup-health-plan").dialog('close');
    });


    /*=========Arun==========*/

    $('.js-add-make-payment').click(function () {
        $('#popup-add-make-payment').dialog('open');
        return false;
    });

    $("#popup-add-make-payment").dialog({
        autoOpen: false,
        title: 'Record Payment',
        width: '600',
        modal: true,
        position: ['center', 150]
    });


    $('.js-write-off-payment').click(function () {
        $('#popup-write-off-payment').dialog('open');
        return false;
    });

    $("#popup-write-off-payment").dialog({
        autoOpen: false,
        title: 'Write off',
        width: '600',
        modal: true,
        position: ['center', 150]
    });

    $('.js-add-liability').click(function () {
        $('#popup-add-liability').dialog('open');
        return false;
    });

    $("#popup-add-liability").dialog({
        autoOpen: false,
        title: 'Billing Item',
        width: '600',


        modal: true,
        position: ['center', 150]
    });

    $('.js-History-Run').click(function () {
        $('#popup-History-Run').dialog('open');
        return false;
    });

    $("#popup-History-Run").dialog({
        autoOpen: false,
        title: 'History of Execution',
        width: '600',
        modal: true,
        position: ['center', 150]
    });

    $('.js-Associated-Entity').click(function () {
        $('#popup-Associated-Entity').dialog('open');
        return false;
    });

    $("#popup-Associated-Entity").dialog({
        autoOpen: false,
        title: 'Associated Entity',
        width: '600',
        modal: true,
        position: ['center', 150]
    });

    $('.js-remittance').click(function () {
        $('#popup-remittance').dialog('open');
        return false;
    });

    $("#popup-remittance").dialog({
        autoOpen: false,
        title: 'Remittance',
        width: '600',
        modal: true,
        position: ['center', 150]
    });


//================Accordion==============

    $('.acc_container').hide(); //Hide/close all containers
    //$('.acc_trigger:first').addClass('active').next().show();

    //On Click

    $(document).on('click', '.delinquencyBox .invoiceSummaryBox > .acc_trigger', function (event) {

        if ($(this).next().is(':hidden')) {
           // $('.acc_trigger').removeClass('active').next().slideUp();
           // $(this).toggleClass('active').next().slideDown();
        	$(this).closest('.invoiceSummaryBox  .acc_trigger').next('.invoiceSummaryBox  .acc_container').toggle()
            $(this).toggleClass('active').next().slideDown();
        }
        else if ($(this).hasClass("active")) {
            //$('.acc_trigger').removeClass('active').next().slideUp();
        	$(this).closest('.invoiceSummaryBox  .acc_trigger').next('.invoiceSummaryBox  .acc_container').toggle()
       	 	$(this).toggleClass('active').next().slideUp();
        }
        return false;
    });
    
    $(document).on('click', '.operatorInvoice .invoiceSummaryBox .acc_trigger', function (event) {
        if ($(this).next().is(':hidden')) {
           //$('.acc_trigger').removeClass('active').next().slideUp();
           // $(this).toggleClass('active').next().slideDown();
        	//$(this).next().toggle()
            $(this).addClass('active').next().slideDown();
        }
        else if ($(this).hasClass("active")) {
            //$('.acc_trigger').removeClass('active').next().slideUp();
        	//$(this).next().toggle()
       	 	$(this).removeClass('active').next().slideUp();
       	 	
        }
        //return false;
    });
    
    


    //$('.openAccordion .acc_container').show(); //Hide/close all containers
    //$('.openAccordion .acc_trigger').removeClass('active');
    
    
    
    $('.invoiceSummaryBox .coverage-period-subs-list .acc_container').hide();
    $(document).on('click', '.invoiceSummaryBox .coverage-period-subs-list h2', function (event) {
    	//$('.coverage-period-subs-list .acc_container').hide();
    	//$('.coverage-period-subs-list h2').removeClass('active');
    	//$(this).addClass('active').next().slideDown();
    	
    	if ($(this).next().is(':hidden')) {
            $('.invoiceSummaryBox .coverage-period-subs-list h2').removeClass('active').next().slideUp();
            $(this).addClass('active').next().slideDown();
        	//$(this).closest('.acc_trigger').next('.acc_container').toggle()
            //$(this).toggleClass('active').next().slideDown();
        }
        else if ($(this).hasClass("active")) {
            $('.invoiceSummaryBox .coverage-period-subs-list h2').removeClass('active').next().slideUp();
        	//$(this).closest('.acc_trigger').next('.acc_container').toggle()
       	 	$(this).removeClass('active').next().slideUp();
        }
    	
    });
    
    

    //On Click
    $(document).on('click', '.openAccordion .acc_trigger', function (event) {
        if ($(this).next('.acc_container').is(':visible')) {
            //alert(1);
            //$('.acc_trigger').removeClass('active').next().slideUp();
            $(this).toggleClass('active').next().slideUp();
        }
        else if ($(this).hasClass("active")) {
            //alert(2);
            $(this).toggleClass('active').next().slideDown();
        }
        return false;
    });


    // Show next radio button checkbox
    $(".invoiceSummaryBox input:radio[class=nextShow]").on('click', function () {

        if ($(this).val() == 'yes') {
            $(this).closest(".innerValue").next().slideDown();
        }
        else {
            $(this).closest(".innerValue").next().slideUp();
        }
    });

    $('.invoiceSummaryBox .btn-secondary').on('click', function () {
        $('.acc_trigger').removeClass('active').next().slideUp();
        $(".acc_container").slideUp();

    })

    // Show payment method
    $(".popupstyle input:radio[name=payMethod]").on('click', function () {
        if ($(this).val() == 'Check' || $(this).val() == 'Money Order') {
            $(this).parents(".rowMargin").next(".identification-number").slideDown();
        }
        else {
            $(this).parents(".rowMargin").next(".identification-number").slideUp();
        }
    });
    
    
 
   

    //============Date Picker===============

    $("#createdFrom, .createdFrom").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        onClose: function (selectedDate) {
            $("#createdTill, .createdTill").datepicker("option", "minDate", selectedDate);
            var fromDateVal = $("#createdFrom, .createdFrom").val();
            $("#createdFrom, .createdFrom").attr('value', fromDateVal);

        }
    });


    $("#createdTill, .createdTill").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        onClose: function (selectedDate) {
            $("#createdFrom, .createdFrom").datepicker("option", "maxDate", selectedDate);
            var toDateVal = $("#createdTill, .createdTill").val();
            $("#createdTill, .createdTill").attr('value', toDateVal);

        }
    });

    $("#effectiveDate, .effectiveDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        onClose: function (selectedDate) {
            $("#termDate").datepicker("option", "minDate", selectedDate);
            var fromDateVal = $("#effectiveDate").val();
            $("#effectiveDate").attr('value', fromDateVal);

        }
    });


    $("#termDate, .termDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        onClose: function (selectedDate) {
            $("#effectiveDate").datepicker("option", "maxDate", selectedDate);
            var toDateVal = $("#termDate").val();
            $("#termDate").attr('value', toDateVal);


        }
    });

    $("#effectiveDate, #termDate, #dob").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
    });

    $("#paymentDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
    });
    $('input[name = paymentOptions]').click(function () {

        if (this.value == 'paperchk') {
            $('.paperCheck').show();
            $('.cardpay').hide();
        }

        if (this.value == 'cash') {
            $(this).attr('checked', true);
            $('.paperCheck').hide();
            $('.cardpay').show();
        }

    });
//===================Manage permission================

    $(".manage-permission > table  input[type=checkbox]").change(function () {
        $(this).closest('tr').toggleClass("selectedRow", this.checked);
        var delRows = $(".selectedRow").length;
        if (delRows > 0) {
            jQuery(".js-removeRow").removeClass("halfOpacity");
            jQuery(".js-removeRow").addClass("rmv");
        } else {
            jQuery(".js-removeRow").addClass("halfOpacity");
            jQuery(".js-removeRow").removeClass("rmv");
        }
    });

    $(document).on('click', '.halfOpacity', function (event) {
        alert("Please select user(s) to delete the record(s)");
    });

    $(document).on('click', '.rmv', function (event) {
        //alert("This will remove the selected notification");
        $.msgBox({
            title: "Remove",
            content: "Are you sure you want to remove the selected record(s)?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $(".selectedRow").hide();
                    jQuery(".js-removeRow").addClass("halfOpacity");
                    jQuery(".js-removeRow").removeClass("rmv");
                } else if (result == "Cancel") {
                    //do nothing
                }
            }
        });
    });


    $('.removeCard1').on('click', function () {
        $.msgBox({
            title: "Remove Card",
            content: "Are you sure you want to remove this Card?",
            type: "confirm",
            buttons: [
                { value: "Cancel" },
                { value: "Yes"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $(".cardOne").hide();
                } else if (result == "Cancel") {
                    //do nothing
                }
            }
        });
    });
    $('.removeCard2').on('click', function () {
        $.msgBox({
            title: "Remove Card",
            content: "Are you sure you want to remove this Card?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $(".cardTwo").hide();
                } else if (result == "Cancel") {
                    //do nothing
                }
            }
        });
    });

    $(document).on('click', '.removeAccount1', function (event) {
        //alert("This will remove the selected notification");
        $.msgBox({
            title: "Remove Account",
            content: "Are you sure you want to remove this Account?",
            type: "confirm",
            buttons: [
                { value: "Cancel" },
                { value: "Yes"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $(".accountOne").hide();
                } else if (result == "Cancel") {
                    //do nothing
                }
            }
        });
    });

    $(document).on('click', '.removeAccount2', function (event) {
        //alert("This will remove the selected notification");
        $.msgBox({
            title: "Remove Account",
            content: "Are you sure you want to remove this Account?",

            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $(".accountTwo").hide();
                } else if (result == "Cancel") {
                    //do nothing
                }
            }
        });
    });

    $("#startsOn,#endsOn").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });


//==============Other===============

    $("#userGname").change(function () {
        if (this.value != "select") {
            $("#groupIdIs").slideDown();
        }
        if (this.value != "select") {
            $(".jsAttrOptAdmin").slideDown();
        } else {
            $(".jsAttrOptAdmin").slideUp();
        }
    });

    /*
     $('table.tableNotification tr td .delRow').hide();
     $('table.tableNotification tr').bind({
     mouseenter: function() {
     $(this).find(".delRow").show();
     },
     mouseleave: function() {
     $(this).find(".delRow").hide();
     }
     });
     */


    /*================Message Page=============*/
    $('select#recipientType').change(function () {
        var recipientType = $(this).val();
        if (recipientType == '1') {
            $('.individual').show();
            $('.group').show();
        }
        if (recipientType == '2') {
            $('.individual').show();
            $('.group').hide();
        }
        if (recipientType == '3') {
            $('.individual').hide();
            $('.group').show();
        }
    });

    $('.js-composeMessage').click(function (e) {
        $(".composeMessageBox").show();
    });
    $('.closeMsgBox,.sendMsgBtn').click(function (e) {
        $(".composeMessageBox").hide();
    });

    $.fn.extend({
        limiter: function (limit, elem) {
            $(this).on("keyup focus", function () {
                setCount(this, elem);
            });
            function setCount(src, elem) {
                var chars = src.value.length;
                if (chars > limit) {
                    src.value = src.value.substr(0, limit);
                    chars = limit;
                }
                elem.html(limit - chars);
            }

            setCount($(this)[0], elem);
        }
    });


    $('.messageTest').on('keyup focus', function () {
        var elem = $("#chars");
        $("#message").limiter(120, elem);
    })


    $('#paymentTbl > tbody > tr.dataRow1').after('<tr class="dataRow1Data" style="display:none;"><td colspan="8"><table class="table innerTable"><tr><td>Bank Name</td><td>American Express</td></tr><tr><td>Bank Account Number</td><td>963258753214582</td></tr><tr><td>Account Holder Name</td><td>CMS MN</td></tr><tr><td>ABA Routing Number</td><td>20145</td></tr><tr><td>Bank Account Type</td><td>Current Account</td></tr></table></td></tr>');

    $('#paymentTbl > tbody > tr.dataRow1 td a.slide-plus').click(function () {
        $(".dataRow1Data").toggle();
        $(this).toggleClass("slide-minus");
    });


    /* Formating function for row details */
    $('tr.dataRow1-health').after('<tr class="dataRow1Data-health " style="display:none;"><td colspan="6"><table class="table innerTable" style="width: 90%; margin: 0 5%"><tr><th>Group Id</th><th>Group Name</th><th class="text-right">Premium Due</th><th class="text-right">Premium Collected</th><th class="text-right">Amount Balanced</th></tr><tr><td>GRP01234567</td><td>Tom\'s Bait and Tackle</td><td class="text-right">$3,343.75</td><td class="text-right">$3,343.75</td><td class="text-right">$0.00</td></tr><tr><td>GRP01234571</td><td>Rudd &amp; Company Pllc</td><td class="text-right">$2,000.00</td><td class="text-right">$1,800.00</td><td class="text-right">$200.00</td></tr><tr><td>GRP01234572</td><td>Milestone Law Firm</td><td class="text-right">$3,200.00</td><td class="text-right">$3,100.00</td><td class="text-right">$100.00</td></tr></table></td></tr>');


    $('tr.dataRow2-health').after('<tr class="dataRow2Data-health " style="display:none;"><td colspan="6"><table class="table innerTable"  style="width: 90%; margin: 0 5%"><tr><th>Group Id</th><th>Group Name</th><th class="text-right">Premium Due</th><th class="text-right">Premium Collected</th><th class="text-right">Amount Balanced</th></tr><tr><td>GRP01234567</td><td>Tom\'s Bait and Tackle</td><td class="text-right">$2,000.00</td><td class="text-right">$2,000.00</td><td class="text-right">$0.00</td></tr><tr><td>GRP01234572</td><td>Milestone Law Firm</td><td class="text-right">1,000.00</td><td class="text-right">1,000.00</td><td class="text-right">$0.00</td></tr></table></td></tr>');


    $('.dataRow1-health a.slide-plus').click(function () {
        $(this).toggleClass("slide-minus");
        $(".dataRow1Data-health").toggle();
    });


    $('.dataRow2-health a.slide-plus').click(function () {
        $(".dataRow2Data-health").toggle();
        $(this).toggleClass("slide-minus");
    });

    $(".dataRow1Data-health, .dataRow2Data-health").hide();


    $('.js-delete-card').on('click', function () {
        $(this).parents('.boxCard').hide();
    });

    $("#timeFrame1").change(function () {

        var timeFrameValue = $('#timeFrame1').val();
        if (timeFrameValue == 'manualSetting') {
            $('.manualTimeFilter.itemDate1').show();//('showItemsDate');
        } else {
            $('.manualTimeFilter.itemDate1').hide();//('showItemsDate');
        }

    });
    $("#timeFrame2").change(function () {

        var timeFrameValue = $('#timeFrame2').val();
        if (timeFrameValue == 'manualSetting') {
            $('.manualTimeFilter.itemDate2').show();//('showItemsDate');
        } else {
            $('.manualTimeFilter.itemDate2').hide();//('showItemsDate');
        }

    });

    $(".fromDate,.toDate").datepicker({
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender"
    });

    $(".showItemsDate > a").click(function () {

        if ($(this).closest('.showItemsDate').find(".dropItems").is(':visible')) {
            $(this).closest('.showItemsDate').find(".dropItems").slideUp();
        }
        else {
            $(this).closest('.showItemsDate').find(".dropItems").slideDown();
        }
    });

    $(".js-apply").click(function () {
        $(this).closest('.dropItems').slideUp();
    });


    $("#broker-group-popup").dialog({
        autoOpen: false,
        width: '600',
        title: 'Account Details',
        modal: true,
        position: ['center', 150]
    });
    $('.js-viewac-group').click(function () {
        $('#broker-group-popup').dialog('open');
        return false;
    });


    $("#broker-individual-popup").dialog({
        autoOpen: false,
        width: '600',
        title: 'Account Details',
        modal: true,
        position: ['center', 150]
    });
    $('.js-broker-viewac-ind').click(function () {
        $('#broker-individual-popup').dialog('open');
        return false;
    });

    $("#broker-search-client-popup").dialog({
        autoOpen: false,
        width: '600',
        title: 'Account Details',
        modal: true,
        position: ['center', 150]
    });
    $('.js-broker-search-client').click(function () {
        $('#broker-search-client-popup').dialog('open');
        return false;
    });


    $('select.fromVal').change(function () { // when one changes
        $('.useVal').text($(this).val()) // they all change
    })

    $("#addRuleArea").dialog({
        title: 'Add Notification',
        autoOpen: false,
        width: '850',
        modal: true
    });
    $('.js-addRule').click(function () {
        $('#addRuleArea').dialog('open');
        return false;
    });
    $("#EditRuleArea").dialog({
        title: 'Edit Notification',
        autoOpen: false,
        width: '850',
        modal: true
    });
    $('.js-editRule').click(function () {
        $('#EditRuleArea').dialog('open');
        return false;
    });


    $(document).on('click', '.cardDelete', function (event) {
        //alert("This will remove the selected notification");
        $.msgBox({
            title: "Save Card",
            content: "Are you sure you want to remove this saved card permanently?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $('#selectCard').hide();
                } else if (result == "Cancel") {
                    //do nothing
                }
            }
        });
    });

    $(document).on('click', '.accountDelete', function (event) {
        //alert("This will remove the selected notification");
        $.msgBox({
            title: "Remove Account",
            content: "Are you sure you want to remove saved Bank Account permanently?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $('#bankAccount').hide();
                } else if (result == "Cancel") {
                    //do nothing
                }
            }
        });
    });


    $('.js-show-list').on('click', function () {
        $(this).next().toggle();
    });

    var checkClick = 0;
    $('.js-all').on('click', function () {
        $this = $(this);
        chblength = $this.parents('.search-list').find('input[type=checkbox]').length;
        if (checkClick == 0) {
            checkClick++;
            $('.browse').html('All');
            $this.parents('.search-list').find('input[type=checkbox]').prop("checked", true);
        } else {
            $('.browse').html('Select');
            $this.parents('.search-list').find('input[type=checkbox]').prop("checked", false);
            checkClick = 0;
        }
    });

    $('.js-carrier-type').on('click', function () {
        $this = $(this);
        var totalCheckbox = $this.parents('.search-list').find('input[type=checkbox]').length;
        var lenCheckbox = $this.parents('.search-list').find('input[type=checkbox]:checked').length;
        var labelValue = $this.parent().text();
        if (lenCheckbox == 1) {
            $('.browse').html(labelValue);
        }
        else if (lenCheckbox > 1 && lenCheckbox != totalCheckbox) {
            $('.browse').html('Multiple');
        }
        else if (lenCheckbox == totalCheckbox) {
            $('.browse').html('All');
        }
        else {
            $('.browse').html('Select');
        }
    });

});

$("#entityDetails").dialog({
    title: 'Billing Cycle - Entities',
    autoOpen: false,
    width: '650',
    modal: true
});
$('.js-icon-details').click(function () {
    $("#entityDetails").dialog('open');
    return false;
});


$('.agingOnOff div').on('click', function () {
    $(this).toggleClass("activeOn");
    if (!$(this).hasClass("activeOn")) {
        $('.agingreport').hide();
        $('.nonagingreport').show();

    } else {
        $('.unpaidTd').show();
        $('.paidTd').hide();

        $('.nonagingreport').hide();
        $('.agingreport').show();
    }
});

$('.agingOnOff').hide();
$('.unpaidTd').show();
$('.paidTd').show();
$('#cStatus').change(function () {
    var cStatus_value = $(this).val();
    if (cStatus_value == "unpaid") {
        $('.agingOnOff').show();
        $('.unpaidTd').show();
        $('.paidTd').hide();
        $('.paidTd').hide();
        $('.icon-on-ff').removeClass("activeOn");
    }
    else if (cStatus_value == "paid") {
        $('.agingOnOff').hide();
        $('.unpaidTd').hide();
        $('.paidTd').show();
        $('.agingreport').hide();
        $('.nonagingreport').show();


    } else {
        $('.agingOnOff').hide();
        $('.unpaidTd, .paidTd').show();
    }

});

$(document).on('click','.advance-filter > a', function () {
    $(this).next().toggleClass('advance-filter-data');
});

$(document).on('click','.filterCancel, .filterSubmit', function () {
    $('.filter-option').toggleClass('advance-filter-data');
});

$(document).on('mouseleave','.advance-filter-data > a', function () {
	$('.filter-option').toggleClass('advance-filter-data');
});

$(document).on('mouseleave','.dropItems', function () {
	if($('#ui-datepicker-div').css('display')=='none'){
		$('.showInvoiceSummaryItemsDate').find('.dropItems').slideUp();
	}
	
});

$('.dropArrow').on('click', function () {
    $(this).toggleClass('dropArrow-active');
    $('.more-option').toggleClass('openMoreOption');
});

$('.cancel, .moreOptionsSave').on('click', function () {
    $('.more-option').removeClass('openMoreOption');
    $('.dropArrow').toggleClass('dropArrow-active');
    $('.filter-option').removeClass('advance-filter-data');
});


// If an event gets to the body
$("body").click(function () {
    //$('.more-option').removeClass('openMoreOption');	
    //$('.dropArrow').toggleClass('dropArrow-active');
});

// Prevent events from getting pass .popup
$(".more-option, .dropArrow").click(function (e) {
    e.stopPropagation();
});

$('.uploadButton').on('click', function () {
    $('.upload-option').toggleClass('openUploadOption');
    $(this).toggleClass('uploadButton-active');

});
$('.cancel, .uploadOptionsSave').on('click', function () {
    $('.upload-option').removeClass('openUploadOption');
    $('.uploadButton').removeClass('uploadButton-active');
});



$(document).on('click', '.invoiceDetailsBtn', function (event) {	
	var desT = $(this).attr('rel');
	//alert(desT);
     $('html, body').animate({
           'scrollTop':   $('#' + desT).offset().top
         }, 2000);
   $('.invoiceDetailsBtn').removeClass('active');
	
	
    $(this).addClass('active');
    $('.acc_trigger').removeClass('active');
    $('.acc_container').slideUp();
   // $('.acc_container').eq().slideDown();
    $('#' + desT).addClass('active').next('.acc_container').slideDown();;
});





$("#broker-account-detail").dialog({
    autoOpen: false,
    width: '600',
    title: 'Account Details',
    modal: true,
    position: ['center', 150]
});
$('.js-viewac-group').click(function () {
    $('#broker-account-detail').dialog('open');
    return false;
});


$('.js-newInvoice').click(function () {
    $("#popup-invoice-details").dialog({
        width: 700,
        title: 'Upload New Invoice',
        modal: true
    });

});

$('.js-replaceInvoice').click(function () {
    $("#popup-replace-invoice").dialog({
        width: 700,
        title: 'Replace Invoice',
        modal: true
    });
});

$('.cancel, #submit').on('click', function () {
    $("#popup-invoice-details").dialog('close');
});

$('.cancel1, #submit1').on('click', function () {
    $("#popup-replace-invoice").dialog('close');
});


//Tooltips
/*$('.viewDetails, .enrollment, .replaceInvoice, .deleteInvoice, .edit, .individual-info, .viewProfile, .toolTip').tipsy({gravity: 'w', });

$('.toolTip1').tipsy({gravity: 'e'});
$('.toolTipDelete').tipsy({gravity: 'n'});
*/

/*======================Message Box====================*/

$(".js-saveIt").click(function () {
    $.msgBox({
        title: "Recurring Setup Confirmation",
        content: "Once your agreement has been set up, payments will automatically be collected according to the type of agreement. The agreement may be set up to take an immediate or a delayed payment.",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "Submit"}
        ],
        success: function (result) {
            if (result == "Submit") {
                window.location = "group";
            } else if (result == "Cancel") {
                window.location = "auto-recurring-confirm";
            }
        }
    });
});

$(".js-saveItCC").click(function () {
    //$('.show-authorizationForm').slideDown();
    //$(this).parents(".control-group").hide();
    $.msgBox({
        title: "Recurring Setup Confirmation",
        content: "Once your agreement has been set up, payments will automatically be collected according to the type of agreement. The agreement may be set up to take an immediate or a delayed payment.",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "Submit"}
        ],
        success: function (result) {
            if (result == "Submit") {
                window.location = "group";
            } else if (result == "Cancel") {
                window.location = "auto-recurring-confirmCC";
            }
        }
    });
});

$(".js-saveIt-individual").click(function () {
    $.msgBox({
        title: "Recurring Setup Confirmation",
        content: "Once your agreement has been set up, payments will automatically be collected according to the type of agreement. The agreement may be set up to take an immediate or a delayed payment.",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "Submit"}
        ],
        success: function (result) {
            if (result == "Submit") {
                window.location = "index";
            } else if (result == "Cancel") {
                window.location = "ind-auto-recurring-confirm";
            }
        }
    });
});

$(".js-saveIt-entity").click(function () {
    $.msgBox({
        title: "Recurring Setup Confirmation",
        content: "Once your agreement has been set up, payments will automatically be collected according to the type of agreement. The agreement may be set up to take an immediate or a delayed payment.",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "Submit"}
        ],
        success: function (result) {
            if (result == "Submit") {
                window.location = "index";
            } else if (result == "Cancel") {
                window.location = "entity-auto-recurring-confirm";
            }
        }
    });
});

$(".js-saveIt-group").click(function () {
    $.msgBox({
        title: "Recurring Setup Confirmation",
        content: "Once your agreement has been set up, payments will automatically be collected according to the type of agreement. The agreement may be set up to take an immediate or a delayed payment.",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "Submit"}
        ],
        success: function (result) {
            if (result == "Submit") {
                window.location = "index";
            } else if (result == "Cancel") {
                window.location = "auto-recurring-confirm";
            }
        }
    });
});

$(function () {
    $('table#entityTbl tr td .icon-delete').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Remove Entity",
                content: "Are you sure you want to remove this selected entity?",
                type: "confirm",
                buttons: [
                    { value: "Cancel" },
                    { value: "Yes"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        },
    });


    $('table.invoiceTable tr td .icon-delete').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Delete Invoice",
                content: "Are you sure you want to delete this Invoice?",
                type: "confirm",
                buttons: [
                    { value: "Yes" },
                    { value: "No"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        },
        mouseenter: function () {
            $(this).attr('src', '../images/delRowIcnClk.png');
        },
        mouseleave: function () {
            $(this).attr('src', '../images/delRowIcn.png');
        }
    });

    $('table.templateTable tr td .icon-delete').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Delete Invoice",
                content: "Are you sure you want to delete this Invoice?",
                type: "confirm",
                buttons: [
                    { value: "Yes" },
                    { value: "No"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        },
        mouseenter: function () {
            $(this).attr('src', '../images/delRowIcnClk.png');
        },
        mouseleave: function () {
            $(this).attr('src', '../images/delRowIcn.png');
        }
    });

    $('table.paymentTbl tr td .icon-delete').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Delete Payment",
                content: "Are you sure you want to delete this Payment?",
                type: "confirm",
                buttons: [
                    { value: "Yes" },
                    { value: "No"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        },
        mouseenter: function () {
            $(this).attr('src', '../images/delRowIcnClk.png');
        },
        mouseleave: function () {
            $(this).attr('src', '../images/delRowIcn.png');
        }
    });

    $('table.tableNotification tr td .delRow').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Delete Notification",
                content: "Are you sure you want to remove the selected notification?",
                type: "confirm",
                buttons: [
                    { value: "Yes" },
                    { value: "Cancel"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        }
    });


    $('.js-deleteInvoice').bind({
        click: function () {
            //alert("This will remove the selected notification");
            $(this).parents("tr").addClass("currentRow");
            $.msgBox({
                title: "Delete Invoice",
                content: "Are you sure you want to delete this Invoice?",
                type: "confirm",
                buttons: [
                    { value: "Yes" },
                    { value: "No"}
                ],
                success: function (result) {
                    if (result == "Yes") {
                        $("tr.currentRow").hide();
                    } else if (result == "Cancel") {
                        $("tr.currentRow").removeClass("currentRow");
                    }
                }
            });
        },
        mouseenter: function () {
            $(this).attr('src', '../images/delRowIcnClk.png');
        },
        mouseleave: function () {
            $(this).attr('src', '../images/delRowIcn.png');
        }
    });


})
/*=======================Tabs============================*/
$(".tabs").tabs();
$('.nxtTab').click(function () {
    $('.nxtTab').click();
});
$('.nxtTabE').click(function () {
    $('.nxtTabE').click();
});
$('.nxtTabEx').click(function () {
    $('.nxtTabEx').click();
});

/*======================Validation=============*/
SubmittingFormETF = function () {
    window.location = 'auto-recurring-confirm';
}


$("#setPaymentOption").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormETF();
    },
    rules: {
        acNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15

        },
        acHolderName: {
            required: true
        },
        acHolderLastName: {
            required: true
        },
        RouNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 10, // will count space 
            maxlength: 10
        }, account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16

        },
        name_on_card: {
            required: true
        },
        cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        },
        inner_cvv_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 4, // will count space 
            maxlength: 4
        },
        inner_account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16
        },
        inner_account_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15
        },
        inner_name_on_card: {
            required: true
        },
        inner_cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        }
    },
    messages: {
        acHolderName: {
            required: "Please enter account holder's first name"
        },
        acHolderLastName: {
            required: "Please enter account holder's last name"
        },
        acNum: {
            required: "Please enter the account number"
        },
        RouNum: {
            required: "Please enter Routing Number"
        },
        account_no: {
            required: "Please enter the card number"
        },
        name_on_card: {
            required: "Please enter the name as appears on card"
        },
        cvv_no: {
            required: "Please enter CVV"
        },
        inner_account_no: {
            required: "Please enter the card number"
        },
        inner_account_no_amex: {
            required: "Please enter the card number"
        },
        inner_name_on_card: {
            required: "Please enter the name as appears on card"
        },
        inner_cvv_no: {
            required: "Please enter CVV"
        },
        inner_cvv_no_amex: {
            required: "Please enter CVV"
        }
    }

});


$('.notice').hide();
$("input[name='paymentOptions']").bind('click', function () {
    if ($("input[name='paymentOptions']:checked").val() == 'card') {
        $.msgBox({
            title: "Pay less using EFT",
            content: "Using EFT makes you eligible for a discount of 5% on your total payment. Would you still like to change your payment method ?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $('.js-cardBox').show();
                    $('.js-eftbox').hide();
                    $('.notice').hide();
                    $('#buttons').hide();
                    $('.js-jumpTo').attr('href', 'auto-recurring-confirmCC');

                } else if (result == "Cancel") {
                    $("#eft").prop("checked", true)
                    $('.js-jumpTo').attr('href', 'auto-recurring-confirm');
                }
            }
        });


    } else if ($("input[name='paymentOptions']:checked").val() == 'echeck') {
        $('.js-cardBox').hide();
        $('.js-eftbox').hide();
        $('.notice').show();
        //alert("We are working on Echeck payment option. Please try other payment option for now.");
    } else if ($("input[name='paymentOptions']:checked").val() == 'eft') {
        $('.js-cardBox').hide();
        $('.js-eftbox').show();
        $('.notice').hide();
        $('#buttons').hide();
        $('.js-jumpTo').attr('href', 'auto-recurring-confirm');
    }

});
$("input[name='cardOption']").bind('click', function () {
    if ($("input[name='cardOption']:checked").val() == 'visacard') {
        $('#master').hide();
        $('#amex').hide();
        $('#discover').hide();
        $('#card').show();


    } else if ($("input[name='cardOption']:checked").val() == 'mastercard') {
        $('#card').hide();
        $('#amex').hide();
        $('#discover').hide();
        $('#master').show();
    }

    else if ($("input[name='cardOption']:checked").val() == 'amexcard') {
        $('#master').hide();
        $('#card').hide();
        $('#discover').hide();
        $('#amex').show();
    }

    else if ($("input[name='cardOption']:checked").val() == 'discovercard') {
        $('#master').hide();
        $('#card').hide();
        $('#amex').hide();
        $('#discover').show();
    }


});
$.validator.addMethod('selectcheck', function (value) {
    return (value !== 'select');
}, "Please select an option");


$(function () {

    SubmittingFormETF1 = function () {
        window.location = 'ind-auto-recurring-eft';
    }

    SubmittingFormETF2 = function () {
        window.location = 'payment-ind-summary';
    }

    SubmittingFormETF3 = function () {
        window.location = 'ind-auto-recurring-CC';
    }

    SubmittingFormETF4 = function () {
        window.location = 'entity-auto-recurring-eft';
    }

    SubmittingFormETFGroup = function () {
        window.location = 'payment-summary';
    }

    SubmittingForm = function () {
        //alert("The form has been validated.");
        var paymentAmount = $('#paymentAmount').val();
        if (paymentAmount > 0) {
            window.location = 'payments';
        }
    }

    SubmittingFormRule1 = function () {
        //alert("The form has been validated.");
        var ruleTypeValue = $('#ruleType').val();
        if (ruleTypeValue == 'Payment') {
            window.location = 'rule-creation-conditions-payment';
        } else if (ruleTypeValue == 'Payout') {
            window.location = 'rule-creation-conditions-payout';
        }
    }


    SubmittingFormCSRPaymentOption = function () {
        window.location = 'payment-ind-summary';
    }


    SubmittingFormMakeaPayment = function () {
        window.location = 'make-payment-summary';
    }


});
// Validate for 2 decimal for money
jQuery.validator.addMethod("money", function (value, element) {
    return this.optional(element) || /^(\d{1,8})$/.test(value) || /^(\d{1,8})(\.\d{1,2})$/.test(value) || /^(\d{1,8})(\.\d{1,1})$/.test(value) || /^(\d{1,8})(\.\d{0,1})$/.test(value) || /^(\.\d{0,2})$/.test(value) || /^(\.\d{0,1})$/.test(value);
}, "Please enter the amount in correct format: xxx.xx");


$("#payment-individual").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormETF1();
    },
    rules: {
        acHolderName: {
            required: true,
            selectcheck: true
        },
        accountType: {
            required: true,
            selectcheck: true
        },
        acNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15

        },
        RouNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 10, // will count space 
            maxlength: 10
        }, account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16

        },
        name_on_card: {
            required: true
        },
        cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        },
        inner_cvv_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 4, // will count space 
            maxlength: 4
        },
        inner_account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16
        },
        inner_account_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15
        },
        inner_name_on_card: {
            required: true
        },
        inner_cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        }
    },
    messages: {

        acNum: {
            required: "Please enter the account number"
        },
        RouNum: {
            required: "Please enter Routing Number"
        },
        account_no: {
            required: "Please enter the card number"
        },
        name_on_card: {
            required: "Please enter the name as appears on card"
        },
        cvv_no: {
            required: "Please enter CVV"
        },
        inner_account_no: {
            required: "Please enter the card number"
        },
        inner_account_no_amex: {
            required: "Please enter the card number"
        },
        inner_name_on_card: {
            required: "Please enter the name as appears on card"
        },
        inner_cvv_no: {
            required: "Please enter CVV"
        },
        inner_cvv_no_amex: {
            required: "Please enter CVV"
        }
    }

});


$("#entity-payment-individual").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormETF4();
    },
    rules: {
        acHolderName: {
            required: true,
            selectcheck: true
        },
        accountType: {
            required: true,
            selectcheck: true
        },
        acNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15

        },
        RouNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 10, // will count space 
            maxlength: 10
        }, account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16

        },
        name_on_card: {
            required: true
        },
        cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        },
        inner_cvv_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 4, // will count space 
            maxlength: 4
        },
        inner_account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16
        },
        inner_account_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15
        },
        inner_name_on_card: {
            required: true
        },
        inner_cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        }
    },
    messages: {

        acNum: {
            required: "Please enter the account number"
        },
        RouNum: {
            required: "Please enter Routing Number"
        },
        account_no: {
            required: "Please enter the card number"
        },
        name_on_card: {
            required: "Please enter the name as appears on card"
        },
        cvv_no: {
            required: "Please enter CVV"
        },
        inner_account_no: {
            required: "Please enter the card number"
        },
        inner_account_no_amex: {
            required: "Please enter the card number"
        },
        inner_name_on_card: {
            required: "Please enter the name as appears on card"
        },
        inner_cvv_no: {
            required: "Please enter CVV"
        },
        inner_cvv_no_amex: {
            required: "Please enter CVV"
        }
    }

});


$("input[name='paymentOptions-individual']").bind('click', function () {
    if ($("input[name='paymentOptions-individual']:checked").val() == 'card') {
        $.msgBox({
            title: "Pay less using EFT",
            content: "Using EFT makes you eligible for a discount of 5% on your total payment. Would you still like to change your payment method ?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $('.js-cardBox').show();
                    $('.js-eftbox').hide();
                    $('.notice').hide();
                    $('#buttons').hide();
                    // $("#cardType").prop("checked", true)	
                    $('.js-jumpTo').attr('href', 'ind-auto-recurring-CC');
                } else if (result == "Cancel") {
                    $("#eft").prop("checked", true)
                    $('.js-jumpTo').attr('href', 'ind-auto-recurring-eft');
                }
            }
        });
    } else if ($("input[name='paymentOptions-individual']:checked").val() == 'echeck') {
        $('.js-cardBox').hide();
        $('.js-eftbox').hide();
        $('.notice').show();
        //alert("We are working on Echeck payment option. Please try other payment option for now.");
    } else if ($("input[name='paymentOptions-individual']:checked").val() == 'eft') {
        $('.js-cardBox').hide();
        $('.js-eftbox').show();
        $('.notice').hide();
        $('#buttons').hide();
        // $('#jumptoPay').attr('href','paymentsummary-eft');
    }

});


//eft2	


jQuery.validator.addMethod("money", function (value, element) {
    return this.optional(element) || /^(\d{1,8})$/.test(value) || /^(\d{1,8})(\.\d{1,2})$/.test(value) || /^(\d{1,8})(\.\d{1,1})$/.test(value) || /^(\d{1,8})(\.\d{0,1})$/.test(value) || /^(\.\d{0,2})$/.test(value) || /^(\.\d{0,1})$/.test(value);
}, "Please enter the amount in correct format: xxx.xx");


$("#payment-ind-option").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormETF2();
    },
    rules: {

        acNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15

        },
        acHolderName: {
            required: true
        },
        acHolderLastName: {
            required: true
        },
        RouNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 10, // will count space 
            maxlength: 10
        }, account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16

        },
        name_on_card: {
            required: true
        },
        cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        },
        inner_cvv_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 4, // will count space 
            maxlength: 4
        },
        inner_account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16
        },
        inner_account_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15
        },
        inner_name_on_card: {
            required: true
        },
        inner_cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        }
    },
    messages: {
        acHolderName: {
            required: "Please enter account holder's first name"
        },
        acHolderLastName: {
            required: "Please enter account holder's last name"
        },
        acNum: {
            required: "Please enter the account number"
        },
        RouNum: {
            required: "Please enter Routing Number"
        },
        account_no: {
            required: "Please enter the card number"
        },
        name_on_card: {
            required: "Please enter the name as appears on card"
        },
        cvv_no: {
            required: "Please enter CVV"
        },
        inner_account_no: {
            required: "Please enter the card number"
        },
        inner_account_no_amex: {
            required: "Please enter the card number"
        },
        inner_name_on_card: {
            required: "Please enter the name as appears on card"
        },
        inner_cvv_no: {
            required: "Please enter CVV"
        },
        inner_cvv_no_amex: {
            required: "Please enter CVV"
        }
    }

});


$("input[name='paymentOptions-ind-option']").bind('click', function () {
    if ($("input[name='paymentOptions-ind-option']:checked").val() == 'card') {
        $.msgBox({
            title: "Pay less using EFT",
            content: "Using EFT makes you eligible for a discount of 5% on your total payment. Would you still like to change your payment method ?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $('.js-cardBox').show();
                    $('.js-eftbox').hide();
                    $('.notice').hide();
                    $('#buttons').hide();
                    $('.js-jumpTo').attr('href', 'payment-ind-summaryCC');
                } else if (result == "Cancel") {
                    $("#eft").prop("checked", true)
                    //do nothing
                }
            }
        });


    } else if ($("input[name='paymentOptions-ind-option']:checked").val() == 'echeck') {
        $('.js-cardBox').hide();
        $('.js-eftbox').hide();
        $('.notice').show();
        //alert("We are working on Echeck payment option. Please try other payment option for now.");
    } else if ($("input[name='paymentOptions-ind-option']:checked").val() == 'eft') {
        $('.js-cardBox').hide();
        $('.js-eftbox').show();
        $('.notice').hide();
        $('#buttons').hide();
        // $('#jumptoPay').attr('href','paymentsummary-eft');
    }

});


$('a.form-submit-payment').click(function (e) {
    e.preventDefault();
    $("#validate-form-payment").submit();
});
$("#validate-form-payment").validate({
    onfocusout: function (element) {
        $(element).valid();
        Number.prototype.format = function () {
            return this.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1");
        };
        var price = document.getElementById('paymentAmount').value;
        //var j =100.00;
        price = parseInt(price);
        $("#paymentAmount").val(price.format());
        //alert(price.format());
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingForm();
    },
    rules: {
        policyNumber: {
            required: true
        },
        paymentAmount: {
            required: true,
            check_b: true
            // money:true
        },
        type: {
            required: true,
            selectcheck: true
        }
    },
    messages: {

        paymentAmount: {
            required: "Please enter the amount"
        }
    }

});
$.validator.addMethod("check_b", function (value, element, param) {
    var val_a = $("#paymentAmount").val();
    return this.optional(element) || (val_a > 0);
}, "Minimum payable amount is : $0.00");

$.validator.addMethod('selectcheck', function (value) {
    return (value !== 'select');
}, "Select an option");


$('a.form-submit-rule-creation1').click(function (e) {
    e.preventDefault();
    $("#validate-form-rule1").submit();
});

$("#validate-form-rule1").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormRule1();
    },
    rules: {
        ruleFor: {
            required: true,
            selectcheck: true
        },
        ruleType: {
            required: true,
            selectcheck: true
        }
    }

});

$.validator.addMethod('selectcheck', function (value) {
    return (value !== 'select');
}, "Please select an option");


$("#payment-set-option").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormCSRPaymentOption();
    },
    rules: {
        bankName: {
            required: true,
            selectcheck: true
        },
        accountType: {
            required: true,
            selectcheck: true
        },
        acNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15

        },
        RouNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 10, // will count space 
            maxlength: 10
        }, account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16

        },
        name_on_card: {
            required: true
        },
        cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        },
        inner_cvv_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 4, // will count space 
            maxlength: 4
        },
        inner_account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16
        },
        inner_account_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15
        },
        inner_name_on_card: {
            required: true
        },
        inner_cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        }
    },
    messages: {

        acNum: {
            required: "Please enter the account number"
        },
        RouNum: {
            required: "Please enter Routing Number"
        },
        account_no: {
            required: "Please enter the card number"
        },
        name_on_card: {
            required: "Please enter the name as appears on card"
        },
        cvv_no: {
            required: "Please enter CVV"
        },
        inner_account_no: {
            required: "Please enter the card number"
        },
        inner_account_no_amex: {
            required: "Please enter the card number"
        },
        inner_name_on_card: {
            required: "Please enter the name as appears on card"
        },
        inner_cvv_no: {
            required: "Please enter CVV"
        },
        inner_cvv_no_amex: {
            required: "Please enter CVV"
        }
    }

});

//==========Group================

$("#payment").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormETFGroup();
    },
    rules: {
        bankName: {
            required: true,
            selectcheck: true
        },
        accountType: {
            required: true,
            selectcheck: true
        },
        acNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15

        },
        RouNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 10, // will count space 
            maxlength: 10
        }, account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16

        },
        name_on_card: {
            required: true
        },
        cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        },
        inner_cvv_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 4, // will count space 
            maxlength: 4
        },
        inner_account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16
        },
        inner_account_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15
        },
        inner_name_on_card: {
            required: true
        },
        inner_cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        }
    },
    messages: {

        acNum: {
            required: "Please enter the account number"
        },
        RouNum: {
            required: "Please enter Routing Number"
        },
        account_no: {
            required: "Please enter the card number"
        },
        name_on_card: {
            required: "Please enter the name as appears on card"
        },
        cvv_no: {
            required: "Please enter CVV"
        },
        inner_account_no: {
            required: "Please enter the card number"
        },
        inner_account_no_amex: {
            required: "Please enter the card number"
        },
        inner_name_on_card: {
            required: "Please enter the name as appears on card"
        },
        inner_cvv_no: {
            required: "Please enter CVV"
        },
        inner_cvv_no_amex: {
            required: "Please enter CVV"
        }
    }

});


$("input[name='paymentOptions-group-option']").bind('click', function () {
    if ($("input[name='paymentOptions-group-option']:checked").val() == 'card') {
        $.msgBox({
            title: "Pay less using EFT",
            content: "Using EFT makes you eligible for a discount of 5% on your total payment. Would you still like to change your payment method ?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $('.js-cardBox').show();
                    $('.js-eftbox').hide();
                    $('.notice').hide();
                    $('#buttons').hide();
                    $('#buttons').hide();
                    $('.js-jumpto').attr('href', 'payment-summaryCC');
                } else if (result == "Cancel") {
                    $("#eft").prop("checked", true)
                    $('.js-jumpto').attr('href', 'payment-summary');
                }
            }
        });


    } else if ($("input[name='paymentOptions-group-option']:checked").val() == 'echeck') {
        $('.js-cardBox').hide();
        $('.js-eftbox').hide();
        $('.notice').show();
        //alert("We are working on Echeck payment option. Please try other payment option for now.");
    } else if ($("input[name='paymentOptions-group-option']:checked").val() == 'eft') {
        $('.js-cardBox').hide();
        $('.js-eftbox').show();
        $('.notice').hide();
        $('#buttons').hide();
        // $('#jumptoPay').attr('href','paymentsummary-eft');
    }

});


$('#preference-broker tr td .icon-delete').bind({
    click: function () {
        //alert("This will remove the selected notification");
        $(this).parents("tr").addClass("currentRow");
        $.msgBox({
            title: "Delete",
            content: "Are you sure you want to remove the record?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $("tr.currentRow").hide();
                } else if (result == "Cancel") {
                    $("tr.currentRow").removeClass("currentRow");
                }
            }
        });
    },
});


$("#payment-set-payment-option").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingFormMakeaPayment();
    },
    rules: {
        bankName: {
            required: true,
            selectcheck: true
        },
        accountType: {
            required: true,
            selectcheck: true
        },
        acNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15

        },
        RouNum: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 10, // will count space 
            maxlength: 10
        }, account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16

        },
        name_on_card: {
            required: true
        },
        cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        },
        inner_cvv_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 4, // will count space 
            maxlength: 4
        },
        inner_account_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 16, // will count space 
            maxlength: 16
        },
        inner_account_no_amex: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 15, // will count space 
            maxlength: 15
        },
        inner_name_on_card: {
            required: true
        },
        inner_cvv_no: {
            required: true,
            //digits: true,
            number: true, // as space is not a number it will return an error
            minlength: 3, // will count space 
            maxlength: 3
        }
    },
    messages: {

        acNum: {
            required: "Please enter the account number"
        },
        RouNum: {
            required: "Please enter Routing Number"
        },
        account_no: {
            required: "Please enter the card number"
        },
        name_on_card: {
            required: "Please enter the name as appears on card"
        },
        cvv_no: {
            required: "Please enter CVV"
        },
        inner_account_no: {
            required: "Please enter the card number"
        },
        inner_account_no_amex: {
            required: "Please enter the card number"
        },
        inner_name_on_card: {
            required: "Please enter the name as appears on card"
        },
        inner_cvv_no: {
            required: "Please enter CVV"
        },
        inner_cvv_no_amex: {
            required: "Please enter CVV"
        }
    }

});


/*====================Change password===================*/
SubmittingFormChangePassword = function () {
    window.location = 'my-profile-info';
}

$(function () {

    $("#changePassword").validate({
        onfocusout: function (element) {
            $(element).valid();
        },
        validClass: "success",
        submitHandler: function (form) {
            SubmittingFormChangePassword();
        },
        rules: {
            current_password: {
                required: true,
                //passwordCheck: true
                pass: true

            },
            new_password: {
                required: true,
                minlength: 8,
                pass: true
            },
            confirm_new_password: {
                required: true,
                minlength: 8,
                equalTo: "#new_password"
            }
        },
        messages: {

            current_password: {
                required: "Please enter your current password"
            },
            new_password: {
                required: "Please enter new password"
            },
            confirm_new_password: {
                required: "Please confirm the password"
            }
        }

    });
    // Validate password for speacial character
    jQuery.validator.addMethod("pass", function (value, element) {
        return this.optional(element) || /[^\w\s]/.test(value);
    }, "Password should have atleast one speacial character.");


    $("#popupChangePassword").dialog({
        title: 'Change Password',
        autoOpen: false,
        width: '500',
        modal: true
    });
    $('.js-popup-change-password').click(function () {
        $('#popupChangePassword').dialog('open');
        return false;
    });

})

function checkValidatebroker() {

    var username = $('#username').val();
    var password = $('#password').val();
    if (username == "" && password == "") {
        alert("Pleas Enter the Username and Password");
        return false;
    }
    if (username == "broker" && password == "broker") {
        window.location = 'index';
        return false;
    }
    else {
        alert('Please check your username and password');
    }
    return true;
}


function checkValidateCSR() {

    var username = $('#username').val();
    var password = $('#password').val();
    if (username == "" && password == "") {
        alert("Pleas Enter the Username and Password");
        return false;
    }
    if (username == "csr" && password == "csr") {
        window.location = 'index';
        return false;
    }
    else {
        alert('Please check your username and password');
    }
    return true;
}


// Payment Method pages


function copy_address_option_Eft(check_value) {
    if (check_value == true) {
        document.getElementById('Add1_Eft').value = "2775 Crossroads Boulevard";
        document.getElementById('Add2_Eft').value = "5th Avenue";
        document.getElementById('city_Eft').value = "Grand Junction";
        document.getElementById('state_Eft').value = "CO";
        document.getElementById('county_Eft').value = "US";
        document.getElementById('zip_Eft').value = "10600";
    }
    else {
        document.getElementById('Add1_Eft').value = '';
        document.getElementById('Add2_Eft').value = '';
        document.getElementById('city_Eft').value = '';
        document.getElementById('state_Eft').value = '';
        document.getElementById('county_Eft').value = '';
        document.getElementById('zip_Eft').value = '';
    }
}


// Entity Popup Box
$('.entityTypeList').hide();
$('#operatorEntity.entityTypeList').show();
$('#entityTypeList').change(function () {
    var entityType = $('#entityTypeList').val();
    $('.entityTypeList').hide();
    $('#' + entityType).show();

});


$('#dueDays').hide();
$('#billCycleDueDate').change(function () {
    var billCycleDueDate = $('#billCycleDueDate').val();
    if (billCycleDueDate == 1 || billCycleDueDate == 4) {
        $('#dueDays').hide();
    } else if (billCycleDueDate == 0 || billCycleDueDate == 2 || billCycleDueDate == 3 || billCycleDueDate == 5 || billCycleDueDate == 6) {
        $('#dueDays').show();
    }
});

// ind-auto-recurring-eft.html

$(".option1 input, .option1 select").prop('disabled', true);
$(".option2 input, .option2 select").prop('disabled', true);

$("input[name='paydate']").bind('click', function () {
    if ($("input[name='paydate']:checked").val() == 'option1') {
        $(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', true);
        $(".option1 input, .option1 select").prop('disabled', false);
        $("img.ui-datepicker-trigger").hide();
    } else if ($("input[name='paydate']:checked").val() == 'option2') {
        $(".option1 input, .option1 select").prop('disabled', true);
        $(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', false);
        $("img.ui-datepicker-trigger").show();
    }
    else if ($("input[name='paydate']:checked").val() == 'option3') {
        $(".option1 input, .option1 select").prop('disabled', true);
        $(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', true);
        $("img.ui-datepicker-trigger").hide();
    }

});


// For Validation

SubmittingForm = function () {

    window.location = 'auto-recurring-4';
}
$("#setPayment").validate({
    onfocusout: function (element) {
        $(element).valid();
    },
    validClass: "success",
    submitHandler: function (form) {
        SubmittingForm();
    },
    rules: {
        from: {
            required: true,
        },
        endDate: {
            required: true,
        }
    },
    messages: {

        from: {
            required: "Please select the date"
        },
        endDate: {
            required: "Please select the date"
        }
    }

});

$("#from, #endDate, .js-currentDate").datepicker({
    showOn: "both",
    buttonImage: "../images/calender.png",
    buttonImageOnly: true,
    buttonText: "Calender",
});


// Popup for Billing Rule Configure

$("#popupViews-3").dialog({
    autoOpen: false,
    title: 'View Entity',
    width: '800',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-views-3').click(function () {
    $('#popupViews-3').dialog('open');
    $('#popupEdits-3').dialog('close');
    return false;
});

$("#popupEdits-3").dialog({
    autoOpen: false,
    title: 'Edit Entity',
    width: '950',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-edits-3').click(function () {
    $('#popupEdits-3').dialog('open');
    $('#popupViews-3').dialog('close');
    return false;
});

$("#popupViewBillCycleConfig").dialog({
    autoOpen: false,
    title: 'Billing Cycle Configuration',
    width: '700',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-BillCycleConf').click(function () {
    $('#popupViewBillCycleConfig').dialog('open');
    return false;
});


$('#billCycleConfigEdit').hide();
$('.js-BillCycleConfigEdit').click(function () {
    $('#billCycleConfigEdit').show();
    $('#billCycleConfigView').hide();
});
$('.js-BillCycleConfigSave').click(function () {
    $('#billCycleConfigView').show();
    $('#billCycleConfigEdit').hide();
});
$('#daysOfMonth').hide();
$('#daysOfBiWeek').hide();
$('#billCycleFrequency').change(function () {
    var cycleValue = $('#billCycleFrequency').val();
    if (cycleValue == 'weekly') {
        $('#daysOfWeek').show();
        $('#daysOfMonth').hide();
        $('#daysOfBiWeek').hide();
    }
    else if (cycleValue == 'biWeekly') {
        $('#daysOfBiWeek').show();

        $('#daysOfWeek').hide();
        $('#daysOfMonth').hide();
    } else if (cycleValue == 'monthly') {
        $('#daysOfMonth').show();
        $('#daysOfWeek').hide();

        $('#daysOfBiWeek').hide();
    }
});

// Billing Config Run

$("#popupViewBillCycleConfigRun").dialog({
    autoOpen: false,
    title: 'Billing Cycles',
    width: '700',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-BillCycleConfRun').click(function () {
    $('#popupViewBillCycleConfigRun').dialog('open');
    return false;
});

// transactions-payment.html


$("input[name='PaymentType']").bind('click', function () {
    if ($("input[name='PaymentType']:checked").val() == 'Incoming') {
        $('.ccPayMethod').show();
        $('.achPayMthod').show();
        $('.sndTo').hide();
        $('.recFrom').show();

    } else if ($("input[name='PaymentType']:checked").val() == 'Outgoing') {
        $('.ccPayMethod').hide();
        $('.achPayMthod').hide();
        $('.sndTo').show();
        $('.recFrom').hide();

    }
});
$("input[name='editPaymentType']").bind('click', function () {
    if ($("input[name='editPaymentType']:checked").val() == 'Incoming') {
        $('.ccPayMethodEdit').show();
        $('.achPayMethodEdit').show();

    } else if ($("input[name='editPaymentType']:checked").val() == 'Outgoing') {
        $('.ccPayMethodEdit').hide();
        $('.achPayMethodEdit').hide();

    }
});


$("#setPaymentAutoRecurringEFT img.ui-datepicker-trigger, #RecuPaymentSchedule img.ui-datepicker-trigger, #setPayment img.ui-datepicker-trigger, #payment-individual img.ui-datepicker-trigger").hide();

/*===========Payment Methods=======*/


$(".showInfo input[type='checkbox']").change(function () {
    $(".showInfo").find("input[type='checkbox']").not(this).prop("checked", false);
    $(this).prop("checked", true);
    $.msgBox({
        title: "Are You Sure?",
        content: "You want to change your Preferred Payment Method ?",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "Yes"}
        ],
        success: function (result) {
            if (result == "Yes") {
                ;
            } else if (result == "Cancel") {
                $(".showInfo").find("input[type='checkbox']").not(this).prop("checked", false);
            }
        }
    });
});

$("#popupViewBillCycleConfig1").dialog({
    autoOpen: false,
    title: 'Edit Template',
    width: '700',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-BillCycleConf1').click(function () {
    $('#popupViewBillCycleConfig1').dialog('open');
    return false;
});


$('select#userType').change(function () {
    var userType = $('select#userType').val();


    if (userType == '1') {
        $('.tollFree1').fadeIn("slow");
        $('.tollFree2').hide();
        $('.tollFree3').hide();
        $('.tollFree4').hide();


    } else if (userType == '2') {
        $('.tollFree1').hide();
        $('.tollFree2').fadeIn("slow");
        $('.tollFree3').hide();
        $('.tollFree4').hide();

    } else if (userType == '3') {
        $('.tollFree1').hide();
        $('.tollFree2').hide();
        $('.tollFree3').fadeIn("slow");
        $('.tollFree4').hide();
    } else if (userType == '4') {
        $('.tollFree1').hide();
        $('.tollFree2').hide();
        $('.tollFree3').hide();
        $('.tollFree4').fadeIn("slow");
    }


});


$('#typeofUser').change(function () {
    if ($(this).val() == "Individual" || $(this).val() == "Group") {
        $(".indgrpBox").slideDown();
        $(".operatorBox").hide();
        $(".brokerBox").hide();

    } else if ($(this).val() == "Operator") {

        $(".operatorBox").slideDown();
        $(".indgrpBox").hide();
        $(".brokerBox").hide();
        //$('.operatorBox .acc_trigger:first').addClass('active').next().show();
    }
    else if ($(this).val() == "Broker") {
        $(".brokerBox").slideDown();
        $(".indgrpBox").hide();
        $(".operatorBox").hide();
        //$('.brokerBox .acc_trigger:first').addClass('active').next().show();
    }
    else if ($(this).val() == "select") {
        $(".brokerBox").hide();
        $(".indgrpBox").hide();
        $(".operatorBox").hide();
    }
});
$('#notificationTbl  input[type=checkbox]').change(function () {
    if ($(this).is(':checked')) {
        $(this).closest("td").next("td").find("select").removeAttr("disabled");
        //$(this).closest("td").next("td").find("a").removeClass("hide");

    } else {
        $(this).closest("td").next("td").find("select").attr("disabled", "disabled");
        //$(this).closest("td").next("td").find("a").addClass("hide");
    }
});


$('.userRoleSaveBtn').bind({
    click: function () {
        $.msgBox({
            title: "Update",
            content: "Are you sure you want to update the record?",
            type: "confirm",
            buttons: [
                { value: "Update" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Update") {
                    window.location = "manage-permissions";
                } else if (result == "Cancel") {

                }
            }
        });
    },
});


// Configuration
$(".codeOption input:radio[class=active]").on('click', function () {
    $(this).parents('.codeOption').find('.codeArea').show();

});
$(".codeOption input:radio[class=suspend]").on('click', function () {
    $(this).parents('.codeOption').find('.codeArea').hide();
});


$('.allowedToView').change(function () {
    if ($(this).is(':checked')) {
        $(this).closest(".innerValue").next().slideDown();

    } else {
        $(this).closest(".innerValue").next().slideUp();
    }
});

$('.abilityTo1, .abilityTo2').change(function () {
    if ($('.abilityTo1').is(':checked') || $('.abilityTo2').is(':checked')) {
        //$(".abilityToValues").slideDown(); 
        $(this).parents('.dataSection').find(".abilityToValues").slideDown();
    } else {
        //$(".abilityToValues").slideUp();
        $(this).parents('.dataSection').find(".abilityToValues").slideUp();
    }
});

// Wfm reports
$('.levelDetails').hide(); //Hide/close all containers


//$('.levelDetails').first().show();
//$('.setDetails').first().addClass("active").find(".action").removeClass("plus").addClass("minus");
//On Click
$('.setDetails').click(function () {
    if ($(this).next().is(':hidden')) {
        $('.setDetails').removeClass('active').next().slideUp();
        $(this).toggleClass('active').next().slideDown();
        $('.setDetails .action').removeClass('minus').addClass('plus');
        $(this).find('.action').removeClass('plus').addClass('minus');
    }
    else if ($(this).hasClass("active")) {
        $('.setDetails').removeClass('active').next().slideUp();
        $(this).find('.action').removeClass('minus').addClass('plus');
    }
    return false;
});

// WFM - Rules - Financial Page JS		
$(".js-helpIcon").click(function () {
    $(".helpBlock").slideDown();
    $(".js-helpIcon").hide();
});
$(".crossIconBlock").click(function () {
    $(".js-helpIcon").show();
    $(".helpBlock").slideUp();
});

$('#FTentriesDropDown').change(function () {
    if ($(this).val() == "1" || $(this).val() == "2" || $(this).val() == "3" || $(this).val() == "4" || $(this).val() == "5") {
        $(".clonedInput").slideDown();
        $(".addTransaction").show();
    }
    else if ($(this).val() == "0") {
        $(".clonedInput").hide();
        $(".addTransaction").hide();
    }
});


$(document).on('change', '#FTentriesDropDown2', function () {

    if ($(this).val() == "1" || $(this).val() == "2" || $(this).val() == "3" || $(this).val() == "4" || $(this).val() == "5") {
        $(".clonedInput2").slideDown();
        $(".addTransaction2").show();
    }
    else if ($(this).val() == "0") {
        $(".clonedInput2").hide();
        $(".addTransaction").hide();
    }
});

$('.grayBox').on("change", "#FTentriesDropDown2", function () {
    alert("i am in");
})
$("#FTentriesDropDown2").bind("change", function () {
    alert("i am in");
})
$('#FTentriesDropDown2').on("change", function () {
    if ($(this).val() == "1" || $(this).val() == "2" || $(this).val() == "3" || $(this).val() == "4" || $(this).val() == "5") {
        alert("hi");
        $(".clonedInput2").show().slideDown();
        $(".addTransaction2").show();
    }
    else if ($(this).val() == "0") {
        $(".clonedInput2").hide();
        $(".addTransaction2").hide();
    }
});


/* $('#btnAdd').click(function() {
 $('.btnDel:disabled').removeAttr('disabled');
 var c = $('.clonedInput:first').clone(true);
 // c.children(':text').attr('name','input'+ (++inputs) );
 $('.clonedInput:last').after(c);
 });

 $('.btnDel').click(function() {
 if (confirm('continue delete?')) {
 // --inputs;
 $(this).closest('.clonedInput').remove();
 $('.btnDel').attr('disabled',($('.clonedInput').length  < 2));
 }
 });*/


// WFM Rules - Policies 
//---------- Add Rule
$("#popupAddRule").dialog({
    autoOpen: false,
    title: 'Assign New Rules',
    width: '657',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-addRule').click(function () {
    $('#popupAddRule').dialog('open');
    return false;
});

$("#popupAssociateEntity").dialog({
    autoOpen: false,
    title: 'Associate New Entity',
    width: '657',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-associateEntity').click(function () {
    $('#popupAssociateEntity').dialog('open');
    return false;
});

//--------- Assign rules

$('div.sourceList ul li input:checkbox').change(function () {
    if ($("div.sourceList ul li input:checkbox:checked").length > 0) {
        $('.applyAction .addItem').addClass('active');
    }
    else {
        $('.applyAction .addItem').removeClass('active');
    }
    if ($(this).is(":checked")) {
        $(this).parents('li').addClass('checked');
    } else {
        $(this).parents('li').removeClass('checked');
    }
});
$(document).on('click', '.applyAction a.addItem', function () {
    $('.applyAction .addItem').removeClass('active');
    $('div.sourceList ul ul li.checked').find('input:checked:not(:disabled)').each(function () {
        var newItem = $(this).parents('li label').html();
        var el = $('<li><label>' + newItem + '</label></li>');
        $('div.desitnationList ul').append(el);
        $(this).attr('disabled', true);
    });
});

$(document).on('change', 'div.desitnationList ul li input:checkbox', function () {
    if ($("div.desitnationList ul li input:checkbox:checked").length > 0) {
        $('.applyAction .removeItem').addClass('active');
    }
    else {
        $('.applyAction .removeItem').removeClass('active');
    }
});
$('.applyAction a.removeItem').on('click', function () {
    $('.applyAction .removeItem').removeClass('active');
    if ($("div.sourceList ul ul li input:checkbox:checked").length > 0) {
        $('.applyAction .addItem').addClass('active');
    }
    $('div.desitnationList ul li').find('input:checked').each(function () {
        $('div.sourceList ul ul li input:disabled[rel~="' + $(this).attr('rel') + '"]').attr('disabled', false);
        $(this).parents('li').remove();
    });
});

$('.popupBox .sourceList .subList').hide(); //Hide/close all containers
$('#popupAddRule .sourceList .subList').first().show();
$('#popupAddRule .sourceList > ul > li a').first().addClass("active").find(".icon-action").removeClass("plus").addClass("minus");
$('#popupAssociateEntity .sourceList .subList').first().show();
$('#popupAssociateEntity .sourceList > ul > li a').first().addClass("active").find(".icon-action").removeClass("plus").addClass("minus");


$('.sourceList > ul > li a.rulesSet').click(function () {
    //$(this).parents('li').addClass('open');
    $(this).parents('li').removeClass('selected');
    if ($(this).parents('li').find('.subList').is(':hidden')) {
        $('.sourceList > ul > li').removeClass('open');
        $('.sourceList > ul > li a.rulesSet').removeClass('active').parents('li').find('.subList').slideUp();
        $(this).toggleClass('active').parents('li').find('.subList').slideDown();
        $('.sourceList > ul > li a.rulesSet').find('.icon-action').removeClass('minus').addClass('plus');
        $(this).find('.icon-action').removeClass('plus').addClass('minus');
        $(this).parents('li').addClass('open')
    }
    else if ($(this).hasClass("active")) {
        $(this).removeClass('active').parents('li').find('.subList').slideUp();
        $(this).find('.icon-action').removeClass('minus').addClass('plus');
        $(this).parents('li').removeClass('open');
    }
    return false;
});

$('.sourceList label').hover(function () {
    $(this).next('b.desc').toggleClass('show');
});
/*$('.sourceList > ul > li > span').click(function(){
 if ($(this).parents('li').hasClass('open')){
 return false;
 }else{
 $(this).parents('li').toggleClass('selected');
 $(this).parents('li').find('input:checkbox').prop('checked', true);
 }
 });*/
$(document).on('click', '.sourceList > ul > li > span', function () {
    if ($(this).parents('li').hasClass('open')) {
        return false;
    } else {

        $(this).parents('li').toggleClass('selected');
        $(this).parents('li').find('input:checkbox').prop('checked', true).parents('li').addClass('checked');
    }
});

// Bill Cycles
$('.multiOptions').parents('.value-text').find('.option.hide').hide();
$('.multiOptions').change(function () {
    var optionValue = $(this).val();
    if (optionValue == 1) {
        $(this).parents('.value-text').find('.option').hide();
        $(this).parents('.value-text').find('.option.first').show();
    }
    else if (optionValue == 2) {
        $(this).parents('.value-text').find('.option').hide();
        $(this).parents('.value-text').find('.option.second').show();
    }
    else if (optionValue == 3) {
        $(this).parents('.value-text').find('.option').hide();
        $(this).parents('.value-text').find('.option.third').show();
    }
    else if (optionValue == 1 && optionValue == 2 && optionValue == 3) {
        $(this).parents('.value-text').find('.option.first').show();
        $(this).parents('.value-text').find('.option.second').show();
        $(this).parents('.value-text').find('.option.third').show();
    }
    else {
        $(this).parents('.value-text').find('.option').hide();
    }

});
$('.yesNoOptions').change(function () {
    var optionValue = $(this).val();
    if (optionValue == 'yes') {
        $('.yesNo').show();
    }
    else if (optionValue == 'no') {
        $('.yesNo').hide();
    }

});

$('.twoOptionsSec .twoOptions').change(function () {
    var optionValue = $(this).val();
    if (optionValue == 1) {
        $(this).parents('.twoOptionsSec').find('.firstOption').show();
        $(this).parents('.twoOptionsSec').find('.secondOption').hide();
    }
    else if (optionValue == 2) {
        $(this).parents('.twoOptionsSec').find('.firstOption').hide();
        $(this).parents('.twoOptionsSec').find('.secondOption').show();
    }
});

$('.threeOptionsSec .threeOptions').change(function () {
    var optionValue = $(this).val();
    if (optionValue == 1) {
        $(this).parents('.threeOptionsSec').find('.first-Option').show();
        $(this).parents('.threeOptionsSec').find('.second-Option').hide();
        $(this).parents('.threeOptionsSec').find('.thirdOption').hide();
    }
    else if (optionValue == 2) {
        $(this).parents('.threeOptionsSec').find('.first-Option').hide();
        $(this).parents('.threeOptionsSec').find('.second-Option').show();
        $(this).parents('.threeOptionsSec').find('.third-Option').hide();
    }
    else if (optionValue == 3) {
        $(this).parents('.threeOptionsSec').find('.first-Option').hide();
        $(this).parents('.threeOptionsSec').find('.second-Option').hide();
        $(this).parents('.threeOptionsSec').find('.third-Option').show();
    }
});


$('.fourOptionsSec .fourOptions').change(function () {
    var optionValue = $(this).val();
    if (optionValue == 1) {
        $(this).parents('.fourOptionsSec').find('.first-Option').show();
        $(this).parents('.fourOptionsSec').find('.second-Option').hide();
        $(this).parents('.fourOptionsSec').find('.thirdOption').hide();
        $(this).parents('.fourOptionsSec').find('.fourth-Option').hide();
    }
    else if (optionValue == 2) {
        $(this).parents('.fourOptionsSec').find('.first-Option').hide();
        $(this).parents('.fourOptionsSec').find('.second-Option').show();
        $(this).parents('.fourOptionsSec').find('.third-Option').hide();
        $(this).parents('.fourOptionsSec').find('.fourth-Option').hide();
    }
    else if (optionValue == 3) {
        $(this).parents('.fourOptionsSec').find('.first-Option').hide();
        $(this).parents('.fourOptionsSec').find('.second-Option').hide();
        $(this).parents('.fourOptionsSec').find('.third-Option').show();
        $(this).parents('.fourOptionsSec').find('.fourth-Option').hide();
    }
    else if (optionValue == 4) {
        $(this).parents('.fourOptionsSec').find('.first-Option').hide();
        $(this).parents('.fourOptionsSec').find('.second-Option').hide();
        $(this).parents('.fourOptionsSec').find('.third-Option').hide();
        $(this).parents('.fourOptionsSec').find('.fourth-Option').show();
    }
});

$("#ruleConfirmation").dialog({
    autoOpen: false,
    title: 'Successful!',
    width: '500',
    modal: true,
    position: ['center', 150]
});
$('.js-ruleConfirmation').click(function () {
    $('#ruleConfirmation').dialog('open');
    return false;
});


//User for on / off switch
$(".switch").on("click", "a", function () {
        $(this).addClass("active").siblings().removeClass("active");
        if ($(this).hasClass("offMode")) {
            $(this).parent().addClass("closed");
        }
        else {
            $(this).parent().removeClass("closed");
        }
    }
);

//delete entity alert box

$(document).on('click', '.delEntity', function (event) {
    //alert("This will remove the selected notification");
    $.msgBox({
        title: "Terminate  Entity",
        content: "Are you sure you want to Terminate the Entity?",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "Yes"}
        ],
        success: function (result) {
            if (result == "Yes") {
                //do nothing
            } else if (result == "Cancel") {
                //do nothing
            }
        }
    });
});

// Termination Date

$("#terminationDate").dialog({
    autoOpen: false,
    title: 'Terminate Entity',
    width: '328',
    modal: true,
    position: ['center', 150]
});
$('.js-terminateEntity').click(function () {
    $('#terminationDate').dialog('open');
    return false;
});
var currentDate = new Date();
$(".terminationDate input[type='text'], input.js-currentDate").datepicker("setDate", currentDate);

var date = currentDate.getDate();
var month = currentDate.getMonth() + 1;
var year = currentDate.getFullYear();

if (date <= 9) {
    date = '0' + date;
}
if (month <= 9) {
    month = '0' + month;
}
$(".js-currentMonth").html(month + "/" + '01' + "/" + year);
$(".js-currentDate").html(month + "/" + date + "/" + year);

// System Billing Cycle

$("#popupBillCycleAdd").dialog({
    autoOpen: false,
    title: 'Add Billing Cycle',
    width: '950',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-BillCycleAdd').click(function () {
    $('#popupBillCycleAdd').dialog('open');
    return false;
});

$('#preference-broker tr td .icon-delete').bind({
    click: function () {
        //alert("This will remove the selected notification");
        $(this).parents("tr").addClass("currentRow");
        $.msgBox({
            title: "Delete",
            content: "Are you sure you want to remove the record?",
            type: "confirm",
            buttons: [
                { value: "Yes" },
                { value: "Cancel"}
            ],
            success: function (result) {
                if (result == "Yes") {
                    $("tr.currentRow").hide();
                } else if (result == "Cancel") {
                    $("tr.currentRow").removeClass("currentRow");
                }
            }
        });
    },
});
$('.dropdown-menu').on('click', function (e) {
    if ($(this).hasClass('associateEntities')) {
        e.stopPropagation();
    }
});
$('#selectAll').on('click', function () {
    $('.selectedId').prop('checked', isChecked('selectAll'));
});

function isChecked(checkboxId) {
    var id = '#' + checkboxId;
    return $(id).is(":checked");
}
function resetSelectAll() {
    // if all checkbox are selected, check the selectall checkbox
    // and viceversa
    if ($(".selectedId").length == $(".selectedId:checked").length) {
        $("#selectAll").attr("checked", "checked");
    } else {
        $("#selectAll").removeAttr("checked");
    }


}

$("input[name='payMethod']").bind('click', function () {
    if ($("input[name='payMethod']:checked").val() == 'cash') {
        $('.IdNumber').hide();
    } else if ($("input[name='payMethod']:checked").val() == 'check') {
        $('.IdNumber').slideDown();
    }
    else if ($("input[name='payMethod']:checked").val() == 'moneyorder') {
        $('.IdNumber').slideDown();
    }
});

//added for others add entity selector box
$("#selectOthersEntity").on("change", function () {
    var selectedOpt = $(this).val();
    $("#" + selectedOpt).removeClass("hide").siblings().addClass("hide");
    switch (selectedOpt) {
        case "exchangeBox":
            $("#dataBoxLabel").text("Exchange Information");
            break;
        case "clientBox":
            $("#dataBoxLabel").text("Client Information");
            break;
        case "GovernmentAgency":
            $("#dataBoxLabel").text("Government Agency Information");
            break;
        case "OtherSubsidizingEntity":
            $("#dataBoxLabel").text("Other Subsidizing Entity");
            break;
        case "operatorBox":
            $("#dataBoxLabel").text("Operator Information");
            break;
        default:
            $("#dataBoxLabel").text("Information");
            break;
    }
})

$(document).on('click', '.js-icon-editgrpbillcycles', function (event) {
    /*$("#popupEditGroupBillCycles").dialog({
     autoOpen: false,
     title: 'Edit Bill Cycles',
        width: '565',
        modal: true,
        position: ['center', 150]
    });
     $('#popupEditGroupBillCycles').dialog('open');*/
    $("#BillCycleDate").datepicker({
        changeMonth: false,
        changeYear: false,
        showOn: "both",
        buttonImage: "../images/calender.png",
        buttonImageOnly: true,
        buttonText: "Calender",
        minDate: 0
    }).focus(function () {
        $(".ui-datepicker-prev, .ui-datepicker-next").remove();
    });

    $('.closePopUp').click(function () {
        $('.popupBox').dialog('close');
    });

    return false;
});

$("#popupAddAccounts").dialog({
    autoOpen: false,
    title: 'Add New Account',
    width: '565',
    modal: true,
    position: ['center', 150]
});
$('.js-icon-addAccounts').click(function () {
    $('#popupAddAccounts').dialog('open');
    return false;
});


$('.js-postHere').click(function () {
    $("#postHere").dialog({
        width: 700,
        title: 'Post Payment',
        modal: true
    });
});
// added for transaction Payment modal popup
$(".changeData").on("change", function () {
    var optionValue = $(this).val();
    if (optionValue == 1) {
        $(this).parents('.controls').find('.option').hide();
        $(this).parents('.controls').find('.option.first').show();
    }
    else if (optionValue == 2) {
        $(this).parents('.controls').find('.option').hide();
        $(this).parents('.controls').find('.option.second').show();
    }
})

$(document).on("click",".js-delete-block", function(){
	$(this).closest("section.gray-box.contact-info").slideUp(500,function(){$(this).remove();});
	})

//added for parent entity checkbox selection
$(".parentEntityChk").on("change", function () {
    if ($(this).prop("checked")) {
        $(".parentEntityDropDown").prop("disabled", true);
    }
    else {
        $(".parentEntityDropDown").prop("disabled", false);
    }
})

//added	for job-status data and time
$(function () {
    var now = new Date();

    var LastRun = (now.getMonth() + 1) + '/' + (now.getDate() - 1) + '/' + now.getFullYear();
    LastRun += ' ' + now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
    $(".LastExec").text(LastRun);

    var NextRun = (now.getMonth() + 1) + '/' + (now.getDate() + 1) + '/' + now.getFullYear();
    NextRun += ' ' + now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
    $(".NextExec").text(NextRun);


    var len = $(".HistoryTime").length;
    for (var i = 1; i <= len; i++) {
        var historyRun = (now.getMonth() + 1) + '/' + (now.getDate() - i) + '/' + now.getFullYear();
        historyRun += ' ' + (now.getHours() - i) + ':' + now.getMinutes() + ':' + now.getSeconds();
        $(".HistoryTime").eq(i - 1).text(historyRun);
    }

})


/*----------------------------------------------------*/
/*	Scroll To Top Section
 /*----------------------------------------------------*/
jQuery(document).ready(function () {

    jQuery(window).scroll(function () {
        if (jQuery(this).scrollTop() > 100) {
            jQuery('.scrollup').fadeIn();
        } else {
            jQuery('.scrollup').fadeOut();
        }
    });

    jQuery('.scrollup').click(function () {
        jQuery("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

});


$("input[name='amount']").bind('click', function () {
    if ($("input[name='amount']:checked").val() == 'percentAmount') {
        $(".flatAmtBlock").hide();
        $(".percentBlock").slideDown();
    }
    else if ($("input[name='amount']:checked").val() == 'flatAmt') {
        $(".flatAmtBlock").slideDown();
        $(".percentBlock").hide();
    }
});
$("input[name='amount1']").bind('click', function () {
    if ($("input[name='amount1']:checked").val() == 'percentAmount1') {
        $(".flatAmtBlock1").hide();
        $(".percentBlock1").slideDown();
    }
    else if ($("input[name='amount1']:checked").val() == 'flatAmt1') {
        $(".flatAmtBlock1").slideDown();
        $(".percentBlock1").hide();
    }
});
$("input[name='amount2']").bind('click', function () {
    if ($("input[name='amount2']:checked").val() == 'percentAmount2') {
        $(".flatAmtBlock2").hide();
        $(".percentBlock2").slideDown();
    }
    else if ($("input[name='amount2']:checked").val() == 'flatAmt2') {
        $(".flatAmtBlock2").slideDown();
        $(".percentBlock2").hide();
    }
});
$("#popupAddChargesRule").dialog({
    autoOpen: false,
    title: 'Add New Financial Charge',
    width: '700',
    modal: true,
    position: ['center', 150]
});
$('.js-addChargeRule').click(function () {
    $('#popupAddChargesRule').dialog('open');
    return false;
});


$("#popupViewChargesRule").dialog({
    autoOpen: false,
    title: 'View Financial Charge',
    width: '700',
    modal: true,
    position: ['center', 150]
});
$('.js-viewChargeRule').click(function () {
    $('#popupViewChargesRule').dialog('open');
    return false;
});


$("#popupEditChargesRule").dialog({
    autoOpen: false,
    title: 'Edit Financial Charge',
    width: '700',
    modal: true,
    position: ['center', 150]
});
$('.js-editChargeRule').click(function () {
    $('#popupEditChargesRule').dialog('open');
    return false;
});


$("#popupAssociateEntity").dialog({
    autoOpen: false,
    title: 'Assign Entities',
    width: '700',
    modal: true,
    position: ['center', 150]
});
$('.js-assignChargeRule').click(function () {
    $('#popupAssociateEntity').dialog('open');
    return false;
});

// Refund Payment amount box

$("#refundPayment").dialog({
    autoOpen: false,
    width: '500',
    height: 'auto',
    title: 'Refund Payment',
    modal: true,
    autoReposition: true,
    show: {
        effect: "fade",
        duration: 800
    },
    hide: {
        effect: "fade",
        duration: 00
    },
    position: {
        my: "center",
        at: "center",
        of: window
    }
});
$('.js-refundPayment').click(function () {
    $('#refundPayment').dialog('open');
    $("#sec2").hide();
    return false;
});
$(".js-refundCheck").click(function () {
    $("#refAmt").text($("#RefundAmt").val())
    $("#sec1").hide();
    $("#sec2").show();
    return false;
});
$(".closePopUpRefund").click(function () {
    $("#refundPayment").dialog('close');
    $("#sec2").hide();
    $("#sec1").show();
});


// =========Report discrepancy 

$('.js-popup-report-discrepancy').click(function () {
    $('#popup-report-discrepancy').dialog('open');
    return false;
});


$("#popup-report-discrepancy").dialog({
    autoOpen: false,
    width: '500',
    height: 'auto',
    title: 'Report Discrepancy ',
    modal: true,
    autoReposition: true,
    show: {
        effect: "fade",
        duration: 800
    },
    hide: {
        effect: "fade",
        duration: 00
    },
    position: {
        my: "center",
        at: "center",
        of: window
    }
});

$(".js-send").click(function () {
    $("#sec1").hide();
    $("#sec2").show();
    return false;
});
$(".closePopUp, .js-closeInvoice").click(function () {
    $("#popup-report-discrepancy").dialog('close');
});

//Void Payment Alert
$('.voidPayment').bind({
    click: function () {
        $.msgBox({
            title: "Void Payment",
            content: "Do you really wish to void payment of $827.63 for Jenny Craig?",
            type: "confirm",
            buttons: [
                { value: "Cancel" },
                { value: "Confirm"}
            ],
            success: function (result) {
                if (result == "Update") {

                } else if (result == "Cancel") {

                }
            }
        });
    },
});

$(".review-billingCycle > table  input[type=checkbox]").change(function () {
    $(this).closest('tr').toggleClass("selectedRow", this.checked);
    var delRows = $(".selectedRow").length;
    if (delRows > 0) {
        jQuery(".js-removeRow1").removeClass("halfOpacity1");
        jQuery(".js-removeRow1").addClass("rmv1");
    } else {
        jQuery(".js-removeRow1").addClass("halfOpacity1");
        jQuery(".js-removeRow1").removeClass("rmv1");
    }
});

$(document).on('click', '.halfOpacity1', function (event) {
    //alert("Please select record(s) to approve them.");
    $.msgBox({
        title: "Error",
        content: "Please select atleast one Invoice.",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "OK"}
        ],
        success: function (result) {
            if (result == "OK") {

            } else if (result == "Cancel") {
                //do nothing
            }
        }
    });
});

$(document).on('click', '.rmv1', function (event) {
    //alert("This will remove the selected notification");
    $.msgBox({
        title: "Approve Invoice(s)",
        content: "Are you sure you want to approve the selected Invoice(s)?",
        type: "confirm",
        buttons: [
            { value: "No" },
            { value: "Yes"}
        ],
        success: function (result) {
            if (result == "Yes") {
                jQuery(".js-removeRow1").addClass("halfOpacity1");
                jQuery(".js-removeRow1").removeClass("rmv1");
            } else if (result == "Cancel") {
                //do nothing
            }
        }
    });

});
$(document).on('click', '.js-approveInv', function (event) {
    //alert("This will remove the selected notification");
    $.msgBox({
        title: "Approve Billing Cycle",
        content: "Kindly approve atleast 1%(100) of total 10,000 invoices generated to approve the Billing Cycle.",
        type: "confirm",
        buttons: [
            { value: "Cancel" },
            { value: "OK"}
        ],
        success: function (result) {
            if (result == "OK") {

            } else if (result == "Cancel") {
                //do nothing
            }
        }
    });
});

$('select#addChargesType').change(function () {
    var userType = $('select#addChargesType').val();
    if (userType == '1') {
        $('.ruleParameter1').slideDown();
        $('.ruleParameter2').hide();
        $('.ruleParameter3').hide();
    } else if (userType == '2') {
        $('.ruleParameter2').slideDown();
        $('.ruleParameter1').hide();
        $('.ruleParameter3').hide();
    } else if (userType == '3') {
        $('.ruleParameter3').slideDown();
        $('.ruleParameter1').hide();
        $('.ruleParameter2').hide();
        $('.tollFree4').hide();
    } else if (userType == '0') {
        $('.ruleParameter1').hide();
        $('.ruleParameter2').hide();
        $('.ruleParameter3').hide();
    }
});
$(".js-next").click(function () {
    $("#AddChargesPopupOne").hide();
    $("#AddChargesPopupTwo").show();
    return false;
});
$("#popupFinancialsRule").dialog({
    autoOpen: false,
    title: 'Rules Configuration',
    width: '850',
    modal: true,
    position: ['center', 150]
});
$('.js-viewFinancials').click(function () {
    $('#popupFinancialsRule').dialog('open');
    return false;
});


$(document).on('click', '.enableClass', function () {
    if ($(this).is(":checked")) {
        $(this).parents(".controls").find('.textareaEnable').removeAttr("disabled");
    }
    else {
        $(this).parents(".controls").find('.textareaEnable').attr('disabled', true);
    }
});


// Approve Record

$("#approveRule").dialog({
    autoOpen: false,
    title: 'Review & Approve',
    width: '800',
    modal: true,
    position: ['center', 150]
});
$('.js-approveRule').click(function () {
    $('#approveRule').dialog('open');
    return false;
});

$('.js-addRecord').on('click', function () {
    $(this).parents('#approveRule').find('.fts-records').append('<tr><td><select class="input-medium"><option>Premium</option><option>APTC</option><option>UserFee</option></select></td><td><input type="text" class="input-small" /></td><td><input type="text" class="input-small" /></td><td><input type="text" class="input-small" /><a href="javascript:;" class="marginL10"><span class="icon-delete"></span></a></td></tr>');
});

$(".js-generateFts").click(function () {
    $("#sec1").hide();
    $("#sec2").show();
    return false;
});
$(".js-generateFtsBack").click(function () {
    $("#sec2").hide();
    $("#sec1").show();
    return false;
});
$(".generateFtsBack").click(function () {
    $('.js-approveRule').parents('td.status').html('Active');
});

$(document).on('click', '.fts-records tr td .icon-delete', function () {
    //alert("This will remove the selected notification");
    $(this).parents("tr").addClass("currentRow");
    $.msgBox({
        title: "Delete",
        content: "Are you sure you want to remove the record?",
        type: "confirm",
        buttons: [
            { value: "Yes" },
            { value: "Cancel"}
        ],
        success: function (result) {
            if (result == "Yes") {
                $("tr.currentRow").hide();
            } else if (result == "Cancel") {
                $("tr.currentRow").removeClass("currentRow");
            }
        }
    });

});


$("#popupInvoicesStatus").dialog({
    autoOpen: false,
    title: 'Invoice Status',
    width: '300',
    modal: true,
    position: ['center', 150]
});
$('.js-invocesStatusPopup').click(function () {
    $('#popupInvoicesStatus').dialog('open');
    return false;
});


// Contract Net Details
var data1 = '<table class="table table-striped tblComplex"tr class="inner"><tr><td width="100px" valign="bottom" class="attr"><h3>Contract</h3></td><td><table class="table table-striped"><thead><tr><th width="10%" data-sort-ignore="true">Entity ID</th><th width="12%" data-sort-ignore="true">Entity</th><th width="11%" data-sort-ignore="true">Entity Type</th><th width="9%" data-sort-ignore="true" class="text-right">Liability</th><th width="9%" data-sort-ignore="true" class="text-right">Invoiced</th><th width="10%" data-sort-ignore="true" class="text-right">Collected</th><th width="9%" data-sort-ignore="true" class="text-right">Applied</th><th width="10%" data-sort-ignore="true" class="text-right">To Remit</th><th width="10%" data-sort-ignore="true" class="text-right">Remitted</th><th width="10%" data-sort-ignore="true" class="text-right">Revenue</th></tr><tr><td>IN-1001</td><td>Jenny Craig</td><td>Individual</td><td class="text-right">$200.00</td><td class="text-right">$200.00</td><td class="text-right">$150.00</td><td class="text-right">$150.00</td><td class="text-right">$170.00</td><td class="text-right">$120.00</td><td class="text-right">$30.00</td></tr></thead><tbody></tbody></table></td/trtr class="inner"></tr><tr><td class="attr"><h3>Contributions</h3></td><td><table class="table table-striped mid"><thead><tr><td width="10%">IN-1001</td><td width="12%">Jenny Craig</td><td width="12%">Individual</td><td width="9%" class="text-right">$150.00</td><td width="9%" class="text-right">$150.00</td><td width="9%" class="text-right">$150.00</td><td width="9%" class="text-right">$150.00</td><td width="11%" class="text-right">--</td><td width="10%" class="text-right">--</td><td width="9%" class="text-right">--</td></tr><tr><td>IN-1001</td><td>CMS</td><td>Government</td><td class="text-right">$50.00</td><td class="text-right">$50.00</td><td class="text-right">$0.00</td><td class="text-right">$0.00</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td></tr></thead><tbody></tbody></table></td/trtr class="inner"></tr><tr><td class="attr"><h3>Partners</h3></td><td><table class="table table-striped"><thead><tr><td width="10%">HP-1001</td><td width="13%">Cigna</td><td width="11%">Partner</td><td width="10%" class="text-right">--</td><td width="9%" class="text-right">--</td><td width="9%" class="text-right">--</td><td width="9%" class="text-right">--</td><td width="9%" class="text-right">$100.00</td><td width="12%" class="text-right">$70.00</td><td width="8%" class="text-right">--</td></tr><tr><td>HP-1002</td><td>Metlife</td><td>Partner</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">$40.00</td><td class="text-right">$50.00</td><td class="text-right">--</td></tr><tr><td>HP-1003</td><td>Delta Dental</td><td>Partner</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">$30.00</td><td class="text-right">$0.00</td><td class="text-right">--</td></tr></thead><tbody></tbody></table></td/tr></tr></table>';


var data2 = '<table class="table table-striped tblComplex"tr class="inner"><tr>  <td width="100px" valign="bottom" class="attr"><h3>Contract</h3></td>  <td><table class="table table-striped"><thead><tr><th width="10%" data-sort-ignore="true">Entity ID</th><th width="12%" data-sort-ignore="true">Entity</th><th width="11%" data-sort-ignore="true">Entity Type</th><th width="9%" data-sort-ignore="true" class="text-right">Liability</th><th width="9%" data-sort-ignore="true" class="text-right">Invoiced</th><th width="10%" data-sort-ignore="true" class="text-right">Collected</th><th width="9%" data-sort-ignore="true" class="text-right">Applied</th><th width="10%" data-sort-ignore="true" class="text-right">To Remit</th><th width="10%" data-sort-ignore="true" class="text-right">Remitted</th><th width="10%" data-sort-ignore="true" class="text-right">Revenue</th></tr><tr><td>IN-1001</td><td>Tony Carlini</td><td>Individual</td><td class="text-right">$600.00</td><td class="text-right">$600.00</td><td class="text-right">$500.00</td><td class="text-right">$500.00</td><td class="text-right">$470.00</td><td class="text-right">$420.00</td><td class="text-right">$30.00</td></tr></thead><tbody></tbody></table></td/trtr class="inner"></tr><tr>  <td class="attr"><h3>Contributions</h3></td>  <td><table class="table table-striped mid"><thead><tr><td width="10%">IN-1001</td><td width="12%">Tony Carlini</td><td width="12%">Individual</td><td width="9%" class="text-right">$500.00</td><td width="9%" class="text-right">$500.00</td><td width="9%" class="text-right">$500.00</td><td width="9%" class="text-right">$500.00</td><td width="11%" class="text-right">--</td><td width="10%" class="text-right">--</td><td width="9%" class="text-right">--</td></tr><tr><td>IN-1001</td><td>CMS</td><td>Government</td><td class="text-right">$100.00</td><td class="text-right">$100.00</td><td class="text-right">$0.00</td><td class="text-right">$0.00</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td></tr></thead><tbody></tbody></table></td/trtr class="inner"></tr><tr>  <td class="attr"><h3>Partners</h3></td>  <td><table class="table table-striped"><thead><tr><td width="10%">HP-1001</td><td width="13%">Cigna</td><td width="11%">Partner</td><td width="10%" class="text-right">--</td><td width="9%" class="text-right">--</td><td width="9%" class="text-right">--</td><td width="9%" class="text-right">--</td><td width="9%" class="text-right">$200.00</td><td width="12%" class="text-right">$180.00</td><td width="8%" class="text-right">--</td></tr><tr><td>HP-1002</td><td>Metlife</td><td>Partner</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">$200.00</td><td class="text-right">$180.00</td><td class="text-right">--</td></tr><tr><td>HP-1003</td><td>Delta Dental</td><td>Partner</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">--</td><td class="text-right">$70.00</td><td class="text-right">$60.00</td><td class="text-right">--</td></tr></thead><tbody></tbody></table></td/tr></tr></table>';


$(".js-addRow").on('click', function () {
    var clicks = $(this).data('clicks');
    if (clicks) {
        $(this).parents("tr").next().remove();
    } else {
        $(this).parents("tr").toggleClass("activerow").after("<tr><td colspan='4' class='tbl-row'>" + data1 + "</td></tr>");
    }
    $(this).data("clicks", !clicks);
    $(this).find("span").toggleClass("icon-up-tbl");
});


$(".js-addRow2").on('click', function () {
    var clicks = $(this).data('clicks');
    if (clicks) {
        $(this).parents("tr").next().remove();
    } else {
        $(this).parents("tr").toggleClass("activerow").after("<tr><td colspan='4' class='tbl-row'>" + data2 + "</td></tr>");
    }
    $(this).data("clicks", !clicks);
    $(this).find("span").toggleClass("icon-up-tbl");
});


//===============Filtrs=================


function convertStringIntoCaptializeCase(str){
	if(str){
	return  str.charAt(0).toUpperCase() + str.substr(1);
	}
	return ;
}

$(document).on('click', '.js-show-list-coverage', function () {
	$(this).next().toggle();	
});
		
$('body').click(function(e) {
	if (!$(e.target).closest('.entity-box-search-box').length){
		$(".search-list").hide();
		$(".search-list-coverage").hide();
	}
	if (!$(e.target).closest('.advance-filter').length){
		$('.filter-option').removeClass('advance-filter-data');
	}
	/*$('.advance-filter').mouseleave(function(){
		$('.filter-option').removeClass('advance-filter-data');
	});*/
});




/*$(document).on('mouseover', '.toolTip', function() {
	$('.toolTip').tipsy({gravity: 'w', });
});
$("html, .closetip").click(function(e) {
    $(".tipsy").remove();
});*/
