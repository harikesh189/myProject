/*jslint node: true */
'use strict';

var pkg = require('./package.json');

//Using exclusion patterns slows down Grunt significantly
//instead of creating a set of patterns like '**/*.js' and '!**/node_modules/**'
//this method is used to create a set of inclusive patterns for all subdirectories
//skipping node_modules, bower_components, dist, and any .dirs
//This enables users to create any directory structure they desire.
var createFolderGlobs = function(fileTypePatterns) {
  fileTypePatterns = Array.isArray(fileTypePatterns) ? fileTypePatterns : [fileTypePatterns];
  var ignore = ['node_modules','bower_components','dist','temp'];
  var fs = require('fs');
  return fs.readdirSync(process.cwd())
          .map(function(file){
            if (ignore.indexOf(file) !== -1 ||
                file.indexOf('.') === 0 ||
                !fs.lstatSync(file).isDirectory()) {
              return null;
            } else {
              return fileTypePatterns.map(function(pattern) {
                return file + '/**/' + pattern;
              });
            }
          })
          .filter(function(patterns){
            return patterns;
          })
          .concat(fileTypePatterns);
};

module.exports = function (grunt) {

  // load all grunt tasks
  require('load-grunt-tasks')(grunt);

  // Project configuration.
  grunt.initConfig({
    connect: {
      main: {
        options: {
          port: 9001
        }
      }
    },
    clean: {
      before:{
        src:['dist','temp']
      },
      after: {
        src:['temp']
      }
    },
    copy: {
      main: {
        files: [
          {src: ['img/**'], dest: 'dist/',filter:'isFile',expand:true},
		  {src: ['images/**'], dest: 'dist/',filter:'isFile',expand:true},
		  {src: ['css/**'], dest: 'dist/',filter:'isFile',expand:true},
		  {src: ['templates/**'], dest: 'dist/',filter:'isFile',expand:true},
		  {src: ['views/**'], dest: 'dist/',filter:'isFile',expand:true},
		  {src: ['widgets/**'], dest: 'dist/',filter:'isFile',expand:true},
		  {cwd: '../',src: ['common/**/*.html'], dest: 'dist/', expand:true},
		  {cwd: '../',src: ['vendor/**'], dest: 'dist/', expand:true}
        ]
      }
     },
    dom_munger:{
      read: {
        options: {
          read:[
            {selector:'script[data-concat!="false"]',attribute:'src',writeto:'appjs'},
            {selector:'link[rel="stylesheet"][data-concat!="false"]',attribute:'href',writeto:'appcss'}
          ]
        },
        src: 'index.html'
      },
      update: {
        options: {
          remove: ['script[data-remove!="false"]','link[data-remove!="false"]'],
          append: [
            {selector:'head',html:'<link rel="stylesheet" href="css/billing-commons.min.css">'},
			{selector:'head',html:'<script src="billing-commons.min.js"></script>'}
          ]
        },
        src:'index.html',
        dest: 'dist/index.html'
      }
    },
    cssmin: {
      main: {
        src:['temp/app.css','<%= dom_munger.data.appcss %>'],
        dest:'dist/css/billing-commons.min.css'
      }
    },
    concat: {
      main: {
        src: ['<%= dom_munger.data.appjs %>'],
        dest: 'temp/billing-commons.js'
      },
        dev: {
            src: ['<%= dom_munger.data.appjs %>'],
            dest: 'dist/billing-commons.js'
        }
    },
    ngmin: {
      main: {
        src:'temp/billing-commons.js',
        dest: 'temp/billing-commons.js'
      },
        dev: {
			src:'dist/billing-commons.js',
			dest: 'temp/billing-commons.js'
        }
    },
	ngAnnotate: {
		main: {
        src:'temp/billing-commons.js',
        dest: 'temp/billing-commons.js'
      },
        dev: {
			src:'dist/billing-commons.js',
			dest: 'temp/billing-commons.js'
        }
	},
    uglify: {
      main: {
        src: 'temp/billing-commons.js',
        dest:'dist/billing-commons.min.js'
      }
    }
  });
  grunt.registerTask('build-dev',['clean:before','dom_munger','cssmin','concat:dev','ngAnnotate:dev','uglify','copy','clean:after']);
};
