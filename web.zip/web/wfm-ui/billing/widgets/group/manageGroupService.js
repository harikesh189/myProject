/**
 * 
 */


hcentive.WFM.GroupServ = [ '$http', 'RESTSrvc',function($http, RESTSrvc) {
	
	var viewGroup=function(param,afterSucess,afterFail){
		RESTSrvc.getForData('itemDetailsService',param,null,afterSucess,afterFail);
	};
	
	var viewBillingPolicyForBE=function(param,afterSucess,afterFail){
		RESTSrvc.getForData('manageBusinessPolicyPort',param,null,afterSucess,afterFail);
	};
	
	var viewBillingPolicyForBA=function(param,afterSucess,afterFail){
		RESTSrvc.getForData('getPoliciesByBAId',param,null,afterSucess,afterFail);
	};
	
	return {
		viewGroup : viewGroup,
		viewBillingPolicyForBE:viewBillingPolicyForBE,
		viewBillingPolicyForBA:viewBillingPolicyForBA
	};
	
}];

//wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "GroupServ",
	"id" : hcentive.WFM.GroupServ
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "GroupServ",
	"id" : hcentive.WFM.GroupServ
});
