hcentive.WFM.manageGroupCntrl=['$scope','$location','GroupServ','EventBusSrvc','$filter','fetchGroupServ',
                             function($scope,$location,GroupServ,EventBusSrvc,$filter,fetchGroupServ){
	//$scope.pagination = defaultPagination('','');
	//$scope.updateLeftNav('Groups');
	$scope.datePattern = /^(1[0-2]|0[0-9])[/]([0-2][0-9]|3[0-1])[/]([0-9]{4})$/;
	$scope.beIdentity = null;
	$scope.viewGroupDetails=function(id, baIdentity,beExternalId){
		/* if(baIdentity) {
			$scope.beIdentity = baIdentity;
			EventBusSrvc.publish('beIdentity',baIdentity);
			EventBusSrvc.publish('goToRelatedBEIdentity', baIdentity);
		}  */
		if(beExternalId) {
			EventBusSrvc.publish('goToRelatedBEExternalId', beExternalId);
		}

		$scope.publishPageBackFilters($scope.pageBackFilters);
		var param = {"id" : id,"type":'be'};
		GroupServ.viewGroup(param,afterSucessGroupDetails,afterFail);

	}
	
	$scope.viewPolicyForGrpEntity=function(billingAccountIdentity){
		console.log(billingAccountIdentity);
		var searchCriteria ={};
     	searchCriteria.criteria ={};
     	searchCriteria.criteria["identity"]= { "operator": "=","columnValue":  "'"+billingAccountIdentity+"'"} ;
     	var paginationForFirst = getAllContent('','');
     	searchCriteria.pageRequestCriteria = getPageRequestCriteria(paginationForFirst);
     	var promise =fetchGroupServ.getBillingAccounts(searchCriteria);
     	promise.then(function(data){
     		var billingAccList =transformInnerTableData(data,$scope);
     		if(billingAccList != null)
     		EventBusSrvc.publish('groupPolicyDetails',billingAccList[0]);
     		else
     			EventBusSrvc.publish('groupPolicyDetails',null);
    		$scope.publishPageBackFilters($scope.pageBackFilters);
    		$location.path('entities/group/view-policy-grp');
    		$location.replace();
     		
     	},function(error){
     		console.log("Error while getting billing accoutns");
     	});
 		

	
	}
	
	//
	$scope.viewFinancialSummaryForSubscription = function(id,beExternalId,baExternalId){
		if(beExternalId) {
			EventBusSrvc.publish('goToRelatedBEExternalId', beExternalId);
		}
		if(baExternalId){
			EventBusSrvc.publish('goToRelatedBAExternalId',baExternalId);
		}
		
		var param = {"id" : id,"type":'be'};
		GroupServ.viewGroup(param,afterSuccessGrpSubscriptionDetail,afterFail);
		
	};
	
	$scope.viewMemberContracts=function(entityId,billingAccountIdentity, itemRecordId){
		EventBusSrvc.publish('groupCustExtId', entityId);
		EventBusSrvc.publish('billingAccountIdentity',billingAccountIdentity);
		EventBusSrvc.publish('groupCustItemRecordId',itemRecordId);
		$location.path('system/eligibility/group');
		$location.replace();
	}
	
	var afterSucessGroupDetails=function(data){
		transformDetailFor_Group(data);
	    $location.path('entities/group/group-details');
		$location.replace();
	}
	
	var afterSuccessGrpSubscriptionDetail =function(data){
		transformDetailFor_Group(data);
		$location.path('entities/group/financial-summary-Subscription');
		$location.replace();
	};
	
	var transformDetailFor_Group = function(data){
		$scope.businessEntity = data.item;
		if(data.itemMetaInfo){
		$scope.businessEntity.source = data.itemMetaInfo.tenant;
		}
		EventBusSrvc.publish('groupDetails', $scope.businessEntity);
		if($scope.businessEntity.groupCustomer!=undefined && $scope.businessEntity.groupCustomer!=null)
		var WriteOffJson={'id':$scope.businessEntity.groupCustomer.id.id,'firstName':$scope.businessEntity.groupCustomer.establishmentName,'lastName':""};
	    EventBusSrvc.publish('WriteOffParameters',WriteOffJson);
	    EventBusSrvc.publish('billable',$scope.businessEntity.groupCustomer.billable);
	}
	$scope.getGroupDetails=function(){
		$scope.groupDetails= EventBusSrvc.subscribe('fetchIdentityForAssociatedEntity');
	}
	
	 $scope.getItemDetails=function(){
	 
		$scope.updateLeftNav('Groups');
		$scope.itemRecordId = EventBusSrvc.subscribeAndInvalidatePayload('itemRecordId');
		if($scope.itemRecordId != null && $scope.itemRecordId != undefined){
			$scope.viewGroupDetails($scope.itemRecordId);
			return;
		}
		
	//	var goToRelatedBEIdentity = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEIdentity');
		var goToRelatedBEExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
		// $scope.goToRelatedBEIdentity = goToRelatedBEIdentity;
		$scope.goToRelatedBEExternalId = goToRelatedBEExternalId;
		
	//	$scope.getFinancialSummary($scope.goToRelatedBEIdentity, 'GROUP');
		
		$scope.pageBackFilters = EventBusSrvc.subscribeAndInvalidatePayload('pageBackFilters');
		
		$scope.addressesList = {};
		$scope.subList={};
		$scope.contactPersonList={};
		$scope.name={};
		$scope.businessEntity=EventBusSrvc.subscribe('groupDetails');
		var groupMetaInfo=EventBusSrvc.subscribe('BEmetaInfo');
		if(groupMetaInfo)
		 $scope.businessEntity.source=groupMetaInfo.tenant;
		
		var customerName = '';
		if($scope.businessEntity != null && $scope.businessEntity != undefined && 
				$scope.businessEntity.groupCustomer != null && $scope.businessEntity.groupCustomer != undefined)
			customerName = $scope.businessEntity.groupCustomer.establishmentName;
		/* var adjustmentJson={'id':$scope.businessEntity.groupCustomer.id.id,'name':customerName,'type':'Group','identity':goToRelatedBEIdentity,'businessEntityType':'Customer'};
		
		$scope.DelinquencyExceptionRuleJson= {};
		$scope.DelinquencyExceptionRuleJson = adjustmentJson;
		//alert($scope.DelinquencyExceptionRuleJson);
		
		EventBusSrvc.publish('EntityType',adjustmentJson);
		$scope.populateWriteOnDetails('Group', goToRelatedBEExternalId, goToRelatedBEIdentity, customerName);
		var billable = $scope.businessEntity.groupCustomer.billable;
		if(billable){
		$scope.goToRelatedItemList = [
		                     {'name': 'Invoices', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/invoices/groups'},
		                     {'name': 'Payments', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/payments'},
		                     {'name': 'Manual Adjustments', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/manual-adjustments/refunds-payments'},
		                     {'name': 'Accounts', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/account-details'},
		                     {'name': 'FT Transactions', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/financials-transactions-report'}
		                 ];
		}
		else{
		$scope.goToRelatedItemList = [
		                     {'name': 'Invoices', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/invoices/groups'},
		                     {'name': 'Payments', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/payments'},
		                     {'name': 'Accounts', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/account-details'},
		                     {'name': 'FT Transactions', 'eventValue': [goToRelatedBEIdentity,goToRelatedBEExternalId], 'redirectUrl': '#/financials/financials-transactions-report'}
		                 ];	
		} */
		if($scope.businessEntity != null && $scope.businessEntity != undefined) {
			if($scope.businessEntity.groupCustomer != null && $scope.businessEntity.groupCustomer != undefined){
				
				if($scope.businessEntity.groupCustomer.addresses != null && $scope.businessEntity.groupCustomer.addresses != undefined) {
					$scope.addressesList = $scope.businessEntity.groupCustomer.addresses;
				}
				
				if($scope.businessEntity.groupCustomer.subGroups != null && $scope.businessEntity.groupCustomer.subGroups != undefined) {
					$scope.subList=$scope.businessEntity.groupCustomer.subGroups;
				}
				
				if($scope.businessEntity.groupCustomer.contactPersons != null && $scope.businessEntity.groupCustomer.contactPersons != undefined &&
						$scope.businessEntity.groupCustomer.contactPersons.contactPerson != null && $scope.businessEntity.groupCustomer.contactPersons.contactPerson != undefined) {
					if($scope.businessEntity.groupCustomer.contactPersons.contactPerson.contactNumbers != null && $scope.businessEntity.groupCustomer.contactPersons.contactPerson.contactNumbers != undefined) {
						$scope.contactPersonList=$scope.businessEntity.groupCustomer.contactPersons.contactPerson.contactNumbers;
					}
					if($scope.businessEntity.groupCustomer.contactPersons.contactPerson.name != null && $scope.businessEntity.groupCustomer.contactPersons.contactPerson.name != undefined) {
						$scope.name=$scope.businessEntity.groupCustomer.contactPersons.contactPerson.name;
					}
				}
				if($scope.businessEntity.groupCustomer.contactNumbers!= null && $scope.businessEntity.groupCustomer.contactNumbers != undefined) {
					$scope.contactsList = $scope.businessEntity.groupCustomer.contactNumbers.contactNumber;
				}
				if($scope.businessEntity.groupCustomer.emailIds!= null && $scope.businessEntity.groupCustomer.emailIds != undefined) {
					$scope.emailList = $scope.businessEntity.groupCustomer.emailIds;
				}
			}
		}
		
	};
	

	
	$scope.getFinancialSummaryDetail =  function(){
		/*var goToRelatedBEIdentity = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEIdentity');
		$scope.goToRelatedBEIdentity = goToRelatedBEIdentity;
		*/
		var goToRelatedBEExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
		$scope.goToRelatedBEExternalId = goToRelatedBEExternalId;
		var goToRelatedBAExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBAExternalId');
		$scope.goToRelatedBAExternalId = goToRelatedBAExternalId;
		$scope.getFinancialSummaryForAccExternalId($scope.goToRelatedBAExternalId, 'GROUP');
		$scope.businessEntity=EventBusSrvc.subscribe('groupDetails');
		var customerName = '';
		$scope.groupflag=false;
		if($scope.businessEntity != null && $scope.businessEntity != undefined && 
				$scope.businessEntity.groupCustomer != null && $scope.businessEntity.groupCustomer != undefined){
			$scope.groupflag=true;
			customerName = $scope.businessEntity.groupCustomer.establishmentName;
		}
		var adjustmentJson={'id':$scope.businessEntity.groupCustomer.id.id,'name':customerName,'type':'Group','identity':null,'businessEntityType':'Customer','baExternalId':goToRelatedBAExternalId};
		$scope.DelinquencyExceptionRuleJson= {};
		$scope.DelinquencyExceptionRuleJson = adjustmentJson;
		//alert($scope.DelinquencyExceptionRuleJson);
		
		EventBusSrvc.publish('EntityType',adjustmentJson);
		//$scope.populateWriteOnDetails('Group', goToRelatedBEExternalId, goToRelatedBEIdentity, customerName);
		var billable = $scope.businessEntity.groupCustomer.billable;
		if(billable){
		$scope.goToRelatedItemList = [
		                     {'name': 'Invoices', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/invoices/groups'},
		                     {'name': 'Payments', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/payments'},
		                     {'name': 'Manual Adjustments', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/manual-adjustments/refunds-payments'},
		                     {'name': 'Accounts', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/account-details'},
		                     {'name': 'FT Transactions', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/financials-transactions-report'}
		                 ];
		}
		else{
		$scope.goToRelatedItemList = [
		                     {'name': 'Invoices', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/invoices/groups'},
		                     {'name': 'Payments', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/payments'},
		                     {'name': 'Accounts', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/account-details'},
		                     {'name': 'FT Transactions', 'eventValue': [goToRelatedBEExternalId,goToRelatedBAExternalId], 'redirectUrl': '#/financials/financials-transactions-report'}
		                 ];	
		}
		
		var searchCriteria ={};
     	searchCriteria.criteria ={};
    
     	if($scope.goToRelatedBAExternalId!=null && $scope.goToRelatedBAExternalId !=undefined && $scope.goToRelatedBAExternalId !=''){
     		searchCriteria.criteria["externalId"]= { "operator": "=","columnValue":  "'"+$scope.goToRelatedBAExternalId+"'"} ;
     	}
     	var paginationForFirst = getAllContent('','');
     	searchCriteria.pageRequestCriteria = getPageRequestCriteria(paginationForFirst);
		var promise =fetchGroupServ.getBillingAccounts(searchCriteria);
     	promise.then(function(data){
     		var billingAccList =transformInnerTableData(data,$scope);
     		if(billingAccList != null && billingAccList[0] !=null)
     	{
     			var billingAccount = billingAccList[0];
     	        console.log(billingAccount);
     			$scope.billingAccount = billingAccount.subscriptionId;
     			$scope.status = billingAccount.status;
     			$scope.effectiveDate = billingAccount.coverageBeginsOn;
     			$scope.termDate = billingAccount.coverageEndsOn;
     	}
     	},function(error){
     		console.log("Error while getting billing accoutns");
     	});
		
	};
	var afterFail = function(){}
	
	$scope.pageBack = function(){
	   var defaultPageBackURL  = 'entities/group';
	   var pageBackURL = EventBusSrvc.subscribeAndInvalidatePayload('pageBackURL');
	   if(pageBackURL != undefined && pageBackURL != '' && pageBackURL != null ){
		   defaultPageBackURL = pageBackURL;
	   }
	   
	   if(defaultPageBackURL=='entities/group' || defaultPageBackURL=='financials/payments'){
		   $scope.publishPageBackFilters($scope.pageBackFilters);		   
	   }
	   
	   $location.path(defaultPageBackURL);
	   $location.replace();
	   if(defaultPageBackURL=='entities/group'){
		   $scope.updateLeftNav('Groups');
	   }else if(defaultPageBackURL=='system/eligibility/group')
		   $scope.updateLeftNav('Eligibility');
   }
	
	$scope.addressCheck = false;
	$scope.setAddressCheck = function(){
		if($scope.addressCheck){
			$scope.addressCheck = false;
		}else{
			$scope.addressCheck = true;
		}
	}
	
	
	$scope.contactCheck=false;
	   $scope.setContactDetailCheck=function(){
		   if($scope.contactCheck){
			   $scope.contactCheck=false;
		   }
		   else{
			   $scope.contactCheck=true;
		   }
	   }
	   
	   $scope.fetchAssociatedEntityForBillCycle=function(entityId,name,billingAccountIdentity,baExternalId){
			//$location.path('entities/group/group-bill-cycles-details');
		   $scope.publishPageBackFilters($scope.pageBackFilters);
		   $location.path('system/associated-entities');
		   $location.replace();
			$scope.entityId =entityId ;
			$scope.updateLeftNav('Bill Cycles');
			var param={"entityId":billingAccountIdentity, "entityExternalId":entityId, "entityName":name ,"baExternalId" : baExternalId};
			EventBusSrvc.publish('fetchIdentityForAssociatedEntity',param);
			EventBusSrvc.publish('pageBackURL', 'entities/group');
		};
	
}];

var transformInnerTableData = function(data,$scope){
	//alert(data);
	
	console.log("Inside transform Inner Table data");
	var entitiesInnerDataList = [];
	angular.forEach(data, function(value){
		var entityInnerDataObj = {};
        entityInnerDataObj.subscriptionId = value.externalId;
        entityInnerDataObj.billingAccountIdentity = value.identity;
        entityInnerDataObj.entityId = value.owner.externalId;
        entityInnerDataObj.name = value.owner.profile.displayName;
        entityInnerDataObj.parentGroup = value.owner.profile.parentOrg;
        entityInnerDataObj.status = value.owner.status;
        entityInnerDataObj.tenantId = value.owner.tenantId;
        entityInnerDataObj.itemRecordId = value.owner.itemRecordId;
        entityInnerDataObj.identity = value.owner.identity;
        entityInnerDataObj.lastupdated = value.owner.auditInfo.modifiedAt.date;
        entityInnerDataObj.subscriptionStatus = value.subscriptionstatus;
       // entityInnerDataObj.value=value;
        if (value.billingAccountPeriod && value.billingAccountPeriod.beginsOn) {
            entityInnerDataObj.coverageBeginsOn = $scope.toUTCDate(value.billingAccountPeriod.beginsOn.date);
        }
        if (value.billingAccountPeriod && value.billingAccountPeriod.endsOn) {
            entityInnerDataObj.coverageEndsOn = $scope.toUTCDate(value.billingAccountPeriod.endsOn.date);
        }
      
    	entitiesInnerDataList.push(entityInnerDataObj);
	});
	return entitiesInnerDataList; 
}

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "manageGroupCntrl",
	"id" : hcentive.WFM.manageGroupCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "manageGroupCntrl",
	"id" : hcentive.WFM.manageGroupCntrl	
});
