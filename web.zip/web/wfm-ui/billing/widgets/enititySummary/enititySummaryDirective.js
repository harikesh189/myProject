hcentive.WFM.enititySummaryDirective=[function(){
	
	return {
		restrict : 'EA',
		templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/enititySummary/broker-summary.html")},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};
	
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
		"name" : "enititysummarydirective",
		"id" : hcentive.WFM.enititySummaryDirective
	});
	
                                  
                                  
                                  
                                  
                                  
                      