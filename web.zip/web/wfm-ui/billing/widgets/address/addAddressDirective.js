/**
 * 
 */

hcentive.WFM.addaddressdirective=[function(){
 
 return {
  restrict : 'E',
  scope: {
	  addressarray:'=',
	  addresscount:'=',
	  formname:'@',
	  submitted : '@'},
  templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/address/address.html")},
  link : function(scope, iElement, iAttrs, ctrl) {
   scope.attrs = iAttrs;
  }
 };
 
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addaddressdirective",
	"id" : hcentive.WFM.addaddressdirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
		"name" : "addaddressdirective",
		"id" : hcentive.WFM.addaddressdirective
	});
                                  
                                  
                                  
                                  
                                  
                            