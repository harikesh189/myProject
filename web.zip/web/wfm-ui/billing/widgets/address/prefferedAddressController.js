/**
 * 
 */
hcentive.WFM.prefferedAddressCntrl=['$scope','$location','EventBusSrvc','$filter','$compile','$element',
                             function($scope,$location,EventBusSrvc,$filter,$compile,$element){
	
	var addressListSize = 0;
	if($scope.addressarray!=undefined){
   	for(var i = 0; i < $scope.addressarray.length; i++) {
		  if($scope.addressarray[i] != null){
			  addressListSize ++;
		  }
	   }
	}
   //	$scope.displayCount = addressListSize;
	 
	$scope.setDisplayCount = function(){
	        var displayCount = $scope.addresscount;
	        if($scope.addressarray){
	         for(var i = 0; i < $scope.addressarray.length; i++) {
	          if($scope.addressarray[i] === undefined){
	           displayCount--;
	          }
	        }
	        }
	        $scope.displayCount = displayCount+1;
	       }
	    
	    $scope.setDisplayCount();
   	
   	
	 $scope.setPrefferedAddress=function(position){
		 angular.forEach($scope.addressarray, function(value, index) {
			 if(value!=null || value!=undefined){
			    if (position != index) 
			    	$scope.addressarray[index].isPrefferedAddress = false;
			 }  });
		 $scope.addressarray[position].isPrefferedAddress = true;
		
	 }
	 
	 
	 $scope.deleteAddress = function(index) {
		   var id="addressDiv"+index;
		   $( "#"+id).remove();
		   $scope.addressarray[index] = undefined;
		   var count = 0;
		      for(var i = 0; i < $scope.addressarray.length; i++) {
		       if($scope.addressarray[i]){
		        var element =  angular.element('#addressForm_'+(i+1));
		        if(element!=undefined && element[0] != undefined){
		        count++;
		        $('#addressForm_'+(i+1)).text(count);
		       }
		       }
		     }
			
		   }
	 
	 $scope.checkPrefferedAddress=function(addressArray){
		  var AddressFlag = 0;
			for(var i = 0; i<addressArray.length; i++)
			{
			 if(addressArray[i]!=null || addressArray[i]!=undefined){
				if(addressArray[i].isPrefferedAddress)
				{
					AddressFlag = 1;
				}
			 }
			}		
			if(AddressFlag == 0)
			{
				return false;
			}
		 return true;
	 }
	 
}];


hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "prefferedAddressCntrl",
	"id" : hcentive.WFM.prefferedAddressCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "prefferedAddressCntrl",
	"id" : hcentive.WFM.prefferedAddressCntrl	
});