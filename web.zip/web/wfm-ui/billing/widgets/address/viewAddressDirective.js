/**
 * 
 */

hcentive.WFM.viewaddressdirective=[function(){
	
	return {
		restrict : 'E',
		templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/address/viewaddress.html")},
		link : function(scope, iElement, iAttrs, ctrl) {

			var preferedIndex = 0;
			   var  count = 1;
			   if(scope.addressesList && scope.addressesList.address && scope.addressesList.address != undefined && scope.addressesList.address.length >0){
			   for(var i = 0; i < scope.addressesList.address.length; i++) {
			    if(scope.addressesList.address[i].preferred){
			     preferedIndex = i;
			    }else{
			     count = count +1;
			     scope.addressesList.address[i].displayCount= count;
			    }
			   }
			   scope.addressesList.address[preferedIndex].displayCount = 1;
			   }
			  
		}
	};
	
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "viewaddressdirective",
	"id" : hcentive.WFM.viewaddressdirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
		"name" : "viewaddressdirective",
		"id" : hcentive.WFM.viewaddressdirective
	});
                                  
                                  
                                  
                                  
                                  
                            