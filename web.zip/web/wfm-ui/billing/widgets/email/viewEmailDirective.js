/**
 * 
 */

hcentive.WFM.viewemaildirective = [ function() {

	return {
		restrict : 'E',
		templateUrl : function(elem, attr) {
			return getTemplateUrl(attr, "widgets/email/viewemail.html")
		},
		link : function(scope, iElement, iAttrs, ctrl) {
			var preferedIndex = 0;
			   var  count = 1;
			   if(scope.emailList && scope.emailList.email && scope.emailList.email != undefined && scope.emailList.email.length >0){
			   for(var i = 0; i < scope.emailList.email.length; i++) {
			    if(scope.emailList.email[i].preferred){
			     preferedIndex = i;
			    }else{
			     count = count +1;
			     scope.emailList.email[i].displayCount= count;
			    }
			   }
			   scope.emailList.email[preferedIndex].displayCount = 1;
			  }}
	};

} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "viewemaildirective",
	"id" : hcentive.WFM.viewemaildirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "viewemaildirective",
	"id" : hcentive.WFM.viewemaildirective
});
