/**
 * 
 */
hcentive.WFM.prefferedEmailCntrl=['$scope','$location','EventBusSrvc','$filter','$compile', '$element',
                             function($scope,$location,EventBusSrvc,$filter,$compile,$element){
	
	//$scope.displayCount = $scope.$parent.$parent.emailcount;
	var emailListSize = 0;
	if($scope.emailarray!=undefined){
   	for(var i = 0; i < $scope.emailarray.length; i++) {
		  if($scope.emailarray[i] != null){
			  emailListSize ++;
		  }
	   }
	}
   	
    $scope.setDisplayCount = function(){
        var displayCount = $scope.emailcount;
        if($scope.emailarray){
         for(var i = 0; i < $scope.emailarray.length; i++) {
          if($scope.emailarray[i] === undefined){
           displayCount--;
          }
        }
        }
        $scope.displayCount = displayCount+1;
       }
    
    $scope.setDisplayCount();
	
	 $scope.setPrefferedEmail=function(position){
		 angular.forEach($scope.emailarray, function(value, index) {
			 if(value!=null || value!=undefined){
			    if (position != index) 
			    	$scope.emailarray[index].isPrefferedEmail = false;
			 }
			  });
		 $scope.emailarray[position].isPrefferedEmail = true;
		
	 }
	 
	 $scope.deleteEmail = function(index){
	     var id="emailDiv"+index;
	     $( "#"+id).remove();
	     $scope.emailarray[index] = undefined;	
	   //  delete $scope.emailForm;
	     
	      var count = 0;
	      for(var i = 0; i < $scope.emailarray.length; i++) {
	       if($scope.emailarray[i]){
	        var element =  angular.element('#emailForm_'+(i+1));
	        if(element!=undefined && element[0] != undefined){
	        count++;
	        $('#emailForm_'+(i+1)).text(count);
	       }
	       }
	     }
	 };
	   
	   $scope.checkPrefferedEmail=function(EmailArray){
			var EmailFlag = 0;
			for(var i = 0; i<EmailArray.length; i++)
			{
				if(EmailArray[i]!=null || EmailArray[i]!=undefined){
				if(EmailArray[i].isPrefferedEmail)
				{
					EmailFlag = 1;
				}
				}
			}		
			if(EmailFlag == 0)
			{
				return false;
			}
			return true;
	   }
}];


hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "prefferedEmailCntrl",
	"id" : hcentive.WFM.prefferedEmailCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "prefferedEmailCntrl",
	"id" : hcentive.WFM.prefferedEmailCntrl	
});