/**
 * 
 */

hcentive.WFM.addemaildirective = [ function() {
	 
	 return {
	  restrict : 'E',
	  scope: {
		  emailarray:'=',
		  emailcount:'=',
		  formname:'@',
		  submitted : '@'},
	  templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/email/email.html")},
	  link : function(scope, iElement, iAttrs, ctrl) {
	   scope.attrs = iAttrs;
	  }
	 };
	 
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addemaildirective",
	"id" : hcentive.WFM.addemaildirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "addemaildirective",
	"id" : hcentive.WFM.addemaildirective
});
