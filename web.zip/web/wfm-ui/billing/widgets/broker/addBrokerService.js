hcentive.WFM.addBrokerServ = [ '$http', 'RESTSrvc',function($http, RESTSrvc) {

var setBroker=function(param,data,afterSucess,afterFail){
		
		RESTSrvc.postForData('importGatewayPort',param,data,null,afterSucess,afterFail);
	};
	
	
var viewBroker=function(param,afterSucess,afterFail){
		RESTSrvc.getForData('itemDetailsService',param,null,afterSucess,afterFail);
	};
		
	return {
		setBroker : setBroker,
		viewBroker : viewBroker
	};
	
}];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "addBrokerServ",
	"id" : hcentive.WFM.addBrokerServ
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "addBrokerServ",
	"id" : hcentive.WFM.addBrokerServ
});