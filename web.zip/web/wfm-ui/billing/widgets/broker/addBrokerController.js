/**
 * 
 */
hcentive.WFM.manageBrokerCntrl = [
		'$scope',
		'$location',
		'addBrokerServ',
		'EventBusSrvc',
		'$filter',
		'$compile',
		function($scope, $location, addBrokerServ, EventBusSrvc, $filter,
				$compile) {

			$scope.datePattern = /^(1[0-2]|0[0-9])[/]([0-2][0-9]|3[0-1])[/]([0-9]{4})$/;
			$scope.businessEntity = {};
			$scope.contactNumberArray = {};
			$scope.contactPersonName = {};
			$scope.ContactPersonEmailIdArray = {};
			$scope.AddressArray = [];
			$scope.ContactArray = [];
			$scope.beIdentity = null;
			$scope.EmailArray = [];
			$scope.isPreferredAddressChecked = true;
			$scope.isPreferredContactDetailChecked = true;
			$scope.isPreferredEmailDetailChecked = true;

			var afterSucess = function(data) {

				if (data && data != 'Success') {
					$("#message").html(
							'<font color="red"><b>' + data + '</font></b>');
					$('html, body').animate({
						'scrollTop' : $('#message').offset().top
					}, 500);
					return;
				}

				var entity = data;
				$location.path('entities/broker');
				$location.replace();
			}
			$scope.updateLeftNav('Brokers');
			var afterFail = function() {
			}

			$scope.addBroker = function(isValid) {
				// traverse the whole address array to see if any of the address
				// selected is preferred or not.
				if ($scope.AddressArray.length == 0
						|| $scope.AddressArray == undefined) {
					$scope.isPreferredAddressChecked = true;
				}

				else {
					$scope.isPreferredAddressChecked = $scope
							.checkPrefferedAddress($scope.AddressArray);
				}
				// traverse the whole contact array to see if any of the contact
				// selected is preferred or not.
				if ($scope.ContactArray.length == 0
						|| $scope.ContactArray == undefined) {
					$scope.isPreferredContactDetailChecked = true;
				} else {
					$scope.isPreferredContactDetailChecked = $scope
							.checkPrefferedContact($scope.ContactArray);
				}
				// traverse the whole email array to see if any of the email
				// selected is preferred or not.
				if ($scope.EmailArray.length == 0
						|| $scope.EmailArray == undefined) {
					$scope.isPreferredEmailDetailChecked = true;
				} else {
					$scope.isPreferredEmailDetailChecked = $scope
							.checkPrefferedEmail($scope.EmailArray);
				}

				$scope.submitted = true;
				$scope.termDateError = false;
				if ($scope.effectiveDate != null
						&& $scope.effectiveDate != undefined) {

					var effectiveDate = new Date($scope.effectiveDate);
					if ($scope.terminationDate != null
							&& $scope.terminationDate != undefined) {
						var terminationDate = new Date($scope.terminationDate);
						if (effectiveDate.getTime() > terminationDate.getTime()) {
							$scope.termDateError = true;

						}
					}

				}
				if ($scope.termDateError || !isValid) {

					return false;
				}

				if (!$scope.isPreferredAddressChecked
						|| !$scope.isPreferredContactDetailChecked
						|| !$scope.isPreferredEmailDetailChecked) {
					return false;
				}
				var param = {};
				var agentType = $scope.businessEntity.agent.agentClassification;
				if (agentType != null && agentType != undefined
						&& agentType != "") {
					if (agentType == 'General Agent') {
						$scope.businessEntity.agent.agentClassification = 'GENERAL';
					} else {
						$scope.businessEntity.agent.agentClassification = agentType
								.toUpperCase();
					}
				} else {
					$scope.businessEntity.agent.agentClassification = 'BROKER';
				}

				// initializing the scope parameters
				$scope.businessEntity.agent.contactNumbers = {};
				$scope.businessEntity.agent.contactNumbers.contactNumber = {};
				$scope.businessEntity.agent.addresses = {};
				$scope.businessEntity.agent.addresses.address = {};
				$scope.businessEntity.agent.emailIds = {};
				$scope.businessEntity.agent.emailIds.email = {};

				$scope.businessEntity.agent.effectiveDate = $filter('date')(
						new Date($scope.effectiveDate), $scope.beTimeFormat);
				if ($scope.terminationDate != null
						&& $scope.terminationDate != undefined)
					$scope.businessEntity.agent.terminationDate = $filter(
							'date')(new Date($scope.terminationDate),
							$scope.beTimeFormat);

				// creating the empty array lists
				var contactPersonList = {};
				var contactPerson = [];
				var contactList = [];
				var emailIdList = [];
				var addressList = [];
				var businessEntityList = [];

				var billable = $scope.businessEntity.agent.billable;
				if (billable == 'Yes') {
					$scope.businessEntity.agent.billable = 'true';
					$scope.businessEntity.agent.invoiceable = 'true';
				} else {
					$scope.businessEntity.agent.billable = 'false';
					$scope.businessEntity.agent.invoiceable = 'false';
				}

				if ($scope.businessEntity.tin != undefined) {
					$scope.businessEntity.agent.identifiers = {};
					$scope.businessEntity.agent.identifiers.identifier = [];
					var idType = {
						id : $scope.businessEntity.tin,
						idQualifier : "TIN"
					};
					$scope.businessEntity.agent.identifiers.identifier
							.push(idType);
				}

				$scope.businessEntity.agent.addresses.address = [];
				$scope.businessEntity.agent.emailIds.email = [];

				angular.forEach($scope.AddressArray, function(value, key) {
					if (value != null || value != undefined) {
						var obj = {};
						obj.category = value.category.toUpperCase();
						obj.state = value.state;
						obj.city = value.city;
						obj.street1 = value.street1;
						obj.street2 = value.street2;
						obj.country = value.country;
						obj.zipcode = value.zipcode;
						if (value.isPrefferedAddress) {
							obj.preferred = value.isPrefferedAddress;
						} else
							obj.preferred = false;
						if (value.state != '' || value.city != ''
								|| value.street1 != '' || value.country != ''
								|| value.street2 != '' || value.zipcode != '') {
							$scope.businessEntity.agent.addresses.address
									.push(obj);
						}
					}
				});

				angular.forEach($scope.EmailArray, function(value, key) {
					if (value != null || value != undefined) {
						var emailObj = {};
						emailObj.category = value.category.toUpperCase();
						emailObj.emailId = value.emailId;
						if (value.isPrefferedEmail) {
							emailObj.preferred = value.isPrefferedEmail;
						} else {
							emailObj.preferred = false;
						}
						if (value.category != '' || value.emailId != '') {
							$scope.businessEntity.agent.emailIds.email
									.push(emailObj);
						}
					}
				});

				$scope.businessEntity.agent.contactNumbers.contactNumber = [];
				angular
						.forEach(
								$scope.ContactArray,
								function(value, key) {
									if (value != null || value != undefined) {
										var contactObj = {};
										contactObj.category = value.category
												.toUpperCase();
										contactObj.type = value.type;
										contactObj.number = value.contactNumber;
										contactObj.smsEnabled = value.smsEnabled;

										if (value.isPrefferedContact) {
											contactObj.preferred = value.isPrefferedContact;
										} else
											contactObj.preferred = false;
										if (value.category != ''
												|| value.type != ''
												|| value.contactNumber != ''
												|| value.smsEnabled != '') {
											$scope.businessEntity.agent.contactNumbers.contactNumber
													.push(contactObj);
										}
									}
								});

				
				 /* if($scope.businessEntity.agent.name != null &&
				  $scope.businessEntity.agent.name != undefined){
				 * if($scope.businessEntity.agent.name.lastName== null &&
				 * $scope.businessEntity.agent.name.lastName == undefined ) {
				 * $scope.businessEntity.agent.name.lastName='';
				 *  } if($scope.businessEntity.agent.name.firstName== null &&
				 * $scope.businessEntity.agent.name.firstName == undefined ) {
				 * $scope.businessEntity.agent.name.firstName='';
				 *  }
				 * 
				 * if($scope.businessEntity.agent.name.middleName== null &&
				 * $scope.businessEntity.agent.name.middleName == undefined ) {
				 * $scope.businessEntity.agent.name.middleName='';
				 *  }
				 *  }*/
				 

				if ($scope.businessEntity.agent.addresses.address.length == 0) {
					$scope.businessEntity.agent.addresses = null;
				}
				if ($scope.businessEntity.agent.contactNumbers.contactNumber.length == 0) {
					$scope.businessEntity.agent.contactNumbers = null;
				}
				if ($scope.businessEntity.agent.emailIds.email.length == 0) {
					$scope.businessEntity.agent.emailIds = null;
				}
              if($scope.businessEntity.agent.name &&(($scope.businessEntity.agent.name.firstName == undefined || $scope.businessEntity.agent.name.firstName =='')&& ($scope.businessEntity.agent.name.middleName == ''||$scope.businessEntity.agent.name.middleName == undefined||$scope.businessEntity.agent.name.lastName == ''|| $scope.businessEntity.agent.name.lastName == undefined))){
            	  $scope.businessEntity.agent.name=null;
              }
				var data = $scope.businessEntity;
				var param = {
					"type" : 'be',
					"pageType" : $scope.pageType
				};
				addBrokerServ.setBroker(param, data, afterSucess, afterFail);

			}

			$scope.viewBrokerDetails = function(index) {

				var brokerObj = $scope.brokerList[index];
				var id = brokerObj.itemRecordId;
				var beIdentity = brokerObj.identity;
				var beExternalId = brokerObj.entityId;
				$scope.fetchBillingAccount(beExternalId).then(function(success){
				   	   success.forEach(function(value){
				   		EventBusSrvc.publish('billingAccountExternalId',value.externalId);
					   		  
					   	   });
					   	},function(error){
					   		console.log("Error while getting billing accoutns");
					   	});
				
				EventBusSrvc.publish('beAuditInfo', getAuditInfo(brokerObj));
				$scope.publishPageBackFilters($scope.pageBackFilters);
				$scope.beIdentity = beIdentity;
				$scope.beExternalId = beExternalId;
				EventBusSrvc.publish('beIdentity', $scope.beIdentity);
				EventBusSrvc.publish('pageBackFilters', $scope.filterObject);
				var param = {
					"id" : id,
					"type" : 'be'
				};
				addBrokerServ.viewBroker(param, afterSucessBrokerDetails,
						afterFail);
				// $scope.updateLeftNav('Broker');

			}

			var afterSucessBrokerDetails = function(data) {
				$scope.businessEntity = data.item;
				EventBusSrvc.publish('brokerDetails', $scope.businessEntity);
				var params = EventBusSrvc
						.subscribeAndInvalidatePayload('EntityParams');
				if (params && params != undefined) {
					// $scope.businessEntity.createdOn=params.createdon;
					// $scope.businessEntity.createdBy=params.createdby;
					$scope.businessEntity.source = params.source;
				}
				$scope.businessEntity.source = data.itemMetaInfo.tenant;
				EventBusSrvc
						.publish('goToRelatedBEIdentity', $scope.beIdentity);
				EventBusSrvc.publish('goToRelatedBEExternalId',
						$scope.beExternalId);
				var billable = $scope.businessEntity.agent.billable;
				EventBusSrvc.publish('billable', billable);
				if ($scope.businessEntity.agent.name != null
						&& $scope.businessEntity.agent.name != undefined)
					var WriteOffJson = {
						'id' : $scope.businessEntity.agent.id.id,
						'firstName' : $scope.businessEntity.agent.name.firstName,
						'lastName' : $scope.businessEntity.agent.name.lastName
					};
				EventBusSrvc.publish('WriteOffParameters', WriteOffJson);
				$location.path('entities/broker/broker-details');
				$location.replace();
			}

			$scope.addresscount = -1;

			$scope.pageBack = function() {
				EventBusSrvc.publish('pageBackFilters', $scope.pageBackFilters);
				$location.path('entities/broker');
				$location.replace();
			}

			$scope.getBrokerDetails = function(pageType) {
				// $scope.updateLeftNav('Broker');
				$scope.pageType = pageType;
				var goToRelatedBEIdentity = EventBusSrvc
						.subscribeAndInvalidatePayload('goToRelatedBEIdentity');
				var goToRelatedBEExternalId = EventBusSrvc
						.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
				$scope.goToRelatedBEExternalId = goToRelatedBEExternalId;
				$scope.pageBackFilters = EventBusSrvc
						.subscribeAndInvalidatePayload('pageBackFilters');
				$scope.businessEntity = EventBusSrvc.subscribe('brokerDetails');

				// var beAuditInfo =
				// EventBusSrvc.subscribeAndInvalidatePayload('beAuditInfo');
				var beAuditInfo = EventBusSrvc.subscribe('beAuditInfo');
				$scope.businessEntity.auditInfo = beAuditInfo;
				var billingAccountExternalId=EventBusSrvc
				.subscribeAndInvalidatePayload('billingAccountExternalId');
				$scope.billingAccountExternalId=billingAccountExternalId;
				console.log($scope.billingAccountExternalId);
				if ($scope.businessEntity.agent.billable) {
					$scope.goToRelatedItemList = [
							{
								'name' : 'Remittance',
								'eventValue' : [ goToRelatedBEExternalId,
								                 billingAccountExternalId],
								'redirectUrl' : '#/financials/remits'
							},
							{
								'name' : 'Manual Adjustments',
								'eventValue' : [ goToRelatedBEExternalId,
								                 billingAccountExternalId],
								'redirectUrl' : '#/financials/manual-adjustments/refunds-payments'
							},
							{
								'name' : 'Accounts',
								'eventValue' : [ goToRelatedBEExternalId,
								                 billingAccountExternalId],
								'redirectUrl' : '#/financials/account-details'
							},
							{
								'name' : 'FT Transactions',
								'eventValue' : [ goToRelatedBEExternalId,
								                 billingAccountExternalId],
								'redirectUrl' : '#/financials/financials-transactions-report'
							} ];
				} else {
					$scope.goToRelatedItemList = [
							{
								'name' : 'Remittance',
								'eventValue' : [ goToRelatedBEExternalId,
								                 billingAccountExternalId ],
								'redirectUrl' : '#/financials/remits'
							},
							{
								'name' : 'Accounts',
								'eventValue' : [ goToRelatedBEExternalId,
								                 billingAccountExternalId ],
								'redirectUrl' : '#/financials/account-details'
							},
							{
								'name' : 'FT Transactions',
								'eventValue' : [ goToRelatedBEExternalId,
								                 billingAccountExternalId],
								'redirectUrl' : '#/financials/financials-transactions-report'
							} ];
				}
				// $scope.businessEntity=EventBusSrvc.subscribe('brokerDetails');
				if ($scope.businessEntity.agent != ''
						&& $scope.businessEntity.agent != undefined) {
					if ($scope.businessEntity.agent.addresses != null) {
						$scope.addressesList = $scope.businessEntity.agent.addresses;
					}
					if ($scope.businessEntity.agent.contactNumbers != null) {
						$scope.contactsList = $scope.businessEntity.agent.contactNumbers.contactNumber;
					}
					if ($scope.businessEntity.agent.emailIds != null) {
						$scope.emailList = $scope.businessEntity.agent.emailIds;
					}
				}
				if ($scope.businessEntity.agent.name
						&& $scope.businessEntity.agent.name.firstName
						&& $scope.businessEntity.agent.name.lastName)
					var name = $scope.businessEntity.agent.name.firstName + ' '
							+ $scope.businessEntity.agent.name.lastName;

				var adjustmentJson = {};
				if (name && name != undefined) {
					var adjustmentJson = {
						'id' : $scope.businessEntity.agent.id.id,
						'name' : name,
						'type' : 'Broker',
						'identity' : goToRelatedBEIdentity,
						'businessEntityType' : 'Broker'
					};
					EventBusSrvc.publish('EntityType', adjustmentJson);
				} else {
					var adjustmentJson = {
						'id' : $scope.businessEntity.agent.id.id,
						'name' : '',
						'type' : 'Broker',
						'identity' : goToRelatedBEIdentity,
						'businessEntityType' : 'Broker'
					};
					EventBusSrvc.publish('EntityType', adjustmentJson);
				}
				if ($scope.businessEntity.agent.contactPersons != undefined) {
					$scope.contactPersonList = $scope.businessEntity.agent.contactPersons.contactPerson.contactNumbers;
					$scope.name = $scope.businessEntity.agent.contactPersons.contactPerson.name;
				}

				if (pageType != undefined && pageType == 'Edit') {
					$scope.populateAddress();
					$scope.populateContacts();
					$scope.populateEmails();
					$scope.contactCheck = true;
					/*
					 * $scope.contactNumberArray = {"category"
					 * :"1234","workNumber":"","faxNumber":"2178403512","mobileNumber":"","homeNumber":"888-356-7871","ext":"","smsEnabled":"","faxExt":""};
					 * $scope.contactPersonName={"firstName":"BELLEMARE","lastName":"YVON","middleName":"K"};
					 * $scope.ContactPersonEmailIdArray={"emailId":"Bellemare.yvon@gmail.com"};
					 */
					$scope.effectiveDate = $scope.businessEntity.agent.effectiveDate;
					$scope.terminationDate = $scope.businessEntity.agent.terminationDate;
					$scope.setBrokerFormName('brokerForm');
				}

			}

			$scope.addAddress = function() {
				$scope.addresscount = $scope.addresscount + 1;
				var addressObj = {
					"category" : "",
					"street2" : "",
					"state" : "",
					"country" : "",
					"street1" : "",
					"city" : "",
					"zipcode" : "",
					"isPrefferedAddress" : false
				};
				$scope.AddressArray[$scope.addresscount] = addressObj;
				var id = "addressDiv" + $scope.addresscount;
				angular
						.element(document.getElementById('addressBoxDiv'))
						.append(
								$compile(
										"<addaddressdirective id="
												+ id
												+ "  addresscount="
												+ $scope.addresscount
												+ " formname='brokerForm' addressarray='AddressArray' submitted={{submitted}}></addaddressdirective>")
										($scope));
			}
			$scope.contactcount = -1;

			$scope.addContact = function() {
				$scope.contactcount = $scope.contactcount + 1;
				var contactObj = {
					"category" : "",
					"type" : "",
					"contactNumber" : "",
					"smsEnabled" : false,
					"isPrefferedContact" : false
				};
				$scope.ContactArray[$scope.contactcount] = contactObj;
				var id = "contactDiv" + $scope.contactcount;
				angular
						.element(document.getElementById('contactBoxDiv'))
						.append(
								$compile(
										"<addcontactdirective contactcount="
												+ $scope.contactcount
												+ " id="
												+ id
												+ " formname='brokerForm' contactarray='ContactArray' submitted={{submitted}}></addcontactdirective>")
										($scope));
			}

			$scope.emailcount = -1;
			$scope.addEmail = function() {
				$scope.emailcount = $scope.emailcount + 1;
				var emailObj = {
					"category" : "",
					"emailId" : "",
					"isPrefferedEmail" : false
				};
				$scope.EmailArray[$scope.emailcount] = emailObj;
				var id = "emailDiv" + $scope.emailcount;

				angular
						.element(document.getElementById('emailBoxDiv'))
						.append(
								$compile(
										"<addemaildirective id="
												+ id
												+ " emailcount="
												+ $scope.emailcount
												+ "  formname='brokerForm' emailarray='EmailArray' submitted={{submitted}}></addemaildirective>")
										($scope));
			}

			$scope.populateAddress = function() {
				if ($scope.addressesList && $scope.addressesList != undefined) {
					angular
							.forEach(
									$scope.addressesList.address,
									function(value, key) {
										$scope.addresscount = $scope.addresscount + 1;
										$scope.AddressArray[$scope.addresscount] = entityAddressTransformer(
												value,
												$scope.addressesList.address.length);
										var id = "addressDiv"
												+ $scope.addresscount;
										angular
												.element(
														document
																.getElementById('addressBoxDiv'))
												.append(
														$compile(
																"<addaddressdirective id="
																		+ id
																		+ " addresscount="
																		+ $scope.addresscount
																		+ " formname='brokerForm' addressarray='AddressArray'></addaddressdirective>")
																($scope));
									});
				}
			}

			$scope.populateContacts = function() {
				if ($scope.contactsList && $scope.contactsList != undefined) {
					angular
							.forEach(
									$scope.contactsList,
									function(value, key) {
										$scope.contactcount = $scope.contactcount + 1;
										$scope.ContactArray[$scope.contactcount] = entityContactsTransformer(
												value,
												$scope.contactsList.length);
										var id = "contactDiv"
												+ $scope.contactcount;
										angular
												.element(
														document
																.getElementById('contactBoxDiv'))
												.append(
														$compile(
																"<addcontactdirective id="
																		+ id
																		+ "  contactcount="
																		+ $scope.contactcount
																		+ " formname='brokerForm' contactarray='ContactArray'></addcontactdirective>")
																($scope));
									});
				}
			}

					$scope.populateEmails = function() {
						if ($scope.emailList && $scope.emailList != undefined) {
							angular
									.forEach(
											$scope.emailList.email,
											function(value, key) {
												$scope.emailcount = $scope.emailcount + 1;
												$scope.EmailArray[$scope.emailcount] = entityEmailsTransformer(
														value,
														$scope.emailList.email.length);
												var id = "emailDiv"
														+ $scope.emailcount;
												angular
														.element(
																document
																		.getElementById('emailBoxDiv'))
														.append(
																$compile(
																		"<addemaildirective id="
																				+ id
																				+ " emailcount="
																				+ $scope.emailcount
																				+ " formname='brokerForm' emailarray='EmailArray'></addemaildirective>")
																		($scope));
											})
						}
					},

					$scope.contactCheck = false;
			$scope.setContactDetailCheck = function() {
				if ($scope.contactCheck) {
					$scope.contactCheck = false;
				} else {
					$scope.contactCheck = true;
				}
			},

			$scope.setFormName = function(formName) {
				$scope.pageType = 'Add';
				$scope.formName = formName;
			}
			$scope.setBrokerFormName = function(formName) {
				$scope.formName = formName;
			}

		} ];

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "manageBrokerCntrl",
	"id" : hcentive.WFM.manageBrokerCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "manageBrokerCntrl",
	"id" : hcentive.WFM.manageBrokerCntrl
});