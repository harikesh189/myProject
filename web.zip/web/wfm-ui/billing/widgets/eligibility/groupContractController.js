hcentive.WFM.GroupContractCtrl = ('$scope', 'EventBusSrvc', 'ContractSrvc','GroupServ','$location','fetchGroupServ' , function ($scope, EventBusSrvc, ContractSrvc,GroupServ,$location,fetchGroupServ) {
	$scope.pagination = defaultPagination('auditInfo.modifiedAt','desc');
	
	$scope.groupCustExtId = EventBusSrvc.subscribeAndInvalidatePayload('groupCustExtId');
	$scope.billingAccountIdentity = EventBusSrvc.subscribeAndInvalidatePayload('billingAccountIdentity');
	$scope.groupCustItemRecordId = EventBusSrvc.subscribeAndInvalidatePayload('groupCustItemRecordId');
	
    $scope.headerGroupColumns = [
        
		{'isSortable': 'yes', 'key': 'subscriberId', 'desc': 'Subscriber ID', 'contentType': 'String', 'sortableKey': 'subscriberExtId'},
        {'isSortable': 'yes', 'key': 'name', 'desc': 'Subscriber Name', 'contentType': 'String', 'sortableKey': 'subscriberName'},
        {'isSortable': 'yes', 'key': 'employerGroupId', 'desc': 'Group ID', 'contentType': 'String', 'sortableKey': 'employerGroupId'},
        {'isSortable': 'yes', 'key': 'employerGroupName', 'desc': 'Group Name', 'contentType': 'String', 'sortableKey': 'employerGroupName'},
		{'isSortable': 'yes', 'key': 'subscriptionExternalId', 'desc': 'Billing Account', 'contentType': 'String', 'sortableKey': 'subscriptionExternalId'},
        {'isSortable': 'no', 'key': 'action', 'desc': 'Actions', 'contentType': 'html'}

    ];

    $scope.groupContractFilters = [{'filterKey':'employerGroupId','filterType':'TextBox'},
                                   {'filterKey':'subscriberExtId','filterType':'TextBox'},
                                   {'filterKey':'employerGroupName','filterType':'TextBox'},
								   {'filterKey':'subscriptionExternalId','filterType':'TextBox'}
               					   ];
    
	$scope.updateLeftNav('Eligibility');
	
	$scope.fetchdata = function(paginationObj,filterObj){
		var crit =  $scope.getSearchCriteriaForGrpEligContracts(paginationObj, filterObj);
		$scope.fetchGrpEligContractSummaries(angular.toJson(crit));
	}							   
	
	$scope.getSearchCriteriaForGrpEligContracts = function(paginationObj, filterObj) {		
		if (paginationObj) {
			$scope.pagination = paginationObj;
		}
		var groupCustExtId = $scope.groupCustExtId;
		var billingAccountIdentity = $scope.billingAccountIdentity ;
		filterObj.push({'employerGroupId':groupCustExtId});
		filterObj.push({'subscriptionIdentity':billingAccountIdentity});
		

		return $scope.populateSearchCriteria($scope.pagination, filterObj);
	}
	
	$scope.fetchGrpEligContractSummaries = function(criteria) {
		$scope.fetchContractSummaries(criteria, "GroupEligibilityContract", fetchGroupContractSuccess, fetchGroupContractError);
	}	
								   
    var fetchGroupContractError = function (data) {
        $scope.groupContracts = 'No Data';
    };

    var fetchGroupContractSuccess = function (data) {
    	        $scope.pagination.totalElements = data.totalElements;
        $scope.pagination.totalNoPages = data.totalPages;
        $scope.groupContracts = getGroupContracts($scope,data);
        if($scope.groupContracts == null || $scope.groupContracts == undefined || $scope.groupContracts.length <= 0){
			$scope.groupContracts = 'No Data';
		} 
		
    };
	
	$scope.transferToEntity =  function(externalId) {
		$scope.fetchItemRecordIdAndRedirect(externalId, "Group", '/entities/group/group-details', 'system/eligibility/group');
	}
	
	$scope.transferToSubscription = function(beExternalId,baExternalId){
		if(beExternalId) {
			EventBusSrvc.publish('goToRelatedBEExternalId', beExternalId);
		}
		if(baExternalId){
			EventBusSrvc.publish('goToRelatedBAExternalId',baExternalId);
		}
		var searchCriteria ={};
     	searchCriteria.criteria ={};
    
     	if($scope.goToRelatedBAExternalId!=null && $scope.goToRelatedBAExternalId !=undefined && $scope.goToRelatedBAExternalId !=''){
     		searchCriteria.criteria["externalId"]= { "operator": "=","columnValue":  "'"+$scope.goToRelatedBAExternalId+"'"} ;
     	}
     	var paginationForFirst = getAllContent('','');
     	searchCriteria.pageRequestCriteria = getPageRequestCriteria(paginationForFirst);
		var promise =fetchGroupServ.getBillingAccounts(searchCriteria);
     	promise.then(function(data){
     	var id ;	
     	if(data && data[0] && data[0].owner && data[0].owner.itemRecordId ){
     	id=	data[0].owner.itemRecordId;
     	}
     	
		var param = {"id" : id,"type":'be'};
		GroupServ.viewGroup(param,afterSuccessGrpSubscriptionDetail,afterFail);
     	},function(error){
     		console.log("Error while getting billing accoutns");
     	});
	};
	

		var afterSuccessGrpSubscriptionDetail =function(data){
		transformDetailFor_Group(data);
		$location.path('entities/group/financial-summary-Subscription');
		$location.replace();
	};
	
	var transformDetailFor_Group = function(data){
		$scope.businessEntity = data.item;
		if(data.itemMetaInfo){
		$scope.businessEntity.source = data.itemMetaInfo.tenant;
		}
		EventBusSrvc.publish('groupDetails', $scope.businessEntity);
		if($scope.businessEntity.groupCustomer!=undefined && $scope.businessEntity.groupCustomer!=null)
		var WriteOffJson={'id':$scope.businessEntity.groupCustomer.id.id,'firstName':$scope.businessEntity.groupCustomer.establishmentName,'lastName':""};
	    EventBusSrvc.publish('WriteOffParameters',WriteOffJson);
	    EventBusSrvc.publish('billable',$scope.businessEntity.groupCustomer.billable);
	}
	
	var afterFail = function(){}
	});


hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
    "name": "GroupContractCtrl",
    "id": hcentive.WFM.GroupContractCtrl
});