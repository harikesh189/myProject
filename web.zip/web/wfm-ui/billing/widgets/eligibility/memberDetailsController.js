
hcentive.WFM.MemberDetailCtrl = ('$scope', 'EventBusSrvc', 'ContractSrvc', function ($scope, EventBusSrvc, ContractSrvc) {

	$scope.memberDetails = {};
	
	$scope.basicInfo={};
	$scope.smokingInfo={};
	$scope.enrolledPlans=[];
	$scope.addressList=[];
	$scope.contactNumbers={};
	$scope.emailid = '';
	
	var contractCallback = function(newVal,oldVal){
		if (null != newVal) {
			$scope.safeApply($scope,function(){
				$scope.memberDetails = newVal;
				$scope.populateMemberDetails(newVal);
			});
		}
	};
	
	EventBusSrvc.subscribe('memberDetails',$scope, contractCallback);

	$scope.recordId = EventBusSrvc.subscribe('contractRecordId');
	$scope.contractType = EventBusSrvc.subscribe('contractType');
	$scope.backButtonURL = '#/system/eligibility/contract-detail';
	
	$scope.publishDetailsBack = function(){
		$scope.publishContractType();
		$scope.publishContractRecordId();
	}
	
	$scope.publishContractType = function(){
		EventBusSrvc.publish('contractType', $scope.contractType);
	}

	$scope.publishContractRecordId = function(){
		EventBusSrvc.publish('contractRecordId', $scope.recordId);
	}
	
	$scope.populateMemberDetails = function(data){
		var result = getContractMemberSubDetails(data);
		
		$scope.basicInfo = result.basicInfo;
		$scope.smokingInfo = result.smokingInfo;
		$scope.insuranceCoverages = result.insuranceCoverages;
		$scope.insuranceCoverages=getSubsidyInformation(result.insuranceCoverages);
		$scope.addressList = result.addressList;
		$scope.contactNumbers = result.contactNumbers;
		$scope.emailId =result.emailId;
	}	
	
	$scope.isNullOrUndefined = function(obj) {
		return (obj == null || obj == undefined);
	}
	
});
	
	
	hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		"name" : "MemberDetailCtrl",
		"id" : hcentive.WFM.MemberDetailCtrl
	});
