hcentive.WFM.ContractSrvc = [ '$http', 'RESTSrvc',function($http, RESTSrvc) {
	
	var getContractSummaries = function(params,data,successCallback, errorCallback) {
		var resourceUriKey = "fetchAllContractSummaries";
		RESTSrvc.postForData(resourceUriKey,params,data,null,successCallback,errorCallback);
	};
	
	// params ::: "itemType":"eligibility", "id":itemRecordId
	var getContractDetails = function(params,data,successCallback, errorCallback){
		var resourceUriKey = "itemDetailsService";
		RESTSrvc.getForData(resourceUriKey,params,data,successCallback,errorCallback);
	};
	
	var getBE = function(params,data,successCallback, errorCallback){
		var resourceUriKey = "manageBusinessEntitiesPort";
		RESTSrvc.postForData(resourceUriKey,params,data,null,successCallback,errorCallback);
	};
	
	var getHistoricalData=function(params,searchCriteria,successCallback,errorCallback){
		RESTSrvc.postForData('HistoricalDataService',params,searchCriteria,null,successCallback,errorCallback);
	};
	
	var downloadContract = function(params,successCallback,errorCallback){
		RESTSrvc.getForData('downloadItem',params,null,successCallback,errorCallback);
	};
		
	return {
		getContractSummaries : getContractSummaries,
		getContractDetails : getContractDetails,
		getBE:getBE,
		getHistoricalData:getHistoricalData,
		downloadContract:downloadContract
	};
	
}];


// wireup the directive to application

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "ContractSrvc",
	"id" : hcentive.WFM.ContractSrvc
});
