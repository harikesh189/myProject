/**
 * 
 */


hcentive.WFM.IndvHistoricalDataCtrl = ('$scope', '$location','$route','EventBusSrvc', 'ContractSrvc','$filter', function($scope,$location,$route, EventBusSrvc, ContractSrvc,$filter) {
	$scope.pagination = defaultPagination('auditInfo.modifiedAt','desc');
	$scope.headerIndvHistoricalDataColumns =   [{'isSortable':'yes','key':'importedDate','desc':'Last Modified','contentType':'Date'},
	                                         	{'isSortable':'yes','key':'subscriberId','desc':'Subscriber ID','contentType' : 'String', 'sortableKey' : 'subscriberExtId'},
	         								    {'isSortable':'yes','key':'groupId','desc':'Group ID','contentType' : 'String', 'sortableKey' : 'groupExtId'},
	         								    {'isSortable':'yes','key':'market','desc':'Market','contentType' : 'String'},
	         									{'isSortable':'yes','key':'name','desc':'Name','contentType':'String'},
	         									{'isSortable':'yes','key':'dob','desc':'DOB','contentType':'Date'},
	         									{'isSortable':'yes','key':'gender','desc':'Gender','contentType':'String'},
	         									{'isSortable' : 'no','key' : 'action','desc' : 'Actions','contentType' : 'html'}
	         	                  				
	         	                  			];

	$scope.fetchdata= function(paginationObj,filterObj){
		$scope.pagination = paginationObj;
		$scope.filterJson = filterObj;
		var exchangeMemberId=EventBusSrvc.subscribe('subscriberId');
		var contractType = EventBusSrvc.subscribe('contractType');
		if(contractType != null && contractType != undefined && contractType =='Group') {
			$scope.backButtonURL = "#/system/eligibility/group";
		}
		//var groupId=EventBusSrvc.subscribe('groupId');
		$scope.viewHistoricalData(exchangeMemberId);
		
	}
	
$scope.backButtonURL = "#/system/eligibility/individual";
		
$scope.viewHistoricalData=function(exchangeMemberId){
		var exchangeMemberKey = 'item.eligibleMembers.eligibleMember$exchangeMemberId._id';
		var subscriberKey='item.eligibleMembers.eligibleMember$subscriber';
		 var projectedFields=[];
		 var projectedFieldId= {
					"entityField" :"_id",
				};
		 var projectedFieldItem= {
					"entityField" :"item",
				};
		 var projectedFieldItemMetaInfo= {
					"entityField" :"itemMetaInfo",
				};
		 projectedFields.push(projectedFieldId);
		 projectedFields.push(projectedFieldItem);
		 projectedFields.push(projectedFieldItemMetaInfo);
		var filterList = addFilter(null,subscriberKey,true,'=',false);
		filterList = addFilter(filterList,exchangeMemberKey,exchangeMemberId,'=',false);
		$scope.pageRequestCriteria=getPageRequestCriteria($scope.pagination);
		var  serachCriteria = getSearchCriteriaJsonWithProjection(filterList,$scope.pageRequestCriteria,null,projectedFields);
		var params={"beType":"eligibility"};
		ContractSrvc.getHistoricalData(params,serachCriteria,afterSuccessHistoricalData,afterFailHistoricalData);
}

$scope.publishSubscriberAndGroupIdForGrp=function(subscriberId,groupId, contractType,billingAccountExtId){
	EventBusSrvc.publish('subscriberId',subscriberId);
	EventBusSrvc.publish('groupId', groupId);
	EventBusSrvc.publish('contractType', contractType);
	EventBusSrvc.publish('goToRelatedBAExternalId', billingAccountExtId);
	//$scope.identity=identity;
	$scope.subId=subscriberId;
}
$scope.publishSubscriberAndGroupId=function(subscriberId,groupId, contractType){
	EventBusSrvc.publish('subscriberId',subscriberId);
	EventBusSrvc.publish('groupId', groupId);
	EventBusSrvc.publish('contractType', contractType);
	//$scope.identity=identity;
	$scope.subId=subscriberId;
}

$scope.getSearchCriteriaForIndvHistoricalData = function(paginationObj, filterObj) {		
	if (paginationObj) {
		$scope.pagination = paginationObj;
	}			
	return $scope.populateSearchCriteria($scope.pagination, filterObj);
}
	/*$scope.getSearchCriteriaForHistoricalData=function(paginationObj, filterObj){
		if(paginationObj){
			$scope.paginationObj=paginationObj;
		}*/
		/*$scope.setSubscriberIdAndGroupId=function(subId,grpId){
			$scope.subId=subId;
			$scope.groupId=grpId;
			
		}*/
	
var afterSuccessHistoricalData=function(data){
	$scope.pagination.totalElements = data.totalElements;
	$scope.pagination.totalNoPages  = data.totalPages;
	$scope.indvhistoricaldata = getIndividualHistoricalData(data);
	$scope.billingAccountExtId=EventBusSrvc.subscribe('goToRelatedBAExternalId');
	//$scope.indvhistoricaldata.length = data.totalElements;
	
	// Work-around to set total number of elements in tablePagination object
	if($scope.indvhistoricaldata == null || $scope.indvhistoricaldata == undefined || $scope.indvhistoricaldata.length <= 0){
		$scope.indvhistoricaldata = 'No Data';
	} 
	
	 $scope.updateLeftNav('Eligibility');
}

$scope.transferToContractDetails =  function(recordId) {
	$scope.fetchItemRecordIdAndRedirect(recordId, '/system/eligibility/contract-detail');
}


$scope.fetchItemRecordIdAndRedirect = function(recordId, redirectTo) {
		EventBusSrvc.publish('contractRecordId',recordId);
		EventBusSrvc.publish('isContractDetailFromHistory', true);
		$location.path(redirectTo);
		$location.replace();
		//$route.reload();
		//$window.location.href = '#entities/individual/individual-details';					
}

$scope.publishContractRecordId = function(contractRecordId, type){
	EventBusSrvc.publish('contractRecordId',contractRecordId);
	EventBusSrvc.publish('contractType', type);
}

var getIndividualHistoricalData=function(data){
	var HistorySummaryList=[];
	angular.forEach(data.content,
			function(value,key)
			{
		var indhistoryObj = {};
		indhistoryObj.importedDate = $filter('date')(value.itemMetaInfo.importedAt.date,'MM/dd/yyyy HH:mm:ss');
		indhistoryObj.id=value.id;
		//indhistoryObj.subscriberId="";//value.item.subscriber.subscriberId.id;
		
		if(value.item.exchangeGroupId==null){
			indhistoryObj.groupId='NA';
		}else{
			indhistoryObj.groupId=value.item.exchangeGroupId;
		}
		
		if(value.item.market=='G'||value.item.market.toLowerCase()=='group'|| value.item.market.toLowerCase()=='one'){
		    indhistoryObj.market = 'Group';
		}else if(value.item.market == 'I'||value.item.market.toLowerCase()=='individual'|| value.item.market.toLowerCase() == 'zero'){
			indhistoryObj.market = 'Individual';
		}
		
		indhistoryObj.name="";//value.item.subscriber.subscriberName.firstName+''+value.item.subscriber.subscriberName.lastName;
		
		if (value.item.eligibleMembers.eligibleMember) {
			  var members =value.item.eligibleMembers.eligibleMember;
			  angular.forEach(members, function(member, key) {
			      if(member.subscriber==true){
			    	  indhistoryObj.subscriberId =  member.exchangeMemberId.id; 
			    	  indhistoryObj.name = member.memberName.firstName; 					  
						   if(member.memberName.middleName != null && member.memberName.middleName!=undefined && member.memberName.middleName.trim().length > 0)
						   {
							indhistoryObj.name= indhistoryObj.name+" "+ member.memberName.middleName;
						   }							 
							indhistoryObj.name= indhistoryObj.name+" "+ member.memberName.lastName;  
					        indhistoryObj.name= indhistoryObj.name.ucwords();
			    	  indhistoryObj.dob=member.dateOfBirth;
			    	  if(member.gender=='M')
			    		  indhistoryObj.gender='Male';
			  		else 
			  			indhistoryObj.gender='Female';
			      }});
			 
			 }
		
		
		
		//indhistoryObj.dob=value.item.subscriber.dateOfBirth;
		//indhistoryObj.gender=value.item.subscriber.gender;
		indhistoryObj.value = value;
		
			indhistoryObj.action = 
		'<a class="viewDetails" title="Eligibility Details"><i ng-click="transferToContractDetails(value.id)" class="icon-view-details"></i></a>'
		
        	HistorySummaryList.push(indhistoryObj);
			}
	);
	
	return HistorySummaryList;			
}


/*

$scope.fetchIndvHistoricalSummaries = function(criteria) {
	$scope.fetchHistSummaries(criteria, afterSuccessHistoricalData, afterFailHistoricalData);
}

$scope.fetchHistSummaries = function(criteria, success, error){ 
	if (criteria === null) {
		criteria = {"criteria": {}};
	}
	ContractSrvc.getHistoricalData(criteria, success, error);
}*/

var afterFailHistoricalData=function(){
	$scope.indvhistoricaldata = 'No Data';
	$scope.updateLeftNav('Eligibility');
}
});


hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "IndvHistoricalDataCtrl",
	"id" : hcentive.WFM.IndvHistoricalDataCtrl
});
