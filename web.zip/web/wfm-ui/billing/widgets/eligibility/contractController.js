hcentive.WFM.ConCtrl = ('$scope', '$location','$route','EventBusSrvc', 'ContractSrvc', function($scope,$location,$route, EventBusSrvc, ContractSrvc) {

	$scope.pagination = defaultPagination('','');

	$scope.populateSearchCriteria = function(paginationObj, filterObj) {
		var searchCriteriaJson = {};
		var criteria = {};
		$scope.filterJson = filterObj;
		$scope.pagination = paginationObj;
		
		// populate pageRequestCriteria
		searchCriteriaJson.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
		
		angular.forEach($scope.filterJson, function(jsonObject, index) {
			var jsonObjectKey = Object.keys(jsonObject);
			var jsonObjectValue = jsonObject[jsonObjectKey];
			if (!isEmptyStr(jsonObjectValue)) {
				criteria[jsonObjectKey] = {
									"operator" : "like" ,
									"columnValue" : "'%" + jsonObjectValue + "%'",
									"caseSensitiveSearch" : "false"
								};
			}
			
		})
		
		searchCriteriaJson.criteria = criteria;
		return searchCriteriaJson;	
	}

	$scope.fetchContractSummaries = function(criteria, contractType, success, error){ 
		var params = {'contractType' : contractType};
		if (criteria === null) {
			criteria = {"criteria": {}};
		}
		ContractSrvc.getContractSummaries(params, criteria, success, error);
	}
	
	$scope.publishContractRecordIdForGrp = function(contractRecordId, type,billingAccountExtId){
		EventBusSrvc.publish('contractRecordId',contractRecordId);
		EventBusSrvc.publish('contractType', type);
		EventBusSrvc.publish('isContractDetailFromHistory', false);
		EventBusSrvc.publish('billingAccountExternalId', billingAccountExtId);
		
	}
	
	$scope.publishContractRecordId = function(contractRecordId, type){
		EventBusSrvc.publish('contractRecordId',contractRecordId);
		EventBusSrvc.publish('contractType', type);
		EventBusSrvc.publish('isContractDetailFromHistory', false);
		
	}
	
	
	
	$scope.fetchItemRecordIdAndRedirect = function(externalId, type, redirectTo, pageBackURL) {
		var column1 ="externalId";
		var operator1 ="=";
		var column1value=externalId;
		
		var column2='type';	
		var operator2 ="=";
		var column2value=type;
		
		var criteria=getSearchCriteriaJson(addFilter(addFilter(null, column1, "'"+column1value+"'",
				operator1, true), column2, "'"+column2value+"'",operator2,true), "", "");
		
		ContractSrvc.getBE("",criteria,success,error);
						
		function error(record){
			;
			//$scope.brokers = 'No Data';
		}
	
		function success(record) {
			EventBusSrvc.publish('itemRecordId',record.content[0].itemRecordId);
			EventBusSrvc.publish('goToRelatedBEIdentity', record.content[0].identity);
			EventBusSrvc.publish('goToRelatedBEExternalId', record.content[0].externalId);
			EventBusSrvc.publish('pageBackURL', pageBackURL);
			$location.path(redirectTo);
			$location.replace();
		//	$route.reload();
			//$window.location.href = '#entities/individual/individual-details';					
		}
	}
	
	$scope.publishContractIdentity = function(contractIdentity){
		EventBusSrvc.publish('contractIdentity',contractIdentity);
	}
	
	var isEmptyStr = function(str) {
		return (!str || 0 === str.length);
	}
	
	

});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		"name" : "ContractCtrl",
		"id" : hcentive.WFM.ConCtrl
});
	
