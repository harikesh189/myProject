hcentive.WFM.IndvContractCtrl = ('$scope', '$location','$route','EventBusSrvc', 'ContractSrvc', function($scope,$location,$route, EventBusSrvc, ContractSrvc) {
	
	$scope.updateLeftNav('Eligibility');
	
	$scope.pagination = defaultPagination('auditInfo.modifiedAt','desc');
	
	$scope.indvContractFilters = [{'filterKey':'subscriberExtId','filterType':'TextBox'},
					   {'filterKey':'subscriberName','filterType':'TextBox'}];
					   
	/*$scope.headerIndvColumns = 	[{'isSortable':'yes','key':'subscriberId','desc':'Subscriber ID','contentType' : 'String', 'sortableKey' : 'subscriberExtId'},
								    {'isSortable':'yes','key':'name','desc':'Subscriber Name','contentType' : 'String', 'sortableKey' : 'subscriberFirstName'},
									{'isSortable':'yes','key':'groupId','desc':'Group ID','contentType' : 'String', 'sortableKey' : 'enrolledGroupId'},
									{'isSortable' : 'no','key' : 'action','desc' : 'Actions','contentType' : 'html'}
	                  				
	                  			];*/
	$scope.headerIndvColumns = 	[{'isSortable':'yes','key':'subscriberId','desc':'Subscriber ID','contentType' : 'String', 'sortableKey' : 'subscriberExtId'},
								    {'isSortable':'yes','key':'name','desc':'Subscriber Name','contentType' : 'String', 'sortableKey' : 'subscriberName'},
									{'isSortable' : 'no','key' : 'action','desc' : 'Actions','contentType' : 'html'}
	                  				
	                  			];
	
	$scope.fetchdata = function(paginationObj,filterObj){
		var crit =  $scope.getSearchCriteriaForIndvEligContracts(paginationObj, filterObj);
		$scope.fetchIndvEligContractSummaries(angular.toJson(crit));
	};
	
	$scope.getSearchCriteriaForIndvEligContracts = function(paginationObj, filterObj) {		
		if (paginationObj) {
			$scope.pagination = paginationObj;
		}			
		return $scope.populateSearchCriteria($scope.pagination, filterObj);
	};
	
	$scope.fetchIndvEligContractSummaries = function(criteria) {
		$scope.fetchContractSummaries(criteria, "IndividualEligibilityContract", fetchIndvContractSuccess, fetchIndvContractError);
	};							 
	
	var fetchIndvContractSuccess = function(data) {
		$scope.pagination.totalElements = data.totalElements;
		$scope.pagination.totalNoPages  = data.totalPages;
		$scope.indvContracts = getIndividualContracts(data);
		
		// Work-around to set total number of elements in tablePagination object
		if($scope.indvContracts == null || $scope.indvContracts == undefined || $scope.indvContracts.length <= 0){
			$scope.indvContracts = 'No Data';
		} 
		
	};
	
	var fetchIndvContractError = function(data){
		$scope.indvContracts = 'No Data';
	};
	
	$scope.searchIndvContracts = function(subscriberId) {
		filterJson = [{"subscriberExtId" : subscriberId}];
		var criteria =  $scope.getSearchCriteriaForIndvEligContracts(null, filterJson);
		$scope.fetchIndvEligContractSummaries(angular.toJson(criteria));
			
	};
		
	$scope.transferToEntity =  function(externalId) {
		$scope.fetchItemRecordIdAndRedirect(externalId, "Individual", '/entities/individual/individual-details', 'system/eligibility/individual');
	};	
	
});
	
	
	hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		"name" : "IndvContractCtrl",
		"id" : hcentive.WFM.IndvContractCtrl
	});
	