
function getIndividualContracts(data) {
	var indvContractSummaryList = [];
	angular.forEach(data.content,
					function(value, key) {
						var contractInfoObject = {};
						contractInfoObject.identity = value.identity;
						contractInfoObject.subscriberId = value.subscriberExtId;
						contractInfoObject.name="";
						if(value.subscriberName !=null && value.subscriberName !=undefined){
						contractInfoObject.name = value.subscriberName;
						}
						//contractInfoObject.groupId = value.enrolledGroupId;	
						
						contractInfoObject.action = 
						'<a href="#system/eligibility/contract-detail" class="viewDetails" title="Eligibility Details">'
							+ '<i class="icon-view-details" ng-click="publishContractRecordId(value.contractRecordId, '+'\'Individual\''+')"></i>'
						+ '</a>'
						/*+ '<span class="lineDivider"></span>'
						+ '<a href="rating" class="viewDetails" title="Rating Details">'
							+ '<i class="icon-payments" ng-click="publishContractIdentity(value.contractId)"></i>'
						+ '</a>' */
						+ '<span class="lineDivider"></span> '
						+ '<a href="#system/eligibility/historical-data" class="viewDetails" title="Historical Records">'
							+ '<i class="icon-histo" ng-click="publishSubscriberAndGroupId(value.subscriberId,value.groupId, '+'\'Individual\''+')"></i>' 
						+ '</a>' 
						+ '<span class="lineDivider"></span>'
                        + '<a  class="viewDetails" title="Related Entity">' 
							+ '<i class="icon-transferToEntity" ng-click="transferToEntity(value.subscriberId)"></i>'
						+ '</a>'
						+ '<span class="lineDivider"></span>'
	                    + '<div wfm-download-file download-file-name="eligibility" download-file-type="eligibility" item-record-id="{{value.contractRecordId}}" data-type="xml"></div>';
						
						contractInfoObject.contractId = value.contractId;	
						contractInfoObject.contractRecordId = value.contractRecordId;
						contractInfoObject.value = value;				
						indvContractSummaryList.push(contractInfoObject);
					});
	return indvContractSummaryList;				
}



function getGroupContracts($scope,data) {
	var groupContractSummaryList = [];
	if(data != null && data != undefined) {
		
		angular.forEach(data.content,
					function(value, key) {
						var contractInfoObject = {};
						contractInfoObject.contractTitle = value.contractTitle;
						contractInfoObject.contractId = value.contractId;
						contractInfoObject.createdOn = value.createdOn;
						contractInfoObject.terminatedOn = value.terminatedOn;
						contractInfoObject.subscriberId = value.subscriberExtId;
						contractInfoObject.subscriptionExternalId = value.subscriptionExternalId;
						contractInfoObject.enrolledGroupId = value.enrolledGroupId;						
					    contractInfoObject.name="";					    
						if(value.subscriberName !=null && value.subscriberName !=undefined){
						contractInfoObject.name = value.subscriberName;
						}
						
						contractInfoObject.employerGroupId = value.employerGroupId;
						contractInfoObject.employerGroupName = value.employerGroupName;
						contractInfoObject.contractRecordId = value.contractRecordId;
						contractInfoObject.value = value;
						
						contractInfoObject.action =
                        '<a href="#/system/eligibility/contract-detail" class="viewDetails" title="Eligibility Details">'
						+ '<i class="icon-view-details" ng-click="publishContractRecordIdForGrp(value.contractRecordId, '+'\'Group\''+',value.subscriptionExternalId)"></i>'
						+ '</a>'
						+ '<span class="lineDivider"></span> '
						+ '<a href="#system/eligibility/historical-data" class="viewDetails" title="Historical Records">'
							+ '<i class="icon-histo" ng-click="publishSubscriberAndGroupIdForGrp(value.subscriberId,value.enrolledGroupId, '+'\'Group\''+',value.subscriptionExternalId)"></i>' 
						+ '</a>'
						+ '<span class="lineDivider"></span>'
						+ '<a href="javascript:void(0);" class="viewDetails" title="Transfer to Billing Account">' 
							+ '<i class="icon-transferToEntity" ng-click="transferToSubscription(\''+contractInfoObject.employerGroupId+'\',\''+contractInfoObject.subscriptionExternalId + '\')"></i>'
						+ '</a>'
						+ '</a>';
						if( $scope.isRenderable('ImportEligibility')){
							contractInfoObject.action = contractInfoObject.action 
						+ '<span class="lineDivider"></span>'
                        +  '<div wfm-download-file download-file-name="eligibility" download-file-type="eligibility" item-record-id="{{value.contractRecordId}}" data-type="xml"></div>';
						}
						groupContractSummaryList.push(contractInfoObject);
					});
		if(!(groupContractSummaryList != null && groupContractSummaryList != undefined && groupContractSummaryList.length > 0)) {
			groupContractSummaryList = 'No Data';
		}
	}
 return groupContractSummaryList;				
}

function getContractBasicInfo(data) {
	var basicInfo = {};
	if (data.eligibleMembers) {
		  var members = data.eligibleMembers.eligibleMember;
		  angular.forEach(members, function(member, key) {
		      if(member.subscriber==true){
		       basicInfo.subscriberId =  member.exchangeMemberId.id; 
		       basicInfo.subscriberName = member.memberName.firstName;
			   if(member.memberName.middleName!= null && member.memberName.middleName!= undefined && member.memberName.middleName.trim().length > 0)
			   {
				 basicInfo.subscriberName = basicInfo.subscriberName+" "+ member.memberName.middleName;
			   }
			   basicInfo.subscriberName = basicInfo.subscriberName +" "+ member.memberName.lastName;  
			   basicInfo.subscriberName = basicInfo.subscriberName;
		       }
		   });
		 }
	//case sensitive check for marketType
	if(data.market && data.market != undefined){
	if(data.market.match(/g/i) || data.market.match(/group/i) || data.market.match(/one/i)){
		basicInfo.market = 'Group';
	}else{
		basicInfo.market = 'Individual';
	}
	}
	if(data.exchangeGroupId==null){
		basicInfo.enrolledGroupId='NA';
	}else{
		basicInfo.enrolledGroupId=data.exchangeGroupId;
	}
	//basicInfo.enrolledGroupId = data.exchangeGroupId;	
	basicInfo.subscription = data.subscriptionExternalId;
	return basicInfo;
}

function getContractMemberList(data) {
	var memberList = [];
	var memberSummaryObject;
	if (data.eligibleMembers) {
		var members = data.eligibleMembers.eligibleMember;
		angular.forEach(members,
						function(member, key) {
							memberSummaryObject = {};
							memberSummaryObject.memberName = member.memberName.firstName; 
						    if(member.memberName.middleName != null && member.memberName.middleName!=undefined && member.memberName.middleName.trim().length > 0)
						   {
							 memberSummaryObject.memberName = memberSummaryObject.memberName +" "+ member.memberName.middleName;
						   }							 
							memberSummaryObject.memberName = memberSummaryObject.memberName +" "+ member.memberName.lastName;  
							
                            memberSummaryObject.memberName = memberSummaryObject.memberName.ucwords();	      				

							memberSummaryObject.memberId = member.exchangeMemberId.id;
							var d = new Date(member.dateOfBirth);
							
							month = '' + (d.getMonth() + 1),
							day = '' + d.getDate(),
							year = d.getFullYear();

							if (month.length < 2) month = '0' + month;
							if (day.length < 2) day = '0' + day;
							memberSummaryObject.dob = [month, day, year].join('/');
							
							if(member.gender=='M' ||member.gender=='MALE')
								memberSummaryObject.gender ='Male';
							else
								memberSummaryObject.gender ='Female';
							
							if(member.relationship != null || member.relationship!= undefined){
								var relationship = member.relationship.split('_').join(' ');
								relationship = toTitleCase(relationship);
								memberSummaryObject.relationship = relationship;
							}
							memberSummaryObject.member=member;
							
							memberSummaryObject.action = '<a href="#system/eligibility/health-coverage-details-single" class="viewDetails"  title="Health Coverage Details">'
							+ '<i class="icon-healthCoverageDetails" ng-click="publishMemberDetails(value.member, contractType);"></i>'
							+ '</a>'
							+ '<span class="lineDivider"></span>'
							+ '<a href="#system/eligibility/information" class="viewDetails"  title="Communication Details">'
							+ '<i class="icon-demographicDetails" ng-click="publishMemberDetails(value.member, contractType);"></i>'
						+ '</a>';
							memberList.push(memberSummaryObject);
						});
	
	} 
	
	return memberList;
}


function getContractBenefitVendorList(data,translate){
	var vendorList = [];
	var memberVendorObject;
	if (data.eligibleMembers) {
		var members = data.eligibleMembers.eligibleMember;
		angular.forEach(members,
				function(member, key) {
			if(member.benefits != null  && member.benefits != undefined &&  member.benefits.benefit.length>0){
				angular.forEach(member.benefits.benefit,
					function(bv, key) {
					memberVendorObject={};
					memberVendorObject.benefitAmount=bv.benefitCoverage.benefitAmount;
					memberVendorObject.effectiveDate=bv.benefitCoverage.coveragePeriod.effectiveDate;
					memberVendorObject.endDate=bv.benefitCoverage.coveragePeriod.endDate;
					memberVendorObject.benefitId=bv.benefitDetails.benefitId;
					memberVendorObject.benefitName=bv.benefitDetails.benefitName;
					memberVendorObject.benefitType=translate.instant(bv.benefitDetails.benefitType);
					memberVendorObject.productType=bv.benefitDetails.benefitType;
					memberVendorObject.benefitVendorName=bv.benefitDetails.benefitVendorName;
					memberVendorObject.benefitVendorId=bv.benefitDetails.benefitVendorId;
					vendorList.push(memberVendorObject);
				
				
			});
				return vendorList;
			}
			
		});
		
	}
	return vendorList;
	}


function toTitleCase(str){
	return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

function getSubsidyInformation(insuranceCoverages){
	 if(insuranceCoverages){
		angular.forEach(insuranceCoverages, 
		        function(coverageValue, index) {
				var data = coverageValue.coverages.coverage;
				if(data != null && data != undefined){
					angular.forEach(data, 
						        function(value, index) {
								var subsidyObjects=[];
								if(value.optInSubsidies != null && value.optInSubsidies != undefined){
									angular.forEach(value.optInSubsidies.subsidy,
											function(v,k){
											var subsidyObject={};	
											subsidyObject.subsidyType=v.subsidyType;
											subsidyObject.subsidyProviderEntityID=v.subsidyProviderId.id;
											subsidyObject.amount="$"+v.subsidyAmount;
											subsidyObject.subsidyLabel = v.subsidyLabel;
					   
											if(v.effectiveDate != null && v.effectiveDate != undefined) {
												var d = new Date(v.effectiveDate);
												month = '' + (d.getMonth() + 1),
												day = '' + d.getDate(),
												year = d.getFullYear();
												if (month.length < 2) month = '0' + month;
												if (day.length < 2) day = '0' + day;
					
												subsidyObject.effectiveDate= [month, day, year].join('/');
											}
										
											if(v.terminationDate != null && v.terminationDate != undefined) {
												var d = new Date(v.terminationDate);
												month = '' + (d.getMonth() + 1),
												day = '' + d.getDate(),
												year = d.getFullYear();
												if (month.length < 2) month = '0' + month;
												if (day.length < 2) day = '0' + day;
						
												subsidyObject.termDate= [month, day, year].join('/');
											}
						
											else
											{
												subsidyObject.subsidyType='';
												subsidyObject.subsidyProviderEntityType='';
												subsidyObject.effectiveDate='';
												subsidyObject.termDate='';
												subsidyObject.amount='';
					   
											}
											subsidyObjects.push(subsidyObject);
									});
									value.subsidyObjects = subsidyObjects;
							}		
						});
					
				    }
			});
	 	}
		return insuranceCoverages;
}


function getContractMemberSubDetails(data) {
	var result = {};
	result.basicInfo={};
	result.smokingInfo={};
	result.insuranceCoverages=[];
	result.addressList=[];
	result.contactNumbers={};
	result.emailId = 'NA';
	
	if(data != null && data != undefined) {
		
		if(data.insuranceCoverages != null && data.insuranceCoverages != undefined &&
			data.insuranceCoverages.insuranceCoverage[0] != null && data.insuranceCoverages.insuranceCoverage[0] != undefined) {
			
			result.insuranceCoverages = data.insuranceCoverages.insuranceCoverage;
		}
		
		if(data.addresses != null && data.addresses != undefined &&
			data.addresses.address != null && data.addresses.address != undefined) {
			result.addressList=data.addresses.address;
		}
		
		result.contactNumbers.home='NA';
		result.contactNumbers.work='NA';
		result.contactNumbers.other='NA';
		var homeDirty=false;
		var emailDirty=false;
		
		if(data.contactNumbers != null && data.contactNumbers != undefined &&
			data.contactNumbers.contactNumber != null && data.contactNumbers.contactNumber != undefined) {

			angular.forEach(data.contactNumbers.contactNumber,function(value, index) {
	            if(value.category=='HOME') {
					if(homeDirty==false) {
						result.contactNumbers.home=value.number;
						homeDirty=true;
					} else if(value.preferred==true) {
						result.contactNumbers.home=value.number;
					}
				}
				if(value.category=='WORK') {
					result.contactNumbers.work=value.number;
				}

				if(value.category=='OTHER') {
					result.contactNumbers.other=value.number;
				}
	        });
		}
		
		result.emailId = 'NA';
		if(data.emailIds != null && data.emailIds != undefined) { 
			if(data.emailIds.emailId != null && data.emailIds.emailId != undefined && data.emailIds.emailId.length != 0) {
				result.emailId = data.emailIds.emailId[0];
			}
			else if (data.emailIds.email != null && data.emailIds.email != undefined) {
				var preferredDirty = false;
				angular.forEach(data.emailIds.email, function(value, index) {
					if (value.emailId != null && value.emailId != undefined && preferredDirty == false) {
						result.emailId = value.emailId; 
						if (value.preferred == true) {
							preferredDirty = true;
						}
					}
				}); 
			}
		}
		/* Basic Information Json getting populated */
				
		var membeName = 'NA';
		if(data.memberName.firstName != null && data.memberName.firstName != undefined){
			membeName = data.memberName.firstName;
		}
		
		if(data.memberName.middleName != null && data.memberName.middleName != undefined){
			membeName = membeName + ' '+data.memberName.middleName;
		}
		
		if(data.memberName.lastName != null && data.memberName.lastName != undefined){
			membeName = membeName + ' '+data.memberName.lastName;
		}
		result.basicInfo.name = membeName;			
		
		result.basicInfo.memberId=data.exchangeMemberId.id;
		
		result.basicInfo.dob = 'NA';
		if(data.dateOfBirth != null && data.dateOfBirth != undefined) {
			var d = new Date(data.dateOfBirth);
			
			month = '' + (d.getMonth() + 1),
			day = '' + d.getDate(),
			year = d.getFullYear();

			if (month.length < 2) month = '0' + month;
			if (day.length < 2) day = '0' + day;
			
			result.basicInfo.dob = [month, day, year].join('/');
		}
		
		result.basicInfo.gender = 'NA';
		if(data.gender != null && data.gender != undefined) {
			if(data.gender == 'M' || data.gender == 'MALE')
				result.basicInfo.gender ='Male';
			else
				result.basicInfo.gender ='Female';
		}
		/* Basic Information Json Population Ends */
		
		/* Smoking Info Getting Populated */
		result.smokingInfo.student='NA';
		if(data.student != null && data.student != undefined) {
			if(data.student==true)
				result.smokingInfo.student='Yes';
			else
				result.smokingInfo.student='No';
		}
		
		result.smokingInfo.smokingStatus = 'NA';
		result.smokingInfo.smokingLevel = 'NA';
		if(data.eligibilityFactors != null && data.eligibilityFactors != undefined) {
			
			if(data.eligibilityFactors.smokingStatus != null && data.eligibilityFactors.smokingStatus != undefined) {
				if(data.eligibilityFactors.smokingStatus==true)
					result.smokingInfo.smokingStatus='Yes';
				else
					result.smokingInfo.smokingStatus='No';
			}
			
			//result.smokingInfo.smokingLevel=data.eligibilityFactors.smoking.smokingLevel
		}
		/*Smaoking Info Population Ends */
	}
	
	return result;
}
function getContractGroupInfoList(data) {
	
	var groupInfoList = [];
	var	groupInfoObject = {};
		groupInfoObject.groupId = "";
		groupInfoObject.groupName = "";
		groupInfoObject.subGroupId = "";
		groupInfoObject.subGroupName = "";
		
		var isGroupInvoiceObjUndefined = true;
		if(data.exchangeGroupId != null){
			isGroupInvoiceObjUndefined = false;
			groupInfoObject.groupId=data.exchangeGroupId;
		}

		if(data.exchangeGroupDescription != null){
			isGroupInvoiceObjUndefined = false;
			groupInfoObject.groupName=data.exchangeGroupDescription;
		}
		
		if(data.exchangeSubGroupId != null){
			isGroupInvoiceObjUndefined = false;
			groupInfoObject.subGroupId=data.exchangeSubGroupId;
		}
		
		if(data.exchangeSubGroupDescription != null){
			isGroupInvoiceObjUndefined = false;
			groupInfoObject.subGroupName=data.exchangeSubGroupDescription;
		}
		
		if(isGroupInvoiceObjUndefined){
			return '';
		}
		
		/*if(data.insuranceCoverages != null && data.insuranceCoverages != undefined && data.insuranceCoverages.insuranceCoverage[0] != null && data.insuranceCoverages.insuranceCoverage[0] != undefined)
		{
		var insuranceCoverageInfo=data.insuranceCoverages.insuranceCoverage[0];
		//if(insuranceCoverageInfo.groupId != null && insuranceCoverageInfo.groupId != undefined)
		//groupInfoObject.groupId=data.exchangeGroupId;
		
		
		
		if(insuranceCoverageInfo.groupName != null && insuranceCoverageInfo.groupName != undefined)
		groupInfoObject.groupName=insuranceCoverageInfo.groupName;
		
		if(insuranceCoverageInfo.subGroupId != null && insuranceCoverageInfo.subGroupId != undefined)
		groupInfoObject.subGroupId=insuranceCoverageInfo.subGroupId;
		
		if(insuranceCoverageInfo.subGroupName != null && insuranceCoverageInfo.subGroupName != undefined)
		groupInfoObject.subGroupName=insuranceCoverageInfo.subGroupName;
		}
		else if(data.eligibleMembers  != null && data.eligibleMembers != undefined)
		
		{
		
	
		var insuranceCoverageInfo=data.eligibleMembers.eligibleMember[0].insuranceCoverages.insuranceCoverage[0];
		//if(insuranceCoverageInfo.groupId != null && insuranceCoverageInfo.groupId != undefined)
		//groupInfoObject.groupId=insuranceCoverageInfo.groupId;
		
		if(insuranceCoverageInfo.groupName != null && insuranceCoverageInfo.groupName != undefined)
		groupInfoObject.groupName=insuranceCoverageInfo.groupName;
		
		if(insuranceCoverageInfo.subGroupId != null && insuranceCoverageInfo.subGroupId != undefined)
		groupInfoObject.subGroupId=insuranceCoverageInfo.subGroupId;
		
		if(insuranceCoverageInfo.subGroupName != null && insuranceCoverageInfo.subGroupName != undefined)
		groupInfoObject.subGroupName=insuranceCoverageInfo.subGroupName;
		
		
		} */ 
		groupInfoList.push(groupInfoObject);
					
	return groupInfoList;
}
