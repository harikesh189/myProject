hcentive.WFM.ContractDetailCtrl = ('$scope','$location', 'EventBusSrvc','$translate' ,'ContractSrvc', function ($scope,$location, EventBusSrvc,$translate, ContractSrvc) {
	
	$scope.pageType = '';
	$scope.contractType = '';
	$scope.backButtonURL = '';
	$scope.recordId = EventBusSrvc.subscribe('contractRecordId');
	$scope.isContractDetailFromHistory = EventBusSrvc.subscribe('isContractDetailFromHistory');
	$scope.updateLeftNav('Eligibility');
	
	var contractTypeCallback = function(newVal,oldVal){
		if (null != newVal) {
			$scope.safeApply($scope,function(){
				$scope.contractType = newVal;
				if($scope.isContractDetailFromHistory != null && $scope.isContractDetailFromHistory != undefined && $scope.isContractDetailFromHistory) {
					$scope.backButtonURL = "#/system/eligibility/historical-data";
				} else if($scope.contractType != null && $scope.contractType != undefined && $scope.contractType =='Group') {
					$scope.backButtonURL = "#/system/eligibility/group";
				} else {
					$scope.backButtonURL = "#/system/eligibility/individual";
				}
			});
		}
	};
		
	EventBusSrvc.subscribe('contractType',$scope, contractTypeCallback);
	$scope.publishMemberDetails = function(member){
		EventBusSrvc.publish('memberDetails', member);
		$scope.publishContractType();
		$scope.publishContractRecordId();
	}
	
	$scope.publishContractType = function(){
		EventBusSrvc.publish('contractType', $scope.contractType);
	}

	$scope.publishContractRecordId = function(){
		EventBusSrvc.publish('contractRecordId', $scope.recordId);
	}
	
	$scope.headerMemberColumns = 
		[{'isSortable':'yes','key':'memberName','desc':'Name','contentType' : 'String', 'sortableKey' : 'firstName, lastName'},
		{'isSortable':'yes','key':'memberId','desc':'Member ID','contentType' : 'String', 'sortableKey' : 'memberId'},
		{'isSortable':'yes','key':'dob','desc':'DOB','contentType' : 'String', 'sortableKey' : 'dateOfBirth'},
		{'isSortable':'yes','key':'gender','desc':'Gender','contentType' : 'String', 'sortableKey' : 'gender'},
		{'isSortable':'yes','key':'relationship','desc':'Relationship','contentType' : 'String', 'sortableKey' : 'relationship'},
		{'isSortable' : 'no','key' : 'action','desc' : 'Actions','contentType' : 'html'}
		];
	
	$scope.headerBrokerColumns = 
		[{'isSortable':'yes','key':'brokerId','desc':'Broker ID','contentType' : 'String', 'sortableKey' : 'brokerId'},
		 {'isSortable':'yes','key':'brokerName','desc':'Broker Name','contentType' : 'String', 'sortableKey' : 'firstName, lastName' }
		];
	
	$scope.headerGroupInfoColumns = 
		[{'isSortable':'yes','key':'groupId','desc':'Group ID','contentType' : 'String', 'sortableKey' : 'firstName, lastName'},
		 {'isSortable':'yes','key':'groupName','desc':'Group Name','contentType' : 'String', 'sortableKey' : 'brokerId'},
		 {'isSortable':'yes','key':'subGroupId','desc':'Sub Group ID','contentType' : 'String', 'sortableKey' : 'firstName, lastName'},
		 {'isSortable':'yes','key':'subGroupName','desc':'Sub Group Name','contentType' : 'String', 'sortableKey' : 'brokerId'}
		];
	
	$scope.setPageType = function(pageType){
		$scope.pageType = pageType;
		/*
		 * if($scope.pageType=='benefitAccount'){
		 * $location.path('system/eligibility/flex-benefit-details-multiple');
		 * $location.replace(); }
		 */
	}	
	
	$scope.fetchdata = function(paginationObj,filterObj){
		$scope.fetchContractDetails();
	}
	
	$scope.fetchContractDetails = function(){ 
		var params = {'type' : "eligibility", 
					  'id' : $scope.recordId,"tenant":$scope.wfmAppContext.loggedInUser.tenantId};
		
		ContractSrvc.getContractDetails(params, null, success, error);			  
		
		function error() {
            $scope.members = 'No Data';
			$scope.brokers = 'No Data';
			$scope.groupInfo = 'No Data';
        }	
					  
		function success(contract) {
            $scope.contract = contract.item;
			$scope.basicInfo = getContractBasicInfo(contract.item);
			$scope.members = getContractMemberList(contract.item);
			$scope.billingAccountExtId=$scope.billingAccountExtId;
			$scope.benefitVendorList=getContractBenefitVendorList(contract.item,$translate);
			$scope.benefitVendorResult=groupBy($scope.benefitVendorList, function(item)
					{
				  return (item.productType);
				});
			// getContractBenefitVendorList(contract.item,$translate);
			
			getContractBrokerList(contract.item);
			$scope.groupInfo = getContractGroupInfoList(contract.item);
			
			if($scope.members == '' || $scope.members == undefined){
				$scope.members = 'No Data';
			}
			
			if($scope.benefitVendor == '' || $scope.benefitVendor == undefined){
				$scope.benefitVendor = 'No Data';
			}
			
			if($scope.brokers == '' || $scope.brokers == undefined){
				$scope.brokers = 'No Data';
			}
			
			if($scope.groupInfo == '' || $scope.groupInfo == undefined){
				$scope.groupInfo = 'No Data';
			}
        }
		
		
		
		function groupBy( array , func )
		{
		  var mapToGroup = {};
		  array.forEach( function( o )
		  {
		    var mapKey =  func(o);
		  // var x= =JSON.stringify(mapkey);
		    mapToGroup[mapKey] = mapToGroup[mapKey] || [];
		    mapToGroup[mapKey].push( o );  
		  });
		  
		  return mapToGroup;
		 /*
			 * return Object.keys(mapToGroup).map( function( mapKey ) { return
			 * mapToGroup; })
			 */
		}
		
		function  getContractBrokerList(data) {

			var column1 ="externalId";
			var operator1 ="IN";
			// var eligibleMembers=data.eligibleMembers.eligibleMember;
			var agents=data.agents;
			var column1valueids=[];
			var result=[];
			var hash = {};

			
				
				
				
					if(agents != null && agents != undefined){
						var startList=true;
						angular.forEach(agents.agent,function(value, key) {
							if ( !hash.hasOwnProperty(value.agentId.id) ) { // it
																			// works
																			// with
																			// objects!
																			// in
																			// FF,
																			// at
																			// least
								hash[ value.agentId.id ] = true;
								result.push(value.agentId.id);
							}						
						});
					}
									
					
			
			if (!result || result.length ===0) {
				$scope.brokers = 'No Data';
				return;
			}
			
			angular.forEach(result,function(value, key) {
				if(key==0)
					column1valueids="'"+value+"'";
				else
					column1valueids=column1valueids+",'"+value+"'";
								
			});
						
			column1valaue="("+	column1valueids+")"	;	
			var column2='type';	
			var operator2 ="=";
			var column2value="Broker";
			var criteria=getSearchCriteriaJson(addFilter(addFilter(null, column1, column1valaue,
			operator1, true), column2, "'"+column2value+"'",operator2,true), "", "");
			ContractSrvc.getBE("",criteria,successBroker,errorBroker);
	
			function errorBroker(brokerDetails){
				$scope.brokers = 'No Data';
			}
	
			function successBroker(brokerDetails) {
				var content=brokerDetails.content;
				var brokerList = [];
				angular.forEach(content,
						function(value, key) {
							brokerSummaryObject = {};
							brokerSummaryObject.brokerName =value.profile.displayName;
							brokerSummaryObject.brokerId = value.externalId;
							brokerList.push(brokerSummaryObject);						 
				});
				$scope.brokers=brokerList;
			}	
		}	
	}
	$scope.billingAccountExtId=EventBusSrvc.subscribe('billingAccountExternalId');
    $scope.recordId = EventBusSrvc.subscribe('contractRecordId');
    $scope.updateLeftNav('Eligibility');
});

	
	hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		"name": "ContractDetailCtrl",
		"id": hcentive.WFM.ContractDetailCtrl
	}); 
	
	