/**
 * 
 */
hcentive.WFM.prefferedContactPersonCntrl = [ '$scope', '$location', 'EventBusSrvc',
		'$filter', '$compile', '$element',
		function($scope, $location, EventBusSrvc, $filter, $compile, $element) {
			
	
	
	$scope.deleteContactPerson = function() {
				$element.remove();
				 $scope.contactpersoncount = -1;
			}
	 $scope.deleteHealthDetails = function(){
			$element.remove();
		 }
	 
	 
		} ];

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "prefferedContactPersonCntrl",
	"id" : hcentive.WFM.prefferedContactPersonCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "prefferedContactPersonCntrl",
	"id" : hcentive.WFM.prefferedContactPersonCntrl
});