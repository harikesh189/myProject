/**
 * 
 */

hcentive.WFM.addcontactdirective = [ function() {

	return {
		restrict : 'E',
		 scope: {
			  contactarray:'=',
			 contactcount:'=',
			  formname:'@',
			  submitted : '@'},
		templateUrl : function(elem, attr) {
			return getTemplateUrl(attr, "widgets/contact/contact.html")
		},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};

} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addcontactdirective",
	"id" : hcentive.WFM.addcontactdirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "addcontactdirective",
	"id" : hcentive.WFM.addcontactdirective
});
