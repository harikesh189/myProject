/**
 * 
 */
hcentive.WFM.prefferedContactCntrl = [ '$scope', '$location', 'EventBusSrvc',
		'$filter', '$compile', '$element',
		function($scope, $location, EventBusSrvc, $filter, $compile, $element) {

	var contactListSize = 0;
	if($scope.contactarray!=undefined){
   	for(var i = 0; i < $scope.contactarray.length; i++) {
		  if($scope.contactarray[i] != null){
			  contactListSize ++;
		  }
	   }
	}
	
	  $scope.setDisplayCount = function(){
	        var displayCount = $scope.contactcount;
	        if($scope.contactarray){
	         for(var i = 0; i < $scope.contactarray.length; i++) {
	          if($scope.contactarray[i] === undefined){
	           displayCount--;
	          }
	        }
	        }
	        $scope.displayCount = displayCount+1;
	       }
	    
	    $scope.setDisplayCount();
   	
			$scope.setPrefferedContact = function(position) {
				angular.forEach($scope.contactarray, function(value, index) {
					 if(value!=null || value!=undefined){
					if (position != index)
						$scope.contactarray[index].isPrefferedContact = false;
					 }});
				$scope.contactarray[position].isPrefferedContact = true;

			}

			$scope.deleteContact = function(index) {
				   var id="contactDiv"+index;
				   $( "#"+id).remove();
				   $scope.contactarray[index] = undefined;
				   
				    var count = 0;
				   	for(var i = 0; i < $scope.contactarray.length; i++) {
				   	  if($scope.contactarray[i]){
					        var element =  angular.element('#contactForm_'+(i+1));
					        if(element!=undefined && element[0] != undefined){
					        count++;
					        $('#contactForm_'+(i+1)).text(count);
					       }
					       }
				   }
				   
				   }
			$scope.checkPrefferedContact=function(ContactArray){
				var ContactDetailFlag = 0;
				for(var i = 0; i<ContactArray.length; i++)
				{
					 if(ContactArray[i]!=null || ContactArray[i]!=undefined){
						if(ContactArray[i].isPrefferedContact)
						{
							ContactDetailFlag = 1;
						}
					 }
				}		
				if(ContactDetailFlag == 0)
				{
					return false;
				}
				return true;
			}
			
		} ];

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "prefferedContactCntrl",
	"id" : hcentive.WFM.prefferedContactCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "prefferedContactCntrl",
	"id" : hcentive.WFM.prefferedContactCntrl
});