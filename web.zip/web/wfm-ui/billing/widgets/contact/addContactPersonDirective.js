/**
 * 
 */

hcentive.WFM.addcontactpersondirective = [ function() {

	return {
		restrict : 'E',	
		 scope: {
			 contactpersoncount:'=',
			 contactpersonarray:'=',
			  formname:'@',
			  submitted : '@'},
		templateUrl : function(elem, attr) {
			return getTemplateUrl(attr, "widgets/contact/contactPerson.html")
		},
		link : function(scope, iElement, iAttrs, ctrl) {
			
			scope.updateCount = function(index){
				scope.$parent.contactpersoncount = -1;	
				 var id="contactPersonDiv"+index;
			     $( "#"+id).remove();
			     scope.contactpersonarray[index] = undefined;	
			      var count = 0;
			      for(var i = 0; i < scope.contactpersonarray.length; i++) {
			       if(scope.contactpersonarray[i]){
			        var element =  angular.element('#contactPersonForm_'+(i+1));
			        if(element!=undefined && element[0] != undefined){
			        count++;
			        $('#contactPersonForm_'+(i+1)).text(count);
			       }
			       }
			     }
			      if(scope.$parent.businessEntity.issuer && scope.$parent.businessEntity.issuer != undefined)
			      scope.$parent.businessEntity.issuer.contactPersons=undefined;
			      if(scope.$parent.businessEntity.exchange && scope.$parent.businessEntity.exchange != undefined)
				      scope.$parent.businessEntity.exchange.contactPersons=undefined;
			      if(scope.$parent.businessEntity.subsidyProvider && scope.$parent.businessEntity.subsidyProvider != undefined)
				      scope.$parent.businessEntity.subsidyProvider.contactPersons=undefined;
			      if(scope.$parent.businessEntity.client && scope.$parent.businessEntity.client != undefined)
				      scope.$parent.businessEntity.client.contactPersons=undefined;
			      if(scope.$parent.businessEntity.otherEntity && scope.$parent.businessEntity.otherEntity != undefined)
				      scope.$parent.businessEntity.otherEntity.contactPersons=undefined;
			}
		}
	};

} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addcontactpersondirective",
	"id" : hcentive.WFM.addcontactpersondirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "addcontactpersondirective",
	"id" : hcentive.WFM.addcontactpersondirective
});
