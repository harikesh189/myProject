/**
 * 
 */
hcentive.WFM.viewcontactpersondirective=[function(){
	return {
		restrict : 'E',
		templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/contact/viewcontactperson.html")},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};
	
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "viewcontactpersondirective",
	"id" : hcentive.WFM.viewcontactpersondirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "viewcontactpersondirective",
	"id" : hcentive.WFM.viewcontactpersondirective
});
