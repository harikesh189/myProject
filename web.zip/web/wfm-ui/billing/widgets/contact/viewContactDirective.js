/**
 * 
 */

hcentive.WFM.viewcontactdirective = [ function() {

	return {
		restrict : 'E',
		templateUrl : function(elem, attr) {
			return getTemplateUrl(attr, "widgets/contact/viewcontact.html")
		},
		link : function(scope, iElement, iAttrs, ctrl) {
			var preferedIndex = 0;
			   var  count = 1;
			   if( scope.contactsList && scope.contactsList != undefined && scope.contactsList.length >0){
			   for(var i = 0; i < scope.contactsList.length; i++) {
			    if(scope.contactsList[i].preferred){
			     preferedIndex = i;
			    }else{
			     count = count +1;
			     scope.contactsList[i].displayCount= count;
			    }
			   }
			   scope.contactsList[preferedIndex].displayCount = 1;
			  }}
	};

} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "viewcontactdirective",
	"id" : hcentive.WFM.viewcontactdirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "viewcontactdirective",
	"id" : hcentive.WFM.viewcontactdirective
});
