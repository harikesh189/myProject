hcentive.WFM.addbenefitvendordirective=[function(){
	
	return {
		restrict : 'EA',
		templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/benefitVendor/benefit-vendor.html")},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};
	
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addbenefitvendordirective",
	"id" : hcentive.WFM.addbenefitvendordirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
		"name" : "addbenefitvendordirective",
		"id" : hcentive.WFM.addbenefitvendordirective
	});
                                  
                                  
                                  
                                  
                                  
                      