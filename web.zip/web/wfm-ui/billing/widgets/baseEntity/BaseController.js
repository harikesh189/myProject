/**
 * 
 */

hcentive.WFM.BaseCntrl=['$scope','$location','BaseServ','EventBusSrvc','$filter','NotifySrvc','popupService',
                             function($scope,$location,BaseServ,EventBusSrvc,$filter,NotifySrvc,popupService){
	
    $scope.financialSummary = {};
    
	var successWriteOff = function(data){
		$scope.succErrDialog('WriteOff','WriteOff successful.');
	}
	
	var failWriteOff = function(data){
		$scope.succErrDialog('WriteOff','WriteOff unsuccessful.');
	}
	 var success = function (data) {     
		   $scope.amount=data;
	   };
   var error = function () {     
	   alert("Error");
   };
	
   $scope.addNewWriteOff = function(_writeOffObj){
		//alert(angular.toJson(_writeOffObj));
	   var writeOffDate = _writeOffObj.writeOffDate;
		var writeOffYear = writeOffDate.split("/")[2];
		var writeOffMonth = writeOffDate.split("/")[0];
		var writeOffDate = writeOffDate.split("/")[1];
		
		var transcationTime = writeOffYear +'-'+writeOffMonth+'-'+writeOffDate+'T00:00:00';
		
		var writeOffJson={"identity":null, 
			 "externalId":_writeOffObj.writeOffId,
			 "operator":{"identity":"WFM"},
			 "writeOffAmount":{"currency":{"name":"US Dollar","symbol":"$","shortName":"USD"},"value":_writeOffObj.writeOffAmt},
			 "beneficiary":{"business_entity_type":"Customer", "identity":_writeOffObj.entity},
			 "writeOffDate":{"date":transcationTime}};
		
		BaseServ.saveWriteOff(null, writeOffJson,null, successWriteOff, failWriteOff);
		
   }
   
    
   
   	var error = function(){
   		
   	}
   
	var amountReceivableSuccess = function(data){
		$scope.amount = data;
		var beIdentity = EventBusSrvc.subscribe('beIdentity');			
		$scope.writeOffParam=EventBusSrvc.subscribe('WriteOffParameters');
		$scope.writeOff ={};
		$scope.writeOffDate = $filter('date')(new Date(),$scope.clientDateFormat);
		$scope.submitted = false;
		
		
		NotifySrvc({
			id : 'simpleDialog',
			controller : 'BaseCntrl',
			scope : $scope,
			template : '<div id="add-write-off-popup" class="">'
				+ ' <form validate id="addWriteOff" name="addWriteOff" class="form-horizontal no-margin"> '
				  
				+ '<div class="rowMargin"> '
				+ '	<label class="control-label" for="entitySel">Entity:</label> ' 
				+ '	 <div class="controls controlText"><id= "entitySel" ng-model="writeOff.entitySel">{{writeOffParam.firstName}}&nbsp;{{writeOffParam.lastName}}({{writeOffParam.id}})'
				+ '<span ng-show=" submitted "></span></div> '
				+ '  </div> '
				 
				+ '  <div class="rowMargin"> '
				+ '	<label class="control-label" for="writeOffDate">Write Off Date:</label> '
				+ '	 <div class="controls dateIconInside"> <input type="text" wfmcalendar ng-model="writeOffDate" placeholder="mm/dd/yyyy" name="writeOffDate"   ng-trim="true" '
				+ 'class="input-small" /required><span ng-show="submitted && addWriteOff.writeOffDate.$error.required"><label class="error">Please provide writeOff date </label></span></div> '
				+ '</div> '
				  
				+ '<div class="rowMargin"> '
				+ '	<label class="control-label" for="reasonCode">Reason:</label> ' 
				+ '	 <div class="controls controlText"> <input id="reasonCode" class="input-medium" type="text" name="reasonCode" ng-model="writeOff.reasonCode" required>'
				+ '<span ng-show=" submitted && addWriteOff.reasonCode.$error.required"><label class="error">Please provide reason Code </label></span></div> '
				+ '  </div> '
				
				+ '<div class="rowMargin"> '
				+ '	<label class="control-label" for="amountReceivable">Amount Receivable</label><ng-model="writeOff.amountReceivable"> ' 
				+ '	 <div class="controls"> $:{{amount}}<span ng-show=" submitted"></span></div> '
				+ '  </div> '
				
				+ '<div class="rowMargin"> '
				+ '	<label class="control-label" for="writeOffAmt">Write Off Amount</label> ' 
				+ '	 <div class="controls"> <input id="writeOffAmt" class="input-medium" type="text" name="writeOffAmt" ng-model="writeOff.writeOffAmt" required>'
				+ '<span ng-show=" submitted && addWriteOff.writeOffAmt.$error.required"><label class="error">Please provide Write Off Amount in numerics</label></span>'
				+ '  </div> '
				  
				  
				+ ' </form> ' + '</div> ',
			title : 'Write Off',
			success : {
				label : 'Confirm',
				fn : function() {
					this.submitted = true;
					this.writeOff.writeOffDate=this.writeOffDate;
					this.writeOff.entity =beIdentity;
					this.writeOff.amountReceivable=this.amount;
					$scope.addNewWriteOff(this.writeOff);
				}
			},
			cancel : {
				label : 'Cancel',
				fn : function() {
				}
			},
			validation : {
				fn : function() {
					this.submitted = true;
					this.writeOff.writeOffDate=this.writeOffDate;
					this.writeOff.entity = beIdentity;
					this.writeOff.amountReceivable=this.amount;
					if (this.addWriteOff.$invalid) {
						return false;
					}
					return true;
				}
			}
		});
	}
   
   
   $scope.popUpWriteOffBox = function() {
	   $scope.beIdentity = EventBusSrvc.subscribe('beIdentity');			
	   BaseServ.getAmountReceivable(null,$scope.beIdentity,null,amountReceivableSuccess,error);
		
	}; 	
	
	$scope.offSchedulePopUp = function(beId){
		//3rd parameter means asking for date or not on which invoice is to be generated.
		popupService.openOffSchedulePopup(beId,null,$scope,false);
	};
	
	$scope.addPaymentPopUp = function(beId){
		var tenantId = $scope.wfmAppContext.loggedInUser.tenantId;
		EventBusSrvc.publish('addPaymentControllerTenantId', tenantId);
		EventBusSrvc.publish('addPaymentSelectedBeId',beId);
		EventBusSrvc.publish('goToRelatedBEExternalId', beId);
		popupService.openPaymentPopup('entity');
	}
	
	$scope.addPaymentPopUpForGrp = function(beId,baExternalId){
		var tenantId = $scope.wfmAppContext.loggedInUser.tenantId;
		EventBusSrvc.publish('addPaymentControllerTenantId', tenantId);
		EventBusSrvc.publish('addPaymentSelectedBeId',beId);
		EventBusSrvc.publish('goToRelatedBEExternalId', beId);
		EventBusSrvc.publish('goToRelatedBAExternalId', baExternalId);
		popupService.openPaymentPopup('entity');
	}
	
	$scope.writeOnDetails = null;
	$scope.billable=EventBusSrvc.subscribe('billable');
	
	$scope.createManualAdjustment=function(){
		 $location.path('financials/manual-adjustments/manual-adjustments');
		// EventBusSrvc.publish('addManualAdjustmentSelectedBeId',beId);
		$scope.updateLeftNav('Manual Adjustments');
		$location.replace();
	}
	
	$scope.createDelinquencyExceptionRule=function(DelinquencyExceptionRuleJson){
		 //alert("hghgh");
		 $location.path('rules/delinquency/add-rule-delinquency-exception');
		 console.log(DelinquencyExceptionRuleJson);
		 EventBusSrvc.publish('DelinquencyExceptionRuleData',DelinquencyExceptionRuleJson);
		$scope.updateLeftNav('Delinquency');
		$location.replace();
	}
	
	$scope.populateWriteOnDetails = function(beType, beId, beIdentity, name) {
		$scope.writeOnDetails = {
				"identity" : null,
				"type" : beType,
				"beId" : beId,
				"beIdentity" : beIdentity,
				"billPeriod" : {},
				"name" : name,
				"writeOnFrom": 'entity'
		};
	}

	$scope.publishWriteOnDetails = function() {
		if($scope.writeOnDetails != null && $scope.writeOnDetails != undefined) {
			EventBusSrvc.publish('writeOnDetails', $scope.writeOnDetails);
			$location.path('entities/add-billing-item');
			$location.replace();
		}
	}
	
	$scope.publishPageBackFilters = function(pageBackFilters){
		EventBusSrvc.publish('pageBackFilters',pageBackFilters);
	}
	
	$scope.publistEventForInvoice = function(invoiceExternalId){
		EventBusSrvc.publish('invoiceExternalId', invoiceExternalId);
	};
	
	$scope.publistEventForPayment = function(paymentExternalId){
		EventBusSrvc.publish('paymentExternalId', paymentExternalId);
	};
	
	var type_be='';
	$scope.getFinancialSummary = function(accountId, type){
		type_be=type;
		var param={"accountId" : accountId};
		BaseServ.getFinancialSummary(param, getFinancialSummarySuccessCallback, getFinancialSummaryErrorCallBack);
	};
	
	$scope.getFinancialSummaryForAccExternalId = function(accExternalId, type){
		type_be=type;
		var param={"accExternalId" : accExternalId};
		BaseServ.getFinancialSummaryForAccExternalId(param, getFinancialSummarySuccessCallback, getFinancialSummaryErrorCallBack);
	};
	
	var getFinancialSummarySuccessCallback = function(data){
		$scope.financialSummary = {};
		if(data.lastInvoiceExternalId != null && data.lastInvoiceExternalId != undefined && data.lastInvoiceExternalId != '') {
			$scope.financialSummary.lastInvoiceIdentity = data.lastInvoiceIdentity;
			$scope.financialSummary.lastInvoiceExternalId = data.lastInvoiceExternalId;
			if(type_be == 'INDIVIDUAL') {
				$scope.financialSummary.lastInvoiceLink = '<a href="#/financials/invoices/individuals" title="View Invoice" ' 
					+ ' ng-click="publistEventForInvoice('+'\''+data.lastInvoiceExternalId+'\''+')">'+data.lastInvoiceExternalId+'</a>';
			} else if (type_be == 'GROUP') {
				$scope.financialSummary.lastInvoiceLink = '<a href="#/financials/invoices/groups" title="View Invoice" ' 
					+ ' ng-click="publistEventForInvoice('+'\''+data.lastInvoiceExternalId+'\''+')">'+data.lastInvoiceExternalId+'</a>';
			}
		} else {
			$scope.financialSummary.lastInvoiceLink = 'N/A';
		}
		
		if(data.lastPaymentIdentity != null && data.lastPaymentIdentity != undefined && data.lastPaymentIdentity != '') {
			$scope.financialSummary.lastPaymentIdentity = data.lastPaymentIdentity;
			$scope.financialSummary.lastPaymentExternalId = data.lastPaymentExternalId;
			
			$scope.financialSummary.lastPaymentLink = '<a href="#/financials/payments" title="View Invoice" ' 
			+ ' ng-click="publistEventForPayment('+'\''+data.lastPaymentExternalId+'\''+')">'+data.lastPaymentExternalId+'</a>';
		} else {
			$scope.financialSummary.lastPaymentLink = 'N/A';
		}
		
		if(data.lastPaidInvoiceDate != null && data.lastPaidInvoiceDate != undefined && data.lastPaidInvoiceDate != '' &&
				data.lastPaidInvoiceDate.date != null && data.lastPaidInvoiceDate.date != undefined && data.lastPaidInvoiceDate.date != '') {
			$scope.financialSummary.lastPaidInvoiceDate = $scope.toUTCDate(data.lastPaidInvoiceDate.date);
		} else {
			$scope.financialSummary.lastPaidInvoiceDate = 'N/A';
		}

		if(data.currentBalance != null && data.currentBalance != undefined && data.currentBalance != '') {
			$scope.financialSummary.currentBalance = data.currentBalance.value;
		} else {
			$scope.financialSummary.currentBalance = '0.0';
		}
		
		if(data.deliquent != null && data.deliquent != undefined && data.deliquent != '' && data.deliquent == true) {
			$scope.financialSummary.deliquent = 'Yes';
		} else {
			$scope.financialSummary.deliquent = 'No';
		}
		
		
		if(data.delinquencyExceptionPeriod != null && data.delinquencyExceptionPeriod != undefined && data.delinquencyExceptionPeriod != '' &&
				data.delinquencyExceptionPeriod.beginsOn != null && data.delinquencyExceptionPeriod.beginsOn != undefined &&
				data.delinquencyExceptionPeriod.beginsOn.date != null && data.delinquencyExceptionPeriod.beginsOn.date != undefined &&
				data.delinquencyExceptionPeriod.endsOn != null && data.delinquencyExceptionPeriod.endsOn != undefined &&
				data.delinquencyExceptionPeriod.endsOn.date != null && data.delinquencyExceptionPeriod.endsOn.date != undefined) {
			var beginsOn = $scope.toUTCDate(data.delinquencyExceptionPeriod.beginsOn.date);
			var endsOn = $scope.toUTCDate(data.delinquencyExceptionPeriod.endsOn.date);
		
			$scope.financialSummary.delinquencyExceptionPeriod = beginsOn + ' - ' + endsOn;
		} else {
			$scope.financialSummary.delinquencyExceptionPeriod = 'N/A';
		}
	}
	
	var getFinancialSummaryErrorCallBack = function(data){
		$scope.financialSummary = {};
		
	}
	
		
}];

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "BaseCntrl",
	"id" : hcentive.WFM.BaseCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "BaseCntrl",
	"id" : hcentive.WFM.BaseCntrl	
});
