/**
 * 
 */

hcentive.WFM.BaseServ = [ '$http', 'RESTSrvc',function($http, RESTSrvc) {
	
	var getAmountReceivable=function(params, data, transformer, afterSucess,afterFail){
		RESTSrvc.postForData('getAmountReceivable',null,data,null,afterSucess,afterFail);
	};
	
	var getFinancialSummary=function(params, afterSucess, afterFail){
		RESTSrvc.getForData('getFinancialSummary', params, null, afterSucess, afterFail);
	};
	
	var getFinancialSummaryForAccExternalId=function(params, afterSucess, afterFail){
		RESTSrvc.getForData('getFinancialSummaryForAccExternalId', params, null, afterSucess, afterFail);
	};
	
	var saveWriteOff=function(params, data, transformer, afterSucess,afterFail){
		RESTSrvc.postForData('saveWriteOff',null,data,null,afterSucess,afterFail);
	};
	return {
		getAmountReceivable:getAmountReceivable,
		getFinancialSummary:getFinancialSummary,
		getFinancialSummaryForAccExternalId : getFinancialSummaryForAccExternalId,
		saveWriteOff:saveWriteOff
	};
	
}];

//wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "BaseServ",
	"id" : hcentive.WFM.BaseServ
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "BaseServ",
	"id" : hcentive.WFM.BaseServ
});
