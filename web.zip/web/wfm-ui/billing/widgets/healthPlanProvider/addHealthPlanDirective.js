/**
 * 
 */
hcentive.WFM.addhealthplandirective = [ function() {

	return {
		restrict : 'E',
		 scope: {
			 carrierproductarray:'=',
			plancount:'=',
			  formname:'@',
			  submitted : '@'},
		templateUrl : function(elem, attr) {
			return getTemplateUrl(attr, "widgets/healthPlanProvider/healthplan.html")
		},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};

} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addhealthplandirective",
	"id" : hcentive.WFM.addhealthplandirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "addhealthplandirective",
	"id" : hcentive.WFM.addhealthplandirective
});
