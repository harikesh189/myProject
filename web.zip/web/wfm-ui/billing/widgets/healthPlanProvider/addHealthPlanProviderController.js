/**
 * 
 */hcentive.WFM.manageHealthPlanProviderCntrl=['$scope','$location','manageHealthPlanProviderServ','EventBusSrvc','$filter','$compile',
                             function($scope,$location,manageHealthPlanProviderServ,EventBusSrvc,$filter,$compile){

	 $scope.datePattern = /^(1[0-2]|0[0-9])[/]([0-2][0-9]|3[0-1])[/]([0-9]{4})$/;
	$scope.contactNumberArray = {};
	$scope.contactPersonName={};
	$scope.ContactPersonEmailIdArray={};
	$scope.AddressArray=[];
	$scope.CarrierProductArray=[];
	$scope.beIdentity = null;
	$scope.ContactArray=[];
	$scope.EmailArray=[];
	$scope.ContactPersonArray=[];
	$scope.isPreferredContactDetailChecked = true;
	 $scope.isPreferredEmailDetailChecked=true;
	 $scope.isPreferredAddressChecked=true;
	

	 function getContactPersonObj(){
		if(!$scope.businessEntity){
			$scope.businessEntity = {};
		}
		
		if(!$scope.businessEntity.issuer){
			$scope.businessEntity.issuer = {};	
		}
		
		
		if(!$scope.businessEntity.issuer.contactPersons){
			$scope.businessEntity.issuer.contactPersons = {};	
		}
		
		if(!$scope.businessEntity.issuer.contactPersons.contactPerson){
			$scope.businessEntity.issuer.contactPersons.contactPerson = {};	
		}
		
		if(!$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers){
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers = {};
		}
		
		if(!$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber){
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber = {};
		}
		
		if(!$scope.businessEntity.issuer.contactPersons.contactPerson.name){
			$scope.businessEntity.issuer.contactPersons.contactPerson.name={};	
		}
		
		if(!$scope.businessEntity.issuer.contactPersons.contactPerson.emailIds){
			$scope.businessEntity.issuer.contactPersons.contactPerson.emailIds = {};	
		}
		
		if(!$scope.businessEntity.issuer.contactPersons.contactPerson.emailIds.email){
			$scope.businessEntity.issuer.contactPersons.contactPerson.emailIds.email = {};	
		}
			
	 }
	 
	var afterSucess = function(data){
		
		if(data && data != 'Success'){
			 $("#message").html('<font color="red"><b>'+data+'</font></b>');
				$('html, body').animate({
			           'scrollTop':   $('#message').offset().top
			         }, 500);
			return;
		}
		
		var entity = data;
		$location.path('entities/health-plans');
		$location.replace();
	}

	var afterFail = function(){}

	$scope.addHealthPlanProvider = function(isValid){
		//traverse the whole address array to see if any of the address selected is preferred or not.
		$scope.isPreferredAddressChecked =  $scope.checkPrefferedAddress($scope.AddressArray);		
		
		  //traverse the whole contact array to see if any of the contact selected is preferred or not.
		$scope.isPreferredContactDetailChecked= $scope.checkPrefferedContact($scope.ContactArray);		
		
		
		//traverse the whole email array to see if any of the email selected is preferred or not.
       $scope.isPreferredEmailDetailChecked= $scope.checkPrefferedEmail($scope.EmailArray);		
	
       
		$scope.submitted = true;
		if(!isValid){
			return false;
		}
			$scope.termDateError=false;
			if( $scope.effectiveDate!= null && $scope.effectiveDate != undefined)
		    {
		    
		    var effectiveDate=new Date($scope.effectiveDate);
		   // var terminationDate=new Date($scope.terminationDate);
		    
		    if($scope.terminationDate!= null && $scope.terminationDate != undefined){
		    	  var terminationDate=new Date($scope.terminationDate);
		    	  if(effectiveDate.getTime()>terminationDate.getTime()){
		    		   $scope.termDateError=true;
		    		    
		    		    }
		    
		    }
		    }
		   
		    if($scope.termDateError || !isValid){
		    
		    
		     return false;
		    }
		    
		    if(!$scope.isPreferredAddressChecked ||  !$scope.isPreferredContactDetailChecked || !$scope.isPreferredEmailDetailChecked){
				return false;
			}
		var param = {};
		
		angular
		.forEach(
				$scope.ContactPersonArray,
				function(value, key) {
					if(value!=null || value!=undefined ){
					
					var obj ={};
					obj.workNumber=value.contactNumber;
					obj.email=value.email;
					obj.faxNumber=value.faxNumber;
					obj.firstName=value.firstName;
					obj.middleName=value.middleName;
					obj.lastName=value.lastName;
				
					if(value.contactNumber != '' || value.email != '' || value.faxNumber != '' || value.firstName != '' || value.middleName != '' || value.lastName != ''){
						$scope.contactPersonObj=obj;	
					}
				
					}});
		
		angular
		.forEach(
				$scope.CarrierProductArray,
				function(value, key) {
					if(value!=null || value!=undefined ){
					var obj ={};
					obj.productType=value.productType;
					obj.legalEntityType=value.legalEntityType;
					obj.authorityCertNumber=value.authorityCertNumber;
					obj.issuerId=value.issuerId;
					obj.domicileState=value.domicileState;
				
					$scope.planObj=obj;
				
					}});
		/*var productType=$scope.CarrierProductArray.productType;
		var legalEntityType= $scope.CarrierProductArray.legalEntityType;
		var authorityCertNumber=$scope.CarrierProductArray.authorityCertNumber;
		var issuerId=$scope.CarrierProductArray.issuerId;
		var domicileState= $scope.CarrierProductArray.domicileState;*/
		if($scope.businessEntity.issuer.status =='' || $scope.businessEntity.issuer.status ==undefined){
			$scope.businessEntity.issuer.status='ACTIVE';
		}
		else{
		$scope.businessEntity.issuer.status=($scope.businessEntity.issuer.status).toUpperCase();
		}
		//initializing the scope parameters
		$scope.businessEntity.issuer.contactNumbers={};
		$scope.businessEntity.issuer.contactNumbers.contactNumber={};
		
		$scope.businessEntity.issuer.emailIds={};
		$scope.businessEntity.issuer.emailIds.email={};
		$scope.businessEntity.issuer.addresses={};
		$scope.businessEntity.issuer.addresses.address={};
		$scope.businessEntity.issuer.issuerProducts={};
		$scope.businessEntity.issuer.issuerProducts.issuerProduct={};
		
		$scope.businessEntity.issuer.effectiveDate = $filter('date')(new Date($scope.effectiveDate),$scope.beTimeFormat);
		if($scope.terminationDate)
		$scope.businessEntity.issuer.terminationDate = $filter('date')(new Date(  $scope.terminationDate),$scope.beTimeFormat);
		
		var billable=$scope.businessEntity.issuer.billable;
		$scope.businessEntity.issuer.invoiceable=$scope.businessEntity.issuer.billable;
		//creating the empty array lists
		var contactPersonList = {};
		var contactPerson = [];
		var contactList = [];
		var emailIdList=[];
		var addressList=[];
		var carrierProdList=[];
		if($scope.contactPersonObj!=''&& $scope.contactPersonObj!=undefined && $scope.contactPersonObj != null){
		if($scope.contactPersonObj.workNumber!='' && $scope.contactPersonObj.workNumber!=undefined)
		{
			getContactPersonObj();
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber.number = $scope.contactPersonObj.workNumber;
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber.category = 'WORK';
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber.type = 'MOBILE';
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber.smsEnabled='true';
			contactList.push($scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber);
		}
		
		if($scope.contactPersonObj.faxNumber !='' && $scope.contactPersonObj.faxNumber!=undefined){
			getContactPersonObj();
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber ={};	
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber.category = 'WORK';
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber.number = $scope.contactPersonObj.faxNumber;
			$scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber.type = 'FAX';
			contactList.push($scope.businessEntity.issuer.contactPersons.contactPerson.contactNumbers.contactNumber);
		}
	
		if($scope.contactPersonObj.email !='' && $scope.contactPersonObj.email != undefined){
			getContactPersonObj();
			$scope.businessEntity.issuer.contactPersons.contactPerson.emailIds.email.emailId = $scope.contactPersonObj.email;
			$scope.businessEntity.issuer.contactPersons.contactPerson.emailIds.email.category='WORK';
			$scope.businessEntity.issuer.contactPersons.contactPerson.emailIds.email.preferred=true;
			emailIdList.push($scope.businessEntity.issuer.contactPersons.contactPerson.emailIds.email);
		}
		
		if($scope.contactPersonObj.firstName != undefined && $scope.contactPersonObj.firstName!= null){
			getContactPersonObj();
			$scope.businessEntity.issuer.contactPersons.contactPerson.name.firstName = $scope.contactPersonObj.firstName;
			
		}
		if($scope.contactPersonObj.middleName != undefined && $scope.contactPersonObj.middleName != null){
			getContactPersonObj();
			$scope.businessEntity.issuer.contactPersons.contactPerson.name.middleName = $scope.contactPersonObj.middleName;
			
		}
		if($scope.contactPersonObj.lastName!=undefined && $scope.contactPersonObj.lastName!=null){
			getContactPersonObj();
			$scope.businessEntity.issuer.contactPersons.contactPerson.name.lastName = $scope.contactPersonObj.lastName;
		}
		}
		
		
		if($scope.businessEntity.issuer.tin!=undefined){
	    	$scope.businessEntity.issuer.identifiers = {};
		    $scope.businessEntity.issuer.identifiers.identifier=[];
		    var idType = {id:$scope.businessEntity.issuer.tin,idQualifier:"TIN"};
		    $scope.businessEntity.issuer.identifiers.identifier.push(idType);
	    }
		
		
		
		$scope.businessEntity.issuer.addresses.address = [];	
		
		
		angular
		.forEach(
				$scope.AddressArray,
				function(value, key) {
					if(value!=null || value!=undefined ){
					var obj ={};
					obj.category=value.category.toUpperCase();
					obj.state=value.state;
					obj.city=value.city;
					obj.street1=value.street1;
					obj.street2=value.street2;
					obj.country=value.country;
					obj.zipcode=value.zipcode;
					if(value.isPrefferedAddress){
						obj.preferred = value.isPrefferedAddress;
					}
					else{
						obj.preferred = false;
					}
					$scope.businessEntity.issuer.addresses.address.push(obj);
					}});
		
		$scope.businessEntity.issuer.emailIds.email=[];
		angular
		.forEach(
				$scope.EmailArray,
				function(value, key) {
					if(value!=null || value!=undefined ){
					var emailObj ={};
					emailObj.category=value.category.toUpperCase();
					emailObj.emailId=value.emailId;
					if(value.isPrefferedEmail){
						emailObj.preferred = value.isPrefferedEmail;
						}
						else
							emailObj.preferred = false;
					
					$scope.businessEntity.issuer.emailIds.email.push(emailObj);
					}});
		
		
		$scope.businessEntity.issuer.contactNumbers.contactNumber=[];
		angular
		.forEach(
				$scope.ContactArray,
				function(value, key) {
					if(value!=null || value!=undefined ){
					var contactObj ={};
					contactObj.category=value.category.toUpperCase();
					contactObj.type=value.type;
					contactObj.number=value.contactNumber;
					contactObj.smsEnabled=value.smsEnabled;
					
					if(value.isPrefferedContact){
						contactObj.preferred = value.isPrefferedContact;
						}
						else
							contactObj.preferred = false;
					
					$scope.businessEntity.issuer.contactNumbers.contactNumber.push(contactObj);
					}});
	
		
		
		
		//start health plan details
		$scope.businessEntity.issuer.issuerProducts.issuerProduct.productType=$scope.planObj.productType;
		$scope.businessEntity.issuer.issuerProducts.issuerProduct.productIssuerId=$scope.planObj.issuerId;
		$scope.businessEntity.issuer.issuerProducts.issuerProduct.legalEntityType=$scope.planObj.legalEntityType;
		$scope.businessEntity.issuer.issuerProducts.issuerProduct.domicileState=$scope.planObj.domicileState;
		$scope.businessEntity.issuer.issuerProducts.issuerProduct.authorityCertNumber=$scope.planObj.authorityCertNumber;
		carrierProdList.push($scope.businessEntity.issuer.issuerProducts.issuerProduct);
		$scope.businessEntity.issuer.issuerProducts={};
		$scope.businessEntity.issuer.issuerProducts.issuerProduct=carrierProdList;
        //end		
		
		if($scope.businessEntity.issuer.contactPersons != undefined){
		if(contactList.length != 0 ){
			contactPersonList.contactNumbers = {};
			contactPersonList.contactNumbers.contactNumber = {};
			contactPersonList.contactNumbers.contactNumber = contactList;
		}
		if(emailIdList.length != 0){
			contactPersonList.emailIds={};
			contactPersonList.emailIds.email=emailIdList;
		}
		
		if($scope.businessEntity.issuer.contactPersons.contactPerson.name.firstName != '' || $scope.businessEntity.issuer.contactPersons.contactPerson.name.middleName != '' || $scope.businessEntity.issuer.contactPersons.contactPerson.name.lastName != '')
		contactPersonList.name=$scope.businessEntity.issuer.contactPersons.contactPerson.name;
		
		contactPersonList.preferred=true;
	//	contactPersonList.name=$scope.contactPersonName;
		
		if(contactList.length !=0 || emailIdList.length !=0 || (contactPersonList.name != '' && contactPersonList.name != undefined) ){
			contactPerson.push(contactPersonList);
			$scope.businessEntity.issuer.contactPersons.contactPerson = contactPerson;
		}
		}
		var data = $scope.businessEntity;
		
	/*	if($scope.pageType=='Edit'){
			var param={"type":'be',"pageType":$scope.pageType};
		manageHealthPlanProviderServ.editHealthPlanProvider(param,data,afterSucess,afterFail);
		}
		else{
			var param={"type":'be'};*/
		var param={"type":'be',"pageType":$scope.pageType};
		manageHealthPlanProviderServ.setHealthPlanProvider(param,data,afterSucess,afterFail);
	}
	
	
	
	$scope.viewPolicyForIssuerEntity=function(issuerObj){
		$scope.publishPageBackFilters($scope.pageBackFilters);
		EventBusSrvc.publish('issuerPolicyDetails',issuerObj);
		$location.path('entities/healthPlanProvider/view-policy-healthplan');
		$location.replace();
		
	}
	
	$scope.addresscount = -1;
	 
	 $scope.addAddress = function(){
	   $scope.addresscount = $scope.addresscount +1;
	   var addressObj = {"category":"","street2":"","state":"","country":"","street1":"","city":"","zipcode":"","isPrefferedAddress":false};
	   $scope.AddressArray[$scope.addresscount] = addressObj;
	   var id="addressDiv"+$scope.addresscount;
	   angular.element(document.getElementById('addressBoxDiv')).append($compile("<addaddressdirective id="+id+" addresscount="+$scope.addresscount+" formname='healthPlanProviderForm' addressarray='AddressArray' submitted={{submitted}}></addaddressdirective>")($scope));
	 }
	 
	 $scope.contactcount = -1;
		
	 $scope.addContact = function(){
		   $scope.contactcount = $scope.contactcount +1;
		   var contactObj = {"category":"","":"Select","contactNumber":"","smsEnabled":false,"isPrefferedContact":false};
		   $scope.ContactArray[$scope.contactcount] = contactObj;
		   var id="contactDiv"+$scope.contactcount;
		   angular.element(document.getElementById('contactBoxDiv')).append($compile("<addcontactdirective id="+id+" contactcount="+$scope.contactcount+" formname='healthPlanProviderForm' contactarray='ContactArray' submitted={{submitted}}></addcontactdirective>")($scope));
		 }
	 
 
 $scope.emailcount = -1;
   $scope.addEmail = function(){
	   $scope.emailcount = $scope.emailcount +1;
	   var emailObj = {"category":"","emailId":"","isPrefferedEmail":false};
	   $scope.EmailArray[$scope.emailcount] = emailObj;
	   var id="emailDiv"+$scope.emailcount;
	   angular.element(document.getElementById('emailBoxDiv')).append($compile("<addemaildirective  id="+id+" emailcount="+$scope.emailcount+" formname='healthPlanProviderForm' emailarray='EmailArray' submitted={{submitted}}></addemaildirective>")($scope));
	   }
   
   $scope.plancount = -1;
   $scope.addPlanDetails=function(){
	   $scope.plancount = $scope.plancount +1;
	   var planObj = {"productType":"","legalEntityType":"","authorityCertNumber":"","productIssuerId":"","domicileState":""};
	   $scope.CarrierProductArray[$scope.plancount] = planObj;
	   if($scope.plancount==0){
	   angular.element(document.getElementById('addPlanBoxDiv')).append($compile("<addhealthplandirective plancount="+$scope.plancount+" formname='healthPlanProviderForm' carrierproductarray='CarrierProductArray' submitted={{submitted}}></addhealthplandirective>")($scope));
   }}
   
   $scope.contactpersoncount = -1;
   $scope.addHealthPlanContactPersonDetail=function(){
	   $scope.contactpersoncount = $scope.contactpersoncount +1;
	   var contactPersonObj={"firstName":"","lastName":"","middleName":"","contactNumber":"","email":"","faxNumber":""};
	   $scope.ContactPersonArray[$scope.contactpersoncount] = contactPersonObj;
	   var id="contactPersonDiv"+$scope.contactpersoncount;
	   if($scope.contactpersoncount==0)
	   angular.element(document.getElementById('contactPersonBoxDiv')).append($compile("<addcontactpersondirective id="+id+" contactpersoncount="+$scope.contactpersoncount+" formname='healthPlanProviderForm' contactpersonarray='ContactPersonArray' submitted={{submitted}}></addcontactpersondirective>")($scope));
   }
	
	$scope.planCheck = false;
	$scope.setPlanCheck = function(){
		if($scope.planCheck){
			$scope.planCheck = false;
		}else{
			$scope.planCheck = true;
		}
	}

	$scope.contactCheck=false;
   $scope.setContactDetailCheck=function(){
	   if($scope.contactCheck){
		   $scope.contactCheck=false;
	   }
	   else{
		   $scope.contactCheck=true;
	   }
   }
	
   $scope.planDetailCheck=false;
   $scope.setHealthDetailsCheck=function(){
	   if($scope.planDetailCheck){
		   $scope.planDetailCheck=false;
	   }
	   else{
		   $scope.planDetailCheck=true;
	   }
   }
   
	$scope.viewHealthProviderDetails=function(index){

			var healthPlanObj = $scope.healthPlanList[index];
	   		var id = healthPlanObj.itemRecordId;
	   		var beIdentity =healthPlanObj.identity ;
	   		var beExternalId = healthPlanObj.entityId;
	   		EventBusSrvc.publish('beAuditInfo',getAuditInfo(healthPlanObj));
	   		$scope.fetchBillingAccount(beExternalId).then(function(success){
			   	   success.forEach(function(value){
			   		EventBusSrvc.publish('billingAccountExternalId',value.externalId);
				   		  
				   	   });
				   	},function(error){
				   		console.log("Error while getting billing accoutns");
				   	});
	   		
			$scope.publishPageBackFilters($scope.pageBackFilters);
			$scope.beIdentity = beIdentity;
			$scope.beExternalId = beExternalId;
			EventBusSrvc.publish('beIdentity',$scope.beIdentity);
			var param = {"id" : id,"type":'be'};
			manageHealthPlanProviderServ.viewHealthPlanProvider(param,afterSucessHealthPlanProviderrDetails,afterFail);
			
		}
		
		var pusblishGoToRelatedEvents = function(){
			EventBusSrvc.publish('goToRelatedBEIdentity', $scope.beIdentity);
			EventBusSrvc.publish('goToRelatedBEExternalId', $scope.beExternalId);
		}
		
		var afterSucessHealthPlanProviderrDetails=function(data){
			$scope.businessEntity = data.item;
			$scope.businessEntity.source = data.itemMetaInfo.tenant;
			EventBusSrvc.publish('healthPlanProviderDetails',$scope.businessEntity);
			var params=EventBusSrvc.subscribeAndInvalidatePayload('EntityParams');
			if(params && params != undefined){
				//$scope.businessEntity.createdOn=params.createdon;
				//$scope.businessEntity.createdBy=params.createdby;
				$scope.businessEntity.source=params.source;
				}
			pusblishGoToRelatedEvents();
			var WriteOffJson={'id':$scope.businessEntity.issuer.id.id,'firstName':$scope.businessEntity.issuer.establishmentName,'lastName':""};
		    EventBusSrvc.publish('WriteOffParameters',WriteOffJson);
		    EventBusSrvc.publish('billable',$scope.businessEntity.issuer.billable);
			$location.path('entities/healthPlanProvider/health-plans-details');
			$location.replace();
		}
		
		$scope.pageBack = function(){
			EventBusSrvc.publish('pageBackFilters',$scope.pageBackFilters);
			$location.path('entities/health-plans');
			$location.replace();
		}
		
		$scope.getHealthPlanDetails=function(pageType){
			$scope.updateLeftNav('Health Plans');
			$scope.pageType=pageType;
			var goToRelatedBEIdentity = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEIdentity');
			var goToRelatedBEExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
			$scope.businessEntity=EventBusSrvc.subscribe('healthPlanProviderDetails');
			$scope.goToRelatedBEExternalId = goToRelatedBEExternalId;
			var billingAccountExternalId=EventBusSrvc
			.subscribeAndInvalidatePayload('billingAccountExternalId');
			$scope.billingAccountExternalId=billingAccountExternalId;
			console.log($scope.billingAccountExternalId);
			
			var beAuditInfo = EventBusSrvc.subscribe('beAuditInfo');
			$scope.businessEntity.auditInfo = beAuditInfo;
			
			$scope.pageBackFilters = EventBusSrvc.subscribeAndInvalidatePayload('pageBackFilters');
			var billable = $scope.businessEntity.issuer.billable;
			if(billable){
			$scope.goToRelatedItemList = [
			                     {'name': 'Remittance', 'eventValue': [goToRelatedBEExternalId,billingAccountExternalId], 'redirectUrl': '#/financials/remits'},
			                     {'name': 'Manual Adjustments', 'eventValue': [goToRelatedBEExternalId,billingAccountExternalId], 'redirectUrl': '#/financials/manual-adjustments/refunds-payments'},
			                     {'name': 'Accounts', 'eventValue': [goToRelatedBEExternalId,billingAccountExternalId], 'redirectUrl': '#/financials/account-details'},
			                     {'name': 'FT Transactions', 'eventValue': [goToRelatedBEExternalId,billingAccountExternalId], 'redirectUrl': '#/financials/financials-transactions-report'}
			                 ];
			}
			else{
			$scope.goToRelatedItemList = [
							     {'name': 'Remittance', 'eventValue': [goToRelatedBEExternalId,billingAccountExternalId], 'redirectUrl': '#/financials/remits'},
							     {'name': 'Accounts', 'eventValue': [goToRelatedBEExternalId,billingAccountExternalId], 'redirectUrl': '#/financials/account-details'},
							     {'name': 'FT Transactions', 'eventValue': [goToRelatedBEExternalId,billingAccountExternalId], 'redirectUrl': '#/financials/financials-transactions-report'}
						     ];
			}
			$scope.addressesList = $scope.businessEntity.issuer.addresses;
			$scope.contactsList = $scope.businessEntity.issuer.contactNumbers.contactNumber;
			$scope.emailList = $scope.businessEntity.issuer.emailIds;
			
			var customerName = '';
			if($scope.businessEntity != null && $scope.businessEntity != undefined && 
					$scope.businessEntity.issuer != null && $scope.businessEntity.issuer != undefined)
				customerName = $scope.businessEntity.issuer.establishmentName;
			var adjustmentJson={'id':$scope.businessEntity.issuer.id.id,'name':customerName,'type':'HealthPlanProvider','identity':goToRelatedBEIdentity,'businessEntityType':'HealthPlanProvider'};
			EventBusSrvc.publish('EntityType',adjustmentJson);
			$scope.populateWriteOnDetails('HealthPlanProvider', goToRelatedBEExternalId, goToRelatedBEIdentity, customerName);
			$scope.healthProductList=$scope.businessEntity.issuer.issuerProducts;
			if($scope.businessEntity.issuer.contactPersons && $scope.businessEntity.issuer.contactPersons.contactPerson.length != 0){
				$scope.contactPersonList=$scope.businessEntity.issuer.contactPersons;
			}
			
			if(pageType !=  undefined && pageType =='Edit'){
				$scope.populateAddress();
				$scope.populateContacts();
				$scope.populatePlanDetails();
				$scope.populateEmails();
				 $scope.populateContactPerson();
				$scope.terminationDate = $scope.businessEntity.issuer.terminationDate;
				$scope.effectiveDate = $scope.businessEntity.issuer.effectiveDate;
			}
		}
		
		
		
		 $scope.populateContactPerson = function(){
			 if($scope.contactPersonList && $scope.contactPersonList != undefined){
			 angular
				.forEach(
						$scope.contactPersonList.contactPerson,
						function(value, key){
					$scope.contactpersoncount = $scope.contactpersoncount +1;
					$scope.ContactPersonArray[$scope.contactpersoncount] = entityContactPersonTransformer(value);
					 var id="contactPersonDiv"+$scope.addresscount;
					if (value.preferred) {
						angular.element(document.getElementById('contactPersonBoxDiv')).append($compile("<addcontactpersondirective id="+id+" contactpersoncount="+$scope.contactpersoncount+" formname='healthPlanForm' contactpersonarray='ContactPersonArray'></addcontactpersondirective>")($scope));
					}
				});
		 }
		}
		 
		 $scope.populatePlanDetails = function(){
			 angular
				.forEach(
						$scope.healthProductList.issuerProduct,
						function(value, key){
					$scope.plancount = $scope.plancount +1;
					$scope.CarrierProductArray[$scope.plancount] = getCarrierProductTransformer(value);
					
						angular.element(document.getElementById('addPlanBoxDiv')).append($compile("<addhealthplandirective plancount="+$scope.plancount+" formname='healthPlanForm' carrierproductarray='CarrierProductArray'></addhealthplandirective>")($scope));
					
				});
		 }
		
		 $scope.populateAddress = function(){
		 angular
			.forEach(
					$scope.addressesList.address,
					function(value, key) {
		   $scope.addresscount = $scope.addresscount +1;
		   $scope.AddressArray[$scope.addresscount] = entityAddressTransformer(value,$scope.addressesList.address.length);
		   var id="addressDiv"+$scope.addresscount;
		   angular.element(document.getElementById('addressBoxDiv')).append($compile("<addaddressdirective id="+id+" addresscount="+$scope.addresscount+" formname='healthPlanForm' addressarray='AddressArray'></addaddressdirective>")($scope));
		});
		}
		
	 $scope.populateContacts = function(){
		angular
			.forEach(
					$scope.contactsList,
					function(value, key){
				$scope.contactcount = $scope.contactcount +1;
				$scope.ContactArray[$scope.contactcount] = entityContactsTransformer(value,$scope.contactsList.length);
				 var id="contactDiv"+$scope.contactcount;
				angular.element(document.getElementById('contactBoxDiv')).append($compile("<addcontactdirective id="+id+" contactcount="+$scope.contactcount+" formname='healthPlanForm' contactarray='ContactArray'></addcontactdirective>")($scope));
			});
	 }
	 
	 $scope.populateEmails = function(){
		angular
			.forEach(
					$scope.emailList.email,
					function(value, key){
				$scope.emailcount = $scope.emailcount + 1;
				$scope.EmailArray[$scope.emailcount] = entityEmailsTransformer(value,$scope.emailList.email.length);
				  var id="emailDiv"+$scope.emailcount;
				angular.element(document.getElementById('emailBoxDiv')).append($compile("<addemaildirective id="+id+" emailcount="+$scope.emailcount+" formname='healthPlanForm' emailarray='EmailArray'></addemaildirective>")($scope));
			})
	 },
		 
		$scope.setFormName=function(formName){
		$scope.pageType='Add';	   
		 $scope.formName = formName;
		   }
   
}];

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "manageHealthPlanProviderCntrl",
	"id" : hcentive.WFM.manageHealthPlanProviderCntrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "manageHealthPlanProviderCntrl",
	"id" : hcentive.WFM.manageHealthPlanProviderCntrl	
});