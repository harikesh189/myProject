hcentive.WFM.addclientdirective=[function(){
	
	return {
		restrict : 'EA',
		templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/client/client.html")},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};
	
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addclientdirective",
	"id" : hcentive.WFM.addclientdirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
		"name" : "addclientdirective",
		"id" : hcentive.WFM.addclientdirective
	});
                                  
                                  
                                  
                                  
                                  
                      