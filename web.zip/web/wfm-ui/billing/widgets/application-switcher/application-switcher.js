 hcentive.WFM.ApplicationSwitcher = function() {
	return {
		restrict: 'E',
		replace: false,
		scope: {
			userConfiguration: '=',
			currentUser: '=',
			active: '='
		},
		templateUrl: 'widgets/application-switcher/application-switcher.html',
		link: function(scope, element, attrs, fn) {


		},
		controller: function($scope){
			function getApplications(config, user){
				var baseUrl  = window.location.pathname;
				var switchUrl = baseUrl.substring(0, baseUrl.lastIndexOf('/' + hcentive.WFM.client_id));
				var subscribedApplications = [];
				var applications;
				angular.forEach(config,function(configuration){
					if(configuration.key===undefined && configuration.applications!==undefined){
						applications = configuration;
					}
				});
				
				angular.forEach(applications.applications, function(application){
					var subscribedApplication = {};
					subscribedApplication.visible = false;
					subscribedApplication.name = application.name;
					subscribedApplication.url = switchUrl + application.url;
					angular.forEach(user.roles, function(role){
						angular.forEach(role.permissions, function(permission){
							if(angular.lowercase(application.name)===angular.lowercase(permission.operationCode)){
								subscribedApplication.visible = true;
								if(angular.lowercase(application.name)===angular.lowercase($scope.active)){
									subscribedApplication.active = true;
								}
							}
						});
					});
					subscribedApplications.push(subscribedApplication);
				});
				if(subscribedApplications.length<=0){
					var baseUrl  = window.location.pathname;
					$scope.applicationSwitcher=true;
					var switchUrl = baseUrl.substring(0, baseUrl.lastIndexOf('/' + hcentive.WFM.client_id));
					var s1 = {name:'ebill', visible:true, active:false, url: switchUrl + "/ebill/"};
					var s2 = {name:'billing', visible:true, active:true, url:switchUrl + "/billing/"};
					var s3 = {name:'system', visible:true, active:false, url: switchUrl+ "/system/"};
					subscribedApplications.push(s1);
					subscribedApplications.push(s2);
					subscribedApplications.push(s3);
				}
				return subscribedApplications;
			}
			$scope.applications = getApplications($scope.userConfiguration, $scope.currentUser);
			$scope.switchApp = function(app){
				window.location.href = app.url;
			};
		}
	};
};

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "applicationSwitcher",
	"id" : hcentive.WFM.ApplicationSwitcher
});
 
 function closeLogoutDropdown(){
	 
	 document.getElementById( 'logoutDiv' ).style.display = 'none';
 }
