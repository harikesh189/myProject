hcentive.WFM.addWriteOffController = [
		'$scope',
		'EventBusSrvc',
		'AssociatedEntitiesService',
		'FinancialPaymentService',
		'popupService','entityService','RESTSrvc','FinancialsWriteOffService',
		function($scope, EventBusSrvc, systemService,FinancialPaymentService,popupService,entityService,RESTSrvc,FinancialsWriteOffService) {
			
			$scope.entities = [];
			$scope.getEntities = function(viewValue){
				return  entityService.fetchBusinessEntity(viewValue,$scope.entityType,$scope);
			}
			
			$scope.payers = [];
			$scope.getPayers = function(viewValue){
				return  entityService.fetchBusinessEntity(viewValue,$scope.payerType,$scope);
			}
			
			function isValidDate(date){
				var timestamp=Date.parse(date);
				return !isNaN(timestamp);
			}
			
			var isNullOrUndefinedOrEmpty = function(obj) {
				return (obj === null || obj === undefined || obj === '');
			}
			var validateForm = function(writeoffObj){
				
				$scope.submitted = true;
				//entity id
					if(isNullOrUndefinedOrEmpty($scope.entityId)){
						$scope.entityIdError = true;
					}
					else{
						$scope.entityIdError = false;	
					}
				
				
				//effective date error
					if(isNullOrUndefinedOrEmpty(writeoffObj.writeOffDate.$viewValue)){
						$scope.effectiveDateError = true;
					}
					else{
						$scope.effectiveDateError = false;
						if(!isValidDate(writeoffObj.writeOffDate.$viewValue)){
							$scope.invalidDate = true;
						}
						else{
							$scope.invalidDate = false;
						}
					}
				
				//paid amount error
					if(isNullOrUndefinedOrEmpty(writeoffObj.writeOffAmount.$viewValue)){
						$scope.paidAmountError = true;
					}
					else{
						$scope.paidAmountError = false;	
					}
					
					//valid amount error
					var enteredAmount = writeoffObj.writeOffAmount.$viewValue;
					if(isNaN(enteredAmount) || enteredAmount <= 0 || (parseFloat(enteredAmount).toFixed(2) - parseFloat(enteredAmount) != 0)){
						$scope.validAmountError = true;
					}
					else{
						$scope.validAmountError = false;
					}
					
				return !($scope.entityIdError || $scope.effectiveDateError || $scope.paidAmountError || $scope.validAmountError || $scope.invalidDate);       
			}
			$scope.addingWriteoff = function(_writeOffObj) {
				
				if(!validateForm(_writeOffObj)){
					return;
				}
				
				var writeOffDate = $scope.writeOffDate;
				var writeOffYear = writeOffDate.split("/")[2];
				var writeOffMonth = writeOffDate.split("/")[0];
				var writeOffDate = writeOffDate.split("/")[1];
				
				
				var transcationTime = writeOffYear +'-'+writeOffMonth+'-'+writeOffDate+'T00:00:00';
				
				var writeOffJson={
						
					 "writeOffAmount":{"currency":{"name":"US Dollar","symbol":"$","shortName":"USD"},"value":$scope.writeOffAmount},
					 "beneficiary":{"business_entity_type":"Broker","externalId":$scope.entityId.externalId},
					 "beneficiaryAccount":{"accountType":"INVOICE_ACCOUNT","identity":"323"},
					 "writeOffDate":{"date":transcationTime}
					 };
				
				var successWriteOff = function(success){
					
					if (success.errors != undefined || success.errors.length!=0) {
						
						console.log(success.errors);
						$scope.errors = success.errors;
						var msg="";
						angular.forEach($scope.errors, function(value) {
								msg=value.errorMsg+msg;

							});
						popupService.openSuccessErrorPopUp('Add Write Off',msg);
						
					}else{
						popupService.openSuccessErrorPopUp('Add Write Off','Write Off added successfully.');
						EventBusSrvc.publish('addWriteoffProcessCompletedSuccess', 'true');
					}
					
					$scope.$modalCancel();
				}
				
				var failWriteOff = function(data){
					popupService.openSuccessErrorPopUp('Add Write Off','Unable to add Write Off.');
					EventBusSrvc.publish('addWriteoffProcessCompletedSuccess', 'false');
					$scope.$modalCancel();
				}
				
				FinancialsWriteOffService.saveWriteOff(null, writeOffJson,null, successWriteOff, failWriteOff);
				
			}

	
		} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'addWriteOffController',
	'id' : hcentive.WFM.addWriteOffController
});
