hcentive.WFM.addPaymentController = [
		'$scope',
		'EventBusSrvc',
		'AssociatedEntitiesService',
		'FinancialPaymentService',
		'popupService','entityService','RESTSrvc','fetchGroupServ',
		function($scope, EventBusSrvc, systemService,FinancialPaymentService,popupService,entityService,RESTSrvc,fetchGroupServ) {
			
			$scope.entities = [];
			$scope.getEntities = function(viewValue){
				$scope.addPayment.entityType.$touched = true;
				if(isNullOrUndefinedOrEmpty($scope.entityType)){
					return;
				}
				return  entityService.fetchBusinessEntity(viewValue,$scope.entityType,$scope);
			}

			$scope.getSubscriptions = function(beId){
				var beExternalId;
				if(null!=beId && beId!=''){
					beExternalId = beId;
				}else if(null!=$scope.entityId && $scope.entityId!=''){
					beExternalId = $scope.entityId.externalId;
				}
				
				$scope.pagination = defaultPagination('auditInfo.modifiedAt', 'desc');
				var serachCriteria = {};
				serachCriteria.criteria = {};
				 serachCriteria.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
				 serachCriteria.criteria["owner.externalId"] = {
					"operator": "=",
					"columnValue": "'" + beExternalId + "'"
				};
				 fetchGroupServ.getBillingAccountsSubscriptions(serachCriteria, successCallback, errorCallback);
			}
			
			  var successCallback = function(data) {
					console.log('success call back');
					$scope.pagination.totalNoPages = data.totalPages;
					$scope.pagination.totalElements = data.totalElements;
					$scope.subscriberList = getSubscribers(data);
				}
			
			var errorCallback = function(data){
				console.log('Error fetching subsciber data');
			}
			
			function getSubscribers(data){
				var subscriberList = [];
					
					angular
					.forEach(
					data.content, 
					function(value, key) {
						var subscriberObj = {};
						subscriberObj.subscriptionId = value.externalId;
						subscriberList.push(subscriberObj);
					});
					return subscriberList;
				}
				
			$scope.addPaymentType = EventBusSrvc.subscribeAndInvalidatePayload('addPaymentGeneralOrEntity');
			$scope.beId = EventBusSrvc.subscribeAndInvalidatePayload('addPaymentSelectedBeId');
			$scope.baExternalId= EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBAExternalId'); 
			if($scope.addPaymentType && $scope.addPaymentType === 'entity'){
				$scope.entityId = {};
				$scope.entityId.externalId = $scope.beId; 
			}
			
			$scope.cancel = function(){
				$scope.$modalCancel();
			}
			
			$scope.transactionIdError = false;
			$scope.entityIdError = false;
			$scope.effectiveDateError = false;
			$scope.paymentSourceError = false;
			$scope.paidAmountError = false;
			$scope.validAmountError = false;
			$scope.invalidDate = false;
			
			
			var date = new Date(), year = date.getFullYear(), month = date
					.getMonth();
			$scope.currentDate = (month+1)+'/'+date.getDate()+'/'+year;
			
			$scope.isValidDate = function(date){
				var timestamp=Date.parse(date);
				return !isNaN(timestamp);
			}
			
			
		var isNullOrUndefinedOrEmpty = function(obj) {
				return (obj === null || obj === undefined || obj === '');
			}
			
			$scope.isValidAmount = function(enteredAmount){
				if((isNaN(enteredAmount) || enteredAmount <= 0 || (parseFloat(enteredAmount).toFixed(2) - parseFloat(enteredAmount) != 0)) && !$scope.paidAmountError){
					return false;
				}
				return true;
			}
			
			
			
			$scope.addNewPayment = function(_paymentObj) {
				$scope.addPayment.$submitted = true;
				 var enteredAmount=$scope.payment.paymentAmount;
                 if((isNaN(enteredAmount) || enteredAmount <= 0 || (parseFloat(enteredAmount).toFixed(2) - parseFloat(enteredAmount) != 0)) && !$scope.paidAmountError){
                         return false;
                 }

				if(!$scope.addPayment.$valid || ($scope.entityId == undefined  || $scope.entityId == '' || $scope.entityId.externalId == '')){
					return;
				}
				
				var tenantId = EventBusSrvc.subscribeAndInvalidatePayload('addPaymentControllerTenantId');
				
				if($scope.addPaymentType == 'general'){
					$scope.beId = $scope.entityId.externalId;
				}
				
			/*	var identificationNumberTag = '';
				if (_paymentObj.payMethod.$viewValue == 'cash') {
					identificationNumberTag = '<cash></cash>';
				} else if (_paymentObj.payMethod.$viewValue == 'check') {
					identificationNumberTag = '<pc><checkNumber>'
							+ _paymentObj.identificationNo.$viewValue
							+ '</checkNumber></pc>';
				} else {
					identificationNumberTag = '<moneyOrder><moneyOrderNumber>'
							+ _paymentObj.identificationNo.$viewValue
							+ '</moneyOrderNumber></moneyOrder>';
				}*/

				var paymentDate = _paymentObj.paymentDate.$viewValue;
				var paymentYear = paymentDate.split("/")[2];
				var paymentMonth = paymentDate.split("/")[0];
				var paymentDate = paymentDate.split("/")[1];

				var transcationTime = paymentYear + '-' + paymentMonth + '-'
						+ paymentDate + 'T00:00:00';

				/*var addPaymentXML = '<paymentReceipts xmlns:xsi="http://www.w3.//org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../payment-receipt.xsd">'
						+ '<metaInfo>' + '<source>'
						+ tenantId
						+ '</source>'
						+ '<totalCount>1</totalCount>'
						+ '</metaInfo>'
						+ '<paymentReceipt>'
						+ '<transactionTime>'
						+ transcationTime
						+ '</transactionTime>'
						+ '<status>SUCCESS</status>'
						+ '<customer>'
						+ '<customerId>'
						+ '<id>'
						+ $scope.beId
						+ '</id>'
						+ '</customerId>'
						+ '</customer>'
						+ '<oneTimePaymentInfo>'
						+ '<transactionId>'
						+ _paymentObj.transactionId.$viewValue
						+ '</transactionId>'
						+ identificationNumberTag
						+ '<amount>'
						+ _paymentObj.paymentAmount.$viewValue
						+ '</amount>'
						+ '</oneTimePaymentInfo>'
						+ '<additionalInfos>'
						+ '<additionalInfo>'
						+ '<name>paymentSource</name>'
						+ '<description>description</description>'
						+ '<qualifier>'+tenantId+'</qualifier>'
						+ ' <value>'
						+ _paymentObj.paymentSource.$viewValue
						+ '</value>'
						+ '</additionalInfo>'
						+ '</additionalInfos>'
						+ '</paymentReceipt>' + '</paymentReceipts>';
*/
				//alert(addPaymentXML);
				
				
				var  paymentInfoJson = {};
				paymentInfoJson.transactionTime = transcationTime;
				paymentInfoJson.customer = {};
				paymentInfoJson.customer.customerId = {};
				paymentInfoJson.customer.customerId.id = $scope.beId;
				
				
				paymentInfoJson.oneTimePaymentInfo = {};
				paymentInfoJson.oneTimePaymentInfo.transactionId = _paymentObj.transactionId.$viewValue;
				paymentInfoJson.oneTimePaymentInfo.amount = _paymentObj.paymentAmount.$viewValue;
				
				paymentInfoJson.additionalInfos = {};
				paymentInfoJson.additionalInfos.additionalInfo = [];
				var additionalInfo = {};
				additionalInfo.name = 'Source';
				additionalInfo.description = 'description';
				additionalInfo.value = _paymentObj.paymentSource.$viewValue;
				paymentInfoJson.additionalInfos.additionalInfo.push(additionalInfo);
				
				paymentInfoJson.referenceIdentities = {};
				paymentInfoJson.referenceIdentities.referenceIdentity = [];

				var referenceIdentity = {};
				referenceIdentity.source = _paymentObj.paymentSource.$viewValue;;
				referenceIdentity.qualifier = 'billingAccountId';  
				if($scope.payment.subscriptionId)
				referenceIdentity.referenceId = $scope.payment.subscriptionId;
				else
					referenceIdentity.referenceId =$scope.baExternalId;
				paymentInfoJson.referenceIdentities.referenceIdentity.push(referenceIdentity);
				
				EventBusSrvc.publish('goToRelatedBAExternalId',referenceIdentity.referenceId);
				paymentInfoJson.status = 'SUCCESS';
				if (_paymentObj.payMethod.$viewValue == 'cash') {
					paymentInfoJson.oneTimePaymentInfo.cash = {};
					//Nothing
				} else if (_paymentObj.payMethod.$viewValue == 'check') {
					paymentInfoJson.oneTimePaymentInfo.pc = {};
					paymentInfoJson.oneTimePaymentInfo.pc.checkNumber = _paymentObj.identificationNo.$viewValue;
				} else {
					paymentInfoJson.oneTimePaymentInfo.moneyOrder = {};
					paymentInfoJson.oneTimePaymentInfo.moneyOrder.moneyOrderNumber = _paymentObj.identificationNo.$viewValue;
				}
				

				
				//console.log('addPaymentXML'+addPaymentXML);
				console.log('paymentInfoJson :: ' +JSON.stringify(paymentInfoJson));
				
				var paymentAddedSucc = function(data){
					if(data === 'SUCCESS'){
						popupService.openSuccessErrorPopUp('Add Payment','Payment added successfully.');
						EventBusSrvc.publish('addPaymentProcessCompletedSuccess', 'true');
						$scope.$modalCancel();
					}else{
						popupService.openSuccessErrorPopUp('Add Payment',data);
					}
				}
				
				var paymentAddedErr = function(data){
					popupService.openSuccessErrorPopUp('Add Payment','Unable to add payment.');
					EventBusSrvc.publish('addPaymentProcessCompletedSuccess', 'false');
					$scope.$modalCancel();
				}
				
				//console.log('addPaymentXML'+addPaymentXML);
				console.log('paymentInfoJson :: ' +JSON.stringify(paymentInfoJson));
				
				FinancialPaymentService.addPaymentReceipt(null, paymentInfoJson,
						paymentAddedSucc, paymentAddedErr);
			}

		} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'addPaymentController',
	'id' : hcentive.WFM.addPaymentController
});
