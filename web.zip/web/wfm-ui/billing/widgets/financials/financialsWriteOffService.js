(function() {
	hcentive.WFM.FinancialsWriteOffService = [
			'$http',
			'RESTSrvc',
			function($http, RESTSrvc) {

				var getAmountReceivable=function(params, data, transformer, afterSucess,afterFail){
					RESTSrvc.postForData('getAmountReceivable',null,data,null,afterSucess,afterFail);
				};
				var saveWriteOff=function(params, data, transformer, afterSucess,afterFail){
					RESTSrvc.postForData('saveWriteOff',null,data,null,afterSucess,afterFail);
				};
				
				var getAllWriteoff = function(params, data,
						transformer, successCallback, errorCallback) {
					RESTSrvc.postForData('getAllWriteoff', params,
							data, null, successCallback, errorCallback);
				};
				
				return {
					getAmountReceivable:getAmountReceivable,
					saveWriteOff:saveWriteOff,
					getAllWriteoff : getAllWriteoff
				};
				
			} ];

		//wireup the service to application
		hcentive.WFM.configData[hcentive.WFM.operator].services.push({
			"name" : "FinancialsWriteOffService",
			"id" : hcentive.WFM.FinancialsWriteOffService
		});
	//
})();
