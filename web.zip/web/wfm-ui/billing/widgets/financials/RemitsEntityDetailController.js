/**
 * Created by Amit.Ag on 19/11/2014.
 */
hcentive.WFM.RemitsEntityDetailController = [
		'$scope',
		'FinancialRemitsService',
		'EventBusSrvc', '$translate', 
		function($scope, financialsRemitsService, EventBusSrvc, $translate) {
			var remitDetails = EventBusSrvc.subscribe('remitDetails');
			var isExcludeBlankIssuerEntityId = remitDetails.isExcludeBlankIssuerEntityId;
			$scope.messsageState = 'AllSelected';
			$scope.selectedCountOnPage = 0;
			$scope.tempExcludedMap = JSON.parse(JSON.stringify(remitDetails.excludedBeMap));
			$scope.subscriberDetails = remitDetails.remitSubscriberDetails;
			$scope.isExclusion = remitDetails.isExclusion;
			$scope.partnerDetails = remitDetails.partnerDetails;
			$scope.totalSelectedAmount = $scope.subscriberDetails.selectedAmount;

			$scope.pagination = defaultPagination('remitPay.exchangeSubscriberId', '');
			$scope.remitDetailTableFilters = [];
			
			$scope.totalSelectedCount = '';
			$scope.totalSelectedCountFxd = '';
			
			var beIdentity = $scope.subscriberDetails.businessEntityIdentity;
			if($scope.tempExcludedMap[beIdentity] && $scope.tempExcludedMap[beIdentity]['TOTAL_SELECTED_COUNT']){
				$scope.totalSelectedCount = $scope.tempExcludedMap[beIdentity]['TOTAL_SELECTED_COUNT'];
			}
			

			$scope.remitDetailTableHeaders = [ {
				'isSortable' : 'no',
				'key' : 'selectAllAction',
				'desc' : '',
				'contentType' : 'html',
			'value' : '<input type="checkbox" ng-init ="selectAllDetailHeader=true" ng-model="selectAllDetailHeader" name="selectAllDetailHeader" id="selectAllDetailHeader" ng-change="selectAllDetailHeaderFn(selectAllDetailHeader)">'
			}, {
				'isSortable' : 'yes',
				'key' : 'exchangeSubscriberId',
				'desc' : 'Exchange Subscriber ID',
				'contentType' : 'String',
				'sortableKey' : 'remitPay.exchangeSubscriberId'
			}, {
				'isSortable' : 'yes',
				'key' : 'issuerSubscriberId',
				'desc' : 'Issuer Subscriber ID',
				'contentType' : 'String',
				'sortableKey' : 'remitPay.issuerSubscriberId'
			}, {
				'isSortable' : 'yes',
				'key' : 'subscriberName',
				'desc' : 'Subscriber Name',
				'contentType' : 'String',
				'sortableKey' : 'remitPay.subscriberName'

			}, {
				'isSortable' : 'yes',
				'key' : 'payableAmount',
				'desc' : 'Payable Amount',
				'contentType' : 'Currency',
				'sortableKey' : 'amount.value',
				'sortableKey' : 'outstandingAmount'
			}, {
				'isSortable' : 'no',
				'key' : 'selectedAmount',
				'desc' : 'Selected Amount',
				'contentType' : 'Currency'
			}, {
				'isSortable' : 'no',
				'key' : 'expandTableAction',
				'desc' : '',
				'contentType' : 'html'
			} ];

			$scope.remitInnerTableHeaders = [ {
				'isSortable' : 'no',
				'key' : 'selectCoverageAction',
				'desc' : '',
				'contentType' : 'html'
			}, {
				'isSortable' : 'no',
				'key' : 'coveragePeriod',
				'desc' : 'Period',
				'contentType' : 'String'
			}, {
				'isSortable' : 'no',
				'key' : 'planName',
				'desc' : 'Plan/Benefit',
				'contentType' : 'String'
			}, {
				'isSortable' : 'no',
				'key' : 'amountName',
				'desc' : 'Amount Name',
				'contentType' : 'String'
			}, {
				'isSortable' : 'no',
				'key' : 'outstandingAmount',
				'desc' : 'Amount',
				'contentType' : 'Currency'
			} ];
			
			$scope.selectAllDetailHeaderFn = function(selectAllDetailHeader){
				var pageRecordsCount = $scope.subscriberRemitsList.length;
				
				if(selectAllDetailHeader){
					if($scope.totalSelectedCount != 0 ){
						var selectedCountFromOtherPages = $scope.totalSelectedCount - $scope.selectedCountOnPage;
						if(selectedCountFromOtherPages === 0){
							$scope.totalSelectedCount = 0;
						}else{
							$scope.totalSelectedCount  = selectedCountFromOtherPages;	
						}
					}
					$scope.selectedCountOnPage = 0;
				}else{
					$scope.selectedCountOnPage = pageRecordsCount;
				}
				
				var rowIndex = 0;
				var checkBoxEventArray = [];
				angular.forEach(
					$scope.subscriberRemitsList,
					function(subscriberValue, subscriberKey) {
						
						var businessEntityIdentity = subscriberValue.businessEntityIdentity;
						var beType = subscriberValue.beType;
						var selectedAmount = subscriberValue.selectedAmount;
						subscriberValue.isChecked = selectAllDetailHeader;
						$scope.updateSubsAndCovgExclusionData(selectAllDetailHeader,businessEntityIdentity,beType,subscriberValue.exchangeSubscriberId,rowIndex);
						$scope.updateAmount(selectAllDetailHeader,rowIndex);
						checkBoxEventArray = prepareCheckBoxEventArray('Remit_'+ rowIndex,selectAllDetailHeader,checkBoxEventArray);
						rowIndex =rowIndex +1;
				});
				
				publishCheckBoxEventArray(checkBoxEventArray);
			}
			
			function updateHeaderCheckBox(){
				if($scope.selectedCountOnPage == $scope.subscriberRemitsList.length ){
					publishCheckBoxEvent('selectAllDetailHeader',true);
				}else{
					publishCheckBoxEvent('selectAllDetailHeader',false);
				}			
			}

			$scope.isSubscriberExclusion = $scope.isExclusion;

			if ($scope.tempExcludedMap != undefined && $scope.tempExcludedMap[beIdentity] != undefined && $scope.tempExcludedMap[beIdentity]['IS_ALL_SELECTED'] != undefined) {
				$scope.isSubscriberExclusion = $scope.tempExcludedMap[beIdentity]['IS_ALL_SELECTED'];
			}

			function addEntry(businessEntityIdentity, beType, exchangeSubscriberId, ftEntryId,
					excludedBeMap,rowIndex) {
				var excludedExchangeMap = $scope.tempExcludedMap[businessEntityIdentity];
				if (excludedExchangeMap == undefined) {
					excludedExchangeMap = new Object();
				}
				if (ftEntryId == undefined) {
					var excludedCoverageList = new Array();
					var rowIndex = 0;
					angular
							.forEach(
									$scope.subscriberRemitsList,
									function(subscriberObjValue,
											subscriberObjKey) {
										if (subscriberObjValue.businessEntityIdentity == businessEntityIdentity
												&& subscriberObjValue.exchangeSubscriberId == exchangeSubscriberId) {
											angular
													.forEach(
															subscriberObjValue.innerTable.data,
															function(
																	coverageValue,
																	coverageKey) {
																excludedCoverageList
																		.push(coverageValue.ftEntryId);
															});
										}
									}); 
							
					excludedExchangeMap[exchangeSubscriberId] = excludedCoverageList;
					excludedBeMap[businessEntityIdentity] = excludedExchangeMap;
				} else {
					var excludedCoverageList = excludedExchangeMap[exchangeSubscriberId];
					if (excludedCoverageList == undefined) {
						excludedCoverageList = new Array();
					}
					excludedCoverageList.push(ftEntryId);
					excludedExchangeMap[exchangeSubscriberId] = excludedCoverageList;
					excludedBeMap[businessEntityIdentity] = excludedExchangeMap;
				}
			return excludedBeMap;
			}

			function removeEntry(businessEntityIdentity, beType, exchangeSubscriberId, ftEntryId,
					excludedBeMap,rowIndex) {
				if (exchangeSubscriberId == undefined) {
					delete excludedBeMap[businessEntityIdentity];
				} else {
					var excludedExchangeMap = $scope.tempExcludedMap[businessEntityIdentity];

					if (ftEntryId == undefined) {
						if(excludedExchangeMap != undefined){
							
							if(excludedExchangeMap[exchangeSubscriberId] != undefined){
								delete excludedExchangeMap[exchangeSubscriberId];
							}
							
							if(Object.keys(excludedExchangeMap).length == 0 && excludedBeMap[businessEntityIdentity]['IS_ALL_SELECTED'] == undefined){
								delete excludedBeMap[businessEntityIdentity];
							}else{
								excludedBeMap[businessEntityIdentity] = excludedExchangeMap;	
							}
						}
						
					} else {
						var excludedCoverageList = excludedExchangeMap[exchangeSubscriberId];
						var index = excludedCoverageList.indexOf(ftEntryId);
						excludedCoverageList.splice(index, 1);
						
						if(excludedCoverageList.length == 0){
							delete excludedExchangeMap[exchangeSubscriberId];
						}else{
							excludedExchangeMap[exchangeSubscriberId] = excludedCoverageList;	
						}
						
						if(Object.keys(excludedExchangeMap).length == 0 && excludedBeMap[businessEntityIdentity]['IS_ALL_SELECTED'] == undefined){
							delete excludedBeMap[businessEntityIdentity];
						}else{
							excludedBeMap[businessEntityIdentity] = excludedExchangeMap;	
						}
						
						excludedBeMap[businessEntityIdentity] = excludedExchangeMap;
					}
				}
				return excludedBeMap;
			}
			
			function updateAllCvgCheckBoxes(isSelected,issuerRowIndex){
				var checkBoxEventArray = [];
				for(var i = 0;i<($scope.subscriberRemitsList[issuerRowIndex].innerTable.data.length);i++){
					$scope.subscriberRemitsList[issuerRowIndex].innerTable.data[i].isChecked = isSelected;  
					checkBoxEventArray = prepareCheckBoxEventArray('Remit_'+ (issuerRowIndex)  +'_'+(i),isSelected,checkBoxEventArray);
				}
				publishCheckBoxEventArray(checkBoxEventArray);
			}
			
			function pageCountIncrement(){
				$scope.selectedCountOnPage = $scope.selectedCountOnPage + 1;
				$scope.totalSelectedCount = $scope.totalSelectedCount + 1;
			}
			
			function pageCountDecrement(){
				$scope.selectedCountOnPage = $scope.selectedCountOnPage - 1;
				$scope.totalSelectedCount = $scope.totalSelectedCount - 1;
			}
			
			$scope.updateSubsAndCovgExclusionData = function(isAdded, businessEntityIdentity,
					beType, exchangeSubscriberId, rowIndex, ftEntryId) {
				var isAllSelected = $scope.isExclusion;
				
				if($scope.tempExcludedMap[businessEntityIdentity] && $scope.tempExcludedMap[businessEntityIdentity]!= undefined && $scope.tempExcludedMap[businessEntityIdentity]['IS_ALL_SELECTED'] != undefined){
					isAllSelected = $scope.tempExcludedMap[businessEntityIdentity]['IS_ALL_SELECTED'];
				}
				
				var map;
				if (isAllSelected) {
					if (isAdded) {
						map = removeEntry(businessEntityIdentity, beType, exchangeSubscriberId,
								ftEntryId, $scope.tempExcludedMap,rowIndex);
					} else {
						map = addEntry(businessEntityIdentity, beType, exchangeSubscriberId, ftEntryId,
								$scope.tempExcludedMap,rowIndex);
					}
				} else {
					if (isAdded) {
						map = addEntry(businessEntityIdentity, beType, exchangeSubscriberId, ftEntryId,
								$scope.tempExcludedMap,rowIndex);
					} else {
						map = removeEntry(businessEntityIdentity, beType, exchangeSubscriberId,
								ftEntryId, $scope.tempExcludedMap,rowIndex);
					}
				}
				$scope.tempExcludedMap = map;
				
			}

			$scope.updateAmount = function(modelId, subscriberTableIndex,
					coverageTableIndex) {
				var amount = 0;
				var previousSelectedAmount = 0;
				var previousSelectedAmt = $scope.subscriberRemitsList[subscriberTableIndex].selectedAmount;
				
				if (coverageTableIndex != '' && coverageTableIndex != undefined) {
					amount = $scope.subscriberRemitsList[subscriberTableIndex].innerTable.data[coverageTableIndex].outstandingAmount;
				} else {
					amount = $scope.subscriberRemitsList[subscriberTableIndex].payableAmount;
					previousSelectedAmount = $scope.subscriberRemitsList[subscriberTableIndex].selectedAmount;
				}

				if (modelId) {
						$scope.totalSelectedAmount = $scope.totalSelectedAmount	+ amount - previousSelectedAmount;
						$scope.subscriberRemitsList[subscriberTableIndex].selectedAmount = $scope.subscriberRemitsList[subscriberTableIndex].selectedAmount
								+ amount - previousSelectedAmount;
					} else {
					if(coverageTableIndex != ''
					&& coverageTableIndex != undefined){
						$scope.totalSelectedAmount = $scope.totalSelectedAmount	- amount;
						$scope.subscriberRemitsList[subscriberTableIndex].selectedAmount = $scope.subscriberRemitsList[subscriberTableIndex].selectedAmount
								- amount;
					}else{
						$scope.totalSelectedAmount = $scope.totalSelectedAmount	- previousSelectedAmount;
						$scope.subscriberRemitsList[subscriberTableIndex].selectedAmount = $scope.subscriberRemitsList[subscriberTableIndex].selectedAmount
								- previousSelectedAmount;
					}
				}
				
				var subscriberSelectedAmount = $scope.subscriberRemitsList[subscriberTableIndex].selectedAmount;
				var subscriberPayableAmount = $scope.subscriberRemitsList[subscriberTableIndex].payableAmount;
					
				if(coverageTableIndex == undefined){
					$scope.subscriberRemitsList[subscriberTableIndex].isChecked = modelId;
					updateAllCvgCheckBoxes(modelId,subscriberTableIndex);
					if(modelId){
						pageCountIncrement();
					}else{
						pageCountDecrement();
					}
				}else{
					$scope.subscriberRemitsList[subscriberTableIndex].innerTable.data[coverageTableIndex].isChecked = modelId; 
					
						if(subscriberSelectedAmount == 0){
							
							var coverageTable = $scope.subscriberRemitsList[subscriberTableIndex].innerTable.data

							if(!modelId){
								var isAllCvgDeSelected = true;
								angular.forEach(coverageTable,function(value,key){
									if(value.isChecked){
										isAllCvgDeSelected = false;
									}
								});
								
								if($scope.subscriberRemitsList[subscriberTableIndex].isChecked && isAllCvgDeSelected){
									publishCheckBoxEvent('Remit_'+ subscriberTableIndex,false);
									$scope.subscriberRemitsList[subscriberTableIndex].isChecked = false;
									pageCountDecrement();	
								}
								
							}
							
							if(!$scope.subscriberRemitsList[subscriberTableIndex].isChecked && modelId){
								publishCheckBoxEvent('Remit_'+ subscriberTableIndex,true);
								$scope.subscriberRemitsList[subscriberTableIndex].isChecked = true;
								pageCountIncrement();
							}
						
					}else{
							if(!$scope.subscriberRemitsList[subscriberTableIndex].isChecked){
								publishCheckBoxEvent('Remit_'+ subscriberTableIndex,true);
								$scope.subscriberRemitsList[subscriberTableIndex].isChecked = true;
								pageCountIncrement();							
							}
					}
			}
				
				updateHeaderCheckBox();
			}
			
			$scope.subscriberRemitsList = '';
			$scope.pagination = defaultPagination(
					'remitPay.exchangeSubscriberId', 'desc');

			function populateSearchCriteria(filterObj) {
				var searchCriteriaJson = {};
				var createdAtFilter = {};
				createdAtFilter.columnValue = $scope.partnerDetails.remitStartTimestamp;
				createdAtFilter.caseSensitiveSearch = "false";
				createdAtFilter.operator = "<=";
				searchCriteriaJson.createdAt = createdAtFilter;
				
				if(isExcludeBlankIssuerEntityId){
					addIssuerEntityNotNullFilter(searchCriteriaJson);
				}
					
				return searchCriteriaJson;
			}

			$scope.fetchdata = function(paginationObj, filterObj, callType) {
				$scope.pagination = paginationObj;
				var searchCriteriaJson = {
					'criteria' : populateSearchCriteria(filterObj),
					'pageRequestCriteria' : getPageRequestCriteria($scope.pagination),
					'referenceId' : null
				};
				getAllRemitsForSubscriber(searchCriteriaJson);
			}

			var successCallback = function(data) {
				$scope.selectedCountOnPage = 0 ;
				if (data != null && data != undefined) {
					if (data.content.length == 0) {
						$scope.subscribersList = 'No Data';
					} else {
						$scope.pagination.totalElements = data.totalElements;
						if($scope.totalSelectedCount  === ''){
							$scope.totalSelectedCount 	= data.totalElements;
							$scope.totalSelectedCountFxd = data.totalElements;
						}
						$scope.pagination.totalNoPages = data.totalPages;
						$scope.subscriberRemitsList = issuerRemitsTransformer(
								data.content, $scope.remitInnerTableHeaders,
								beIdentity,
								$scope.subscriberDetails.businessEntityType,
								$scope.tempExcludedMap, $scope.isExclusion, $translate);
						
						angular.forEach($scope.subscriberRemitsList,function(value,key){
							if(value.isChecked){
								$scope.selectedCountOnPage = $scope.selectedCountOnPage + 1;
							}
						});
						
						var defaultSubscriberExclusionFlag = true;
						var businessEntityIdentity = beIdentity;
						if($scope.tempExcludedMap!= undefined && $scope.tempExcludedMap[businessEntityIdentity] != undefined && $scope.tempExcludedMap[businessEntityIdentity]['IS_ALL_SELECTED'] != undefined){
							defaultSubscriberExclusionFlag = $scope.tempExcludedMap[businessEntityIdentity]['IS_ALL_SELECTED'];
						}else{
							defaultSubscriberExclusionFlag = $scope.isExclusion;
						}
						
						if(!defaultSubscriberExclusionFlag && ($scope.totalSelectedCount == data.totalElements)){
							$scope.totalSelectedCount = $scope.selectedCountOnPage;	
						}
						updateHeaderCheckBox();
					}
				} else {
					$scope.subscriberRemitsList = 'No Data';
				}
			}

			var errorCallBack = function() {
				$scope.subscriberRemitsList = 'No Data';
			}

				
			
			var getAllRemitsForSubscriber = function(searchCriteriaJson) {
				var params = {
					"partnerId" : $scope.partnerDetails.partnerIdentity,
					"subscriberId" : beIdentity
				};
				
				financialsRemitsService.getAllRemitsForSubscriber(params,
						searchCriteriaJson, successCallback, errorCallBack);
			}

			$scope.updateExclusionData = function(isAdded, businessEntityIdentity) {
				$scope.excludedBeMap = updateExclusionMap(isAdded, businessEntityIdentity,
						$scope.tempExcludedMap, $scope.isExclusion);
			}

			$scope.success = function() {
				if($scope.tempExcludedMap[beIdentity]){
					$scope.tempExcludedMap[beIdentity]['TOTAL_SELECTED_COUNT'] = $scope.totalSelectedCount;
				}
				this.tempExcludedMap = $scope.tempExcludedMap;
				$scope.$modalSuccess();
			}

			$scope.cancel = function() {
				$scope.$modalCancel();
			}

			
     		 function publishCheckBoxEvent(key,value){
				var data = {};
				data.key = key;
				data.value = value;
				$scope.$broadcast('checkBoxEvent', data);
			}
     		 
     		function prepareCheckBoxEventArray(key,value,array){
     			var data = {};
				data.key = key;
				data.value = value;
				array.push(data);
				return array;
     		}
     		
     		 
     		function publishCheckBoxEventArray(checkBoxArray){
     			if(checkBoxArray){
     				$scope.$broadcast('checkBoxEvent', checkBoxArray);
     			}
     		} 
     		 
			$scope.selectAllFn = function(isAllSelected){
				var pageRecordsCount = $scope.subscriberRemitsList.length;
				
				if(isAllSelected){
					$scope.messsageState = 'AllSelected';
					$scope.totalSelectedCount  = $scope.totalSelectedCountFxd;
					$scope.selectedCountOnPage = pageRecordsCount;
					$scope.totalSelectedAmount = $scope.subscriberDetails.payableAmount;
				}else{
					$scope.messsageState = 'NotAllSelected';
					$scope.totalSelectedCount = 0;
					$scope.selectedCountOnPage = 0;
					$scope.totalSelectedAmount = 0;
				}
				
				var businessEntityIdentity = beIdentity;
				if($scope.isExclusion  == isAllSelected){
					delete $scope.tempExcludedMap[businessEntityIdentity];
				}else{
					$scope.tempExcludedMap[businessEntityIdentity] = new Object();
					$scope.tempExcludedMap[businessEntityIdentity]['IS_ALL_SELECTED'] = isAllSelected;
				}
				
				var rowIndex = 0;
				var checkBoxEventArray = [];
				
				angular
				.forEach(
						$scope.subscriberRemitsList,
						function(subscriberValue, subscriberKey) {
							
							if(isAllSelected){
								subscriberValue.selectedAmount = subscriberValue.payableAmount;
							}else{
								subscriberValue.selectedAmount = 0;
							}
							
							subscriberValue.isChecked = isAllSelected;
							
							checkBoxEventArray = prepareCheckBoxEventArray('Remit_'+ rowIndex,isAllSelected,checkBoxEventArray);
							
							for(var i = 0;i<($scope.subscriberRemitsList[rowIndex].innerTable.data.length);i++){
								$scope.subscriberRemitsList[rowIndex].innerTable.data[i].isChecked = isAllSelected;
								checkBoxEventArray = prepareCheckBoxEventArray('Remit_'+ (rowIndex)  +'_'+(i),isAllSelected,checkBoxEventArray);
							}
							
							rowIndex = rowIndex +1;
				});
				
				
				
				publishCheckBoxEventArray(checkBoxEventArray);
				updateHeaderCheckBox();
			}
			
			function addIssuerEntityNotNullFilter(criteria){
					var issuerEntityIdFilter = {};
					issuerEntityIdFilter.columnValue = " IS NOT NULL ";
					issuerEntityIdFilter.caseSensitiveSearch = "false";
					issuerEntityIdFilter.operator = "=";
					criteria.issuerEntityId = issuerEntityIdFilter;
				}
			
		} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'RemitsEntityDetailController',
	'id' : hcentive.WFM.RemitsEntityDetailController
});