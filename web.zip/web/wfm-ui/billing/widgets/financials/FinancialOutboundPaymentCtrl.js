hcentive.WFM.FinancialOutboundPaymentCtrl = ['$scope', 'FinancialPaymentService', '$location','EventBusSrvc','IndividualServ','GroupServ','manageHealthPlanProviderServ','NotifySrvc','FinancialsOutboundPaymentsFilterService','$filter','$route','popupService',
        function ($scope, FinancialPaymentService, $location,EventBusSrvc,IndividualServ,GroupServ,manageHealthPlanProviderServ,NotifySrvc,FinancialsOutboundPaymentsFilterService,$filter,$route,popupService) {
            $scope.ftList = [];
            $scope.pagination = defaultPagination('txnDate', 'desc');
            
            $scope.preSelectedFilters = {};
            $scope.onLoadFetchData = true;
				            
			var goToRelatedBeEntity = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
			if(goToRelatedBeEntity != undefined && goToRelatedBeEntity !=''){
				$scope.preSelectedFilters['beExtenalId'] =  goToRelatedBeEntity;
			}
			var goToRelatedBAExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBAExternalId');
			if(goToRelatedBAExternalId != undefined && goToRelatedBAExternalId !=''){
				$scope.preSelectedFilters['subscription'] =  goToRelatedBAExternalId;
			}
			var ftEventData = EventBusSrvc.subscribeAndInvalidatePayload('ftEventData');
			if(ftEventData){
				$scope.preSelectedFilters['externalId'] =  ftEventData.externalId;
			}
			
			var paymentExternalId = EventBusSrvc.subscribeAndInvalidatePayload('paymentExternalId');
			if(paymentExternalId){
				$scope.onLoadFetchData = false;
				$scope.preSelectedFilters['externalId'] =  paymentExternalId;
				$scope.paymentsFilter = $scope.preSelectedFilters;
			}
			
			var remitId = EventBusSrvc.subscribeAndInvalidatePayload('remitId');
			if(remitId){
				$scope.onLoadFetchData = false;
				$scope.preSelectedFilters['remitId'] =  remitId;
				$scope.paymentsFilter = $scope.preSelectedFilters;
			}
			
			
			
			/*Page back*/
			$scope.pageBackFilters = EventBusSrvc.subscribeAndInvalidatePayload('pageBackFilters'); //clearing page back URL from event bus
			if($scope.pageBackFilters){
				$scope.onLoadFetchData = false;
				$scope.preSelectedFilters = $scope.pageBackFilters;
				$scope.paymentsFilter = $scope.pageBackFilters;
				$scope.updateLeftNav('Payments');
			}
			/*Page back*/
			
			$scope.publishRemitIdentity = function(remitId){
				EventBusSrvc.publish('remitId', remitId);
				$location.path("reports/report-remittance-details");
				$location.replace();
			}
            $scope.filterBoxConfig = FinancialsOutboundPaymentsFilterService.getPaymentsFilterConfiguration($scope.preSelectedFilters);

            
            
            $scope.headerListForOutbund = [
                                 {'isSortable': 'yes', 'key': 'paymentId', 'desc': 'Payment ID','contentType' : 'String','sortableKey' : 'externalId'},
                                 {'isSortable': 'yes', 'key': 'partnerId', 'desc': 'Partner ID','contentType' : 'String','sortableKey' : 'payee.externalId'},
                                 {'isSortable': 'yes', 'key': 'partnerType', 'desc': 'Partner Type','contentType' : 'String','sortableKey' : 'payee.type','isExportable' : true},
                                 {'isSortable': 'yes', 'key': 'paymentDate', 'desc': 'Payment Date','contentType' : 'Date','sortableKey' : 'txnDate'},
                                 {'isSortable': 'yes', 'key': 'paymentMethod', 'desc': 'Payment Method','contentType' : 'String','sortableKey' : 'paymentMode'},
                                 {'isSortable': 'yes', 'key': 'status', 'desc': 'Status','contentType' : 'String','sortableKey' : 'status'},
                                 {'isSortable': 'yes', 'key': 'amount', 'desc': 'Amount','contentType' : 'Currency','sortableKey' : 'amountPaid.value'},
                                 {'isSortable': 'yes', 'key': 'createdBy', 'desc': 'Created By','contentType' : 'String','sortableKey' : 'auditInfo.createdByName'},
                                 {
                 					'isSortable' : 'no',
                 					'key' : 'action',
                 					'desc' : 'Actions',
                 					'contentType' : 'html'
                 				}

                             ];
            
            $scope.publishPaymentIdentity = function(paymentIdentity) {
				if(paymentIdentity){
					EventBusSrvc.publish('eventAdditionalId', paymentIdentity);
					$location.path("financials/financials-transactions-report");
					$location.replace();
				}
			};
            
            
            
			    var pageIndex = 0;
			    $scope.exportHandler = function(filterData,type){
			    	$scope.paymentFor = type;
			    	$scope.isExportCall = true;
			    	pageIndex  = $scope.pagination.pageIndex;
			    	$scope.pagination = setExportPageSize($scope.pagination);
			    	$scope.fetchdata($scope.pagination, buildCriteria($scope.filterList,filterData));
			    };
			    
			    $scope.handleSearch = function(filterData){
			     console.log("Handle Individual Search");
			     console.log(filterData);
			     
			     $scope.handleChange(filterData);
			    };
			    
			    $scope.handleChange = function(filterData){
			     console.log(filterData);
			     $scope.pageBackFilters = filterData;
			     $scope.paymentsFilter = JSON.parse(JSON.stringify(filterData));
			    };

       

            $scope.filterList = [ {
					'filterKey' : 'externalId',
					'filterType' : 'String',
				}, {
					'filterKey' : 'subscriptionId',
					'filterType' : 'String',
					'filterQueryKey' : 'subscription.externalId'
				}, {
					'filterKey' : 'paymentMode',
					'filterType' : 'StringList'
				},{
					'filterKey' : 'status',
					'filterType' : 'StringList'
					
				},{
					'filterKey' : 'paymentDate',
					'filterType' : 'DateRange',
					'filterQueryKey' : 'txnDate.date',
					'dateFormat' : 'yyyy/mm/dd',
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'amount',
					'filterType' : 'NumberRange',
					'filterQueryKey' : 'amountPaid.value'
				},{
					'filterKey' : 'payeeExternalId',
					'filterType' : 'String',
					'filterQueryKey' : 'payee.externalId'
				},{
					'filterKey' : 'createdBy',
					'filterType' : 'String',
					'filterQueryKey' : 'auditInfo.createdByName'
				},{
					'filterKey' : 'partnerType',
					'filterType' : 'String',
					'filterQueryKey' : 'payee.type'
				},{
					'filterKey' : 'remitId',
					'filterType' : 'String',
					'filterQueryKey' : 'sourceRefId'
				}
				
				];
			
			$scope.getAllPaymentRecordsForAdmin = function(criteria){ 
			
				if (criteria === null) {
					criteria =  {"recordType" : {
						"operator": "=",
						"columnValue": "com.hcentive.billing.wfm.api.enumeration.PaymentRecordType.OUTBOUND_PAYMENT",
						 "caseSensitiveSearch": true
					}};
				}
				
				var searchCriteria = angular.fromJson(criteria);
				searchCriteria.projectedFields=$scope.fetchProjectedFieldsForPaymentRecords();
		FinancialPaymentService.getAllPaymentRecordsForAdmin(null, searchCriteria, fetchPaymentRecordSuccess, fetchPaymentRecordError);
	}
	
	
	var fetchPaymentRecordSuccess = function(data) {
		if($scope.isExportCall){
			$scope.isExportCall = false;
	    	var exportData = {};
	    	exportData.fileName = 'Payments';
	    	exportData.data =  getPaymentRecords($scope,data,$filter);
	    	$scope.pagination = setDefaultPageSize($scope.pagination,pageIndex);
	    	$scope.$broadcast('exportEvent', exportData);
			return;
		}
		$scope.pagination.totalElements = data.totalElements;
		$scope.pagination.totalNoPages  = data.totalPages;
		$scope.paymentRecords = getPaymentRecords($scope,data,$filter);
		
		// Work-around to set total number of elements in tablePagination object
	
		if($scope.paymentRecords == '' || $scope.paymentRecords == undefined){
			$scope.paymentRecords = 'No Data';
			$scope.paymentRecords.length=0;
	
		}
		
	}
	
	var fetchPaymentRecordError  = function(data){
		$scope.paymentRecords = 'No Data';
		$scope.pagination = setDefaultPageSize($scope.pagination,pageIndex);
		$scope.isExportCall = false;
	}
	
	$scope.getPaymentRecordsForAdmin = function(callType){
		var  crit = $scope.populateSearchCriteria(callType);
				$scope.fetchOutbound(angular.toJson(crit));
			
		}
	
         
	  $scope.fetchdata = function (paginationObj, filterObj,callType) {
		  	filterObj = filterObj || {};
		  	
			$scope.pagination = paginationObj;
            $scope.filterJson = filterObj;
            $scope.getPaymentRecordsForAdmin(callType);
        };
		 
     

	var isEmptyStr = function(str) {
		return (!str || 0 === str.length);
	}
	
					$scope.fetchProjectedFieldsForPaymentRecords = function() {};
					
					$scope.fetchProjectedFieldsForOutBoundPaymentRecords = function() {
						var projectedFields = [];
						var projectFieldForIdentity = {
							"entityField" : "d.identity",
							"mappedField" : "identity"
						};
						projectedFields.push(projectFieldForIdentity);
						var projectFieldForExternalId = {
							"entityField" : "d.externalId",
							"mappedField" : "externalId"
						};
						projectedFields.push(projectFieldForExternalId);

						var projectedFieldForGatewayConfirmationNumber = {
							"entityField" : "d.gatewayConfirmationNumber",
							"mappedField" : "gatewayConfirmationNumber"
						};
						projectedFields
								.push(projectedFieldForGatewayConfirmationNumber);

						var projectedFieldForPaymentEffectiveDate = {
							"entityField" : "d.status",
							"mappedField" : "status"
						};
						projectedFields
								.push(projectedFieldForPaymentEffectiveDate);

						var projectedFieldForOriginalPaymentDate = {
							"entityField" : "d.txnDate",
							"mappedField" : "txnDate"
						};
						projectedFields
								.push(projectedFieldForOriginalPaymentDate);

						var projectedFieldForAmountPaid = {
							"entityField" : "d.amountPaid",
							"mappedField" : "amountPaid"
						};
						projectedFields.push(projectedFieldForAmountPaid);
						var projectedFieldForPayee = {
							"entityField" : "d.payee",
							"mappedField" : "payee"
						};
						projectedFields.push(projectedFieldForPayee);

						

						var projectedFieldForPaymentMode = {
							"entityField" : "d.paymentMode",
							"mappedField" : "paymentMode"
						};
						projectedFields.push(projectedFieldForPaymentMode);

						
						
						var projectedFieldForAudit = {
								"entityField" : "d.auditInfo",
								"mappedField" : "auditInfo"
							};
						projectedFields.push(projectedFieldForAudit);
						
						var projectedFieldForSourceRefId = {
								"entityField" : "d.sourceRefId",
								"mappedField" : "sourceRefId"
							};
						projectedFields.push(projectedFieldForSourceRefId);
						
						return projectedFields;
					};
			
			
	 $scope.viewBEDetails = function(value,type,beExternalId, beIdentity) {
		 
		 		EventBusSrvc.publish('pageBackFilters', beExternalId);
		 		EventBusSrvc.publish('goToRelatedBEExternalId', beExternalId);
		 		EventBusSrvc.publish('goToRelatedBEIdentity', beIdentity);
		 		EventBusSrvc.publish('pageBackURL', 'financials/payments');
		 		EventBusSrvc.publish('pageBackFilters',$scope.pageBackFilters);
		 		
                var param = {"id": value, "type": "be"};
                if (type == 'Individual') {
                    IndividualServ.viewIndividual(param, afterSucessIndividualDetails, afterFail);
                } else if (type == 'Group') {
                	GroupServ.viewGroup(param, afterSucessGroupDetails, afterFail);
                }
                else if(type=='HealthPlanProvider'){
                	
                	manageHealthPlanProviderServ.viewHealthPlanProvider(param,afterSucessHealthPlanProviderrDetails,afterFail);
                }
            }
			
			 var afterSucessGroupDetails = function (data) {
                EventBusSrvc.publish('groupDetails', data.item);
                EventBusSrvc.publish('BEmetaInfo', data.itemMetaInfo);
                $location.path('entities/group/group-details');
                $location.replace();
            }
            var afterSucessIndividualDetails = function (data) {
                EventBusSrvc.publish('individualDetails', data.item);
                EventBusSrvc.publish('BEmetaInfo', data.itemMetaInfo);
                $location.path('entities/individual/individual-details');
                $location.replace();
            }
			
            var afterSucessHealthPlanProviderrDetails=function(data){
            	EventBusSrvc.publish('healthPlanProviderDetails', data);
            	EventBusSrvc.publish('BEmetaInfo', data.itemMetaInfo);
            	 $location.path('entities/healthPlanProvider/health-plans-details');
                 $location.replace();
            	
            }
			 var afterFail = function (data) {
            }
	
	$scope.populateSearchCriteria = function(callType) {
		var searchCriteriaJson = {};
		var criteria = {};
		var criteriaRecordType = {
						"operator": "=",
						"columnValue": "com.hcentive.billing.wfm.api.enumeration.PaymentRecordType.OUTBOUND_PAYMENT",
						 "caseSensitiveSearch": true
					};
	
		
		// populate pageRequestCriteria
		searchCriteriaJson.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
		//var paymentFromDateStr = null;
		//var paymentToDateStr = null;
		
		if($scope.filterJson && !Array.isArray($scope.filterJson)){
			criteria = $scope.filterJson;
		}
	
		if (callType != null && callType != undefined
							&& callType == 'search') {
			//$scope.preSelectedFilters = null;
		}
					
		
		if($scope.preSelectedFilters){
			if($scope.preSelectedFilters.beExtenalId){
				criteria =  addStringFilter({},'payer.externalId',$scope.preSelectedFilters.beExtenalId,false);
				$scope.updateLeftNav('Payments');
			}
			if($scope.preSelectedFilters.subscription){
				criteria =  addStringFilter({},'subscription.externalId',$scope.preSelectedFilters.subscription,false);
				$scope.updateLeftNav('Payments');
			}
			if($scope.preSelectedFilters.externalId){
				criteria =  addStringFilter({},'externalId',$scope.preSelectedFilters.externalId,false);
				$scope.updateLeftNav('Payments');
			}
			
			if($scope.preSelectedFilters.baIdentity){
				criteria =  addStringFilter({},'paymentFor.identity',$scope.preSelectedFilters.baIdentity,false);
				$scope.updateLeftNav('Payments');
			}
		}
		criteria.recordType = {};
		criteria.recordType = criteriaRecordType;
		console.log('Paymnet Filters -> '+JSON.stringify(criteria));
		searchCriteriaJson.criteria = criteria;
		return searchCriteriaJson;	
	};
	
		$scope.addPaymentDialog = function() {
			var tenantId = $scope.wfmAppContext.loggedInUser.tenantId;
			EventBusSrvc.publish('addPaymentControllerTenantId', tenantId);
			popupService.openPaymentPopup('general');
		}; 
		 
		//popup for void payment		
		$scope.voidPopup = function(data,type) {
					
					var param = {
					'identity':data
					};
					NotifySrvc({
						id : 'simpleDialog',
						controller : 'FinancialPaymentCtrl',
						scope : $scope,
						template : 'Do you really wish to void payment? ',
						title : 'Void Payment',

						cancel : {
							label : 'Cancel',
							fn : function() {
							}
						},
						success : {
							label : 'Confirm',
							fn : function() {
								this.submitted = true;
									FinancialPaymentService.voidOutboundPayment(param,
											null, voidSuccessCallback,
											errorCallback);
								
								}
						}
					});
				}

		var voidSuccessCallback = function(arg1){
			$route.reload();
			console.log("void success");
		}
		var errorCallback = function(){
		console.log("Error");
		}
		var paymentSuccessCallback = function(arg1){
			if(arg1 && arg1=='true'){
					$scope.getPaymentRecordsForAdmin();
				}
			}
		$scope.changeCurrentPage = function(){
			
		}
		$scope.fetchOutbound = function(criteria){
			var fetchOutBoundPaymentRecordSuccess = function(data) {
				$scope.updateLeftNav('Payments');
				if($scope.isExportCall){
					$scope.isExportCall = false;
			    	var exportData = {};
			    	exportData.fileName = 'Payments';
			    	exportData.data =  getPaymentRecords($scope,data,$filter);
			    	$scope.pagination = setDefaultPageSize($scope.pagination,pageIndex);
			    	$scope.$broadcast('exportEvent', exportData);
					return;
				}
				$scope.pagination.totalElements = data.totalElements;
				$scope.pagination.totalNoPages  = data.totalPages;
				$scope.outboundPaymentRecords = getPaymentRecords($scope,data,$filter);
				$scope.currentPage = 'outbound';
				
				// Work-around to set total number of elements in tablePagination object
			
				if($scope.outboundPaymentRecords == '' || $scope.outboundPaymentRecords == undefined){
					$scope.outboundPaymentRecords = 'No Data';
					$scope.outboundPaymentRecords.length=0;
			
				}
				
			}
			var fetchOutBoundPaymentRecordError = function(){
				$scope.currentPage = 'outbound';
			}
			if (criteria === null || criteria === undefined) {
				criteria =  {"recordType" : {
					"operator": "=",
					"columnValue": "com.hcentive.billing.wfm.api.enumeration.PaymentRecordType.OUTBOUND_PAYMENT",
					 "caseSensitiveSearch": true
				}};
			}
			
			var searchCriteria = angular.fromJson(criteria);
			searchCriteria.projectedFields = {};
			searchCriteria.projectedFields=$scope.fetchProjectedFieldsForOutBoundPaymentRecords();
			FinancialPaymentService.getOutBoundPaymentDetails(null, searchCriteria, fetchOutBoundPaymentRecordSuccess, fetchOutBoundPaymentRecordError);
		}
			
	
	
	

		EventBusSrvc.subscribe('addPaymentProcessCompletedSuccess', $scope,paymentSuccessCallback);
   
        }];
    hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
        "name": "FinancialOutboundPaymentCtrl",
        "id": hcentive.WFM.FinancialOutboundPaymentCtrl
    });
