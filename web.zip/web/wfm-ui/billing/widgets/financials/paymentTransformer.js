
function getPaymentRecords($scope,data,filter) {
	var paymentRecordList = [];
	angular.forEach(data.content,function(value, key) {
						var paymentRecordObject = {};
						paymentRecordObject.paymentId = value.externalId; //changed from externalId to identity-aditya
						paymentRecordObject.itemRecordId=value.itemRecordId;
						paymentRecordObject.identity = value.identity;
						paymentRecordObject.sourceRefId = value.sourceRefId;
						if(value.payer != null && value.payer != undefined){
							paymentRecordObject.action = '<a class="viewProfile" href="" ng-click="publishPaymentIdentity(value.paymentId)" title="View Transactions"><i class="icon-entityList"></i></a>';
						}else if(value.payee != null && value.payee != undefined){
							paymentRecordObject.action = '<a href="" class="toolTip" ng-click="publishRemitIdentity(value.sourceRefId)" title="Associated Remits"><i class="icon-addNotes"></i></a>';
						}
						paymentRecordObject.subscriptionId='';
						if(value.subscription) {
							paymentRecordObject.subscriptionId=value.subscription.externalId;
						}
						
						if(value.payer != null && value.payer != undefined)
						{
							paymentRecordObject.beItemRecordId=value.payer.itemRecordId;	
							paymentRecordObject.type=value.payer.type;
							
							paymentRecordObject.entityId = '<a href ng-click="viewBEDetails(\''+value.payer.itemRecordId+'\',\''+value.payer.type+'\',\''+value.payer.externalId+'\',\''+value.payer.identity+'\')">'
								+ value.payer.externalId + '</a>';
							paymentRecordObject.entityId_exportValue = value.payer.externalId;
						}
						if(value.payee != null && value.payee != undefined)
						{
							paymentRecordObject.partnerId=value.payee.externalId;	
							paymentRecordObject.partnerType=value.payee.type;
							
							/*paymentRecordObject.entityId = '<a href ng-click="viewBEDetails(\''+value.payer.itemRecordId+'\',\''+value.payer.type+'\',\''+value.payer.externalId+'\',\''+value.payer.identity+'\')">'
								+ value.payer.externalId + '</a>';
							paymentRecordObject.entityId_exportValue = value.payer.externalId;*/
						}
						
						if(value.operator != null && value.operator != undefined)
						{
						if(value.payer.profile != null && value.payer.profile != undefined)
						paymentRecordObject.entityName = value.payer.profile.name;
						
						}
						if(value.txnDate != null && value.txnDate != undefined)
						{
						paymentRecordObject.paymentDate = convertDate(value.txnDate.date);
						
						}
						
						 if(value.paymentMode == 'MoneyOrder'){
							paymentRecordObject.paymentMethod = 'Money Order';
						 }else if(value.paymentMode == 'Token-Card'){
							paymentRecordObject.paymentMethod = 'Card';
						 }else if(value.paymentMode == 'Token-BankAccount'){
							paymentRecordObject.paymentMethod = 'Bank Account';
						 }else if(value.paymentMode == 'BUSINESS_CHECKING'){
							paymentRecordObject.paymentMethod = 'Business Checking';
						 }else if(value.paymentMode == 'BankAccount' || value.paymentMode == 'ACH'){
							paymentRecordObject.paymentMethod = 'Bank Account';
						 }else if(value.paymentMode == 'VISA'){
							paymentRecordObject.paymentMethod = 'Visa';
						 } else if(value.paymentMode == 'OTHER'){
						    paymentRecordObject.paymentMethod = 'Other';
							 }else {
							paymentRecordObject.paymentMethod=value.paymentMode;
						}
						
						paymentRecordObject.status=filter('translate')('payment.status.'+value.status);
						if(value.amountPaid != null && value.amountPaid != undefined){
						paymentRecordObject.amount=value.amountPaid.value;
						}
						paymentRecordObject.value = value;
						if(value.auditInfo){
							paymentRecordObject.createdBy = value.auditInfo.createdByName;
						}
						
						if(paymentRecordObject.status=='Successful'){
							if(value.payee != null && value.payee != undefined){
								if( $scope.isRenderable('void-outbound-payment')){
									paymentRecordObject.action+='<span class="lineDivider"></span><a class="toolTip voidPayment" href="" ng-click="voidPopup(\''
									+ paymentRecordObject.identity + '\',\'outbound\')" title="Void"><span class="icon-void"></span></a>'
								}
							}else{
								if( $scope.isRenderable('void-inbound-payment')){
									paymentRecordObject.action+='<span class="lineDivider"></span><a class="toolTip voidPayment" href="" ng-click="voidPopup(\''
													+ paymentRecordObject.paymentId + '\')" title="Void"><span class="icon-void"></span></a>'
								}
							}
						}else if(paymentRecordObject.status=='Unknown'){
							if(value.payee != null && value.payee != undefined){
								if( $scope.isRenderable('void-outbound-payment')){
									paymentRecordObject.action+='<span class="lineDivider"></span><a class="toolTip voidPayment" href="" ng-click="voidPopup(\''
										+ paymentRecordObject.identity + '\',\'outbound\')" title="Void"><span class="icon-void"></span></a>'
								}
							}else{
								if( $scope.isRenderable('void-inbound-payment')){
									paymentRecordObject.action+='<span class="lineDivider"></span><a class="toolTip voidPayment" href="" ng-click="voidPopup(\''
													+ paymentRecordObject.paymentId + '\')" title="Void"><span class="icon-void"></span></a>'
								}
							}
						}
						paymentRecordList.push(paymentRecordObject);
						
		
					});
	return paymentRecordList;				
}

/*function getOutBoundPaymentRecords(data,filter) {
	var paymentRecordList = [];
	angular.forEach(data.content,function(value, key) {
						var paymentRecordObject = {};
						paymentRecordObject.paymentId = value.externalId; //changed from externalId to identity-aditya
						paymentRecordObject.itemRecordId=value.itemRecordId;
						paymentRecordObject.identity = value.identity;
						paymentRecordObject.action = '<a class="viewProfile" href="" ng-click="publishPaymentIdentity(value.paymentId)" title="View Transactions"><i class="icon-entityList"></i></a>';
						paymentRecordObject.subscriptionId='';
						
						
						
						
						if(value.operator != null && value.operator != undefined)
						{
						if(value.payer.profile != null && value.payer.profile != undefined)
						paymentRecordObject.entityName = value.payer.profile.name;
						
						}
						if(value.txnDate != null && value.txnDate != undefined)
						{
						paymentRecordObject.paymentDate = convertDate(value.txnDate.date);
						
						}
						
						 if(value.paymentMode == 'MoneyOrder'){
							paymentRecordObject.paymentMethod = 'Money Order';
						 }else if(value.paymentMode == 'Token-Card'){
							paymentRecordObject.paymentMethod = 'Card';
						 }else if(value.paymentMode == 'Token-BankAccount'){
							paymentRecordObject.paymentMethod = 'Bank Account';
						 }else if(value.paymentMode == 'BUSINESS_CHECKING'){
							paymentRecordObject.paymentMethod = 'Business Checking';
						 }else if(value.paymentMode == 'BankAccount'){
							paymentRecordObject.paymentMethod = 'Bank Account';
						 }else if(value.paymentMode == 'VISA'){
							paymentRecordObject.paymentMethod = 'Visa';
						 } else if(value.paymentMode == 'OTHER'){
						    paymentRecordObject.paymentMethod = 'Other';
							 }else {
							paymentRecordObject.paymentMethod=value.paymentMode;
						}
						
						paymentRecordObject.status=filter('translate')('payment.status.'+value.status);
						if(value.amountPaid != null && value.amountPaid != undefined){
						paymentRecordObject.amount=value.amountPaid.value;
						}
						paymentRecordObject.value = value;
						if(value.auditInfo){
							paymentRecordObject.createdBy = value.auditInfo.createdByName;
						}
						if(paymentRecordObject.status=='Successful' || paymentRecordObject.status=='Unknown'){
							paymentRecordObject.action+='<span class="lineDivider"></span><a class="toolTip voidPayment" href="" ng-click="voidPopup(\''
													+ paymentRecordObject.paymentId + '\,outbound')" title="Void"><span class="icon-void"></span></a>'
						}
						paymentRecordList.push(paymentRecordObject);
						
		
					});
	return paymentRecordList;				
}
*/
