hcentive.WFM.FinancialInvoiceDetailsCtrl = ['$scope',
'EventBusSrvc',
'FinancialsInvoiceService', '$location' ,'$filter','$translate','NotifySrvc','FinancialsInvoiceHelperService',
function($scope, EventBusSrvc,FinancialsInvoiceService ,$location,$filter,$translate,NotifySrvc,FinancialsInvoiceHelperService) {
	
	$scope.expandCollapse = 'Expand All';
	$scope.pageBackFilters = EventBusSrvc.subscribeAndInvalidatePayload('pageBackFilters'); //clearing page back URL from event bus
	
	$scope.pageBack = function(){
		EventBusSrvc.publish('pageBackFilters',$scope.pageBackFilters);
		changeLocation();
	}
	
	
	$scope.invoiceDetails = {};
	$scope.employeeTablePagination = defaultPagination('groupName','asc');
	var rebillInvoiceForAdminSuccess = function(data){
		$scope.succErrDialog('Rebill Invoice', 'Request Submitted');
		changeLocation();
	}
	
	var changeLocation = function() {
		if($scope.typeOfIncomingInvoice == 'Individual')
			$location.path('financials/invoices/individuals');
		else if($scope.typeOfIncomingInvoice == 'Group')
			$location.path('financials/invoices/groups');
		else
			$location.path('financials/invoices/partners');
		$location.replace();
	}
	
	var regenerateInvoiceForAdminSuccess = function(data){
		$scope.succErrDialog('Regenerate Invoice', 'Request Submitted');
		changeLocation();
	}
	
	var rebillInvoiceForAdminError = function(data){
		$scope.succErrDialog('Rebill Invoice', 'Error');
	}
	
	var regenerateInvoiceForAdminError = function(data){
		$scope.succErrDialog('Regenerate Invoice', 'Error');
	}
	
	$scope.rebillInvoiceForAdmin = function(){
		/*var data = {"invoiceIdentity": $scope.invoiceIdentity};
		FinancialsInvoiceService.regenerateInvoiceForAdmin(data,regenerateInvoiceForAdminSuccess,regenerateInvoiceForAdminError);*/
		NotifySrvc({id : 'simpleDialog',
			template : 'You want to rebill this invoice for bill period ' + $scope.invoiceRightSection.period + '?',
			title : 'Are You Sure',
			cancel : {
				label : 'Cancel',
				fn : function() {
				   }
					},
			success : {label : 'Yes',
						fn : function() {
								var data = {"invoiceIdentity": $scope.invoiceIdentity};
								FinancialsInvoiceService.regenerateInvoiceForAdmin(data,rebillInvoiceForAdminSuccess,rebillInvoiceForAdminError);
							}
						}
					});		
	}

	$scope.regenerateInvoiceForAdmin = function() {
		var currentDate = new Date(Date.now());
		var dueDate = new Date(Date.parse($scope.invoiceRightSection.dueDate));
		var warnMsg = 'You want to regenerate this invoice for bill period ' + $scope.invoiceRightSection.period + ' ? ';
		if(dueDate<currentDate){
			warnMsg =  'This invoice has a due date in the past, regenerating it will create a new invoice for which the due date has already passed.'
				 	+ ' It may also impact the delinquency workflow for this entity, if the new invoice is unpaid.'
				 	+ ' Are you sure you want to regenerate this invoice for bill period ' + $scope.invoiceRightSection.period + ' ? ';
		}
		NotifySrvc({id : 'simpleDialog',
			template : warnMsg,
			title : 'Are You Sure',
			cancel : {
				label : 'Cancel',
				fn : function() {
				   }
					},
			success : {label : 'Yes',
						fn : function() {
									var data = {
										"invoiceIdentity": $scope.invoiceIdentity,
										"rerunType" : "INVOICE_ONLY"};
									FinancialsInvoiceService.regenerateInvoiceForAdmin(data,regenerateInvoiceForAdminSuccess,regenerateInvoiceForAdminError);
							}
						}
					});
	}
	
	var approveInvoiceForAdminSuccess = function(data){
		$scope.succErrDialog('Approve Invoice', 'Request Submitted');
		if($scope.typeOfIncomingInvoice == 'Individual')
			$location.path('financials/invoices/individuals');
		else if($scope.typeOfIncomingInvoice == 'Group')
			$location.path('financials/invoices/groups');
		else
			$location.path('financials/invoices/partners');
		$location.replace();
		
	}
	
	var approveInvoiceForAdminError = function(data){
		$scope.succErrDialog('Approve Invoice', 'Error');
	}
	
	$scope.approveInvoiceForAdmin = function(){
		/*var params = {"identity": $scope.invoiceIdentity};
		FinancialsInvoiceService.approveInvoiceForAdmin(params,approveInvoiceForAdminSuccess,approveInvoiceForAdminError);*/
		NotifySrvc({id : 'simpleDialog',
			template : 'Are you sure you want to approve the selected invoice(s)?',
			title : 'Approve',
			cancel : {
				label : 'Cancel',
				fn : function() {
				   }
					},
			success : {
							label : 'Yes',
							fn : function() {
								var params = {"identity": $scope.invoiceIdentity};
								FinancialsInvoiceService.approveInvoiceForAdmin(params,approveInvoiceForAdminSuccess,approveInvoiceForAdminError);
								}
						}
					});
	}
	
	var rejectInvoiceForAdminSuccess = function(data){
		$scope.succErrDialog('Reject Invoice', 'Request Submitted');
		if($scope.typeOfIncomingInvoice == 'Individual')
			$location.path('financials/invoices/individuals');
		else if($scope.typeOfIncomingInvoice == 'Group')
			$location.path('financials/invoices/groups');
		else
			$location.path('financials/invoices/partners');
		$location.replace();
		
	}
	
	var rejectInvoiceForAdminError = function(data){
		$scope.succErrDialog('Reject Invoice', 'Error');
	}
	
	$scope.rejectInvoiceForAdmin = function(){
		/*var params = {"identity": $scope.invoiceIdentity};
		FinancialsInvoiceService.rejectInvoiceForAdmin(params,rejectInvoiceForAdminSuccess,rejectInvoiceForAdminError);*/
		NotifySrvc({id : 'simpleDialog',
			template : 'Are you sure you want to reject the selected invoice(s)?',
			title : 'Reject',
			cancel : {
				label : 'Cancel',
				fn : function() {
				   }
					},
			success : {label : 'Yes',
					      fn : function() {
						var params = {"identity": $scope.invoiceIdentity};
						FinancialsInvoiceService.rejectInvoiceForAdmin(params,rejectInvoiceForAdminSuccess,rejectInvoiceForAdminError);
					     }
						}
					});
	}
	
	$scope.memberHeaderList = [ {
		'isSortable' : 'yes',
		'key' : 'memberId',
		'desc' : 'Member ID',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'memberName',
		'desc' : 'Name',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'planName',
		'desc' : 'Plan Name',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'planId',
		'desc' : 'Plan ID',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'coverageType',
		'desc' : 'Coverage Type',
		'contentType' : 'String'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'coveragePeriod',
		'desc' : 'Coverage Period',
		'contentType' : 'Period'
	},{
		'isSortable' : 'yes',
		'key' : 'aptcAmount',
		'desc' : 'APTC',
		'contentType' : 'Currency'
	}, {
		'isSortable' : 'yes',
		'key' : 'planPremium',
		'desc' : 'Premium',
		'contentType' : 'Currency'
	} ];

	$scope.exchangeEmployeeHeaderList = [ {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : '',
		'contentType' : 'html'
	},{
		'isSortable' : 'yes',
		'key' : 'groupName',
		'desc' : 'Group Name',
		'contentType' : 'String'
	},
	{
		'isSortable' : 'yes',
		'key' : 'subscriberName',
		'desc' : 'Subs. Name',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'coverageType',
		'desc' : 'Coverage Type',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'planName',
		'desc' : 'Plan Name',
		'contentType' : 'String'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'coveragePeriod',
		'desc' : 'Coverage Period',
		'contentType' : 'Period'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'employeeResponsibility',
		'desc' : 'EE Contribution',
		'contentType' : 'Currency'
	}, {
		'isSortable' : 'yes',
		'key' : 'employerResponsibility',
		'desc' : 'ER Contribution',
		'contentType' : 'Currency'
	}, {
		'isSortable' : 'yes',
		'key' : 'premiumAmount',
		'desc' : 'Premium',
		'contentType' : 'Currency'
	} ];
	

	$scope.employeeMemberHeaderList = [ {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : '',
		'contentType' : 'html'
	},{
		'isSortable' : 'yes',
		'key' : 'memberId',
		'desc' : 'Member ID',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'memberLastName',
		'desc' : 'Last Name',
		'contentType' : 'String'
	},
	{
		'isSortable' : 'yes',
		'key' : 'memberFirstName',
		'desc' : 'First Name',
		'contentType' : 'String'
	}, 
	 {
		'isSortable' : 'yes',
		'key' : 'membercoverageType',
		'desc' : 'Coverage Type',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'memberplanName',
		'desc' : 'Plan Name',
		'contentType' : 'String'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'membercoveragePeriod',
		'desc' : 'Coverage Period',
		'contentType' : 'String'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'mememployeeResponsibility',
		'desc' : 'EE Contribution',
		'contentType' : 'Currency'
	}, {
		'isSortable' : 'yes',
		'key' : 'mememployerResponsibility',
		'desc' : 'ER Contribution',
		'contentType' : 'Currency'
	}, {
		'isSortable' : 'yes',
		'key' : 'premiumAmount',
		'desc' : 'Total Premium',
		'contentType' : 'Currency'
	}];
	
	$scope.groupEmployeeHeaderList = [ {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : '',
		'contentType' : 'html'
	}, {
		'isSortable' : 'yes',
		'key' : 'subscriberLastName',
		'desc' : 'Subs. Last Name',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'subscriberFirstName',
		'desc' : 'Subs. First Name',
		'contentType' : 'String'
	},
	
	{
		'isSortable' : 'yes',
		'key' : 'coverageType',
		'desc' : 'Coverage Type',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'planName',
		'desc' : 'Plan Name',
		'contentType' : 'String'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'coveragePeriod',
		'desc' : 'Coverage Period',
		'contentType' : 'Period'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'employeeResponsibility',
		'desc' : 'EE Contribution',
		'contentType' : 'Currency'
	}, {
		'isSortable' : 'yes',
		'key' : 'employerResponsibility',
		'desc' : 'ER Contribution',
		'contentType' : 'Currency'
	}, {
		'isSortable' : 'yes',
		'key' : 'premiumAmount',
		'desc' : 'Premium',
		'contentType' : 'Currency'
	} ];
	
	$scope.subsidyProviderEmployeeHeaderList = [ {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : '',
		'contentType' : 'html'
	}, {
		'isSortable' : 'yes',
		'key' : 'subscriberName',
		'desc' : 'Subs. Name',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'coverageType',
		'desc' : 'Coverage Type',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'planName',
		'desc' : 'Plan Name',
		'contentType' : 'String'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'coveragePeriod',
		'desc' : 'Coverage Period',
		'contentType' : 'Period'
	}, {
		'isSortable' : 'yes',
		'key' : 'aptcAmount',
		'desc' : 'APTC',
		'contentType' : 'Currency'
	} ];
	
	
	
	

	$scope.retroHeaderList = [ {
		'isSortable' : 'yes',
		'key' : 'subscriberId',
		'desc' : 'Subscriber ID',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'subscriberLastName',
		'desc' : 'Last Name',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'subscriberFirstName',
		'desc' : 'First Name',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'planName',
		'desc' : 'Plan Name',
		'contentType' : 'String'
	}, 
	{
		'isSortable' : 'yes',
		'key' : 'coveragePeriod',
		'desc' : 'Coverage Period',
		'contentType' : 'Period'
	},
	{
		'isSortable' : 'yes',
		'key' : 'adjustmentReason',
		'desc' : 'Adjustment Reason',
		'contentType' : 'String'
	},
	{
		'isSortable' : 'yes',
		'key' : 'retroAmountType',
		'desc' : 'Amount Type',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'amount',
		'desc' : 'Amount',
		'contentType' : 'Currency'
	} ];

	$scope.sectionHeaderList = [ 
	                             {
			'isSortable' : 'yes',
			'key' : 'qualifier',
			'desc' : 'Name',
			'contentType' : 'String'
		},{
		'isSortable' : 'yes',
		'key' : 'description',
		'desc' : 'Description',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'amount',
		'desc' : 'Amount',
		'contentType' : 'Currency'
	} ];
	
	$scope.paymentDetailsHeaderList = [ 
	   {
		'isSortable' : 'yes',
		'key' : 'description',
		'desc' : 'Description',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'associatedDate',
		'desc' : 'Effective Date',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'amount',
		'desc' : 'Amount',
		'contentType' : 'Currency'
	} ];
	
	$scope.manualAdjHeaderList = [{
		'isSortable' : 'yes',
		'key' : 'manualAdjType',
		'desc' : 'Type',
		'contentType' : 'String'
	},
		  {  'isSortable' : 'yes',
			'key' : 'manualAdjName',
			'desc' : 'Name',
			'contentType' : 'String'
		},
		{
		'isSortable' : 'yes',
		'key' : 'description',
		'desc' : 'Description',
		'contentType' : 'String'
	}, {
		'isSortable' : 'yes',
		'key' : 'amount',
		'desc' : 'Amount',
		'contentType' : 'Currency'
	} ];
	
	$scope.partnerFeeHeaderList= [ 
        				            {
										'isSortable' : 'yes',
										'key' : 'coveragePeriod',
										'desc' : 'Coverage Period',
										'contentType' : 'Period'
									}, {
										'isSortable' : 'yes',
										'key' : 'planId',
										'desc' : 'Plan ID',
										'contentType' : 'String'
									}, {
										'isSortable' : 'yes',
										'key' : 'amountType',
										'desc' : 'Amount Type',
										'contentType' : 'String'
									}, {
										'isSortable' : 'yes',
										'key' : 'amount',
										'desc' : 'Amount',
										'contentType' : 'Currency'
									}
			                     	                                				
                 				];
	
	
	$scope.partnerAdjustmentHeaderList= [ 
        				            {
										'isSortable' : 'yes',
										'key' : 'coveragePeriod',
										'desc' : 'Coverage Period',
										'contentType' : 'Period'
									}, {
										'isSortable' : 'yes',
										'key' : 'planId',
										'desc' : 'Plan ID',
										'contentType' : 'String'
									}, {
										'isSortable' : 'yes',
										'key' : 'amount',
										'desc' : 'Amount',
										'contentType' : 'Currency'
									}
			                     	                                				
                 				];


	$scope.sectionFooterList = [ {
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	}, {
		'desc' : 'Total',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	}, {
		'desc' : '',
		'key' : 'amount',
		'calculationType' : 'Sum',
		'contentType' : 'Currency',
		'calculatedValue' : 0,
		'colSpan' : 1
	} ];
	
	$scope.retroFooterList = [ {
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},{
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},{
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},
	{
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},{
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	}, 
	{
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},{
		'desc' : 'Total',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	}, {
		'desc' : '',
		'key' : 'amount',
		'calculationType' : 'Sum',
		'contentType' : 'Currency',
		'calculatedValue' : 0,
		'colSpan' : 1
	} ];
	
	$scope.partnerFooterList=[ {
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},{
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	}, {
		'desc' : 'Total',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	}, {
		'desc' : '',
		'key' : 'amount',
		'calculationType' : 'Sum',
		'contentType' : 'Currency',
		'calculatedValue' : 0,
		'colSpan' : 1
	} ];
	
	$scope.partnerAdjustmentFooterList=[ {
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},{
		'desc' : '',
		'key' : '',
		'calculationType' : '',
		'contentType' : '',
		'calculatedValue' : '',
		'colSpan' : 1
	},  {
		'desc' : '',
		'key' : 'amount',
		'calculationType' : 'Sum',
		'contentType' : 'Currency',
		'calculatedValue' : 0,
		'colSpan' : 1
	} ];

	var fetchHeaderList=function(category){
		var type=category;
		if(type=='Premium'){
			return $scope.memberHeaderList;
		}
		else {
			return $scope.sectionHeaderList;
		}
	}
	var invoiceDetailSuccess = function(invoiceObj) {
		$scope.invoiceDetails = {};
		$scope.invoiceSummary = {};
		$scope.invoiceDetails.summary = {};
		$scope.invoiceDetails.identity = invoiceObj.invoiceId;
		$scope.invoiceDetails.period = invoiceObj.period;
		$scope.invoiceDetailsMap = {};
		
		// var type = 'Individual';
		if (invoiceObj) {
			if(invoiceObj.invoiceDetails != null && invoiceObj.invoiceDetails != undefined){
				$scope.invoiceDetails.summary.currentInvoiceAmount = invoiceObj.invoiceDetails.currentInvoiceAmount;
				$scope.invoiceDetails.summary.netDue = invoiceObj.invoiceDetails.netDue;
				$scope.invoiceSummary.lineItems = getInvoiceDetailLineItems(invoiceObj);
				//console.log(JSON.stringify($scope.invoiceSummary.lineItems));
				$scope.invoiceSummary.length = Object
						.keys($scope.invoiceSummary.lineItems).length;
			}
		} else {
			$scope.invoiceDetail = '';
			$scope.invoiceObj = '';
			$scope.isInvoiceLoading = false;
		}
	}

	var getEmployeeList = function(_employees) {
		if (_employees != undefined) {
			var employeesList = new Array();
			if (_employees != undefined) {
				if (Array.isArray(_employees)) {
					for ( var i = 0; i < _employees.length; i++) {
						var employee = _employees[i];
						employeesList[i] = getEmployeeObj(employee,null);
					}
				} else {
					var employee = _employees;
					employeesList[0] = getEmployeeObj(employee,null);
				}
			}
			return employeesList;
		}
	}

	$scope.innerTableId = 0;
	$scope.innerTableData=[];
	var getEmployeeObj = function(_employee,beType) {
		var employeeObj = {};
		
		if(_employee.amount !=undefined && _employee.amount != null ){
			for ( var i = 0; i < _employee.amount.length; i++) {
				if(_employee.amount[i].qualifier=='APTC'){
					employeeObj.aptcAmount = _employee.amount[i].value;
				}			
			}
		}
		
		if(_employee.additionalInfos != undefined && _employee.additionalInfos != null ){
			if(_employee.additionalInfos.additionalInfo != undefined && _employee.additionalInfos.additionalInfo != null){
				for ( var i = 0; i < _employee.additionalInfos.additionalInfo.length; i++) {
					if(_employee.additionalInfos.additionalInfo[i].name=='AssociatedWithName'){
						employeeObj.groupName = _employee.additionalInfos.additionalInfo[i].value;
					}
					if(_employee.additionalInfos.additionalInfo[i].name=='REASON_CODES'){
						employeeObj.adjustmentReason= _employee.additionalInfos.additionalInfo[i].value;
					}
				}
			}
		}
		
		if(_employee.subscriber!=undefined && _employee.subscriber!=null){
		employeeObj.subscriberId = _employee.subscriber.subscriberId.id;
		if(_employee.subscriber.subscriberName && (_employee.subscriber.subscriberName.middleName==null || _employee.subscriber.subscriberName.middleName == undefined)){
		/*employeeObj.subscriberName = _employee.subscriber.subscriberName.firstName
				+ ' ' + _employee.subscriber.subscriberName.lastName;*/
		employeeObj.subscriberFirstName = _employee.subscriber.subscriberName.firstName;
		employeeObj.subscriberLastName = _employee.subscriber.subscriberName.lastName;
		}
		if(_employee.subscriber.subscriberName && (_employee.subscriber.subscriberName.middleName!=null && _employee.subscriber.subscriberName.middleName != undefined)){
			employeeObj.subscriberName = _employee.subscriber.subscriberName.firstName
			+ ' ' + _employee.subscriber.subscriberName.middleName + ' ' + _employee.subscriber.subscriberName.lastName;
			employeeObj.subscriberFirstName = _employee.subscriber.subscriberName.firstName;
			employeeObj.subscriberLastName = _employee.subscriber.subscriberName.lastName;
		}
		}
		employeeObj.coverageType = _employee.coverageType;
		//setting only the first amount and qualifier for subscriber 
		employeeObj.amount= _employee.amount[0].value;   // setting the retro amt value to first element of amt array
		//building the amount type for the employee list
		employeeObj.retroAmountType=buildRetroAmountType(_employee.amount[0].name);
		
		//end
		for ( var i = 0; i < _employee.amount.length; i++) {
			if(_employee.amount[i].qualifier=='TOTAL_PREMIUM'){
				employeeObj.premiumAmount = _employee.amount[i].value;
				employeeObj.amountType=_employee.amount[i].qualifier;
			}
			if(_employee.amount[i].qualifier=='EMPLOYEE_RESP'){
				employeeObj.employeeResponsibility =_employee.amount[i].value;
			}
			if(_employee.amount[i].qualifier=='EMPLOYER_RESP'){
				employeeObj.employerResponsibility  =_employee.amount[i].value;
			}
			
		}
		if (_employee.coveragePeriod != undefined) {
			employeeObj.coverageFrom = $filter('date')(_employee.coveragePeriod.from, $scope.clientDateFormat);
			employeeObj.coverageTo = $filter('date')(_employee.coveragePeriod.to, $scope.clientDateFormat);
			employeeObj.coveragePeriod=$scope.toUTCDate(_employee.coveragePeriod.from)+'-' +$scope.toUTCDate(_employee.coveragePeriod.to);
		}
		if(_employee.healthPlan != null && _employee.healthPlan != undefined){
		employeeObj.planName=_employee.healthPlan.planName;
		}
		if(_employee.memberSubItems !=null && _employee.memberSubItems != undefined){
		var memberDetails = getMemberList(_employee.memberSubItems.memberSubItem);
		employeeObj.memberDetails = memberDetails;
		$scope.innerTableId = $scope.innerTableId +1;
		if(beType=='SubsidyProvider'){
			
			var innerTable = {
				    "innerTableColSpan" : 6,
				    "innerChild1TableId" : $scope.innerTableId,
					"headers" : $scope.subsidyProviderEmployeeHeaderList,
					"data" : memberDetails
				};
			
		}
		else{
		var innerTable = {
		    "innerTableColSpan" : 9,
		    "innerChild1TableId" : $scope.innerTableId,
			"headers" : $scope.employeeMemberHeaderList,
			"data" : memberDetails
		};
		}
		employeeObj.innerTable = innerTable;
		
		$scope.innerTableData.push(employeeObj.innerTable);
		

							employeeObj.action = '<a class="testClass" ng-class="{true :\'slide-minus slide-plus hide-text\' , false : \'slide-plus hide-text\'}[ innerChild1TableId['
							+ $scope.innerTableId
							+ '] == true ]" href="javascript:;" ng-click="toggle('+$scope.innerTableId+');"></a>';
		}
		return employeeObj;
	}
	
	
	
	var buildRetroAmountType=function(_amountType){
		if(_amountType != null && _amountType !=undefined){
		if(_amountType=='EMPLOYER_RESP'){
			return 'Employer Responsibility';
		}
		else if(_amountType=='EMPLOYEE_RESP'){
			return 'Employee Responsibility';
		}
		else
			return _amountType;
	}
	}
	var getMemberList = function(_memberList) {
		var invoiceMemberList = new Array();
		if (_memberList != undefined) {
			if (Array.isArray(_memberList)) {
				for ( var i = 0; i < _memberList.length; i++) {
					var invMember = _memberList[i];
					invoiceMemberList[i] = getMemberObj(invMember);
				}
			} else {
				var invMember = _memberList;
				invoiceMemberList[0] = getMemberObj(invMember);
			}
		}
		return invoiceMemberList;
	}

	var getMemberObj = function(_member) {
		var invMember = _member.member;
		var memberObj = new Object();
		memberObj.memberId = invMember.exchangeMemberId.id;
		if(invMember.memberName && ( invMember.memberName.middleName == null ||invMember.memberName.middleName == undefined)){
		memberObj.memberFirstName = invMember.memberName.firstName ;
		memberObj.subscriberName=invMember.memberName.firstName + ' '+ invMember.memberName.lastName;
		memberObj.memberLastName = invMember.memberName.lastName;

		}
		if( invMember.memberName && ( invMember.memberName.middleName!=null &&  invMember.memberName.middleName != undefined)){
			memberObj.memberName = invMember.memberName.firstName
			+ ' ' + invMember.memberName.middleName + ' ' + invMember.memberName.lastName;
			memberObj.subscriberName=invMember.memberName.firstName
			+ ' ' + invMember.memberName.middleName + ' ' + invMember.memberName.lastName;
			memberObj.memberFirstName = invMember.memberName.firstName ;
			memberObj.memberLastName = invMember.memberName.lastName;
			
		}
		
		
		if (_member.coveragePeriod != undefined) {
			memberObj.coverageFrom = $filter('date')(_member.coveragePeriod.from, $scope.clientDateFormat);
			memberObj.coverageTo = $filter('date')(_member.coveragePeriod.to, $scope.clientDateFormat);
			memberObj.membercoveragePeriod= $scope.toUTCDate(_member.coveragePeriod.from)+'-' +$scope.toUTCDate(_member.coveragePeriod.to);

		}
		memberObj.membercoverageType = _member.coverageType;
		if(_member.healthPlan != undefined){
		memberObj.planId = _member.healthPlan.issuerPlanId
		memberObj.memberplanName = _member.healthPlan.planName
		memberObj.employeeResponsibility = _member.healthPlan.employeeResponsibility;
		memberObj.employerResponsibility = _member.healthPlan.employerResponsibility;
		}
		memberObj.relationship = invMember.relationship;
	    memberObj.amountType=_member.amount[0].qualifier;
		$scope.buildPremiumAptcAmount(_member.amount,memberObj);
		$scope.buildEmployeeAndEmployerContributionAmount(_member.amount,memberObj);
		return memberObj;
	}
	
	   $scope.buildPremiumAptcAmount=function(_amt,memberObj){
    	var amtList = new Array();
		
    	if (_amt != undefined) {
			if (Array.isArray(_amt)) {
				for ( var i = 0; i < _amt.length; i++) {
					if(_amt[i].qualifier=='TOTAL_PREMIUM'){
						memberObj.planPremium=_amt[i].value;
					}
					else if(_amt[i].qualifier=='APTC'){
						memberObj.aptcAmount =_amt[i].value;
					}
				}
				
			}	
		}
		
		if(memberObj.aptcAmount == undefined || memberObj.aptcAmount == null){
			memberObj.aptcAmount = '--';
		}
		
		if(memberObj.planPremium == undefined || memberObj.planPremium == null){
			memberObj.planPremium = '--';
		}
	   }
    	
    $scope.buildEmployeeAndEmployerContributionAmount=function(_amt,memberObj){
    	var amtList = new Array();
		if (_amt != undefined) {
			if (Array.isArray(_amt)) {
				for ( var i = 0; i < _amt.length; i++) {
					if(_amt[i].qualifier=='EMPLOYEE_RESP'){
					     memberObj.mememployeeResponsibility=_amt[i].value;
					}
					else if(_amt[i].qualifier=='EMPLOYER_RESP'){
						memberObj.mememployerResponsibility  =_amt[i].value;
					}
					else if(_amt[i].qualifier=='TOTAL_PREMIUM'){
						memberObj.premiumAmount = _amt[i].value;
						memberObj.amountType=_amt[i].qualifier;
					}
				}
				
			}	}}
    
	var getInvoiceDetailLineItems = function(invoiceObj) {
		var lineItems = [];
		if (invoiceObj.invoiceDetails != undefined
				&& invoiceObj.invoiceDetails.breakUp != undefined
				&& invoiceObj.invoiceDetails.breakUp.itemBreakUp != undefined) {
			var itemBreakUps = invoiceObj.invoiceDetails.breakUp.itemBreakUp;
			if (Array.isArray(itemBreakUps)) {
				for ( var i = 0; i < itemBreakUps.length; i++) {
					lineItems.push(getItemBreakup(itemBreakUps[i]));
				}
			} else {
				lineItems.push(getItemBreakup(itemBreakUps));
			}
		}
		return lineItems;
	}
	

	$scope.publishWriteOnDetails = function() {
		EventBusSrvc.publish('writeOnDetails', $scope.invoiceDetailEventObj);
	}
													
	var getItemBreakup = function(itemBreakUp) {
		if (itemBreakUp.item == 'OUTSTANDING_ACCOUNT_BALANCE') {
			$scope.outStandingBalance = itemBreakUp.totalAmount;
		}
		if(itemBreakUp.item == 'PRIOR_DUE'){
			$scope.priorRecievables=itemBreakUp.totalAmount;
			
		}
		
		var itemBreakUpObj = {};
		var itemType = itemBreakUp.item;
		console.log(itemType);
		itemBreakUpObj.type =getLineItemCategory(itemType);
		itemBreakUpObj.description = getLineItemCategory(itemType);
		itemBreakUpObj.totalAmount = itemBreakUp.totalAmount;
		itemBreakUpObj.isCredit = itemBreakUp.isCredit;
		
		
		     if(itemType=='PAYMENT'){
			  itemBreakUpObj.description = 'Payment Details';
			  itemBreakUpObj.headers = $scope.paymentDetailsHeaderList;
			  if(itemBreakUp.genericSubItems !=undefined){
					itemBreakUpObj.detailLines=buildGenericSubItemType(itemBreakUp.genericSubItems.genericSubItem,itemBreakUp.item);
					if(itemBreakUpObj.detailLines.length == 0){
						itemBreakUpObj.detailLines = undefined;
					}
					console.log('payments--->'+itemBreakUpObj.detailLines);
			  }
			
		    }
			if( itemType == 'APTC' || itemType == 'DISCOUNT'  || itemType == 'CREDIT' || itemType == 'FEE' || itemType == 'TAX' || itemType =='OTHER'){
				itemBreakUpObj.headers = $scope.sectionHeaderList;
				if($scope.typeOfIncomingInvoice=='HealthPlanProvider'&& itemType == 'FEE'){
					itemBreakUpObj.headers = $scope.partnerFeeHeaderList;
				}
				if(itemBreakUp.genericSubItems!=undefined)
					itemBreakUpObj.detailLines=buildGenericSubItemType(itemBreakUp.genericSubItems.genericSubItem,itemBreakUp.item);
				else if(itemBreakUp.planSubItems != undefined){
					itemBreakUpObj.detailLines=buildPlanSubItemType(itemBreakUp.planSubItems.planSubItem,itemBreakUp.item);
				}
				else if(itemBreakUp.employeeSubItems != undefined){
					itemBreakUpObj.description = 'Subscriber List';
					if($scope.beType == 'SubsidyProvider')
						itemBreakUpObj.headers = $scope.subsidyProviderEmployeeHeaderList;
					itemBreakUpObj.detailLines=buildEmployeeSubItemType(itemBreakUp.employeeSubItems.subscriberSubItem,$scope.beType);
				}
			}else if(itemType == 'PREMIUM'){
				if(itemBreakUp.memberSubItems!=undefined){
					itemBreakUpObj.description = 'Member List';
					itemBreakUpObj.headers = $scope.memberHeaderList;
					itemBreakUpObj.detailLines=buildMemberSubItemType(itemBreakUp.memberSubItems.memberSubItem);
				}
				else if(itemBreakUp.employeeSubItems!=undefined){
					itemBreakUpObj.description = 'Employee List';
					if($scope.beType == 'Group')
						itemBreakUpObj.headers = $scope.groupEmployeeHeaderList;
					else if(($scope.beType == 'Exchange'))
						itemBreakUpObj.headers = $scope.exchangeEmployeeHeaderList; 
					itemBreakUpObj.detailLines=buildEmployeeSubItemType(itemBreakUp.employeeSubItems.subscriberSubItem,$scope.beType);
				}
			}else if(itemType == 'RETRO'){
				if(itemBreakUp.memberSubItems!=undefined){
					itemBreakUpObj.description == 'Member List';
					itemBreakUpObj.headers = $scope.memberHeaderList;
					itemBreakUpObj.detailLines=buildMemberSubItemType(itemBreakUp.memberSubItems.memberSubItem);
				}
				else if(itemBreakUp.employeeSubItems!=undefined){
					itemBreakUpObj.headers = $scope.retroHeaderList;
					itemBreakUpObj.description = "Retroactive Adjustment";
					itemBreakUpObj.detailLines=buildEmployeeSubItemType(itemBreakUp.employeeSubItems.subscriberSubItem,null);
				}
				else if(itemBreakUp.planSubItems!=undefined){
					itemBreakUpObj.headers = $scope.partnerAdjustmentHeaderList;
					itemBreakUpObj.description = "Adjustment";
					itemBreakUpObj.detailLines=buildPlanSubItemType(itemBreakUp.planSubItems.planSubItem,itemBreakUp.item);
				}
			}
			else if(itemType=='ADJUSTMENT'){
				itemBreakUpObj.headers=$scope.manualAdjHeaderList;
			//	itemBreakUpObj.description='Manual Adjustment';
				if(itemBreakUp.genericSubItems!=undefined)
					itemBreakUpObj.detailLines=buildGenericSubItemType(itemBreakUp.genericSubItems.genericSubItem,itemBreakUp.item);
			}
		
		//console.log(JSON.stringify(itemBreakUpObj));
		return itemBreakUpObj;
	}
	
	var buildGenericSubItemType=function(_genericList){
		var genericList=new Array();
			if (_genericList != undefined) {
				for ( var i = 0; i < _genericList.length; i++) {
					var generic = _genericList[i];
					genericList.push(getSubItemObj(generic));
			}
		}
		return genericList;
	}
	
	var buildDummyGenericSubItemType=function(_genericList){
		var genericList=new Array();
		var generic =_genericList[0]; 
		generic.description='No Data';
		genericList.push(generic);
		return genericList;
	}
	
	var buildPlanSubItemType=function(_planList,planItemType){
		var planList=new Array();
		if (_planList != undefined) {
			for ( var i = 0; i < _planList.length; i++) {
				var plan = _planList[i];
				planList.push(getPlanSubItemObj(plan));
		}
	}
		planList = planList(employeesList);
	return planList;
}
	
	
	var buildMemberSubItemType=function(_memberList){
		var invoiceMemberList = new Array();
		if (_memberList != undefined) {
				for ( var i = 0; i < _memberList.length; i++) {
					var invMember = _memberList[i];
					invoiceMemberList.push(getMemberObj(invMember));
			}
		}
		invoiceMemberList = setNoData(invoiceMemberList);
		return invoiceMemberList;
	}
	
	//Seting 'No Data' if table has no records to display.
	function setNoData(list){
		if(list && list.length === 0){
			list = 'No Data';
		}
		return list;
	}
	var buildSubscriberSubItemType=function(_empList){
			var employeesList = new Array();
			if (_empList != undefined) {
					for ( var i = 0; i < _empList.length; i++) {
						var employee = _empList[i];
						employeesList.push(getEmployeeObj(employee,null));
					}
				} 
			return employeesList;
		}
	
	var buildEmployeeSubItemType=function(_empList,beType){
		var employeesList = new Array();
		if (_empList != undefined) {
				for ( var i = 0; i < _empList.length; i++) {
					var employee = _empList[i];
					employeesList.push(getEmployeeObj(employee,beType));
				}};
		employeesList = setNoData(employeesList);
		return employeesList;
	}
		
	var getSubItemObj = function(subItem) {
		var subItemObj = {};
		if(subItem.description == 'MoneyTransfer')
			subItemObj.description = 'Payment Adjustment';
			else
				subItemObj.description = subItem.description;
		subItemObj.qualifier = subItem.amount[0].name;
		subItemObj.amount = subItem.amount[0].value;
		subItemObj.reference = subItem.reference;
		subItemObj.isCredit = subItem.isCredit;
		if(subItem.associatedDate && subItem.associatedDate != undefined)
		subItemObj.associatedDate=$filter('date')(subItem.associatedDate, $scope.clientDateFormat);
		subItemObj.manualAdjName=buildManualAdjName(subItem.amount[0].name);
		subItemObj.manualAdjType=buildManualAdjName(subItem.amount[0].qualifier);
		return subItemObj;
		
	}
	var buildManualAdjName=function(manAdjName){
		 return $filter('translate')(manAdjName);
	}
	var getPlanSubItemObj=function(_plan,_planItemType){
		var planObj = new Object();
		if (_plan.coveragePeriod != undefined) {
			planObj.coverageFrom = $filter('date')(_plan.coveragePeriod.from, $scope.clientDateFormat);
			planObj.coverageTo = $filter('date')(_plan.coveragePeriod.to, $scope.clientDateFormat);
			planObj.coveragePeriod= $scope.toUTCDate(_plan.coveragePeriod.from)+'-' +$scope.toUTCDate(_plan.coveragePeriod.to);

		}
		planObj.coverageType = _plan.coverageType;
		if(_plan.healthPlan != undefined){
			planObj.planId = _plan.healthPlan.issuerPlanId;
			planObj.planName = _plan.healthPlan.planName;
		}
		//displaying the first amount for the partner 
		planObj.amountType=_plan.amount[0].name;
		planObj.amount=_plan.amount[0].value;
		
		return planObj;
	
	}

	function getLineItemCategory(lineItem) {
		category = lineItem;
		if (lineItem == 'APTC' || lineItem == 'DISCOUNT'
				|| lineItem == 'CREDIT') {
			category = 'Credits';
		}
		else if (lineItem == 'FEE') {
			category = 'Fees';
		} else if (lineItem == 'TAX') {
			category = 'Taxes';
		} else if (lineItem == 'OUTSTANDING_ACCOUNT_BALANCE') {
			category = 'Outstanding Balance';
		} else if (lineItem == 'PREMIUM') {
			category = 'Premium';
		} 
		else if(lineItem=='RETRO' && $scope.typeOfIncomingInvoice=='HealthPlanProvider'){
			category="Adjustment";
		}else if(lineItem=='RETRO'){
			category="Retroactive Adjustment";
		}
		else if(lineItem=='ADJUSTMENT'){
			category='Manual Adjustment';
		}
		else if(lineItem=='PAYMENT')
			{
			category='Total Payments';
			}
		else if(lineItem=='PRIOR_DUE')
		{
		category='Prior Due';
		}
		else {
			category = "Others Adjustment";
		}

		return category;
	}


	var getMemberDetails = function(invoice) {
		var memberDetails = [];
		var planName;
		var planId;
		var coverageType;
		if (invoice.enrolledGroupBillAmounts != null
				&& invoice.enrolledGroupBillAmounts != undefined
				&& invoice.enrolledGroupBillAmounts.length > 0) {
			angular
					.forEach(
							invoice.enrolledGroupBillAmounts,
							function(enrollGrpBillAmt, index) {
								if (enrollGrpBillAmt.groupAmounts != null
										&& enrollGrpBillAmt.groupAmounts != undefined
										&& enrollGrpBillAmt.groupAmounts.length > 0) {
									angular
											.forEach(
													enrollGrpBillAmt.groupAmounts,
													function(
															groupAmt,
															index) {
														planName = '';
														planId = '';
														coverageType = '';
														// Populate
														// plan
														// details
														if (groupAmt.enrolledPlan != null
																&& groupAmt.enrolledPlan != undefined) {
															if (groupAmt.enrolledPlan.healthPlan != null
																	&& groupAmt.enrolledPlan.healthPlan != undefined) {
																planName = groupAmt.enrolledPlan.healthPlan.name;
																planId = groupAmt.enrolledPlan.healthPlan.externalId;
															}
															if (groupAmt.enrolledPlan.coverageInfo != null
																	&& groupAmt.enrolledPlan.coverageInfo != undefined) {
																coverageType = groupAmt.enrolledPlan.coverageInfo.coverageType;
															}
														}
														// Populate
														// member
														// details

														if (groupAmt.memberBreakUps != null
																&& groupAmt.memberBreakUps != undefined
																&& groupAmt.memberBreakUps.length > 0) {
															angular
																	.forEach(
																			groupAmt.memberBreakUps,
																			function(
																					memBreakUp,
																					index) {
																				var member = {};
																				member.planName = planName;
																				member.planId = planId;
																				member.coverageType = coverageType;
																				member.amountCode = groupAmt.code;
																				if (memBreakUp.member != null
																						&& memBreakUp.member != undefined) {
																					member.memberId = memBreakUp.member.memberId;
																					if (memBreakUp.member.personalProfile != null
																							&& memBreakUp.member.personalProfile != undefined) {
																						member.memberName = memBreakUp.member.personalProfile.displayName;
																					}
																				}
																				if (memBreakUp.amount != null
																						&& memBreakUp.amount != undefined) {
																					member.amount = memBreakUp.amount.value;
																				}
																				memberDetails
																						.push(member);
																			});
														}
													});
								}
							});
		}
		return memberDetails;
	}

	
	var getInvoiceDetailErrorCallback = function(error){
		$scope.invoiceDetails.invoiceId = '';
		$scope.invoiceDetails = {};
		if($scope.buildFeeGenericList==undefined ||$scope.buildFeeGenericList=='')
			$scope.buildFeeGenericList='No data';
		}

	var getInvoiceDetailSuccessCallback = function(_invoiceWrapper){
		if((_invoiceWrapper.status == 'OPEN' || _invoiceWrapper.status == 'REJECTED' 
			|| _invoiceWrapper.status == 'SETTLED' || _invoiceWrapper.status == 'PARTIAL_PAYMENT')
				&& _invoiceWrapper.latest == true && _invoiceWrapper.subscriptionStatus != 'INACTIVE'){
			$scope.showRebillInvoice = true;
			$scope.showEditInvoice = true;
		}
		
		if((_invoiceWrapper.status == 'OPEN' || _invoiceWrapper.status == 'SETTLED' 
				|| _invoiceWrapper.status == 'PARTIAL_PAYMENT')
				&& _invoiceWrapper.latest == true){
			$scope.showRegenrateInvoice = true;
		}
		
		if(_invoiceWrapper.status == 'REVIEW') {
			$scope.showApproveInvoice = true;
			$scope.showRejectInvoice = true;
		}
		
		invoiceDetailSuccess(_invoiceWrapper.invoice);
		if($scope.buildFeeGenericList==undefined ||$scope.buildFeeGenericList=='')
			$scope.buildFeeGenericList='No data';
	}
	
	$scope.invoiceIdentity = '';
	$scope.showRegenrateInvoice = false;
	$scope.showRebillInvoice = false;
	$scope.showApproveInvoice = false;
	$scope.showRejectInvoice = false;
	$scope.showEditInvoice = false;	
	
	$scope.beType ='';
	$scope.beIdentity ='';
	var invoiceDetailsCallback = function(invoiceDetail, oldVal) {
		if (null != invoiceDetail) {
			$scope.invoiceDetailEventObj = invoiceDetail;
			$scope.status = invoiceDetail.status;
			$scope.latest = invoiceDetail.latest;
			$scope.typeOfIncomingInvoice = invoiceDetail.type;
			$scope.invoiceIdentity = invoiceDetail.identity;
			$scope.beIdentity =invoiceDetail.beIdentity;
			var dueDate=invoiceDetail.dueDate;
			var generationDate=invoiceDetail.generationDate;
			var billPeriod=$scope.toUTCDate(invoiceDetail.billPeriod.beginsOn.date)+'-'+$scope.toUTCDate(invoiceDetail.billPeriod.endsOn.date);
				$scope.invoiceRightSection={"subscriberId":invoiceDetail.beId,"name":invoiceDetail.name,"period":billPeriod,
						"dueDate":dueDate,"generationDate":generationDate,"invoiceType":invoiceDetail.invoiceType,"status":invoiceDetail.status,"subscription":invoiceDetail.subscription};
			
				//EventBusSrvc.publish($scope.invoiceRightSection)
			
			if (invoiceDetail != null && invoiceDetail != undefined) {
				$scope.beType = invoiceDetail.type;
				var params = {"identity":invoiceDetail.identity}
				var searchCriteriaJson = {};
				FinancialsInvoiceService.getInvoiceDetailForAdmin(params,
				searchCriteriaJson, getInvoiceDetailSuccessCallback,
				getInvoiceDetailErrorCallback);
			} else {
				$scope.invoiceDetails.invoiceId = '';
				$scope.invoiceDetails = {};
			}
		}
	};
	
	EventBusSrvc.subscribeAndInvalidatePayload('invoiceDetail', $scope,invoiceDetailsCallback);
	
	var getAllFinancialsInvoicesForAdminSuccess = function(data){
		if(data){
			var invoiceObj = FinancialsInvoiceHelperService.getInvoiceTransformer(data.content[0],$scope,'invoiceDetail');
			invoiceObj.identity = invoiceObj.invoiceId;
			invoiceObj.type = invoiceObj.beType; 
			invoiceObj.name = invoiceObj.entityName;
			invoiceDetailsCallback(invoiceObj);
		}
	};
	
	var getAllFinancialsInvoicesForAdminError = function(){
		
	};
	
	var showInvoiceDetail = function(ftEventData){
		if (null != ftEventData) {
			var criteria= {};
			criteria.projectedFields = FinancialsInvoiceHelperService.getProjectedFieldsForInvoice();
			
			criteria.criteria = {};
			criteria.criteria['invoiceId'] = {
					'operator' : '=',
					'columnValue' :  ftEventData.dataIdentity ,
					'caseSensitiveSearch' : 'false'
			};
			
			if(ftEventData){
				FinancialsInvoiceService.getAllFinancialsInvoicesForAdmin(
						criteria, getAllFinancialsInvoicesForAdminSuccess,
						getAllFinancialsInvoicesForAdminError);		
			}
		}
	}
	

	EventBusSrvc.subscribeAndInvalidatePayload('ftEventData', $scope,showInvoiceDetail);
}];

	                                			

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'FinancialInvoiceDetailsCtrl',
	'id' : hcentive.WFM.FinancialInvoiceDetailsCtrl
});