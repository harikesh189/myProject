hcentive.WFM.financialsaccountlistview = [function() {
	
	return {
		restrict : 'E',
		templateUrl : function(elem,attr){return getTemplateUrl(attr, "views/financials/accounts-and-ledgers.html")},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};
} ];

// wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "financialsaccountlistview",
	"id" : hcentive.WFM.financialsaccountlistview
});

 
