hcentive.WFM.RemitSubscriber = [
		'$scope',
		'FinancialRemitsService',
		'EventBusSrvc',
		'NotifySrvc',
		'$location',
		function($scope, financialsRemitsService, EventBusSrvc,NotifySrvc,$location) {
			
		$scope.viewType = 'ENTITY';
		$scope.partnerDetails=EventBusSrvc.subscribe('remitPartnerDetails');
		$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalPayableAmount;
		$scope.excludedRemits = new Array();
		$scope.selectedViewType = 'ENTITY';
		$scope.periodMap = new Object();
		
		
		var launchDoRemitPopup = function(excludedMap,viewType,isExclusion,isIssuerAssignedFilter) {
			NotifySrvc({
				id : 'simpleDialog',
				template: 'Do you want to proceed with this remit transaction ?',
				title : 'Are You Sure',
				backdrop : true,
				closeButton : false,
				success : {
					label : 'Yes',
					fn : function() {
					$scope.doRemitFn(excludedMap,viewType,isExclusion,isIssuerAssignedFilter)
				}
				},
				cancel :{
					label : 'Cancel',
					fn : function() {}
					}
				
			});
		}
		
		var launchErrorRemitPopup = function() {
			NotifySrvc({
				id : 'simpleDialog',
				template: 'Please select valid amount. Zero or negative amount cannot be remitted.',
				title : 'Remit',
				backdrop : true,
				closeButton : false,
				success : {
					label : 'Ok',
					fn : function() {
					
				}
				}
			});
		}
		
		$scope.doRemit = function(excludedMap,viewType,isExclusion,isIssuerAssignedFilter){
			if(parseFloat($scope.partnerDetails.totalSelectedAmount) <= 0) {
				launchErrorRemitPopup();
			} else {
				launchDoRemitPopup(excludedMap,viewType,isExclusion,isIssuerAssignedFilter);
			}
		}
		
		$scope.doRemitFn = function(excludedMap,viewType,isExclusion,isIssuerAssignedFilter){
			var params = {"partnerId" : $scope.partnerDetails.partnerIdentity};
			var remitRunPayableObj ={}
			
			var exclusionBeIdList = new Array();
			var ftEntryInclusionList =  new Array();
			var ftEntryExclusionList = new Array();
			var inclusionBeIdList = new Array();
			var remitRunCoverageList =  new Array();
			var remitRunCoverageDTO = {};
			console.log('ExcludedMap :: ' +JSON.stringify(excludedMap));
			if(viewType == 'ENTITY'){
					delete excludedMap['IS_EXCLUSION'];
					if(excludedMap != null && Object.keys(excludedMap).length > 0){
						if(isExclusion){
						var isBeExclusion;
						for(var beId in excludedMap){
							var ftEntryList = [];
							var beExclusionMap =  excludedMap[beId];
							isBeExclusion = isExclusion;
							var selectedAmount;
							for(var key in beExclusionMap){
								var value = beExclusionMap[key];
								if(key == 'IS_ALL_SELECTED'){
									isBeExclusion = value;
								}else if(key == 'SELECTED_AMOUNT'){
									selectedAmount = value;
								}else if(key != 'TOTAL_SELECTED_COUNT'){
									ftEntryList = ftEntryList.concat(value);
								}
							}
							
							if(!isBeExclusion){
								exclusionBeIdList.push(beId);
							}
							
							if(ftEntryList != null && ftEntryList.length >0 ){
								if(!isBeExclusion){
									ftEntryInclusionList = ftEntryInclusionList.concat(ftEntryList);
								}else{
									ftEntryExclusionList = ftEntryExclusionList.concat(ftEntryList);
									}
							}
						}
					}else{
						var isBeExclusion;
						for(var beId in excludedMap){
							var ftEntryList = [];
							var beExclusionMap =  excludedMap[beId];
							isBeExclusion = isExclusion;
							var selectedAmount;
							for(var key in beExclusionMap){
								var value = beExclusionMap[key];
								if(key == 'IS_ALL_SELECTED'){
									isBeExclusion = value;
								}else if(key == 'SELECTED_AMOUNT'){
									selectedAmount = value;
								}else if(key != 'TOTAL_SELECTED_COUNT'){
									ftEntryList = ftEntryList.concat(value);
								}
							}
							
							if(isBeExclusion){
								inclusionBeIdList.push(beId);
							}
							
							if(ftEntryList != null && ftEntryList.length >0 ){
								if(isBeExclusion){
									ftEntryExclusionList = ftEntryExclusionList.concat(ftEntryList);
								}else{
									ftEntryInclusionList = ftEntryInclusionList.concat(ftEntryList);
									}
							}
						}
					}
					
					}
					
					remitRunCoverageDTO.ftEntryExclusionList = ftEntryExclusionList;
					remitRunCoverageDTO.ftEntryInclusionList = ftEntryInclusionList;
					
					if(isExclusion){
						remitRunCoverageDTO.beIds = exclusionBeIdList;
					}else{
						remitRunCoverageDTO.beIds = inclusionBeIdList;
						}
						
					remitRunCoverageDTO.exclusion = isExclusion;
					remitRunCoverageDTO.excludeIssuerEntity = isIssuerAssignedFilter;
					
					remitRunCoverageList.push(remitRunCoverageDTO);
			}else{
				if(excludedMap != undefined && Object.keys(excludedMap).length > 0){
						for(var coveragePeriod in excludedMap){
							if(!endswith(coveragePeriod,'_IS_BE_EXCLUSION_LIST') && !endswith(coveragePeriod,'_IS_EMPTY_ISSUER_ID_EXCLUDED')){
							var remitRunCoverageDTO = {};
							var ftEntryInclusionList =  new Array();
							var ftEntryExclusionList = new Array();							
							var BeIdsList = new Array();
						
							var coveragExcludedMap =  excludedMap[coveragePeriod];
							var isCoverageExclusion = excludedMap[coveragePeriod+'_IS_BE_EXCLUSION_LIST'];
							var isEmptyIssuerIdExcluded = excludedMap[coveragePeriod+'_IS_EMPTY_ISSUER_ID_EXCLUDED'];
							
							var BeIdFor_IS_FT_EXCLUSION_LIST = '';
							
							for(var key in coveragExcludedMap){
								var isBeIdExclusion;	
								if(!endswith(key,'_IS_FT_EXCLUSION_LIST') && !endswith(key,'_TOTAL_SELECTED_COUNT') && !endswith(key,'_TOTAL_SELECTED_AMOUNT')){
								//console.log('key-->'+key);
								
								if(BeIdFor_IS_FT_EXCLUSION_LIST != key.split("_")[0]){
									BeIdFor_IS_FT_EXCLUSION_LIST = key.split("_")[0];
									isBeIdExclusion = coveragExcludedMap[key+'_IS_FT_EXCLUSION_LIST'];
								}
									
								var value = coveragExcludedMap[key];
								
								ftEntryList = value;
								//console.log('isBeIdExclusion Inside->'+isBeIdExclusion);
								
								if(ftEntryList != null && ftEntryList.length >0 ){
									if(isBeIdExclusion){
										ftEntryExclusionList = ftEntryExclusionList.concat(ftEntryList);
									}else{
										ftEntryInclusionList = ftEntryInclusionList.concat(ftEntryList);
									}
								}
								
								if(isCoverageExclusion === true && isBeIdExclusion === false){
									isBeIdExclusion = true;
								}else if(isCoverageExclusion === true && isBeIdExclusion === true){
									isBeIdExclusion = false;
								}if(isCoverageExclusion === false && isBeIdExclusion === true){
									isBeIdExclusion = true;
								}else if(isCoverageExclusion === false && isBeIdExclusion === false){
									isBeIdExclusion = false;
								}
								
								if(isBeIdExclusion){
									BeIdsList.push(key);
								}
								//console.log('BeIdsList Inside->'+BeIdsList);
								
								//console.log('ftEntryExclusionList->'+ftEntryExclusionList+'   ftEntryInclusionList->'+ftEntryInclusionList);
								
							  }
								
							}
							
							remitRunCoverageDTO.ftEntryExclusionList = ftEntryExclusionList;
							remitRunCoverageDTO.ftEntryInclusionList = ftEntryInclusionList;
							remitRunCoverageDTO.beIds = BeIdsList;
							var coveragePeriodJson = $scope.periodMap[coveragePeriod];
							if(coveragePeriodJson != undefined){
								delete coveragePeriodJson['$$hashKey'];
								remitRunCoverageDTO.coveragePeriod = coveragePeriodJson;
							}
							remitRunCoverageDTO.exclusion = isCoverageExclusion;

							remitRunCoverageDTO.excludeIssuerEntity = false;	
							
							if(isEmptyIssuerIdExcluded != undefined){
								remitRunCoverageDTO.excludeIssuerEntity = isEmptyIssuerIdExcluded;
							}
							
							//console.log('isCoverageExclusion->'+isCoverageExclusion+'  ftEntryExclusionList->'+ftEntryExclusionList+'  ftEntryInclusionList->'+ftEntryInclusionList+'  BeIdsList.length->'+BeIdsList.length);
							if(!(isCoverageExclusion === false && ftEntryExclusionList.length == 0 && ftEntryInclusionList.length == 0 && BeIdsList.length == 0)){
								remitRunCoverageList.push(remitRunCoverageDTO);
							}

							}
					  }
					}
				}

			remitRunPayableObj.remitRunCoverageList = remitRunCoverageList;
			
			remitRunPayableObj.createdAt = $scope.partnerDetails.remitStartTimestamp;
			remitRunPayableObj.viewType = viewType;
			remitRunPayableObj.partnerPayableAmount = parseFloat($scope.partnerDetails.totalPayableAmount);
			remitRunPayableObj.partnerSelectedAmount = $scope.partnerDetails.totalSelectedAmount;
		
			console.log('Remit :: ' +JSON.stringify(remitRunPayableObj));
			financialsRemitsService.doRemit(params,
			remitRunPayableObj, doRemitSuccessCallback,
			doRemitErrorCallBack);
		}
		
		var doRemitSuccessCallback = function(data){
			if(data == 'SUCCESS'){
					$scope.succErrDialog('Remit','Your remits will be processed shortly.');
					$location.path("financials/remits");
					$location.replace();
				}else{
					$scope.succErrDialog('Remit','Remit failed, please try again.');
				}
		}
		
		var doRemitErrorCallBack = function(data){
			if(data && data.Error) {
				$scope.succErrDialog('Remit',data.Error);
			} else {
				$scope.succErrDialog('Remit','Remit failed, please try again.');
			}
		}
		
		var coveragePeriodListSuccessCallBack = function(data) {
					$scope.coveragePeriods = [];
					$scope.coveragePeriodsAmountArray = [];
					$scope.coveragePeriodsSelectedAmountArray = [];
					$scope.coveragePeriodsPayableAmountArray = [];
					
					for(var i = 0 ; i < data.length; i++){
						var key = '';
					      if(data[i][0] == null || data[i][0] == undefined || data[i][0] == ''){
					       key = '--';
					      }else{
					       key = data[i][0].beginsOn.date+'-' + data[i][0].endsOn.date;
					      }
						$scope.periodMap[key] = data[i][0];
						$scope.coveragePeriods.push(data[i][0]);
						$scope.coveragePeriodsAmountArray.push(data[i][1]);
						$scope.coveragePeriodsSelectedAmountArray.push(data[i][1]);
						$scope.coveragePeriodsPayableAmountArray.push(data[i][1]);
						$scope['selectionInfo_'+i] = 'AllSelected';
						$scope['coveragePagination_'+i] = defaultPagination('"exchangeEntityId"','');
					}
					
					$scope.totalSelectedCoveragePeriods = $scope.coveragePeriods.length;
					
					//console.log('Set selectedCoveragePeriodDisplay');
					$scope.initializeSelectedCoveragePeriodList();
					$scope.partnerDetails.totalSelectedAmount = 0;
					for(var i = 0; i < $scope.coveragePeriodsAmountArray.length; i++)
					{
						$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount + parseFloat($scope.coveragePeriodsAmountArray[i]);
					}
		};
		var coveragePeriodListErrorCallBack = function(data) {
					$scope.coveragePeriods = '';
		};
				
		function populateSearchCriteriaForCoveragePeriodList(excludeNonIssuerAssignedRecords) {
			var criteria = {};
			var createdAtFilter = {};
			createdAtFilter.columnValue = $scope.partnerDetails.remitStartTimestamp;
			createdAtFilter.caseSensitiveSearch = "false"; 
			createdAtFilter.operator = "<=";
			criteria.createdAt = createdAtFilter;
			
			var partnerIdFilter = {};
			partnerIdFilter.columnValue = $scope.partnerDetails.partnerIdentity;
			partnerIdFilter.caseSensitiveSearch = "false"; 
			partnerIdFilter.operator = "=";
			criteria.partnerIdentity = partnerIdFilter;
			
			var excludeRecordsWithoutIssuerAssignedIdFilter = {};
			excludeRecordsWithoutIssuerAssignedIdFilter.columnValue = excludeNonIssuerAssignedRecords;
			excludeRecordsWithoutIssuerAssignedIdFilter.caseSensitiveSearch = "false"; 
			excludeRecordsWithoutIssuerAssignedIdFilter.operator = "=";
			criteria.excludeRecordsWithoutIssuerAssignedId = excludeRecordsWithoutIssuerAssignedIdFilter;
			
			return criteria;
		}
		
		$scope.initializeSelectedCoveragePeriodList = function(){
		  $scope.selectedCoveragePeriodsIndex = new Array($scope.coveragePeriods.length);
			for(var i = 0; i < $scope.coveragePeriods.length ; i++)
			{
				$scope.selectedCoveragePeriodsIndex[i] = true;
			}
			$scope.$$childTail.updateCoverageDisplayForChangeNonIssuerAssignedRecords();
		}
		
		$scope.changeSelectedViewTypeRemits = function(viewType){
				launchSubscriberDetailPopup(viewType);
		}
		
			
		$scope.getSubscribersOnCoverageBasis = function(excludeNonIssuerAssignedRecords){
			var params = {};
			var searchCriteriaJson = {
				'criteria' : populateSearchCriteriaForCoveragePeriodList(excludeNonIssuerAssignedRecords),
				'pageRequestCriteria' : null,
				'referenceId' : null
			};
			financialsRemitsService.getAllCoveragePeriodsForPartner(params,searchCriteriaJson, coveragePeriodListSuccessCallBack,coveragePeriodListErrorCallBack);
		}
		
		var launchSubscriberDetailPopup = function(view) {
				NotifySrvc({
					id : 'simpleDialog',
					template: 'You want to switch views. All selections for the current view will be lost.',
					title : 'Are You Sure',
					backdrop : true,
					closeButton : false,
					success : {
						label : 'Yes',
						fn : function() {
						$scope.selectedViewType = view;
						if($scope.selectedViewType == 'COVERAGE'){
							$scope.getSubscribersOnCoverageBasis(false);
							$scope.$$childTail.resetToDefault();
						}else{
							$scope.$$childHead.refeshEntityView();	
						}
					}
					},
					cancel :{
						label : 'Cancel',
						fn : function() {
								if($scope.viewType == 'COVERAGE')
								{
									$scope.viewType = 'ENTITY';
								}
								else
								{
									$scope.viewType = 'COVERAGE';
								}
							}
					
						}
					
				});
			}
		
			
			var endswith = function(string, suffix) {
				return string.indexOf(suffix, string.length - suffix.length) != -1;
			};
		

		}];


hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'RemitSubscriber',
	'id' : hcentive.WFM.RemitSubscriber
});