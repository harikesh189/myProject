(function () {
    hcentive.WFM.FinancialsFilterConfigService = ['$translate',function ($translate) {
    	
    	var financialEventTypes = {
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.INVOICE_SETTLEMENT' :$translate.instant('financial.event.type.INVOICE_SETTLEMENT'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.BILLING_RUN' :$translate.instant('financial.event.type.BILLING_RUN'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.PAYMENT' :$translate.instant('financial.event.type.PAYMENT'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.WRITEOFF' :$translate.instant('financial.event.type.WRITEOFF'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.REMIT' :$translate.instant('financial.event.type.REMIT'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.VOID' :$translate.instant('financial.event.type.VOID'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.RETRO' :$translate.instant('financial.event.type.RETRO'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.UNHOLD_PAYMENT' :$translate.instant('financial.event.type.UNHOLD_PAYMENT'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.HOLD_PAYMENT' :$translate.instant('financial.event.type.HOLD_PAYMENT'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.REFUND' :$translate.instant('financial.event.type.REFUND'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.CREDIT' :$translate.instant('financial.event.type.CREDIT'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.WRITEON' :$translate.instant('financial.event.type.WRITEON'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.INVOICE_SETTLEMENT_REVERSAL' :$translate.instant('financial.event.type.INVOICE_SETTLEMENT_REVERSAL'),
    			'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.REFUND_PAYOUT' :$translate.instant('financial.event.type.REFUND_PAYOUT'),
                'com.hcentive.billing.wfm.api.enumeration.ft.FinancialEventType.MONEY_TRANSFER':$translate.instant('financial.event.type.MONEY_TRANSFER')
    	}
    	
    		function getAccountKeyByName(name,accountMap){
    			var result = null;
    			if(name){
	    			for(var a in accountMap){
	    				if(accountMap[a]===name){
	    					result = a;
	    					break;
	    				}
	    			}
    			}
    			return result;
    		}
    	
            return {
            	 getTransactionFilterConfiguration : function(preSelectedFilters){
    				var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("eventDate","daterange", "Transaction Date", {}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("coveragePeriod","daterange", "Coverage Period", {}, {}));
    				
    				defaultFiltersConfig.push(new WFMFilterConfiguration("entityId", "text", "Entity ID", {init:preSelectedFilters.externalId}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("subscription", "text", "Billing Account", {init:preSelectedFilters.subscription}, {}));
    				
    				var moreFiltersConfig = [];
    				moreFiltersConfig.push(new WFMFilterConfiguration("billingPeriod","daterange", "Billing Period", {}, {}));
    				
    				moreFiltersConfig.push(new WFMFilterConfiguration("businessTx","checkbox", "Event", {
						enableAll : true
						},financialEventTypes));
    				
    				moreFiltersConfig.push(new WFMFilterConfiguration("amount","range", "Amount", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("entityName", "text", "Entity Name", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("eventAdditionalId", "text", "Event ID", {init:preSelectedFilters.eventAdditionalId}, {}));
    				//moreFiltersConfig.push(new WFMFilterConfiguration("billCycleId", "text", "Billing Cycle ID", {init:preSelectedFilters.billCycleId}, {}));
    				
    				
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
    			},
    			
    			enrichTransactionFilterWithAccountFilter: function(filteConfig,preSelectedFilters,accountMap){
    				
    				var accountOptions = {};
    				
    				if(accountMap){
	    				if(preSelectedFilters.account){
	    					// pre select an account
	    					accountOptions.enableAll = true;
	    					accountOptions.init = [];
	    					var accountKey = getAccountKeyByName(preSelectedFilters.account,accountMap);
	    					if(accountKey){
	    						accountOptions.init.push(accountKey);
	    						console.log('initialized accountkey');
	    					}else{
	    						accountOptions.enableAll = true;
	    						console.log('account key not initialized.');
	    					}
	    				}else{
	    					// pre select all.
	    					accountOptions.enableAll = true;
	    				}
	    				
	    				filteConfig.defaultFiltersConfig.push(new WFMFilterConfiguration(
	    						"account", "checkbox", "Account", accountOptions, accountMap));
    				}
    				
    				return filteConfig;
    			},
    			
    			getOnHoldEventConfiguration  : function(pageType){
    				var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("onHoldDate","daterange", "Date", {}, {}));
    				/*defaultFiltersConfig.push(new WFMFilterConfiguration(
    						"status", "checkbox", "Status", {enableAll : true}, 
    								{
    									"ASSOCIATIONS_PENDING" :"On Hold"
	    							}));*/
    				if(pageType=='oneTimePaymentReceipt')
    					defaultFiltersConfig.push(new WFMFilterConfiguration("paymentId", "text", "Payment ID", {}, {}));
    				else if (pageType=='recurringPaymentReceipt')
    					defaultFiltersConfig.push(new WFMFilterConfiguration("recurringpaymentId", "text", "Payment ID", {}, {}));
    				else if(pageType=='tokenizePaymentReceipt')
    					defaultFiltersConfig.push(new WFMFilterConfiguration("tokenizepaymentId", "text", "Payment ID", {}, {}));
    				else if(pageType=='lockbox')
    					defaultFiltersConfig.push(new WFMFilterConfiguration("lockboxpaymentId", "text", "Payment ID", {}, {}));
    				else
    				defaultFiltersConfig.push(new WFMFilterConfiguration("transactionId", "text", "Transaction ID", {}, {}));
    				
    				var moreFiltersConfig = [];
    				//moreFiltersConfig.push(new WFMFilterConfiguration("eventType", "text", "Event", {}, {}));
    				
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
    			},
    			
    			getRejectedEventConfiguration : function(){
    				var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("rejectedDate","daterange", "Date", {}, {}));
    				//defaultFiltersConfig.push(new WFMFilterConfiguration("lockboxpaymentId", "text", "Payment ID", {}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("confirmationNumber", "text", "LockBox ConfirmationNumber", {}, {}));
    				
    				var moreFiltersConfig = [];
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
    			},
            
    			 getInvoiceFilterConfiguration : function(preSelectedFilters,beType){
    				var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("invoiceDate","daterange", "Bill Generation Date", {init:preSelectedFilters.invoiceDate}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("subscription", "text", "Billing Account", {init:preSelectedFilters.subscription}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("externalId", "text", "Invoice ID", {init:preSelectedFilters.externalId}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration(
    						"status", "checkbox", "Invoice Status", {
    							enableAll : true,
    							init : preSelectedFilters.status
    						}, {
    							OPEN:"Unpaid",
    							SETTLED : "Paid",
    							VOID : "Cancelled",
    							INITIATED : "Initiated",
    							PARTIAL_PAYMENT : "Partially Paid",
    							REVIEW : "In-Review",
    							REJECTED:"Rejected"
    						}));
    				
    				var moreFiltersConfig = [];
    				moreFiltersConfig.push(new WFMFilterConfiguration("billingPeriod","daterange", "Billing Period", {init:preSelectedFilters.billingPeriod}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("dueDate","daterange", "Due Date", {init:preSelectedFilters.dueDate}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("amount","range", "Amount", {init:preSelectedFilters.amount}, {}));
    				
    				var idDesc = '';
    				var nameDesc = '';
    				
    				if(beType == 'Group'){
    					idDesc ='Group ID' ;
    					nameDesc = 'Group Name';
    				}else if(beType=='Partner'){
    					idDesc = 'Partner ID';
    					nameDesc ='Partner Name' ;
    				}else{
    					idDesc = 'Subscriber ID';
    					nameDesc ='Subscriber Name' ;
    				}
    				
    				moreFiltersConfig.push(new WFMFilterConfiguration("beId","text", idDesc, {init:preSelectedFilters.beId}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("name","text", nameDesc, {init:preSelectedFilters.name}, {}));
    				
    				var invoiceTypeFilter = new WFMFilterConfiguration(
    						"invoiceType", "checkbox", "Invoice Type", {
    							enableAll : true,
    							init : preSelectedFilters.invoiceType
    						}, {
    							REGULAR:$translate.instant('REGULAR'),
    							BINDER : $translate.instant('BINDER')
    							//REINSTATEMENT : $translate.instant('REINSTATEMENT'),
    							//RUNOUT : $translate.instant('RUNOUT')
    						});
    				
    				moreFiltersConfig.push(invoiceTypeFilter);
    				
    				
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
    			},
    			getAccountFilterConfiguration : function(){
					var defaultFiltersConfig = [];
					defaultFiltersConfig.push(new WFMFilterConfiguration(
					"accountType", "checkbox", "Account Type", {
						enableAll : true
					}, {
						CR:"Credit",
						DR : "Debit"
					}));
					
					defaultFiltersConfig.push(new WFMFilterConfiguration("accountName", "text", "Account Name", {}, {}));
					
					var moreFiltersConfig = [];
					moreFiltersConfig.push(new WFMFilterConfiguration("totalSum","range", "Account Balance", {}, {}));
					moreFiltersConfig.push(new WFMFilterConfiguration("accountId","text", "Account No", {}, {}));
					
					return new WFMFIlterBoxConfiguration(
					defaultFiltersConfig, moreFiltersConfig);
				},
				getWriteOffFilterConfiguration : function(){
					var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("invoiceDate","daterange", "Write Off Date", {}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("writeOffId","text", "Write Off Id", {}, {}));
    				
    				var moreFiltersConfig = [];
    				moreFiltersConfig.push(new WFMFilterConfiguration("amount","range", "Amount", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("entityId","text", "Entity Id", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("entityName","text", "Entity Name", {}, {}));
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
				},
				
				getAdjustmentFilterConfiguration : function(preSelectedFilters,pageType){
					var defaultFiltersConfig = [];
					var id ='';
					var desc ='';
					if(pageType =='Refund'){
						desc = "Refund ID";
					}
					else if(pageType =='Write-Off'){
						desc = "Write Off ID";
					}
					else if(pageType=='Write-On'){
						desc = "Write On ID";
					}
					else if (pageType=='Credit'){
						desc = "Credit ID";
					}
					else if (pageType=='Money-Transfer'){
						desc = "Money Transfer ID";
					}
					id = "Effective Date";
					var initDateParam='Initiated Date';
    				defaultFiltersConfig.push(new WFMFilterConfiguration("effectiveDate","daterange", id, {}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("initDate","daterange", initDateParam, {}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("externalId","text", desc, {}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("entityId","text", "Entity ID", {init:preSelectedFilters.entityId}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("entityName","text", "Entity Name", {}, {}));
    				defaultFiltersConfig.push(new WFMFilterConfiguration("subscription","text", "Billing Account ID", {init:preSelectedFilters.subscription}, {}));

    				var moreFiltersConfig = [];

    				moreFiltersConfig.push(new WFMFilterConfiguration("amount","range", "Amount", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("status","checkbox", "Status", {
						enableAll : true
						},{
						INITIATED:"Initiated",
						SUCCESS:"Success",
						FAILED:"Failed",
						REJECTED:"Rejected",
						OVERDUE:"Overdue",
						VOID:"Void"
						}));
    				//moreFiltersConfig.push(new WFMFilterConfiguration("entityName","text", "Entity Name", {}, {}));
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
				},
					
				getAccountDetailsFilterConfiguration : function(preSelectedFilters){
					
					var defaultFiltersConfig = [];
					defaultFiltersConfig.push(new WFMFilterConfiguration("accountName","text", "Account Name", {init:preSelectedFilters.accountName}, {}));
					defaultFiltersConfig.push(new WFMFilterConfiguration("entityId","text", "Entity Id", {init:preSelectedFilters.entityId}, {}));
					defaultFiltersConfig.push(new WFMFilterConfiguration("subscription","text", "Billing Account", {init:preSelectedFilters.subscription}, {}));
					
					var moreFiltersConfig = [];
					moreFiltersConfig.push(new WFMFilterConfiguration("entityName","text", "Entity Name", {}, {}));
					
					moreFiltersConfig.push(new WFMFilterConfiguration(
    						"entityType", "checkbox", "Entity Type", {
    							enableAll : true
    						}, {
	   						    "Individual": "Individual",
							    "SubsidyProvider": "Subsidy Provider",
							    "Group": "Group",
							    "Broker": "Broker",
							    "HealthPlanProvider": "Health Plan Provider",
							    "Exchange": "Exchange",
							    "SuspenseEntity":"Suspense Entity",
							    "Client" : "Client"
    						}));
					return new WFMFIlterBoxConfiguration(defaultFiltersConfig, moreFiltersConfig);
				}
        	};
        	
            }
         ];
		 
    // wireup the service to application
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialsFilterConfigService",
        "id": hcentive.WFM.FinancialsFilterConfigService
    });
})();