(function () {
    hcentive.WFM.FinancialsRemitsFilterService = [function () {
            return {
            	 getRemitsFilterConfiguration : function(preSelectedFilters){
    				
            	 	var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("outstandingAmount","range", "Payable Amount", {}, {}));
    				if(preSelectedFilters.partnerId != undefined && preSelectedFilters.partnerId != null && preSelectedFilters.partnerId != '') {
    					defaultFiltersConfig.push(new WFMFilterConfiguration("partnerId", "text", "Partner ID", {init:preSelectedFilters.partnerId}, {}));
    				} else {
    					defaultFiltersConfig.push(new WFMFilterConfiguration("partnerId", "text", "Partner ID", {}, {}));
    				}
    				
    				var moreFiltersConfig = [];
    				moreFiltersConfig.push(new WFMFilterConfiguration("lastRemitAmount","range", "Last Remitted Amount", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("partnerName", "text", "Partner Name", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("ytdRemitAmount","range", "YTD Remit Amount", {}, {}));
    				
    				return new WFMFIlterBoxConfiguration(defaultFiltersConfig, moreFiltersConfig);
    			},
    			 getRefundsFilterConfiguration : function(preSelectedFilters){
     				
             	 	var defaultFiltersConfig = [];
             	 	defaultFiltersConfig.push(new WFMFilterConfiguration("refundDate","daterange", "Last Refund Date", {}, {}));
             	 	
             	 	defaultFiltersConfig.push(new WFMFilterConfiguration(
    						"partnerType", "checkbox", "Entity Type", {
    							enableAll : true
    						}, {
    							Individual:"Individual",
    							Group : "Group"
    						}));
             	 	//defaultFiltersConfig.push(new WFMFilterConfiguration("lastRemitAmount","range", "Last Refund Amount", {}, {}));
             	 	
     				//defaultFiltersConfig.push(new WFMFilterConfiguration("outstandingAmount","range", "Last Payable Amount", {}, {}));
     				
     				defaultFiltersConfig.push(new WFMFilterConfiguration("partnerId", "text", "Entity ID", {}, {}));
     				defaultFiltersConfig.push(new WFMFilterConfiguration("subscription", "text", "Billing Account", {}, {}));
     				
     				defaultFiltersConfig.push(new WFMFilterConfiguration("partnerName", "text", "Entity Name", {}, {}));
     				
     				/*if(preSelectedFilters.refundID != undefined && preSelectedFilters.refundID != null && preSelectedFilters.refundID != '') {
     					defaultFiltersConfig.push(new WFMFilterConfiguration("refundID", "text", "Entity ID", {init:preSelectedFilters.refundID}, {}));
     				} else {
     					defaultFiltersConfig.push(new WFMFilterConfiguration("refundID", "text", "Entity ID", {}, {}));
     				}*/
     				var moreFiltersConfig = [];
    				moreFiltersConfig.push(new WFMFilterConfiguration("lastRemitAmount","range", "Last Refund Amount", {}, {}));
    				//moreFiltersConfig.push(new WFMFilterConfiguration("partnerName", "text", "Entity Name", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("outstandingAmount","range", "Last Payable Amount", {}, {}));
     				
     				return new WFMFIlterBoxConfiguration(defaultFiltersConfig, moreFiltersConfig);
     			},
     			getRefundsDetailsFilterConfiguration : function(preSelectedFilters){
     				
             	 	var defaultFiltersConfig = [];
     				defaultFiltersConfig.push(new WFMFilterConfiguration("outstandingAmount","range", "Refund Amount", {}, {}));
     				defaultFiltersConfig.push(new WFMFilterConfiguration("amountCategory", "text", "Amount Type", {}, {}));
     				var moreFiltersConfig = null;
     				return new WFMFIlterBoxConfiguration(defaultFiltersConfig, moreFiltersConfig);
     			}
        	};
            }
         ];
		 
    // wireup the service to application
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialsRemitsFilterService",
        "id": hcentive.WFM.FinancialsRemitsFilterService
    });
})();