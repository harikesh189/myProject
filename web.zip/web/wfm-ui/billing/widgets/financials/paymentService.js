/**
 * Created by Dikshit.Vaid on 6/10/2014.
 */

	hcentive.WFM.FinancialPaymentService = ['$http', 'RESTSrvc', '$filter', function($http, RESTSrvc,$filter) {
	 	                            	
	 	                            	var getAllPaymentRecordsForAdmin = function(params, data, successCallback,errorCallback) {
	 	                            		RESTSrvc.postForData('getPaymentRecords', params, data ,null, successCallback,errorCallback);
	 	                            	};
										
										  var addPymentAdmin = function(params, data, successCallback,errorCallback) {
	 	                            		RESTSrvc.postForData('addPayment', params, data ,null, successCallback,errorCallback,'application/xml');
	 	                            	};
	 	                            	
	 	                            	var addPaymentReceipt = function(params, data, successCallback,errorCallback) {
	 	                            		RESTSrvc.postForData('addPaymentReceipt', params, data ,null, successCallback,errorCallback);
	 	                            	};
	 	                            	var voidPayment = function(params, data, successCallback,errorCallback){
											RESTSrvc.postForData('voidPayment',params,data,null,successCallback,errorCallback);
										}
	 	                            	var voidOutboundPayment = function(params, data, successCallback,errorCallback){
											RESTSrvc.postForData('voidOutBoundPayment',params,data,null,successCallback,errorCallback);
										}
	 	                            	
	 	                            	var getOutBoundPaymentDetails = function(params, data, successCallback,errorCallback){
											RESTSrvc.postForData('outBoundPaymentDetails',params,data,null,successCallback,errorCallback);
										}
	 	                            	
	 	                            	
										
	 	                            	return {
	 	                            		getAllPaymentRecordsForAdmin : getAllPaymentRecordsForAdmin,
											addPymentAdmin : addPymentAdmin,
											addPaymentReceipt : addPaymentReceipt,
											voidPayment : voidPayment,
											voidOutboundPayment : voidOutboundPayment,
											getOutBoundPaymentDetails : getOutBoundPaymentDetails
	 	                            	};
	 	                            } ];

	
    // wireup the service to application
   
    
 
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialPaymentService",
        "id": hcentive.WFM.FinancialPaymentService
    });
