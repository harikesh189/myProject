/**
 * Created by Amit.Ag on 19/11/2014.
 */

hcentive.WFM.FinancialRefundCtrl = [
			'$scope',
			'FinancialRemitsService',
			'EventBusSrvc',
			'FinancialsRemitsFilterService',
			'$location',
			'$filter',
			function($scope, financialsRemitsService, EventBusSrvc,FinancialsRemitsFilterService,$location,$filter) {
				$scope.customerRefunds ='';
				$scope.pagination = defaultPagination('partnerExternalId', 'ASC');
				
				$scope.refundStartTimestamp = null;
				$scope.refundDetails = function(refundId, refundIdentity, refundExternalId, refundName,subscription) {
					
				var refundCustomerDetails = {};
					refundCustomerDetails.refundId = refundId;
					refundCustomerDetails.subscription = subscription;
					refundCustomerDetails.refundIdentity = refundIdentity;
					refundCustomerDetails.refundExternalId = refundExternalId;
					refundCustomerDetails.refundName = refundName;
					refundCustomerDetails.refundStartTimestamp = $scope.refundStartTimestamp;
					
					EventBusSrvc.publish('refundCustomerDetails',refundCustomerDetails);
					$location.path("financials/refunds/refund-customers-details");
					$location.replace();
				};

//=========================================CUSTOMER REFUND LISTING SCREEN FILTER CODE STARTS.=======================================
				//var refundJSON = [{"refundId":"PARTYNEW3911430103","refundIdentity":"Q62-3T8U825E","refundExternalId":"ISS-001","refundName":"Tom's Bait","refundType":"INDIVIDUAL","lastRefundDate":null,"lastRefundAmount":"400","outstandingAmount":"11200.0"},{"refundId":"PARTYNEW1769040460","refundIdentity":"Q62-RR8U825E","refundExternalId":"ISS-001","refundName":"Tackle","refundType":"INDIVIDUAL","lastRefundDate":null,"lastRefundAmount":"200","outstandingAmount":"1001.0"}];
				var preSelectedFilters = {};
				var goToRelatedBeExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
				if(goToRelatedBeExternalId != undefined && goToRelatedBeExternalId != null && goToRelatedBeExternalId != ''){
					preSelectedFilters.partnerId =  goToRelatedBeExternalId;
				}
				$scope.filterBoxConfig = FinancialsRemitsFilterService.getRefundsFilterConfiguration(preSelectedFilters);
				
				$scope.exportHandler = function(filterData){
					console.log(filterData);
			     	var data = {};
			    	data.fileName = 'Refunds';
			    	$scope.$broadcast('exportEvent', data);
			    };
			    
			    $scope.handleSearch = function(filterData){
			     console.log("Handle Individual Search");
			     console.log(filterData);
			     $scope.handleChange(filterData);
			    };
			    
			    $scope.handleChange = function(filterData){
			     console.log(filterData);
			     $scope.customerRefundsFilter = JSON.parse(JSON.stringify(filterData));
			    };

       

            $scope.filterList = [ 
                {
					'filterKey' : 'refundDate',
					'filterType' : 'DateRange',
					'filterQueryKey' : ['dateFrom' ,'dateTo'],
					'filterValueWithQuote' : false
				},
				{
					'filterKey' : 'partnerType',
					'filterType' : 'StringList',
					'filterValueWithQuote' : true
				},
				{
					'filterKey' : 'lastRemitAmount',
					'filterType' : 'NumberRange'
				},
				{
					'filterKey' : 'outstandingAmount',
					'filterType' : 'NumberRange'
				},
				{
					'filterKey' : 'partnerId',
					'filterType' : 'String',
					'filterValueWithQuote' : false
				},
				{
					'filterKey' : 'subscription',
					'filterType' : 'String',
					'filterValueWithQuote' : false
				},
				{
					'filterKey' : 'partnerName',
					'filterType' : 'String',
					'filterValueWithQuote' : false
				}
			];

//==============================CUSTOMER REFUND LISTING SCREEN FILTER CODE ENDS.======================================

				$scope.customerRefundsTableFooter = [
			    {
		        'desc' : '',
		        'key' : '',
		        'calculationType' :'',
		        'contentType' : '',
		        'calculatedValue' :'',
		        'colSpan' : 3
		        },{
				'desc' : 'Grand Total:',
				'key' : '',
				'calculationType' :'',
				'contentType' : '',
				'calculatedValue' :'',
				'colSpan' : 1,
		        'style' : 'text-left'
				},{
				'desc' : '',
				'key' : 'lastRefundAmount',
				'calculationType' :'Sum',
				'contentType' : 'Currency',
				'calculatedValue' :'',
				'colSpan' : 1,
				'style' : 'text-left'
				},{
				'desc' : '',
				'key' : 'outstandingAmount',
				'calculationType' :'Sum',
				'contentType' : 'Currency',
				'calculatedValue' :'',
				'colSpan' : 1,
				'style' : 'text-left'
				}];
				
				$scope.refundTableHeaders = [ {
					'isSortable' : 'yes',
					'key' : 'refundId',
					'desc' : 'Entity ID',
					'contentType' : 'String'
				},
				{
					'isSortable' : 'yes',
					'key' : 'subscription',
					'desc' : 'Billing Account',
					'contentType' : 'String'
				},{
					'isSortable' : 'yes',
					'key' : 'entityName',
					'desc' : 'Entity Name',
					'contentType' : 'String'
				}, {
					'isSortable' : 'yes',
					'key' : 'entityType',
					'desc' : 'Entity Type',
					'contentType' : 'String'
				},{
					'isSortable' : 'yes',
					'key' : 'lastRefundDate',
					'desc' : 'Last Refund Date',
					'contentType' : 'Date'
				}, {
					'isSortable' : 'yes',
					'key' : 'lastRefundAmount',
					'desc' : 'Last Refund Amount',
					'contentType' : 'Currency'
				},{
					'isSortable' : 'yes',
					'key' : 'outstandingAmount',
					'desc' : 'Payable Amount',
					'contentType' : 'Currency'
				}, {
					'isSortable' : 'no',
					'key' : 'action',
					'desc' : 'Actions',
					'contentType' : 'html'
				} ];
				var successCallback = function(data) {
					
					$scope.customerRefunds = getFinancialRefundTransformer($scope,data);
					
					if ($scope.customerRefunds == ''
							|| $scope.customerRefunds == undefined) {
						$scope.customerRefunds = 'No Data';
					}
				};
				var errorCallBack = function(data) {
					$scope.customerRefunds = 'No Data';
					$scope.updateLeftNav('Remits');
				};
				$scope.fetchdata = function(paginationObj, filterObj) {
					$scope.updateLeftNav('Remits');
					$scope.pagination = paginationObj;
					var searchCriteriaJson = {};
					var searchCriteriaJson = populateSearchCriteria(filterObj);
					getAllRefunds(searchCriteriaJson);
				};
				
				var getAllRefunds = function(searchCriteriaJson) {
					financialsRemitsService.getAllRefunds(null,
							searchCriteriaJson, null, successCallback,
							errorCallBack);
				}

				function populateSearchCriteria(filterObj) {
					var searchCriteriaJson = {};
					if(Array.isArray(filterObj)){
						filterObj = {};
					}
					/*
					if(filterObj.dateTo!=undefined){
						filterObj.dateTo.columnValue = 	filterObj.dateTo.columnValue;
					}
					if(filterObj.dateFrom!=undefined){
						filterObj.dateFrom.columnValue = filterObj.dateFrom.columnValue;
					}
					*/
					searchCriteriaJson.criteria = filterObj;
					searchCriteriaJson.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
					
					/*searchCriteriaJson.criteria['remitStartTimestamp'] = {
							'operator' : '=',
							'columnValue' :  $scope.refundStartTimestamp 
						};*/
					return 	searchCriteriaJson;									;
				}
			} ];

/********************Refund details controller start here***************************************/ 

	hcentive.WFM.FinancialRefundDetailsCtrl = [
                        			'$scope',
                        			'NotifySrvc',
                        			'FinancialRemitsService',
                        			'EventBusSrvc',
                        			'FinancialsRemitsFilterService',
                        			'$location',
                        			'$log',
                        			'$filter',
                        			function($scope,NotifySrvc, financialsRemitsService, EventBusSrvc,FinancialsRemitsFilterService,$location,$log,$filter) {
                        				$scope.refundDetails ='';
                        				$scope.pagination = defaultPagination('', '');
                        				$scope.refundCustomerDetails = EventBusSrvc.subscribe('refundCustomerDetails');
                        				
        //=========================================CUSTOMER REFUND LISTING SCREEN FILTER CODE STARTS.=======================================
                        				var preSelectedFilters = {};
                        				
                        				$scope.filterBoxConfig = FinancialsRemitsFilterService.getRefundsDetailsFilterConfiguration(preSelectedFilters);
                        				
                        				$scope.exportHandler = function(filterData){
                        					console.log(filterData);
                        			     	var data = {};
                        			    	data.fileName = 'Refunds';
                        			    	$scope.$broadcast('exportEvent', data);
                        			    };
                        			    
                        			    $scope.handleSearch = function(filterData){
                        			    	
                        			     console.log("Handle Individual Search");
                        			     console.log(filterData);
                        			     $scope.handleChange(filterData);
                        			    };
                        			    
                        			    $scope.handleChange = function(filterData){
                        			     console.log(filterData);
                        			     $scope.refundDetailsFilter = JSON.parse(JSON.stringify(filterData));
                        			    };

                               
                        			    function populateSearchCriteria(filterObj) {
                        					var searchCriteriaJson = {};
                        					if(Array.isArray(filterObj)){
                        						filterObj = {};
                        					}
                        					searchCriteriaJson.criteria = filterObj;
                        					searchCriteriaJson.pageRequestCriteria = null;
                        					searchCriteriaJson.criteria['createdAt'] = {
                        						'operator' : '<=',
                        						'columnValue' :  $scope.refundCustomerDetails.refundStartTimestamp 
                        					};
                        					
                        					
                        					return 	searchCriteriaJson;									;
                        				}
                                    $scope.filterList = [ 
                                        {
                        					'filterKey' : 'outstandingAmount',
                        					'filterType' : 'NumberRange',
                        				}, 
                        				{
                        					'filterKey' : 'amountCategory',
                        					'filterType' : 'String',
                        					'filterValueWithQuote' : false
                        				} 
                        			];

                        //==============================CUSTOMER REFUND LISTING SCREEN FILTER CODE ENDS.======================================

                        				
                        				
                        				$scope.refundDetailsTableHeaders = [ {
                        					'isSortable' : 'yes',
                        					'key' : 'refundAmountType',
                        					'desc' : 'Amount Type',
                        					'contentType' : 'String'
                        				},{
                        					'isSortable' : 'yes',
                        					'key' : 'refundAmount',
                        					'desc' : 'Refund Amount',
                        					'contentType' : 'Currency'
                        				},{
                        					'isSortable' : '',
                        					'key' : '',
                        					'desc' : '',
                        					'contentType' : ''
                        				},{
                        					'isSortable' : 'no',
                        					'key' : 'action',
                        					'desc' : 'Actions',
                        					'contentType' : 'html'
                        				} ];
                        				var successCallback = function(data) {
                        					$scope.refundDetails = getFinancialRefundDetailsTransformer($scope,data);
                        					
                        					if ($scope.refundDetails == ''
                        							|| $scope.refundDetails == undefined) {
                        						$scope.refundDetails = 'No Data';
                        					}
                        				};
                        				var errorCallBack = function(data) {
                        					$scope.refundDetails = 'No Data';
                        					$scope.updateLeftNav('Remits');
                        				};
                        				$scope.fetchdata = function(paginationObj, filterObj) {
                        					
                        					$scope.updateLeftNav('Remits');
                        					$scope.pagination = paginationObj;
                        					var searchCriteriaJson = {};
                        					var searchCriteriaJson = populateSearchCriteria(filterObj);
                        					
                        					var param = {customerId:$scope.refundCustomerDetails.refundIdentity};
                        					financialsRemitsService.getCustomerRefunds(param,
                        							searchCriteriaJson, null, successCallback,
                        							errorCallBack);
                        				};
                        				
        				$scope.getAssociatedAdj =  function(category){
        					
        					$scope.refundCustomerDetails.category = category;
        					EventBusSrvc.publish('refundCustomerDetails',$scope.refundCustomerDetails);
        					$location.path('financials/manual-adjustments/refunds-payments/');
        					$location.replace();
        				}
                        				
        				
                        $scope.confirmRefund =  function(amountCategory , refundAmount){
                        	$scope.formData = {entityID:$scope.refundCustomerDetails.refundId,entityName:$scope.refundCustomerDetails.refundName,amountCategory:amountCategory,refundAmount:refundAmount,subscription:$scope.refundCustomerDetails.subscription};
                        	$scope.form = {payeeBillingAccount:$scope.refundCustomerDetails.subscription,outstandingAmount:refundAmount,amountCategory:amountCategory,createdAt:$scope.refundCustomerDetails.refundStartTimestamp};
                        	
                        	NotifySrvc({
                				id : 'simpleDialog',
                				controller : 'FinancialRefundDetailsCtrl',
                				scope : $scope,
                				template: '<div >' 
                	                +'<div class="rowMargin"></div>'
                	                +'<div class="rowMargin">'
                	                + ' <label class="control-label width200px" for="accountName">Entity ID:</label>'
                	                  +'<div class="controls width150"> {{refundCustomerDetails.refundId}} </div>'
                	               + '</div>'
                	               + '<div class="rowMargin">'
                	                 + '<label class="control-label width200px" for="accountName">Entity Name:</label>'
                	                 + '<div class="controls width150"> {{refundCustomerDetails.refundName}} </div>'
                	                +'</div>'
                	                + '<div class="rowMargin">'
               	                 		+ '<label class="control-label width200px" for="accountName">Billing Account</label>'
               	                 		+ '<div class="controls width150"> {{refundCustomerDetails.subscription}} </div>'
               	                 	+'</div>'  
                	              + '<div class="rowMargin">'
                	                  +'<label class="control-label width200px" for="accountNo">Refund Amount:</label>'
                	                  +'<div class="controls width150"> <span class="amountToBeRemitted">{{form.outstandingAmount|number:2}}</span></div>'
                	               +'</div></div>',
                	              
                				title : 'Refund Confirmation',
                				backdrop : true,
                				closeButton : true,
                				cancel :{
                					label : 'Cancel',
                					fn : function() {}
                					},
                				success : {
                    					label : 'Confirm',
                    					fn : function() {
                    						var param = {customerId:$scope.refundCustomerDetails.refundIdentity};
                    						financialsRemitsService.saveRefunds(param,
                    								$scope.form, null,function (success) {
                    							        $log.debug(success);
                    							        if (success.errors != undefined) {			        			        							     				        	
                    							            console.log("inside ");
                    							        } else {		             		          							           
                    							        	$scope.saveSuccessDialog();
                    							        	
                    							        }
                    							    }, function (error) {						     
                    							        console.log("inside save rule function 4");
                    							    });
                    					}
                    				}
                				
                			});
                        	
                        };			
                  
                        $scope.saveSuccessDialog = function(){
                        	NotifySrvc({
                				id : 'simpleDialog',
                				template: '<div >' 
                	                +'<div class="rowMargin"></div>'
                	                +'<div class="rowMargin">'
                	                + '<label> Your Refund will be processed shortly!</label>'
                	                +'</div></div>',
                	              
                				title : 'Refund Successful',
                				backdrop : true,
                				closeButton : true,
                				success : {
                    					label : 'Close',
                    					fn : function() {
                    						$location.path("financials/refunds/refund-customers");
                    						$location.replace();
                    					}
                    				}
                				
                			});
                        	
                        	}

                        				
                        			} ];



hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		'name' : 'FinancialRefundCtrl',
		'id' : hcentive.WFM.FinancialRefundCtrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'FinancialRefundDetailsCtrl',
	'id' : hcentive.WFM.FinancialRefundDetailsCtrl
});

