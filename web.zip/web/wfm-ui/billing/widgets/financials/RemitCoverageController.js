hcentive.WFM.RemitCoverageController = [
		'$scope',
		'FinancialRemitsService',
		'EventBusSrvc',
		'NotifySrvc',
		'$filter',
		function($scope, financialsRemitsService, EventBusSrvc, NotifySrvc, $filter) {
			
		$scope.coverageFilterDisplayStyle = 'none';
		$scope.selectedCoveragePeriodDisplay = 'All';
		$scope.numberOfSelectedCoveragePeriods = 0;
		$scope.totalNumberOfRecords;
		$scope.allCoveragePeriodsSelected = true;
		$scope.excludedBeIds = new Array();
		$scope.beMap = new Object();
		$scope.isExclusionMap = true;
		$scope.isIssuerAssignedFilter = false;
		
		$scope.changeNonIssuerAssignedRecords = function(excludeNonIssuerAssignedRecords){
			$scope.isIssuerAssignedFilter = excludeNonIssuerAssignedRecords;
			$scope.selectedIndexList = [];
			$scope.getSubscribersOnCoverageBasis(excludeNonIssuerAssignedRecords);
		}
		
		$scope.updateCoverageDisplayForChangeNonIssuerAssignedRecords = function(){
			if($scope.coveragePeriods.length == 0){
				$scope.selectedCoveragePeriodDisplay = 'None';
				$scope.allCoveragePeriodsSelected = false;	
			}else{
				$scope.selectedCoveragePeriodDisplay = 'All';
				$scope.allCoveragePeriodsSelected = true;	
			}
		}
		
		$scope.resetToDefault = function(){
			$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalPayableAmount;
			$scope.coverageFilterDisplayStyle = 'none';
			$scope.selectedCoveragePeriodDisplay = 'All';
			$scope.numberOfSelectedCoveragePeriods = 0;
			$scope.allCoveragePeriodsSelected = true;
			$scope.excludedBeIds = new Array();
			$scope.beMap = new Object();
			$scope.selectionInfo_0 = 'AllSelected';
			$scope.isExclusionMap = true;
			$scope.isIssuerAssignedFilter = false;
			$scope.excludeNonIssuerAssignedRecords = false;
			$scope.numberOfSelectedEntities = 0;
			$scope.numberOfTotalSelectedEntities = 0;
			$scope.selectedIndex = -1;
			$scope.selectedIndexList = [];
			if($scope.coveragePeriodsPayableAmountArray){
				for(var i=0;i<$scope.coveragePeriodsPayableAmountArray.length;i++){
					$scope.coveragePeriodsSelectedAmountArray[i]=  parseFloat($scope.coveragePeriodsPayableAmountArray[i]);
					$scope['coveragePagination_'+i] = defaultPagination('"exchangeEntityId"','');
				}
			}
		}
		
		
		$scope.doRemitCoverage = function(){
			for(var i=0; i< $scope.selectedCoveragePeriodsIndex.length; i++){
				var key =  ($scope.coveragePeriods[i] === null) ? '--' : $scope.coveragePeriods[i].beginsOn.date+'-' + $scope.coveragePeriods[i].endsOn.date;
				if(!$scope.selectedCoveragePeriodsIndex[i]){
					delete $scope.beMap[key];
					delete $scope.beMap[key+'_IS_BE_EXCLUSION_LIST'];
				}
				else{
					if($scope.beMap[key] == undefined){
						$scope.beMap[key] = new Object();
						$scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] = true;
					}
					
				}
				
			}
			$scope.doRemit($scope.beMap,'COVERAGE');
		}
		
		
		$scope.resetCurrentTableSelectionMap = function(remitAnyRecord,tableIndex){
			if(remitAnyRecord){
				$scope['selectionInfo_'+tableIndex] = 'AllSelected';
			}else{
				$scope['selectionInfo_'+tableIndex] = 'NotAllSelected';
			}
			
			resetCheckBoxesSelectionForResetCurrentTableSelectionMap(remitAnyRecord,$scope.beMap);
			if($scope.coveragePeriods[$scope.selectedIndex] != null && $scope.coveragePeriods[$scope.selectedIndex] != undefined){
				var key = $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-'+$scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
				}
			var map = new Object();
			$scope.beMap[key] = map;
			if(!remitAnyRecord)
			{
				$scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] = false;
				$scope.numberOfSelectedEntities = 0;
				$scope.numberOfTotalSelectedEntities = 0;
				$scope.isExclusionMap = false;
			}
			else
			{
				$scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] = true;
				$scope.numberOfSelectedEntities = $scope.subscribersListOnCoverageBasis.length;
				$scope.numberOfTotalSelectedEntities = $scope['coveragePagination_'+$scope.selectedIndex].totalElements;
				$scope.isExclusionMap = true;
			}
			publishCheckBoxEvent('selectAllFromHeader',remitAnyRecord);
		}
		
		
		$scope.initializeCoverageExclusionMap = function(allCoverageSelected){
			$scope.numberOfSelectedCoveragePeriods = $scope.coveragePeriods.length;
			$scope.beMap = new Object();
		}
		
		$scope.changeSelectedCoveragePeriodDisplay = function(index){
			if(index == -1)
			{
				//$scope.beMap = new Object();
				if($scope.allCoveragePeriodsSelected == true){
					$scope.allCoveragePeriodsSelected = false;
					$scope.numberOfSelectedCoveragePeriods = 0;
				}
				else{
					$scope.allCoveragePeriodsSelected = true;
					$scope.numberOfSelectedCoveragePeriods = $scope.coveragePeriods.length;
				}
				$scope.partnerDetails.totalSelectedAmount = 0;		
				if($scope.allCoveragePeriodsSelected == true){
					//$scope.initializeCoverageExclusionMap(true);
					for(var i = 0; i < $scope.coveragePeriods.length ; i++)
					{ 
						$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount + parseFloat($scope.coveragePeriodsAmountArray[i]);
						$scope.selectedCoveragePeriodsIndex[i] = true;
//						$scope.resetCurrentTableSelectionMap(true,i);
					}
					$scope.totalSelectedCoveragePeriods = $scope.coveragePeriods.length;
					$scope.selectedCoveragePeriodDisplay = 'All';
				}
				else
				{
					//$scope.initializeCoverageExclusionMap(false);
					for(var i = 0; i < $scope.coveragePeriods.length ; i++)
					{
						$scope.selectedCoveragePeriodsIndex[i] = false;
//						$scope.resetCurrentTableSelectionMap(false,i);
					}
					$scope.totalSelectedCoveragePeriods = 0;
					$scope.selectedCoveragePeriodDisplay = 'None';
				}
			}
			else
			{
				if($scope.allCoveragePeriodsSelected == true){
					$scope.allCoveragePeriodsSelected = false;
				}
				$scope.changeSelectedCoveragePeriods(index);
				var coveragePeriod = $scope.coveragePeriods[index];
				var startDate = (coveragePeriod == null || coveragePeriod.beginsOn == null) ? '' : $filter('date')(coveragePeriod.beginsOn.date,$scope.clientDateFormat);
				var endDate =  (coveragePeriod == null || coveragePeriod.endsOn == null) ? '' : $filter('date')(coveragePeriod.endsOn.date,$scope.clientDateFormat);
				if($scope.totalSelectedCoveragePeriods == $scope.coveragePeriods.length)
					$scope.selectedCoveragePeriodDisplay = 'All';
				else if($scope.totalSelectedCoveragePeriods == 1){
					
					for(var i = 0; i < $scope.coveragePeriods.length ; i++)
					{
						if($scope.selectedCoveragePeriodsIndex[i]){
							var selectedCvgPeriod = $scope.coveragePeriods[i];
							startDate = (selectedCvgPeriod == null || selectedCvgPeriod.beginsOn == null) ? '' : $scope.toUTCDate(selectedCvgPeriod.beginsOn.date);
							endDate =  (selectedCvgPeriod == null || selectedCvgPeriod.endsOn == null) ? '' : $scope.toUTCDate(selectedCvgPeriod.endsOn.date);
						}
					}
					
					$scope.selectedCoveragePeriodDisplay = startDate + ' - ' + endDate;
					if($scope.selectedCoveragePeriodDisplay == ' - '){
						$scope.selectedCoveragePeriodDisplay='NA';
					}
				}
				else if($scope.totalSelectedCoveragePeriods == 0)
					$scope.selectedCoveragePeriodDisplay = 'None';
				else{
					$scope.selectedCoveragePeriodDisplay = 'Multiple';
				}
				var key = ($scope.coveragePeriods[index] === null) ? '--' : $scope.coveragePeriods[index].beginsOn.date+'-' + $scope.coveragePeriods[index].endsOn.date;
				if($scope.selectedCoveragePeriodsIndex[index] == true)
				{
					$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount + parseFloat($scope.coveragePeriodsSelectedAmountArray[index]);
				}
				else
				{
					$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount - parseFloat($scope.coveragePeriodsSelectedAmountArray[index]);
				}
			}
			
			
		}

		$scope.updateSubscriberAmount = function(rowIndex,isSelected,y)
		{
			
			var key = ($scope.coveragePeriods[$scope.selectedIndex] === null || $scope.coveragePeriods[$scope.selectedIndex] === undefined)?'--':$scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-'+$scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
			var beId = $scope.subscribersListOnCoverageBasis[rowIndex].businessEntityIdentity;
			$scope.subscribersListOnCoverageBasis[rowIndex].isChecked = isSelected;
			
			if($scope.beMap[key] == undefined){
				var coverageMap = new Object();
				$scope.beMap[key] = coverageMap;
				$scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] = true;
			}
			
			if(!isSelected){
				$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities - 1;
				$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities - 1;
				$scope.selectAllFromHeader = false;
				$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount - parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount);
				$scope.coveragePeriodsAmountArray[$scope.selectedIndex] = parseFloat($scope.coveragePeriodsAmountArray[$scope.selectedIndex]) - $scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount;
				
				
				$scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex] = parseFloat($scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]) - parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount);
				$scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount = 0;
			}
			
			else{
				$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities + 1;
				$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities + parseFloat(1);
				$scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex] = parseFloat($scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]) - parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount) + parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].payableAmount);
				
				$scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount = $scope.subscribersListOnCoverageBasis[rowIndex].payableAmount;
				$scope.coveragePeriodsAmountArray[$scope.selectedIndex] = parseFloat($scope.coveragePeriodsAmountArray[$scope.selectedIndex]) + parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount);
				
				$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount + parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount);
			}
			
			updateSelectionInfoMessage();
			
			if((!isSelected && $scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] == true) || (isSelected && $scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] == false)) //unchecked any entity.
			{
				// any beId is unselected completly.
					var beMap =  $scope.beMap[key];
					if(beMap == undefined)
						beMap = new Object();
					
					beMap[beId + '_IS_FT_EXCLUSION_LIST'] = !($scope.beMap[key+'_IS_BE_EXCLUSION_LIST']);
					beMap[beId] = new Array();
					
					$scope.beMap[key] = beMap;
			}
			else //checked any entity
			{
					delete $scope.beMap[key][beId];
					delete $scope.beMap[key][beId + '_IS_FT_EXCLUSION_LIST'];
					delete $scope.beMap[key][beId + '_TOTAL_SELECTED_COUNT'];
					/*if(Object.keys($scope.beMap[key]).length == 0){
						delete $scope.beMap[key];
						delete $scope.beMap[key+'_IS_BE_EXCLUSION_LIST'];
					}*/
			}
			if($scope.numberOfSelectedEntities == $scope.subscribersListOnCoverageBasis.length)
			{
				$scope.selectAllFromHeader = true;
			}else{
				$scope.selectAllFromHeader = false;
			}
		
			publishCheckBoxEvent('selectAllFromHeader',$scope.selectAllFromHeader);
			updateSelectionInfoMessage();
		}
		
		var updateSelectionInfoMessage = function(){
			if($scope.numberOfTotalSelectedEntities == $scope['coveragePagination_'+$scope.selectedIndex].totalElements){
				$scope['selectionInfo_'+$scope.selectedIndex] = 'AllSelected';
			}else{
				$scope['selectionInfo_'+$scope.selectedIndex] = 'NotAllSelected';
			}
		}
		
		
		$scope.selectAllFromHeaderFn = function(selectAllFromHeader){
			var tempBeMap = JSON.parse(JSON.stringify($scope.beMap));
			if($scope.coveragePeriods[$scope.selectedIndex] != null && $scope.coveragePeriods[$scope.selectedIndex] != undefined){
			var key = $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-'+$scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
			}else{
			var key='--';
			}
			if($scope.beMap[key] == undefined){
				$scope.beMap[key] =  new Object();
			}
			
			for(var rowIndex=0; rowIndex < $scope.subscribersListOnCoverageBasis.length; rowIndex++){
				var beId = $scope.subscribersListOnCoverageBasis[rowIndex].businessEntityIdentity;
				if((selectAllFromHeader && !$scope.isExclusionMap) || (!selectAllFromHeader && $scope.isExclusionMap)){
					//add to map
					$scope.beMap[key][beId] = new Array();
					if(selectAllFromHeader)
						$scope.beMap[key][beId + '_IS_FT_EXCLUSION_LIST'] = true;
					else
						$scope.beMap[key][beId + '_IS_FT_EXCLUSION_LIST'] = false;
				}
				else{
					//delete from map
					delete $scope.beMap[key][beId];
					delete $scope.beMap[key][beId + '_TOTAL_SELECTED_AMOUNT'];
					delete $scope.beMap[key][beId + '_TOTAL_SELECTED_COUNT'];
					delete $scope.beMap[key][beId + '_IS_FT_EXCLUSION_LIST'];
//					if(Object.keys($scope.beMap[key]).length == 0){
//						delete $scope.beMap[key];
//						delete $scope.beMap[key+'_IS_BE_EXCLUSION_LIST'];
//					}
				}
			}
			
			if(selectAllFromHeader){
				$scope.numberOfSelectedEntities = $scope.subscribersListOnCoverageBasis.length;
			}
			else{
				$scope.numberOfSelectedEntities = 0;
			}
			
			resetCheckBoxesSelectionForSelectAllFromHeaderFn(selectAllFromHeader,tempBeMap);
			
			updateSelectionInfoMessage();
		}
		
		
		var resetCheckBoxesSelectionForResetCurrentTableSelectionMap = function(selectAll,tempBeMap){
			var coverageSelectedAmount = parseFloat($scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]);
			var coveragePayableAmount = parseFloat($scope.coveragePeriodsPayableAmountArray[$scope.selectedIndex]);
			
			if(!selectAll){
				$scope.partnerDetails.totalSelectedAmount = parseFloat($scope.partnerDetails.totalSelectedAmount)  - coverageSelectedAmount;
				$scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex] = 0;
			}else{
				$scope.partnerDetails.totalSelectedAmount = parseFloat($scope.partnerDetails.totalSelectedAmount)  + coveragePayableAmount - coverageSelectedAmount;
				$scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex] = coveragePayableAmount;
			}
			
			var checkBoxEventArray = [];
			for(var rowIndex=0 ; rowIndex < $scope.subscribersListOnCoverageBasis.length; rowIndex++){
				var beId = $scope.subscribersListOnCoverageBasis[rowIndex].businessEntityIdentity;
				if($scope.coveragePeriods[$scope.selectedIndex] != null && $scope.coveragePeriods[$scope.selectedIndex] != undefined){
				var key = $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-'+$scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
				}
				else{
					var key ='--';
				}
				$scope.subscribersListOnCoverageBasis[rowIndex].isChecked = selectAll;
				checkBoxEventArray = prepareCheckBoxEventArray('SubscriberRemit_'+key.split("-")[0]+'_'+rowIndex,selectAll,checkBoxEventArray);
				if(!selectAll){
					$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities - 1;
					$scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount = 0;
				}
				else{
					var previousSelectedAmount = $scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount; 
					$scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount = parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].payableAmount);
					$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities + parseFloat(1); 
				}
			}
			publishCheckBoxEventArray(checkBoxEventArray);
		}
		
		var resetCheckBoxesSelectionForSelectAllFromHeaderFn = function(selectAll,tempBeMap)
		{
			var checkBoxEventArray = [];
			for(var rowIndex=0 ; rowIndex < $scope.subscribersListOnCoverageBasis.length; rowIndex++){
				
				var beId = $scope.subscribersListOnCoverageBasis[rowIndex].businessEntityIdentity;
				if($scope.coveragePeriods[$scope.selectedIndex] != null && $scope.coveragePeriods[$scope.selectedIndex] != undefined){
				var key = $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-'+$scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
				}else{
				var key = '--';
				}
				var subscriberSelectedAmount = parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount);
				var subscriberPayableAmount = 	parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].payableAmount);
				
				$scope.subscribersListOnCoverageBasis[rowIndex].isChecked = selectAll;
				checkBoxEventArray = prepareCheckBoxEventArray('SubscriberRemit_'+key.split("-")[0]+'_'+rowIndex,selectAll,checkBoxEventArray);				
				if(!selectAll){
					$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount  - subscriberSelectedAmount;
					$scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]  = $scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]  - subscriberSelectedAmount;
					$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities - 1;
					$scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount = 0;
				}else{
					$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount  + subscriberPayableAmount - subscriberSelectedAmount;
					$scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]  = $scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]   + subscriberPayableAmount - subscriberSelectedAmount;
					$scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount = subscriberPayableAmount;
					$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities + parseFloat(1); 
				}
				
			}
			publishCheckBoxEventArray(checkBoxEventArray);
		}
		
		
		
		$scope.changeSelectedCoveragePeriods = function(index)
		{
			if($scope.selectedCoveragePeriodsIndex[index] == true){
				$scope.selectedCoveragePeriodsIndex[index] = false;
				$scope.totalSelectedCoveragePeriods = $scope.totalSelectedCoveragePeriods - 1;
			}
			else{
				$scope.selectedCoveragePeriodsIndex[index] = true;
				$scope.totalSelectedCoveragePeriods = $scope.totalSelectedCoveragePeriods + 1;
			}
			if($scope.totalSelectedCoveragePeriods == $scope.coveragePeriods.length)
			{
				$scope.allCoveragePeriodsSelected = true;
				$scope.selectedCoveragePeriodDisplay = 'All';
			}
		}
		
		
		$scope.remitSubscriberCoverageBasisTableHeaders = [ {
					'isSortable' : 'no',
					'key' : 'selectSubscriber',
					'desc' : '',
					'contentType' : 'html',
					'value' : '<input type="checkbox" ng-init ="selectAllFromHeader=true" ng-model="selectAllFromHeader" name="selectAllFromHeader" id="selectAllFromHeader" ng-change="selectAllFromHeaderFn(selectAllFromHeader)">'
				}, {
					'isSortable' : 'yes',
					'key' : 'exchangeEntityId',
					'desc' : 'Exchange Entity ID',
					'contentType' : 'String',
					'sortableKey' : '"exchangeEntityId"'
				}, {
					'isSortable' : 'yes',
					'key' : 'issuerEntityId',
					'desc' : 'Issuer Entity ID',
					'contentType' : 'String',
					'sortableKey' : '"issuerEntityId"'
				}, {
					'isSortable' : 'yes',
					'key' : 'businessEntityName',
					'desc' : 'Entity Name',
					'contentType' : 'String',
					'sortableKey' : '"businessEntityName"'
				}, {
					'isSortable' : 'yes',
					'key' : 'businessEntityType',
					'desc' : 'Entity Type',
					'contentType' : 'String',
					'sortableKey' : '"businessEntityType"'
				}, {
					'isSortable' : 'yes',
					'key' : 'payableAmount',
					'desc' : 'Payable Amount',
					'contentType' : 'Currency',
					'sortableKey' : '"outstandingAmount"'
				}, {
					'isSortable' : 'no',
					'key' : 'selectedAmount',
					'desc' : 'Selected Amount',
					'contentType' : 'Currency'
				} , {
					'isSortable' : 'no',
					'key' : 'detailAction',
					'desc' : '',
					'contentType' : 'html'
				}];
		
		var updateBeIdTableCheckBoxes = function(){
			var key = $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-' + $scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
			var selectedCoveragePeriodMap = $scope.beMap[key];
			if(selectedCoveragePeriodMap == undefined)
				return;
			var isExclusionList = $scope.beMap[key+'_IS_BE_EXCLUSION_LIST'];
			var checkBoxEventArray = [];
			for(var i = 0; i < $scope.subscribersListOnCoverageBasis.length; i++){
				var beId = $scope.subscribersListOnCoverageBasis[i].businessEntityIdentity;
				var shouldBeChecked = true;
				if((isExclusionList && selectedCoveragePeriodMap[beId] != undefined) || (!isExclusionList && selectedCoveragePeriodMap[beId] == undefined)){
					shouldBeChecked = false;
					$scope.subscribersListOnCoverageBasis[i].selectedAmount = 0;
				}
				else{
					$scope.subscribersListOnCoverageBasis[i].selectedAmount = $scope.subscribersListOnCoverageBasis[i].payableAmount;
				}
				checkBoxEventArray = prepareCheckBoxEventArray('SubscriberRemit_'+key.split("-")[0]+'_'+i,shouldBeChecked,checkBoxEventArray);
			}
			publishCheckBoxEventArray(checkBoxEventArray);
		}
		
		
		var populateCoveragePeriodTableSuccessCallback = function(data){
			if (data != null && data != undefined) 
			{
				if(data.content.length == 0)
				{
					$scope.subscribersListOnCoverageBasis = 'No Data';
					$scope.numberOfSelectedEntities = 0;
				}
				else
				{
					$scope['coveragePagination_'+$scope.selectedIndex].totalElements = data.totalElements;
					$scope['coveragePagination_'+$scope.selectedIndex].totalNoPages = data.totalPages;
					$scope.totalNumberOfRecords = data.totalElements;
					var key = ($scope.coveragePeriods[$scope.selectedIndex] === null) ? '--' : $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-' + $scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
					var beMap = $scope.beMap;
					var subscribersListOnCoverageBasisObject = coveragePeriodTableTransformer(data.content,key,beMap);
					$scope.subscribersListOnCoverageBasis = subscribersListOnCoverageBasisObject.subscribersListOnCoverageBasis;
					$scope.isExclusionMap = subscribersListOnCoverageBasisObject.isExclusionMap;
					
					if($scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] === undefined && $scope.isExclusionMap !== undefined){
						$scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] = $scope.isExclusionMap; 	
					}
					
					var checkBoxEventArray = [];
					for(var j=0;j<subscribersListOnCoverageBasisObject.checkBoxArray.length;j++){
						checkBoxEventArray = prepareCheckBoxEventArray('SubscriberRemit_'+key.split("-")[0]+'_'+j,subscribersListOnCoverageBasisObject.checkBoxArray[j],checkBoxEventArray);
					}
					
					if(subscribersListOnCoverageBasisObject.numberOfSelectedEntitiesOnPage == data.numberOfElements){
						checkBoxEventArray = prepareCheckBoxEventArray('selectAllFromHeader',true,checkBoxEventArray);
					}
					else{
						checkBoxEventArray = prepareCheckBoxEventArray('selectAllFromHeader',false,checkBoxEventArray);
					}
					$scope.numberOfSelectedEntities = subscribersListOnCoverageBasisObject.numberOfSelectedEntitiesOnPage;
					publishCheckBoxEventArray(checkBoxEventArray);
				}
			}
			else
			{
				$scope.subscribersListOnCoverageBasis = 'No Data';
				$scope.numberOfSelectedEntities = 0;
			}
		}
		
		var populateCoveragePeriodTableErrorCallBack = function(data){
			$scope.subscribersListOnCoverageBasis = 'No Data';
		}
		
		$scope.selectedIndex = -1;
		$scope.selectedIndexList = [];
		
		$scope.populateCoveragePeriodTables = function(coveragePeriodIndex,startDate,endDate){
			
			var index = $scope.selectedIndexList.indexOf(coveragePeriodIndex);
			if(index != -1)
			{
				$scope.selectedIndexList.splice(index, 1);
				return;
			}
			else
			{
				$scope.selectedIndex = coveragePeriodIndex;
				$scope.selectedIndexList = [];
				$scope.selectedIndexList.push(coveragePeriodIndex);
			}

			if($scope['coveragePagination_'+$scope.selectedIndex] == undefined){
				$scope['coveragePagination_'+$scope.selectedIndex] = defaultPagination('"exchangeEntityId"', '');
			}
			
			$scope.selectedCoveragePeriod = {};
			$scope.selectedCoveragePeriod.beginsOn = startDate;
			$scope.selectedCoveragePeriod.endsOn = endDate;
			EventBusSrvc.publish('selectedCoveragePeriod', $scope.selectedCoveragePeriod);
			
			getBusinessEntitiesCoverageBasis();
			
		}
		
		var getBusinessEntitiesCoverageBasis = function(){
			
			var params = {"partnerId" : $scope.partnerDetails.partnerIdentity};
			
			
			
			var searchCriteriaJson = {
				'criteria' : populateSearchCriteria(),
				'pageRequestCriteria' : getPageRequestCriteria($scope['coveragePagination_'+$scope.selectedIndex]),
				'referenceId' : null
			};
			
			financialsRemitsService.getAllSubscribersForPartner(params,searchCriteriaJson, 
			populateCoveragePeriodTableSuccessCallback,populateCoveragePeriodTableErrorCallBack);
			
		}
		
		
			$scope.fetchdata = function(paginationObj) {
				$scope['coveragePagination_'+$scope.selectedIndex] = paginationObj;
				getBusinessEntitiesCoverageBasis();
			}
		
		//details popup code.

		var populateSearchCriteria = function(){
		
			var coveragePeriod = $scope.coveragePeriods[$scope.selectedIndex];
		
			var startDate = '';
			var endDate = '';
			
			if(!(coveragePeriod === '' || coveragePeriod === undefined)){
				if(coveragePeriod !== null){
					startDate = (coveragePeriod.beginsOn.date);
					endDate = (coveragePeriod.endsOn.date);
				}else{
					startDate = 'NA';
					endDate = 'NA';
				}
			}
		
			var criteria = {};
			var createdAtFilter = {};
			createdAtFilter.columnValue = $scope.partnerDetails.remitStartTimestamp;
			createdAtFilter.caseSensitiveSearch = "false"; 
			createdAtFilter.operator = "<=";
			criteria.createdAt = createdAtFilter;
			
			var coverageFromFilter = {};
			coverageFromFilter.columnValue = startDate;
			coverageFromFilter.caseSensitiveSearch = "false"; 
			coverageFromFilter.operator = "=";
			criteria.coverageFrom = coverageFromFilter;
			
			var coverageToFilter = {};
			coverageToFilter.columnValue = endDate;
			coverageToFilter.caseSensitiveSearch = "false"; 
			coverageToFilter.operator = "=";
			criteria.coverageTo = coverageToFilter;

			if($scope.isIssuerAssignedFilter){
				var issuerEntityIdFilter = {};
				issuerEntityIdFilter.columnValue = " IS NOT NULL ";
				issuerEntityIdFilter.caseSensitiveSearch = "false"; 
				issuerEntityIdFilter.operator = "=";
				criteria.issuerEntityId = issuerEntityIdFilter;
			}
			return criteria;
		}
		
		
		var launchSubscriberDetailPopup = function(exchangeEntityId,rowIndex) {
				NotifySrvc({
					id : 'simpleDialog',
					templateUrl : 'views/financials/remit-subscriber-coverage-basis-details.html',
					title : exchangeEntityId,
					backdrop : true,
					closeButton : true,
					controller : 'RemitCoverageDetailController',
					css : {
						'top' : '5%',
						'left' : '15%',
						'margin' : '0 auto',
						'width' : '1000'
					},
					success : {
						label : 'Blank',
						fn : function() {
							$scope.updateSubscriberDetails(
									this.totalSelectedAmount,
									this.tempExcludedList,
									this.subscriberDetails.businessEntityIdentity,
									this.ftExclusionMapFlagBe,
									this.isCancelled,
									rowIndex,this.totalNumberOfRecordsSelected)
						}
					}
				});
			}

			$scope.updateSubscriberDetails = function(totalIssuerSelectedAmount, ftList, beId, exclusionFlag, isCancelled, rowIndex,totalNumberOfRecordsSelected) 
			{
				var previousSelectedAmount = $scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount;
				if(isCancelled)
					return;

				var key = ($scope.coveragePeriods[$scope.selectedIndex] === null) ? '--' : $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-' + $scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
				if($scope.beMap[key] == undefined)
				{
					$scope.beMap[key] = new Object(); 
					$scope.beMap[key+'_IS_BE_EXCLUSION_LIST'] = $scope.isExclusionMap;
				}
				
				var memberMap = $scope.beMap[key];
				memberMap[beId] = ftList;
				memberMap[beId + '_IS_FT_EXCLUSION_LIST'] = exclusionFlag;
				memberMap[beId + '_TOTAL_SELECTED_AMOUNT'] = totalIssuerSelectedAmount;
				
				
				var changeInCoveragePeriodAmount = totalIssuerSelectedAmount - $scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount;
				
				$scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex] = parseFloat($scope.coveragePeriodsSelectedAmountArray[$scope.selectedIndex]) - parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount) + totalIssuerSelectedAmount;
				
				$scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount = totalIssuerSelectedAmount;
				
				var tempCoveragePeriodAmount = $scope.coveragePeriodsAmountArray[$scope.selectedIndex]; 
				$scope.coveragePeriodsAmountArray[$scope.selectedIndex] = 0;
				for(var i = 0 ; i<$scope.subscribersListOnCoverageBasis.length; i++){
					$scope.coveragePeriodsAmountArray[$scope.selectedIndex] = $scope.coveragePeriodsAmountArray[$scope.selectedIndex] + parseFloat($scope.subscribersListOnCoverageBasis[i].selectedAmount);
				}
				
				$scope.partnerDetails.totalSelectedAmount = parseFloat($scope.partnerDetails.totalSelectedAmount) + parseFloat(changeInCoveragePeriodAmount);
				var selectBeCheckBox = true;
				if(totalNumberOfRecordsSelected == 0)
				{
					selectBeCheckBox = false;
				}
				
				$scope.beMap[key][beId+'_TOTAL_SELECTED_COUNT'] = totalNumberOfRecordsSelected;
				
				var payableAmount = $scope.subscribersListOnCoverageBasis[rowIndex].payableAmount;
				publishCheckBoxEvent('SubscriberRemit_'+key.split("-")[0]+'_'+rowIndex,selectBeCheckBox);
				
				if($scope.subscribersListOnCoverageBasis[rowIndex].isChecked == true && selectBeCheckBox == false){
					$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities - 1;
					$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities - 1;
				}else if($scope.subscribersListOnCoverageBasis[rowIndex].isChecked == false && selectBeCheckBox == true){
					$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities + parseFloat(1);
					$scope.numberOfTotalSelectedEntities = $scope.numberOfTotalSelectedEntities + parseFloat(1);
				}
				
				$scope.subscribersListOnCoverageBasis[rowIndex].isChecked = selectBeCheckBox;
				
				if($scope.numberOfSelectedEntities == $scope.subscribersListOnCoverageBasis.length){
					publishCheckBoxEvent('selectAllFromHeader',true);
				}else{
					publishCheckBoxEvent('selectAllFromHeader',false);
				}
				
				var isExclusion = $scope.beMap[key+'_IS_BE_EXCLUSION_LIST'];
				if((parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].selectedAmount) === parseFloat($scope.subscribersListOnCoverageBasis[rowIndex].payableAmount)) && isExclusion !== undefined){
					if(totalNumberOfRecordsSelected > 0){
						if(isExclusion){
							delete $scope.beMap[key][beId];
							delete $scope.beMap[key][beId + '_IS_FT_EXCLUSION_LIST'];
							delete $scope.beMap[key][beId + '_TOTAL_SELECTED_COUNT'];							
						}
					}else if(totalNumberOfRecordsSelected == 0){
						if(!isExclusion){
							delete $scope.beMap[key][beId];
							delete $scope.beMap[key][beId + '_IS_FT_EXCLUSION_LIST'];
							delete $scope.beMap[key][beId + '_TOTAL_SELECTED_COUNT'];
						}
					}
				}
			
				updateSelectionInfoMessage();
			}

			$scope.publishSubscriberDetail = function(remitSubscriberDetails,rowIndex) {
				$scope.remitSubscriberDetails = remitSubscriberDetails;
				$scope.remitSubscriberDetails.rowIndex = rowIndex;
				$scope.remitSubscriberDetails.allCheckBoxSelected = (($scope.remitSubscriberDetails.selectedAmount != 0) ? true : false);
				var currentCoveragePeriod = ($scope.coveragePeriods[$scope.selectedIndex] === null) ? '--' : $scope.coveragePeriods[$scope.selectedIndex].beginsOn.date+'-' + $scope.coveragePeriods[$scope.selectedIndex].endsOn.date;
				var remitDetails = {
					"remitSubscriberDetails" : $scope.remitSubscriberDetails,
					"partnerDetails" : $scope.partnerDetails,
					"beMap" : $scope.beMap,
					"isExclusion" : $scope.isExclusion,
					"currentCoveragePeriod" : currentCoveragePeriod,
					"isIssuerAssignedFilter" : $scope.isIssuerAssignedFilter
				};
				EventBusSrvc.publish('remitDetails', remitDetails);
				launchSubscriberDetailPopup(remitSubscriberDetails.exchangeEntityId, rowIndex);
			}
			
			var publishCheckBoxEvent = function(key,value){
				var data = {};
				data.key = key;
				data.value = value;
				$scope.$broadcast('checkBoxEvent', data);
			}
			
			function prepareCheckBoxEventArray(key,value,array){
     			var data = {};
				data.key = key;
				data.value = value;
				array.push(data);
				return array;
     		}
    
			function publishCheckBoxEventArray(checkBoxArray){
     			if(checkBoxArray){
     				$scope.$broadcast('checkBoxEvent', checkBoxArray);
     			}
     		}
			
		}];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'RemitCoverageController',
	'id' : hcentive.WFM.RemitCoverageController
});