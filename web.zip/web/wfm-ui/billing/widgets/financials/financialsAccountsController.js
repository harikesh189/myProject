	hcentive.WFM.FinancialAccountsCtrl = [
	'$scope',
	'FinancialAccountsService',
	'EventBusSrvc',
	'FinancialsFilterConfigService',
	function($scope, financialsService, EventBusSrvc,FinancialsFilterConfigService) {

		$scope.filterBoxConfig = FinancialsFilterConfigService.getAccountFilterConfiguration();
	    
	    $scope.exportHandler = function(filterData){
	    	var data = {};
	    	data.fileName = 'Accounts';
	    	$scope.$broadcast('exportEvent', data);
	    };
	    
	    $scope.handleSearch = function(filterData){
	    	$scope.handleChange(filterData);
	    };
	    
	    $scope.handleChange = function(filterData){
	    	$scope.accountFilter = JSON.parse(JSON.stringify(filterData));
	    };				

		$scope.accountDetailsList = [];
		$scope.pagination = defaultPagination('gla.name', '');
		$scope.searchAccountNameFilter = '';
		

		$scope.accountDetailsListFilters = [ {
			'filterKey' : 'accountId',
			'filterType' : 'String',
			'filterQueryKey' : 'gla.account_id',
			'filterValueWithQuote' : true
		},{
			'filterKey' : 'accountType',
			'filterType' : 'StringList',
			'filterQueryKey' : 'gla.account_type'
		}, {
			'filterKey' : 'accountName',
			'filterType' : 'String',
			'filterQueryKey' : 'gla.name'
		},{
			'filterKey' : 'totalSum',
			'filterType' : 'NumberRange',
			'filterQueryKey' :'CASE WHEN t1.totalSum IS NULL THEN 0 ELSE t1.totalSum END'
		}
		];				


		$scope.publishFTEntries = function(data,accountName) {
			var payload = {};
			payload.data=data;
			payload.accountName = accountName;
			EventBusSrvc.publish('fetchFTEntry', payload);
		};
		$scope.accountDetailsListHeaders = [ {
			'isSortable' : 'yes',
			'key' : 'accountId',
			'desc' : 'Account No',
			'contentType' : 'String',
			'sortableKey' :'gla.account_id'
		},{
			'isSortable' : 'yes',
			'key' : 'accountName',
			'desc' : 'Account Name',
			'contentType' : 'String',
			'sortableKey' :'gla.name'
		}, {
			'isSortable' : 'yes',
			'key' : 'creditDebit',
			'desc' : 'Account Type',
			'contentType' : 'String',
			'sortableKey' :'gla.account_type'
		}, {
			'isSortable' : 'no',
			'key' : 'accountBalance',
			'desc' : 'Account Balance',
			'contentType' : 'Currency',
			'sortableKey' :''
		}, {
			'isSortable' : 'no',
			'key' : 'action',
			'desc' : 'Actions',
			'contentType' : 'html'
		} ];
		var successCallback = function(data) {
			// alert(angular.toJson(success.errorMsg));
			$scope.pagination.totalElements = data.totalElements;
			$scope.accountDetailsList = getFinancialAccountsTransformer(data);
			$scope.pagination.totalElements = data.length;
			if ($scope.accountDetailsList == ''
					|| $scope.accountDetailsList == undefined) {
				$scope.accountDetailsList = 'No Data';
			}
		};
		var errorCallBack = function(data) {
			$scope.accountDetailsList = 'No Data';
		};
		$scope.fetchdata = function(paginationObj, filterObj) {
			var pagination = getPageRequestCriteria(paginationObj);
			var searchCriteriaJson = {
				'criteria' : {},
				'pageRequestCriteria' : pagination,
				'referenceId' : null
			};
			
			if(filterObj){
				if(Array.isArray(filterObj)){
					searchCriteriaJson.criteria =  {};
				}else{
					searchCriteriaJson.criteria =  filterObj;
				}
			}
			
			
			/*if (filterObj != null && filterObj != undefined
					&& filterObj.length > 0) {
				var criteria = {};
				angular
						.forEach(
								filterObj,
								function(jsonObject, index) {
									var jsonObjectKey = Object
											.keys(jsonObject);
									var jsonObjectValue = jsonObject[jsonObjectKey];
									criteria[jsonObjectKey] = {
										'operator' : 'like',
										'columnValue' : '\'%'
												+ jsonObjectValue
												+ '%\'',
										'caseSensitiveSearch' : 'false'
									};
								})
				searchCriteriaJson.criteria = criteria;
				//searchCriteriaJson.criteria = {"gle.glAccount.qualifier.name": { "operator" : "like", "columnValue": "%" + filterObj[0].searchAccountName + "%", "caseSensitiveSearch": "true" }};
			}*/
			var goToRelatedBEIdentity = EventBusSrvc
					.subscribeAndInvalidatePayload('goToRelatedBEIdentity');
			var goToRelatedBeExternalId =EventBusSrvc
			.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
			if (goToRelatedBEIdentity != null
					&& goToRelatedBEIdentity != undefined
					&& goToRelatedBEIdentity != '') {
				searchCriteriaJson.criteria['billingAccount.identity'] = {
					'operator' : '=',
					'columnValue' : '\'' + goToRelatedBEIdentity + '\'',
					'caseSensitiveSearch' : 'false'
				};						
			}
			if (goToRelatedBeExternalId != null
					&& goToRelatedBeExternalId != undefined
					&& goToRelatedBeExternalId != '') {
				searchCriteriaJson.criteria['billingAccount.owner.externalId'] = {
					'operator' : '=',
					'columnValue' : '\'' + goToRelatedBeExternalId + '\'',
					'caseSensitiveSearch' : 'false'
				};						
			}
			financialsService.getAllFinancialAccounts(null,
					searchCriteriaJson, null, successCallback,
					errorCallBack);
		};
	} ];
	hcentive.WFM.FinancialAccountDetailsCtrl = [
	'$scope',
	'FinancialAccountDetailsService',
	'$route',
	'EventBusSrvc',
	'$routeParams',
	'FinancialsFilterConfigService',
	function($scope, financialsService, $route, EventBusSrvc,
			$routeParams,FinancialsFilterConfigService) {
		var isResetCalled=false;
		$scope.exportHandler = function(filterData){
	    	var data = {};
	    	data.fileName = 'Accounts';
	    	$scope.$broadcast('exportEvent', data);
	    };
	    
	    $scope.handleSearch = function(filterData,filterReset){
	    	if(filterReset){
	    		isResetCalled=filterReset;
	    	}
	    	$scope.handleChange(filterData);
	    };
	    
	    $scope.handleChange = function(filterData){
	    	$scope.accountFilter = JSON.parse(JSON.stringify(filterData));
	    };			

		$scope.entityDetailsList = [];
		$scope.pagination = defaultPagination(
				'gle.glAccount.qualifier.name', 'asc');
		
		$scope.searchEntityFilter = '';
		
		var preSelectedFilters = {};
		var accountName = null;
		
		var goToRelatedBeExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
		var goToRelatedBAExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBAExternalId');
		if(goToRelatedBeExternalId != undefined && goToRelatedBeExternalId !=''){
			preSelectedFilters.entityId =  goToRelatedBeExternalId;
		}
		
		if(goToRelatedBAExternalId != undefined && goToRelatedBAExternalId !=''){
			preSelectedFilters.subscription =  goToRelatedBAExternalId;
		}
		
		if ($routeParams.accountName != null
				&& $routeParams.accountName != undefined) {
			accountName = $routeParams.accountName;
			preSelectedFilters.accountName = accountName;
		} else {
			accountName = null;
		}
		
		
	
		$scope.filterBoxConfig = FinancialsFilterConfigService.getAccountDetailsFilterConfiguration(preSelectedFilters);
		
		$scope.accountFilterConfig = [ {
			'filterKey' : 'accountName',
			'filterType' : 'String',
			'filterQueryKey' : 'gle.glAccount.qualifier.name'
		},{
			'filterKey' : 'entityId',
			'filterType' : 'String',
			'filterQueryKey' : 'gle.billingAccount.owner.externalId'
		},{
			'filterKey' : 'subscription',
			'filterType' : 'String',
			'filterQueryKey' : 'gle.billingAccount.externalId'
		}, {
			'filterKey' : 'entityName',
			'filterType' : 'String',
			'filterQueryKey' : 'gle.billingAccount.owner.profile.name'
		},{
			'filterKey' : 'entityType',
			'filterType' : 'StringList',
			'filterQueryKey' :'gle.billingAccount.owner.type'
		}
		];		
		
		$scope.entityDetailsListHeaders = [ {
			'isSortable' : 'yes',
			'key' : 'accountName',
			'desc' : 'Account Name',
			'contentType' : 'String',
			'sortableKey' : 'gle.glAccount.qualifier.name'
		}, {
			'isSortable' : 'yes',
			'key' : 'entity',
			'desc' : 'Entity',
			'contentType' : 'String',
			'sortableKey' : 'gle.billingAccount.owner.externalId'
		}, {
			'isSortable' : 'yes',
			'key' : 'subscription',
			'desc' : 'Billing Account',
			'contentType' : 'String',
			'sortableKey' : 'gle.billingAccount.externalId'
		}, {
			'isSortable' : 'yes',
			'key' : 'entityName',
			'desc' : 'Entity Name',
			'contentType' : 'String',
			'sortableKey' : 'gle.billingAccount.owner.profile.name'
		}, {
			'isSortable' : 'yes',
			'key' : 'entityType',
			'desc' : 'Entity Type',
			'contentType' : 'String',
			'sortableKey' : 'gle.billingAccount.owner.type'
		}, {
			'isSortable' : 'yes',
			'key' : 'accountBalance',
			'desc' : 'Account Balance',
			'contentType' : 'Currency',
			'sortableKey' : 'totalSum'
		}, {
			'isSortable' : 'no',
			'key' : 'action',
			'desc' : 'Actions',
			'contentType' : 'html'
		}  ];
		var successCallback = function(data) {
			$scope.pagination.totalElements = data.totalElements;
			$scope.pagination.totalNoPages = data.totalPages;

			$scope.entityDetailsList = getFinancialAccountDetailsTransformer(data);

			if ($scope.entityDetailsList == null
					|| $scope.entityDetailsList == undefined
					|| $scope.entityDetailsList == '') {
				$scope.entityDetailsList = 'No Data';
			} 
		};
		var errorCallBack = function(data) {
			$scope.entityDetailsList = 'No Data';
		};
		$scope.fetchdata = function(paginationObj, filterObj, callType) {
			$scope.pagination = paginationObj;

			if (callType != null && callType != undefined
					&& callType == 'search') {
				accountName = null;
			//	goToRelatedBAExternalId = null;
			//	goToRelatedBeExternalId =null;
			}

			var searchCriteriaJson = {
				'criteria' : {},
				'pageRequestCriteria' : getPageRequestCriteria($scope.pagination),
				'referenceId' : null
			};
			
			if (filterObj && !Array.isArray(filterObj)) {
				searchCriteriaJson.criteria = filterObj;
			}
			
			if(!isResetCalled){
				
				if (accountName && accountName != '') {
					searchCriteriaJson.criteria = addStringFilter(searchCriteriaJson.criteria,'gle.glAccount.qualifier.name',accountName,false,true);
				}

				if (goToRelatedBeExternalId) {
					searchCriteriaJson.criteria = addStringFilter(searchCriteriaJson.criteria,'gle.billingAccount.owner.externalId',goToRelatedBeExternalId,false,true);
					$scope.updateLeftNav('Accounts');
				}
				
				if (goToRelatedBAExternalId ) {
					searchCriteriaJson.criteria = addStringFilter(searchCriteriaJson.criteria,'gle.billingAccount.externalId',goToRelatedBAExternalId,false,true);
					$scope.updateLeftNav('Accounts');
				}
				
			}
			
			
			
			financialsService.getFinancialAccountDetails(null,
					searchCriteriaJson, null, successCallback,
					errorCallBack);
		};
		
		$scope.publishFTEntries = function(entityId,accountName) {
			var payload = {};
			payload.entityId=entityId;
			payload.accountName = accountName;
			EventBusSrvc.publish('fetchFTEntry', payload);
		};
		
	} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'FinancialAccountsCtrl',
	'id' : hcentive.WFM.FinancialAccountsCtrl
});
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'FinancialAccountDetailsCtrl',
	'id' : hcentive.WFM.FinancialAccountDetailsCtrl
});