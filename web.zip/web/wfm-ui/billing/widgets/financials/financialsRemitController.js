/**
 * Created by Amit.Ag on 19/11/2014.
 */

hcentive.WFM.FinancialRemitsCtrl = [
			'$scope',
			'FinancialRemitsService',
			'EventBusSrvc',
			'FinancialsRemitsFilterService',
			'$location', '$translate',
			function($scope, financialsRemitsService, EventBusSrvc,FinancialsRemitsFilterService,$location, translate) {
				$scope.remits ='';
				$scope.pagination = defaultPagination('partnerExternalId', 'ASC');
				$scope.remitStartTimestamp = null;
				$scope.onlyDigits=/([1-9][0-9]*)|0/;

				$scope.remit = function(ftList, partnerIdentity, partnerExternalId, partnerName, partnerType, totalPayableAmount) {
					
					/*if(totalPayableAmount && totalPayableAmount <= 0){
						$scope.succErrDialog('Partner Remits','Remit amount cannot be Zero or less than Zero');
						return;
					}*/
				
					//Publishing partner details
					var remitPartnerDetails = {};
					remitPartnerDetails.partnerIdentity = partnerIdentity;
					remitPartnerDetails.partnerExternalId = partnerExternalId;
					remitPartnerDetails.partnerName = partnerName;
					remitPartnerDetails.partnerType = partnerType;
					remitPartnerDetails.totalPayableAmount= totalPayableAmount;
					remitPartnerDetails.remitStartTimestamp = $scope.remitStartTimestamp;
					EventBusSrvc.publish('remitPartnerDetails',remitPartnerDetails);
					$location.path("financials/remit-advice-start");
					$location.replace();
				};

//=========================================REMIT PARTNER LISTING SCREEN FILTER CODE STARTS.=======================================
				var preSelectedFilters = {};
				var goToRelatedBeExternalId = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
				if(goToRelatedBeExternalId != undefined && goToRelatedBeExternalId != null && goToRelatedBeExternalId != ''){
					preSelectedFilters.partnerId =  goToRelatedBeExternalId;
				}
				$scope.filterBoxConfig = FinancialsRemitsFilterService.getRemitsFilterConfiguration(preSelectedFilters);
				
				$scope.exportHandler = function(filterData){
					console.log(filterData);
			     	var data = {};
			    	data.fileName = 'Remits';
			    	$scope.$broadcast('exportEvent', data);
			    };
			    
			    $scope.handleSearch = function(filterData){
			     console.log("Handle Individual Search");
			     console.log(filterData);
			     $scope.handleChange(filterData);
			    };
			    
			    $scope.handleChange = function(filterData){
			     console.log(filterData);
			     $scope.remitsFilter = JSON.parse(JSON.stringify(filterData));
			    };

       

            $scope.filterList = [ 
                {
					'filterKey' : 'outstandingAmount',
					'filterType' : 'NumberRange',
				}, 
				{
					'filterKey' : 'partnerId',
					'filterType' : 'String',
					'filterValueWithQuote' : false
				}, 
				{
					'filterKey' : 'partnerName',
					'filterType' : 'String',
					'filterValueWithQuote' : false
				},
				{
					'filterKey' : 'lastRemitAmount',
					'filterType' : 'NumberRange'
				},
				{
					'filterKey' : 'ytdRemitAmount',
					'filterType' : 'NumberRange'
				}
			];

//==============================REMIT PARTNER LISTING SCREEN FILTER CODE ENDS.======================================

				$scope.remitsTableFooter = [
			    {
		        'desc' : '',
		        'key' : '',
		        'calculationType' :'',
		        'contentType' : '',
		        'calculatedValue' :'',
		        'colSpan' : 2
		        },{
				'desc' : 'Grand Total:',
				'key' : '',
				'calculationType' :'',
				'contentType' : '',
				'calculatedValue' :'',
				'colSpan' : 1,
		        'style' : 'text-left'
				},{
				'desc' : '',
				'key' : 'lastRemitAmount',
				'calculationType' :'Sum',
				'contentType' : 'Currency',
				'calculatedValue' :'',
				'colSpan' : 1,
				'style' : 'text-left'
				},{
				'desc' : '',
				'key' : 'YTDRemitAmount',
				'calculationType' :'Sum',
				'contentType' : 'Currency',
				'calculatedValue' :'',
				'colSpan' : 1,
				'style' : 'text-left'
				},{
				'desc' : '',
				'key' : 'outstandingAmount',
				'calculationType' :'Sum',
				'contentType' : 'Currency',
				'calculatedValue' :'',
				'colSpan' : 1,
				'style' : 'text-left'
				}];
				
				$scope.remitsTableHeaders = [ {
					'isSortable' : 'yes',
					'key' : 'partnerExternalId',
					'desc' : 'Partner ID',
					'contentType' : 'String'
				},{
					'isSortable' : 'yes',
					'key' : 'partnerName',
					'sortableKey' : '"partnerName"',
					'desc' : 'Partner Name',
					'contentType' : 'String'
				},{
					'isSortable' : 'yes',
					'key' : 'partnerType',
					'sortableKey' : '"partnerType"',
					'desc' : 'Partner Type',
					'contentType' : 'String'
				}, {
					'isSortable' : 'yes',
					'key' : 'lastRemitDate',
					'sortableKey' : '"lastRemitDate"',
					'desc' : 'Last Remitted Date',
					'contentType' : 'Date'
				}, {
					'isSortable' : 'yes',
					'key' : 'lastRemitAmount',
					'sortableKey' : '"lastRemitAmount"',
					'desc' : 'Last Remitted Amount',
					'contentType' : 'Currency'
				}, {
					'isSortable' : 'yes',
					'key' : 'YTDRemitAmount',
					'sortableKey' : '"ytdRemitAmount"',
					'desc' : 'YTD Remit Amount',
					'contentType' : 'Currency'
				}, {
					'isSortable' : 'yes',
					'key' : 'outstandingAmount',
					'sortableKey' : '"outstandingAmount"',
					'desc' : 'Payable Amount',
					'contentType' : 'Currency'
				}, {
					'isSortable' : 'no',
					'key' : 'action',
					'desc' : 'Actions',
					'contentType' : 'html'
				} ];
				
				var successCallback = function(data) {
					$scope.remits = getFinancialRemitsTransformer($scope, data, translate);
					if(data){
						$scope.pagination.totalElements = data.length;
						$scope.pagination.totalNoPages = 1;
					}
					if ($scope.remits == ''
							|| $scope.remits == undefined) {
						$scope.remits = 'No Data';
					}
				};
				var errorCallBack = function(data) {
					$scope.remits = 'No Data';
					$scope.updateLeftNav('Remits');
				};
				$scope.fetchdata = function(paginationObj, filterObj) {
					$scope.updateLeftNav('Remits');
					$scope.pagination = paginationObj;
					var searchCriteriaJson = {};
					var searchCriteriaJson = populateSearchCriteria(filterObj);
					getAllRemits(searchCriteriaJson);
				};
				var getAllRemits = function(searchCriteriaJson) {
					financialsRemitsService.getAllRemits(null,
							searchCriteriaJson, null, successCallback,
							errorCallBack);
				}

				function populateSearchCriteria(filterObj) {
					var searchCriteriaJson = {};
					if(Array.isArray(filterObj)){
						filterObj = {};
					}
					searchCriteriaJson.criteria = filterObj;
					searchCriteriaJson.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
					
					if(preSelectedFilters.partnerId != undefined && preSelectedFilters.partnerId != null && preSelectedFilters.partnerId != '') {
						searchCriteriaJson.criteria['partnerId'] = {
							'operator' : '=',
							'columnValue' :  preSelectedFilters.partnerId 
						};
						preSelectedFilters = {};
					}
					
					return 	searchCriteriaJson;									;
				}
			} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'FinancialSubscriberRemitDetailCtrl',
	'id' : hcentive.WFM.FinancialSubscriberRemitDetailCtrl
});


hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		'name' : 'FinancialRemitsCtrl',
		'id' : hcentive.WFM.FinancialRemitsCtrl
});

