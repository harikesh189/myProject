hcentive.WFM.RemitCoverageDetailController = [
		'$scope',
		'FinancialRemitsService',
		'EventBusSrvc', '$translate', 
		function($scope, financialsRemitsService, EventBusSrvc, $translate) {
			var remitDetails = EventBusSrvc.subscribe('remitDetails');
			$scope.messsageState = 'AllSelected';
			$scope.subscriberDetails = remitDetails.remitSubscriberDetails;
			$scope.rowIndex = remitDetails.remitSubscriberDetails.rowIndex;
			$scope.partnerDetails = remitDetails.partnerDetails;
			$scope.totalSelectedAmount = parseFloat($scope.subscriberDetails.selectedAmount);
			$scope.coverageDetailSubscriberList = [];
			$scope.popUpCheckBoxSelected = remitDetails.remitSubscriberDetails.allCheckBoxSelected;
			$scope.coverageKey = remitDetails.currentCoveragePeriod;
			$scope.pagination = defaultPagination('', '');
			$scope.remitDetailTableFilters = [];
			$scope.beMap = remitDetails.beMap;
			$scope.isSelectAllRecordsTrue = $scope.popUpCheckBoxSelected;
			$scope.isCancelled = false;
			$scope.allSelected = $scope.popUpCheckBoxSelected;
			$scope.ftExclusionMapFlagBe = '';
			$scope.tempExcludedList = [];
			$scope.totalNumberOfRecordsFixed = '';
			$scope.totalNumberOfRecordsSelected = '';
			$scope.isIssuerAssignedFilter = remitDetails.isIssuerAssignedFilter;
			
			$scope.remitCoverageDetailTableHeaders = [ {
				'isSortable' : 'no',
				'key' : 'selectAllAction',
				'desc' : '',
				'contentType' : 'html',
				'value' : '<input type="checkbox" ng-init ="selectAllDetailsFromHeader='+$scope.popUpCheckBoxSelected+'" ng-model="selectAllDetailsFromHeader" name="selectAllDetailsFromHeader" id="selectAllDetailsFromHeader" ng-change="selectAllDetailsFromHeaderFn(selectAllDetailsFromHeader)">'
			}, {
				'isSortable' : 'yes',
				'key' : 'exchangeSubscriberId',
				'desc' : 'Exchange Subscriber ID',
				'contentType' : 'String',
				'sortableKey' : 'exchangeSubscriberId'
			}, {
				'isSortable' : 'yes',
				'key' : 'issuerSubscriberId',
				'desc' : 'Issuer Subscriber ID',
				'contentType' : 'String',
				'sortableKey' : 'issuerSubscriberId'
			}, {
				'isSortable' : 'yes',
				'key' : 'subscriberName',
				'desc' : 'Subscriber Name',
				'contentType' : 'String',
				'sortableKey' : 'subscriberName'
			}, {
				'isSortable' : 'yes',
				'key' : 'planName',
				'desc' : 'Plan/Benefit',
				'contentType' : 'String',
				'sortableKey' : 'planName'
			}, {
				'isSortable' : 'yes',
				'key' : 'amountName',
				'desc' : 'Amount Name',
				'contentType' : 'String',
				'sortableKey' : 'amountName'
			}, {
				'isSortable' : 'yes',
				'key' : 'payableAmount',
				'desc' : 'Payable Amount',
				'contentType' : 'Currency',
				'sortableKey' : 'amount.value'
			}];

			$scope.subscriberRemitsList = '';
			$scope.pagination = defaultPagination('partnerId', 'desc');
			
			$scope.selectAllDetailsFromHeaderFn = function(selectAllDetailsFromHeader) {
				resetCheckBoxesSelection(selectAllDetailsFromHeader);
			}
			

			function populateSearchCriteria(filterObj) {
				$scope.selectedCoveragePeriod=EventBusSrvc.subscribe('selectedCoveragePeriod');
				var searchCriteriaJson = {};
				
				var createdAtFilter = {};
				createdAtFilter.columnValue = $scope.partnerDetails.remitStartTimestamp;
				createdAtFilter.caseSensitiveSearch = "false";
				createdAtFilter.operator = "<=";
				searchCriteriaJson.createdAt = createdAtFilter;
				
				var partnerIdFilter = {};
				partnerIdFilter.columnValue = $scope.partnerDetails.partnerIdentity;
				partnerIdFilter.caseSensitiveSearch = "false";
				partnerIdFilter.operator = "=";
				searchCriteriaJson.partnerIdentity = partnerIdFilter;
				
				var beIdFilter = {};
				beIdFilter.columnValue = $scope.subscriberDetails.businessEntityIdentity;
				beIdFilter.caseSensitiveSearch = "false";
				beIdFilter.operator = "=";
				searchCriteriaJson.beId = beIdFilter;
				
				var issuerEntityIdFilter = {};
				issuerEntityIdFilter.columnValue = $scope.isIssuerAssignedFilter;
				issuerEntityIdFilter.caseSensitiveSearch = "false";
				issuerEntityIdFilter.operator = "=";
				searchCriteriaJson.issuerEntityId = issuerEntityIdFilter;
				
				var beginsOnFilter = {};
				beginsOnFilter.columnValue = $scope.selectedCoveragePeriod.beginsOn;
				beginsOnFilter.caseSensitiveSearch = "false";
				beginsOnFilter.operator = ">=";
				searchCriteriaJson.beginsOn = beginsOnFilter;
				
				var endsOnFilter = {};
				endsOnFilter.columnValue = $scope.selectedCoveragePeriod.endsOn;
				endsOnFilter.caseSensitiveSearch = "false";
				endsOnFilter.operator = "<=";
				searchCriteriaJson.endsOn = endsOnFilter;
				
				return searchCriteriaJson;
			}

			$scope.fetchdata = function(paginationObj, filterObj, callType) {
				$scope.pagination = paginationObj;
				var searchCriteriaJson = {
					'criteria' : populateSearchCriteria(filterObj),
					'pageRequestCriteria' : getPageRequestCriteria($scope.pagination),
					'referenceId' : null
				};
				getCoverageDetailsSubscribers(searchCriteriaJson);
			}
			
			$scope.resetFtEntryMap = function(action) {
				$scope.tempExcludedList = [];
				if(action =='clear'){
					$scope.popUpCheckBoxSelected = false;
					$scope.numberOfSelectedEntities = 0;
					$scope.totalSelectedAmount = 0;
					$scope.allSelected = false;
					$scope.totalNumberOfRecordsSelected = 0;
					$scope.numberOfSelectedEntitiesOnPage = 0;
					publishCheckBoxEvent('selectAllDetailsFromHeader',false);
					$scope.ftExclusionMapFlagBe = false;
				}
				else{
					$scope.popUpCheckBoxSelected = true;
					$scope.numberOfSelectedEntities = $scope.pagination.totalElements;
					$scope.totalSelectedAmount = parseFloat($scope.subscriberDetails.payableAmount);
					$scope.allSelected = true;
					$scope.totalNumberOfRecordsSelected = $scope.pagination.totalElements;
					$scope.numberOfSelectedEntitiesOnPage = $scope.coverageDetailSubscriberList.length;
					publishCheckBoxEvent('selectAllDetailsFromHeader',true);
					$scope.ftExclusionMapFlagBe = true;
				}
					
				$scope.isSelectAllRecordsTrue = $scope.popUpCheckBoxSelected;
					
				for(var i = 0; i < $scope.coverageDetailSubscriberList.length; i++){
					var shouldBeChecked = $scope.popUpCheckBoxSelected;
					var rowIndex = i;
					publishCheckBoxEvent('CoverageDetailSubscriberRemit_'+rowIndex,shouldBeChecked);
				}
			}
			
			
			var successCallback = function(data) {
				if (data != null && data != undefined) {
					if (data.content.length == 0) {
						$scope.coverageDetailSubscriberList = 'No Data';
					} else {
						$scope.pagination.totalElements = data.totalElements;
						$scope.pagination.totalNoPages = data.totalPages;
						if($scope.totalNumberOfRecordsFixed == ''){
							$scope.totalNumberOfRecordsFixed = data.totalElements;
						}
						
						var beIdentity = $scope.subscriberDetails.businessEntityIdentity;
						
						if($scope.beMap && $scope.beMap[$scope.coverageKey] && $scope.beMap[$scope.coverageKey][beIdentity+'_TOTAL_SELECTED_COUNT'] != undefined){
							$scope.totalNumberOfRecordsSelected = $scope.beMap[$scope.coverageKey][beIdentity+'_TOTAL_SELECTED_COUNT']; 
						}
						var list = ($scope.beMap[$scope.coverageKey] === undefined) ? [] : $scope.beMap[$scope.coverageKey][beIdentity] ;
						if(list == undefined || list.length == 0){
							list = $scope.tempExcludedList;
						}
						var coverageDetailSubscriberListObject = coverageDetailsTransformer(data.content, $scope.popUpCheckBoxSelected, $translate,$scope.subscriberDetails.businessEntityIdentity,$scope.beMap,$scope.coverageKey,list,$scope.numberOfSelectedEntitiesOnPage,$scope.numberOfSelectedEntities,$scope.ftExclusionMapFlagBe);
						$scope.coverageDetailSubscriberList = coverageDetailSubscriberListObject.coverageDetailSubscriberList;
						var dataToUpdate = coverageDetailSubscriberListObject.dataToUpdate;
						$scope.ftExclusionMapFlagBe = dataToUpdate.ftExclusionMapFlagBe;
						$scope.tempExcludedList = dataToUpdate.tempExcludedList;
						$scope.numberOfSelectedEntitiesOnPage = dataToUpdate.numberOfSelectedEntitiesOnPage;
						$scope.numberOfSelectedEntities = dataToUpdate.numberOfSelectedEntities;
						
						var checkBoxEventArray = [];
						if(dataToUpdate && dataToUpdate.checkBoxArray){
							for(var i=0;i<dataToUpdate.checkBoxArray.length;i++){
								checkBoxEventArray = prepareCheckBoxEventArray('CoverageDetailSubscriberRemit_'+i,dataToUpdate.checkBoxArray[i],checkBoxEventArray); 	
							}
						}
						
						//checking if header should be ticked or not.
						if($scope.numberOfSelectedEntitiesOnPage == data.numberOfElements){
							checkBoxEventArray = prepareCheckBoxEventArray('selectAllDetailsFromHeader',true,checkBoxEventArray);
						}
						else{
							checkBoxEventArray = prepareCheckBoxEventArray('selectAllDetailsFromHeader',false,checkBoxEventArray);
						}
						
						publishCheckBoxEventArray(checkBoxEventArray);
						
						if($scope.totalNumberOfRecordsSelected == ''){
							if($scope.beMap && $scope.beMap[$scope.coverageKey] && $scope.beMap[$scope.coverageKey][beIdentity+'_TOTAL_SELECTED_COUNT'] != undefined){
								$scope.totalNumberOfRecordsSelected = $scope.beMap[$scope.coverageKey][beIdentity+'_TOTAL_SELECTED_COUNT']; 
							}else{
								if($scope.numberOfSelectedEntitiesOnPage == 0){
									$scope.totalNumberOfRecordsSelected = 0;
								}else{
									$scope.totalNumberOfRecordsSelected = data.totalElements;	
								}
							}
						}
						
						
						updateAllSelectedFlag();
					}
				} else {
					$scope.coverageDetailSubscriberList = 'No Data';
				}
			}

			var errorCallBack = function() {
				$scope.coverageDetailSubscriberList = 'No Data';
			}

			
			var getCoverageDetailsSubscribers = function(searchCriteriaJson) {
				var params = {};
				financialsRemitsService.getCoverageDetailsSubscribers(params,
						searchCriteriaJson, successCallback, errorCallBack);
			}
			
			$scope.updateSubscriberAmount =function(rowIndex,isSelected,payableAmount){
				if(isSelected)
				{
					$scope.totalSelectedAmount = parseFloat($scope.totalSelectedAmount) + parseFloat(payableAmount);
					$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities + parseFloat(1);
					$scope.numberOfSelectedEntitiesOnPage = $scope.numberOfSelectedEntitiesOnPage + parseFloat(1);
					$scope.totalNumberOfRecordsSelected = $scope.totalNumberOfRecordsSelected + 1;
				}
				else
				{
					$scope.totalSelectedAmount = parseFloat($scope.totalSelectedAmount) - parseFloat(payableAmount);
					$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities - 1;
					$scope.numberOfSelectedEntitiesOnPage = $scope.numberOfSelectedEntitiesOnPage - 1;
					$scope.totalNumberOfRecordsSelected = $scope.totalNumberOfRecordsSelected - 1;
				}
				
				updateAllSelectedFlag();
				if($scope.numberOfSelectedEntitiesOnPage == $scope.coverageDetailSubscriberList.length){
					publishCheckBoxEvent('selectAllDetailsFromHeader',true);
					$scope.popUpCheckBoxSelected = true;
				}
				else{
					publishCheckBoxEvent('selectAllDetailsFromHeader',false);
					$scope.popUpCheckBoxSelected = false;
				}
					
					
				var beId = $scope.subscriberDetails.businessEntityIdentity;
				var ftId = $scope.coverageDetailSubscriberList[rowIndex].ftEntryId;
				if(!($scope.beMap == undefined || Object.keys($scope.beMap).length == 0 || $scope.beMap[$scope.coverageKey]== undefined)){
					if($scope.ftExclusionMapFlagBe == undefined || $scope.ftExclusionMapFlagBe === ''){
						$scope.ftExclusionMapFlagBe = $scope.beMap[$scope.coverageKey+'_IS_BE_EXCLUSION_LIST'];
					}
				}
				
				if(!($scope.beMap == undefined || Object.keys($scope.beMap).length == 0 || ($scope.beMap[$scope.coverageKey] != undefined && $scope.beMap[$scope.coverageKey][beId] == undefined))){
					if($scope.ftExclusionMapFlagBe == undefined || $scope.ftExclusionMapFlagBe === ''){
						$scope.ftExclusionMapFlagBe = $scope.beMap[$scope.coverageKey][beId+'_IS_FT_EXCLUSION_LIST'];
					}
				}
				
				if($scope.ftExclusionMapFlagBe === undefined){
					$scope.ftExclusionMapFlagBe = true;
				}
				
				if($scope.tempExcludedList == undefined){
					$scope.tempExcludedList = [];
				}
				
				if(($scope.ftExclusionMapFlagBe && !isSelected) || (!$scope.ftExclusionMapFlagBe && isSelected)) //true means selected from outside.
				{
					 $scope.tempExcludedList.push(ftId);
				}
				else
				{
					var index = $scope.tempExcludedList.indexOf(ftId);
					$scope.tempExcludedList.splice(index, 1);
				}
			}
			
			var updateAllSelectedFlag = function(){
				if($scope.numberOfSelectedEntities != $scope.pagination.totalElements)
					$scope.allSelected = false;
				else
					$scope.allSelected = true;
			}
			
			var publishCheckBoxEvent = function(key,value){
				var data = {};
				data.key = key;
				data.value = value;
				$scope.$broadcast('checkBoxEvent', data);
				}
				
			
			var resetCheckBoxesSelection = function(selectAll)
			{
				var ftExclusionListFlag = $scope.ftExclusionMapFlagBe;
				var pageTotalPayableAmount = 0;
				var selectAllDetailsFromHeader = selectAll;
				var pageTotalAmount = 0;
				for(var rowIndex=0 ; rowIndex < $scope.coverageDetailSubscriberList.length; rowIndex++)
				{
					var ftId = $scope.coverageDetailSubscriberList[rowIndex].ftEntryId;
					var index = $scope.tempExcludedList.indexOf(ftId);
					var value = $scope.coverageDetailSubscriberList[rowIndex].payableAmount;
					if(selectAll && ((ftExclusionListFlag && index != -1) || (!ftExclusionListFlag && index==-1))){
						pageTotalPayableAmount = pageTotalPayableAmount + $scope.coverageDetailSubscriberList[rowIndex].payableAmount;
					}
					var index = $scope.tempExcludedList.indexOf(ftId);
					pageTotalAmount = pageTotalAmount + parseFloat($scope.coverageDetailSubscriberList[rowIndex].payableAmount);
					if((ftExclusionListFlag && selectAllDetailsFromHeader)||(!ftExclusionListFlag && !selectAllDetailsFromHeader)){
						if(index != -1){
							$scope.tempExcludedList.splice(index, 1);
						}
					}
					else{
						if(index == -1)
						$scope.tempExcludedList.push(ftId);
					}
					publishCheckBoxEvent('CoverageDetailSubscriberRemit_'+rowIndex,selectAllDetailsFromHeader);
				}
				if(selectAll){
					$scope.totalNumberOfRecordsSelected = $scope.totalNumberOfRecordsSelected -  $scope.numberOfSelectedEntitiesOnPage + $scope.coverageDetailSubscriberList.length;
					$scope.totalSelectedAmount = parseFloat($scope.totalSelectedAmount) + parseFloat(pageTotalPayableAmount);
					$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities + parseFloat($scope.coverageDetailSubscriberList.length);
					$scope.numberOfSelectedEntitiesOnPage = $scope.coverageDetailSubscriberList.length;
				}
				else{
					$scope.totalNumberOfRecordsSelected = $scope.totalNumberOfRecordsSelected -  $scope.numberOfSelectedEntitiesOnPage ;
					$scope.totalSelectedAmount = parseFloat($scope.totalSelectedAmount) - parseFloat(pageTotalAmount);
					$scope.numberOfSelectedEntities = $scope.numberOfSelectedEntities - $scope.coverageDetailSubscriberList.length;
					$scope.numberOfSelectedEntitiesOnPage = 0;
				}
				
				updateAllSelectedFlag();
			}

			$scope.success = function() {
				$scope.$modalSuccess();
			}

			$scope.cancel = function() {
				$scope.isCancelled = true;
					$scope.$modalCancel();
			}
			
			function prepareCheckBoxEventArray(key,value,array){
     			var data = {};
				data.key = key;
				data.value = value;
				array.push(data);
				return array;
     		}
     		
     		 
     		function publishCheckBoxEventArray(checkBoxArray){
     			if(checkBoxArray){
     				$scope.$broadcast('checkBoxEvent', checkBoxArray);
     			}
     		}
     		
     		
		} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'RemitCoverageDetailController',
	'id' : hcentive.WFM.RemitCoverageDetailController
});