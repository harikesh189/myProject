/**
 * Created by Dikshit.Vaid on 6/10/2014.
 */
(function () {
    hcentive.WFM.FinancialsInvoiceService = [
        '$http',
        'RESTSrvc',
        function ($http, RESTSrvc) {
        	var getAllFinancialsInvoicesForAdmin =  function (data, successCallback, errorCallback) {
                RESTSrvc.postForData('getAllFinancialsInvoicesForAdmin', null, data, null, successCallback, errorCallback);
            };
            
            var getInvoiceDetailForAdmin =  function (params,data, successCallback, errorCallback) {
                RESTSrvc.postForData('getInvoiceDetailForAdmin', params, data, null, successCallback, errorCallback);
            };
            
            var regenerateInvoiceForAdmin =  function (data, successCallback, errorCallback) {
                RESTSrvc.postForData('regenerateInvoiceForAdmin', null, data, null, successCallback, errorCallback);
            };
            
            var approveInvoiceForAdmin =  function (params, successCallback, errorCallback) {
                RESTSrvc.postForData('approveInvoiceForAdmin', params, null, null, successCallback, errorCallback);
            };
            
            var rejectInvoiceForAdmin =  function (params, successCallback, errorCallback) {
                RESTSrvc.postForData('rejectInvoiceForAdmin', params, null, null, successCallback, errorCallback);
            };
            
            return {
            	getAllFinancialsInvoicesForAdmin : getAllFinancialsInvoicesForAdmin,
            	getInvoiceDetailForAdmin : getInvoiceDetailForAdmin,
            	regenerateInvoiceForAdmin: regenerateInvoiceForAdmin,
            	approveInvoiceForAdmin: approveInvoiceForAdmin,
            	rejectInvoiceForAdmin: rejectInvoiceForAdmin
        	};
            }
         ];
		 

    hcentive.WFM.FinancialTransactionService = [
        '$http',
        'RESTSrvc',
        function ($http, RESTSrvc) {
            return {
                getFinancialTransactionsByIdentities: function (data, successCallback, errorCallback) {
                    RESTSrvc.postForData('getFinancialTransactionsByIdentities', null, data, null, successCallback, errorCallback);
                },
				
				//function for financial transactions corresponding to invoice id	
				 getFinancialTxnsForInvoiceId: function (data, successCallback, errorCallback) {
                    RESTSrvc.postForData('getAllFinancialTxnsForInvoiceId', data, null, null, successCallback, errorCallback);
                }
            }
        } ];

    hcentive.WFM.FinancialRemitAdviceService = [
 	    '$http',
        'RESTSrvc','$filter',
        function($http, RESTSrvc,$filter) {
        	
        	var getAllRemitAdvice = function(params, data, transformer, successCallback,errorCallback) {
        		RESTSrvc.postForData('getAllFinancialRemitAdvice', params, data ,null, successCallback,errorCallback);
        	};
        	
        	return {
        		getAllRemitAdvice : getAllRemitAdvice
        	};
        } ];
		
		// this service is to fetch remits 
		hcentive.WFM.FinancialRemitsService = [
 	    '$http',
        'RESTSrvc','$filter',
        function($http, RESTSrvc,$filter) {
        	
        	var getAllRemits = function(params, data, transformer, successCallback,errorCallback) {
        		RESTSrvc.postForData('getAllFinancialRemits', params, data ,null, successCallback,errorCallback);
        	};
        	
        	var getAllRefunds = function(params, data, transformer, successCallback,errorCallback) {
        		RESTSrvc.postForData('getAllFinancialCustomerRefundsList', params, data ,null, successCallback,errorCallback);
        	};
        	
        	var getCustomerRefunds = function(params, data, transformer, successCallback,errorCallback) {
        		RESTSrvc.postForData('getCustomerRefunds', params, data ,null, successCallback,errorCallback);
        	};
        	var saveRefunds = function(params, data, transformer, successCallback,errorCallback) {
        		RESTSrvc.postForData('refund', params, data ,null, successCallback,errorCallback);
        	};
        	
        	
			var remit = function(params, data, transformer, successCallback,errorCallback){
				RESTSrvc.postForData('remit', params, data ,null, successCallback,errorCallback);
			};
			
			var getAllSubscribersForPartner = function(params, data, successCallback,errorCallback){
				RESTSrvc.postForData('getAllSubscribersForPartner', params, data ,null, successCallback,errorCallback);
			}
			
			var getAllRemitsForSubscriber = function(params, data, successCallback,errorCallback){
				RESTSrvc.postForData('getAllRemitsForSubscriber', params, data ,null, successCallback,errorCallback);
			}
			
			var doRemit = function(params, data, successCallback,errorCallback){
				RESTSrvc.postForData('doRemit', params, data ,null, successCallback,errorCallback);
			}
			
			var getAllCoveragePeriodsForPartner = function(params, data, successCallback,errorCallback){
				RESTSrvc.postForData('getAllCoveragePeriodsForPartner', params, data ,null, successCallback,errorCallback);
			}
			
			var getCoverageDetailsSubscribers = function(params, data, successCallback,errorCallback){
				RESTSrvc.postForData('getCoverageDetailsSubscribers', params, data ,null, successCallback,errorCallback);
			}
			
			var savePaymentInfo = function(params, data, transformer, successCallback,errorCallback){
				RESTSrvc.postForData('saveRemitPaymentInfo', params, data ,null, successCallback,errorCallback);
			}
			var getPaymentInfo = function(params, data,transformer, successCallBack, errorCallBack) {
				var resourceKey ='getPaymentInfo';
				RESTSrvc.postForData(resourceKey, params, data, null, successCallBack, errorCallBack);
			};
			
			var getOutstandingAmtForPartnerWithoutIssuerEntityId = function(params, data, successCallback,errorCallback){
				RESTSrvc.postForData('getOutstandingAmtForPartnerWithoutIssuerEntityId', params, data ,null, successCallback,errorCallback);
			}
        	
        	return {
        		getAllRemits : getAllRemits,
				remit : remit,
				getAllSubscribersForPartner :getAllSubscribersForPartner,
				getAllRemitsForSubscriber : getAllRemitsForSubscriber,
				doRemit :  doRemit,
				getAllCoveragePeriodsForPartner : getAllCoveragePeriodsForPartner,
				getCoverageDetailsSubscribers : getCoverageDetailsSubscribers,
				getAllRefunds:getAllRefunds,
				getCustomerRefunds:getCustomerRefunds,
				saveRefunds:saveRefunds,
				savePaymentInfo:savePaymentInfo,
				getPaymentInfo:getPaymentInfo,
				getOutstandingAmtForPartnerWithoutIssuerEntityId:getOutstandingAmtForPartnerWithoutIssuerEntityId
				
        	};
        } ];

	hcentive.WFM.FinancialAccountsService = [
	    '$http',
		'RESTSrvc','$filter',
		function($http, RESTSrvc,$filter) {
			var getAllFinancialAccounts = function(params, data, transformer, successCallback,errorCallback) {
				RESTSrvc.postForData('getAllFinancialAccounts', params ,data,null, successCallback,errorCallback);
				
			};
			
			return {
				getAllFinancialAccounts : getAllFinancialAccounts
			};
		} ];

	hcentive.WFM.FinancialAccountDetailsService = [
 	    '$http',
 		'RESTSrvc','$filter',
 		function($http, RESTSrvc,$filter) {
 			var getFinancialAccountDetails = function(params, data, transformer, successCallback,errorCallback) {
 				RESTSrvc.postForData('getFinancialAccountDetails', params ,data,null, successCallback,errorCallback);
 				
 			};
 			
 			return {
 				getFinancialAccountDetails : getFinancialAccountDetails
 			};
 		} ];
	
	

	
	
    // wireup the service to application
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialsInvoiceService",
        "id": hcentive.WFM.FinancialsInvoiceService
    });
    
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialRemitAdviceService",
        "id": hcentive.WFM.FinancialRemitAdviceService
    });

    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialTransactionService",
        "id": hcentive.WFM.FinancialTransactionService
    });

    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialAccountsService",
        "id": hcentive.WFM.FinancialAccountsService
    });
    
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialAccountDetailsService",
        "id": hcentive.WFM.FinancialAccountDetailsService
    });
	hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialRemitsService",
        "id": hcentive.WFM.FinancialRemitsService
    });
	
})();