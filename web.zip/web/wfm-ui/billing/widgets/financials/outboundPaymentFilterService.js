(function () {
    hcentive.WFM.FinancialsOutboundPaymentsFilterService = [function () {
            return {
            	 getPaymentsFilterConfiguration : function(preSelectedFilters){
    				var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("paymentMode","checkbox", "Payment Method", {enableAll : true}, 
    					{
    						BankAccount :"BankAccount",
    						Card : "Card",
							ACH : "ACH",
							CHK : "Check",
							MoneyOrder : "Money Order",
							'Token-Card' : "Token Card",
							'Token-BankAccount' : "Token Bank Account",
							'OTHER' :'Other',
    					}));
    					defaultFiltersConfig.push(new WFMFilterConfiguration("externalId", "text", "Payment ID", {init:preSelectedFilters.externalId}, {}));
    					defaultFiltersConfig.push(new WFMFilterConfiguration("payeeExternalId", "text", "Partner ID", {init:preSelectedFilters.payeeExternalId}, {}));
    					defaultFiltersConfig.push(new WFMFilterConfiguration("paymentDate", "daterange", "Payment Date", {init:preSelectedFilters.paymentDate}, {}));
    					defaultFiltersConfig.push(new WFMFilterConfiguration("partnerType", "text", "Partner Type", {init:preSelectedFilters.partnerType}, {}));
    					
    				
    				var moreFiltersConfig = [];
    				moreFiltersConfig.push(new WFMFilterConfiguration("status","checkbox", "Status", {enableAll : false}, 
    					{
    						PAYMENT_REQUEST_SUCCESSFULL :"Successful",
    						PAYMENT_REQUEST_FAILED : "Failed",
    						PAYMENT_REQUEST_UNKNOWN : "Unknown"
    					}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("createdBy","text", "Created By", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("amount","range", "Amount", {}, {}));
    				
//    				var searchFilterConfig = new WFMFilterConfiguration("invoiceId", "text", "Invoice Id", {}, {});
    				
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
    			}
        	};
            }
         ];
		 
    // wireup the service to application
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialsOutboundPaymentsFilterService",
        "id": hcentive.WFM.FinancialsOutboundPaymentsFilterService
    });
})();