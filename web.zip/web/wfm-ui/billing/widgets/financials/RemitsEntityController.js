hcentive.WFM.RemitsEntityController = [
		'$scope',
		'FinancialRemitsService',
		'EventBusSrvc',
		'NotifySrvc',
		'$location',
		function($scope, financialsRemitsService, EventBusSrvc, NotifySrvc,
				$location) {
			
			$scope.selectedCountOnPage = 0;
			$scope.totalSelectedCount = '';
			$scope.totalSelectedCountFixd = '';
			$scope.messsageState = 'AllSelected';
			$scope.isExclusion = true;
			$scope.partnerDetails = EventBusSrvc
					.subscribe('remitPartnerDetails');
			$scope.oldIssuerAssignedFilterValue = false;
			$scope.isIssuerAssignedFilter = false;
			$scope.outstandingAmtForPartnerWithoutIssuerEntityId;
			
			$scope.subscriberTableFilters = [ {
				'filterKey' : 'isIssuerAssigned',
				'filterType' : 'TextBox',
				'filterQueryKey' : 'issuerEntityId'
			}];
			
			$scope.isRefeshEntityViewCall = false;
			
			var outstandingAmtSuccessCallback = function(outstandingAmt){
				if(outstandingAmt === 0 ){
					$scope.subscribersList = 'No Data';
					$scope.totalSelectedCount = '';
					$scope.pagination.totalElements = 0;
					$scope.partnerDetails.totalSelectedAmount = 0;	
				}else{
					$scope.outstandingAmtForPartnerWithoutIssuerEntityId = outstandingAmt;
					$scope.partnerDetails.totalSelectedAmount = outstandingAmt;
					getAllSubscribersForPartner();
				}
			}
			
			$scope.getOutstandingAmtForPartnerWithoutIssuerEntityId = function(){
				
				var criteria = {};
				var createdAtFilter = {};
				createdAtFilter.columnValue = $scope.partnerDetails.remitStartTimestamp;
				createdAtFilter.caseSensitiveSearch = "false";
				createdAtFilter.operator = "<=";
				criteria.createdAt = createdAtFilter;
				
				var searchCriteriaJson = {
						'criteria' : criteria,
						'pageRequestCriteria' : null,
						'referenceId' : null
				};

				var params = {
						"partnerId" : $scope.partnerDetails.partnerIdentity
					};
				
				financialsRemitsService.getOutstandingAmtForPartnerWithoutIssuerEntityId(params,
							searchCriteriaJson, outstandingAmtSuccessCallback, errorCallBack);
				
			}
			
			$scope.refeshEntityView = function(){
				resetToDefault();
				$scope.isRefeshEntityViewCall = true;
				$scope.$$childTail['isIssuerAssignedFilter'] = false;
				$scope.$$childTail['filterJson'] = [];
				$scope.$$childTail['pageNumber'] = 1; 
				$scope.pagination = defaultPagination('"exchangeEntityId"','');
				$scope.fetchdata($scope.pagination,{});				
			}
			
			function resetToDefault(){
				$scope.selectedCountOnPage = 0;
				$scope.totalSelectedCount = '';
				$scope.messsageState = 'AllSelected';
				$scope.isExclusion = true;
				$scope.excludedBeMap = new Object();
				$scope.excludedBeMap['IS_EXCLUSION'] = $scope.isExclusion;
				if($scope.isIssuerAssignedFilter){
					$scope.partnerDetails.totalSelectedAmount = $scope.outstandingAmtForPartnerWithoutIssuerEntityId;
				}else{
					$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalPayableAmount;
				}
			}
			
			$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalPayableAmount;
			$scope.excludedBeIds = new Array();
			$scope.excludedBeMap = new Object();
			$scope.isExclusion = true;
			$scope.excludedBeMap['IS_EXCLUSION'] = $scope.isExclusion;
			
			function updateSubscriberList(totalSelectedAmount, selectedBeId,totalSelectedCount) {
				var totalSelectedAmount = totalSelectedAmount;
				var selectedBeId = selectedBeId;
				var rowIndex = 0;
				var checkBoxEventArray = [];
				angular.forEach(
								$scope.subscribersList,
								function(subscriberValue, subscriberKey) {
									var beId = subscriberValue.businessEntityIdentity;
									var beType = subscriberValue.businessEntityType;
									var payableAmount = subscriberValue.payableAmount;

									if (beId == selectedBeId) {

										var isCheckBoxChecked = false;
										if (totalSelectedCount > 0) {
											isCheckBoxChecked = true;
										}
										
										checkBoxEventArray = prepareCheckBoxEventArray('SubscriberRemit_'+rowIndex,isCheckBoxChecked,checkBoxEventArray);
										var previousTotalSelectedAmount = $scope.subscribersList[rowIndex].selectedAmount;
										
										if($scope.subscribersList[rowIndex].isChecked == true && isCheckBoxChecked == false){
											$scope.selectedCountOnPage = $scope.selectedCountOnPage - 1;
											$scope.totalSelectedCount = $scope.totalSelectedCount  - 1;
										}else if($scope.subscribersList[rowIndex].isChecked == false && isCheckBoxChecked == true){
											$scope.selectedCountOnPage = $scope.selectedCountOnPage + 1;
											$scope.totalSelectedCount = $scope.totalSelectedCount  + 1;	
										}
										
										$scope.subscribersList[rowIndex].isChecked = isCheckBoxChecked;
										
										var netAmount = previousTotalSelectedAmount	- totalSelectedAmount;
										subscriberValue.selectedAmount = totalSelectedAmount;
										$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount - netAmount;
												
										if($scope.isExclusion){
											if(payableAmount == totalSelectedAmount && payableAmount != 0){
												delete $scope.excludedBeMap[beId];
												}
										}else{
											if(totalSelectedAmount == 0 && totalSelectedCount == 0){
												delete $scope.excludedBeMap[beId];
												}
											}
									}
									rowIndex = rowIndex + 1;
								});
								updateHeader();
								publishCheckBoxEventArray(checkBoxEventArray);
			}

			$scope.resetMap = function(isAllSelected) {
				
				if(isAllSelected){
					$scope.messsageState='AllSelected';
				}else{
					$scope.messsageState='NotAllSelected';
				}
			
				$scope.isExclusion = isAllSelected;
				$scope.excludedBeMap = new Object();
				var rowIndex = 0;
				$scope.excludedBeMap['IS_EXCLUSION'] = isAllSelected;
				
				if(isAllSelected){
					$scope.totalSelectedCount = $scope.totalSelectedCountFixd;
				}else{
					$scope.totalSelectedCount = $scope.totalSelectedCount + $scope.subscribersList.length - $scope.selectedCountOnPage;
				}

				$scope.selectedCountOnPage = 0;
				var checkBoxEventArray = [];
				angular
						.forEach(
								$scope.subscribersList,
								function(subscriberValue, subscriberKey) {
									var beId = subscriberValue.businessEntityIdentity;
									var beType = subscriberValue.businessEntityType;
									var payableAmount = subscriberValue.payableAmount;
									subscriberValue.isChecked = isAllSelected;
									checkBoxEventArray = prepareCheckBoxEventArray('SubscriberRemit_' + rowIndex , $scope.isExclusion,checkBoxEventArray);
									if ($scope.isExclusion) {
										$scope.selectedCountOnPage = $scope.selectedCountOnPage + 1;
										
										if($scope.isIssuerAssignedFilter){
											$scope.partnerDetails.totalSelectedAmount = $scope.outstandingAmtForPartnerWithoutIssuerEntityId;
										}else{
											$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalPayableAmount;
										}
										
										subscriberValue.selectedAmount = subscriberValue.payableAmount;
									} else {
										delete $scope.excludedBeMap[beId];
										$scope.partnerDetails.totalSelectedAmount = 0;
										subscriberValue.selectedAmount = 0;
									}
									delete $scope.excludedBeMap[beId];
									rowIndex = rowIndex + 1;
								});
					publishCheckBoxEventArray(checkBoxEventArray);
					publishCheckBoxEvent('selectAllFromHeader',isAllSelected);
						
			}
			
			function updateTotalSelectedCount(isAllSelected){
				if(isAllSelected){
					$scope.totalSelectedCount = $scope.totalSelectedCountFixd;
				}else{
					$scope.totalSelectedCount = $scope.totalSelectedCount + $scope.subscribersList.length - $scope.selectedCountOnPage;
				}
			}
			


			$scope.updateExclusionData = function(isAdded, beId,isUpdateHeader,isSelectionCntUpdateReq) {
					$scope.excludedBeMap = updateExclusionMap(isAdded, beId,$scope.excludedBeMap, $scope.isExclusion);
					if(isSelectionCntUpdateReq){					
						selectionCountOnPageFn(isAdded)
					}
					if(isUpdateHeader == undefined || (isUpdateHeader!= undefined && isUpdateHeader)){
						updateHeader();
					}
			}
			
			function selectionCountOnPageFn(isAdded){
				if ($scope.isExclusion) {
					if(!isAdded){
						$scope.selectedCountOnPage = $scope.selectedCountOnPage - 1;
						$scope.totalSelectedCount = $scope.totalSelectedCount  - 1;
					}else{
						$scope.selectedCountOnPage = $scope.selectedCountOnPage + 1;
						$scope.totalSelectedCount = $scope.totalSelectedCount  + 1;
						}
				}else{
					if(isAdded){
						$scope.selectedCountOnPage = $scope.selectedCountOnPage + 1;
						$scope.totalSelectedCount = $scope.totalSelectedCount  + 1;
					}else{
						$scope.selectedCountOnPage = $scope.selectedCountOnPage - 1;
						$scope.totalSelectedCount = $scope.totalSelectedCount  - 1;
						}
				}
			}

			function updateHeader(){
				if($scope.selectedCountOnPage == $scope.subscribersList.length ){
					publishCheckBoxEvent('selectAllFromHeader',true);
				}else{
					publishCheckBoxEvent('selectAllFromHeader',false);
				}
			}
			
			
			var successCallback = function(data) {
				if (data != null && data != undefined) {
					if (data.content.length == 0) {
						$scope.subscribersList = 'No Data';
						$scope.totalSelectedCount = '';
						$scope.pagination.totalElements = 0;
						$scope.partnerDetails.totalSelectedAmount = 0;
					} else {
						$scope.pagination.totalElements = data.totalElements;
						if($scope.totalSelectedCount === '' || ($scope.oldIssuerAssignedFilterValue != $scope.isIssuerAssignedFilter)){
							resetToDefault(); 	
							$scope.oldIssuerAssignedFilterValue = $scope.isIssuerAssignedFilter;
							$scope.totalSelectedCount = data.totalElements;
							$scope.totalSelectedCountFixd = data.totalElements;
						}
						$scope.pagination.totalNoPages = data.totalPages;
						$scope.subscribersList = subscriberRemitTransformer(
								data.content, $scope.excludedBeMap,
								$scope.isExclusion);
						var rowIndex = 0;
						var checkBoxEventArray = [];
						angular
								.forEach(
										$scope.subscribersList,
										function(subscriberValue, subscriberKey) {
											
											if(subscriberValue.isChecked){
												$scope.selectedCountOnPage = $scope.selectedCountOnPage +1;
											}
											
											if($scope.isRefeshEntityViewCall){
												checkBoxEventArray = prepareCheckBoxEventArray('SubscriberRemit_'+rowIndex,true,checkBoxEventArray);
												rowIndex =rowIndex +1;
											}
											
										});
						publishCheckBoxEventArray(checkBoxEventArray);
						$scope.isRefeshEntityViewCall = false;
						updateHeader();
					}
				} else {
					$scope.subscribersList = 'No Data';
				}
			}

			var errorCallBack = function() {
				$scope.subscribersList = 'No Data';
			}

			$scope.updateSubscriberAmount = function(rowIndex, isSelected) {
				var selectedAmount = 0;
				var beId = $scope.subscribersList[rowIndex].businessEntityIdentity;
				$scope.subscribersList[rowIndex].isChecked = isSelected;
				if (isSelected) {
					var index = $scope.excludedBeIds.indexOf(beId);
					var previousSelectedAmount = $scope.subscribersList[rowIndex].selectedAmount;
					$scope.excludedBeIds.splice(index, 1);
					selectedAmount = $scope.subscribersList[rowIndex].payableAmount;
					if (!isNaN(selectedAmount)) {
						selectedAmount = parseFloat(selectedAmount);
					}
					$scope.subscribersList[rowIndex].selectedAmount = selectedAmount;
					$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount
							+ selectedAmount - previousSelectedAmount;
				} else {
					selectedAmount = $scope.subscribersList[rowIndex].selectedAmount;
					if (!isNaN(selectedAmount)) {
						selectedAmount = parseFloat(selectedAmount);
					}
					$scope.subscribersList[rowIndex].selectedAmount = 0;
					$scope.excludedBeIds.push(beId);
					$scope.partnerDetails.totalSelectedAmount = $scope.partnerDetails.totalSelectedAmount
							- selectedAmount;
				}
			}
			
			
			$scope.selectAllFromHeaderFn = function(
					selectAllFromHeader) {
				
				var rowIndex = 0;
						angular
						.forEach(
								$scope.subscribersList,
								function(subscriberValue, subscriberKey) {
									var beId = subscriberValue.businessEntityIdentity;
									var beType = subscriberValue.businessEntityType;
									subscriberValue.isChecked = selectAllFromHeader;
									publishCheckBoxEvent('SubscriberRemit_' + rowIndex , selectAllFromHeader);
									var payableAmount = subscriberValue.payableAmount;
									var isChecked = isCheckBoxSelected(beId,selectAllFromHeader);
									$scope.updateExclusionData(selectAllFromHeader,beId,false,isChecked);
									$scope.updateSubscriberAmount(rowIndex,selectAllFromHeader);
									rowIndex =rowIndex +1;
						});
				
			}
			
			
			function isCheckBoxSelected(beId,selectAllFromHeader){
				var isExclusion = $scope.excludedBeMap['IS_EXCLUSION'];
				if(isExclusion){
					if(selectAllFromHeader){
						if($scope.excludedBeMap[beId]){
							return true;
						}else{
							return false;
						}						
					}else{
						if($scope.excludedBeMap[beId] && $scope.excludedBeMap[beId]['TOTAL_SELECTED_COUNT'] && $scope.excludedBeMap[beId]['TOTAL_SELECTED_COUNT'] === 0){
							return false;
						}else{
							return true;
						}	
					}
				}else{
					if(selectAllFromHeader){
						if($scope.excludedBeMap[beId]){
							return false;
						}else{
							return true;
						}						
					}else{
						if($scope.excludedBeMap[beId]){
							return true;
						}else{
							return false;
						}	
					}
				}
			}
			
			

			var getAllSubscribersForPartner = function() {
				$scope.selectedCountOnPage = 0;
				var searchCriteriaJson = {
					'criteria' : populateSearchCriteria($scope.filterObject),
					'pageRequestCriteria' : getPageRequestCriteria($scope.pagination),
					'referenceId' : null
				};
				
				var params = {
					"partnerId" : $scope.partnerDetails.partnerIdentity
				};
				financialsRemitsService.getAllSubscribersForPartner(params,
						searchCriteriaJson, successCallback, errorCallBack);
			}

			$scope.pagination = defaultPagination('"exchangeEntityId"',
					'');
			
			$scope.fetchdata = function(paginationObj, filterObj,searchCall) {
				$scope.filterObject = filterObj;
				$scope.pagination = paginationObj;
				
				if(searchCall === 'search'){
					$scope.isRefeshEntityViewCall = true;
					if(filterObj!= undefined && filterObj.length > 0 && filterObj[0]['issuerEntityId'] == "true"){
						$scope.getOutstandingAmtForPartnerWithoutIssuerEntityId();
						return;
					}
				}
				
				getAllSubscribersForPartner();
			}
			
			

			function populateSearchCriteria(filterObj) {
				
				var criteria = {};
				var createdAtFilter = {};
				createdAtFilter.columnValue = $scope.partnerDetails.remitStartTimestamp;
				createdAtFilter.caseSensitiveSearch = "false";
				createdAtFilter.operator = "<=";
				criteria.createdAt = createdAtFilter;
				
				if(filterObj!= undefined && filterObj.length > 0 && filterObj[0]['issuerEntityId'] == "true"){
					var issuerEntityIdFilter = {};
					issuerEntityIdFilter.columnValue = " IS NOT NULL ";
					issuerEntityIdFilter.caseSensitiveSearch = "false";
					issuerEntityIdFilter.operator = "=";
					criteria.issuerEntityId = issuerEntityIdFilter;
					$scope.isIssuerAssignedFilter = true;
				}else{
					$scope.isIssuerAssignedFilter = false;
				}
				return criteria;
			}

			$scope.remitSubscriberTableHeaders = [
					{
						'isSortable' : 'no',
						'key' : 'selectSubscriber',
						'desc' : '',
						'contentType' : 'html',
						'value' : '<input type="checkbox" ng-init ="selectAllFromHeader=true" ng-model="selectAllFromHeader" name="selectAllFromHeader" id="selectAllFromHeader" ng-change="selectAllFromHeaderFn(selectAllFromHeader)">'
					}, {
						'isSortable' : 'yes',
						'key' : 'exchangeEntityId',
						'desc' : 'Exchange Entity ID',
						'contentType' : 'String',
						'sortableKey' : '"exchangeEntityId"'
					}, {
						'isSortable' : 'yes',
						'key' : 'issuerEntityId',
						'desc' : 'Issuer Entity ID',
						'contentType' : 'String',
						'sortableKey' : '"issuerEntityId"'
					}, {
						'isSortable' : 'yes',
						'key' : 'businessEntityName',
						'desc' : 'Entity Name',
						'contentType' : 'String',
						'sortableKey' : '"businessEntityName"'
					}, {
						'isSortable' : 'yes',
						'key' : 'businessEntityType',
						'desc' : 'Entity Type',
						'contentType' : 'String',
						'sortableKey' : '"businessEntityType"'
					}, {
						'isSortable' : 'yes',
						'key' : 'payableAmount',
						'desc' : 'Payable Amount',
						'contentType' : 'Currency',
						'sortableKey' : '"outstandingAmount"'
					}, {
						'isSortable' : 'no',
						'key' : 'selectedAmount',
						'desc' : 'Selected Amount',
						'contentType' : 'Currency'
					}, {
						'isSortable' : 'no',
						'key' : 'detailAction',
						'desc' : '',
						'contentType' : 'html'
					} ];

			var launchSubscriberDetailPopup = function(exchangeEntityId) {
				NotifySrvc({
					id : 'simpleDialog',
					templateUrl : 'views/financials/remit-advice-detail.html',
					title : exchangeEntityId,
					backdrop : true,
					closeButton : true,
					controller : 'RemitsEntityDetailController',
					css : {
						'top' : '5%',
						'left' : '15%',
						'margin' : '0 auto',
						'width' : '1000'
					},
					success : {
						label : 'Blank',
						fn : function() {
							$scope.updateSubscriberDetails(
									this.totalSelectedAmount,
									this.tempExcludedMap,
									this.subscriberDetails.businessEntityIdentity,this.totalSelectedCount)
						}
					}
				});
			}

			$scope.updateSubscriberDetails = function(
					totalSelectedAmount, excludedMap, beId,totalSelectedCount) {
				$scope.excludedBeMap = excludedMap;
				
				if($scope.excludedBeMap[beId] != undefined){
					$scope.excludedBeMap[beId]['SELECTED_AMOUNT'] = totalSelectedAmount;
				}
				
				updateSubscriberList(totalSelectedAmount, beId,totalSelectedCount);
			}

			$scope.publishSubscriberDetail = function(remitSubscriberDetails,
					rowIndex) {
				$scope.remitSubscriberDetails = remitSubscriberDetails;
				$scope.remitSubscriberDetails.rowIndex = rowIndex;
				var remitDetails = {
					"remitSubscriberDetails" : $scope.remitSubscriberDetails,
					"partnerDetails" : $scope.partnerDetails,
					"excludedBeMap" : $scope.excludedBeMap,
					"isExclusion" : $scope.isExclusion,
					"isExcludeBlankIssuerEntityId" : $scope.isIssuerAssignedFilter
				};
				EventBusSrvc.publish('remitDetails', remitDetails);
				launchSubscriberDetailPopup(remitSubscriberDetails.exchangeEntityId);
			}
			
			function publishCheckBoxEvent(key,value){
				var data = {};
				data.key = key;
				data.value = value;
				$scope.$broadcast('checkBoxEvent', data);
				}
			
			function prepareCheckBoxEventArray(key,value,array){
     			var data = {};
				data.key = key;
				data.value = value;
				array.push(data);
				return array;
     		}
     		
     		 
     		function publishCheckBoxEventArray(checkBoxArray){
     			if(checkBoxArray){
     				$scope.$broadcast('checkBoxEvent', checkBoxArray);
     			}
     		}
     		
		} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'RemitsEntityController',
	'id' : hcentive.WFM.RemitsEntityController
});