/**
 * Created by Dikshit.Vaid on 6/10/2014.
 */
(function() {
	hcentive.WFM.FinancialsInvoiceController = [
	'$scope',
	'$location',
	'FinancialsInvoiceService',
	'IndividualServ',
	'EventBusSrvc',
	'FinancialTransactionService',
	'FinancialsFilterConfigService',
	'$translate',
	'FinancialsInvoiceHelperService',
	'GroupServ',
	function($scope, $location, FinancialsInvoiceService,
			IndividualServ, EventBusSrvc,FinancialTransactionService,FinancialsFilterConfigService,$translate,FinancialsInvoiceHelperService,GroupServ) {
		
		$scope.preSelectedFilters = {};
		$scope.onLoadFetchData = true;
		var isResetCalled = false;		
		
		/*Page back*/
		$scope.pageBackFilters = EventBusSrvc.subscribeAndInvalidatePayload('pageBackFilters'); //clearing page back URL from event bus
		if($scope.pageBackFilters){
			$scope.onLoadFetchData = false;
			$scope.preSelectedFilters = $scope.pageBackFilters;
			$scope.invoiceFilter = $scope.pageBackFilters;
		}
		/*Page back*/
			
		var goToRelatedBeEntity = EventBusSrvc.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
		if(goToRelatedBeEntity != undefined && goToRelatedBeEntity !=''){
			$scope.preSelectedFilters['beId'] =  goToRelatedBeEntity;
			$scope.onLoadFetchData = false;
			$scope.invoiceFilter = $scope.preSelectedFilters;
		}
		
		var invoiceExternalId = EventBusSrvc.subscribeAndInvalidatePayload('invoiceExternalId');
		if(invoiceExternalId != null && invoiceExternalId != undefined && invoiceExternalId !=''){
			$scope.preSelectedFilters['externalId'] =  invoiceExternalId;
			$scope.onLoadFetchData = false;
			$scope.invoiceFilter = $scope.preSelectedFilters;
		}
		
		var goToRelatedBAExternalId = EventBusSrvc
		.subscribeAndInvalidatePayload('goToRelatedBAExternalId');
		if(goToRelatedBAExternalId != undefined && goToRelatedBAExternalId !=''){
			$scope.preSelectedFilters['subscription'] =  goToRelatedBAExternalId;
			$scope.onLoadFetchData = false;
			$scope.invoiceFilter = $scope.preSelectedFilters;
		}
		
		var pageIndex = 0;
	    $scope.exportHandler = function(filterData){
	    	$scope.isExportCall = true;
	    	pageIndex  = $scope.pagination.pageIndex;
	    	$scope.pagination = setExportPageSize($scope.pagination);
	    	$scope.fetchdata($scope.pagination, buildCriteria($scope.filterList,filterData));
	    };
	    
	    $scope.handleSearch = function(filterData,filterReset){
	    	console.log('handleSearch called');
	        if(filterReset){
	    		isResetCalled = filterReset;
	    	}
	    	$scope.handleChange(filterData);
	    };
	    
	    $scope.handleChange = function(filterData){
	    	console.log('handleChange called');
	    	$scope.pageBackFilters = filterData;
	    	$scope.invoiceFilter = JSON.parse(JSON.stringify(filterData));
	    };
		
		$scope.invoiceList = [];
		$scope.pageType = '';
		$scope.setPageType = function(pageType){
			$scope.pageType = pageType;
			$scope.filterBoxConfig = FinancialsFilterConfigService.getInvoiceFilterConfiguration($scope.preSelectedFilters,pageType);
		}
		$scope.pagination = defaultPagination(
				'wfmInvoice.summary.generationDate', 'desc');
		var billCycleIdentity = EventBusSrvc
				.subscribeAndInvalidatePayload('billCycleIdentity');
		var beIdentity = EventBusSrvc
				.subscribeAndInvalidatePayload('beIdentity');
	// function is used to find the financial txns corresponding to invoice id and then to redirect to  'financials-transactions-report' page.
		$scope.getAllFinancialTxnsForInvoiceIdentity = function(invoiceId) {
			if(invoiceId !=null){
			var params = {
				'invoiceId' : invoiceId
			};
			}
			FinancialTransactionService.getFinancialTxnsForInvoiceId(
					params, successCallback,errorCallback);
		};
		var successCallback = function(data) {
		$location.path("financials/financials-transactions-report");
		$location.replace();
		var payload = {};
		payload.data = data;
		EventBusSrvc.publish('fetchFTEntry', payload);
		};
		
		var errorCallback = function(data) {
		$location.path("financials/financials-transactions-report");
		$location.replace();
		EventBusSrvc.publish('fetchFTEntry', data);
		};
		
		$scope.individualheaderList = FinancialsInvoiceHelperService.getIndividualInvoiceHeaders();
		$scope.groupHeaderList= FinancialsInvoiceHelperService.getGroupInvoiceHeaders();
		$scope.partnerHeaderList= FinancialsInvoiceHelperService.getPartnerInvoiceHeaders();
		
		$scope.filterList = FinancialsInvoiceHelperService.getFilterList();
		
		var isEmptyStr = function(str) {
			return (!str || 0 === str.length);
		}
		$scope.fetchdata = function(paginationObj, filterObj, callType) {
			filterObj = filterObj || {};
			
			if (callType != null && callType != undefined
					&& callType == 'search') {
				billCycleIdentity = null;
				beIdentity = null;
				//goToRelatedBEIdentity = null;
				//goToRelatedBeEntity =null;
			}
			
			$scope.updateLeftNav('Invoices');
			$scope.pagination = paginationObj;
			$scope.filterJson = filterObj;
			var crit = $scope.populateSearchCriteria();
			$scope.getAllFinancialsInvoicesForAdmin(angular
					.toJson(crit));
		};
		$scope.populateSearchCriteria = function() {
			var searchCriteriaJson = {};
			var criteria = {};
			// populate pageRequestCriteria
			searchCriteriaJson.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
			
			if($scope.filterJson.length == 0){
				criteria = {};
			}else{
				criteria = $scope.filterJson;
			}
			
			
			searchCriteriaJson.criteria =  criteria;
			searchCriteriaJson.criteria['beType'] = {
					'operator' : '=',
					'columnValue' :  $scope.pageType ,
					'caseSensitiveSearch' : 'false'
			};
			
			
			if (billCycleIdentity != null
					&& billCycleIdentity != undefined
					&& billCycleIdentity != '') {
				searchCriteriaJson.referenceId = billCycleIdentity;
			}

			if (beIdentity != null && beIdentity != undefined
					&& beIdentity != '' && (isResetCalled==false)) {
				searchCriteriaJson.criteria['beIdentity'] = {
					'operator' : '=',
					'columnValue' : beIdentity,
					'caseSensitiveSearch' : 'false'
				};
			}
			
			if (goToRelatedBeEntity != null
					&& goToRelatedBeEntity != undefined
					&& goToRelatedBeEntity != '' && (isResetCalled==false)) {
				searchCriteriaJson.criteria['beId'] = {
					'operator' : '=',
					'columnValue' : goToRelatedBeEntity,
					'caseSensitiveSearch' : 'false'
				};
			}
			if (goToRelatedBAExternalId != null
					&& goToRelatedBAExternalId != undefined
					&& goToRelatedBAExternalId != '' && (isResetCalled==false)) {
				searchCriteriaJson.criteria['subscription'] = {
					'operator' : '=',
					'columnValue' : goToRelatedBAExternalId,
					'caseSensitiveSearch' : 'false'
				};
			}
			var projectedFields = $scope
					.fetchProjectedFieldsForInvoice();
			searchCriteriaJson.projectedFields = projectedFields;
			return searchCriteriaJson;
		}

		$scope.fetchProjectedFieldsForInvoice = function() {return FinancialsInvoiceHelperService.getProjectedFieldsForInvoice();}
		
		$scope.getAllFinancialsInvoicesForAdmin = function(criteria) {
			if (criteria === null) {
				criteria = {
					'criteria' : {}
				};
			}
			FinancialsInvoiceService.getAllFinancialsInvoicesForAdmin(
					criteria, getAllFinancialsInvoicesForAdminSuccess,
					getAllFinancialsInvoicesForAdminError);
		};
		var getAllFinancialsInvoicesForAdminError = function(data) {
			$scope.isExportCall = false;
			$scope.pagination = setDefaultPageSize($scope.pagination,pageIndex);
			$scope.invoiceList = 'No Data';
		};
		var getAllFinancialsInvoicesForAdminSuccess = function(data) {
			var startTime = (new Date()).getTime();
			$scope.invoiceList = [];
			
			if (data != null && data != undefined) {
				if($scope.isExportCall){
					$scope.isExportCall = false;
			    	var exportData = {};
			    	exportData.fileName = 'Invoices';
			    	exportData.data = invoiceTransformer(data);
			    	$scope.pagination = setDefaultPageSize($scope.pagination,pageIndex);
			    	$scope.$broadcast('exportEvent', exportData);
					return;
				}
				$scope.invoiceList = invoiceTransformer(data);
				$scope.pagination.totalElements = data.totalElements;
				$scope.pagination.totalNoPages = data.totalPages;
								if (!($scope.invoiceList != null
						&& $scope.invoiceList != undefined
						&& $scope.invoiceList.length > 0)) {
					$scope.invoiceList = 'No Data';
				}
			} else {
				$scope.invoiceList = 'No Data';
			}
			var endtime = (new Date()).getTime();
			var total = (endtime - startTime) / 1000;
		};
		
		var invoiceTransformer = function(data){
			var invoiceList = [];
			angular
			.forEach(
					data.content,
					function(value, key) {
						var invoiceObject = FinancialsInvoiceHelperService.getInvoiceTransformer(value,$scope,'invoice');
						invoiceList.push(invoiceObject);
					});
			return invoiceList;
		}
		
		$scope.viewBEDetails = function(id, beType, beExternalId, beIdentity) {
			//alert(id +'   '+ beType);
			var param = {
				'id' : id,
				'type' : 'be'
			};
			
			var pageBackURL = '';
			var generateLeftNavFor = 'Entities';
			var updatedLeftNav = '';
			var redirectPath = '';
			var dataKey = '';
			

			if (beType == 'Individual') {
				pageBackURL = 'financials/invoices/individuals';
				updatedLeftNav = 'Individuals';
				redirectPath = 'entities/individual/individual-details';
				dataKey = 'individualDetails';
			} else if (beType == 'Group') {
				pageBackURL = 'financials/invoices/groups';
				updatedLeftNav = 'Groups';
				redirectPath = 'entities/group/group-details';
				dataKey = 'groupDetails';
			}else if(beType == 'Partner'){
				pageBackURL = 'financials/invoices/partners'; 
				updatedLeftNav = 'Health Plans';
				redirectPath = 'entities/healthPlanProvider/health-plans-details';
				dataKey = 'healthPlanProviderDetails';
			}

			var success = function(data) {
				EventBusSrvc.publish(dataKey, data.item);
				EventBusSrvc.publish('goToRelatedBEIdentity', beIdentity);
				EventBusSrvc.publish('BEmetaInfo', data.itemMetaInfo);
				EventBusSrvc.publish('goToRelatedBEExternalId', beExternalId);
				EventBusSrvc.publish('pageBackURL', pageBackURL);
				$scope.generateLeftNav(generateLeftNavFor);
				$scope.updateLeftNav(updatedLeftNav);
				$location.path(redirectPath);
				$location.replace();
			}
			var fail = function(data) {
				EventBusSrvc.publish(dataKey, null);
				EventBusSrvc.publish('goToRelatedBEIdentity', beIdentity);
				EventBusSrvc.publish('goToRelatedBEExternalId', beExternalId);
				EventBusSrvc.publish('pageBackURL', pageBackURL);
				$scope.generateLeftNav(generateLeftNavFor);
				$scope.updateLeftNav(updatedLeftNav);
				$location.path(redirectPath);
				$location.replace();
			}

			IndividualServ.viewIndividual(param, success, fail);

		}

		$scope.viewBillCycleDetails = function(refId) {
			EventBusSrvc.publish('billCycleIdentity', refId);
			EventBusSrvc.publish('beTypeFromInvoiceListing', $scope.pageType);
			$location.path('/system/bill-cycle');
			$location.replace();

		}

		$scope.showMemberDetails = function(invoice, identity, beType, beId, beIdentity, billPeriod, name,status,invType,dueDate,generationDate,subscription) {
			EventBusSrvc.publish('pageBackFilters',$scope.pageBackFilters);
			var invoiceDetail = {
					"identity" : identity,
					"type" : beType,
					"beId" : beId,
					"beIdentity" : beIdentity,
					"billPeriod" : billPeriod,
					"name" : name,
					"status":status,
					"invoiceType":invType,
					"dueDate":dueDate,
					"generationDate":generationDate,
					"subscription":subscription
			};
			console.log(JSON.stringify(invoiceDetail));
			EventBusSrvc.publish('invoiceDetail', invoiceDetail);
		}
		
		
		$scope.viewFinancialSummaryDetails = function(id,beExternalId,baExternalId){
			if(beExternalId) {
				EventBusSrvc.publish('goToRelatedBEExternalId', beExternalId);
			}
			if(baExternalId){
				EventBusSrvc.publish('goToRelatedBAExternalId',baExternalId);
			}
			
			var param = {"id" : id,"type":'be'};
			GroupServ.viewGroup(param,afterSuccessGrpSubscriptionDetail,afterFail);
			
		};
		
		var afterSuccessGrpSubscriptionDetail =function(data){
			transformDetailFor_Group(data);
			$location.path('entities/group/financial-summary-Subscription');
			$location.replace();
		};
		
		var transformDetailFor_Group = function(data){
			$scope.businessEntity = data.item;
			if(data.itemMetaInfo){
			$scope.businessEntity.source = data.itemMetaInfo.tenant;
			}
			EventBusSrvc.publish('groupDetails', $scope.businessEntity);
			if($scope.businessEntity.groupCustomer!=undefined && $scope.businessEntity.groupCustomer!=null)
			var WriteOffJson={'id':$scope.businessEntity.groupCustomer.id.id,'firstName':$scope.businessEntity.groupCustomer.establishmentName,'lastName':""};
		    EventBusSrvc.publish('WriteOffParameters',WriteOffJson);
		    EventBusSrvc.publish('billable',$scope.businessEntity.groupCustomer.billable);
		}
		
		var afterFail = function(){}

	} ];
	
	
	hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		'name' : 'FinancialsInvoiceCntrl',
		'id' : hcentive.WFM.FinancialsInvoiceController
	});
})();
