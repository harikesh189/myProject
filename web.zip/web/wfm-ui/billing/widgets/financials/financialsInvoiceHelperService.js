(function() {
	hcentive.WFM.FinancialsInvoiceHelperService = [
			'$translate',
			function($translate) {

				return {
					getProjectedFieldsForInvoice : function() {

						var projectedFields = [];
						var projectFieldForInvoiceIdentity = {
							"entityField" : "wfmInvoice.identity",
							"mappedField" : "invoiceId"
						};
						projectedFields.push(projectFieldForInvoiceIdentity);
						var projectFieldBE = {
							"entityField" : "wfmInvoice.summary.generatedFor.owner.externalId",
							"mappedField" : "beId"
						};
						projectedFields.push(projectFieldBE);
						var projectFieldBillingAccountId = {
								"entityField" : "wfmInvoice.summary.generatedFor.externalId",
								"mappedField" : "subscription"
							};
							projectedFields.push(projectFieldBillingAccountId);
						var projectFieldBEIdentity = {
							"entityField" : "wfmInvoice.summary.generatedFor.owner.identity",
							"mappedField" : "beIdentity"
						};
						projectedFields.push(projectFieldBEIdentity);
						var projectedFieldName = {
							"entityField" : "wfmInvoice.summary.generatedFor.owner.profile.name",
							"mappedField" : "name"
						};
						projectedFields.push(projectedFieldName);

						var projectedFieldBillPeriod = {
							"entityField" : "wfmInvoice.summary.billPeriod",
							"mappedField" : "billPeriod"
						};
						projectedFields.push(projectedFieldBillPeriod);
						var projectedFieldGenerationDate = {
							"entityField" : "wfmInvoice.summary.generationDate",
							"mappedField" : "generationDate"
						};
						projectedFields.push(projectedFieldGenerationDate);
						var projectedFieldDueDate = {
							"entityField" : "wfmInvoice.summary.dueDate",
							"mappedField" : "dueDate"
						};
						projectedFields.push(projectedFieldDueDate);
						var projectedFieldStatus = {
							"entityField" : "wfmInvoice.status",
							"mappedField" : "status"
						};
						projectedFields.push(projectedFieldStatus);
						var projectedFieldAmount = {
							"entityField" : "wfmInvoice.summary.currentBillAmount",
							"mappedField" : "currentBillAmount"
						};
						projectedFields.push(projectedFieldAmount);
						var projectedFieldBEType = {
							"entityField" : "wfmInvoice.summary.generatedFor.owner.type",
							"mappedField" : "beType"
						};
						projectedFields.push(projectedFieldBEType);
						var projectedFieldBEecordId = {
							"entityField" : "wfmInvoice.summary.generatedFor.owner.itemRecordId",
							"mappedField" : "beItemRecordId"
						};
						projectedFields.push(projectedFieldBEecordId);
						var projectFieldForexternalId = {
							"entityField" : "wfmInvoice.externalId",
							"mappedField" : "externalId"
						};
						projectedFields.push(projectFieldForexternalId);
						var projectedFieldPaidAmount = {
							"entityField" : "wfmInvoice.summary.paidAmount",
							"mappedField" : "paidAmount"
						};
						projectedFields.push(projectedFieldPaidAmount);
						var projectedFieldPaidAmount = {
							"entityField" : "wfmInvoice.invoiceType",
							"mappedField" : "invoiceType"
						};
						projectedFields.push(projectedFieldPaidAmount);
						var projectedFieldsReferenceId = {
							"entityField" : "reference.referenceId",
							"mappedField" : "billCycleIdentity"
						};
						projectedFields.push(projectedFieldsReferenceId);


						var projectedFieldsModifiedBy = {
								"entityField" : "wfmInvoice.auditInfo.modifiedByName",
								"mappedField" : "modifiedBy"
						};
						projectedFields.push(projectedFieldsModifiedBy);

							
						return projectedFields;
					},
					
					getIndividualInvoiceHeaders : function(){
						return [
										{
											'isSortable' : 'yes',
											'key' : 'externalId',
											'desc' : 'Invoice ID',
											'contentType' : 'String',
											'sortableKey' : 'wfmInvoice.externalId'
										},
										{
											'isSortable' : 'yes',
											'key' : 'entityId',
											'desc' : 'Subscriber ID',
											'contentType' : 'html',
											'sortableKey' : 'wfmInvoice.summary.generatedFor.owner.externalId',
											'isExportable' : true
										},
										{
											'isSortable' : 'yes',
											'key' : 'entityName',
											'desc' : 'Subscriber Name',
											'contentType' : 'String',
											'sortableKey' : 'wfmInvoice.summary.generatedFor.owner.profile.name'
										},
										{
											'isSortable' : 'yes',
											'key' : 'billCycleName',
											'desc' : 'Billing Period',
											'contentType' : 'String',
											'sortableKey' : 'wfmInvoice.summary.billPeriod.beginsOn',
											'isExportable' : true,
											 // 'style' : 'width:100px
												// important'
										},
										{
											'isSortable' : 'yes',
											'key' : 'invoiceDate',
											'desc' : 'Bill Generation Date',
											'contentType' : 'html',
											'sortableKey' : 'wfmInvoice.summary.generationDate',
											'isExportable' : true
										},
										{
											'isSortable' : 'yes',
											'key' : 'dueDate',
											'desc' : 'Due Date',
											'contentType' : 'Date',
											'sortableKey' : 'wfmInvoice.summary.dueDate'
										},
										{
											'isSortable' : 'yes',
											'key' : 'amount',
											'desc' : 'Amount',
											'contentType' : 'Currency',
											'sortableKey' : 'wfmInvoice.summary.currentBillAmount'
										},{
											'isSortable' : 'yes',
											'key' : 'paidAmount',
											'desc' : 'Paid Amount',
											'contentType' : 'Currency',
											'sortableKey' : 'wfmInvoice.summary.paidAmount'
										}, {
											'isSortable' : 'yes',
											'key' : 'status',
											'desc' : 'Status',
											'contentType' : 'String',
											'sortableKey' : 'status'
										}/*, {
											'isSortable' : 'yes',
											'key' : 'modifiedByName',
											'desc' : 'User',
											'contentType' : 'String',
											'sortableKey' : 'wfmInvoice.auditInfo.modifiedByName'
										}*/, {
											'isSortable' : 'yes',
											'key' : 'invoiceType',
											'desc' : 'Invoice Type',
											'contentType' : 'String',
											'sortableKey' : 'invoiceType'
										}, {
											'isSortable' : 'no',
											'key' : 'action',
											'desc' : 'Actions',
											'contentType' : 'html'
										} ];
					},
					getGroupInvoiceHeaders : function(){
						
						return [
								{
									'isSortable' : 'yes',
									'key' : 'externalId',
									'desc' : 'Invoice ID',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.externalId'
								},
								{
									'isSortable' : 'yes',
									'key' : 'entityId',
									'desc' : 'Group ID',
									'contentType' : 'html',
									'sortableKey' : 'wfmInvoice.summary.generatedFor.owner.externalId',
									'isExportable' : true
								},
								{
									'isSortable' : 'yes',
									'key' : 'entityName',
									'desc' : 'Group Name',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.summary.generatedFor.owner.profile.name'
								},
								{
									'isSortable' : 'yes',
									'key' : 'subscription',
									'desc' : 'Billing Account',
									'contentType' : 'html',
									'sortableKey' : 'wfmInvoice.summary.generatedFor.externalId'
								},
								{
									'isSortable' : 'yes',
									'key' : 'billCycleName',
									'desc' : 'Billing Period',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.summary.billPeriod.beginsOn, wfmInvoice.summary.billPeriod.endsOn',
									'isExportable' : true
								},
								{
									'isSortable' : 'yes',
									'key' : 'invoiceDate',
									'desc' : 'Bill Generation Date',
									'contentType' : 'html',
									'sortableKey' : 'wfmInvoice.summary.generationDate',
									'isExportable' : true
								},
								{
									'isSortable' : 'yes',
									'key' : 'dueDate',
									'desc' : 'Due Date',
									'contentType' : 'Date',
									'sortableKey' : 'wfmInvoice.summary.dueDate'
								},
								{
									'isSortable' : 'yes',
									'key' : 'amount',
									'desc' : 'Amount',
									'contentType' : 'Currency',
									'sortableKey' : 'wfmInvoice.summary.currentBillAmount'
								},{
									'isSortable' : 'yes',
									'key' : 'paidAmount',
									'desc' : 'Paid Amount',
									'contentType' : 'Currency',
									'sortableKey' : 'wfmInvoice.summary.paidAmount'
								}, {
									'isSortable' : 'yes',
									'key' : 'status',
									'desc' : 'Status',
									'contentType' : 'String',
									'sortableKey' : 'status'
								},/* {
									'isSortable' : 'yes',
									'key' : 'modifiedByName',
									'desc' : 'User',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.auditInfo.modifiedByName'
								},*/ {
									'isSortable' : 'yes',
									'key' : 'invoiceType',
									'desc' : 'Invoice Type',
									'contentType' : 'String',
									'sortableKey' : 'invoiceType'
								}, {
									'isSortable' : 'no',
									'key' : 'action',
									'desc' : 'Actions',
									'contentType' : 'html'
								} ];
						
					},getPartnerInvoiceHeaders : function(){
						return [
		  						{
									'isSortable' : 'yes',
									'key' : 'externalId',
									'desc' : 'Invoice ID',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.externalId'
								},
								{
									'isSortable' : 'yes',
									'key' : 'entityId',
									'desc' : 'Partner ID',
									'contentType' : 'html',
									'sortableKey' : 'wfmInvoice.summary.generatedFor.owner.externalId',
									'isExportable' : true
								},
								{
									'isSortable' : 'yes',
									'key' : 'entityName',
									'desc' : 'Partner Name',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.summary.generatedFor.owner.profile.name'
								},
								{
									'isSortable' : 'yes',
									'key' : 'subscription',
									'desc' : 'Billing Account',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.summary.generatedFor.externalId'
								},
								{
									'isSortable' : 'yes',
									'key' : 'billCycleName',
									'desc' : 'Billing Period',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.summary.billPeriod.beginsOn, wfmInvoice.summary.billPeriod.endsOn',
									'isExportable' : true
								},
								{
									'isSortable' : 'yes',
									'key' : 'invoiceDate',
									'desc' : 'Bill Generation Date',
									'contentType' : 'html',
									'sortableKey' : 'wfmInvoice.summary.generationDate',
									'isExportable' : true
								},
								{
									'isSortable' : 'yes',
									'key' : 'dueDate',
									'desc' : 'Due Date',
									'contentType' : 'Date',
									'sortableKey' : 'wfmInvoice.summary.dueDate'
								},
								{
									'isSortable' : 'yes',
									'key' : 'amount',
									'desc' : 'Amount',
									'contentType' : 'Currency',
									'sortableKey' : 'wfmInvoice.summary.currentBillAmount'
								},{
									'isSortable' : 'yes',
									'key' : 'paidAmount',
									'desc' : 'Paid Amount',
									'contentType' : 'Currency',
									'sortableKey' : 'wfmInvoice.summary.paidAmount'
								}, {
									'isSortable' : 'yes',
									'key' : 'status',
									'desc' : 'Status',
									'contentType' : 'String',
									'sortableKey' : 'status'
								}/*, {
									'isSortable' : 'yes',
									'key' : 'modifiedByName',
									'desc' : 'User',
									'contentType' : 'String',
									'sortableKey' : 'wfmInvoice.auditInfo.modifiedByName'
								}*/, {
									'isSortable' : 'yes',
									'key' : 'invoiceType',
									'desc' : 'Invoice Type',
									'contentType' : 'String',
									'sortableKey' : 'invoiceType'
								}, {
									'isSortable' : 'no',
									'key' : 'action',
									'desc' : 'Actions',
									'contentType' : 'html'
								} ];
					},
					
					getFilterList : function(){
						return [ {
							'filterKey' : 'subscription',
							'filterType' : 'Number',
						},{
							'filterKey' : 'externalId',
							'filterType' : 'Number',
						}, {
							'filterKey' : 'status',
							'filterType' : 'EnumList'
						},{
							'filterKey' : 'invoiceDate',
							'filterType' : 'DateRange',
							'filterQueryKey' : ['invoiceDateFrom' ,'invoiceDateTo'],
							'filterValueWithQuote' : false
							
						},{
							'filterKey' : 'dueDate',
							'filterType' : 'DateRange',
							'filterQueryKey' : ['dueDateFrom' ,'dueDateTo'],
							'filterValueWithQuote' : false
						},{
							'filterKey' : 'billingPeriod',
							'filterType' : 'DateRange',
							'filterQueryKey' : ['billingPeriodFrom' ,'billingPeriodTo'],
							'filterValueWithQuote' : false
						},{
							'filterKey' : 'amount',
							'filterType' : 'NumberRange',
							'filterQueryKey' : ['minAmount' ,'maxAmount']
						},{
							'filterKey' : 'beId',
							'filterType' : 'Number',
						},{
							'filterKey' : 'name',
							'filterType' : 'Number',
						}, {
							'filterKey' : 'invoiceType',
							'filterType' : 'EnumList'
						}
						];
					},
					getInvoiceTransformer : function(value,scope,callerPage){
						var invoiceObject = {};
						invoiceObject.invoiceId = value.invoiceId;
						invoiceObject.status = '';
						if (value.status != null
								&& value.status != undefined) {
							if (value.status == 'SETTLED') {
								invoiceObject.status = 'Paid';
							} else if(value.status == 'VOID'){
								invoiceObject.status = 'Cancelled';
							}else if(value.status == 'PARTIAL_PAYMENT'){
								invoiceObject.status = 'Partially Paid';
							} else if(value.status == 'REVIEW'){
								invoiceObject.status = 'In-Review';
							} else if(value.status == 'REJECTED' || value.status == 'REJECTION_INITIATED'){
								invoiceObject.status = 'Rejected';
							} else{
								invoiceObject.status = 'Unpaid';
							}
						}
						
						if(value.invoiceType){
							invoiceObject.invoiceType = $translate.instant(value.invoiceType); 
						}
						
						/*
						 * if (value.referenceSet != null && value.referenceSet !=
						 * undefined && value.referenceSet.references != null &&
						 * value.referenceSet.references != undefined &&
						 * value.referenceSet.references.length > 0) {
						 * angular.forEach(value.referenceSet.references,
						 * function (refObj, refKey) { if ('BillingRunCycle' ==
						 * refObj.typeName) { invoiceObject.billCycleName = '<a
						 * href="#/system/bill-cycle"
						 * ng-click="viewBillCycleDetails(value.billCycleIdentity)">' +
						 * scope.toUTCDate(value.billPeriod.beginsOn.date) + ' - ' +
						 * scope.toUTCDate(value.billPeriod.endsOn.date) + '</a>';
						 * invoiceObject.typeName = refObj.typeName;
						 * invoiceObject.referenceId = refObj.referenceId;
						 * invoiceObject.refValue = refObj.refValue; } }); }
						 */
						var generationDate;
						if (value.generationDate != null
								&& value.generationDate != undefined
								&& value.generationDate.date != null
								&& value.generationDate.date != undefined) {
							var billGenDate = scope.toUTCDate(value.generationDate.date);
							invoiceObject.invoiceDate = '<a href="javascript:void(0);" ng-click="viewBillCycleDetails(value.billCycleIdentity)">'
														+ billGenDate + '</a>';
							invoiceObject.invoiceDate_exportValue=billGenDate;
							generationDate = value.generationDate.date;
							invoiceObject.generationDate=scope.toUTCDate(value.generationDate.date);
						
						}
						
						var dueDate;
						if (value.dueDate != null
								&& value.dueDate != undefined
								&& value.dueDate.date != null
								&& value.dueDate.date != undefined) {
							dueDate = value.dueDate.date;
							invoiceObject.dueDate = scope.toUTCDate(
									value.dueDate.date);
						}
						if (value.currentBillAmount != null
								&& value.currentBillAmount != undefined
								&& value.currentBillAmount.value != null
								&& value.currentBillAmount.value != undefined) {
							invoiceObject.amount = value.currentBillAmount.value;
						}
						
						if (value.paidAmount != null
								&& value.paidAmount != undefined
								&& value.paidAmount.value != null
								&& value.paidAmount.value != undefined) {
							invoiceObject.paidAmount = value.paidAmount.value;
						}

						if (value.billPeriod != null
								&& value.billPeriod != undefined
								&& value.billPeriod.beginsOn != null
								&& value.billPeriod.beginsOn != undefined
								&& value.billPeriod.beginsOn.date != null
								&& value.billPeriod.beginsOn.date != undefined
								&& value.billPeriod.endsOn != null
								&& value.billPeriod.endsOn != undefined) {
							invoiceObject.billCycleIdentity = value.billCycleIdentity;
							invoiceObject.billPeriod = value.billPeriod;
							var billCycleNameValue = scope.toUTCDate(value.billPeriod.beginsOn.date)	+ ' - ' + scope.toUTCDate(value.billPeriod.endsOn.date);
							invoiceObject.billCycleName = billCycleNameValue;
							/*
							 * '<a href="javascript:void(0);"
							 * ng-click="viewBillCycleDetails(value.billCycleIdentity)">' +
							 * billCycleNameValue + '</a>';
							 */
							invoiceObject.billCycleName_exportValue = billCycleNameValue;
						}
						invoiceObject.externalId = value.externalId;
						var subscriptionOb=value.subscription;
				
						if(scope.pageType=='Group' && callerPage=='invoice'){
							invoiceObject.subscription = '<a href="javascript:void(0);" ng-click="viewFinancialSummaryDetails(value.beItemRecordId, value.beId,'+subscriptionOb+')">'
								+ value.subscription + '</a>';	
						}else{
							invoiceObject.subscription = value.subscription;
						}
						invoiceObject.beItemRecordId = value.beItemRecordId;
						invoiceObject.beType = value.beType;
						invoiceObject.beId = value.beId;
						invoiceObject.beIdentity = value.beIdentity;
						invoiceObject.entityId = '<a href="javascript:void(0);" ng-click="viewBEDetails(value.beItemRecordId, value.beType, value.beId,value.beIdentity)">'
								+ value.beId + '</a>';
						invoiceObject.entityId_exportValue = value.beId;
						invoiceObject.entityName = '';
						if (value.name != null
								&& value.name != undefined) {
							invoiceObject.entityName = value.name;
						}

						invoiceObject.modifiedByName = value.modifiedBy;
						invoiceObject.value = value;
						if(scope.pageType=='Individual'|| scope.pageType=='Group'){
						invoiceObject.action = '<a href="#/financials/invoiceDetails" class="icon-view toolTip" original-title="Details" title="View Details">'
								+ '<i class="icon-view-details" ng-click="showMemberDetails(value.value,value.invoiceId,value.beType, value.beId, value.beIdentity, value.billPeriod, value.entityName,value.status,value.invoiceType,value.dueDate,value.generationDate,\'' + subscriptionOb + '\')"></i></a>'
								+ '<span class="lineDivider"></span>'
								+ ' <a original-title="Associated Financial Transactions" class="icon-view" title="Associated Financial Transactions" ng-click="getAllFinancialTxnsForInvoiceIdentity(value.invoiceId)"  href="javascript:void(0)"> <i class="icon-entityList"></i></a>';
						}
						if(scope.pageType=='Partner'){
							invoiceObject.action='<a href="#/financials/invoiceDetails" class="icon-view toolTip" original-title="Details" title="View Details">'
							+ '<i class="icon-view-details" ng-click="showMemberDetails(value.value,value.invoiceId,value.beType, value.beId, value.beIdentity, value.billPeriod, value.entityName,value.status,value.invoiceType,value.dueDate,value.generationDate,\'' + subscriptionOb + '\')"></i></a>'
							+ '<span class="lineDivider"></span>'
							+' <a original-title="Associated Financial Transactions" class="icon-view" title="Associated Financial Transactions" ng-click="getAllFinancialTxnsForInvoiceIdentity(value.invoiceId)"  href="javascript:void(0)"> <i class="icon-entityList"></i></a>';
						}
						return invoiceObject;
					}

				};

			} ];

	// wireup the service to application
	hcentive.WFM.configData[hcentive.WFM.operator].services.push({
		"name" : "FinancialsInvoiceHelperService",
		"id" : hcentive.WFM.FinancialsInvoiceHelperService
	});
})();