hcentive.WFM.FinancialTransactionCtrl = [
			'$scope',
			'FinancialTransactionService',
			'EventBusSrvc',
			'$filter',
			'$translate','FinancialsFilterConfigService','FinancialRuleService','$location',
			function($scope, FinancialTransactionService, EventBusSrvc,
					$filter, $translate,FinancialsFilterConfigService,FinancialRuleService,$location) {
				
				
				// Get GL Accounts from backend
				$scope.loadGLAccounts = function(){
		            FinancialRuleService.getGlAccounts(null, function (success) {
		            	$scope.accountMap={};
		                angular.forEach(success,
		            			function(value, key) {
		                	$scope.accountMap['com.hcentive.billing.wfm.domain.ft.GLAccountQualifier.Type.'+value] = key;
		                });
		                loadFilter();
		            }, function (error) {
		                $scope.accountTypes = null;
		            });
				}
	            
				$scope.pagination = defaultPagination('ftEntry.auditInfo.createdAt.date', '');
				
				var goToRelatedBEExternalId = EventBusSrvc
						.subscribeAndInvalidatePayload('goToRelatedBEExternalId');
				var beExternalId = EventBusSrvc
						.subscribeAndInvalidatePayload('beExternalId');
				var billCycleExternalId = EventBusSrvc
						.subscribeAndInvalidatePayload('billCycleExternalId');
				var eventAdditionalId = EventBusSrvc
					.subscribeAndInvalidatePayload('eventAdditionalId');
				var goToRelatedBAExternalId = EventBusSrvc
				.subscribeAndInvalidatePayload('goToRelatedBAExternalId');
				
				$scope.preSelectedFilters = {};
				if(goToRelatedBAExternalId && goToRelatedBAExternalId !== ''){
					$scope.preSelectedFilters['subscription'] =  goToRelatedBAExternalId;
				}

				if(billCycleExternalId){
					eventAdditionalId = billCycleExternalId; 
				}
				
				var getFTEntriesRequestBody = function(payload) {
					var data = {
						'criteria' : {},
						'pageRequestCriteria' : {}
					};

					data.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
					
					//For account, transaction are not filtered on FtId's.Instead filtered on account name.
					if(payload && payload.accountName){
						return data;
					}
					
					//For Invoice, transaction are filtered on FtId's.
					var identities = payload.data;
					var identitiesList = '(\'\')';
					if (identities != null && identities != undefined
							&& identities.length > 0) {
						identitiesList = '(';
						angular.forEach(identities, function(identity) {
							if(identitiesList == '('){
									identitiesList += '\'' + identity + '\'';
							}else{
									identitiesList += ',\'' + identity + '\'';
								}
						});
						identitiesList += ')';	

						data.criteria.identity = {};
						ftEntryCriteria = {};
						ftEntryCriteria['operator'] = 'IN';
						ftEntryCriteria['columnValue'] = identitiesList;
						data.criteria.identity = ftEntryCriteria;
					}
					return data;
				};
				
				// Coming from accounts page START
				var payload = EventBusSrvc.subscribeAndInvalidatePayload('fetchFTEntry');
				var accountName = null;
				var ftEntriesRequestBody = {};
				var searchId = '';
				if(payload){
					console.debug(payload);
					ftEntriesRequestBody = getFTEntriesRequestBody(payload);
					accountName = payload.accountName || null;
					searchId =    payload.entityId || '';
				}
				// Coming from accounts page END
				
				var isResetCalled = false;		
				if (goToRelatedBEExternalId != null	&& goToRelatedBEExternalId != undefined && goToRelatedBEExternalId != '') 
					{
					searchId = goToRelatedBEExternalId;
					}
				if (beExternalId != null && beExternalId != undefined	&& beExternalId != '')
					{
					searchId = beExternalId;
					}
						
				
				if(searchId != undefined && searchId !=''){
					$scope.preSelectedFilters['externalId'] =  searchId;
				}
				
				if(eventAdditionalId && eventAdditionalId !== ''){
					$scope.preSelectedFilters['eventAdditionalId'] =  eventAdditionalId;
				}

				if(accountName){
					// pre fill account name in filters
					$scope.preSelectedFilters['account'] = accountName;
				}

			 	$scope.filterBoxConfig = FinancialsFilterConfigService.getTransactionFilterConfiguration($scope.preSelectedFilters);
				
			 	function loadFilter(){
					 $scope.filterBoxConfig = FinancialsFilterConfigService.enrichTransactionFilterWithAccountFilter($scope.filterBoxConfig,$scope.preSelectedFilters,$scope.accountMap);
	            }
				
					
				var pageIndex = 0;
				$scope.exportHandler = function(filterData){
			    	$scope.isExportCall = true;
			    	pageIndex  = $scope.pagination.pageIndex;
			    	$scope.pagination = setExportPageSize($scope.pagination);
			    	$scope.fetchdata($scope.pagination, buildCriteria($scope.filterList,filterData));
			    };
			    
			    $scope.handleSearch = function(filterData,filterReset){
			    	if(filterReset){
			    		isResetCalled = filterReset;
			    	}
			    	$scope.handleChange(filterData);
			    };
			    
			    
			    
			    $scope.transactionFilter = {};
			    $scope.transactionFilter.isSearchCall = false;
			    $scope.filterData = $scope.filterData || {};
			    
			    $scope.handleChange = function(filterData){
			    	$scope.transactionFilter = filterData;
			    	$scope.transactionFilter.isSearchCall = true;
			    };
				
				$scope.ftList = [];
				$scope.pagination = defaultPagination(
						'ftEntry.auditInfo.createdAt.date', 'desc');
				String.prototype.replaceAt = function(index, character) {
					return this.substr(0, index) + character
							+ this.substr(index + character.length);
				}
				
				var ftEntryCriteria;
				
				$scope.headerList = [{
					'isSortable' : 'yes',
					'key' : 'entityId',
					'desc' : 'Entity ID',
					'contentType' : 'String',
					'sortableKey' : 'externalId',
					'isDrillDownFilter' : true
				},{
					'isSortable' : 'yes',
					'key' : 'entityName',
					'desc' : 'Entity Name',
					'contentType' : 'String',
					'isDrillDownFilter' : true
				},{
					'isSortable' : 'yes',
					'key' : 'subscription',
					'desc' : 'Billing Account',
					'contentType' : 'String',
					'isDrillDownFilter' : true
				} ,{
					'isSortable' : 'yes',
					'key' : 'accountName',
					'desc' : 'Account',
					'contentType' : 'String',
					'sortableKey' : 'accountName'
				} ,{
					'isSortable' : 'yes',
					'key' : 'eventAdditionalId',
					'desc' : 'Event ID',
					'contentType' : 'String',
					'sortableKey' : 'eventAdditionalId',
					'isDrillDownFilter' : true
				}, {
					'isSortable' : 'yes',
					'key' : 'businessTx',
					'desc' : 'Event',
					'contentType' : 'String',
					'sortableKey' : 'businessTx',
					'translate' : true,
					'isDrillDownFilter' : true
				}, {
					'isSortable' : 'yes',
					'key' : 'dataDisplayId',
					'desc' : 'Event Data',
					'contentType' : 'html',
					'sortableKey' : 'ftEntry.financialTransaction.eventDataRef.dataDisplayId',
					'isExportable' : true
				},
				{
					'isSortable' : 'yes',
					'key' : 'eventDate',
					'desc' : 'Transaction Date',
					'contentType' : 'String',
					'sortableKey' : 'eventDate',
					'isDrillDownFilter' : true
				},{
					'isSortable' : 'yes',
					'key' : 'coveragePeriod',
					'desc' : 'Coverage Period',
					'contentType' : 'String',
					'sortableKey' : 'ftEntry.coveragePeriod.beginsOn.date',
					'isDrillDownFilter' : true
				},{
					'isSortable' : 'yes',
					'key' : 'billingPeriod',
					'desc' : 'Billing Period',
					'contentType' : 'String',
					'sortableKey' : 'ftEntry.billingPeriod.beginsOn.date',
					'isDrillDownFilter' : true
				}, {
					'isSortable' : 'yes',
					'key' : 'amountType',
					'desc' : 'Amount Type',
					'contentType' : 'String',
					'sortableKey' : 'amountName'
				}, {
					'isSortable' : 'yes',
					'key' : 'debit',
					'desc' : 'Debit',
					'contentType' : 'Currency',
					'sortableKey' : 'ftEntry.glEntry.amount.value.debit'
				}, {
					'isSortable' : 'yes',
					'key' : 'credit',
					'desc' : 'Credit',
					'contentType' : 'Currency',
					'sortableKey' : 'ftEntry.glEntry.amount.value.credit'
				}
				];
				
				$scope.filterList = [ {
					'filterKey' : 'entityId',
					'filterType' : 'String',
					'filterQueryKey' : 'externalId',
					'filterValueWithQuote' : false
						
				},{
					'filterKey' : 'entityName',
					'filterType' : 'StringLike',
					'filterQueryKey' : 'entityName',
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'subscription',
					'filterType' : 'Number',
					'filterQueryKey' : 'subscription',
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'eventAdditionalId',
					'filterType' : 'String',
					'filterQueryKey' : 'eventAdditionalId',
					'filterValueWithQuote' : false
				}, {
					'filterKey' : 'account',
					'filterType' : 'StringList',
					'filterQueryKey' : 'accountType',
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'billingPeriod',
					'filterType' : 'DateRange',
					'filterQueryKey' : ['billingPeriodFrom','billingPeriodTo'],
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'eventDate',
					'filterType' : 'DateRange',
					'filterQueryKey' : ['eventDateFrom','eventDateTo'],
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'coveragePeriod',
					'filterType' : 'DateRange',
					'filterQueryKey' : ['coveragePeriodFrom','coveragePeriodTo'],
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'amount',
					'filterType' : 'NumberRange',
					'filterQueryKey' : ['minAmount','maxAmount']
				},{
					'filterKey' : 'billCycleId',
					'filterType' : 'String',
					'filterValueWithQuote' : false
				},{
					'filterKey' : 'businessTx',
					'filterType' : 'StringList',
					'filterValueWithQuote' : false
				}
				];	
				
				
				$scope.fetchProjectedFieldsForFinancialTransactions = function(){
					var projectedFields = [];
					var projectFieldForIdentity = {
						"entityField" : "ftEntry.identity",
						"mappedField" : "identity"
					};
					projectedFields.push(projectFieldForIdentity);
					var projectFieldBusinessTrxn = {
						"entityField" : "ftEntry.financialTransaction.eventType",
						"mappedField" : "businessTx"
					};
					projectedFields.push(projectFieldBusinessTrxn);
					
					var projectedFieldEventDate  = {
								"entityField" : "ftEntry.financialTransaction.eventDate",
								"mappedField" : "eventDate"
							};
					projectedFields.push(projectedFieldEventDate);
					
					var projectedFieldAmountName = {
						"entityField" : "ftEntry.amountName",
						"mappedField" : "amountName"
					};
					projectedFields.push(projectedFieldAmountName);
					var projectedFieldDebitValue = {
						"entityField" : "ftEntry.glEntry.amount.value",
						"mappedField" : "amountValue"
					};
					projectedFields.push(projectedFieldDebitValue);
					var projectedFieldCreditValue = {
						"entityField" : "ftEntry.glEntry.postingType",
						"mappedField" : "postingType"
					};
					projectedFields.push(projectedFieldCreditValue);
					var projectedFieldEntityName = {
						"entityField" : "ftEntry.glEntry.billingAccount.owner.profile.name",
						"mappedField" : "entityName"
					};
					projectedFields.push(projectedFieldEntityName);
					var projectedFieldEntityName = {
							"entityField" : "ftEntry.glEntry.billingAccount.externalId",
							"mappedField" : "subscription"
						};
						projectedFields.push(projectedFieldEntityName);
					var projectedFieldEventAdditionalId = {
						"entityField" : "ftEntry.financialTransaction.eventAdditionalId",
						"mappedField" : "eventAdditionalId"
					};
					projectedFields.push(projectedFieldEventAdditionalId);
					var projectedFieldEntityId = {
						"entityField" : "ftEntry.glEntry.billingAccount.owner.externalId",
						"mappedField" : "externalId"
					};
					projectedFields.push(projectedFieldEntityId);
					var projectedFieldAccountName = {
						"entityField" : "ftEntry.glEntry.glAccount.qualifier.name",
						"mappedField" : "accountName"
					};
					projectedFields.push(projectedFieldAccountName);
					var projectedFieldAccountType = {
						"entityField" : "ftEntry.glEntry.glAccount.qualifier.type",
						"mappedField" : "accountType"
					};
					projectedFields.push(projectedFieldAccountType);
					var projectedFieldCoveragePeriod = {
						"entityField" : "ftEntry.coveragePeriod",
						"mappedField" : "coveragePeriod"
					};
					projectedFields.push(projectedFieldCoveragePeriod);
					var projectedFieldBillingPeriod = {
						"entityField" : "ftEntry.billingPeriod",
						"mappedField" : "billingPeriod"
					};
					projectedFields.push(projectedFieldBillingPeriod);
					
					var projectFieldForEventDataRef = {
							"entityField" : "ftEntry.financialTransaction.eventDataRef",
							"mappedField" : "eventDataRef"
						};
					projectedFields.push(projectFieldForEventDataRef);
					
					return projectedFields;
				}
				
				var financialTransactionsProjectedFields = $scope.fetchProjectedFieldsForFinancialTransactions();

				function transformData(content) {
					var ftEntryTableContent = [];
					angular
							.forEach(
									content,
									function(ftEntry,index) {
										var ftEntryTableJSON = {
											'identity' : '',
											'businessTx' : '',
											'businessTxID' : '',
											'eventDate' : '',
											'debit' : '',
											'credit' : '',
											'entityName' : '',
											'accountName' : ''
										};
										ftEntryTableJSON.identity = ftEntry.identity;
										ftEntryTableJSON.businessTx = ftEntry.businessTx;
										ftEntryTableJSON.entityName = ftEntry.entityName;
										if(ftEntry.eventDate && ftEntry.eventDate.date){
											ftEntryTableJSON.eventDate = $scope.toUTCDate
														(
															ftEntry.eventDate.date,
															$scope.$parent.clientDateFormat + '  '+ 'hh:mm:ss a');
										}
										ftEntryTableJSON.amountType = $scope.buildFtAmountType(ftEntry.amountName);
										ftEntryTableJSON.accountName = ftEntry.accountName;
										if (ftEntry.postingType == 'DR') {
											ftEntryTableJSON.debit = ftEntry.amountValue
													|| '';
											ftEntryTableJSON.rowColor = 'debitRow';
											delete ftEntryTableJSON.credit;
										} else {
											delete ftEntryTableJSON.debit;
											ftEntryTableJSON.rowColor = 'creditRow';
											ftEntryTableJSON.credit = ftEntry.amountValue
													|| '';
										}
										
										ftEntryTableJSON.eventAdditionalId = ftEntry.eventAdditionalId;
										ftEntryTableJSON.entityId = ftEntry.externalId;
										ftEntryTableJSON.subscription = ftEntry.subscription;
										
										if(ftEntry.coveragePeriod && ftEntry.coveragePeriod.beginsOn.date && ftEntry.coveragePeriod.endsOn.date){
												ftEntryTableJSON.coveragePeriod = $scope.toUTCDate(ftEntry.coveragePeriod.beginsOn.date) +'-'+$scope.toUTCDate(ftEntry.coveragePeriod.endsOn.date);
										}''
										
										if(ftEntry.billingPeriod && ftEntry.billingPeriod.beginsOn.date && ftEntry.billingPeriod.endsOn.date){
												ftEntryTableJSON.billingPeriod = $scope.toUTCDate(ftEntry.billingPeriod.beginsOn.date) +'-'+$scope.toUTCDate(ftEntry.billingPeriod.endsOn.date);
										}
										
										
										if(ftEntry.eventDataRef){
											ftEntryTableJSON.eventDataRef = ftEntry.eventDataRef;
											if(ftEntry.eventDataRef.dataDisplayId){
											ftEntryTableJSON.dataDisplayId = '<a href="javascript:void(0); title="Event Data" ng-click="showEventData('+index+')">'
												+ ftEntry.eventDataRef.dataDisplayId
												+ "</a>";
											}
										}
										
										ftEntryTableContent
												.push(ftEntryTableJSON);
									});
					return ftEntryTableContent;
				}
				
				$scope.showEventData = function(index){
					var eventDataRefObj = $scope.ftList[index].eventDataRef;
					var dataType = eventDataRefObj.dataType;
					var dataDisplayId =  eventDataRefObj.dataDisplayId;
					var dataIdentity = eventDataRefObj.dataIdentity;
					var path;
					var ftEventData = {};
					var eventName = 'ftEventData';
					switch(dataType){
						case 'ELIGIBILITY' :
							eventName = 'contractRecordId';
							ftEventData = dataIdentity;
							path = 'system/eligibility/contract-detail/';
							break;
						case 'PAYMENT' : 
							$scope.updateLeftNav('Payments');
							//To be removed once payment detail page will be created
							ftEventData['externalId'] = dataDisplayId;
							path = 'financials/payments/';
							break;
						case 'REFUND' : 
							$scope.updateLeftNav('Manual Adjustments');
							eventName = 'manualAdjustmentExtId';
							ftEventData['identity'] = dataIdentity;
							ftEventData['type'] = 'Refund';
							path = 'financials/manual-adjustments/refunds-details/';
							break;
						case 'WRITEOFF' : 
							$scope.updateLeftNav('Manual Adjustments');
							eventName = 'manualAdjustmentExtId';
							ftEventData['identity'] = dataIdentity;
							ftEventData['type'] = 'Write-Off';
							path = 'financials/manual-adjustments/writeoff-payment-details/';
							break;
						case 'WRITEON' : 
							$scope.updateLeftNav('Manual Adjustments');
							eventName = 'manualAdjustmentExtId';
							ftEventData['identity'] = dataIdentity;
							ftEventData['type'] = 'Write-On';
							path = 'financials/manual-adjustments/writeon-payment-details/';
							break;
						case 'CREDIT' : 
							$scope.updateLeftNav('Manual Adjustments');
							eventName = 'manualAdjustmentExtId';
							ftEventData['identity'] = dataIdentity;
							ftEventData['type'] = 'Credit';
							path = 'financials/manual-adjustments/credit-details/';
							break;
						case 'MONEY_TRANSFER' : 
							$scope.updateLeftNav('Manual Adjustments');
							eventName = 'manualAdjustmentExtId';
							ftEventData['identity'] = dataIdentity;
							ftEventData['type'] = 'Money-Transfer';
							path = 'financials/manual-adjustments/money-transfer-details/';
							break;
						case 'INVOICE' :
							$scope.updateLeftNav('Invoices');
							ftEventData['dataIdentity'] = dataIdentity;
							path = 'financials/invoiceDetails/';
							break;
						case 'REMIT' : 
							$scope.updateLeftNav('Remits');
							path = 'reports/report-remit-details/';
							$location.path(path).search({'pridentity': dataIdentity});;
							break;
						case 'REFUND_PAYOUT' : 
							$scope.updateLeftNav('Remits');
							path = 'reports/report-customer-refunds/';
							$location.path(path).search({'refundId': dataDisplayId});
							break;
					}
					
					if(path){

						if(dataType != 'REMIT' && dataType != 'REFUND_PAYOUT'){
							EventBusSrvc.publish(eventName,ftEventData);
							$location.path(path);
						}
						
						$location.replace();
					}
				}

				function success(ftEntries) {
					if (null != ftEntries && ftEntries.content != null
							&& ftEntries.content.length > 0) {
				if($scope.isExportCall){
					$scope.isExportCall = false;
			    	var exportData = {};
			    	exportData.fileName = 'Transactions';
			    	exportData.data = transformData(ftEntries.content);
			    	$scope.pagination = setDefaultPageSize($scope.pagination,pageIndex);
			    	$scope.$broadcast('exportEvent', exportData);
					return;
				}
						$scope.ftList = transformData(ftEntries.content);
						//$scope.ftList.length = ftEntries.totalElements;
						$scope.pagination.totalElements = ftEntries.totalElements;
						$scope.pagination.totalNoPages = ftEntries.totalPages;
					} else {
						$scope.ftList = 'No Data';
					}
					$scope.error = null;
				}

				function error(error) {
					$scope.error = error;
					$scope.isExportCall = false;
	    			$scope.pagination = setDefaultPageSize($scope.pagination,pageIndex);
					$scope.ftList = 'No Data';
				}
				
				$scope.buildFtAmountType = function(_amountType){
					if(_amountType =='INDV_RESP'){
						return 'Individual Responsibility';
					}
					else if(_amountType=='EMPLOYER_RESP'){
						return 'Employer Responsibility';
					}
					else if(_amountType=='EMPLOYEE_RESP'){
						return 'Employee Responsibility';
					}
					else if(_amountType=='MONEY_TRANSFER'){
						return 'Money Transfer';
					}
					else{
						return _amountType;
					}
				}

				var createCriteria = function(filters) {
					var criteria = {};
					
					if(!Array.isArray(filters)){
						criteria = filters;
					}
					
					return criteria;
				};
				$scope.fetchdata = function(pagination, filters, callType) {
					console.log('Filters fetch data :: ' +JSON.stringify(filters));
					if (callType != null && callType != undefined
							&& callType == 'search') {
						payload = null;
						searchId = '';
						ftEntriesRequestBody.referenceId = undefined;
						eventAdditionalId = '';
					}

					if (filters != null && filters != undefined && payload == null) {
						ftEntriesRequestBody.criteria = createCriteria(filters);
						
						if(!isResetCalled && ftEntryCriteria){
							ftEntriesRequestBody.criteria.identity = ftEntryCriteria;
							}
						
					}

					ftEntriesRequestBody.pageRequestCriteria = getPageRequestCriteria(pagination);
					if (searchId != '') 
					{
						ftEntriesRequestBody.criteria['externalId'] = {
							'operator' : '=',
							'columnValue' :  searchId,
							'caseSensitiveSearch' : 'false'
						};
					}
					if (goToRelatedBAExternalId != '') 
					{
						ftEntriesRequestBody.criteria['ftEntry.glEntry.billingAccount.externalId'] = {
							'operator' : '=',
							'columnValue' :goToRelatedBAExternalId,
							'caseSensitiveSearch' : 'false'
						};
					}
					//Account Filter
					if(payload && payload.accountName){
						ftEntriesRequestBody.criteria['accountName'] = {
								'operator' : '=',
								'columnValue' : '\'' +payload.accountName+'\'' ,
								'caseSensitiveSearch' : 'false'
						};
							
					}
					
					if(ftEntriesRequestBody.criteria['billCycleId']){
						ftEntriesRequestBody.referenceId = ftEntriesRequestBody.criteria['billCycleId'].columnValue;
						delete ftEntriesRequestBody.criteria['billCycleId'];
					}
					
					if(eventAdditionalId && eventAdditionalId !=''){
						ftEntriesRequestBody.criteria['eventAdditionalId'] = {
								'operator' : '=',
								'columnValue' :   eventAdditionalId ,
								'caseSensitiveSearch' : 'false'
						};
					}
					
					$scope.updateLeftNav('Accounts');
					ftEntriesRequestBody.projectedFields = financialTransactionsProjectedFields;
					FinancialTransactionService
							.getFinancialTransactionsByIdentities(
									ftEntriesRequestBody, success, error);
				};
			} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		'name' : 'FinancialTransactionCtrl',
		'id' : hcentive.WFM.FinancialTransactionCtrl
});