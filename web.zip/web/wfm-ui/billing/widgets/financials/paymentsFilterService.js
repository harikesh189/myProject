(function () {
    hcentive.WFM.FinancialsPaymentsFilterService = [function () {
            return {
            	 getPaymentsFilterConfiguration : function(preSelectedFilters){
    				var defaultFiltersConfig = [];
    				defaultFiltersConfig.push(new WFMFilterConfiguration("paymentMode","checkbox", "Payment Method", {enableAll : true}, 
    					{
    						BankAccount :"BankAccount",
    						Card : "Card",
							Cash : "Cash",
							Check : "Check",
							MoneyOrder : "Money Order",
							'Token-Card' : "Token Card",
							'Token-BankAccount' : "Token Bank Account",
							'OTHER' :'Other',
    					}));
    				
    					defaultFiltersConfig.push(new WFMFilterConfiguration("externalId", "text", "Payment ID", {init:preSelectedFilters.externalId}, {}));
    					defaultFiltersConfig.push(new WFMFilterConfiguration("subscriptionId", "text", "Billing Account", {init:preSelectedFilters.subscription}, {}));
    				
    				var moreFiltersConfig = [];
    				moreFiltersConfig.push(new WFMFilterConfiguration("status","checkbox", "Status", {enableAll : false}, 
    					{
    						PAYMENT_REQUEST_SUCCESSFULL :"Successful",
    						PAYMENT_REQUEST_FAILED : "Failed",
    						PAYMENT_REQUEST_UNKNOWN : "Unknown"
    					}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("paymentDate","daterange", "Payment Date", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("amount","range", "Amount", {}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("payerEntityId","text", "Entity ID", {init:preSelectedFilters.beExtenalId}, {}));
    				moreFiltersConfig.push(new WFMFilterConfiguration("payerEntityName","text", "Entity Name", {}, {}));
    				
//    				var searchFilterConfig = new WFMFilterConfiguration("invoiceId", "text", "Invoice Id", {}, {});
    				
    				return new WFMFIlterBoxConfiguration(
    						defaultFiltersConfig, moreFiltersConfig);
    			}
        	};
            }
         ];
		 
    // wireup the service to application
    hcentive.WFM.configData[hcentive.WFM.operator].services.push({
        "name": "FinancialsPaymentsFilterService",
        "id": hcentive.WFM.FinancialsPaymentsFilterService
    });
})();