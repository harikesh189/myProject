/**
 * Added by Manish for Write off controller
 */
(function() {

	hcentive.WFM.WriteoffController = [
		'$scope',
		'FinancialsWriteOffService',
		'EventBusSrvc','NotifySrvc','IndividualServ','FinancialsFilterConfigService','entityService','popupService',
		function($scope, writeoffService, EventBusSrvc,NotifySrvc,BaseServ,FinancialsFilterConfigService,entityService,popupService) {
			
			
			$scope.filterBoxConfig = FinancialsFilterConfigService.getWriteOffFilterConfiguration($scope.preSelectedFilters);
			
			var pageIndex = 0;
		    $scope.exportHandler = function(filterData){
		    	$scope.isExportCall = true;
		    	pageIndex  = $scope.pagination.pageIndex;
		    	$scope.pagination = setExportPageSize($scope.pagination);
		    	$scope.fetchdata($scope.pagination, buildCriteria($scope.writeoffListFilters,filterData));
		    };
		    
		    $scope.handleSearch = function(filterData){
		    	console.log('handleSearch called');
		    	$scope.handleChange(filterData);
		    };
		    
		    $scope.handleChange = function(filterData){
		    	console.log('handleChange called');
		    	$scope.writeOffFilter = JSON.parse(JSON.stringify(filterData));
		    };
			

			$scope.writeoffList = [];
			$scope.pagination = defaultPagination('identity', '');
			$scope.searchAccountNameFilter = '';
			
			$scope.writeoffListFilters = [ {
				'filterKey' : 'writeOffId',
				'filterType' : 'Number',
				'filterQueryKey' : 'externalId'
			},{
				'filterKey' : 'invoiceDate',
				'filterType' : 'DateRange',
				'filterQueryKey' : 'writeOffDate.date',
				'filterValueWithQuote' : true
				
			},{
				'filterKey' : 'amount',
				'filterType' : 'NumberRange',
				'filterQueryKey' : 'writeOffAmount.value'
			},{
				'filterKey' : 'entityId',
				'filterType' : 'String',
				'filterQueryKey' : 'beneficiary.identity'
			},{
				'filterKey' : 'entityName',
				'filterType' : 'String',
				'filterQueryKey' : 'beneficiary.externalId'
			}
			];
			
			$scope.writeoffListHeaders = [ {
				'isSortable' : 'no',
				'key' : 'writeOffId',
				'desc' : 'Write Off ID',
				'contentType' : 'String'
			}, {
				'isSortable' : 'no',
				'key' : 'entityId',
				'desc' : 'Entity ID',
				'contentType' : 'String'
			}, {
				'isSortable' : 'no',
				'key' : 'entityName',
				'desc' : 'Entity Name',
				'contentType' : 'String'
			}, {
				'isSortable' : 'no',
				'key' : 'writeOffDate',
				'desc' : 'Write Off Date',
				'contentType' : 'String'
			},{
				'isSortable' : 'no',
				'key' : 'amount',
				'desc' : 'Amount',
				'contentType' : 'Currency'
			}];
			var successCallback = function(data) {
				console.log(angular.toJson(data));
				// alert(angular.toJson(success.errorMsg));
				$scope.pagination.totalElements = data.totalElements;
				$scope.writeoffList = getWriteoffTransformer(data);
				$scope.pagination.totalElements = data.length;
				if ($scope.writeoffList == ''
						|| $scope.writeoffList == undefined) {
					$scope.writeoffList = 'No Data';
				}
			};
			var errorCallBack = function(data) {
				$scope.writeoffList = 'No Data';
			};
			$scope.fetchdata = function(paginationObj, filterObj) {
				$scope.pagination = paginationObj;
				var searchCriteriaJson = {
					'criteria' : {},
					'pageRequestCriteria' : getPageRequestCriteria($scope.pagination),
					'referenceId' : null
				};
				if (filterObj != null && filterObj != undefined
						) {
					if(Array.isArray(filterObj)){
						searchCriteriaJson.criteria = {};
					}else{
						searchCriteriaJson.criteria = filterObj;
					}
				}
				writeoffService.getAllWriteoff(null,
						searchCriteriaJson, null, successCallback,
						errorCallBack);
			};
			
			var writeoffSuccessCallback = function(arg1){
				if(arg1 && arg1=='true'){
						$scope.fetchdata($scope.pagination,null);
					}
				}
			
			EventBusSrvc.subscribe('addWriteoffProcessCompletedSuccess', $scope,writeoffSuccessCallback);
			
			$scope.addWriteoffDialog = function() {
				var tenantId = $scope.wfmAppContext.loggedInUser.tenantId;
				//EventBusSrvc.publish('addPaymentControllerTenantId', tenantId);
				popupService.openWriteoffPopup('general');
			}; 
			
		} ];
	
	hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
		'name' : 'WriteoffController',
		'id' : hcentive.WFM.WriteoffController
	});
})();
