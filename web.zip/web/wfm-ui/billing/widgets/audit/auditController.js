hcentive.WFM.AuditController = [
		'$scope',
		'AuditService',
		'AuditConfigService',
		function($scope,AuditService, AuditConfigService) {

			$scope.preSelectedFilters = {};
			$scope.audits = [];
			
			$scope.exportHandler = function(filterData){
	    		var data = {};
	    		data.fileName = 'Audit';
	    		$scope.$broadcast('exportEvent', data);
	    	};
			

			$scope.handleSearch = function(filterData) {
				$scope.handleChange(filterData);
			};

			$scope.handleChange = function(filterData) {
				$scope.auditFilter = JSON.parse(JSON.stringify(filterData));
			};

			$scope.auditHeaders = AuditConfigService.getAuditHeaders();

			$scope.filterBoxConfig = AuditConfigService
					.getAuditFilterBoxConfig($scope.preSelectedFilters);

			$scope.filterList = AuditConfigService.getFilters();

			$scope.pagination = defaultPagination(
					'auditTime', 'desc');

			$scope.fetchdata = function(paginationObj, filterObj, callType) {
				
				var auditCriteria = {};
				
				auditCriteria.criteria = {};

				if (filterObj && !Array.isArray(filterObj)) {
					auditCriteria.criteria = filterObj;
				}

				if (paginationObj) {
					auditCriteria.pageRequestCriteria = getPageRequestCriteria(paginationObj);
				}

				$scope.getAudits(auditCriteria);
			}

			var successCallback = function(content) {
				if (content) {
					if(!content.totalElements){
						$scope.audits = 'No Data';
						return;
					}
					$scope.pagination.totalElements = content.totalElements;
					$scope.pagination.totalNoPages = content.totalPages;
					$scope.audits = auditTransformer(content);
				} else {
					$scope.audits = 'No Data';
				}
			}

			var errorCallback = function(error) {
				$scope.audits = 'No Data';
			}

			$scope.getAudits = function(auditCriteria) {
				AuditService.getAudits(auditCriteria, successCallback,
						errorCallback);
			}

		} ];
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	'name' : 'AuditController',
	'id' : hcentive.WFM.AuditController
});