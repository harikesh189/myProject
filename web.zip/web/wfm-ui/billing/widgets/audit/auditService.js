(function() {
	hcentive.WFM.AuditService = [
			'$http',
			'RESTSrvc',
			function($http, RESTSrvc) {

				return {
					getAudits : function(data, successCallback, errorCallback) {
						RESTSrvc.postForData('getAudits', null, data, null,successCallback, errorCallback);
					}
				};

			} ];
	// wireup the service to application
	hcentive.WFM.configData[hcentive.WFM.operator].services.push({
		"name" : "AuditService",
		"id" : hcentive.WFM.AuditService
	});
})();