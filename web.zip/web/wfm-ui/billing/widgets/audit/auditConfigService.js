(function() {
	hcentive.WFM.AuditConfigService = [
			'$translate',
			function($translate) {

				return {
					getAuditHeaders : function() {
						return [
								{
									'isSortable' : 'yes',
									'key' : 'externalId',
									'desc' : 'Audit Id',
									'contentType' : 'String'
								},
								{
									'isSortable' : 'yes',
									'key' : 'message',
									'desc' : 'Operation',
									'contentType' : 'String'
								},
								{
									'isSortable' : 'yes',
									'key' : 'auditTime',
									'desc' : 'Date',
									'contentType' : 'Date'
								},
								{
									'isSortable' : 'yes',
									'key' : 'userName',
									'desc' : 'Username',
									'contentType' : 'String'
								},
								{
									'isSortable' : 'yes',
									'key' : 'status',
									'desc' : 'Status',
									'contentType' : 'String'
								},
								{
									'isSortable' : 'yes',
									'key' : 'auditType',
									'desc' : 'Audit Type',
									'contentType' : 'String'
								} ];

					},

					getAuditFilterBoxConfig : function(preSelectedFilters) {

						var defaultFiltersConfig = [];
						defaultFiltersConfig
								.push(new WFMFilterConfiguration("auditTime",
										"daterange", "Event Date", {}, {}));
						defaultFiltersConfig.push(new WFMFilterConfiguration(
								"status", "checkbox", "Status", {
									enableAll : true
								}, {
									SUCCESS : "Success",
									FAILURE : "Failure",
									CREATED : "Created",
									DESTROYED : "Destroyed"
								}));
						defaultFiltersConfig.push(new WFMFilterConfiguration(
								"externalId", "text", "Audit Id", {}, {}));
						defaultFiltersConfig.push(new WFMFilterConfiguration(
								"userName", "text", "User Name", {}, {}));

						var moreFiltersConfig = [];

						return new WFMFIlterBoxConfiguration(
								defaultFiltersConfig, undefined);
					},

					getFilters : function() {
						return [ {
							'filterKey' : 'externalId',
							'filterType' : 'String',
							'filterValueWithQuote' : false
						}, {
							'filterKey' : 'status',
							'filterType' : 'EnumList',
							'filterValueWithQuote' : false
						}, {
							'filterKey' : 'auditTime',
							'filterType' : 'DateRange',
							'filterQueryKey' :'auditTime.date',
							'filterValueWithQuote' : false,
							'dateFormat' : 'yyyy/mm/dd'
						}, {
							'filterKey' : 'userName',
							'filterType' : 'String',
							'filterValueWithQuote' : false
						} ];
					}
				};

			} ];
	// wireup the service to application
	hcentive.WFM.configData[hcentive.WFM.operator].services.push({
		"name" : "AuditConfigService",
		"id" : hcentive.WFM.AuditConfigService
	});
})();