hcentive.WFM.fetchGroupServ = ['$http', 'RESTSrvc', function($http, RESTSrvc) {
    
	var getBillingAccountsSubscriptions = function(serachCriteria, successCallback, errorCallback) {
        var resourceUriKey = 'fetchBillingAccounts';
        RESTSrvc.postForData(resourceUriKey, null , serachCriteria, null , successCallback, errorCallback);
    }
    ;
	
	var getBillingAccounts = function(serachCriteria) {
        var resourceUriKey = 'fetchBillingAccounts';
        return RESTSrvc.postForDataReturnsPromise(resourceUriKey, null , serachCriteria, null , null);
    };
    
    var doAjaxCall = function(serachCriteria,successCallback,errorCallback){
		var resourceUriKey = 'manageBusinessEntitiesPort';
		RESTSrvc.postForData(resourceUriKey,null,serachCriteria,null,successCallback,errorCallback);
	};
	
    var getEntities = function(serachCriteria, successCallback, errorCallback) {
        var resourceUriKey = 'manageBusinessEntitiesPort';
        RESTSrvc.postForData(resourceUriKey, null , serachCriteria, null , successCallback, errorCallback);
    }
    ;
    
    var findPendingCycleForBE = function(params, success, error) {
        RESTSrvc.postForData('findPendingCycleForBE', params, null , null , success, error);
    }
    ;
    
    var findPendingCycleForBAExternalId = function(params, success, error) {
        RESTSrvc.postForData('findPendingCycleForBAExternalId', params, null , null , success, error);
    }
    
    var findPendingCycleForBAIdentity = function(params, success, error) {
        RESTSrvc.postForData('findPendingCycleForBAIdentity', params, null , null , success, error);
    }
    
    return {
        getBillingAccounts: getBillingAccounts,
		getBillingAccountsSubscriptions: getBillingAccountsSubscriptions,
        getEntities: getEntities,
        doAjaxCall : doAjaxCall,
        findPendingCycleForBE: findPendingCycleForBE,
        findPendingCycleForBAExternalId: findPendingCycleForBAExternalId,
        findPendingCycleForBAIdentity : findPendingCycleForBAIdentity,
        getGroupFilterConfiguration: function(preSelectedFilters) {
            var defaultFiltersConfig = [];
            defaultFiltersConfig.push(new WFMFilterConfiguration("externalId","text","Group ID",{},{}));
            defaultFiltersConfig.push(new WFMFilterConfiguration("subscriptionId","text","Billing Account ID",{},{}));
            defaultFiltersConfig.push(new WFMFilterConfiguration("name","text","Group Name",{},{}));
            defaultFiltersConfig.push(new WFMFilterConfiguration("coverageDate","daterange","Coverage Date",{},{}));
            defaultFiltersConfig.push(new WFMFilterConfiguration(
            "status","checkbox","Status",{
                enableAll: true
            },{
                "com.hcentive.billing.core.commons.domain.enumtype.BEStatus.ACTIVE": "Active",
                "com.hcentive.billing.core.commons.domain.enumtype.BEStatus.INACTIVE": "Inactive"
            }));
            
            return new WFMFIlterBoxConfiguration(defaultFiltersConfig);
        }
    };
}
];


//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].services.push({
    "name": "fetchGroupServ",
    "id": hcentive.WFM.fetchGroupServ
});
