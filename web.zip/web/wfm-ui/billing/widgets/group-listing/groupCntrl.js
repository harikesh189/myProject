hcentive.WFM.groupCntrl = ['$scope', 'fetchGroupServ', 'EventBusSrvc', '$filter', 'NotifySrvc', 'AssociatedEntitiesService','popupService','$translate',
    function ($scope, fetchGroupServ, EventBusSrvc, $filter, NotifySrvc, systemService,popupService,$translate) {
	
	$scope.businessEntities={};
	$scope.contactNumberArray = {};
	$scope.contactPersonName={};
	EventBusSrvc.subscribeAndInvalidatePayload('pageBackURL'); //clearing page back URL from event bus
	$scope.pageBackFilters = EventBusSrvc.subscribeAndInvalidatePayload('pageBackFilters'); //clearing page back URL from event bus
	//headers for group page
	$scope.GroupTableHeaders = [ {
		'isSortable' : 'no',
		'key' : 'expandRow',
		'desc' : '',
		'contentType' : 'html'
	}, {
		'isSortable' : 'yes',
		'key' : 'entityId',
		'desc' : 'Group ID',
		'contentType' : 'String',
		'sortableKey':'externalId'
	},  {
		'isSortable' : 'yes',
		'key' : 'name',
		'desc' : 'Group Name',
		'contentType' : 'String',
		'sortableKey':'profile.name'
	}, {
		'isSortable' : 'yes',
		'key' : 'lastupdated',
		'desc' : 'Last Updated',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.modifiedAt'
	},{
		'isSortable' : 'yes',
		'key' : 'tenantId',
		'desc' : 'Source',
		'contentType' : 'String',
		'sortableKey':'tenantId'
	},{
		'isSortable' : 'yes',
		'key' : 'status',
		'desc' : 'Status',
		'contentType' : 'String',
		'sortableKey':'status'
	}, {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : 'Actions',
		'contentType' : 'html'
	} ];
	
	// headers for group - subscriber detail
	$scope.subscribersTableHeaders = [ {
		'isSortable' : 'yes',
		'key' : 'subscriptionId',
		'desc' : 'Billing Account',
		'contentType' : 'String',
		'sortableKey':'externalId'
	},  {
		'isSortable' : 'yes',
		'key' : 'coverageBeginsOn',
		'desc' : 'Effective Date',
		'contentType' : 'Date',
		'sortableKey':'profile.name'
	}, {
		'isSortable' : 'yes',
		'key' : 'coverageEndsOn',
		'desc' : 'Termination Date',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.modifiedAt'
	}, {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : 'Actions',
		'contentType' : 'html'
	} ];
	//headers for individual page
	$scope.IndividualTableHeaders = [ {
		'isSortable' : 'yes',
		'key' : 'entityId',
		'desc' : 'Entity ID',
		'contentType' : 'String',
		'sortableKey':'externalId'
	}, {
		'isSortable' : 'yes',
		'key' : 'name',
		'desc' : 'Name',
		'contentType' : 'String',
		'sortableKey':'profile.name'
	}, {
		'isSortable' : 'yes',
		'key' : 'status',
		'desc' : 'Status',
		'contentType' : 'String',
		'sortableKey':'status'
	},{
		'isSortable' : 'yes',
		'key' : 'tenantId',
		'desc' : 'Source',
		'contentType' : 'String',
		'sortableKey':'tenantId'
	}, {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : 'Actions',
		'contentType' : 'html'
	} ];
	//headers for Broker page
	$scope.BrokerTableHeaders = [ {
		'isSortable' : 'yes',
		'key' : 'entityId',
		'desc' : 'Entity ID',
		'contentType' : 'String',
		'sortableKey' : 'externalId' 
	}, {
		'isSortable' : 'yes',
		'key' : 'name',
		'desc' : 'Broker Name',
		'contentType' : 'String',
		'sortableKey' : 'profile.name' 
	}, {
		'isSortable' : 'no',
		'key' : 'agencyId',
		'desc' : 'Agency ID',
		'contentType' : 'String',
		'sortableKey' : 'agencyId'
	}, {
		'isSortable' : 'no',
		'key' : 'npn',
		'desc' : 'NPN',
		'contentType' : 'String',
		'sortableKey' : 'npn'
	},{
		'isSortable' : 'yes',
		'key' : 'createdBy',
		'desc' : 'Created By',
		'contentType' : 'String',
		'sortableKey' : 'auditInfo.createdByName'
	}, {
		'isSortable' : 'yes',
		'key' : 'creationDate',
		'desc' : 'Creation Date',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.createdAt.date'
	},{
		'isSortable' : 'yes',
		'key' : 'modifiedDate',
		'desc' : 'Last Updated',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.modifiedAt'
	},{
		'isSortable' : 'yes',
		'key' : 'tenantId',
		'desc' : 'Source',
		'contentType' : 'String',
		'sortableKey':'tenantId'
	},{
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : 'Actions',
		'contentType' : 'html'
	} ];
	//headers for healthPlan page
	$scope.CarrierTableHeaders = [ {
		'isSortable' : 'yes',
		'key' : 'entityId',
		'desc' : 'Entity ID',
		'contentType' : 'String',
		'sortableKey' : 'externalId'
	}, {
		'isSortable' : 'yes',
		'key' : 'name',
		'desc' : 'Issuer Name',
		'contentType' : 'String',
		'sortableKey' : 'profile.name'
	},{
		'isSortable' : 'yes',
		'key' : 'createdBy',
		'desc' : 'Created By',
		'contentType' : 'String',
		'sortableKey' : 'auditInfo.createdByName'
	}, {
		'isSortable' : 'yes',
		'key' : 'creationDate',
		'desc' : 'Creation Date',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.createdAt.date'
	},{
		'isSortable' : 'yes',
		'key' : 'modifiedDate',
		'desc' : 'Last Updated',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.modifiedAt'
	}, {
		'isSortable' : 'yes',
		'key' : 'status',
		'desc' : 'Status',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'tenantId',
		'desc' : 'Source',
		'contentType' : 'String',
		'sortableKey':'tenantId'
	}, {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : 'Actions',
		'contentType' : 'html'
	} ];
	//header for other table
	$scope.OtherTableHeaders = [ {
		'isSortable' : 'yes',
		'key' : 'entityId',
		'desc' : 'Entity ID',
		'contentType' : 'String',
		'sortableKey' : 'externalId'
	}, {
		'isSortable' : 'yes',
		'key' : 'otherEntityType',
		'desc' : 'Entity Type',
		'contentType' : 'String',
		'sortableKey' : 'type'
	}, {
		'isSortable' : 'yes',
		'key' : 'name',
		'desc' : 'Entity Name',
		'contentType' : 'String',
		'sortableKey' : 'profile.name'
	},{
		'isSortable' : 'yes',
		'key' : 'createdBy',
		'desc' : 'Created By',
		'contentType' : 'String',
		'sortableKey' : 'auditInfo.createdByName'
	}, {
		'isSortable' : 'yes',
		'key' : 'creationDate',
		'desc' : 'Creation Date',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.createdAt.date'
	}, {
		'isSortable' : 'yes',
		'key' : 'modifiedDate',
		'desc' : 'Last Updated',
		'contentType' : 'Date',
		'sortableKey':'auditInfo.modifiedAt'
	}, {
		'isSortable' : 'yes',
		'key' : 'status',
		'desc' : 'Status',
		'contentType' : 'String'
	},{
		'isSortable' : 'yes',
		'key' : 'tenantId',
		'desc' : 'Source',
		'contentType' : 'String',
		'sortableKey':'tenantId'
	}, {
		'isSortable' : 'no',
		'key' : 'action',
		'desc' : 'Actions',
		'contentType' : 'html'
	} ];
	
	   $scope.OtherFilters = [{
	        'filterKey': 'externalId',
	        'filterType': 'TextBox',
	        'filterQueryKey': 'externalId'
	    }, 
	    {
	        'filterKey': 'name',
	        'filterType': 'TextBox',
	        'filterQueryKey': 'profile.name'
	    }, 
	    {
	        'filterKey': 'status',
	        'filterType': 'SelectBox'
	    }, 
	    {
	        'filterKey': 'type',
	        //  'filterType': 'String',
	        'filterType': 'SelectBox'
	    }];
	
	//filter json for group
	$scope.GroupFilters = [{'filterKey':'externalId','filterType':'TextBox' , 'filterQueryKey':'externalId'},
						   {'filterKey':'name','filterType':'TextBox','filterQueryKey':'profile.name'},
						   {'filterKey':'type','filterType':'SelectBox'}];
	
	
	$scope.sort = defaultSort('');
	$scope.pagination = defaultPagination('auditInfo.modifiedAt','desc');
	var successCallback = function(data){
		console.log('success call back');
		$scope.pagination.totalNoPages  = data.totalPages;
		$scope.pagination.totalElements = data.totalElements;
		if($scope.callerPage == 'Group'){
			$scope.grouplist = getGroupList($scope,data,$filter, $scope.clientDateFormat,fetchGroupServ);
			$scope.updateLeftNav('Groups');
			//$scope.grouplist.length = data.totalElements;
		}else if($scope.callerPage == 'Individual'){
			$scope.individualList = getindividualList($scope,data);
			//$scope.individualList.length = data.totalElements;
		}else if($scope.callerPage =='Broker'){			
			$scope.brokerList = getBrokerList($scope,data,$filter,$scope.clientDateFormat,EventBusSrvc);
			//$scope.brokerList.length = data.totalElements;
		}else if($scope.callerPage == 'HealthPlanProvider'){
			$scope.healthPlanList = getHealthPlanList($scope,data,$filter,$scope.clientDateFormat,EventBusSrvc);
			//$scope.healthPlanList.length = data.totalElements;
		}else if($scope.callerPage == 'OTHER'){
			$scope.otherList = getOtherList($scope,data,$filter,$scope.clientDateFormat,EventBusSrvc,$translate);
			//$scope.otherList.length = data.totalElements;
		}
		else{
			console.log('discripency between caller page name and entry found in DB');
		}
	};

	var errorCallback = function(){
		console.log('error call back');
	};
	
	$scope.getGroups = function(pageName){
		$scope.callerPage = pageName;
		var serachCriteria=populateSearchCriteria();
		//var serachCriteria=createSearchCriteria();
		fetchGroupServ.doAjaxCall(serachCriteria,successCallback,errorCallback);
	};
	
	  $scope.fetchBillingAccount=function(beExternalId){
		  var searchCriteria ={};
	   	searchCriteria.criteria ={};
	   	searchCriteria.criteria["owner.externalId"]= { "operator": "=","columnValue":  "'"+beExternalId+"'"} ;
	   	var paginationForFirst = getAllContent('','');
	   	searchCriteria.pageRequestCriteria = getPageRequestCriteria(paginationForFirst);
	   	var promise =fetchGroupServ.getBillingAccounts(searchCriteria);
	   	return promise;/*.then(function(success){
	   	   
	   		   return value.externalId;
	   	   });
	   	},function(error){
	   		console.log("Error while getting billing accoutns");
	   	});	  */
	  }	
	
	
	$scope.setPageName = function(pageName){
		$scope.callerPage = pageName;
	};
	$scope.fetchdata = function(paginationObj,filterObj){
		$scope.pagination = paginationObj;
		$scope.filterObject = filterObj;
		console.log("filters : "+ angular.toJson(filterObj));
		$scope.getGroups($scope.callerPage);
	};
	

		function populateSearchCriteria(){
		var serachCriteria={};
		serachCriteria.criteria = {};
		serachCriteria.pageRequestCriteria = getPageRequestCriteria($scope.pagination);
		serachCriteria.criteria["operator.externalId"] = { "operator": "=","columnValue":  "'"+$scope.wfmAppContext.loggedInUser.tenantId+"'"} ;
		
		if($scope.callerPage == 'OTHER'){
			serachCriteria.criteria["type"] =  { "operator": "IN", "columnValue": "('OtherRegulatoryBody','Exchange', 'BenefitVendor','SubsidyProvider', 'Client')", 'caseSensitiveSearch' : 'false' };
		}
		else {
			serachCriteria.criteria["type"] =  { "operator": "=", "columnValue": "'"+$scope.callerPage+"'", 'caseSensitiveSearch' : 'false' };
		}
		
		if($scope.filterObject.length > 0){
			serachCriteria = modifySearchCreiteria(serachCriteria);
		}
		else{
			var jsonObjectKey = "status";
			var jsonObjectValue = "ACTIVE";
			serachCriteria.criteria[jsonObjectKey] = { "operator" : "=", "columnValue": "'"+jsonObjectValue+"'" };
		}
		return serachCriteria;
	}
	
	function modifySearchCreiteria(searchCriteriaJson){
		
		angular.forEach($scope.filterObject, function(jsonObject, index) {
			var jsonObjectKey = Object.keys(jsonObject);
			var jsonObjectValue = jsonObject[jsonObjectKey];
			var operator = "=";
			if(jsonObjectKey == "profile.name" || jsonObjectKey == "externalId") {
				operator = "like";
				jsonObjectValue = "%"+jsonObjectValue+"%";
			}
			searchCriteriaJson.criteria[jsonObjectKey] = {
								'operator' : operator,
								'columnValue' :  "'"+jsonObjectValue+"'" ,
								'caseSensitiveSearch' : 'false'
							};
		});
		return searchCriteriaJson;
	}

	 $scope.offSchedulePopUp = function(beId,baId) {
	        //3rd parameter means asking for date or not on which invoice is to be generated.
	        popupService.openOffSchedulePopup(beId,baId, $scope, true);
	    }
	    ;
        
        $scope.publishPageBackFilters = function(pageBackFilters){
    		EventBusSrvc.publish('pageBackFilters',pageBackFilters);
    	}
        
       
        
        
        $scope.transformInnerTableData = function(data,beIdentity){
        	//alert(data);
        	
			console.log("Inside transform Inner Table data");
			var entitiesInnerDataList = [];
			angular.forEach(data, function(value){
				var entityInnerDataObj = {};
	            entityInnerDataObj.subscriptionId = value.externalId;
	            entityInnerDataObj.billingAccountIdentity = value.identity;
	            entityInnerDataObj.entityId = value.owner.externalId;
	            entityInnerDataObj.name = value.owner.profile.displayName;
	            entityInnerDataObj.parentGroup = value.owner.profile.parentOrg;
	            entityInnerDataObj.status = value.owner.status;
	            entityInnerDataObj.tenantId = value.owner.tenantId;
	            entityInnerDataObj.itemRecordId = value.owner.itemRecordId;
	            entityInnerDataObj.identity = value.owner.identity;
	            entityInnerDataObj.lastupdated = value.owner.auditInfo.modifiedAt.date;
	            entityInnerDataObj.subscriptionStatus = value.subscriptionstatus;
	           // entityInnerDataObj.value=value;
	            if (value.billingAccountPeriod && value.billingAccountPeriod.beginsOn) {
	                entityInnerDataObj.coverageBeginsOn = $scope.toUTCDate(value.billingAccountPeriod.beginsOn.date);
	            }
	            if (value.billingAccountPeriod && value.billingAccountPeriod.endsOn) {
	                entityInnerDataObj.coverageEndsOn = $scope.toUTCDate(value.billingAccountPeriod.endsOn.date);
	            }
	            entityInnerDataObj.action = '<a href="" class="toolTip" title="Financial Summay Details" ng-click="viewFinancialSummaryForSubscription(\'' +  entityInnerDataObj.itemRecordId + '\',\'' +entityInnerDataObj.entityId + '\',\'' +entityInnerDataObj.subscriptionId +'\')"><i class="icon-view-details"></i></a><span class="lineDivider"></span><a href="" class="js-viewPolicy toolTip" title="View Policy" ng-click="viewPolicyForGrpEntity(\''+entityInnerDataObj.billingAccountIdentity+'\')"><i class="icon-view-policy"></i></a><span class="lineDivider"></span><a class="viewDetails" href="" title="Subscriber Details" ng-click="viewMemberContracts(\'' + entityInnerDataObj.entityId  + '\',\''+entityInnerDataObj.billingAccountIdentity+'\',\'' + entityInnerDataObj.itemRecordId + '\')"><i class="icon-hierarchy"></i></a><span class="lineDivider"></span><a href="" class="toolTip" title="Bill Cycles Details" ng-click="fetchAssociatedEntityForBillCycle(\'' + entityInnerDataObj.entityId + '\',\'' + entityInnerDataObj.name + '\',\'' + entityInnerDataObj.billingAccountIdentity + '\',\'' + entityInnerDataObj.subscriptionId + '\')"><i class="icon-billingCycle"></i></a>';
	            if ($scope.isRenderable('off-schedule') && value.owner.billable == true) {
	                entityInnerDataObj.action = entityInnerDataObj.action + '<span class="lineDivider"></span><a class="viewProfile js-icon-editgrpbillcycles" href="javascript:void(0);" title="Off Schedule" data-ng-click="offSchedulePopUp(\'' + entityInnerDataObj.identity + '\',\'' + entityInnerDataObj.billingAccountIdentity + '\')"><span class="toolTip icon-Off-Schedule"></span></a>';
	            }
	        	entitiesInnerDataList.push(entityInnerDataObj);
			});
			return entitiesInnerDataList; 
		};
        
        
        
    }];

//wireup the controller to application

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "groupCntrl",
	"id" : hcentive.WFM.groupCntrl	
});

//local utility function
function getGroupList($scope,data,$filter,timeFormat,fetchGroupServ){
	//temp testinting
	var groupList = [];
	if(data == "" || data.content.length == 0){
		groupList = "No Data";
		return groupList;
	}
	
	var innerTableIndex = 1;
	angular
			.forEach(
					data.content,
					function(value, key) {
						var groupObj = {};
						groupObj.entityId = value.externalId;
						groupObj.name = value.profile.displayName;
						groupObj.parentGroup = value.profile.parentOrg;
						groupObj.status = value.status;
						groupObj.tenantId=value.tenantId;
						groupObj.itemRecordId = value.itemRecordId;
						groupObj.identity = value.identity;
                        groupObj.lastupdated = value.auditInfo.modifiedAt.date;
                        var groupId=value.externalId;
                        groupObj.action = '<a href="" class="toolTip" title="View Details" ng-click="viewGroupDetails(\'' + groupObj.itemRecordId + '\',\'' + groupObj.identity + '\',\'' + groupObj.entityId + '\')"><i class="icon-view-details"></i></a>';
                        groupList.push(groupObj);
                       /* if ($scope.isRenderable('off-schedule') && value.billable == true) {
                            groupObj.action = groupObj.action + '<span class="lineDivider"></span><a class="viewProfile js-icon-editgrpbillcycles" href="javascript:void(0);" title="Off Schedule" data-ng-click="offSchedulePopUp(\'' + groupObj.identity + '\')"><span class="toolTip icon-Off-Schedule"></span></a>';
                        }*/
                       
                       // var subscribersDetail =[];
                        
                        var searchCriteria ={};
                     	searchCriteria.criteria ={};
                     	searchCriteria.criteria["owner.externalId"]= { "operator": "=","columnValue":  "'"+groupId+"'"} ;
                     	var paginationForFirst = getAllContent('','');
                     	searchCriteria.pageRequestCriteria = getPageRequestCriteria(paginationForFirst);
                     	var promise =fetchGroupServ.getBillingAccounts(searchCriteria);
                     	promise.then(function(success){
                     		innerTableIndex++;
                     		console.log("Promise made !!!");
                     		console.log(success);
                     		var billingAccountList = $scope.transformInnerTableData(success,groupId);
    						var innerTable = {
    								"innerTableColSpan" : 5,
    								"innerChild1TableId" : innerTableIndex,
    								"headers" : $scope.subscribersTableHeaders,
    								"data" : billingAccountList
    							};
    						
    						groupObj.innerTable = innerTable;
    						 groupObj.expandRow ='<a ng-class="{true :\'slide-minus slide-plus hide-text\' , false : \'slide-plus hide-text\'}[ innerChild1TableId['	+ innerTableIndex
 							+ '] == true ]" href="javascript:;" ng-click="toggle('
    								+ innerTableIndex + ');"></a>';
                     		//return billingAccountList;
                     		
                     	},function(error){
                     		console.log("Error while getting billing accoutns");
                     	});
                 		
                        
                        
                        
                        //var billingAccountData = openEntityDetail(groupId,$scope,fetchGroupServ);
                        //alert(billingAccountData);
                       // groupObj.
                        	
                        	//fetchGroupServ.setPolicyData(value);
					});
					return groupList;
}

function getindividualList($scope,data){

	var individualList = [];
	if(data == "" || data.content.length == 0){
		individualList = "No Data";
		return individualList;
	}
	angular
			.forEach(
					data.content,
					function(value, key) {
						var indObj = {};
						indObj.entityId = value.externalId;
						indObj.name = value.profile.displayName;
						indObj.status = value.status;
						indObj.tenantId=value.tenantId;
						indObj.itemRecordId = value.itemRecordId;
						indObj.identity = value.identity;
                        indObj.action = '<a href="" class="toolTip" title="View Details" ng-click="viewIndividualDetails(\'' + indObj.itemRecordId + '\', \'' + indObj.identity + '\',\'' + indObj.entityId + '\')"><i class="icon-view-details"></i></a><span class="lineDivider"></span><a href="" class="js-viewPolicy toolTip" title="View Policy" ng-click="viewPolicyForIndEntity(value)"><i class="icon-view-policy"></i></a><span class="lineDivider"></span><a href="" class="toolTip" title="Bill Cycles Details" ng-click="fetchAssociatedEntityForBillCycle(value)"><i class="icon-billingCycle"></i></a>';
                        if ($scope.isRenderable('off-schedule') && value.invoiceable == true) {
                        	 indObj.action = indObj.action + '<span class="lineDivider"></span><a class="viewProfile js-icon-editgrpbillcycles" href="javascript:void(0);" title="Off Schedule" data-ng-click="offSchedulePopUp(\'' + indObj.entityId + '\', \'' + "" + '\')"><span class="toolTip icon-Off-Schedule"></span></a>';
                        		
                        }
                        individualList.push(indObj);
					});
					
					return individualList;
}

function getBrokerList($scope,data,$filter,timeFormat,EventBusSrvc){

	var brokerList = [];
	if(data == "" || data.content.length == 0){
		brokerList = "No Data";
		return brokerList;
	}
	angular
			.forEach(
					data.content,
					function(value, key) {
						var brokerObj = {};
						brokerObj.profile={};
						brokerObj.entityId = value.externalId;
						brokerObj.tenantId=value.tenantId;
						/*if(value.auditInfo.modifiedAt != undefined && value.auditInfo.modifiedAt != null)
						brokerObj.createdon=$filter('date')(value.auditInfo.modifiedAt.date,timeFormat);
						if(value.auditInfo.createdBy && value.auditInfo.createdBy != null)
						brokerObj.createdby=value.auditInfo.createdBy;
						brokerObj.tenantId=value.tenantId;*/
						brokerObj.name = ((value.profile!=null && value.profile !=undefined) ? value.profile.displayName : '');
						brokerObj.itemRecordId = value.itemRecordId;
						
						brokerObj = populateAuditInfo(brokerObj,value.auditInfo);
						
						if(value.additionalInfoSet!=null && value.additionalInfoSet!='undefined'){
						var items = value.additionalInfoSet.items; 
						angular.forEach(items, function(value,key){
							
							if(value.name == 'agencyId'){
								brokerObj.agencyId = value.value;
							}
							if(value.name == 'nationalProducerNumber'){
								brokerObj.npn = value.value;
							}
						});
						}
						var brokerParam ={"source":value.tenantId};
						EventBusSrvc.publish("EntityParams",brokerParam);
						brokerObj.action = '<a href="" class="viewProfile" title="View Details" ng-click="viewBrokerDetails('+key+')"><i class="icon-view-details"></i></a><!--<span class="lineDivider"></span> <a href="broker-edit.html#anchorName4" class="viewProfile" title="Edit"><img src="../images/editIcon.png"></a> -->';
						brokerList.push(brokerObj);
					});
					return brokerList;
}


function getHealthPlanList($scope,data,$filter,timeFormat,EventBusSrvc){

	var carrierList = [];
	if(data == "" || data.content.length == 0){
		carrierList = "No Data";
		return carrierList;
	}
	angular
			.forEach(
					data.content,
					function(value, key) {
						var carrierObj = {};
						carrierObj.entityId = value.externalId;
						carrierObj.name = value.profile.displayName;
						carrierObj.status = value.status;
					/*	if(value.auditInfo.createdAt != undefined && value.auditInfo.createdAt != null)
						carrierObj.createdon=$filter('date')(value.auditInfo.createdAt.date,timeFormat);
						if(value.auditInfo.createdBy && value.auditInfo.createdBy != null)
						carrierObj.createdby=value.auditInfo.createdBy;*/
						carrierObj.itemRecordId = value.itemRecordId;
						carrierObj.tenantId=value.tenantId;

						carrierObj.identity=value.identity;
						carrierObj = populateAuditInfo(carrierObj,value.auditInfo);
                        carrierObj.action = '<a href="" class="viewProfile" title="View Details" ng-click="viewHealthProviderDetails('+key+')"><i class="icon-view-details"></i></a><span class="lineDivider"></span><a href="" class="js-viewPolicy toolTip" title="View Policy" ng-click="viewPolicyForIssuerEntity(value)"><i class="icon-view-policy"></i></a> ';
                        
                        if ($scope.isRenderable('off-schedule') && value.invoiceable == true) {
                        	carrierObj.action = carrierObj.action + '<span class="lineDivider"></span><a class="viewProfile js-icon-editgrpbillcycles" href="javascript:void(0);" title="Off Schedule" data-ng-click="offSchedulePopUp(\'' + value.identity+ '\', \'' + "" + '\')"><span class="toolTip icon-Off-Schedule"></span></a>';
                        }
                     
                        var issuerParam ={"source":value.tenantId};
                        EventBusSrvc.publish("EntityParams",issuerParam);
						
                        
                        carrierList.push(carrierObj);
					});
					return carrierList;
}
function getOtherList($scope,data,$filter,timeFormat,EventBusSrvc,$translate){

	var otherList = [];
	if(data == "" || data.content.length == 0){
		otherList = "No Data";
		return otherList;
	}
	angular
			.forEach(
					data.content,
					function(value, key) {
						var otherObj = {};
						otherObj.entityId = value.externalId;
						otherObj.otherEntityType = $translate.instant(value.type);
					      otherObj.entityType=value.type;
						otherObj.name=""; // added by harikesh
						if(value.profile.name !=null && value.profile.name !=undefined){
						otherObj.name =value.profile.name;
						}	
						//otherObj.parent = value.profile.parentOrg;
						otherObj.status = value.status;
						otherObj.itemRecordId = value.itemRecordId;
						otherObj.tenantId=value.tenantId;
						
						otherObj = populateAuditInfo(otherObj,value.auditInfo);
						
						otherObj.identity = value.identity;
                        otherObj.action = '<a href="" class="viewProfile" title="View Details" ng-click="viewOtherEntity('+key+')"><i class="icon-view-details"></i></a>';
                        //<span class="lineDivider"></span> <a href="javascript:void(0);" class="viewProfile js-terminateEntity" title="Terminate Entity"><i class="icon-terminateEntity"></i></a>';
						
                        if ($scope.isRenderable('off-schedule') &&  value.invoiceable == true) {
                        	otherObj.action = otherObj.action + '<span class="lineDivider"></span><a class="viewProfile js-icon-editgrpbillcycles" href="javascript:void(0);" title="Off Schedule" data-ng-click="offSchedulePopUp(\'' + value.identity+ '\', \'' + "" + '\')"><span class="toolTip icon-Off-Schedule"></span></a>';
                        }
                        
                            var otherParam ={"source":value.tenantId};
                            
                            EventBusSrvc.publish("EntityParams",otherParam);
                        
                        otherList.push(otherObj);
					});
					return otherList;
}