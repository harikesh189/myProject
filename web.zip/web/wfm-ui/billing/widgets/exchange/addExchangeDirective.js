hcentive.WFM.addexchangedirective=[function(){
	
	return {
		restrict : 'EA',
		templateUrl : function(elem,attr){return getTemplateUrl(attr, "widgets/exchange/exchange.html")},
		link : function(scope, iElement, iAttrs, ctrl) {
			//scope.attrs = iAttrs;
		}
	};
	
} ];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "addexchangedirective",
	"id" : hcentive.WFM.addexchangedirective
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
		"name" : "addexchangedirective",
		"id" : hcentive.WFM.addexchangedirective
	});
                                  
                                  
                                  
                                  
                                  
                      