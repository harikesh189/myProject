hcentive.WFM.entityService = ['$http', 'RESTSrvc',function($http, RESTSrvc) {
	return {
		 fetchBusinessEntity : function (beName,beType,scope) {
			var projectedFields = [
		    {
		        "entityField": "businessEntity.profile.name",
		        "mappedField": "displayName"
		     },
		  	{
		        "entityField": "businessEntity.externalId",
		        "mappedField": "externalId"
		     }];
			
			function entitySucess(content){
				scope.entities = content.content;
			}
			
			function entityError(content){
				scope.entities = [];
				//scope.entities='No Data Found';
			}
			var searchCriteria = {};
			var criteria = {};
			criteria = addStringFilter(criteria,'beName',beName,false,false);
			criteria = addStringFilter(criteria,'beType',beType,false,false);
			searchCriteria.criteria = criteria;
			searchCriteria.projectedFields = projectedFields;
			searchCriteria.pageRequestCriteria = null;
			
			function transformFn(content){
				if(content && content.length != 0){
					angular.forEach(content, function(value, key) {
						value.displayName = value.displayName +' ('+value.externalId+')';
					});
				}else{
					var emptyContent={displayName:'No record found',externalId:''};
					content.push(emptyContent);
				/*	angular.forEach(content, function(value, key) {
						value.displayName = 'No record found';
					});*/
					//return [];	
				}
				
				return content;
			}
			
        	return RESTSrvc.postForDataReturnsPromise('fetchBusinessEntity', {}, searchCriteria, transformFn);
    	}
	};
}];


//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "entityService",
	"id" : hcentive.WFM.entityService
});
