//customer configuration
hcentive.WFM.configData[hcentive.WFM.customer] = {
	"providers" : [ /*
					 * { "name" : "Media", "id" : hcentive.WFM.MediaProvider }
					 */],
	"services" : [ {
		"name" : "EventBusSrvc",
		"id" : hcentive.WFM.EventBusSrvc
	}, {
		"name" : "RESTSrvc",
		id : hcentive.WFM.RESTSrvc
	}],
	"directives" : [ 
	  {
		"name" : "canceldir",
		"id" : hcentive.WFM.CancelButtonDir
	  },
	  {
		  "name" : "wfmcalendar",
		  "id" : hcentive.WFM.CalendarDir
	  } ,
      {
		  "name": "erroraware",
          "id": hcentive.WFM.ErrorAwareDir
      }
    ],
	"filters" : [ {
		"name" : "WFMlink",
		"id" : hcentive.WFM.WFMLink
	}, {
		"name" : "descriptivename",
		"id" : hcentive.DescriptiveName
	}, {
		"name" : "InitCap",
		"id" : hcentive.InitCap
	}
	, {
		"name" : "ContactNumber",
		"id" : hcentive.ContactNumber
	}, {
		"name" : "customCurrency",
		"id" : hcentive.customCurrency
	} ],
	"controllers" : [ {
		"name" : "MainCtrl",
		"id" : hcentive.WFM.MainCtrl
	} ],
	"includes" : [ {
		'/home/home' : "includes/invoice/banner.html"
	}, {
		'/payment/pay-online' : "includes/payment/banner.html"
	}, {
		'/payment/quick-pay' : "includes/payment/banner.html"
	}, {
		'/payment/payment-status-eft' : "includes/payment/banner.html"
	}, {
		'/payment/recurring/auto-recurring' : "includes/payment/banner.html"
	}, {
		'/home/dashboard' : "includes/banner.html"
	} ]
};

// operator configuration
hcentive.WFM.configData[hcentive.WFM.operator] = {
	"providers" : [ /*
					 * { "name" : "Media", "id" : hcentive.WFM.MediaProvider }
					 */],
	"services" : [ {
		"name" : "EventBusSrvc",
		"id" : hcentive.WFM.EventBusSrvc
	}, {
		"name" : "RESTSrvc",
		id : hcentive.WFM.RESTSrvc
	}],
	"directives" : [ 
		{
			"name" : "canceldir",
			"id" : hcentive.WFM.CancelButtonDir
		},
		{
			"name" : "nextdir",
			"id" : hcentive.WFM.NextButtonDir
		},
		{
			"name" : "wfmcalendar",
			"id" : hcentive.WFM.CalendarDir
        },
        {
            "name": "erroraware",
            "id": hcentive.WFM.ErrorAwareDir
        }
	],
	"filters" : [ {
		"name" : "WFMlink",
		"id" : hcentive.WFM.WFMLink
	}, {
		"name" : "descriptivename",
		"id" : hcentive.DescriptiveName
	} , {
		"name" : "InitCap",
		"id" : hcentive.InitCap
	}, {
		"name" : "ContactNumber",
		"id" : hcentive.ContactNumber
	}, {
		"name" : "customCurrency",
		"id" : hcentive.customCurrency
	}],
	"controllers" : [ {
		"name" : "MainCtrl",
		"id" : hcentive.WFM.MainCtrl
	} ],
	"includes" : [ {
		'/home/home' : "includes/invoice/banner.html"
	}, {
		'/payment/pay-online' : "includes/payment/banner.html"
	}, {
		'/payment/quick-pay' : "includes/payment/banner.html"
	}, {
		'/payment/payment-status-eft' : "includes/payment/banner.html"
	}, {
		'/payment/recurring/auto-recurring' : "includes/payment/banner.html"
	}, {
		'/home/dashboard' : "includes/banner.html"
	} ]
};

//broker configuration
hcentive.WFM.configData[hcentive.WFM.broker] = {
	"providers" : [ /*
					 * { "name" : "Media", "id" : hcentive.WFM.MediaProvider }
					 */],
	"services" : [ {
		"name" : "EventBusSrvc",
		"id" : hcentive.WFM.EventBusSrvc
	}, {
		"name" : "RESTSrvc",
		id : hcentive.WFM.RESTSrvc
	}],
	"directives" : [ 
		{
			"name" : "canceldir",
			"id" : hcentive.WFM.CancelButtonDir
		},
		{
			"name" : "nextdir",
			"id" : hcentive.WFM.NextButtonDir
		},
		{
			"name" : "wfmcalendar",
			"id" : hcentive.WFM.CalendarDir
        },
        {
            "name": "erroraware",
            "id": hcentive.WFM.ErrorAwareDir
        }
	],
	"filters" : [ {
		"name" : "WFMlink",
		"id" : hcentive.WFM.WFMLink
	}, {
		"name" : "descriptivename",
		"id" : hcentive.DescriptiveName
	}, {
		"name" : "InitCap",
		"id" : hcentive.InitCap
	} , {
		"name" : "ContactNumber",
		"id" : hcentive.ContactNumber
	}, {
		"name" : "customCurrency",
		"id" : hcentive.customCurrency
	} ],
	"controllers" : [ {
		"name" : "MainCtrl",
		"id" : hcentive.WFM.MainCtrl
	} ],
	"includes" : [ {
		'/home/home' : "includes/invoice/banner.html"
	}, {
		'/payment/pay-online' : "includes/payment/banner.html"
	}, {
		'/payment/quick-pay' : "includes/payment/banner.html"
	}, {
		'/payment/payment-status-eft' : "includes/payment/banner.html"
	}, {
		'/payment/recurring/auto-recurring' : "includes/payment/banner.html"
	}, {
		'/home/dashboard' : "includes/banner.html"
	} ]
};


//mobile configuration
hcentive.WFM.configData[hcentive.WFM.mobile] = {
	"providers" : [ /*
					 * { "name" : "Media", "id" : hcentive.WFM.MediaProvider }
					 */],
	"services" : [ {
		"name" : "EventBusSrvc",
		"id" : hcentive.WFM.EventBusSrvc
	}, {
		"name" : "RESTSrvc",
		id : hcentive.WFM.RESTSrvc
	}],
	"directives" : [ 
		{
			"name" : "canceldir",
			"id" : hcentive.WFM.CancelButtonDir
		},
		{
			"name" : "nextdir",
			"id" : hcentive.WFM.NextButtonDir
		},
		{
			"name" : "wfmcalendar",
			"id" : hcentive.WFM.CalendarDir
        },
        {
            "name": "erroraware",
            "id": hcentive.WFM.ErrorAwareDir
        }
	],
	"filters" : [ {
		"name" : "WFMlink",
		"id" : hcentive.WFM.WFMLink
	}, {
		"name" : "descriptivename",
		"id" : hcentive.DescriptiveName
	}, {
		"name" : "InitCap",
		"id" : hcentive.InitCap
	} ],
	"controllers" : [ {
		"name" : "MainCtrl",
		"id" : hcentive.WFM.MainCtrl
	} ],
	"includes" : []
};

// XPG
hcentive.WFM.configData[hcentive.WFM.XPG_No_Login] = {
	"providers" : [ /*
					 * { "name" : "Media", "id" : hcentive.WFM.MediaProvider }
					 */],
	"services" : [ {
		"name" : "EventBusSrvc",
		"id" : hcentive.WFM.EventBusSrvc
	}, {
		"name" : "RESTSrvc",
		id : hcentive.WFM.RESTSrvc
	}],
	"directives" : [],
	"controllers" : [ {
		"name" : "MainCtrl",
		"id" : hcentive.WFM.MainCtrl
	} ]
};

