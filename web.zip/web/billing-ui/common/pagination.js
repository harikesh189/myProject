var tablePageSize = 25;
var exportPageSizeCriteria = 10000;

function defaultPagination(colToBeSorted, sortedOrder) {
	var pagination = {
		"pageIndex" : "0",
		"size" : tablePageSize,
		"sortedOrder" : sortedOrder,
		"sortedColumn" : colToBeSorted,
		"displayPageNo" : "1",
		"totalNoPages" : "1",
		"totalElements" :"0"
	};

	return pagination;
}

function getAllContent(colToBeSorted, sortedOrder) {
	var pagination = {
		"pageIndex" : "0",
		"size" : "1000",
		"sortedOrder" : sortedOrder,
		"sortedColumn" : colToBeSorted,
		"displayPageNo" : "1",
		"totalNoPages" : "1",
		"totalElements" :"0"
	};

	return pagination;
}

function defaultSort(colToBeSorted) {
	var sortConfig = {
		"sortedColumn" : colToBeSorted,
		"sortedOrder" : "desc",
		"sortedColClass" : "footable-sortable footable-sorted"
	};
	return sortConfig;
}

function pageChange(pageOperation, pagination) {
	var currPageNo = pagination.pageIndex;
	var currDispPageNo = pagination.displayPageNo;
	var noOfPages = pagination.totalNoPages;
	var indexPagination = '';
	var newPageIndex = '0';
	var newDisplayPageNo = '1';
	if (pageOperation == 'first') {
		newPageIndex = '0';
		newDisplayPageNo = '1';
	} else if (pageOperation == 'next') {
		newPageIndex = parseInt(currPageNo) + 1;
		newDisplayPageNo = parseInt(currDispPageNo) + 1;
	} else if (pageOperation == 'prev') {
		if (parseInt(currPageNo) != 0) {
			newPageIndex = parseInt(currPageNo) - 1;
			newDisplayPageNo = parseInt(currDispPageNo) - 1;
		}
	} else if (pageOperation == 'last') {
		newPageIndex = parseInt(noOfPages) - 1;
		newDisplayPageNo = parseInt(noOfPages);
	}
	if (parseInt(newPageIndex) < noOfPages) {
		indexPagination = {
			"newPageIndex" : newPageIndex,
			"newDisplayPageNo" : newDisplayPageNo
		};
	}
	return indexPagination;
}

function sortConfig(colToBeSorted, colSorted, sortedOrder) {
	var sortedColClass = '';
	if (colToBeSorted == colSorted) {
		if (sortedOrder == "desc") {
			sortedOrder = "asc";
			sortedColClass = "sorting_asc";
		} else {
			sortedOrder = "desc";
			sortedColClass = "footable-sorted-desc";
		}
	} else {
		sortedOrder = "desc";
		sortedColClass = "footable-sorted-desc";
	}
	var sortConfig = {
		"sortedColumn" : colToBeSorted,
		"sortedOrder" : sortedOrder,
		"sortedColClass" : sortedColClass
	};
	return sortConfig;
}

function getPageRequestCriteria(pagination) {
	var pageRequestCriteria = {
		"pageIndex" : pagination.pageIndex,
		"size" : pagination.size,
		"sortingOrder" : pagination.sortedOrder,
		"sortedColumn" : pagination.sortedColumn
	};
	return pageRequestCriteria;
}

function setExportPageSize(pagination){
	pagination.size = exportPageSizeCriteria;
	pagination.pageIndex = 0;
	return pagination;
}

function setDefaultPageSize(pagination,pageIndex){
	pagination.size = tablePageSize;
	pagination.pageIndex = pageIndex;
	return pagination;
}
