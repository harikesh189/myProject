hcentive.WFM.LogoutSrvc = ['$http', 'RESTSrvc',function($http, RESTSrvc) {

	var logout = function(params,data,successCallback, errorCallback){
		 RESTSrvc.getForData('logoutUIServiceUrl',params,null,successCallback,errorCallback);
	}
	return {
		logout : logout
	};
}];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "LogoutSrvc",
	"id" : hcentive.WFM.LogoutSrvc
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "LogoutSrvc",
	"id" : hcentive.WFM.LogoutSrvc
});

hcentive.WFM.configData[hcentive.WFM.broker].services.push({
	"name" : "LogoutSrvc",
	"id" : hcentive.WFM.LogoutSrvc
});

hcentive.WFM.configData[hcentive.WFM.mobile].services.push({
	"name" : "LogoutSrvc",
	"id" : hcentive.WFM.LogoutSrvc
});

