// Current Bill Banner control
hcentive.WFM.LogoutCtrl = [
		'$scope',
		'LogoutSrvc','$window', 'NotifySrvc',
		function($scope, LogoutSrvc ,$window , NotifySrvc) {
			var logoutSuccessCallback = function(data){
				$scope.safeApply($scope,function(){
					$window.location.href = data;
					console.log("redirecting to login!"+data);
		            deleteStorage('WFMHeadersStorage');
				});
			}
			
			var errorCallBack = function(){
				alert('error');
			}
		
			$scope.populateLogoutUrl = function() {
				   var baseUrl  = window.location.pathname;
                                 baseUrl = baseUrl.substring(0, baseUrl.lastIndexOf('admin/'+hcentive.WFM.client_id));
//                              baseUrl = baseUrl.replace('ui-gateway','security');
                              //  var logoutUrl = hcentive.WFM.serviceURL['logoutServiceUrl'];
                               // logoutUrl = "/security"+baseUrl + logoutUrl+"?client_id="+hcentive.WFM.client_id+"&response_type="+$scope.responseType;
								var logoutUrl =  baseUrl + "security/oAuth2/logout"+"?client_id="+hcentive.WFM.client_id+"&response_type="+$scope.responseType;
								return logoutUrl;


			}
					
			$scope.launchInlineModal = function() {
				var logoutUrl = $scope.populateLogoutUrl();
				NotifySrvc({
	              id: 'simpleDialog',
	              template:
	            	'<form method="post" name="logoutform" id="logoutform" class="formStyle" action="'+logoutUrl+'">' +
	                '<div class="row-fluid">' +
	                ' <p>You want to Logout.</p>' +
	                '</div>'+
	                '</form>',
	              title: 'Are You Sure?',
	              backdrop: true,
				  success: {label: 'Yes', fn: function() {$('#logoutform').submit();}},
	              cancel: {label: 'Cancel', fn: function() {}}
				});
			};
			
	}];
		
hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "LogoutCtrl",
	"id" : hcentive.WFM.LogoutCtrl
});

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "LogoutCtrl",
	"id" : hcentive.WFM.LogoutCtrl
});

hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "LogoutCtrl",
	"id" : hcentive.WFM.LogoutCtrl
});

hcentive.WFM.configData[hcentive.WFM.mobile].controllers.push({
	"name" : "LogoutCtrl",
	"id" : hcentive.WFM.LogoutCtrl
});