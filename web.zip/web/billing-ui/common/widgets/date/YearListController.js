// Current Bill Banner control
hcentive.WFM.YearListController = ['$scope', function($scope) {
			
			$scope.currentYear = new Date().getFullYear();
			
			$scope.yearsList = [];
			
			for(var i=0; i<15; i++)
			{
				var year = {};
				year.value = $scope.currentYear + i;
				year.displayName = $scope.currentYear + i;
				$scope.yearsList.push(year);
			}
			
		} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "YearListController",
	"id" : hcentive.WFM.YearListController
});

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "YearListController",
	"id" : hcentive.WFM.YearListController
});
hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "YearListController",
	"id" : hcentive.WFM.YearListController
});