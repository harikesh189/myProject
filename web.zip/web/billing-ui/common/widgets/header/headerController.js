hcentive.WFM.HeaderCtrl = [
		'$scope',
		'HeaderSrvc',
		'NotificationSrvc',
		'EventBusSrvc',
		function($scope, HeaderSrvc, NotificationSrvc, EventBusSrvc) {
	
			
			$scope.userConfiguration = $scope.$parent.wfmAppContext.configuration;
			$scope.currentUser = $scope.$parent.wfmAppContext.loggedInUser;
			
			$scope.updateContract = function(contract) {
				$scope.$parent.wfmAppContext.contextualContract = contract;
				if(angular.equals($scope.$parent.beType(),hcentive.WFM.beTypes["1"])){
				$scope.userDesignation = "Subscriber";
			} else if(angular.equals($scope.$parent.beType(),hcentive.WFM.beTypes["2"])){
				$scope.userDesignation = "Group Admin";
			}
				getNotifications(contract);
				// publish contractUpdated event
				EventBusSrvc.publish('contractUpdated', contract);
			};

			var notificationSuccess = function(notifications) {
				var notificationsJSON = notifications;
				$scope.notifications = notificationsJSON.content;
				EventBusSrvc.subscribe('notificationRead', $scope, function(
						notificationIds) {
					if (notificationIds != null && notificationIds.length > 0) {
						var unreadNotifications = [];
						// remove READ notifications from notifications
						angular.forEach($scope.notifications, function(
								notification) {
							if (notificationIds.indexOf(notification.id)>-1) {
								notification.status = "READ";
							}else {
								unreadNotifications.push(notification);
							}
						});
						$scope.notifications = unreadNotifications;
					}
				});

			};
			var notificationError = function(error) {
				console.log('Error in fetching notification');
			};
			var getNotifications = function(contract) {
				var pagination = {};
				pagination.displayPage = "1";
				pagination.pageIndex = "0";
				pagination.size = "2";
				pagination.sortedColumn = "dateCreated";
				pagination.sortedOrder = "desc";
				pagination.totalElements = "0";
				pagination.totalNoPages = "1";
				var data = angular.toJson(getPageRequestCriteria(pagination));
				NotificationSrvc.getNotifications({
					"beId" :   contract.beId,
					"status" : "NEW"
				}, data , notificationSuccess, notificationError);
			};
			var contractSuccess = function(contracts) {
				$scope.contracts = contracts;
				angular.forEach($scope.contracts, function(value, key) {
					var beIdKey = key;
					angular.forEach(value, function(value, key) {
						var contractJSON = {};
						contractJSON["beId"] = beIdKey;
						contractJSON["contractId"] = value.contractId;
						contractJSON["contractTitle"] = value.contractTitle;
						$scope.$parent.wfmAppContext.contracts
								.push(contractJSON);
					});
				});
				$scope.contracts = $scope.$parent.wfmAppContext.contracts;
				$scope.$parent.wfmAppContext.contextualContract = $scope.$parent.wfmAppContext.contracts[0];
				$scope
						.updateContract($scope.$parent.wfmAppContext.contextualContract);
				// get notifications for current contract
				getNotifications($scope.$parent.wfmAppContext.contextualContract);
			};
			var contractError = function(error) {
			};
			$scope.safeApply($scope, function() {
				//HeaderSrvc.getContracts(contractSuccess, contractError);
			});

			// method body... do something attach to scope
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "HeaderCtrl",
	"id" : hcentive.WFM.HeaderCtrl
});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "HeaderCtrl",
	"id" : hcentive.WFM.HeaderCtrl
});

hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "HeaderCtrl",
	"id" : hcentive.WFM.HeaderCtrl
});