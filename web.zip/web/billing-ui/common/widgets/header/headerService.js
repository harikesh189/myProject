hcentive.WFM.HeaderSrvc = ['$http', 'RESTSrvc',function($http, RESTSrvc) {
	
	var getContracts = function(successCallback, errorCallback) {
		var resourceUriKey = 'fetchContractInfo';
		var data = {};
		RESTSrvc.postForData(resourceUriKey,"",data,null,successCallback,errorCallback);
	}
			
	return {
		getContracts : getContracts
	};
}];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "HeaderSrvc",
	"id" : hcentive.WFM.HeaderSrvc
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "HeaderSrvc",
	"id" : hcentive.WFM.HeaderSrvc
});

hcentive.WFM.configData[hcentive.WFM.broker].services.push({
	"name" : "HeaderSrvc",
	"id" : hcentive.WFM.HeaderSrvc
});