hcentive.WFM.CustomTableCtrl = [
		'$scope','$filter','$translate','$rootScope','$timeout',
		function($scope,$filter,$translate,$rootScope,$timeout) {

			$scope.pageNumber = 1;
			$scope.masterData = '';
			$scope.enablePagination = 'Yes';
			$scope.serversorting = 'No';
			$scope.paginationColSpan = '1';
			$scope.filters = [];
			$scope.filterJson = [];
			$scope.clientCaching = true;
			$scope.searchedData = '';
			$scope.masterTotalNoPages = 0;
			$scope.tableFooter ='';
			$scope.showNoOfRecords =  true;
			$scope.fetchDataFnName = 'fetchdata';
			$scope.paginationObjName = 'pagination';
			$scope.isTableRenderable = true;
			$scope.isDrillDownFilterEnabled = false;
			
			$scope.sortConfig = {
				"sortedColumn" : "",
				"sortingOrder" : "",
				"sortedColClass" : ""
			};
			
			$scope.tablePagination = {
				"pageSize" : 25,
				"noOfPages" : 1,
				"totalElements" : 0
			};
			
			$scope.getClass = function(valueObj,index){
				if(valueObj && valueObj.rowColor){
					return valueObj.rowColor;
				}
			}

			$scope.pageChange = function(pageOperation) {
				resetChildTables();
				if ($scope.dataPageMap != '' && $scope.dataPageMap != undefined) {
					if (pageOperation == 'First') {
						if ($scope.pageNumber != 1) {
							$scope.pageNumber = 1;
						} else {
							return;
						}
					} else if (pageOperation == 'Previous') {
						if ($scope.pageNumber != 1) {
							$scope.pageNumber = $scope.pageNumber - 1;
						} else {
							return;
						}
					} else if (pageOperation == 'Next') {
						if ($scope.tablePagination.noOfPages >= ($scope.pageNumber + 1)) {
							$scope.pageNumber = $scope.pageNumber + 1;
						} else {
							return;
						}
					} else if (pageOperation == 'Last') {
						var totalNoOfPgs = 0;
						if($scope.serversorting == 'No'){
							totalNoOfPgs = $scope.tablePagination.noOfPages;
						}else{
							totalNoOfPgs =  $scope.masterTotalNoPages;
						}
								
						if ($scope.pageNumber != totalNoOfPgs) {
							$scope.pageNumber = totalNoOfPgs;
						} else {
							return;
						}
					}
					
					if(!$scope.clientCaching){
						$scope.dataPageMap = new Object();
					}
					
					if ($scope.serversorting == 'No') {
						$scope.data = $scope.dataPageMap[$scope.pageNumber];
					} else {
						if ($scope.dataPageMap[$scope.pageNumber] == null
								|| $scope.dataPageMap[$scope.pageNumber] == undefined) {
							$scope[$scope.paginationObjName].pageIndex = $scope.pageNumber - 1;
							$scope[$scope.fetchDataFnName]($scope[$scope.paginationObjName], $scope.filterJson, 'pageChange');
						} else {
							$scope.data = $scope.dataPageMap[$scope.pageNumber];
						}
					}
				}
			}

			
			$scope.sortByColumn = function(colToBeSorted, isSortable,sortableKey,isInitSortCall,isInnerTable) {
				if(isInnerTable==false || isInnerTable== undefined)
				resetChildTables();
				if (isSortable == 'yes' && $scope.dataPageMap != ''
						&& $scope.dataPageMap != undefined) {
					var colSorted = $scope.sortConfig.sortedColumn;
					var sortingOrder = $scope.sortConfig.sortingOrder;

					if (colToBeSorted == colSorted) {
						if (sortingOrder == "desc") {
							sortingOrder = "asc";
						} else {
							sortingOrder = "desc";
						}
					} else {
						sortingOrder = "desc";
					}
					
					if(isInitSortCall){
						sortingOrder = $scope.sortConfig.sortingOrder
					}
					
					$scope.sortConfig = {
						"sortedColumn" : colToBeSorted,
						"sortingOrder" : sortingOrder
					};

					if ($scope.serversorting == 'No') {
						if (sortableKey != undefined && sortableKey != null) {
							colToBeSorted = sortableKey;
						}
						var tempData={};
						if(isInnerTable==undefined || isInnerTable==false){
						tempData = $scope.sortJsonArrayByProp(
								$scope.searchedData, colToBeSorted,
								$scope.sortConfig.sortingOrder);
						$scope.dataPageMap = $scope
						.constructTabelData(tempData);
				$scope.data = $scope.dataPageMap[1];
				$scope.pageNumber = 1;
						}
						if(isInnerTable==true){
							//fetch innerchild1TableId
							var innerChildTabId=$scope.data[$scope.innerChild1TableId-1].innerTable.innerChild1TableId;
						 tempData = $scope.sortInnerJsonArrayByProp(
								$scope.data[innerChildTabId-1].innerTable, colToBeSorted,
								$scope.sortConfig.sortingOrder);
						 $scope.dataPageMap = $scope
							.constructTabelData(tempData);
					$scope.innerTabledata = $scope.dataPageMap[1];
					$scope.pageNumber = 1;
					$scope.data[innerChildTabId-1].innerTable.data=$scope.innerTabledata;
						}
						
						/*$scope.dataPageMap = $scope
								.constructTabelData(tempData);
						$scope.data = $scope.dataPageMap[1];
						$scope.pageNumber = 1;*/
					} else {
						$scope[$scope.paginationObjName].sortedOrder = $scope.sortConfig.sortingOrder;
						var tempColumnToBeSorted = $scope.sortConfig.sortedColumn;
						if (sortableKey != undefined && sortableKey != null) {
							tempColumnToBeSorted = sortableKey;
						}
						$scope.dataPageMap = '';
						$scope.pageNumber = 1;
						$scope[$scope.paginationObjName].pageIndex = "0";
						$scope[$scope.paginationObjName].sortedColumn = tempColumnToBeSorted;
						$scope[$scope.fetchDataFnName]($scope[$scope.paginationObjName], $scope.filterJson, 'sort');
					}
				}
			}
			
			$scope.sortJsonArrayByProp = function(objArray, prop, order) {
				var contentType = '';
					for(var i = 0; i < $scope.tableheaders.length; i++){
						if($scope.tableheaders[i].key === $scope.sortConfig.sortedColumn){
							contentType = $scope.tableheaders[i].contentType;
							break;
						}
					}
				if(contentType === 'String'){
					if (order == 'desc'){
						objArray = $filter('orderBy')(objArray,'-'+prop);
					}
					else{
						objArray = $filter('orderBy')(objArray,prop);
					}
				}
				else if(contentType === 'html'){
					if (order == 'desc'){
						objArray = $filter('orderBy')(objArray,'-'+prop);
					}
					else{
						objArray = $filter('orderBy')(objArray,prop);
					}
				}
				else if(contentType === 'Number' || contentType === 'Currency'){
					if (order == 'desc'){
						objArray = $filter('orderBy')(objArray,'-'+prop+'*1');
					}
					else{
						objArray = $filter('orderBy')(objArray,prop+'*1');
					}
				}
				else if(contentType === 'Date'){
					objArray.sort(function(obj1, obj2) {
						if (order == 'desc') {
							return compare(obj1[prop], obj2[prop]);
						} else {
							return compare(obj2[prop], obj1[prop]);
						}
					});
				}
				else if(contentType === 'Period'){
					objArray.sort(function(obj1, obj2) {
						if (order == 'desc') {
							return comparePeriods(obj1[prop], obj2[prop]);
						} else {
							return comparePeriods(obj2[prop], obj1[prop]);
						}
					});
				}
				
				return objArray;
			}
			
			$scope.sortInnerJsonArrayByProp = function(objArray, prop, order) {
				var contentType = '';
				  var objInnerArray=objArray.data;      
					for(var i = 0; i < objArray.headers.length; i++){
						if(objArray.headers[i].key === $scope.sortConfig.sortedColumn){
							contentType = objArray.headers[i].contentType;
							break;
						}
					}
				if(contentType === 'String'){
					if (order == 'desc'){
						objInnerArray = $filter('orderBy')(objInnerArray,'-'+prop);
					}
					else{
						objInnerArray= $filter('orderBy')(objInnerArray,prop);
					}
				}
				else if(contentType === 'html'){
					if (order == 'desc'){
						objInnerArray = $filter('orderBy')(objInnerArray,'-'+prop);
					}
					else{
						objInnerArray = $filter('orderBy')(objInnerArray,prop);
					}
				}
				else if(contentType === 'Number' || contentType === 'Currency'){
					if (order == 'desc'){
						objInnerArray = $filter('orderBy')(objInnerArray,'-'+prop+'*1');
					}
					else{
						objInnerArray = $filter('orderBy')(objInnerArray,prop+'*1');
					}
				}
				else if(contentType === 'Date'){
					objInnerArray.sort(function(obj1, obj2) {
						if (order == 'desc') {
							return compare(obj1[prop], obj2[prop]);
						} else {
							return compare(obj2[prop], obj1[prop]);
						}
					});
				}
				else if(contentType === 'Period'){
					objInnerArray.sort(function(obj1, obj2) {
						if (order == 'desc') {
							return comparePeriods(obj1[prop], obj2[prop]);
						} else {
							return comparePeriods(obj2[prop], obj1[prop]);
						}
					});
				}
				
				return objInnerArray;
			}
			
			function comparePeriods(period1, period2){
				var splittedPeriod1 = period1.split('-');
				var splittedPeriod2 = period2.split('-');
				var period1Begins = new Date(splittedPeriod1[0]);
				var period1Ends = new Date(splittedPeriod1[1]);
				var period2Begins = new Date(splittedPeriod2[0]);
				var period2Ends = new Date(splittedPeriod2[1]);
				//if period2 > period 1 -- return 1 => sort by begins on and than ends on. If both period invalid, return 0
				// Invalid period is shorter.
				// period1 > period 2 -- return -1
				// period 1 = period 2 -- return 0
				if((period1Begins == 'Invalid Date' || period1Ends == 'Invalid Date')  && (period2Begins == 'Invalid Date' || period2Ends == 'Invalid Date')){
					return 0;
				}
				else if((period1Begins == 'Invalid Date' || period1Ends == 'Invalid Date') || (period2Begins > period1Begins) || ((period2Begins === period1Begins) && (period2Ends > period1Ends))){
					return 1;
				}
				else if((period2Begins == 'Invalid Date' || period2Ends == 'Invalid Date') || (period1Begins > period2Begins) || ((period1Begins === period2Begins) && (period1Ends > period2Ends))){
					return -1;
				}
				else{
					return 0;
				}
			}
			

			function compare(var1, var2) {
				var date1 = new Date(var1);
				var date2 = new Date(var2);
				if(date1 == 'Invalid Date' && date2 == 'Invalid Date')
					return 0;
				return (date1 < date2 || date1 == 'Invalid Date')? 1 // if b should come earlier, push a to end
				: (date1 > date2 || date2 == 'Invalid Date')? -1 // if b should come later, push a to begin
				: 0;
			}

			$scope.constructTabelData = function(data) {
				var _dataPageMap = new Object();
				var _page = 1;

				if ($scope.enablePagination == 'No') {
					_dataPageMap[1] = data;
					$scope.tablePagination.noOfPages = 1;
					return _dataPageMap;
				}

				if ($scope.serversorting == 'Yes') {
					if ($scope.dataPageMap == null
							|| $scope.dataPageMap == undefined || $scope.dataPageMap == "") {
						_dataPageMap = new Object();
						_page = 1;
					} else {
						_dataPageMap = $scope.dataPageMap;
						_page = $scope.pageNumber;
					}
					
					$scope.tablePagination.noOfPages = $scope.masterTotalNoPages;
					
				} else {
					_dataPageMap = new Object();
					_page = 1;
					var totalNoPages = Math.ceil(data.length/$scope.tablePagination.pageSize);
					$scope.tablePagination.noOfPages = totalNoPages;
					$scope.tablePagination.totalElements = data.length;
				}
				var dataPerPage = [];
				var count = 0;
				

				angular.forEach(data, function(value, key) {
					if(value != undefined){
						if (count == $scope.tablePagination.pageSize) {
							count = 0;
							if (_page != 0) {
								_dataPageMap[_page] = dataPerPage;
							}
							_page = _page + 1;
							dataPerPage = [];
						}
						count = count + 1;
						dataPerPage.push(value);
					}
				});

				if (dataPerPage != []) {
					_dataPageMap[_page] = dataPerPage;
				}

				return _dataPageMap;
			}
			
			$scope.updatePageBackFilter = function(filterKey,filterValue,filterType){
				var pageBackBackFilter = {};
				pageBackBackFilter.filterKey = filterKey;
				pageBackBackFilter.filterValue = filterValue;
				pageBackBackFilter.filterType = filterType;
				$scope.$parent.pageBackFilters.push(pageBackBackFilter);
			}

			$scope.search = function() {
			
				if ($scope.dataPageMap != '' && $scope.dataPageMap != undefined
						&& $scope.serversorting == 'No') {
					
					var arr = $scope.masterData;
					for ( var i = 0; i < $scope.filters.length; i++) {

						var filterValue = $scope[($scope.filters[i].filterKey + 'Filter')];
						var filterKey = $scope.filters[i].filterKey;
						var filterType = $scope.filters[i].filterType;
						var filterFromValue = $scope[($scope.filters[i].filterKey + 'FromFilter')];
						var filterToValue = $scope[($scope.filters[i].filterKey + 'ToFilter')];
						var isArrayObject=angular.isArray(filterValue);
						if(filterType == 'SelectBox'  && isArrayObject){
								if(filterValue.length>0){
									arr = searchByMultipleSelectFilter(arr, filterKey, filterValue);	
								}
								
						}else{
							if (((filterValue != undefined && filterValue !== '' && filterType !='NumberRange' && filterType !='DateRange' )
									&& ( (filterType != 'SelectBox') || (filterValue.toLowerCase() != 'select'	
									&& filterValue.toLowerCase() != 'all' && filterType == 'SelectBox'))) || ((filterType =='NumberRange' || filterType =='DateRange') && (filterFromValue != undefined && filterFromValue !== '' && filterToValue != undefined && filterToValue !== ''))) {
									arr = searchByFilter(arr, filterKey, filterValue,
											filterType,filterFromValue,filterToValue)
								}
						} 
					}
					$scope.tablePagination.totalElements = arr.length
					$scope.searchedData = arr;
					$scope.dataPageMap = $scope.constructTabelData(arr);
					$scope.data = $scope.dataPageMap[1];
					$scope.pageNumber = 1;
					$scope.generateFooter();
				} else {
					//alert("hi1");
					$scope.$parent.pageBackFilters = [];
					var filtersJson = [];
					for ( var i = 0; i < $scope.filters.length; i++) {

						var filterValue = $scope[($scope.filters[i].filterKey + 'Filter')];
						var filterKey = $scope.filters[i].filterKey;
						var filterType = $scope.filters[i].filterType;
						$scope.updatePageBackFilter(filterKey,filterValue,filterType);
						
						//added queryKey for the case when we need to access nested field in search Criteria ex: profile.name (by uttam)
						var queryKey=$scope.filters[i].filterQueryKey;

						if (filterKey != undefined && filterValue != undefined
								&& filterValue != ''
								&& filterValue.toLowerCase() != 'select'
								&& filterValue.toLowerCase() != 'all') {
							var jsonObject = {};
							if(queryKey != undefined){
								jsonObject[queryKey] = filterValue;
							}else{
								jsonObject[filterKey] = filterValue;
							}
							filtersJson.push(jsonObject);
						}
					}
					$scope.filterJson = filtersJson;
					$scope.dataPageMap = null;
					$scope.pageNumber = 1;
					$scope[$scope.paginationObjName].pageIndex = $scope.pageNumber -1;
					$scope[$scope.fetchDataFnName]($scope.pagination, $scope.filterJson, 'search');
					var arr = $scope.masterData;
					$scope.dataPageMap = $scope.constructTabelData(arr);
				}

			}

			function searchByFilter(arr, filterName, filterValue, filterType,filterFromValue,filterToValue) {
				var searchedElements = [];
				
				if(filterFromValue !=undefined && filterFromValue !== '' && filterFromValue != null && filterToValue !=undefined && filterToValue !== '' && filterToValue != null){
				
					if(!isNaN(filterFromValue) && !isNaN(filterToValue) && filterType == 'NumberRange'){
						for ( var i = 0; i < arr.length; i++) {
							if(arr[i]!= undefined){
							var value = arr[i][filterName];
							if(value != undefined && value != null){
								if(parseFloat(value) >= parseFloat(filterFromValue) && parseFloat(value) <= parseFloat(filterToValue)){
									searchedElements.push(arr[i]);
								}else{
									value = 0;
								}
						}
						}
					  }
					  return searchedElements;
					  }else if(filterType == 'DateRange'){
						var fromDate = (filterFromValue.valueOf());
						var toDate = (filterToValue.valueOf());
						if(fromDate != 'Invalid Date' && toDate != 'Invalid Date'){
							for ( var i = 0; i < arr.length; i++) {
								if(arr[i]!= undefined){
										var value = convertToUTCMillis(arr[i][filterName],'S');
										if(value != undefined && value != null){
											if(value >= fromDate && value <= toDate){
												searchedElements.push(arr[i]);
											}else{
												value = 0;
											}
										}
								}
							}
					  return searchedElements;
					}
				}
				}
				
				
				if (filterValue !== '' && filterValue != undefined
						&& filterValue != null && filterType != null
						&& filterType != undefined && filterType != 'NumberRange') {
					for ( var i = 0; i < arr.length; i++) {
						var value = '';
						if (filterType == 'SelectBox'
								|| filterType == 'TextBox') {
							if(arr[i] != undefined && arr[i][filterName] != undefined && arr[i][filterName] != null){
								value = (arr[i][filterName]).toLowerCase();
							}else{
								value ="";
							}
						}
						var filterValue = ((filterValue)).toLowerCase();
						if ((filterType == 'TextBox')
								&& value.indexOf(filterValue) > -1) {
							searchedElements.push(arr[i]);
						}

						else if ((filterType == 'SelectBox')
								&& value == filterValue) {
							searchedElements.push(arr[i]);
						} else if (filterType == 'FreeTextBox') {
							var isObjectHasSearchFilter = false;
							
							var filterWithHTMLContentMap = new Object();
							angular.forEach($scope.tableheaders, function(headerValue, headerKey) {
								var headerValue = headerValue;
								var headerKey = headerKey;
								if(headerValue.contentType == 'html'){
									filterWithHTMLContentMap[headerValue.key] = true;
								}
							});
							
							
							
							angular.forEach(arr[i], function(objValue, ObjKey) {
								value = (objValue).toLowerCase();
								if ((value.indexOf(filterValue) > -1) && filterWithHTMLContentMap[ObjKey] != true) {
									isObjectHasSearchFilter = true;
									//break;
								}
							});

							if (isObjectHasSearchFilter) {
								searchedElements.push(arr[i]);
							}
						}
					}
					return searchedElements;
				} else {
					return arr;
				}
			}
			
			function searchByMultipleSelectFilter(arr, filterName, filterValue) {
				var searchedElements = [];
				var filterText='';
				if(filterName!=undefined && filterName!=='' && filterValue!= undefined && filterValue!==''){
					
					for ( var i = 0; i < arr.length; i++) {
						var value = '';
						var name='';
						if(arr[i][filterName]){
							name=arr[i][filterName];
						}
						value = (name).toLowerCase();
						
						for(var j=0; j < filterValue.length; j++){
							if(value === filterValue[j].toLowerCase()){
								searchedElements.push(arr[i]);
								break;
							}
						} 
					}
					return  searchedElements;
				}else {
					return arr;
				}
			}
			
			$scope.$on('exportEvent', function (event, payload) {
				$scope.exportData(payload.fileName,payload.fileFormat,payload.data);
			});	
			
			$scope.exportData = function(fileName, fileFormat,exportData)
			{ 
				if($scope.isTableRenderable){
					var format = 'csv';
					if(fileFormat != null && fileFormat != undefined && fileFormat != '') {
						format = fileFormat;
					}
					// Check for csv or xls file format. Only these 2 formats are supported.
					if(format != 'csv' && format != 'xls') {
						return;
					}
					
					var ShowLabel = true;
					
					var CSV = '';    
					var headers = $scope.tableheaders;
					var moreExportHeaders=$scope.moreTableheaders;
					if(moreExportHeaders){
						headerLength=headers.length;
						for(var i = 0; i<moreExportHeaders.length ; i++)
						{
							headers[headerLength+i]=moreExportHeaders[i];
						}
						
					}
					var row = "";
					//This condition will generate the Label/Header
					for(var i = 0; i<headers.length ; i++)
					{
						var colName = headers[i].desc;
						//Now convert each value to string and comma-seprated
						if(headers[i].contentType != 'html' ||  (headers[i].contentType == 'html' && headers[i].isExportable))
						row += colName + ',';
					}
					row = row.slice(0, -1);
					
					//append Label row with line break
					CSV += row + '\r\n';
					var JSONData ='';
					if($scope.serversorting == 'No'){
						if($scope.searchedData!=undefined && $scope.searchedData!=''){
							JSONData=$scope.searchedData;
						}else{
							JSONData = $scope.masterData;
						}
						
					}else{
						JSONData = $scope.data;
					}
					
					if(exportData){
						JSONData = exportData;	
					}
					
				    var arrData = '';
				    if(JSONData == '' || JSONData == undefined || JSONData.length==0)
				    	arrData = {};
				    else
				    	arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
				    
				    for(var i = 0; i < arrData.length; i++){
				    	var json = arrData[i];
				    	var row = "";
				    	for(var j = 0; j<headers.length ; j++)
				    		{
				    			var cellValue = json[headers[j].key];
				    			if(headers[j].contentType=='Date') {
				    				if(cellValue != null && cellValue != '' && cellValue != undefined && cellValue != '--')
				    					cellValue = $filter('date')(new Date(cellValue),$scope.clientDateFormat);
				    				else
				    					cellValue = '--';
				    			} else if(headers[j].contentType=='Currency') {
				    				if(cellValue != null && cellValue != '' && cellValue != undefined && cellValue != '--')
				    					cellValue = $filter('customCurrency')(cellValue);
				    				else
				    					cellValue = '--';
				    			} else if(headers[j].contentType=='html'){
				    				if(headers[j].isExportable){
				    					cellValue = json[headers[j].key +'_exportValue'];
				    				}else{
				    					cellValue = '';
					    				continue;	
				    				}
				    			}
				    			 row += '"' +cellValue + '",';
				    		}
				    	
				    	row.slice(0, row.length - 1);
				        
				        //add a line break after each row
				        CSV += row + '\r\n';
				    }
				    
				    //Footer
				    var tableFooter = $scope.tableFooter;
				    var moreExportFooters=$scope.moreTableFooters;
					
				    
				    if(tableFooter){
				    	
				    	if(moreExportFooters){
							footerLength=tableFooter.length;
							for(var i = 0; i<moreExportFooters.length ; i++)
							{
								tableFooter[footerLength+i]=moreExportFooters[i];
							}
							$scope.tableFooter=tableFooter;
							
						}
				    	
				    	var row = "";	
				    	angular.forEach($scope.tableFooter, function(value, key) {
				    		var cellValue ='';
				    		var colSpan = value.colSpan;

				    		if(value.contentType == 'Currency'){
								cellValue = $filter('customCurrency')(value.calculatedValue);
							}else if(value.contentType == 'Number'){
								cellValue = value.calculatedValue;
							}else if(value.desc != ''){
								cellValue = value.desc;
							}
				    		
							if(colSpan && colSpan > 1){
								for(var i=0;i<(colSpan-1);i++){
									row += ',';
								}
							}
							
							row += '"' +cellValue + '",';
						});
				    	
						row.slice(0, row.length - 1);
				        
						//add a line break after each row
						CSV += row + '\r\n';
				    }
				    

				    //1st loop is to extract each row
				   /* for (var i = 0; i < arrData.length; i++) {
				        var row = "";
				        
				        //2nd loop will extract each column and convert it in string comma-seprated
				        for (var index in arrData[i]) {
				            row += '"' + arrData[i][index] + '",';
				        }
	
				        row.slice(0, row.length - 1);
				        
				        //add a line break after each row
				        CSV += row + '\r\n';
				    }*/
	
				    if (CSV == '') {        
				        alert("Invalid data");
				        return;
				    }   
				    
					if (navigator.msSaveBlob) { // IE10
				        return navigator.msSaveBlob(new Blob([CSV], {type: "data:text/xls"}), fileName + "." + format);
				    } else {
				    	//Initialize file format you want csv or xls
					    var uri = 'data:text/xls;charset=utf-8,' + escape(CSV);
						
						// Now the little tricky part.
						// you can use either>> window.open(uri);
						// but this will not work in some browsers
						// or you will not get the correct file extension    
						
						//this trick will generate a temp <a /> tag
						var link = document.createElement("a");    
						link.href = uri;
						
						//set the visibility hidden so it will not effect on your web-layout
						link.style = "visibility:hidden";
						link.download = fileName + "." + format;
						
						//this part will append the anchor tag and remove it after automatic click
						document.body.appendChild(link);
						link.click();
						document.body.removeChild(link);
				    }
				}
			}

			$scope.generateFooter = function(){
				if($scope.tableFooter != '' && $scope.tableFooter != undefined){
					angular.forEach($scope.tableFooter, function(value, key) {
						if(value.contentType == 'Number' || value.contentType == 'Currency'){
							value.calculatedValue = $scope.calculate(value.calculationType,value.key);
						}
					});
				}
			}

			
			$scope.calculate = function(calculationType,columnName){
				if(calculationType != undefined && columnName != undefined ){
					var masterData = '';
						if($scope.searchedData!==undefined && $scope.searchedData !==''){
							masterData=$scope.searchedData;
						}else{
							masterData=$scope.masterData;
						}
					var sum = 0;
					
					if(calculationType == 'TotalRecords'){
						return $scope.tablePagination.totalElements;
					}else if(calculationType == 'Sum' || calculationType == 'Avg' ){
						angular.forEach(masterData, function(value, key) {
						if(value[columnName] != undefined && value[columnName] != '' && !isNaN(value[columnName])){
							sum = sum + parseFloat(value[columnName]);
							}
						});
						if(calculationType == 'Sum'){
							return sum;
						}else if(calculationType == 'Avg'){
							var totalElements  = $scope.tablePagination.totalElements;
							if(totalElements != undefined && totalElements != 0){
								return (sum/totalElements);
							}else{
								return 0;
							}
						}
					}
				 }
				return 0;
				}
			
			$scope.updateDrillDownFilter = function(filterObj,filterValue){
				
				var filterKey = filterObj.key;
				if(filterObj.translate){
					filterValue = $translate.instant(filterValue);
				}

				var defaultFiltersConfig = $scope.$parent.filterBoxConfig.defaultFiltersConfig;
				var moreFiltersConfig = $scope.$parent.filterBoxConfig.moreFiltersConfig;
				
				angular.forEach($scope.filters, function(filterObj,key) {
					
					if(filterObj.filterKey == filterKey && filterObj.filterType == 'DateRange'){
						//console.log(filterValue);
						if(filterValue && filterValue != ''){
							var fromDate = filterValue.split("-")[0];
							var toDate = filterValue.split("-")[1];
							filterValue = {"from" : fromDate,"to": toDate};
						}
					}
					
					if(filterObj.filterKey == filterKey && (filterObj.filterType == 'StringList' || filterObj.filterType == 'EnumList')){
						$scope.$parent[$scope.watchablefilterobjname] =  $scope.$parent[$scope.watchablefilterobjname] || {};
						
						var selectedEnumValue;
						
						if(defaultFiltersConfig){
							angular.forEach(defaultFiltersConfig, function(defaultFilterObj,defaultFilterKey) {
								if(defaultFilterObj.name === filterKey){
									var filterConfig = defaultFilterObj.config;
									angular.forEach(filterConfig, function(filterConfigValue,filterConfigKey) {
										if(filterConfigValue === filterValue){
											selectedEnumValue  = filterConfigKey;
										}
									});
								}
							});
						}
						
						if(!selectedEnumValue){
							if(moreFiltersConfig){
								angular.forEach(moreFiltersConfig, function(moreFiltersConfigObj,moreFiltersConfigKey) {
									if(moreFiltersConfigObj.name === filterKey){
										var filterConfig = moreFiltersConfigObj.config;
										angular.forEach(filterConfig, function(filterConfigValue,filterConfigKey) {
											if(filterConfigValue === filterValue){
												selectedEnumValue  = filterConfigKey;
											}
										});
									}
								});
							}
						}
						
						if(selectedEnumValue){
							var array = [];
							array.push(selectedEnumValue);
							filterValue =  array;
							 $timeout(function() {
									publishCheckBoxFilterEvent(filterKey,selectedEnumValue);
						        }, 250);
							}
						}
					
				});
				
				isMoreFilterType(filterKey,filterValue,moreFiltersConfig);

				$scope.$parent[$scope.watchablefilterobjname] =  $scope.$parent[$scope.watchablefilterobjname] || {};
				$scope.$parent[$scope.watchablefilterobjname][filterKey] = filterValue;
				$scope.$parent['filterData'][filterKey] = filterValue;
				
				if($scope.$parent[$scope.watchablefilterobjname]['isSearchCall'] != undefined){
					$scope.$parent[$scope.watchablefilterobjname]['isSearchCall'] = true;
				}
			}
			
			var publishCheckBoxFilterEvent = function(filterName,filterValue){
				var payload = {};
				payload.filterName = filterName;
				payload.filterValue = filterValue;
				$rootScope.$broadcast('checkBoxFilterEvent', payload);
			}
			
			var isMoreFilterType = function(filterKey,filterValue,moreFiltersConfig){
				if(moreFiltersConfig){
					angular.forEach(moreFiltersConfig, function(moreFiltersConfigObj,moreFiltersConfigKey) {
						if(moreFiltersConfigObj.name === filterKey){

							var payload = {};
							payload.filterName = moreFiltersConfigObj.name;
							payload.filterValue = filterValue;
							$rootScope.$broadcast('moreFilterEvent', payload);
							
						}
					});
				}
			} 
			

			$scope.createDefaultTable = function(masterData, filters,
					serversorting, tableheaders, noOfPages, enablePagination,tableFooter,
					isWatchCall) {
				if (masterData != null || masterData != undefined) {
					if (masterData == 'No Data') {
						$scope.masterData = 'No Data';
						$scope.data = '';
						$scope.dataPageMap ='';
						$scope.tablePagination.totalElements = 0;
					} else {
						
						$scope.serversorting = serversorting;
						$scope.filters = filters;
						$scope.tableheaders = tableheaders;
						$scope.enablePagination = enablePagination;
						
						$scope.masterData = masterData;
						$scope.searchedData = masterData;  // Default setting to master Data
						$scope.dataPageMap = $scope
								.constructTabelData($scope.masterData);
								
						if ($scope.serversorting == 'Yes') {
							if (noOfPages != 0 && noOfPages!= undefined) {
								$scope.masterTotalNoPages = noOfPages;
								
							}
							$scope.data = $scope.dataPageMap[$scope.pageNumber];
						} else {
							$scope.search(); // Apply Client side filters if any 
							$scope.data = $scope.dataPageMap[1];
						}
					
						$scope.tableFooter = tableFooter;
						$scope.generateFooter();
					}
				}
			}

			$scope.updatePagination = function(pagination) {
				if (pagination != undefined && pagination != '') {
					if (pagination.totalNoPages != ''
							&& pagination.totalNoPages != undefined) {
						$scope.masterTotalNoPages = parseInt(pagination.totalNoPages);
						$scope.tablePagination.noOfPages = $scope.masterTotalNoPages;
					}
					if (pagination.totalElements != ''
							&& pagination.totalElements != undefined) {
						var totalNoOfElemets = parseInt(pagination.totalElements);
						$scope.tablePagination.totalElements = totalNoOfElemets;
						//$scope.masterTotalElements = totalNoOfElemets;
					}
				}
				
				if($scope.dataPageMap != undefined && ($scope.dataPageMap[$scope.pageNumber] == null
				|| $scope.dataPageMap[$scope.pageNumber] == undefined)){
					$scope.createDefaultTable($scope.masterData, $scope.filters,
						$scope.serversorting, $scope.tableheaders,
						$scope.masterTotalNoPages, $scope.enablePagination,$scope.tableFooter, false);
				}	
			}

			$scope.onLoadFetchData = function() {
				$scope[$scope.fetchDataFnName]($scope.pagination, $scope.filterJson);
			}
			
			$scope.setDefaultSort =function(){
				if ($scope.$parent && $scope.$parent[$scope.paginationObjName] && $scope.$parent[$scope.paginationObjName] && $scope.$parent[$scope.paginationObjName].sortedColumn) {
					var defaultSortedColumn = getHeaderColumnKey($scope.$parent[$scope.paginationObjName].sortedColumn);
					if (defaultSortedColumn != '') {
						$scope.sortConfig.sortedColumn = defaultSortedColumn;
						if ($scope.$parent[$scope.paginationObjName].sortedOrder == ''
								|| $scope.$parent[$scope.paginationObjName].sortedOrder == undefined) {
							$scope.sortConfig.sortingOrder = 'asc';
						} else {
							$scope.sortConfig.sortingOrder = $scope.$parent[$scope.paginationObjName].sortedOrder;
						}
						if($scope.serversorting == 'No'){
							$scope.sortByColumn($scope.sortConfig.sortedColumn,'yes',$scope.sortConfig.sortingOrder,true);						
						}
					}
				}
			}
			

			var getHeaderColumnKey = function(_columnKey) {
				var headerKey = "";
				if (_columnKey != '' && _columnKey != undefined && $scope.tableheaders && $scope.tableheaders != '') {
					angular.forEach($scope.tableheaders, function(headerObj,
							key) {
						if (headerObj.key == _columnKey	|| headerObj.sortableKey == _columnKey) {
							headerKey =  headerObj.key;
						}
					});
				}
				return headerKey;
			}

			$scope.innerChild1TableId = [];
			$scope.expandAll=true;
			$scope.toggle = function(index) {
				/*if(value=='ExpandAll'){
					$scope.innerChild1TableId[index] =true;
				}
				else if(value=='CollapseAll'){
					$scope.innerChild1TableId[index]=false;
				}*/
				
				$scope.innerChild1TableId[index] = !$scope.innerChild1TableId[index];
				
				};
				
				$scope.expandAllCollapseAll=function(){
					for(var i=1;i <=$scope.innerTableId;i++){
						$scope.innerChild1TableId[i] = $scope.expandAll;
					}
					/*$scope.innerChild1TableId.forEach(function(value){
						
						
					});*/
					
					$scope.expandAll = !$scope.expandAll;
					if($scope.expandAll){
						$scope.expandCollapse='Expand All';
					}else
						{
						$scope.expandCollapse='Collapse All';
						}
					
					
				}

			var resetChildTables = function() {
				$scope.innerChild1TableId = [];
			}
			
			$scope.updateTableWithFilters = function(filterObj){
				//console.log('filterObj :: ' +JSON.stringify(filterObj));
				criteria = buildCriteria($scope.filters, filterObj, $filter);
				$scope.filterJson = criteria;
				$scope.dataPageMap = null;
				$scope.pageNumber = 1;
				$scope[$scope.paginationObjName].pageIndex = $scope.pageNumber -1;
				$scope[$scope.fetchDataFnName]($scope.pagination, $scope.filterJson, 'search');
				var arr = $scope.masterData;
				$scope.dataPageMap = $scope.constructTabelData(arr);
			}

			$scope.populateSelectedFilters = function(selectedFilters){
				angular.forEach(selectedFilters, function(selectedFilter,selectedFilterKey) {
					var filterKey = selectedFilter.filterKey+'Filter';
					var filterValue = selectedFilter.filterValue;
					$scope[filterKey] = filterValue;
				});
				$scope.search();
			}
			
			$scope.checkDrillDownFilterEnabled = function(){
				if($scope.tableheaders){
					angular.forEach($scope.tableheaders, function(value, key) {
						if(value.isDrillDownFilter){
							if(!$scope.isDrillDownFilterEnabled){
								$scope.isDrillDownFilterEnabled = true;
							}
						}
					});
				}
			}
			
			$scope.clientCachingFn = function(isClientCaching){
				if(isClientCaching != undefined){
					$scope.clientCaching = isClientCaching;
				}
			}
			
		} ];

hcentive.WFM.CustomHeadersDir = [ function() {
	return {
		restrict : 'A',
		templateUrl : function($scope, elem, attr) {
			var customURL = $scope.customtableheaders;
			// alert(customURL);
			if (customURL == undefined || customURL == 0) {
				return "../common/widgets/table/defaultTableHeaders.html";
			}
			return customURL;
		}
	};
} ];


hcentive.WFM.CustomInnerHeadersDir = [ function() {
	return {
		restrict : 'A',
		templateUrl : function($scope, elem, attr) {
			var customURL = $scope.customtableinnerheaders;
			// alert(customURL);
			if (customURL == undefined || customURL == 0) {
				return "../common/widgets/table/defaultTableInnerHeaders.html";
			}
			return customURL;
		}
	};
} ];


hcentive.WFM.CustomFooterDir = [ function() {
	return {
		restrict : 'A',
		replace :true,
		templateUrl : function($scope, elem, attr) {
			var customURL = $scope.customtablefooter;
			// alert(customURL);
			if (customURL == undefined || customURL == 0) {
				return "../common/widgets/table/defaultTableFooter.html";
			}
			return customURL;
		}
	};
} ];


hcentive.WFM.CustomNestedTableDir = [ function() {
	return {
		restrict : 'AE',
		replace :true,
		link : function(scope, element, attr) {
		if(attr != undefined){
			scope.innerTableHeaders = angular.fromJson(attr.innertableheaders);
			scope.innerTableData = angular.fromJson(attr.innertabledata);
			}
		},
		templateUrl : function($scope, elem, attr) {
			var customURL = $scope.customnestedtable;
			// alert(customURL);
			if (customURL == undefined || customURL == 0) {
				return "../common/widgets/table/defaultNestedTable.html";
			}
			return customURL;
		}
	};
} ];



hcentive.WFM.CustomPaginationDir = [ function() {
	return {
		restrict : 'A',
		replace :true,
		templateUrl : function($scope, elem, attr) {
			var customURL = $scope.customtablepagination;
			// alert(customURL);
			if (customURL == undefined || customURL == 0) {
				return "../common/widgets/table/defaultTablePagination.html";
			}
			return customURL;
		}
	};
} ];

hcentive.WFM.CustomTableDir = [ function() {
	return {
		restrict : 'AE',
		link : function(scope, element, attrs) {

			var watchAbleObjName = attrs.watchableobjname;
			
			var selectedFilters = scope[attrs.selectedfilterobjname];
			if(selectedFilters){
				scope.selectedFilterObjName = attrs.selectedfilterobjname;
			}
			
			var watchAbleFilterObjName = attrs.watchablefilterobjname;
			scope.watchablefilterobjname = attrs.watchablefilterobjname;
			
			if(attrs.fetchdatafnname){
				scope.fetchDataFnName = attrs.fetchdatafnname;
			}
			
			if(attrs.widgetKey){
				scope.isTableRenderable = scope.isRenderable(attrs.widgetKey);
			}

			if(attrs.paginationobjname){
				scope.paginationObjName = attrs.paginationobjname;
			}else{
				scope.paginationObjName = 'pagination';
			}

			if (attrs.enablepagination != ''
					&& attrs.enablepagination != undefined) {
				scope.enablePagination = attrs.enablepagination;
			}
			if(attrs.showtableheaders == 'false')
			{
				scope.showTableHeaders = 'false';
			}
			else
			{
				scope.showTableHeaders = 'true';
			}
			
			if(attrs.renderdata == 'loading')
			{
				scope.renderData = 'loading';
			}
			else if(attrs.renderdata == 'nodata')
			{
				scope.renderData = '';
			}
			else
			{
				scope.renderData = 'blank';
			}

			if (attrs.serversorting != '' && attrs.serversorting != undefined) {
				scope.serversorting = attrs.serversorting;
			}
			if (attrs.paginationcolspan != ''
					&& attrs.paginationcolspan != undefined) {
				scope.paginationColSpan = attrs.paginationcolspan;
			}

			if (attrs.tabledata != undefined && attrs.tabledata != '' && attrs.tabledata != 'No Data') {   
				scope.masterData = eval("(" + attrs.tabledata + ")");
			}

			if (attrs.headers != '' && attrs.headers != undefined) {
				scope.tableheaders = eval("(" + attrs.headers + ")");
			}
			
			scope.checkDrillDownFilterEnabled();

			if (attrs.filters != '' && attrs.filters != undefined) {
				scope.filters = eval("(" + attrs.filters + ")");
			}

			if (attrs.noofpages != '' && attrs.noofpages != undefined) {
				scope.noOfPages = parseInt(attrs.noofpages);
			}

			if (attrs.headertemplateurl != ''
					&& attrs.headertemplateurl != undefined) {
				scope.headerTemplateURL = attrs.headertemplateurl;
			}

			if (attrs.onloadfetchdata != ''
					&& attrs.onloadfetchdata != undefined) {
				var onLoadFetchData = scope.$parent['onLoadFetchData']; //Page back filter check
				if (attrs.onloadfetchdata == "Yes" && selectedFilters == undefined && (onLoadFetchData  == undefined || onLoadFetchData)) {
					scope.onLoadFetchData();
				}
			}

			if (attrs.clientcaching != '' && attrs.clientcaching != undefined) {
				if (attrs.clientcaching == "No") {
					scope.clientCaching = false;
				}
			}
			
			if(attrs.tablefooter != '' && attrs.tablefooter != undefined) {
				scope.tableFooter = eval("(" + attrs.tablefooter + ")");
			}

			if (attrs.bodytemplateurl != ''
					&& attrs.bodytemplateurl != undefined) {
				scope.bodyTemplateURL = attrs.bodytemplateurl;
			}
			
			if (attrs.shownoofrecords != ''
					&& attrs.shownoofrecords != undefined && attrs.shownoofrecords == 'No') {
				scope.showNoOfRecords = false;
			}
			
			if (attrs.pagesize != ''
					&& attrs.pagesize != undefined ) {
					var pageSize = parseInt(attrs.pagesize);
					if(pageSize > 0){
						scope.tablePagination.pageSize = pageSize;
					}
			}
			
			if(selectedFilters){
				scope.populateSelectedFilters(selectedFilters);
			}

			var isFirstWatchCall = false;
			scope.$watch(watchAbleObjName, function(newValue) {
				if (newValue != undefined && newValue != '') {
					scope.createDefaultTable(newValue, scope.filters,
							scope.serversorting, scope.tableheaders,
							scope.masterTotalNoPages, scope.enablePagination,scope.tableFooter, true);
							scope.renderData = '';
					
					if(scope.serversorting == 'No' && !isFirstWatchCall){
						scope.setDefaultSort();
						isFirstWatchCall = true;
					}
				}
			}, true)
			
			if(watchAbleFilterObjName && watchAbleFilterObjName != ''){
				//scope.filters = {};
				scope.$watch(watchAbleFilterObjName, function(newValue) {
					if (newValue != undefined && newValue != '' && (newValue.isSearchCall == undefined || newValue.isSearchCall )) {
						if(newValue.isSearchCall){
							newValue.isSearchCall = false;
						}
						if(scope.isTableRenderable){
							scope.updateTableWithFilters(newValue);
						}
					}
				}, true)
			}
			

			scope.$watch(scope.paginationObjName, function(newValue) {
				if (newValue != undefined && newValue != '') {
					if (newValue != '' && newValue != undefined) {
						scope.updatePagination(newValue);
					}
				}
			}, true)

			if (scope.masterData != undefined && scope.masterData != '') {
				scope.createDefaultTable(scope.masterData, scope.filters,
						scope.serversorting, scope.tableheaders,
						scope.noOfPages, scope.enablePagination,scope.tableFooter, false);
			}
			
			scope.setDefaultSort();
			scope.clientCachingFn(scope.clientCaching);

		},
		templateUrl : function(elem, attr) {
			return getTemplateUrl(attr,
					"../common/widgets/table/defaultTable.html")
		}

	};
} ];

hcentive.WFM.CustomBodyData = [ function() {
	return {
		restrict : 'AE',
		replace : true,
		link : function(scope, element, attr) {
		if(attr != undefined){
			scope.cellValue = angular.fromJson(attr.cellvalue);
			scope.cellColValue = angular.fromJson(attr.cellcolvalue);
			}
		},
	
		templateUrl : function($scope, elem, attr) {
			var customURL = $scope.customTableBody;
			if (customURL == undefined || customURL == 0) {
				return "../common/widgets/table/defaultTableBody.html";
			}
			return customURL;
		}
	};
} ];

hcentive.WFM.CompileTemplate = [ '$compile', '$parse',
		function($compile, $parse) {
			return {
				link : function(scope, element, attr) {
					var parsed = $parse(attr.ngBindHtml);
					function getStringValue() {
						return (parsed(scope) || '').toString();
					}

					scope.$on('checkBoxEvent', function (event, data) {
						if(angular.isArray(data)){
							angular.forEach(data, function(checkBoxObj, key) {
								if(scope[checkBoxObj.key] != undefined){
									scope[checkBoxObj.key] = checkBoxObj.value;
								}
							});
						}else{
							if(scope[data.key] != undefined){
								scope[data.key] = data.value;
							}
						}
					});						

					// Recompile if the template changes
					scope.$watch(getStringValue, function() {
						$compile(element, null, -9999)(scope); // The -9999
						// makes it skip
						// directives so
						// that we do
						// not recompile
						// ourselves
					});
				}
			}
		} ];

hcentive.WFM.ngRightClick = [ '$parse', function($parse) {
	return function(scope, element, attrs) {
        var fn = $parse(attrs.ngrightclick);
        element.bind('contextmenu', function(event) {
            scope.$apply(function() {
                event.preventDefault();
                fn(scope, {$event:event});
            });
        });
    };
} ];

hcentive.WFM.TableDrillDown = [ function() {
	return {
		 restrict: 'A',
		 templateUrl: function(elem, attr){
		      return "../common/widgets/table/defaultTableDrillDown.html"
		    }
	};
} ];



hcentive.WFM.UnsafeFilter = [ '$sce', function($sce) {
	return function(val) {
		return $sce.trustAsHtml(val);
	};
} ];

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "CustomTableCtrl",
	"id" : hcentive.WFM.CustomTableCtrl
});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "CustomTableCtrl",
	"id" : hcentive.WFM.CustomTableCtrl
});

hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "CustomTableCtrl",
	"id" : hcentive.WFM.CustomTableCtrl
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].filters.push({
	"name" : "unsafefilter",
	"id" : hcentive.WFM.UnsafeFilter
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].filters.push({
	"name" : "unsafefilter",
	"id" : hcentive.WFM.UnsafeFilter
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].filters.push({
	"name" : "unsafefilter",
	"id" : hcentive.WFM.UnsafeFilter
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "customheaders",
	"id" : hcentive.WFM.CustomHeadersDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "customheaders",
	"id" : hcentive.WFM.CustomHeadersDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "customheaders",
	"id" : hcentive.WFM.CustomHeadersDir
});


//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "custominnerheaders",
	"id" : hcentive.WFM.CustomInnerHeadersDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "custominnerheaders",
	"id" : hcentive.WFM.CustomInnerHeadersDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "custominnerheaders",
	"id" : hcentive.WFM.CustomInnerHeadersDir
});


// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "customfooter",
	"id" : hcentive.WFM.CustomFooterDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "customfooter",
	"id" : hcentive.WFM.CustomFooterDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "customfooter",
	"id" : hcentive.WFM.CustomFooterDir
});


// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "customnestedtable",
	"id" : hcentive.WFM.CustomNestedTableDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "customnestedtable",
	"id" : hcentive.WFM.CustomNestedTableDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "customnestedtable",
	"id" : hcentive.WFM.CustomNestedTableDir
});


// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "custompagination",
	"id" : hcentive.WFM.CustomPaginationDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "custompagination",
	"id" : hcentive.WFM.CustomPaginationDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "custompagination",
	"id" : hcentive.WFM.CustomPaginationDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "custombody",
	"id" : hcentive.WFM.CustomBodyData
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "custombody",
	"id" : hcentive.WFM.CustomBodyData
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "custombody",
	"id" : hcentive.WFM.CustomBodyData
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "customtable",
	"id" : hcentive.WFM.CustomTableDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "customtable",
	"id" : hcentive.WFM.CustomTableDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "customtable",
	"id" : hcentive.WFM.CustomTableDir
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "compiletemplate",
	"id" : hcentive.WFM.CompileTemplate
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "compiletemplate",
	"id" : hcentive.WFM.CompileTemplate
});

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "compiletemplate",
	"id" : hcentive.WFM.CompileTemplate
});



//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "ngrightclick",
	"id" : hcentive.WFM.ngRightClick
});

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "ngrightclick",
	"id" : hcentive.WFM.ngRightClick
});

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "ngrightclick",
	"id" : hcentive.WFM.ngRightClick
});

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "tableDrillDown",
	"id" : hcentive.WFM.TableDrillDown
});