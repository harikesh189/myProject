hcentive.WFM.ContactCtrl = [ '$scope', function($scope) {
	// method body... do something attach to scope
} ];

//wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
"name" : "ContactCtrl",
"id" : hcentive.WFM.ContactCtrl
});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
"name" : "ContactCtrl",
"id" : hcentive.WFM.ContactCtrl
});

hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "ContactCtrl",
	"id" : hcentive.WFM.ContactCtrl
	});