hcentive.WFM.ContactDir = [ function() {
	return {
		restrict : 'A',
		templateUrl : function(elem,attr){return getTemplateUrl(attr,"../common/widgets/contact/contact.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "contact",
	"id" : hcentive.WFM.ContactDir
});

 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "contact",
	"id" : hcentive.WFM.ContactDir
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
		"name" : "contact",
		"id" : hcentive.WFM.ContactDir
});