hcentive.WFM.DownloadFileCtrl = (
    '$scope',
     '$http',
    'DownloadFileSrvc',  
    function ($scope, $http,DownloadFileSrvc) {
    	$scope.xmlFileName = '';
		$scope.download = function(xmlFileName,type,id,dataType){
		$scope.xmlFileName = xmlFileName;
		$scope.dataType = dataType;
		var params = {'type' : type, 
				  'id' : id,"tenant":$scope.wfmAppContext.loggedInUser.tenantId};
			DownloadFileSrvc.download(params,successCallback,errorCallback);
		}
		function successCallback(data) {
			if($scope.dataType == 'xml')
				$scope.downloadXML(data,$scope.xmlFileName);		    
		}
		function errorCallback(data){}

    	
    }
  );

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
    "name": "DownloadFileCtrl",
    "id": hcentive.WFM.DownloadFileCtrl
});