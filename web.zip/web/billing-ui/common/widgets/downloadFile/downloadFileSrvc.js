hcentive.WFM.DownloadFileSrvc = [ '$http', 'RESTSrvc',function($http, RESTSrvc) {
	
	var download = function(params,successCallback,errorCallback){
		RESTSrvc.getForData('downloadItem',params,null,successCallback,errorCallback);
	};
		
	return {
		download:download
	};
	
}];


// wireup the directive to application

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "DownloadFileSrvc",
	"id" : hcentive.WFM.DownloadFileSrvc
});
