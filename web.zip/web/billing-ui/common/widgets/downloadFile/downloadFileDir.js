hcentive.WFM.DownloadFileDir = [ '$compile', '$sce', function($compile, $sce) {
	return {
		restrict : 'A',
		replace : true,
		 templateUrl: function(elem,attr){return getTemplateUrl(attr,"../common/widgets/downloadFile/downloadFile.html")},
		 link : function(scope, iElement, iAttrs, ctrl) {
			console.log("in download dir");
			scope.attrs = iAttrs;
		}
			
		};
} ];



//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "wfmDownloadFile",
	"id" : hcentive.WFM.DownloadFileDir
});
 
