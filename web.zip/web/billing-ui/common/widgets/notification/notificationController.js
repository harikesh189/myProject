hcentive.WFM.NotificationCtrl = [
		'$scope',
		'NotificationSrvc',
		'EventBusSrvc',
		'$timeout', 'NotifySrvc' ,
		function($scope, NotificationSrvc, EventBusSrvc, $timeout,NotifySrvc) {
			
			$scope.pagination = defaultPagination('notification','');
			$scope.sort = defaultSort('');
			
			$scope.deleteNotificationPopup = function(id){
				NotifySrvc({
		            id: 'simpleDialog',
		            template: '<div><div class="msgBoxContainer"><div class="msgBoxImage" id="msgBox1404108354749Image"><img src="../images/confirm.png"></div><div class="msgBoxContent" id="msgBox1404108354749Content"><p><span>Are you sure you want to remove the selected notification?</span></p></div></div><div class="msgBoxButtons" id="msgBox1404108354749Buttons"></div></div>',
		            title: 'Account Details',
		            backdrop: true,
		            success: {label: 'Yes', fn: function() {
		            	$scope.deleteNotification(id);
					}},
					cancel: {label: 'Cancel', fn: function() {
						
					}}
					});
			}
			
			$scope.deleteNotification = function(id){
				var inputJson = {"notificationId" : id};
				NotificationSrvc.deleteNotification(inputJson,deleteNotificationSuccess,deleteNotificationError);
				
			}
			
			var deleteNotificationSuccess = function(){
				getNotifications($scope.$parent.wfmAppContext.contextualContract);
			}
			
			var deleteNotificationError = function(){
				alert("Error in Deleting Notification");
			}

			var notificationSuccess = function(notifications) {
				var notificationsJSON = notifications;
				if(notificationsJSON.content.length > 0)
				{
					if($scope.isBrokerBeType()){
						$scope.notifications = getTransformedNotificationsForBroker(notificationsJSON.content);
					}else{
						$scope.notifications = getTransformedNotifications(notificationsJSON.content);
					}
					
					$scope.notifications.length = notificationsJSON.totalElements;
				}
				else
					$scope.notifications = 'No Data';

				// Mark notification as read after some time !!
				$timeout(function() {
					var nids = [];
					angular.forEach($scope.notifications,
							function(notification) {
								if (notification.status != "READ") {
									nids.push(notification.id);
								}
							});
					if (nids != null && nids.length > 0) {
						var params = {
							"notificationIDs" : nids
						};
						NotificationSrvc.markRead(params, null, function() {
							angular.forEach($scope.notifications, function(
									notification) {
								notification.status = "READ";
							});
							// publish notificationRead event
							EventBusSrvc.publish('notificationRead', nids);
						}, null);
					}
				}, 2000);
				$scope.pagination.totalElements = notifications.totalElements;
				$scope.pagination.totalNoPages  = notifications.totalPages;
			};
			var notificationError = function(error) {
				$scope.notifications = 'No Data';
			};
			var getNotifications = function(contract) {
				var data = angular.toJson(getPageRequestCriteria($scope.pagination));
				NotificationSrvc.getNotifications({
					"beId" : contract.beId
				}, data,notificationSuccess, notificationError);
			};

			$scope.markRead = function(notificationIDs) {
				NotificationSrvc.markRead(params, data, successCallback,
						errorCallback);
			};
			
			$scope.notificationTableHeaders = [ {
				'isSortable' : 'yes',
				'key' : 'notification',
				'desc' : 'Description',
				'contentType' : 'String'
			}, {
				'isSortable' : 'yes',
				'key' : 'notification_time',
				'desc' : 'Time',
				'contentType' : 'String'
			}];
			
			$scope.notificationTableHeadersBroker = [ {
				'isSortable' : 'yes',
				'key' : 'notification',
				'desc' : 'Description',
				'contentType' : 'String'
			}, {
				'isSortable' : 'yes',
				'key' : 'notification_time',
				'desc' : 'Time',
				'contentType' : 'String'
			}, {
				'isSortable' : 'no',
				'key' : 'action',
				'desc' : '',
				'contentType' : 'html'
			}
			];

			// get notifications for current contract
			$scope.fetchdata = function(paginationObj,filterObj){
				$scope.pagination = paginationObj;
				getNotifications($scope.$parent.wfmAppContext.contextualContract);
			}
			
			EventBusSrvc.subscribe('contractUpdated', $scope, function(newVal,
					oldVal) {
				getNotifications(newVal);
			});

			$scope.isRead = function(notification) {
				return !angular.equals(notification.status, 'NEW');
			};
			$scope.isUnRead = function(notification) {
				return angular.equals(notification.status, 'NEW');
			};
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "NotificationCtrl",
	"id" : hcentive.WFM.NotificationCtrl
});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "NotificationCtrl",
	"id" : hcentive.WFM.NotificationCtrl
});

hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "NotificationCtrl",
	"id" : hcentive.WFM.NotificationCtrl
});