hcentive.WFM.NotificationSrvc = [
		'$http',
		'RESTSrvc',
		function($http, RESTSrvc) {

			var getUnreadNotifications = function(params, successCallback,
					errorCallback) {
				RESTSrvc.getForData('fetchUnreadNotifications', params, null,
						successCallback, errorCallback);
			};
			var getNotifications = function(params, data,successCallback,
					errorCallback) {
				RESTSrvc.postForData('fetchNotifications', params,data, null,
						successCallback, errorCallback);
			};
			var markRead = function(params, data,successCallback, errorCallback) {
				RESTSrvc.postForData("markNotificationRead",params,data,null,successCallback,errorCallback);
			};
			
			var deleteNotification = function(params, successCallback,
					errorCallback){
				RESTSrvc.getForData("deleteNotification",params,null,successCallback,errorCallback);
			}
			return {
				getNotifications : getNotifications,
				getUnreadNotifications : getUnreadNotifications,
				markRead : markRead,
				deleteNotification : deleteNotification
			};
		} ];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "NotificationSrvc",
	"id" : hcentive.WFM.NotificationSrvc
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "NotificationSrvc",
	"id" : hcentive.WFM.NotificationSrvc
});

hcentive.WFM.configData[hcentive.WFM.broker].services.push({
	"name" : "NotificationSrvc",
	"id" : hcentive.WFM.NotificationSrvc
});