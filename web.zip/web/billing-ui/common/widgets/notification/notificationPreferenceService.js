hcentive.WFM.NotificationPreferenceSrvc = [
		'$http',
		'RESTSrvc',
		function($http, RESTSrvc) {
            return { 
				getuserPreferences : function(params, successCallback,errorCallback) {
					RESTSrvc.getForData('getUserNotificationPreferences', params, null,successCallback, errorCallback);
				},
				saveuserPreferences : function(params, data,successCallback, errorCallback) {
					RESTSrvc.postForData("saveUserNotificationPreferences",params,data,null,successCallback,errorCallback);					
				}				
            }
		} ];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "NotificationPreferenceSrvc",
	"id" : hcentive.WFM.NotificationPreferenceSrvc
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "NotificationPreferenceSrvc",
	"id" : hcentive.WFM.NotificationPreferenceSrvc
});