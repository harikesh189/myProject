hcentive.WFM.NotificationPreferenceCtrl = [
		'$scope',
		'NotificationPreferenceSrvc',
		'EventBusSrvc',
		'NotifySrvc',
		'$timeout',
		function($scope, NotificationPreferenceSrvc, EventBusSrvc, NotifySrvc,$timeout) {
			var params = {
				"userID" 	: $scope.$parent.wfmAppContext.contextualContract.beId,
				"tenantID" 	: hcentive.WFM.applicationContext.loggedInUser.tenantId
			};
			$scope.preferences = [];
			if(hcentive.WFM.applicationContext.loggedInUser.managesBEofTypes.length>0){
				$scope.clientType = hcentive.WFM.applicationContext.loggedInUser.managesBEofTypes[0]
			}
			$scope.getPreferences = function(){
				NotificationPreferenceSrvc.getuserPreferences(params, function(result) {
					var mapList = [];
					angular.forEach(result,
						function(value, key) {
							var modeMap = value.modeEnableMap;
							angular.forEach(modeMap, function(mapValue, mapKey) {
							   if(mapKey=='IN_APP_NOTIFICATION'){
									delete modeMap.IN_APP_NOTIFICATION;
							   }
							 });
							
					});
					$scope.preferences = result;
				}, function(error) {
					console.log(error);
					$scope.preferences = null;
				});
			}
			$scope.getPreferences();
		$scope.launchInlineModal = function() {
			$scope.submitted = false;
			NotifySrvc({
			id: 'simpleDialog',
			template:
				'<div class="row-fluid">' +
				' <p>You want to change your notification settings.</p>' +
				'</div>',
				title: 'Are You Sure?',
				backdropCancel: false,
				backdrop: true,
				cancel: {label: 'Cancel', fn: function() {$scope.getPreferences()}},
				success: {label: 'Yes', fn: function() {$scope.updatePreferences()}}
			});
		};
			
			// submit handler.
			$scope.updatePreferences = function() {
				NotificationPreferenceSrvc.saveuserPreferences(params,
						$scope.preferences, function(success) {
							// handle sucess here.
						}, function(error) {
							console.log(error);
						});
			};
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "NotificationPreferenceCtrl",
	"id" : hcentive.WFM.NotificationPreferenceCtrl
});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "NotificationPreferenceCtrl",
	"id" : hcentive.WFM.NotificationPreferenceCtrl
});