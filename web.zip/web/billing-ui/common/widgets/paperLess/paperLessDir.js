hcentive.WFM.PaperLessDir = [ function() {
	return {
		restrict : 'A',
		templateUrl : function(elem,attr){return getTemplateUrl(attr,"../common/widgets/paperLess/teaser.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "paperless",
	"id" : hcentive.WFM.PaperLessDir
});

 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "paperless",
	"id" : hcentive.WFM.PaperLessDir
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
		"name" : "paperless",
		"id" : hcentive.WFM.PaperLessDir
	});