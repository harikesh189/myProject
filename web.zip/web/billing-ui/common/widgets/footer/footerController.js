hcentive.WFM.FooterCtrl = [ '$scope', function($scope) {
	// method body... do something attach to scope
} ];

//wireup the controller to application
 hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "FooterCtrl",
	"id" : hcentive.WFM.FooterCtrl
});

 hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "FooterCtrl",
	"id" : hcentive.WFM.FooterCtrl
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
		"name" : "FooterCtrl",
		"id" : hcentive.WFM.FooterCtrl
});