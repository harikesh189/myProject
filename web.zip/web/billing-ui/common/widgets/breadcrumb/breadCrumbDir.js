hcentive.WFM.BreadCrumbDir = [ '$compile', '$sce', function($compile, $sce) {
	return {
		restrict : 'A',
		 templateUrl: function(elem,attr){return getTemplateUrl(attr,"../common/widgets/breadcrumb/breadcrumb.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "wfmbreadcrumb",
	"id" : hcentive.WFM.BreadCrumbDir
});

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "wfmbreadcrumb",
	"id" : hcentive.WFM.BreadCrumbDir
});
 
//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "wfmbreadcrumb",
	"id" : hcentive.WFM.BreadCrumbDir
});