hcentive.WFM.paginationCtrl = ('paginationCtrl', function($scope, $http, EventBusSrvc) {
		
		$scope.sortConfig = function(colToBeSorted,isSortable) {
			if(isSortable == 'yes'){
				var colSorted = $scope.sort.sortedColumn;
				var sortedOrder = $scope.sort.sortedOrder;
				var sortedColClass = '';
				if (colToBeSorted == colSorted) {
					if (sortedOrder == "desc") {
						sortedOrder = "asc";
						sortedColClass = ".sorting_desc";
					} else {
						sortedOrder = "desc";
						sortedColClass = "footable-sorted-desc";
					}
				} else {
					sortedOrder = "desc";
					sortedColClass = "footable-sorted-desc";
				}
				var sortConfig = {
					"sortedColumn" : colToBeSorted,
					"sortedOrder" : sortedOrder,
					"sortedColClass" : sortedColClass
				};
				$scope.sort = sortConfig;
				$scope.pagination.sortingOrder = $scope.sort.sortedOrder;
				$scope.pagination.sortedColumn = $scope.sort.sortedColumn;
				$scope.fetchdata(getPageRequestCriteria($scope.pagination));
			}
		};
			
		$scope.pageChange = function(pageOperation) {
			var currPageNo = $scope.pagination.pageIndex;
			var currDispPageNo = $scope.pagination.displayPageNo;
			var noOfPages = $scope.pagination.totalNoPages;
			var indexPagination = '';
			var newPageIndex = '0';
			var newDisplayPageNo = '1';
			
			if (pageOperation == 'first') {
				if(parseInt(currDispPageNo) != 1){
					newPageIndex = '0';
					newDisplayPageNo = '1';
				}else{
					return;
				}
			} else if (pageOperation == 'next'){
				if(parseInt(currDispPageNo) < parseInt(noOfPages)){
					newPageIndex = parseInt(currPageNo) + 1;
					newDisplayPageNo = parseInt(currDispPageNo) + 1;
				}else{
					return;
				}
			} else if (pageOperation == 'prev') {
				if (parseInt(currPageNo) != 0) {
					newPageIndex = parseInt(currPageNo) - 1;
					newDisplayPageNo = parseInt(currDispPageNo) - 1;
				}else{
					return ;
				}
			} else if (pageOperation == 'last') {
				if(parseInt(currDispPageNo) != parseInt(noOfPages)){
					newPageIndex = parseInt(noOfPages) - 1;
					newDisplayPageNo = parseInt(noOfPages);
				}else{
					return ;
				}
			}
			if (parseInt(newPageIndex) < noOfPages) {
				indexPagination = {
					"newPageIndex" : newPageIndex,
					"newDisplayPageNo" : newDisplayPageNo
				};
			}
			$scope.pagination.pageIndex = newPageIndex;
			$scope.pagination.displayPageNo = newDisplayPageNo;
			$scope.fetchdata(getPageRequestCriteria($scope.pagination));
	      };
});

hcentive.WFM.PaginationDir = [ '$compile', '$sce', function($compile, $sce) {
	return {
		restrict : 'A',
		link : function(scope, iElement, iAttrs, ctrl) {
			scope.attrs = iAttrs;
		},
		 templateUrl: function(elem,attr){
		return getTemplateUrl(attr,"../common/widgets/pagination/pagination.html")}
		
	};
} ];

hcentive.WFM.TableHeadersDir = [ '$compile', '$sce', function($compile, $sce) {
	return {
		restrict : 'A',
		link : function(scope, iElement, iAttrs, ctrl) {
			scope.attrs = iAttrs;
			if(scope.attrs.columns){
				scope.headerColumns =eval('('+ scope.attrs.columns+')');
			}
		},
		 templateUrl: function(elem,attr){
		return getTemplateUrl(attr,"../common/widgets/pagination/tableheaders.html")}
		
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "tableheaders",
	"id" : hcentive.WFM.TableHeadersDir
});

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "tableheaders",
	"id" : hcentive.WFM.TableHeadersDir
});

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "tableheaders",
	"id" : hcentive.WFM.TableHeadersDir
});


//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "pagination",
	"id" : hcentive.WFM.PaginationDir
});

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "pagination",
	"id" : hcentive.WFM.PaginationDir
});

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "pagination",
	"id" : hcentive.WFM.PaginationDir
});

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "paginationCtrl",
	"id" : hcentive.WFM.paginationCtrl
});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "paginationCtrl",
	"id" : hcentive.WFM.paginationCtrl
});

hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "paginationCtrl",
	"id" : hcentive.WFM.paginationCtrl
});