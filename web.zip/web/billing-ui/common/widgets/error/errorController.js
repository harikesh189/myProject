hcentive.WFM.ErrorCtrl = [ '$scope', function($scope) {
	// method body... do something attach to scope
	$scope.$watch("wrongDate", function(newValue) {
		if (newValue != undefined && newValue != '') {
			if(newValue == "true"){
					$scope.show = 'true';
			}else{
				    $scope.show = 'false';
			}
		}
	}, true)
} ];

//wireup the controller to application
 hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "ErrorCtrl",
	"id" : hcentive.WFM.ErrorCtrl
});

 hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "ErrorCtrl",
	"id" : hcentive.WFM.ErrorCtrl
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
		"name" : "ErrorCtrl",
		"id" : hcentive.WFM.ErrorCtrl
});