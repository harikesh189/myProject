hcentive.WFM.errorDateDir = function() {
	return {
		restrict : 'E',
		templateUrl : '../common/widgets/error/error.html',
		link : function(scope, iElement, iAttrs, ctrl) {
			scope.attrs = iAttrs;
			scope.message = hcentive.WFM.errorMessage[scope.attrs.message];
			scope.show = scope.attrs.show;
		}
	};
};

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "errordate",
	"id" : hcentive.WFM.errorDateDir
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
		"name" : "errordate",
		"id" : hcentive.WFM.errorDateDir
});
 
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
		"name" : "errordate",
		"id" : hcentive.WFM.errorDateDir
});