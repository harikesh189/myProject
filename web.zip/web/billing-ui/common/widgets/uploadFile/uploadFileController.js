hcentive.WFM.UploadCtrl = (
    '$scope',
     '$http',
    'RESTSrvc',  'NotifySrvc',
    function ($scope, $http,RESTSrvc, NotifySrvc) {
    	
    	$scope.showUploadPopup = function(uploadType,popupHeader) {
    		
			if(popupHeader == undefined || popupHeader == ''){
				popupHeader = "Upload";
			}
        	
        	NotifySrvc({
	            id: 'simpleDialog',
	       template:  ' <div class="rowMargin">'+
			 ' <label for="contactNo" class="control-label">Select input file:</label> '+
 			 '</div> '+
			 '<input type="file" name="file" onchange="angular.element(this).scope().uploadFile(this.files,\''+uploadType+'\')"/>',
	            title: popupHeader,
	            backdropCancel : true,
	            backdrop: true,
				controller : 'UploadCtrl'
				});
        	
        }
        $scope.uploadFile = function(files,uploadType) {
        	var sucessCallBack = function(data){
        		$scope.$modalClose();
        	}
        	
        	var errorCallBack = function(data){
        		alert("error while uploading");
        	}
        	
        	RESTSrvc.postForFile('uploadXMLFile',{'uploadType':uploadType},files,sucessCallBack,errorCallBack);
        };
    	
    }
  );

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
    "name": "UploadCtrl",
    "id": hcentive.WFM.UploadCtrl
});