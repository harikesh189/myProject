hcentive.WFM.UploadFileDir = [ '$compile', '$sce', function($compile, $sce) {
	return {
		restrict : 'A',
		 templateUrl: function(elem,attr){return getTemplateUrl(attr,"../common/widgets/uploadFile/uploadFile.html")},
		 scope: {
			uploadType : '@',
			uploadPopupHeaderText : '@',
			uploadButtonText : '@'
		 },
		link : function(scope, iElement, iAttrs, ctrl) {
			console.log("in upload dir");
			scope.attrs = iAttrs;
		}
			
		};
} ];



//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "wfmUpload",
	"id" : hcentive.WFM.UploadFileDir
});
 
