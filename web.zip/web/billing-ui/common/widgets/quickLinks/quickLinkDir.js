hcentive.WFM.QuickLinksDir = [ function() {
	return {
		restrict : 'A',
		templateUrl : function(elem,attr){return getTemplateUrl(attr,"../common/widgets/quickLinks/quickLinks.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "quicklink",
	"id" : hcentive.WFM.QuickLinksDir
});

 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "quicklink",
	"id" : hcentive.WFM.QuickLinksDir
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
		"name" : "quicklink",
		"id" : hcentive.WFM.QuickLinksDir
	});