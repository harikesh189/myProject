hcentive.WFM.QuickLinkCtrl = [ '$scope','NotifySrvc', 'PaymentMethodService','EventBusSrvc','$location', function($scope,NotifySrvc,PaymentMethodService,EventBusSrvc,$location) {
	
	if(angular.equals($scope.$parent.beType(),hcentive.WFM.beTypes["2"])){
		$scope.quickLinkList = $scope.getRenderableMenuList(hcentive.WFM.clientConfigurations[0].quickLinksGroup.menus);
	}else{
		$scope.quickLinkList = $scope.getRenderableMenuList(hcentive.WFM.clientConfigurations[0].quickLinksIndividual.menus);
	}
		
	$scope.quickPaymentPopUp = function() {
			NotifySrvc({
              id: 'simpleDialog',
              template:
                '<div class="row-fluid">' +
                ' <p>There are currently no preferred payment methods saved for your account.</p>'+
				' <a href="#paymentMethod/payment-method" ng-click="$modalClose()">CLICK HERE</a> to save a new payment method for making faster payments in the future</p>' +
                '</div>',
              title: 'Are You Sure',
              backdrop: true,
			  success: {label: 'OK', fn: null}
			});
		};
		
	var changeLocation = function(){
		$location.path('payment/quick-pay');
		$location.replace();
	}
	
	var successPreferredPaymentMethodSaved = function(data) {
	//preferred payment method exists
		
		if(data!="")
		{
			$scope.paymentDetail=data;
			EventBusSrvc.publish('prefferedPaymentMode',data);
			changeLocation();
		}
		else{
			$scope.quickPaymentPopUp();
		}
	};
	
	var errorCallback = function(data) {
		alert('error in payment method service call');
	};
	
	$scope.test = function(value) {
	alert(value);
	};
	
	$scope.getPreferredPaymentMethod =function(){
		var params = {
						customerId : $scope.$parent.wfmAppContext.contextualContract.beId
					};
		PaymentMethodService.getPreferredPayementMethod(params,successPreferredPaymentMethodSaved,errorCallback);
	}

} ];

//wireup the controller to application
 hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "QuickLinkCtrl",
	"id" : hcentive.WFM.QuickLinkCtrl
});

 hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "QuickLinkCtrl",
	"id" : hcentive.WFM.QuickLinkCtrl
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
		"name" : "QuickLinkCtrl",
		"id" : hcentive.WFM.QuickLinkCtrl
	});