hcentive.WFM.NotifySrvc = [
		"$document",
		"$compile",
		"$rootScope",
		"$controller",
		"$timeout",
		function($document, $compile, $rootScope, $controller, $timeout) {
			var defaults = {
				id : null,
				template : null,
				templateUrl : null,
				title : 'Default Title',
				backdrop : true,
				success : {
					label : 'Blank',
					fn : null
				},
				cancel : {
					label : 'Blank',
					fn : null
				},
				closeHandler : {
					callOnCloseFn : false,
					fn : null
				},
				controller : null, // just like route controller declaration
				backdropClass : "modal-backdrop",
				backdropCancel : true,
				footerTemplate : null,
				modalClass : "modal",
				closeButton : true,
				closeModalBox : true,
				css : {
					top : '100px',
					left : '30%',
					margin : '0 auto'
				}
			};

			return function mobilePopup(options) {

				var body = $document.find('mobileDiv');

				var ctrl, locals, scope = options.scope || $rootScope.$new();

				scope.$modalSuccessLabel = options.success.label;
				var cancelButtonDiv = '';
				if (options.cancel != undefined) {
					scope.$modalCancelLabel = options.cancel.label;
					cancelButtonDiv = '<a href="" class="btn btn-secondary js-close ui-btn" data-rel="back" ng-click="$modalCancel()" id="mobilePopupCancel">'
							+ scope.$modalCancelLabel + '</a>';
				}
				scope.$title = options.title;
				var modalEl = angular
						.element('<div>'
								+ '<div class="ui-dialog-titlebar">'
								+ '<span class="ui-dialog-title">'
								+ scope.$title
								+ '</span>'
								+ '</div>'
								+ '<form class="form popup-form form-popup-design">'
								+ '<fieldset>'
								+ '<p>'
								+ options.template
								+ '</p>'
								+ '<div class="controls">'
								+ '<a href="" class="btn btn-primary ui-btn" id="mobilePopupOk">'
								+ scope.$modalSuccessLabel + '</a>'
								+ cancelButtonDiv + '</div>' + '</fieldset>'
								+ '</form>' + '</div>');

				scope.$modalClose = function() {
					if (options.closeHandler && options.closeHandler.callOnCloseFn) {
						var callFn = options.closeHandler.fn || closeFn;
						callFn.call(this);
						$('#mobilePopup').popup("close");
					} else {
						$('#mobilePopup').popup("close");
					}
				};
				scope.$modalCancel = function() {
					var callFn = options.cancel.fn || closeFn;
					callFn.call(this);
					scope.$modalClose();
				};
				scope.$modalSuccess = function() {
					var callFn = options.success.fn || closeFn;
					var validationFn = options.validation;
					if (validationFn != undefined) {
						if (options.validation.fn.call(this)) {
							callFn.call(this);
							if (options.closeModalBox)
								scope.$modalClose();
						}
					} else {
						callFn.call(this);
						if (options.closeModalBox)
							scope.$modalClose();
					}

				};

				if (options.controller) {
					locals = angular.extend({
						$scope : scope
					}, passedInLocals);
					ctrl = $controller(options.controller, locals);
					// Yes, ngControllerController is not a typo
					modalEl.contents().data('$ngControllerController', ctrl);
				}

				$compile(modalEl)(scope);
				document.getElementById('mobilePopup').innerHTML = '';
				angular.element(document.getElementById('mobilePopup')).append(
						modalEl);

				$("#mobilePopupOk").on("click", function(event) {
					$('#mobilePopup').popup("close");
					var callFn = options.success.fn || closeFn;
					callFn.call(this);
				});
				
				$("#mobilePopupCancel").on("click", function(event) {
					$('#mobilePopup').popup("close");
					var callFn = options.cancel.fn || closeFn;
					callFn.call(this);
				});
				
				$("#mobilePopup").popup("open");

			};

		} ];

hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "NotifySrvc",
	"id" : hcentive.WFM.NotifySrvc
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "NotifySrvc",
	"id" : hcentive.WFM.NotifySrvc
});

hcentive.WFM.configData[hcentive.WFM.broker].services.push({
	"name" : "NotifySrvc",
	"id" : hcentive.WFM.NotifySrvc
});

hcentive.WFM.configData[hcentive.WFM.mobile].services.push({
	"name" : "NotifySrvc",
	"id" : hcentive.WFM.NotifySrvc
});