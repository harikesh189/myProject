hcentive.WFM.NavDir = [ function() {
	return {
		restrict : 'E',
		templateUrl : function(elem,attr){return getTemplateUrl(attr,"../common/widgets/navigation/headerNav.html")},
		link : function(scope, iElement, iAttrs, ctrl) {
			var navJson = angular.fromJson(iAttrs.input);
			scope.navList = navJson;
		}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "wfmnavigation",
	"id" : hcentive.WFM.NavDir
});

 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "wfmnavigation",
	"id" : hcentive.WFM.NavDir
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
		"name" : "wfmnavigation",
		"id" : hcentive.WFM.NavDir
});