hcentive.WFM.LeftNavigationDir = [ function() {
	return {
		restrict : 'A',
		templateUrl : function(elem,attr){return getTemplateUrl(attr,"../common/widgets/navigation/leftNavigation/leftNav.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "leftnavigation",
	"id" : hcentive.WFM.LeftNavigationDir
});

 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "leftnavigation",
	"id" : hcentive.WFM.LeftNavigationDir
});
 
 hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
		"name" : "leftnavigation",
		"id" : hcentive.WFM.LeftNavigationDir
});