hcentive.WFM.ReportService = [ 'RESTSrvc','$window', function(RESTSrvc, $window) {

	var getReportForAdmin = function(params, data, successCallBack, errorCallBack) {
		var resourceKey ='getReportForAdmin';
		RESTSrvc.postForData(resourceKey, params, data, null, successCallBack, errorCallBack);
	};
	
	var getReportForBE = function(params, data, successCallBack, errorCallBack) {
		var resourceKey ='getReportForBE';
		RESTSrvc.postForData(resourceKey, params, data, null, successCallBack, errorCallBack);
	};
	
	var downloadReportForAdmin = function(reportName, params, successCallback, errorCallBack) {
		RESTSrvc.postForData('downloadReportForAdmin', params, null, null, successCallback, errorCallBack);
	};
	
	var downloadReportForBE = function(reportName, params, errorCallBack) {
		RESTSrvc.postForData('downloadReportForBE', params, null, null, successCallback, errorCallBack);
	};
	
	var makeOutboundPayment = function(params,data,successCallback, errorCallBack) {
		RESTSrvc.postForData('makeOutboundPaymentUrl', params, data, null, successCallback, errorCallBack);
	};
	
	var getBeByExternalId = function(params,successCallback, errorCallBack) {
		RESTSrvc.getForData('getBeByExternalId', params, null, successCallback, errorCallBack);
	};
	
	
	return {
		getReportForAdmin : getReportForAdmin,
		getReportForBE    : getReportForBE,
		downloadReportForAdmin : downloadReportForAdmin,
		downloadReportForBE : downloadReportForBE,
		makeOutboundPayment : makeOutboundPayment,
		getBeByExternalId : getBeByExternalId
		
	};
	
}];

// wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "ReportSrvc",
	"id" : hcentive.WFM.ReportService
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "ReportSrvc",
	"id" : hcentive.WFM.ReportService
});

hcentive.WFM.configData[hcentive.WFM.broker].services.push({
	"name" : "ReportSrvc",
	"id" : hcentive.WFM.ReportService
});