hcentive.WFM.ReportBaseCtrl = ('ReportBaseCtrl', 'ReportSrvc', '$filter', 'NotifySrvc', function($scope, $sce, ReportSrvc, $filter, NotifySrvc) {
	
		$scope.filter = {};
		$scope.downloadFilter = {};
		$scope.reportName = '';
		$scope.subTitle = '';
		$scope.isAdmin = 'true';
		
		$scope.init = function(iAttrs){
 			$scope.attrs = iAttrs;
 			
 			$scope.id = iAttrs.id;
 			
 			$scope.reportName = iAttrs.report;
 			$scope.format = iAttrs.format;
 			
 			if(iAttrs.admin != null && iAttrs.admin != undefined && iAttrs.admin != '') {
 				$scope.isAdmin = iAttrs.admin;
 			}
 			
 			$scope.reportTitle = iAttrs.reporttitle;
 			$scope.subTitleFormat = iAttrs.subtitleformat;
 			$scope.subTitleArgs = iAttrs.subtitleargs;
 			
 			$scope.chartWidth = iAttrs.chartwidth;
 				
 			$scope.viewMoreURL = iAttrs.viewmoreurl;
 			
 			$scope.pieReport = iAttrs.piereport;
 			$scope.barReport = iAttrs.barreport;
			$scope.lineReport = iAttrs.linereport;
 			$scope.tabularReport = iAttrs.tabularreport;
 			
 			//$scope.filterAtTop = iAttrs.filterattop;
 			$scope.topFilterTemplate = iAttrs.topfiltertemplate;
 			$scope.filterTemplate = iAttrs.filtertemplate;
 			
 			$scope.downloadPdf = iAttrs.downloadpdf;
 			$scope.downloadXls = iAttrs.downloadxls;
 			$scope.downloadCsv = iAttrs.downloadcsv;
 			
 			$scope.exportXlsReport = iAttrs.exportxlsreport;

 			$scope.showSwitchExport = ($scope.downloadPdf != null || $scope.downloadXls != null || $scope.downloadCsv != null || $scope.pieReport != null || 
 										$scope.lineReport != null ||	$scope.barReport != null|| $scope.tabularReport != null);
 			
 			$scope.titleSpanClass = 'span6';
 			$scope.filterSpanClass = 'span6';
 			
 			if(iAttrs.titlespanclass != null && iAttrs.titlespanclass != undefined && iAttrs.titlespanclass != '' ) {
 				$scope.titleSpanClass = iAttrs.titlespanclass;
 			}
 			if(iAttrs.filterspanclass != null && iAttrs.filterspanclass != undefined && iAttrs.filterspanclass != '' ) {
 				$scope.filterSpanClass = iAttrs.filterspanclass;
 			}
 			
 			$scope.filter.timeFrame = '';
		};
		
	      $scope.getReportContentError = function(data){
	    	 stopProcessing($scope.id);
	  		 var result = 'Internal Server Error';
	  		 if(data != null && data != undefined && data != '') {
	  			var error = data.error;
		    	var msg = data.message;
		    	
		    	if(error != null && error != undefined && error != '') {
		    		result = error;
		    	}
		    	
		    	if(msg != null && msg != undefined && msg != '') {
		    		result = result + ' : ' + msg;
		    	}
	  		 }
			 $scope.reportContent = $sce.trustAsHtml("<div style='color:red;'>" + result + "</div>");
			 $scope.applyUpdateExportFunctions();
	  	  };
		  	
		  $scope.getReportContentSuccess = function(data){
			  stopProcessing($scope.id);
			  var $htmlNode = $(data, true);
			  var result = '<div>No data found for report.</div>';
			  if($htmlNode.find("div") != null && $htmlNode.find("div") != undefined && $htmlNode.find("div").length > 0) {
				  var length = $htmlNode.find("div").length;
				  result = "";
				  for (var i = 0; i < length; i++) {
					  var divNode = $htmlNode.find("div")[i];
					  if(divNode.outerHTML !=null && divNode.outerHTML != undefined && 
					     divNode.nextElementSibling.outerHTML != null && divNode.nextElementSibling.outerHTML != undefined &&
					     divNode.nextElementSibling.className == "jasperreports" && divNode.nextElementSibling.type == "text/javascript") {
						  var chartScript = updateChartWidth(divNode.nextElementSibling.outerHTML);
						  result = result + divNode.outerHTML + chartScript; 
					  }
				  }
				   
			  } else if($htmlNode.find("table") != null && $htmlNode.find("table") != undefined && $htmlNode.find("table") != '' &&
					  $htmlNode.find("table")[0] != null && $htmlNode.find("table")[0] != undefined && $htmlNode.find("table")[0] != '' &&
					  $htmlNode.find("table")[0].outerHTML != null && $htmlNode.find("table")[0].outerHTML != undefined && $htmlNode.find("table")[0].outerHTML != '') {
				  var $contentTable = $htmlNode.find("table");
				  //$contentTable.find("img").remove();
				  /*$contentTable.find("img").each(
						function() {
							this.src = "images/px";
						});*/
				  result = $contentTable[0].outerHTML
			  }
			  
			  $scope.reportContent = $sce.trustAsHtml(result);
			  $scope.applyUpdateExportFunctions();
		  };
		  
		  function updateChartWidth(script) {
			  var chartWidth = $scope.chartWidth;
			  if(chartWidth != null && chartWidth != undefined && chartWidth != '') {
				  	var findVal = "width: ";
					var widthIndex = script.indexOf(findVal);
					if(widthIndex != null && widthIndex != undefined && widthIndex > 0) {
						var result1 = script.substring(0, widthIndex + findVal.length);
						var result2 = script.substr(script.indexOf(',', widthIndex), script.length);
						var finalResult = result1 + chartWidth + result2;
						return finalResult;
					}
			  }
			  return script;
			}

	      $scope.getReportContent = function(reportName, format, successCallBack, errorCallBack) {
	    	  
	    	if(successCallBack == null || successCallBack == undefined || successCallBack == '') {
	    		successCallBack = $scope.getReportContentSuccess;
	    	}
	    	if(errorCallBack == null || errorCallBack == undefined || errorCallBack == '') {
	    		errorCallBack = $scope.getReportContentError;
	    	}
	    	
	    	startProcessing($scope.id);
	    	$scope.reportName = reportName;
	    	
			var data = {"filters" : $scope.getFilter(reportName)};
			var params = {
					"reportName" : reportName,
					"format" : format
				};
			$scope.downloadFilter = data;
			$scope.updateSubTitle();
			
			if($scope.isAdmin == 'true') {
				ReportSrvc.getReportForAdmin(params, data, successCallBack, errorCallBack);
			} else {
				params.beType = '';
				params.beId = '';
				ReportSrvc.getReportForBE(params, data, successCallBack, errorCallBack);
			}
	      };
	      
	      $scope.getFilter = function(reportName) {
		    	var reportFilter = getReportConfiguration(reportName, $filter);
		    	
		    	if(reportFilter == null || reportFilter == '' || reportFilter == {} || reportFilter == undefined) {
		    		return $scope.filter;
		    	} else {
		    		angular.forEach(reportFilter, function(value, key){
						var filter = $scope.filter[key];
						if(filter == null || filter == '' || filter == {} || filter == undefined) {
							$scope.filter[key] = value;
						}
					 });
		    		return $scope.filter;
		    	}
	      };
	      
	      $scope.loadDefaultFilter = function(reportName) {
		    	var reportFilter = getReportConfiguration(reportName, $filter);
		    	
		    	if(reportFilter == null || reportFilter == '' || reportFilter == {} || reportFilter == undefined) {
		    		return $scope.filter;
		    	} else {
		    		angular.forEach(reportFilter, function(value, key){
						$scope.filter[key] = value;
					 });
		    		return $scope.filter;
		    	}
	      };
	      
	      $scope.downloadReport = function(format) {
	    	
	    	  var convertByteStreamData= function (data) {
	            var raw = window.atob(data);
	            var rawLength = raw.length;
	            var array = new Uint8Array(new ArrayBuffer(rawLength));
	
	            for(i = 0; i < rawLength; i++) {
	              array[i] = raw.charCodeAt(i);
	            }
	            return array;
	          }
	          var downloadReportSuccess = function(data){
	        	  if (navigator.msSaveBlob) { // IE 10+ 
	        		navigator.msSaveBlob(new Blob([convertByteStreamData(data)], { type: 'data:application/pdf' }), $scope.reportName + '.' + format); 
	        	  } else {
			    	   //Initialize file format you want csv or xls
					    var uri = 'data:application/pdf;base64,' + escape(data);
					    
					    // Now the little tricky part.
					    // you can use either>> window.open(uri);
					    // but this will not work in some browsers
					    // or you will not get the correct file extension    
					    
					    //this trick will generate a temp <a /> tag
					    var link = document.createElement("a");    
					    link.href = uri;
					    
					    //set the visibility hidden so it will not effect on your web-layout
					    link.style = "visibility:hidden";
					    link.download =  $scope.reportName + '.' + format;
					    
					    //this part will append the anchor tag and remove it after automatic click
					    document.body.appendChild(link);
					    link.click();
					    document.body.removeChild(link);
	        	  }
	        };
	        
	        var downloadReportError = function(data){
	        	var result = '';
		  		 if(data != null && data != undefined && data != '') {
		  			var error = data.error;
			    	var msg = data.message;
			    	var exception = data.exception;
			    	
			    	console.log('Error while downloading report : ' + error + ' : ' + msg + ' : ' + exception);
			    	if(msg != null && msg != undefined && msg != '') {
			    		result = ': ' + msg;
			    	}
		  		 }
	        	NotifySrvc({
					id : 'simpleDialog',
					template: 'Unable to download report ' + result,
					title : 'Download failed',
					backdrop : true,
					closeButton : false,
					success : {
						label : 'Ok',
						fn : function() {
						}
					}
				});
	        };
	      
	        var downloadReportName = $scope.reportName;
	    	if(format != null && format != undefined && format != '' && 
	    			(format == 'xls' || format == 'csv')) {
	    		downloadReportName =  $scope.exportXlsReport;
	    	}  
			var filter = '';
			angular.forEach($scope.downloadFilter.filters, function(value, key, index) {
				filter = filter + key + '=' + value + '&';
			});
			if(filter.charAt(filter.length-1) == '&'){
				filter = filter.substr(0, filter.length-1);
			}
	    	var params = {
	    			"reportName" : downloadReportName,
	    			"format" : format,
					"filter" : filter
	    		};
	    	
	    	if($scope.isAdmin == 'true') {
	    		ReportSrvc.downloadReportForAdmin($scope.reportName, params, downloadReportSuccess, downloadReportError);
			} else {
				params.beType = '';
				params.beId = '';
				ReportSrvc.downloadReportForBE($scope.reportName, params, downloadReportSuccess, downloadReportError);
			}
		  };
		  
	      $scope.updateReport = function(reportName) {
	    	  if(reportName == null || reportName == undefined || reportName == '') {
	    		  reportName = $scope.reportName;
	    	  }
	    	  $scope.getReportContent(reportName, 'html');
	      };
	      
	      $scope.reRenderReport = function() {
	    	  $scope.getReportContent($scope.reportName, $scope.format);
	      };
	      
	      $scope.updateSubTitle = function(format) {
	    	  var subTitle = '';
	    	  var fromDate = '';
	    	  var toDate = '';
	    	  
	 			
	    	  if($scope.downloadFilter != null && $scope.downloadFilter != '' && $scope.downloadFilter != {} && $scope.downloadFilter != undefined) {
	    		  var filters = $scope.downloadFilter.filters;
	    		  var args = $scope.subTitleArgs;
	    		  var format = $scope.subTitleFormat;
	    		  if(filters != null && filters != '' && filters != {} && filters != undefined &&
	    				  args != null && args != undefined && args != '' &&
	    				  format != null && format != undefined && format != '') {
	    			  subTitle = format;
	    			  angular.forEach(args.split(','), function(value, index) {
	    				  subTitle = subTitle.replace('{'+index+'}', filters[value]);
	    				});
	    			  $scope.subTitle = subTitle;
	    		  }
	    	  }
		  };
		  		  
		  // utils
		 //============Date Picker===============
		$scope.applyDatepicker = function(idOrClass, disabled) {
			$( "#"+idOrClass+", ."+idOrClass ).datepicker({
				showOn: "both",
		        buttonImage: "images/calender.png",
		        buttonImageOnly: true,
				buttonText: "Calender",
		  		changeMonth: true,
		  		changeYear: true,
				onClose: function( selectedDate ) {
					
					
					var dy;
					var mnth;
					var yr;
				if(idOrClass=="createdTill"){
					var toDateVal = new Date(selectedDate);
					dy=toDateVal.getDate();
					mnth=toDateVal.getMonth();
					yr=toDateVal.getFullYear();
					if(dy==31&&mnth==11){
						toDateVal.setDate(1);
						toDateVal.setMonth(0);
					}else{
						toDateVal.setMonth(mnth-12);
					}
					$( "#createdFrom, .createdFrom" ).datepicker( "option", "minDate", toDateVal );
					$( "#createdFrom, .createdFrom" ).datepicker( "option", "maxDate", selectedDate );
					
					$("#createdTill, .createdTill").attr('value',selectedDate );
				}else if(idOrClass=="createdFrom"){
					var fromDateVal= new Date(selectedDate);
					dy=fromDateVal.getDate();
					mnth=fromDateVal.getMonth();
					
					if(dy==1&&mnth==0){
						fromDateVal.setDate(31);
						fromDateVal.setMonth(11);
					}else{
						fromDateVal.setMonth(mnth+12);
					}
					$( "#createdTill, .createdTill" ).datepicker( "option", "minDate", selectedDate );
					$( "#createdTill, .createdTill" ).datepicker( "option", "maxDate", fromDateVal  );
					$("#createdFrom, .createdFrom").attr('value',selectedDate );
				}
      	  		
      		}
			});
		};
			
		  $scope.applyUpdateExportFunctions = function() {
			  var reportName=$scope.reportName;
			  var reportType='';
			  if($scope.filter.Select_Chart!==undefined && $scope.filter.Select_Chart!==''){
				  reportType=$scope.filter.Select_Chart.toLowerCase();
			  }
			  
			  $('#'+reportName+reportType+'Chart').addClass('active');
			  
			  $(".showItems").hover(
				  function() {
					$(this).find(".dropItems").show();
				  }, function() {
					$(this).find(".dropItems").hide();
				  }
			  );
			  
				
			  $('#'+reportName+'pieChart').on('click', function(){
					$(this).addClass('active');
					$('#'+reportName+'lineChart').removeClass('active');
					$('#'+reportName+'tabularChart').removeClass('active');
					$('#'+reportName+'barChart').removeClass('active');
					//$('#barChart1').removeClass('active');
					//$('#tabularData1').removeClass('active');
			  });
			  
			  $('#'+reportName+'lineChart').on('click', function(){
					$(this).addClass('active');
					$('#'+reportName+'pieChart').removeClass('active');
					$('#'+reportName+'barChart').removeClass('active');
					$('#'+reportName+'tabularChart').removeClass('active');
					//$('#barChart1').removeClass('active');
					//$('#tabularData1').removeClass('active');
			  });
				  
			  $('#'+reportName+'barChart').on('click', function(){
					/*$('#pieChart1').removeClass('active');
					$('#tabularData1').removeClass('active');
					$(this).addClass('active');*/
				  	$(this).addClass('active');
				  	$('#'+reportName+'lineChart').removeClass('active');
				  	$('#'+reportName+'tabularChart').removeClass('active');
				  	$('#'+reportName+'pieChart').removeClass('active');
			  });
			  
			  $('#'+reportName+'tabularData').on('click', function(){
					/*$('#pieChart1').removeClass('active');
					$('#barChart1').removeClass('active');
					$(this).addClass('active');*/
				  	$(this).addClass('active');
				  	$('#'+reportName+'pieChart').removeClass('active');
				  	$('#'+reportName+'barChart').removeClass('active');
				  	$('#'+reportName+'lineChart').removeClass('active');
			  });
		  };
			  /*$('#pieChart2').on('click', function(){
					$(this).addClass('active');
					$('#barChart2').removeClass('active');
					$('#tabularData2').removeClass('active');
			  });
			  
			  $('#barChart2').on('click', function(){
					$('#pieChart2').removeClass('active');
					$('#tabularData2').removeClass('active');
					$(this).addClass('active');
			  });
			  
			  $('#tabularData2').on('click', function(){
					$('#pieChart2').removeClass('active');
					$('#barChart2').removeClass('active');
					$(this).addClass('active');
			  });
	
			  $('#pieChart3').on('click', function(){
					$(this).addClass('active');
					$('#barChart3').removeClass('active');
					$('#tabularData3').removeClass('active');
			  });
			  
			  $('#barChart3').on('click', function(){
					$('#pieChart3').removeClass('active');
					$('#tabularData3').removeClass('active');
					$(this).addClass('active');
			  });
			  
			  $('#tabularData3').on('click', function(){
					$('#pieChart3').removeClass('active');
					$('#barChart3').removeClass('active');
					$(this).addClass('active');
			  });
			  
			  $('#pieChart4').on('click', function(){
					$(this).addClass('active');
					$('#barChart4').removeClass('active');
					$('#tabularData4').removeClass('active');
			  });
			  
			  $('#barChart4').on('click', function(){
					$('#pieChart4').removeClass('active');
					$('#tabularData4').removeClass('active');
					$(this).addClass('active');
			  });
			  
			  $('#tabularData4').on('click', function(){
					$('#pieChart4').removeClass('active');
					$('#barChart4').removeClass('active');
					$(this).addClass('active');
			  });*/

	      
});

/*
 * Report Configuration util functions
 */

var parseAmountToFloat = function(value) {
	var result = 0.00;
	var convertedValue = parseFloat(value);
	if(convertedValue != 'NaN') {
		result = (convertedValue.toFixed(2))/1;
	} 
	return result;
};

var getReportConfiguration = function(_reportName, filter) {
	var reportFilter = hcentive.WFM.reportConfiguration[_reportName]
	if(reportFilter == null || reportFilter == '' || reportFilter == {} || reportFilter == undefined) {
		return null;
	} else {
		var currentDate = new Date();
		angular.forEach(reportFilter, function(value, key){
			if(value != null && value != '' && value != undefined) {
				if(value == 'YEAR_TO_DATE') {
					reportFilter[key] = getYearStartDate(currentDate);
				} else if(value == 'MONTH_TO_DATE') {
					reportFilter[key] = getMonthStartDate(currentDate);
				} else if(value == 'CURRENT_DATE') {
					reportFilter[key] = getCurrentDate(currentDate, filter);
				}else if(value=='MONTH_END_DATE'){
					reportFilter[key] = getMonthEndDate(currentDate, filter);
				}
			}
		 });
	}
 return reportFilter;
};

var getYearStartDate = function(currentDate) {
	return '01/01/' + currentDate.getFullYear();
};

var getMonthStartDate = function(currentDate) {
	var month = (currentDate.getMonth()+1);
	if(month < 10) {
		month = '0' + month; 
	}
	return month + '/01/' + currentDate.getFullYear();
};

var getMonthEndDate = function(currentDate) {
	 var y = currentDate.getFullYear();
	 var m = currentDate.getMonth();
	 var endDate=new Date(y, m + 1, 0);
	 var day=endDate.getDate();
	var month = (endDate.getMonth()+1);
	if(month < 10) {
		month = '0' + month; 
	}
	if(day<10){
		day='0'+day;
	}
	return month + '/'+day+'/' + endDate.getFullYear();
};

var getCurrentDate = function(currentDate, filter) {
	return filter('date')(currentDate, hcentive.WFM.clientConfigurations[0].dateFormat.format);
};

	
hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "ReportBaseCtrl",
	"id" : hcentive.WFM.ReportBaseCtrl
});

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "ReportBaseCtrl",
	"id" : hcentive.WFM.ReportBaseCtrl
});

hcentive.WFM.configData[hcentive.WFM.broker].controllers.push({
	"name" : "ReportBaseCtrl",
	"id" : hcentive.WFM.ReportBaseCtrl
});