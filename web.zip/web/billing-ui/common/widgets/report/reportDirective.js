// Main report directive
hcentive.WFM.ReportDir = [function($sce) {
	
	return {
 		restrict : 'E',
 		templateUrl : function(elem,attr){return getTemplateUrl(attr, "../common/widgets/report/report.html")},
 		link : function(scope, iElement, iAttrs, ctrl) {
 			scope.init(iAttrs);
 			scope.getReportContent(iAttrs.report, iAttrs.format);
 			scope.applyUpdateExportFunctions();
 		}
 	};
}];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "reportdir",
	"id" : hcentive.WFM.ReportDir
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "reportdir",
	"id" : hcentive.WFM.ReportDir
});

hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "reportdir",
	"id" : hcentive.WFM.ReportDir
});


// filter directive
hcentive.WFM.ReportFilterDir = [function() {
	
	return {
 		restrict : 'E',
 		replace: true,
 		template: '<div ng-include src="filterTemplate"></div>',
 		link : function(scope, iElement, iAttrs, ctrl) {
 		}
 	};
}];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "reportfilterdir",
	"id" : hcentive.WFM.ReportFilterDir
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "reportfilterdir",
	"id" : hcentive.WFM.ReportFilterDir
});

hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "reportfilterdir",
	"id" : hcentive.WFM.ReportFilterDir
});


//filter directive
hcentive.WFM.ReportTopFilterDir = [function() {
	
	return {
 		restrict : 'E',
 		replace: true,
 		template: '<div ng-include src="topFilterTemplate"></div>',
 		link : function(scope, iElement, iAttrs, ctrl) {
 		}
 	};
}];

//wireup the directive to application
hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "reporttopfilterdir",
	"id" : hcentive.WFM.ReportTopFilterDir
});

hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "reporttopfilterdir",
	"id" : hcentive.WFM.ReportTopFilterDir
});

hcentive.WFM.configData[hcentive.WFM.broker].directives.push({
	"name" : "reporttopfilterdir",
	"id" : hcentive.WFM.ReportTopFilterDir
});
