hcentive.WFM.BannerDir = [function() {
	return {
		restrict : 'A',
		 templateUrl: function(elem,attr){return getTemplateUrl(attr,"../common/widgets/banner/currentBillBanner.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.customer].directives.push({
	"name" : "banner",
	"id" : hcentive.WFM.BannerDir
});

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.operator].directives.push({
	"name" : "banner",
	"id" : hcentive.WFM.BannerDir
});