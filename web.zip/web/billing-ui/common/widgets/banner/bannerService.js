hcentive.WFM.BannerSrvc = ['$http', 'RESTSrvc',function($http, RESTSrvc) {
	var getCurrentInvoicesSummary = function(params,data, successCallback, errorCallback) {
		var currentInvoiceSummary = RESTSrvc.postForData('fetchCurrentInvoicesSummary',params,data,null,successCallback,errorCallback);
	};
	
	return {
		getCurrentInvoicesSummary : getCurrentInvoicesSummary 
	};
}];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.customer].services.push({
	"name" : "BannerSrvc",
	"id" : hcentive.WFM.BannerSrvc
});

hcentive.WFM.configData[hcentive.WFM.operator].services.push({
	"name" : "BannerSrvc",
	"id" : hcentive.WFM.BannerSrvc
});