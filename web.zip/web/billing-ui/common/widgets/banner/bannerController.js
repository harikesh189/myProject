// Current Bill Banner control
hcentive.WFM.CurrentBillCtrl = [
		'$scope',
		'BannerSrvc',
		'EventBusSrvc','$interval','$filter',
		function($scope, BannerSrvc, EventBusSrvc, $interval,$filter) {

			var customerIdJson = {};
			var contractId ='';
			$scope.hasCurrentInvoice = false;
			var currentBillBannerSuccessCallback = function(data) {
				$scope.banner = {"totalOutstanding" : "$0.00","inSuspense" :"$0.00" ,"dueIn" : "--" ,"status" : "--"};
				if(data != undefined && data != ''){
					if(data.content != undefined && data.content[0] != undefined && data.content[0].invoice != undefined){
					var invoiceSummary = data.content[0];
					var payableAmount = invoiceSummary.invoice.payableAmount.value;
					var amountPaid = invoiceSummary.amountPaid.value;
					var discount =invoiceSummary.discount.value;
					var dueDate = invoiceSummary.invoice.dueDate.date;
					var status = invoiceSummary.invoice.status;
					var totalOutstanding = 0;
					
					var invoiceId = invoiceSummary.invoice.identity;
					var invoiceItemRecordId = invoiceSummary.invoice.itemRecordId;
					EventBusSrvc.publish('currentInvoiceIdentity', invoiceId);
					EventBusSrvc.publish('currentInvoiceItemRecord', invoiceItemRecordId);
					$scope.hasCurrentInvoice = true;
					if(payableAmount != undefined){
						payableAmount = parseFloat(payableAmount);
						totalOutstanding = payableAmount;
						if(amountPaid != undefined){
							amountPaid = parseFloat(amountPaid);
						}
						
						if( !isNaN(payableAmount) &&  !isNaN(amountPaid) ){
							totalOutstanding  = payableAmount - amountPaid-discount;
						}
					}
					
					if(totalOutstanding > 0){
						$scope.banner.totalOutstanding = $filter('currency')(totalOutstanding);
						$scope.banner.inSuspense = $filter('currency')(0); ;
					
						var currentDate =  new Date().getTime();
					 
						var diff = Math.floor(dueDate- currentDate);
						var day = 1000* 60 * 60 * 24;
						var days = Math.ceil(diff/day);
						
						if(days > 0){
							$scope.banner.dueIn = days +" days";
						}else if(days == 0){
							$scope.banner.dueIn = "Immediate";
						}else{
							$scope.banner.dueIn = "Overdue";
						}
					}else{
						$scope.banner.totalOutstanding = $filter('currency')(0);
						$scope.banner.inSuspense = $filter('currency')(Math.abs(totalOutstanding));
						$scope.banner.dueIn = "--";
					}
					
					if(status == "SETTLED"){
						$scope.banner.status = "Paid";
					}else{
						$scope.banner.status = "Unpaid";
					}
					}
					else{
						$scope.hasCurrentInvoice = false;
					}
				
				}
				else{
					$scope.hasCurrentInvoice = false;
				}
				if ($scope.banner.totalOutstanding != null
						|| $scope.banner.totalOutstanding != undefined) {
					/*EventBusSrvc.publish('paymentAmount',
							$scope.banner.totalOutstanding);*/
					EventBusSrvc.publish('totalOutStdng',
							$scope.banner.totalOutstanding);
							
				}
			};

			var errorCallBack = function() {
				$scope.banner = '';
				/*EventBusSrvc.publish('paymentAmount', '0.00');*/
				EventBusSrvc.publish('totalOutStdng', '0.00');
			};

			$scope.getCurrentBillBanner = function(customerIdJson,contractId) {
				console.log("calling banner service:: "
						+ angular.toJson(customerIdJson));

				
				if($scope.$parent.wfmAppContext.contextualContract !=null && $scope.$parent.wfmAppContext.contextualContract != undefined && $scope.$parent.wfmAppContext.contextualContract.contractId != null && $scope.$parent.wfmAppContext.contextualContract.contractId != undefined && contractId == ''){
					contractId  = $scope.$parent.wfmAppContext.contextualContract.contractId;
				}

				var inputJson = customerIdJson;
				var data = {"criteria" : {},
						  "pageRequestCriteria" : {},
						  "referenceId" : contractId
						};
			
			BannerSrvc.getCurrentInvoicesSummary(inputJson,data,currentBillBannerSuccessCallback,
						errorCallBack);				
						
			};

			$scope
					.safeApply(
							$scope,
							function() {
								customerIdJson['customerId'] = $scope.$parent.wfmAppContext.contextualContract.beId;
								console.log("calling banner :: "
										+ angular.toJson(customerIdJson));
								if($scope.$parent.wfmAppContext.contextualContract.beId != undefined)
									$scope.getCurrentBillBanner(customerIdJson,'');
							});

			var paymentMadeCallback = function(newVal, oldVal) {
				if (null != newVal) {
					//hackish...
					$interval(function() {
						$scope.safeApply($scope, function() {
							$scope.getCurrentBillBanner(customerIdJson,contractId);
						});
					}, 5000, 3);
				}
			};

			EventBusSrvc.subscribe('paymentMade', $scope, paymentMadeCallback);
			
			var contractUpdatedCallBack = function(newVal, oldVal) {
				if (null != newVal) {
						$scope.safeApply($scope, function() {
							contractId = newVal.contractId;
							customerIdJson['customerId'] = newVal.beId;
							$scope.getCurrentBillBanner(customerIdJson,newVal.contractId);
						});
					}
			};

			EventBusSrvc.subscribe('contractUpdated', $scope, contractUpdatedCallBack);
			
			
			
			
		} ];

hcentive.WFM.configData[hcentive.WFM.operator].controllers.push({
	"name" : "CurrentBillCtrl",
	"id" : hcentive.WFM.CurrentBillCtrl
});

hcentive.WFM.configData[hcentive.WFM.customer].controllers.push({
	"name" : "CurrentBillCtrl",
	"id" : hcentive.WFM.CurrentBillCtrl
});