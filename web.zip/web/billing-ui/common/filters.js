hcentive.WFM.WFMLink = function() {
	// filters return a function
	return function(item, arg) {
		var currentLocation = location.href;
		if (currentLocation[currentLocation.length - 1] !== "/")
			currentLocation += "/";
		// a very simple appending of the current item's name
		if (item)
			return currentLocation + item[arg];
		else
			return currentLocation + "add";
	};
};
hcentive.DescriptiveName = function() {
	return function(item) {
		var out = item.id;
		if (item.name)
			out = item.name;
		else if (item.sku)
			out = item.sku;
		else if (item.slug)
			out = item.slug;
		else if (item.title)
			out = item.title;
		else if (item.email)
			out = item.email;
		return out;
	};
};

hcentive.InitCap = function() {
	return function(input) {
		return input.substring(0,1).toUpperCase()+input.substring(1).toLowerCase();
	};
};

hcentive.ContactNumber = function() {
	return function(input) {
		return "("+input.substring(0,3)+") "+input.substring(3,3)+"-"+input.substring(6);
	};
};

hcentive.customCurrency = ["$filter", function ($filter) {       
    return function(amount, currencySymbol){
        var currency = $filter('currency');         
        if(amount < 0){
            return currency(amount, currencySymbol).replace("(", "-").replace(")", ""); 
        }

        return currency(amount, currencySymbol);
    };
}];