var getTemplateUrl = function (attr, defaultTemplateUrl) {
    if (attr.templateurl === undefined || attr.templateurl.length == 0) {
        return defaultTemplateUrl;
    }
    return attr.templateurl;
}

// calendar
hcentive.WFM.CalendarDir =  ['$filter', function ($filter) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
        	var maxDate = null;
        	var minDate = null;
        	var hideInfoPreviousNext = false;
             if(attrs.hideinfopreviousnext != undefined && attrs.hideinfopreviousnext != null){
                     hideInfoPreviousNext = true;
             }
             
            var changeMonth = true;
            if(attrs.changemonth != undefined && attrs.changemonth != null){
            	changeMonth = false;
            }
            
            var changeYear = true;
            if(attrs.changeyear != undefined && attrs.changeyear != null){
            	changeYear = false;
            }

    		if(attrs.maxdate != undefined && attrs.maxdate != null){
    			var date = new Date(attrs.maxdate);
    			if(angular.isDate(date)){
    				maxDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), 0, 0, 0);
    			}
    		}
      		if(attrs.mindate != undefined && attrs.mindate != null){
    			var date = new Date(attrs.mindate);
    			if(angular.isDate(date)){
    				minDate = date;
    			}
    		}
      		
      		/*if( attrs.prepopulate == undefined){
      			if(scope[attrs.ngModel] == undefined || scope[attrs.ngModel] == ''){
        			scope[attrs.ngModel] =$filter('date')(new Date(),scope.clientDateFormat);
        			var elementId= $(element).attr('id');
                    $("#" +elementId).trigger('change');
        		}
      		}*/  // Commented as it is impacting filters
    		
    		
            element.datepicker({
                dateFormat: 'mm/dd/yy',
                changeMonth: changeMonth,
                changeYear: changeYear,
                yearRange: '1900:2999',
                showOn: "both",
                buttonImageOnly: true,
                buttonImage: "images/calender.png",
                minDate : minDate,
                maxDate:  maxDate,
                hideIfNoPrevNext: hideInfoPreviousNext,
                onSelect: function (date) {
                    scope[attrs.ngModel] = date;
                    // when date is selected from calender. it is not a change event for input element.
                    // So explicitily change event has to be performed on input element.
                    var elementId= $(element).attr('id');
                    $("#" +elementId).trigger('change');
                    scope.$apply();
                }
            });
        }
    };
} ];

// cancel button
hcentive.WFM.CancelButtonDir = [ function () {
    var templateHTML = '<a href="{{url}}" class="btn btn-secondary ">Cancel </a>';
    return {
        restrict: 'EA',
        scope: {
            url: '@'
        },
        template: templateHTML

    };
} ];

// Next button
hcentive.WFM.NextButtonDir = [ function () {
    var templateHTML = '<a href="{{url}}" class="btn btn-primary ">Next </a>';

    return {
        restrict: 'EA',
        scope: {
            url: '@'
        },
        template: templateHTML
    };
} ];

// error aware
hcentive.WFM.ErrorAwareDir = ['$compile', '$log', function ($compile, $log) {

    var errorHTML = '<div class="error">{{message}}</div>';

    return {
        restrict: 'E',
        link: function (scope, element, attrs) {
            attrs.$observe('message', function (val) {
                scope.message = attrs.message;
                var errorElem = angular.element(errorHTML);
                if (angular.isDefined(attrs.message) && attrs.message.length > 0) {
                    $compile(errorElem)(scope);
                    element.html(errorElem);
                } else {
                    errorElem.remove();
                }
            });
        }
    };
} ]
;