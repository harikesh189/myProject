//controllers available on bootstrap
hcentive.WFM.MainCtrl = [
    '$scope',
    '$routeParams',
    '$http',
    'EventBusSrvc', '$location', 'WFMAppContext', 'NotifySrvc', '$filter',
    function ($scope, $routeParams, $http, EventBusSrvc, $location, WFMAppContext, NotifySrvc, $filter) {

        //set up $http with security headers
        var enrichHeaders = function () {
            angular.forEach(WFMAppContext.headers, function (value, key) {
                //set application wide security headers
                if (key != 'validTill' && key != 'nonce' && key != 'passKey' && key != 'identity') {
                    $http.defaults.headers.common[key] = value;
                }
            });
        };
        enrichHeaders();
        $location.url($location.path());
        // application context set and available to application
        $scope.wfmAppContext = WFMAppContext;

        // Variables for Left Navigation Menus
        $scope.selectedLeftNav = "";
        $scope.leftNavList = null;
        $scope.loggedInUser = {};
        $scope.logoutUrl = hcentive.WFM.serviceURL.logoutServiceUrl;
        $scope.userWidgets = '';
        $scope.$on("$routeChangeSuccess", function () {
            //global variables
			$http.defaults.headers.common['App-Requested-With'] = true;
            $scope.breadCrumb = $routeParams.breadCrumb;
            if (($scope.selectedModule != $routeParams.selectedModule) || ($scope.selectedSubModule != $routeParams.selectedSubModule)) {
                $scope.selectedModule = $routeParams.selectedModule;
                $scope.selectedSubModule = $routeParams.selectedSubModule;
                // create left nav for first call or on refresh
                $scope.generateLeftNav($scope.selectedModule);
                $scope.generateLeftNavForNonModule($scope.selectedModule);
            }
        });

        var cofigMap = {};
        $scope.getConfigurationByKey = function (key) {
            return cofigMap[key];
        }

        if ($scope.userWidgets == '') {
            var userWidgets = [];
            var permissionArray = [];
            //Storing all the permissions assigned to the logged in user.
            var userRoles = WFMAppContext.loggedInUser.roles;
            angular.forEach(userRoles, function (roleValue, roleKey) {
                var userPermissions = roleValue.permissions;
                angular.forEach(userPermissions, function (permissionValue, permissionKey) {
                    permissionArray.push(permissionValue.operationCode);
                });
            });

            var configuration = WFMAppContext.configuration;
            angular.forEach(configuration, function (configValue, configKey) {
                var widgetKey = configValue.key;
                var value = configValue.value;
                cofigMap[widgetKey] = value;
                if (value != undefined && value != '' && value != 'NA') {
                    var jsonValue = undefined;
                    try {
					if(!angular.isObject(value)){
                        jsonValue = JSON.parse(value);
                        jsonValue = JSON.parse(jsonValue);
						}else{
						jsonValue = value;
						}
                    }
                    catch (e) {
                    }

                    if (jsonValue != undefined) {
                        var permissions = jsonValue.permissions;
                        if (permissions != undefined) {
                            angular.forEach(permissions, function (permissionValue, permissionKey) {
                                if (permissionArray.indexOf(permissionValue) > -1) {
                                    userWidgets.push(widgetKey);
                                }
                            });
                        }
                    }
                } else if (value == 'NA') {
                    userWidgets.push(widgetKey);
                }
            });

            if (userWidgets != []) {
                $scope.userWidgets = userWidgets;
                //alert(angular.toJson($scope.userWidgets));
            }

        }

        $scope.isRenderable = function (widgetKey) {
            var userWidgets = $scope.userWidgets;

            //To be uncommented
			
			 if(angular.isUndefined(widgetKey)){
            	return true;
            	
            }

            if (userWidgets == '' || userWidgets == undefined) {
                return false;
            } else {
                if (userWidgets.indexOf(widgetKey) > -1) {
                    return true;
                } else {
                    return false;
                }
            }
            //return true;
            return false; // To do :  be changed to false  
        };

        $scope.beType = function () {
            // check if null then return loggedInUser.manBeType[0].lower
            var beType = hcentive.WFM.beTypes[$scope.wfmAppContext.beType];
            if (beType == null || beType == undefined || beType == '') {
                if (WFMAppContext.loggedInUser != undefined && WFMAppContext.loggedInUser.managesBEofTypes != undefined && WFMAppContext.loggedInUser.managesBEofTypes.length > 0) {
                    return WFMAppContext.loggedInUser.managesBEofTypes[0].toLowerCase();
                }
            }
            return beType;
        };

        $scope.isAdminBeType = function () {
            var beType = $scope.beType();

            if (angular.equals(beType, hcentive.WFM.beTypes["3"]) ||
                angular.equals(beType, hcentive.WFM.beTypes["5"])) {
                return true;
            } else {
                return false;
            }
        };

        $scope.isIndividualBeType = function () {
            var beType = $scope.beType();

            if (angular.equals(beType, hcentive.WFM.beTypes["1"])) {
                return true;
            } else {
                return false;
            }
        };

        $scope.isGroupBeType = function () {
            var beType = $scope.beType();

            if (angular.equals(beType, hcentive.WFM.beTypes["2"])) {
                return true;
            } else {
                return false;
            }
        };

        $scope.isCSRBeType = function () {
            var beType = $scope.beType();

            if (angular.equals(beType, hcentive.WFM.beTypes["5"])) {

                for (var i = 0; i < WFMAppContext.loggedInUser.roles.length; i++) {
                    if (WFMAppContext.loggedInUser.roles[i].name == "CSR") {
                        $scope.csrBE = true;
                        return true;
                    }
                }
                return false;
            } else {
                return false;
            }
        };

        $scope.isBrokerBeType = function () {
            var beType = $scope.beType();

            if (angular.equals(beType, hcentive.WFM.beTypes["4"])) {
                return true;
            } else {
                return false;
            }
        };

        $scope.isOperatorBeType = function () {
            var beType = $scope.beType();

            if (angular.equals(beType, hcentive.WFM.beTypes["5"])) {
                for (var i = 0; i < WFMAppContext.loggedInUser.roles.length; i++) {
                    if (WFMAppContext.loggedInUser.roles[i].name == "Operator") {
                        $scope.oprBE = true;
                        return true;
                    }
                }
                return false;
            } else {
                return false;
            }
        };

        $scope.generateLeftNav = function (selectedModule) {
            angular.forEach($scope.headerList, function (header, key) {
                if (header.mainMenu == selectedModule) {
                    var keepGoing = true;
                    if (header.leftNav !== undefined) {
                        $scope.leftNavList = header.leftNav;
                        angular.forEach(header.leftNav, function (leftNav) {
                            if (keepGoing) {
                                if ($location.path() == leftNav.labelPath) {
                                    $scope.selectedLeftNav = leftNav.labelDescription;
                                    keepGoing = false;
                                }
                            }
                        });
                    } else {
                        $scope.leftNavList = null;
                    }
                }
            });
        };

        $scope.generateLeftNavForNonModule = function (selectedNonModule) {
            var selectedNonModuleRes = hcentive.WFM.clientConfigurations[0][selectedNonModule];
            if (selectedNonModuleRes != null && selectedNonModuleRes.leftNav != null && selectedNonModuleRes.leftNav != undefined &&
                selectedNonModuleRes.leftNav[0] != null && selectedNonModuleRes.leftNav[0] != undefined) {
                $scope.selectedLeftNav = selectedNonModuleRes.leftNav[0].labelDescription;
                $scope.leftNavList = selectedNonModuleRes.leftNav;
            }
        };

        $scope.updateLeftNav = function (selectedLeftNav) {
            $scope.selectedLeftNav = selectedLeftNav;
        };
        
        $scope.updateLeftNavForTopMenu = function (menu) {
        	if(menu != null && menu != undefined && menu.leftNav[0] != null &&  menu.leftNav[0] != undefined){       	
        		$scope.selectedLeftNav = menu.leftNav[0].labelDescription;
        	}
        };

        $scope.getRenderableMenuList = function (menuList) {
            var clientId = hcentive.WFM.client_id;
            if (clientId == undefined || clientId == null) {
                return menuList;
            }
            //angular.forEach(menuList,function(value, key) {
            for (var key = menuList.length - 1; key >= 0; key--) {
                var value = menuList[key];
                if (clientId == 'Customer') {
                    if (value.subMenu != undefined) {
                        //angular.forEach(value.subMenu , function(subMenuValue , subMenuKey){
                        for (var subMenuKey = menuList[key].subMenu.length - 1; subMenuKey >= 0; subMenuKey--) {
                            var subMenuValue = menuList[key].subMenu[subMenuKey];
                            if (subMenuValue.permissionKey != undefined) {
                                var isRenderable = $scope.isRenderable(subMenuValue.permissionKey);
                                if (isRenderable == false) {
                                    menuList[key].subMenu.splice(subMenuKey, 1);
                                }
                            }
                        }
                        if (value.subMenu.length == 0) {
                            delete menuList.splice(key, 1);
                        }
                    }
                    else {
                        if (value.permissionKey != undefined) {
                            var isRenderable = $scope.isRenderable(value.permissionKey);
                            if (isRenderable == false) {
                                delete menuList.splice(key, 1);
                            }
                        }
                    }
                }
                else if (clientId == 'Operator' || clientId == 'Broker') {
                    if (value.leftNav != undefined) {
                        for (var subMenuKey = menuList[key].leftNav.length - 1; subMenuKey >= 0; subMenuKey--) {
                            var subMenuValue = menuList[key].leftNav[subMenuKey];
                            if (subMenuValue.permissionKey != undefined) {
                                var isRenderable = $scope.isRenderable(subMenuValue.permissionKey);
                                if (isRenderable == false) {
                                    menuList[key].leftNav.splice(subMenuKey, 1);
                                }
                            }
                        }
                        if (value.leftNav.length == 0) {
                            delete menuList.splice(key, 1);
                        }
                    }
                    else {
                        if (value.permissionKey != undefined) {
                            var isRenderable = $scope.isRenderable(value.permissionKey);
                            if (isRenderable == false) {
                                delete menuList.splice(key, 1);
                            }
                        }
                    }
                }
            }
            return menuList;
        }
        $scope.updateHeaderList = function () {
            $scope.safeApply($scope, function () {
                var menuList = hcentive.WFM.clientConfigurations[0].topNav.menus;
                $scope.headerList = $scope.getRenderableMenuList(menuList);
            });
        };
        $scope.clientCurrencyFormat = hcentive.WFM.clientConfigurations[0].currencyFormat.format
        $scope.clientDateFormat = hcentive.WFM.clientConfigurations[0].dateFormat.format;
        $scope.ddMONyyyyDateFormat = hcentive.WFM.clientConfigurations[0].ddMonthyyyydateFormat.format;
        $scope.clientnumberRoundOffFormat = hcentive.WFM.clientConfigurations[0].numberRoundOffFormat.format;
        $scope.clientdateTimeFormat = hcentive.WFM.clientConfigurations[0].dateTimeFormat.format;
        $scope.beTimeFormat = hcentive.WFM.clientConfigurations[0].beTimeFormat.format;


        $scope.toUTCDate = function (date) {
        	if(date == undefined || date === '' || date === null ){
        		return;
        	}
            var now = new Date(date);
            var now_utc = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
            var utcDate = $filter('date')(now_utc, $scope.clientDateFormat);
            return utcDate;
        }
        //  $scope.headerList = hcentive.WFM.clientConfigurations[0].topNav.menus;

        // registering client events
        angular.forEach(hcentive.WFM.clientConfigurations[0].interestingEvents, function (event) {
            EventBusSrvc.register($scope, event);
        });

        //when you add it to the $rootScope variable, then it's accessible to all other $scope variables.
        $scope.safeApply = function ($scope, fn) {
            fn = fn || function () {
            };
            if ($scope.$$phase) {
                //don't worry, the value gets set and AngularJS picks up on it...
                fn();
            }
            else {
                //this will fire to tell angularjs to notice that a change has happened
                //if it is outside of it's own behaviour...
                $scope.$apply(fn);
            }
        };

        //Added success/error dialog
        $scope.succErrDialog = function (title, msg) {
            NotifySrvc({
                id: 'simpleDialog',
                template: '<div class="row-fluid">' + ' <p>' + msg
                    + '</p>' + '</div>',
                title: title,
                backdrop: true,
                success: {
                    label: 'Ok',
                    fn: function () {
                    }
                },

            });
        };

        $scope.downloadXML = function(data,fileName){
        	if (navigator.msSaveBlob) { // IE 10+ 
        		navigator.msSaveBlob(new Blob([data], { type: 'text/xml;charset=utf-8;' }), fileName); 
        	} else {
	    	   //Initialize file format you want csv or xls
	        	var escapedData = escape(data);
			    var uri = 'data:text/xml;charset=utf-8,' + escapedData;
			    
			    // Now the little tricky part.
			    // you can use either>> window.open(uri);
			    // but this will not work in some browsers
			    // or you will not get the correct file extension    
			    
			    //this trick will generate a temp <a /> tag
			    var link = document.createElement("a");    
			    link.href = uri;
			    
			    //set the visibility hidden so it will not effect on your web-layout
			    link.style = "visibility:hidden";
			    link.download =  fileName + ".xml";
			    
			    //this part will append the anchor tag and remove it after automatic click
			    document.body.appendChild(link);
			    link.click();
			    document.body.removeChild(link);
        	}
        }
		
		$scope.encrypt = function(value) {
        	var aesUtil = new AesUtil(128, 10);
        	var sip = {};
            sip.iv = $scope.wfmAppContext.headers['securityKey'].replace(/-/g, '');
            sip.passPhrase = sip.iv.repeat(2);
            sip.salt = sip.iv.repeat(3);
           	return value ? aesUtil.encrypt(sip.salt, sip.iv, sip.passPhrase, value) : value;
        }
        
        $scope.decrypt = function(value) {
        	var aesUtil = new AesUtil(128, 10);
        	var sip = {};
            sip.iv = $scope.wfmAppContext.headers['securityKey'].replace(/-/g, '');
            sip.passPhrase = sip.iv.repeat(2);
            sip.salt = sip.iv.repeat(3);
           	return value ? aesUtil.decrypt(sip.salt, sip.iv, sip.passPhrase, value) : value;
        }
        
        $scope.responseType = "token";
    } ];