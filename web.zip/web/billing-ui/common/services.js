var previousUniqueNumber = 0;
function lastNonce() {
    var date = Date.now();
   
    // If created at same millisecond as previous
    if (date <= previousUniqueNumber) {
        date = ++previousUniqueNumber;
    } else {
        previousUniqueNumber = date;
    }

    return date;
}
//services available on bootstrap
var genereateRequestConfig = function(_resourceKey, _params) {
	var paramsJson = {};
	var url = hcentive.WFM.serviceURL[_resourceKey];
	angular.forEach(_params, function(value, key) {
		if (url.search(":" + key) != -1) {
			url = url.replace(":" + key, value);
		} else {
			paramsJson[key] = value;
		}
	});
	var returnJson = {
		"url" : url,
		"paramsJson" : paramsJson
	};
	return returnJson;
};

var addTenantAndApp = function(_url,_tenant,_appKey){
	_url = _url.replace(":tenantId",_tenant);
	_url = _url + "?client_Id="+_appKey;
	return _url;
}
var sessionTimedOut = false;


hcentive.WFM.RESTSrvc = [
		'$http', 'NotifySrvc', '$window',
		function($http, NotifySrvc, $window) {	
			
			var postForFile = function(_resourceKey, _params, files,_success, _error){
				
				 var fd = new FormData();
		            //Take the first selected file
		            fd.append("file", files[0]);
		            var currentTime = lastNonce();
					var message = hcentive.WFM.applicationContext.headers['securityKey'] + currentTime;

					

					//enriched with 'nonce' headers
					$http.defaults.headers.common['nonce'] = currentTime;
					delete $http.defaults.headers.common['checksum'];
					$http.defaults.headers.common['securityKey'] = CryptoJS.MD5(message);
					$http.defaults.headers.common['Authorization'] = "BASIC "+hcentive.WFM.applicationContext.headers['identity'];
					var requestConfig = genereateRequestConfig(_resourceKey,
							_params);
					
				 $http.post(requestConfig.url, fd, {
		                withCredentials: true,
		                headers: {'Content-Type': undefined },
		                transformRequest: angular.identity
		            }).
		            success( function(data) {
		            	_success(data);
					}).
		            error( function(data) {
		            	_error(data);
		            } );
			}
			
			var getForData = function(_resourceKey, _params, transformer,
					_success, _error, _retryCount) {
				
				if(_retryCount == null || _retryCount == undefined){
					_retryCount = 0;
				} else {
					++_retryCount;
				}
			
				sessionTimedOut = false;		
				var currentTime = lastNonce();
				var message = hcentive.WFM.applicationContext.headers['securityKey'] + currentTime;

				
			//var checksum = CryptoJS.SHA256(null).toString(CryptoJS.enc.Base64);	
			//enriched with 'nonce' headers
			//$http.defaults.headers.common['checksum'] = checksum;
			$http.defaults.headers.common['nonce'] = currentTime;
			$http.defaults.headers.common['securityKey'] = CryptoJS.MD5(message);
			$http.defaults.headers.common['Authorization'] = "BASIC "+hcentive.WFM.applicationContext.headers['identity']
				var requestConfig = genereateRequestConfig(_resourceKey,
						_params);
				$http({
					method : 'GET',
					url : requestConfig.url,
					withCredentials: true,
					params : requestConfig.paramsJson
				}).success(function(data) {
					if (transformer != undefined)
						_success(transformer(data));
					else
						_success(data);
				}).error(function(data) {
					if(data.message=="Invalid nonce" && _retryCount<=hcentive.WFM.retryCount)
						getForData(_resourceKey, _params, transformer,_success, _error,_retryCount);
					else
						_error(data);	
				});
			};

			var postForData = function(_resourceKey, _params, _data,
					transformer, _success, _error,_contentType,_retryCount) {
				
				
				if(_retryCount == null || _retryCount == undefined){
					_retryCount = 0;
				} else {
					++_retryCount;
				}
				
				sessionTimedOut = false;
				var currentTime = lastNonce();
				var message = hcentive.WFM.applicationContext.headers['securityKey'] + currentTime;


				var checksum = null;
				/*if( _data && (typeof _data === 'string' || _data instanceof String)){
					checksum = CryptoJS.SHA256(_data.toString()).toString(CryptoJS.enc.Base64);
	        		$http.defaults.headers.common['checksum'] = checksum;
				}
				else if(_data && (Object.keys(_data).length>0)){
	        		checksum = CryptoJS.SHA256(JSON.stringify(_data)).toString(CryptoJS.enc.Base64);
	        		$http.defaults.headers.common['checksum'] = checksum;
	        	}else{
	        		delete $http.defaults.headers.common['checksum'] ;
	        	}*/

				//enriched with 'nonce' headers
				$http.defaults.headers.common['nonce'] = currentTime;
				if(checksum!=null){
					$http.defaults.headers.common['securityKey'] = CryptoJS.MD5(message+checksum);
				}else{
					$http.defaults.headers.common['securityKey'] = CryptoJS.MD5(message);
				}
				if(_contentType != null && _contentType != undefined && _contentType != ''){
					$http.defaults.headers.post['Content-Type'] = _contentType;
				}else{
					$http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
					}
				var requestConfig = genereateRequestConfig(_resourceKey,
						_params);
				$http({
					method : 'POST',
					url : requestConfig.url,
					withCredentials: true,
					params : requestConfig.paramsJson,
					data : _data
				}).success(function(data) {
					if (transformer != undefined)
						_success(transformer(data));
					else
						_success(data);
				}).error(function(data) {
					if(data.message=="Invalid nonce" && _retryCount<=hcentive.WFM.retryCount)
						postForData(_resourceKey, _params, _data,transformer, _success, _error,_contentType,_retryCount);
					else
						_error(data);		
				});

			};
			
			var postForDataReturnsPromise = function(_resourceKey, _params, _data,
					transformer, _contentType){
					
					sessionTimedOut = false;
					var currentTime = lastNonce();
				var message = hcentive.WFM.applicationContext.headers['securityKey'] + currentTime;


				var checksum = null;
				/*if( _data && (typeof _data === 'string' || _data instanceof String)){
					checksum = CryptoJS.SHA256(_data.toString()).toString(CryptoJS.enc.Base64);
	        		$http.defaults.headers.common['checksum'] = checksum;
				}
				else if(_data && (Object.keys(_data).length>0)){
	        		checksum = CryptoJS.SHA256(JSON.stringify(_data)).toString(CryptoJS.enc.Base64);
	        		$http.defaults.headers.common['checksum'] = checksum;
	        	}else{
	        		delete $http.defaults.headers.common['checksum'] ;
	        	}*/

				//enriched with 'nonce' headers
				$http.defaults.headers.common['nonce'] = currentTime;
				if(checksum!=null){
					$http.defaults.headers.common['securityKey'] = CryptoJS.MD5(message+checksum);
				}else{
					$http.defaults.headers.common['securityKey'] = CryptoJS.MD5(message);
				}
				if(_contentType != null && _contentType != undefined && _contentType != ''){
					$http.defaults.headers.post['Content-Type'] = _contentType;
				}else{
					$http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
					}
				var requestConfig = genereateRequestConfig(_resourceKey,
						_params);
				   return $http({
							method : 'POST',
							url : requestConfig.url,
							withCredentials: true,
							params : requestConfig.paramsJson,
							data : _data
				   		}).then(function(response){
				   			if (transformer){
				   				return transformer(response.data.content);
				   			}else{
				   				return response.data.content;
				   			}
					    });	
			}
			
			var launchSessionTimedOutModal = function() {
				NotifySrvc({
			      id: 'simpleDialog',
			      template:
			        '<div class="row-fluid"><p>Dear User, Your session has timed out. Please login again.</p></div>',
			      title: 'Session Timed Out',
			      backdrop: true,
			      closeButton:false,
				  success: {label: 'Ok', fn: function() {$window.location.href = hcentive.WFM.serviceURL['loginServiceUrl'];}}
				});
			};
			
			// rest interface
			return {
				getForData : getForData,
				postForData : postForData,
				postForFile : postForFile,
				postForDataReturnsPromise : postForDataReturnsPromise
			};
		} ];

// data sharing service
hcentive.WFM.EventBusSrvc = [
		'$rootScope',
		function($rootScope) {
			var cache = {};
			// publish edit data notification
			var publish = function(topic, payload) {
				// alert("published :: event " + topic);
				$rootScope.$emit(topic, payload);
				/*
				 * (cache[topic] && angular.forEach(cache[topic], function() {
				 * this.apply(null, payload || []); });
				 */
			};
			// register to edit data notification
			var register = function($scope, topic) {
				// alert("registered :: event " + topic);
				$scope.$onRootScope(topic, function(event, args) {
					if (!cache[topic] || cache[topic].length > 0) {
						cache[topic] = [];
					}
					cache[topic].push(args);
				});
			};
			// register to edit data
			var subscribeOnce = function(topic) {
				// alert("subscribed :: event " + topic);
				if (cache[topic] == null || cache[topic] == 'undefined'
						|| cache[topic][0] == null
						|| cache[topic][0] == 'undefined') {
					return null;
				}
				return cache[topic][0];
			};
			
			var subscribe  = function(topic, _scope, _callback) {
				if(angular.isDefined(_scope) && angular.isDefined(_callback)){
					_scope.$watch(function(){return subscribeOnce(topic);}, function(newVal,oldVal){
						_callback(newVal,oldVal);
					});
				}else{
					//alert("subscribed :: event 2 " + topic);
					return subscribeOnce(topic);
				}
			};
			// This method call will remove payload from topic after first call.
			// Please do not use this method if your event is subscribed/listened by multiple view or from multiple places.
			var subscribeAndInvalidatePayload  = function(topic, _scope, _callback) {
			    if(angular.isDefined(_scope) && angular.isDefined(_callback)){
			     _scope.$watch(function(){
			       var payload =  subscribeOnce(topic);
			       if(payload != null && payload != undefined) {
			        cache[topic] = null;
			       }
			       return payload;
			      }, function(newVal,oldVal){
			      _callback(newVal,oldVal);
			     });
			    } else {
			     var payload =  subscribeOnce(topic);
			     if(payload != null && payload != undefined) {
			      cache[topic] = null;
			     }
			     return payload;
			    }
			   };
			
			return {
				publish : publish,
				register : register,
				subscribe : subscribe,
				subscribeAndInvalidatePayload : subscribeAndInvalidatePayload
			};
		} ];
