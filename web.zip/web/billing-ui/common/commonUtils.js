// Show waiting sign on element
var startProcessing = function(id) {

	//$("#" + id).mask("");

};

// Remove waiting sign from element
var stopProcessing = function(id) {
	//$("#" + id).unmask();
};

var checkCurrentDate = function(month,year) {
	
	if(month == '' || month == undefined || year == '' || year == undefined)
		return false;
	
	var currentYear = new Date().getFullYear();
	var currentMonth = new Date().getMonth() + 1
	if(year < currentYear)
	{
		return false;
	}
	else if(year == currentYear)
	{
		if(month < currentMonth)
		{
			return false;
		}
	}
	return true;
};

var preferredContactIndex = function(contactList)
{
	var tempVal = -1;
	if(contactList != null && contactList != undefined)
	{
		for(var i=0;i<contactList.length;i++)
		{
			var contact = contactList[i];
			if(contact.primary)
			{
				tempVal = i;
				break;
			}
		}
	}
	return tempVal;
};

var populatePreferredAddress = function(adressList){
	var address = {};
	if(adressList != undefined && adressList != null){
		var preferredAddressIndex = preferredContactIndex(adressList.contacts);
		if(preferredAddressIndex < 0)
			preferredAddressIndex = 0;
		var address = adressList.contacts[preferredAddressIndex];
	}
	validateAndPopulateAddress(address);
	return address;
}

var validateAndPopulateAddress = function(address){
	
	if(address.addressLine1 == null || address.addressLine1 == undefined){
		address.addressLine1 = '';
	}
	
	if(address.addressLine2 == null || address.addressLine2 == undefined){
		address.addressLine2 = '';
	}
	
	if(address.addressLine3 == null || address.addressLine3 == undefined){
		address.addressLine3 = '';
	}
	
	if(address.city == null || address.city == undefined){
		address.city = '';
	}
	
	if(address.state == null || address.state == undefined){
		address.state = '';
	}
	
	if(address.zipcode == null || address.zipcode == undefined){
		address.zipcode = '';
	}
	return address;
}

var populatePreferredEmail = function(emailList){
	var emailId = '';
	if(emailList != undefined && emailList != null){
		var preferredEmailIndex = preferredContactIndex(emailList.contacts);
		if(preferredEmailIndex < 0 )
			preferredEmailIndex = 0;
		emailId = emailList.contacts[preferredEmailIndex].emailId;
	}
	return emailId;
}


var populatePreferredContactNumber = function(contactList){
	var contactNumber = '';
	if(contactList != undefined && contactList != null){
		var preferredContactNumberIndex = preferredContactIndex(contactList.contacts);
		if(preferredContactNumberIndex < 0 )
			preferredContactNumberIndex = 0;
		contactNumber = contactList.contacts[preferredContactNumberIndex].number;
	}
	return contactNumber;
}

var fetchDataFromReferenceSet = function(referenceSet,checkOn){
	if(referenceSet != undefined && referenceSet.references.length > 0 && checkOn != undefined){
		for(var i=0; i < referenceSet.references.length; i++){
			if(referenceSet.references[i].typeName == checkOn){
				return referenceSet.references[i].referenceId;
			}
		}
		return null;
	}
}
// this function is used to convert First letter of name into Uppercase (added by harikesh)
String.prototype.ucwords = function() {
	
	if(this != null && this != undefined && this.length > 0) {
		 return this.toLowerCase().replace(/\b[a-z]/g, function(value) {
		        return value.toUpperCase();
		   });
	}
}
