function appendCriteriaInSearchCriteria(_searchCriteria, _keyValueJsonList){	
	var _filterList = transformKeyValJsonToFilter(_keyValueJsonList);
	return appendFilterInSearchCriteria(_searchCriteria,_filterList);
}


function transformKeyValJsonToFilter(_keyValueJsonList) {
	_filterList = [];

	angular.forEach(_keyValueJsonList, function(jsonObject, index) {
		var jsonObjectKey = Object.keys(jsonObject);
		var jsonObjectValue = jsonObject[jsonObjectKey];
		_filterList = addFilter(_filterList, jsonObjectKey, jsonObjectValue,
				"=", false);
	});
	return _filterList;

}
function appendFilterInSearchCriteria(_searchCriteria, _filterList) {
	var _prevFilterList = getPrevFiltersFromSearchCriteria(_searchCriteria);
	var _finalFilterList=_filterList.concat(_prevFilterList);
	var _paginationJson = _searchCriteria.pageRequestCriteria;
	var _refrenceId=_searchCriteria.referenceId;
	return getSearchCriteriaJson(_finalFilterList, _paginationJson, _refrenceId);
	
}
function getPrevFiltersFromSearchCriteria(_searchCriteria) {
	var _filterList=[];
	if(isValueNullOrNotDefinedOrBlank(_searchCriteria))
		return _filterList;
	
	var _criteria = _searchCriteria.criteria
	for (var i = 0, keys = Object.keys(_criteria), n = keys.length; i < n; i++) {
		var _columnName=keys[i];
		var _columnValue=_criteria(columnName).columnValue;
		var _operator=_criteria(columnName).columnValue;
		var _caseSensitiveSearch=_criteria(columnName).columnValue;
		_filterList = addFilter(_filterList, _columnName, _columnValue,
				_operator, _caseSensitiveSearch);
	}
	return _filterList;

} 

function addFilter(_filterList, _filterColumnName, _filterValue,
		_filterOperand, _filterValueCaseSensitive) {

	if (isValueNullOrNotDefinedOrBlank(_filterValue)
			|| isValueNullOrNotDefinedOrBlank(_filterOperand)) {
		return _filterList;
	}

	if (isValueNullOrNotDefinedOrBlank(_filterList)) {
		_filterList = [];
	}

	if (isValueNullOrNotDefinedOrBlank(_filterValueCaseSensitive)) {
		_filterValueCaseSensitive = false;
	}

	var filter = {};
	filter.columnName = _filterColumnName;
	filter.filterValue = _filterValue;
	filter.filterOperand = _filterOperand;
	filter.filterCaseSensitive = _filterValueCaseSensitive;
	_filterList.push(filter);

	return _filterList;
}

function isValueNullOrNotDefinedOrBlank(_value) {
	if (_value === undefined || _value === '' || _value === null) {
		return true;
	}
	return false;
}

function getSearchCriteriaJson(_filterList, _paginationJson, _refrenceId) {

	var criteria = {};
	var filterListSize =0;
	if(!isValueNullOrNotDefinedOrBlank(_filterList)){
		filterListSize= _filterList.length;
		for ( var index in _filterList) {
			var filterObj = _filterList[index];
			value = {};
			value.operator=filterObj.filterOperand;
			value.caseSensitiveSearch=filterObj.filterCaseSensitive;
			value.columnValue=filterObj.filterValue;
			criteria[filterObj.columnName]=value;
		}
	}


	if (isValueNullOrNotDefinedOrBlank(_paginationJson)) {
		_paginationJson = {};
	}

	var searchCriteria = {};
	searchCriteria.criteria = criteria;
	searchCriteria.pageRequestCriteria = _paginationJson;
	if (!isValueNullOrNotDefinedOrBlank(_refrenceId)) {
		searchCriteria.referenceId = _refrenceId;
	}
	return searchCriteria;
}
function getSearchCriteriaJsonWithProjection(_filterList, _paginationJson, _refrenceId,_projectedFields){
	var criteria = {};
	var filterListSize =0;
	if(!isValueNullOrNotDefinedOrBlank(_filterList)){
		filterListSize= _filterList.length;
		for ( var index in _filterList) {
			var filterObj = _filterList[index];
			value = {};
			value.operator=filterObj.filterOperand;
			value.caseSensitiveSearch=filterObj.filterCaseSensitive;
			value.columnValue=filterObj.filterValue;
			criteria[filterObj.columnName]=value;
		}
	}


	if (isValueNullOrNotDefinedOrBlank(_paginationJson)) {
		_paginationJson = {};
	}

	var searchCriteria = {};
	searchCriteria.criteria = criteria;
	searchCriteria.pageRequestCriteria = _paginationJson;
	if (!isValueNullOrNotDefinedOrBlank(_refrenceId)) {
		searchCriteria.referenceId = _refrenceId;
	}
	if (!isValueNullOrNotDefinedOrBlank(_projectedFields)) {
		searchCriteria.projectedFields = _projectedFields;
	}
	
	return searchCriteria;
}


function convertArrayToString(arrayObj,isString,isAppendQuote){
	if(isAppendQuote == undefined || isAppendQuote === '' || isAppendQuote == null){
		isAppendQuote = true;
	}
	
	var queryValue = '';
	if(arrayObj && arrayObj.length > 0){
		queryValue = '( '
		for(var i=0;i<arrayObj.length;i++){
			if(isString){
				if(queryValue == '( '){
						if(isAppendQuote){
							queryValue =queryValue + '\''+arrayObj[i]+'\'';
						}
						else{
							queryValue =queryValue + arrayObj[i];
						}
				}else{
					if(isAppendQuote){
						queryValue = queryValue + ',\''+arrayObj[i]+'\'';
					}
					else{
						queryValue = queryValue + ','+arrayObj[i];
					}
				}
			}else{
				if(queryValue == '( '){
					queryValue =queryValue + arrayObj[i];
				}else{
					queryValue = queryValue + ','+arrayObj[i];
				}
			}
		}
		queryValue = queryValue + " )";
	}
	return queryValue;
}

function addDateRangeFilter(criteria,columnName,filterValue,desiredDateFormat,filterAppendQuote, ngFilter,isMongoFilter){
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	var dateRangeCriteria;

	if(filterValue ){
		var startDate = filterValue.from;
		var endDate = filterValue.to;
		if(startDate != null && startDate != undefined && 
			endDate != null && endDate != undefined) {
			dateRangeCriteria = {};
			dateRangeCriteria.operator = "between";
			if(filterAppendQuote){
				dateRangeCriteria.columnValue = "'" + dateFormat(startDate,"from",desiredDateFormat, ngFilter,isMongoFilter) +"' AND '" + dateFormat(endDate,"to",desiredDateFormat, ngFilter,isMongoFilter) + "'";
			}
			else{
				dateRangeCriteria.columnValue = dateFormat(startDate,"from",desiredDateFormat, ngFilter,isMongoFilter) +" AND " + dateFormat(endDate,"to",desiredDateFormat, ngFilter,isMongoFilter);
			}
		} else if(startDate != null && startDate != undefined) {
			dateRangeCriteria = {};
			if(isMongoFilter){
				dateRangeCriteria.operator = "GTE_DATE";
			}else{
			dateRangeCriteria.operator = ">=";
			}
			if(filterAppendQuote){
				dateRangeCriteria.columnValue = "'" + dateFormat(startDate,"from",desiredDateFormat, ngFilter,isMongoFilter) +"'";
			}
			else{
				dateRangeCriteria.columnValue = dateFormat(startDate,"from",desiredDateFormat, ngFilter,isMongoFilter);			
			}
		} else if(endDate != null && endDate != undefined) {
			dateRangeCriteria = {};
			if(isMongoFilter){
				dateRangeCriteria.operator = "LTE_DATE";
			}else{
				dateRangeCriteria.operator = "<=";
			}
			if(filterAppendQuote){
				dateRangeCriteria.columnValue = "'" + dateFormat(endDate,"to",desiredDateFormat, ngFilter,isMongoFilter) +"'";
			}
			else{
				dateRangeCriteria.columnValue = dateFormat(endDate,"to",desiredDateFormat, ngFilter,isMongoFilter);
			}
		}
		
		if(dateRangeCriteria != undefined){
			criteria[columnName] = dateRangeCriteria;
		}
		
	}
	return criteria;
}

function addNumberRangeFilter(criteria,columnName,filterValue){
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	var numberRangeCriteria;	

	if(filterValue){
		var minNumber = filterValue.min;
		var maxNumber = filterValue.max;
		if(isNumber(minNumber) &&  isNumber(maxNumber)) {
			numberRangeCriteria = {};
			numberRangeCriteria.operator = "between";
			numberRangeCriteria.columnValue = minNumber +" AND " + maxNumber ;
		} else if(isNumber(minNumber)) {
			numberRangeCriteria = {};
			numberRangeCriteria.operator = ">=";
			numberRangeCriteria.columnValue = minNumber;
		} else if( isNumber(maxNumber)) {
			numberRangeCriteria = {};
			numberRangeCriteria.operator = "<=";
			numberRangeCriteria.columnValue = maxNumber ;
		}
		
		if(numberRangeCriteria != undefined){
				criteria[columnName] = numberRangeCriteria;
		}
	}
	
	return criteria;
}

function addNumberFilter(criteria,columnName,filterValue){
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	var numberRangeCriteria;
	
	var numberCriteria = {};
	
	if(filterValue) {
		numberRangeCriteria = {};
		numberRangeCriteria.operator = "=";
		numberRangeCriteria.columnValue = filterValue;
		criteria[columnName] = numberRangeCriteria;
	} 
	return criteria;
}

function addStringFilter(criteria,columnName,filterValue,isCaseSensitive,filterAppendQuote){
	
	if(isCaseSensitive == undefined){
		isCaseSensitive = false;
	}	

	if(filterAppendQuote == undefined){
		filterAppendQuote = true;
	}
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	if(filterValue) {
		var stringCriteria = {};
		stringCriteria.operator = "=";
		if(filterAppendQuote == true){
			stringCriteria.columnValue = '\''+filterValue +'\'';
		}
		else{
			stringCriteria.columnValue = filterValue;
		}
			
		stringCriteria.caseSensitiveSearch = isCaseSensitive;
		criteria[columnName] = stringCriteria;
	} 
	
	return criteria;
}

function addDateFilter(criteria,columnName,filterValue,desiredDateFormat,operator,isFromDate,isAppendQuote, ngFilter,isMongoFilter){
	
	if(operator == undefined){
		operator = '=';	
	}
	
	var from = "to";
	if(isFromDate == undefined || isFromDate){
		from = "from";	
	}
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	if(filterValue) {
		
		var dateCriteria = {};
		var formatedDate  = dateFormat(filterValue,from,desiredDateFormat, ngFilter,isMongoFilter);
		
		dateCriteria.operator = operator;
		
		if(isAppendQuote != undefined && !isAppendQuote){
			dateCriteria.columnValue = formatedDate;
		}else{
			dateCriteria.columnValue = '\''+formatedDate+'\'';
		}
		
		criteria[columnName] = dateCriteria;
	} 
	
	return criteria;
}

function addNumberListFilter(criteria,columnName,filterValue){
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	if(filterValue) {
		var numberListCriteria = {};
		numberListCriteria.operator = "IN";
		numberListCriteria.columnValue = convertArrayToString(filterValue,false);
		if(numberListCriteria.columnValue != ''){
			criteria[columnName] = numberListCriteria;
		}
	}
	return criteria;
}

function addEnumListFilter(criteria,columnName,filterValue){
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	if(filterValue) {
		var enumListCriteria = {};
		enumListCriteria.operator = "IN";
		enumListCriteria.columnValue = filterValue.toString();
		if(enumListCriteria.columnValue != ''){
			criteria[columnName] = enumListCriteria;
		}
	}
	return criteria;
}

function addStringListFilter(criteria,columnName,filterValue,isCaseSensitive,isAppendQuote){
	
	if(isCaseSensitive == undefined){
		isCaseSensitive = false;
	}
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	if(filterValue) {
		var stringListCriteria = {};
		stringListCriteria.operator = "IN";
		stringListCriteria.columnValue = convertArrayToString(filterValue,true,isAppendQuote);
		stringListCriteria.caseSensitiveSearch = isCaseSensitive;
		if(stringListCriteria.columnValue != ''){
			criteria[columnName] = stringListCriteria;
		}
	}
	return criteria;
}

function dateFormat(date,dateType,desiredDateFormat, ngFilter,isMongoFilter){

	if(typeof date === "string"){
		date = new Date(date);
	}
	
	var dateString = '';
	
	if(isMongoFilter)
    {
    	dateString = ngFilter('date')(date, 'yyyy/MM/dd');
    
	}else{
			if(hcentive.WFM.clientConfigurations[0].dateFormat.format && ngFilter) {
				dateString = ngFilter('date')(date, hcentive.WFM.clientConfigurations[0].dateFormat.format);
			} else {
				dateString = String(date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
			}
	}

	
	
	var timeString = '';
	if(dateType == 'from'){
		timeString = ' 00:00:00.0';
	}
	else if(dateType == 'to'){
		timeString = ' 23:59:59.999';
	}
	return dateString + timeString;
}


function removeFilter(filterJson,columnName){
	delete filterJson[columnName];
	return filterJson;
}

function addStringLikeFilter(criteria,columnName,filterValue,isCaseSensitive,isAppendQuote){
	if(isCaseSensitive == undefined){
		isCaseSensitive = false;
	}
	
	if(criteria == undefined){
		criteria = {};	
	}
	
	if(filterValue) {
		var stringLikeCriteria = {};
		stringLikeCriteria.operator = "LIKE";
		if(isAppendQuote){
			stringLikeCriteria.columnValue = '\'%' + filterValue + '%\'';
		}else{
			stringLikeCriteria.columnValue = filterValue;
		}
		stringLikeCriteria.caseSensitiveSearch = isCaseSensitive;
		if(stringLikeCriteria.columnValue != ''){
			criteria[columnName] = stringLikeCriteria;
		}
	}
	return criteria;
}


function buildCriteria(tableFilters, selectedFilters, ngFilter){
	
		var criteria = {};
	
		angular.forEach(tableFilters,function(filter,key){
			
			var filterValue = selectedFilters[filter.filterKey];
			var filterType = filter.filterType;
			var isCaseSensitive = filter.isCaseSensitive;
			var dateFormat = filter.dateFormat;
			var isMongoFilter= filter.isMongoFilter;
			var filterAppendQuote = '';
			if(filter.filterValueWithQuote === undefined || filter.filterValueWithQuote === '' || filter.filterValueWithQuote === null){
				filterAppendQuote = true;
			}
			else{
				filterAppendQuote = filter.filterValueWithQuote;
			}
			
			if(filterValue && filterType){
				var filterQueryKey = filter.filterKey;
				
				if(filter.filterQueryKey){
					filterQueryKey = filter.filterQueryKey;
				}
				
				if(filterType == 'DateRange'){
					if(Array.isArray(filterQueryKey)){
						var fromValue = filterValue.from;
						var toValue = filterValue.to;
						criteria = addDateFilter(criteria,filterQueryKey[0],fromValue,dateFormat,'>=',true,filterAppendQuote, ngFilter,isMongoFilter);
						criteria = addDateFilter(criteria,filterQueryKey[1],toValue,dateFormat,'<=',false,filterAppendQuote, ngFilter,isMongoFilter);
					}else{
						criteria = addDateRangeFilter(criteria,filterQueryKey,filterValue,dateFormat,filterAppendQuote, ngFilter,isMongoFilter);								
					}
				}else if(filterType == 'NumberRange'){
					if(Array.isArray(filterQueryKey)){
						var fromValue = filterValue.min;
						var toValue = filterValue.max;
						criteria = addNumberFilter(criteria,filterQueryKey[0],fromValue);
						criteria = addNumberFilter(criteria,filterQueryKey[1],toValue);
					}else{
						criteria = addNumberRangeFilter(criteria,filterQueryKey,filterValue);								
					}
				}else if(filterType == 'Number'){
					criteria = addNumberFilter(criteria,filterQueryKey,filterValue);
				}else if(filterType == 'String'){
					criteria = addStringFilter(criteria,filterQueryKey,filterValue,isCaseSensitive,filterAppendQuote);
				}else if(filterType == 'NumberList'){
					criteria = addNumberListFilter(criteria,filterQueryKey,filterValue);
				}else if(filterType == 'StringList'){
					criteria = addStringListFilter(criteria,filterQueryKey,filterValue,isCaseSensitive,filterAppendQuote);
				}else if(filterType == 'EnumList'){
					criteria = addEnumListFilter(criteria,filterQueryKey,filterValue);
				}else if(filterType == 'StringLike'){
					criteria = addStringLikeFilter(criteria,filterQueryKey,filterValue,false,true);
				}
				else if(filterType == 'JSONStringLike'){
					criteria = addStringLikeFilter(criteria,filterQueryKey,filterValue,false,false);
				}
			}
		});

		return criteria;
	
}

function isNumber(value){
	if(value == undefined){
		return false;
	}else if(angular.isNumber(value)){
		return true;
	}else{
		var number = parseInt(value);
		if(number == undefined || isNaN(number)){
			return false;
		}else if(angular.isNumber(number)){
			return true;
		}
	}
	return false;
}
