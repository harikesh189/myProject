var tranformInvoiceSummary = function(data) {

	return data;
};


function validateDate(input) {
	var dateFormat = /^\d\d?\/\d\d?\/\d\d\d\d$/;
	// assuming that input is coming as MM/DD/YYYY
	if (input == null || input == 'undefined' || input == '' || !dateFormat.test(input)) {
		return false;
	} else { //Detailed check for valid date i.e 02/30/2012 is not a valid date
		var monthfield = input.split("/")[0];
		var dayfield = input.split("/")[1];
		var yearfield = input.split("/")[2];

		var dayobj = new Date(yearfield, monthfield - 1, dayfield);

		if ((dayobj.getMonth() + 1 != monthfield)
				|| (dayobj.getDate() != dayfield)
				|| (dayobj.getFullYear() != yearfield))
			return false;
		else
			return true;
	}
	return false;
}



function getPaymentHistoryRecord(data) {
	var paymentHistoryList = [];
	angular.forEach(
			data,
			function(value,key){
				var paymentHistoryObject = {};
				paymentHistoryObject.identity = value.identity;
				paymentHistoryObject.payment_date = value.paymentDate.date;
				paymentHistoryObject.paid_value = value.amountPaid.value;
				paymentHistoryObject.discount_value = value.discount.value;
				paymentHistoryObject.invoice_amount = value.amountPaid.value + value.discount.value;
				paymentHistoryObject.type = getPaymentType(value.type);
				paymentHistoryObject.payment_mode = getPAymentMode(value.paymentMode);
				paymentHistoryObject.status = getPaymentStatus(value.status);
				paymentHistoryList.push(paymentHistoryObject);
			});
	return paymentHistoryList;
}

function getTransformedNotifications(data)
{
	var notifications = [];
	angular.forEach(
			data,
			function(value,key){
				var notificationsObject = {};
				notificationsObject.notification = value.body;
				notificationsObject.notification_time = convertTime(value.dateCreated) + ', ' +convertDate(value.dateCreated);
				notifications.push(notificationsObject);
			});
	return notifications;
			
}

function getTransformedNotificationsForBroker(data){
	var notifications = [];
	angular.forEach(
			data,
			function(value,key){
				var notificationsObject = {};
				notificationsObject.notification = value.body;
				notificationsObject.notification_time = convertTime(value.dateCreated) + ', ' +convertDate(value.dateCreated);
				notificationsObject.id = value.id;
				notificationsObject.action = '<a class="toolTip delRow" original-title="Delete" href="javascript:void(0);" ng-click="deleteNotificationPopup(value.id);"><span class="icon-delete"></span></a>';
				notifications.push(notificationsObject);
			});
	return notifications;
}


var getPaymentRecord = function(data) {
	var paymentRecord = [];
	if (data != "")
		paymentRecord.push(data);
	var paymentHistoryRecordList = getPaymentRecordList(paymentRecord);
	var transformData = {};
	transformData.paymentHistoryRecordList = paymentHistoryRecordList;

	return transformData;
};

function getPaymentRecordList(data) {
	var paymentHistoryRecordList = [];
	angular
			.forEach(
					data,
					function(value, key) {

						var paymentHistoryRecord = {};

						paymentDate = convertDate(value.paymentDate.date);
						paymentHistoryRecord.date = paymentDate
						paymentHistoryRecord.transactionId = value.identity;
						paymentHistoryRecord.amountPaid = value.amountPaid.value;
						paymentHistoryRecord.type = getPaymentType(value.type);
						paymentHistoryRecord.paymentMode = getPAymentMode(value.paymentMode);
						paymentHistoryRecord.status = getPaymentStatus(value.status);
						paymentHistoryRecord.discount = value.discount.value;
						for(var i = 0 ; i < value.referenceSet.references.length ; i++){
							var ref = value.referenceSet.references[i];
							if(ref.typeName == 'DISCOUNT_GIVEN')
							{	
								paymentHistoryRecord.discount = ref.refValue;
								break;
							}
						}
						paymentHistoryRecord.totalAmountPaid = parseFloat(value.amountPaid.value) + parseFloat(paymentHistoryRecord.discount);
						paymentHistoryRecordList.push(paymentHistoryRecord);
					});
	return paymentHistoryRecordList;
}

function getPaymentType(type) {

	if (type == 'OneTime_Payment_Request')
		return 'One Time Payment';
	else if (type == 'Recurring_Payment_Request')
		return 'Recurring Payment';
}

function getPAymentMode(paymentMode) {
	if (paymentMode == 'BankAccount' || paymentMode == 'Token-BankAccount')
		return 'Bank Account';
	else if (paymentMode == 'Card' || paymentMode == 'Token-Card')
		return 'Credit Card';
	else 
		return paymentMode;
}

function getPaymentStatus(status) {
	if (status == 'PAYMENT_REQUEST_SUCCESSFULL')
		return 'Successful';
	if (status == 'PAYMENT_REQUEST_FAILED')
		return 'Failed';
	if (status == 'PAYMENT_REQUEST_INITIATED')
		return 'Initiated';
}


function getMemebersList(enrolledPlans){
var memberList = [];
	angular
		.forEach(
				enrolledPlans,
				function(plan, key) {
				var healthPlan = plan.healthPlan;
				angular.forEach(plan.memberCoverages,function(memberCoverage, key) {
				var member = memberCoverage.member;
				var memberObj = {};
				memberObj.memberId = member.memberId;
				memberObj.memberName = getPersonalProfileFullName(member.personalProfile);
				memberObj.relation = toPascalCase(member.relationship);
				memberObj.planId = healthPlan.externalId;
				memberObj.planName = healthPlan.name;
				memberObj.effDate = memberCoverage.coverage.beginsOn.date;
				memberObj.termDate = memberCoverage.coverage.endsOn.date;
				memberObj.status = toPascalCase(member.personalProfile.status);
				//memberObj.amount = memberCoverage.premium.amount.value;
				memberList.push(memberObj);
				});
				
				});
	return memberList;
}

function getPersonalProfileFullName(profile) {
	
	var name = '';
	if(profile.firstName != null)
		name = name + profile.firstName;
	if(profile.middleName != null)
		name = name + ' ' + profile.middleName;
	if(profile.lastName != null)
		name = name + ' ' + profile.lastName;
	
	return name;
	
}

function getPlansList(data){
var planList = [];
	angular
			.forEach(
				data,
				function(value, key) {
				 var planObj = {};
				 planObj.planId = value.healthPlan.externalId;
				 planObj.planName = value.healthPlan.name;
				 planObj.carrier = (value.healthPlan.carrier != null) ? value.healthPlan.carrier.externalId : null;
				 /*planObj.effDate = value.coverageInfo.coverage.beginsOn.date;
				 planObj.validUpto = value.coverageInfo.coverage.endsOn.date;*/
				 planObj.coveredLife = value.memberCoverages.length;
				 planObj.totalPremium = getTotalPremium(value.memberCoverages);
				// planObj.coverageType = value.coverageInfo.coverageType;
				 planList.push(planObj);
				});
	return planList;
}

function getTotalPremium(data)
{
	var totalPremium = 0;
	for(var i=0 ; i < data.length; i++)
	{
		//totalPremium = totalPremium + data[i].premium.amount.value;
	}
	return totalPremium;
}

function getClientList(data, pageType) {

	var clientList = [];
	angular
			.forEach(
					data.content,
					function(value, key) {
						var clientObj = {};
						clientObj.beExternalId = value.beExternalId;
						clientObj.beType = value.beType;
						clientObj.customerName = value.firstName;
						clientObj.currentBalance = value.currentBalance;
						
						
						clientObj.generatedOn = value.generatedOn;
						clientObj.dueDate = value.dueDate;
						if(value.billingStatus == 'NEW')
							clientObj.billingStatus = 'UNPAID';
						else if(value.billingStatus == 'PARTIAL_PAYMENT')
							clientObj.billingStatus = 'PARTIALLY PAID';
						else if(value.billingStatus == 'SETTLED')
							clientObj.billingStatus = 'PAID';
						clientObj.invoiceIdentity = value.invoiceIdentity;
						clientObj.invoiceExternalId = value.invoiceExternalId;
						clientObj.beIdentity = value.beIdentity;
						clientObj.contractIdentity = value.contractIdentity;
						clientObj.contractExternalId = value.contractExternalId;
						clientObj.beExternalId = value.beExternalId;
						if (pageType == '' ) {
							if(clientObj.invoiceIdentity != undefined && clientObj.invoiceIdentity != '' ){
								if(clientObj.beType == 'Group'){
									clientObj.action = '<a href="#/view-bills/current-invoice-group" ng-click="generateLeftNav(\'Search Clients\''
										+ ');publishInvoiceBEIdentity(value.invoiceIdentity,value.beIdentity,value.beType,value.contractIdentity,value.contractExternalId);" class="smallLinkBtn toolTip noWrap" title="View'
										+ 'Details">Invoice Details</a>';
								}else{
									clientObj.action = '<a href="#/view-bills/current-invoice-individual" ng-click="generateLeftNav(\'Search Clients\''
										+ ');publishInvoiceBEIdentity(value.invoiceIdentity,value.beIdentity,value.beType,value.contractIdentity,value.contractExternalId);" class="smallLinkBtn toolTip noWrap" title="View'
										+ 'Details">Invoice Details</a>';
								}
							}
						} else {
							clientObj.action = '';
							if(clientObj.beType == 'Group'){
								if(clientObj.invoiceIdentity != undefined && clientObj.invoiceIdentity != ''){
									clientObj.action = clientObj.action + '<a href="#/view-bills/current-invoice-group" class="viewProfile toolTip noWrap" title="View'
									+ 'Invoice" ng-click="publishInvoiceBEIdentity(value.invoiceIdentity,value.beIdentity,value.beType,value.contractIdentity)"><i'
									+ ' class="icon-view-details"></i></a> <span class="lineDivider"></span>';
								}
							}else{
								if(clientObj.invoiceIdentity != undefined && clientObj.invoiceIdentity != ''){
									clientObj.action = clientObj.action + '<a href="#/view-bills/current-invoice-individual" class="viewProfile toolTip noWrap" title="View'
									+ 'Invoice" ng-click="publishInvoiceBEIdentity(value.invoiceIdentity,value.beIdentity,value.beType,value.contractIdentity)"><i'
									+ ' class="icon-view-details"></i></a> <span class="lineDivider"></span>';
								}
							}
							clientObj.action = clientObj.action + ' <a class="viewProfile"'
							+ 'js-broker-viewac-ind toolTip" href="javascript:void(0);" title="View Account"'
							+ 'ng-click="launchInlineModal(value.beExternalId);"><i class="icon-viewac"></i></a>';
						}
						clientList.push(clientObj);
					});
	return clientList;
}

var accountTransactionTransformer = function(data) {
	var auditData = [];
	
	for(var i =0 ; i<data.content.length ; i++){
		var value = data.content[i];
		var auditDataObj = {};
		auditDataObj.dateTime = value.auditTime.date;
		auditDataObj.auditType = toPascalCase(value.auditType);
		auditDataObj.message = value.message;
		auditData.push(auditDataObj);
	}
	return auditData;
};

function toPascalCase(type) {
	
	return type.substring(0,1).toUpperCase() + type.substring(1,type.length).toLowerCase();
	
}

var invoiceListTransformer = function(data) {
	if(data!='' && data != undefined)
	{
		for(var i =0 ; i<data.content.length ; i++){
			var value = data.content[i];
			var invoice = value.invoice;
			var itemsArray = new Array();
			for(var j =0;j<invoice.items.length ; j++){
				var index =0;
				if(itemsArray.length != undefined){
					index =itemsArray.length;
				}

				var item = invoice.items[j];
				if(item.type == 'CURRENT_PREMIUM'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Premiums this period';
					itemsArray[index].amount = item.amount.value;
				}
				if(item.type == 'PRIOR_DUE'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Amount Due from Prior'
						itemsArray[index].amount = item.amount.value;
				}
				if(item.type == 'ADJUSTMENT'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Adjustments Applied';
					itemsArray[index].amount = item.amount.value;
				}
				if(item.type == 'FEE'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Fee Applied';
					itemsArray[index].amount = item.amount.value;
				}
				if(item.type == 'DISCOUNT'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Discount Given';
					itemsArray[index].amount = item.amount.value;
				}
				if(item.type == 'CREDIT'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Credits Applied';
					itemsArray[index].amount = item.amount.value;
				}
				if(item.type == 'APTC'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Aptc Amount';
					itemsArray[index].amount = item.amount.value;
				}
				if(item.type == 'OTHER'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Other';
					itemsArray[index].amount = item.amount.value;
				}
				if(item.type  == 'OUTSTANDING_ACCOUNT_BALANCE'){
					itemsArray[index] = new Object();
					itemsArray[index].category = 'Outstanding Balance';
					itemsArray[index].amount = item.amount.value;
				}
			}
			invoice.items = itemsArray.sort(dynamicSort("category"));
			var appDateFormat = hcentive.WFM.clientConfigurations[0].dateFormat.format;
			invoice.dueDate.date = invoice.dueDate.date;
			invoice.generatedOn.date =invoice.generatedOn.date;

		}
	}
	return data;
};

function getUserMgmtList(data){
var userMgmtList = [];
	angular
			.forEach(
				data,
				function(value, key) {
				 var roleObj = {};
				  roleObj.tenantId = value.tenantId ;
				  roleObj.identity = value.identity;
				 roleObj.type = value.userType;
				 roleObj.name = value.name;
				 roleObj.status = 'Active';
				 if(value.tenantId == 'System'){
					roleObj.action = '';
				 }else{
					roleObj.action = '<a href="" ng-click="selectedRoleForUpdation(value)"><span class="icon-edit"></span></a>';
					}
					userMgmtList.push(roleObj);
				 });
	return userMgmtList;
}
function dynamicSort(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}


function dateFormater(date) {
	var appDateFormat = hcentive.WFM.clientConfigurations[0].dateFormat.format;
	if (date != undefined) {
		date = new Date(date);
		date = date.format(appDateFormat);
	}
	return date;
}

function InitCap(input){
	if(input == null){
		return null;
	}
	return input.substring(0,1).toUpperCase()+input.substring(1).toLowerCase();
}

function getUserTransformer(data){
	var usersList = [];
		angular
				.forEach(
					data,
					function(value, key) {
					 var userObj = {};
					 userObj.identity = value.identity;
					 userObj.checkbox = '<input type="checkbox" ng-click="selectUser(value.identity)" name="checkbox" id="checkbox" />';
					 userObj.name = value.profile.firstName +' '+value.profile.lastName;
					 userObj.userId = '';
					 var roleNames ='';
					 angular.forEach(value.roles,function(roleValue, roleKey) {
						roleNames = roleNames +roleValue.name;
					 });
					 userObj.userRole =roleNames;
					 userObj.status = InitCap(value.status);
					 userObj.action = '<a href="#/profile/add-edit-user" title="Edit" ng-click="publishUserIdentity(value.identity)"><span class="icon-edit"></span></a>';
					 usersList.push(userObj);
					 });
		return usersList;
	}

function customerSummaryTransformer(data){
	var customerSummaryList = [];
		angular
				.forEach(
					data,
					function(value, key) {
					 var custSummObj = {};
					 custSummObj.externalId = value.externalId;
					 custSummObj.identity = value.identity;
					 custSummObj.subscriberId = value.subscriberId;
					 custSummObj.name  = value.name;
					 custSummObj.firstName = value.firstName;
					 custSummObj.lastName = value.lastName;
					 custSummObj.groupId = value.groupId;
					 custSummObj.groupIdentity = value.groupIdentity;
					 custSummObj.premiumDue = value.premiumDue;
					 custSummObj.premiumCollected = value.premiumCollected;
					 custSummObj.accBalance = value.accBalance;
					 
					 
					 custSummObj.value = value;
					 var permission = 'make-payment';
					 
					 custSummObj.action = '<a class="viewDetails" title="View Details">'
									+'<i class="icon-view-details" ng-click="callViewDetails(value)"></i>'
								+'</a>'
								+'<span ng-if="isRenderable(\'make-payment\')"><span class="lineDivider"></span>'
								+' <a  class="viewProfile" ng-click="callPaymentOnline(value)" title="Make a Payment">'
									+'<img src="images/dolar-sign1.png" alt="Make a Payment">'
								+'</a></span>'
								+'<span class="lineDivider"></span> '
								+'<a class="viewProfile" title="Setup Recurring" ng-click="callRecurringPayment(value)">'
									+'<img src="images/recurring-icon.png" alt="Setup Recurring">'
								+'</a>';
					 customerSummaryList.push(custSummObj);
					 });
		return customerSummaryList;
	}
	
	function paymentSummaryTransformer(data,paymentId){
	var paymentSummaryList = [];
		angular
				.forEach(
					data,
					function(value, key) {
					 var paymentSummObj = {};
					 paymentSummObj.paymentId = value.paymentId;
					 paymentSummObj.subscriberId = value.businessEntity.externalId;
					 paymentSummObj.groupId  = value.groupId;
					 paymentSummObj.paymentDate = value.date.date;
					 angular.forEach(value.referenceSet.references,
					function(paymentReference, index) {
						if(paymentReference.typeName == 'PaymentInstrument'){
							paymentSummObj.paymentMethod = paymentReference.refValue.replace('Token-','');
						}
					});
					 
					 paymentSummObj.amount = '$'+ value.amount.value;
					 paymentSummObj.value = value;
					 paymentSummaryList.push(paymentSummObj);
					 });
		return paymentSummaryList;
	}
	

	function invoiceSummaryPage(data,isCSR){
	var invoiceSummaryList = [];
		angular
				.forEach(
					data,
					function(value, key) {
						
							 var invoiceSummObj = {};
							 invoiceSummObj.beType = value.beType;
							 invoiceSummObj.itemRecordId = value.invoice.itemRecordId;
							 invoiceSummObj.identity = value.invoice.identity;
							 invoiceSummObj.externalId = value.invoice.externalId;
							 invoiceSummObj.dueDate = value.invoice.dueDate.date;
							 invoiceSummObj.generatedFor  = value.invoice.generatedFor.externalId;
							 invoiceSummObj.groupId = value.groupId;
							 invoiceSummObj.payableAmount = value.invoice.payableAmount.value;
							 invoiceSummObj.invoice = value.invoice;
							 invoiceSummObj.amountPaid = value.amountPaid;
							 if(value.invoice.docRefs.length > 0){
								invoiceSummObj.docRefId = value.invoice.docRefs[0].docRefId;
								invoiceSummObj.dmsKey = value.invoice.docRefs[0].dmsKey;
							 }
							 if(value.amountPaid.value == 0){
								invoiceSummObj.status = 'Unpaid';
							 }
							 else if (value.amountPaid.value + value.discount.value >= value.invoice.payableAmount.value){
								invoiceSummObj.status = 'Paid';
							 }
							 else {
								invoiceSummObj.status = 'Partially Paid';
							 }
							 
							 if(!isCSR){ 
							 invoiceSummObj.action = '<span ng-if="value.amountPaid.value>0">'
											+'<a href="" class="js-icon-payments toolTip" original-title="Payments">'
												+'<i class=" icon-payments" ng-click="getPaidInvoiceSummary(value.invoice.identity)">></i></a> '
											+'<span class="lineDivider"></span>'
										+'</span>'
										+'<a href="" class="viewDetails" title="View Details">'
											+'<i class="icon-view-details" ng-click="getInvoiceDetail(value)"></i>'
										+'</a>'
										+'<span ng-if="value.invoice.docRefs[0].docRefId != undefined && value.invoice.docRefs[0].dmsKey != undefined && isRenderable(\'invoice-download\')"><span class="lineDivider"></span> '
										+'<a href="javascript:void(0);" '
										+' ng-click="downloadInvoiceForOperator(value.invoice.docRefs[0].dmsKey)" class="viewProfile" title="Download PDF">'
										+' <i class="icon-pdf"></i></a></span>';
							 }
							 invoiceSummObj.value = value;
							 invoiceSummaryList.push(invoiceSummObj);
						 
					 });
		return invoiceSummaryList;
	}
	




	function getPoliciesTransformer(data){
		var policiesList = [];
		angular
		.forEach(
				data.payload,
				function(value, key) {
					var policyObj = {};
					policyObj.identity = value.identity;
					policyObj.policyname = value.name;
					policyObj.checkbox = '<input type="radio" name="checkbox" id="checkbox" />';
					policyObj.description = value.description;
					policyObj.effectivedt = convertDate(value.period.beginsOn.date);
					policyObj.terminationdt = convertDate(value.period.endsOn.date);

					policyObj.action ='<a id="viewRule" href="#/rules/associate-entity?id='+policyObj.identity+'" title="Associate Entity" ng-click=""><span class="icon-view-details"></span></a>'+
	 				 				 '<span class="lineDivider"></span>'+ 
									 '<a href="#/rules/policy-rule-view?id='+policyObj.identity+'" title="Associated Rules" ><span class="icon-rule-associate"></span></a>'+
					                 '<span class="lineDivider"></span>'+
					 				 '<a href="#/rules/policy-entity-view?id='+policyObj.identity+'" title="Associated Entities" ><span class="icon-rule-entity"></span></a>'+
									 '<span class="lineDivider"></span>'+
									 '<a href="" title="Create a Copy" ><span class="icon-copy"></span></a>'+
									 '<span class="lineDivider"></span>'+
									 '<a href="" title="Delete" ><span class="icon-delete"></span></a>';
					
					policiesList.push(policyObj);
				});

		return policiesList;
	}
	
	function billingSummaryTransformer(data){
	var billingSummaryList = [];
		angular
				.forEach(
					data,
					function(value, key) {
					 var billSummObj = {};
					 billSummObj.date = value.date.date;
					 billSummObj.type = value.type;
					 billSummObj.description = value.description;
					 billSummObj.amount  = value.amount.value;
					 billSummObj.balance = value.balance.value;
					 billingSummaryList.push(billSummObj);
					 });
		return billingSummaryList;
	}
	
	function getRulesTransformer(data){
		var rulesList = [];
		angular
		.forEach(
				data.payload,
				function(value, key) {
					var ruleObj = {};
					ruleObj.identity = value.identity;
					ruleObj.rulename = value.name;
					ruleObj.desc = value.description;
					ruleObj.status = 'Active';
					ruleObj.rulecategory = value.configType;
					ruleObj.ruletype = value.type;
					ruleObj.creationdt = convertDate(value.auditInfo.createdAt.date);
					ruleObj.effdt = convertDate(value.period.beginsOn.date);
					ruleObj.termdt = convertDate(value.period.endsOn.date);

					ruleObj.action = '<a id="viewRule" href="#/rules/view?id='+ruleObj.identity+'" title="Details" ng-click=""><span class="icon-view-details"></span></a>'+
									 '<span class="lineDivider"></span>'+
									'<a href="#/rules/view?id='+ruleObj.identity+'" title="Edit" ng-click=""><span class="icon-edit"></span></a>'+
									 '<span class="lineDivider"></span>'+
									 '<a href="#/rules/add?rid="'+ruleObj.identity+'" title="Delete" ng-click=""><span class="icon-delete"></span></a>';
					rulesList.push(ruleObj);
				});

		return rulesList;
	}
	
	function transformRuleList(data){
		
		var ruleList = [];
		angular
		.forEach(
				data.payload,
				function(value, key) {
					
					var rule = {name: value.name,identity :value.identity};
					
					ruleList.push(rule);
				});
		
		
		return ruleList;
		
	}
	
	function transformEntitiesList(data){
			
			var entityList = [];
			angular
			.forEach(
					data.content,
					function(value, key) {
						
						var entity = {name: value.externalId,identity :value.identity,type:value.businessEntityType};
						
						entityList.push(entity);
					});
			
			
			return entityList;
			
		}

	function transformPolicyEntityMap(data){

		
		var mapList = [];
		angular
		.forEach(
				data.payload,
				function(value, key) {
					var map = {name: value.businessEntity.externalId};
					
					mapList.push(map);
				});

		
		return mapList;

	}
//added by Priya
	function getSytemBillCycleTransformer($scope,data,beType){
	
		var billCycleList = [];
		
		if(data != null && data != undefined) {
			angular.forEach(data.content, function(value, key) {
						var billCycleObj = {};
						
						billCycleObj.identity = value.identity;
						billCycleObj.externalId = value.externalId;
						
						if(value.billingPeriod != null && value.billingPeriod != undefined && 
							value.billingPeriod.beginsOn != null && value.billingPeriod.beginsOn != undefined && 
							value.billingPeriod.beginsOn.date != null && value.billingPeriod.beginsOn.date != undefined && 
							value.billingPeriod.endsOn != null && value.billingPeriod.endsOn != undefined && 
							value.billingPeriod.endsOn.date != null && value.billingPeriod.endsOn.date != undefined) {
							
								var beginDate=convertDate(value.billingPeriod.beginsOn.date);
								var endDate=convertDate(value.billingPeriod.endsOn.date);
								
								billCycleObj.billPeriod = beginDate+" - "+endDate;
								
						} else {
							billCycleObj.billPeriod = '';
						}
						
						if(value.runDate != null && value.runDate != undefined && 
							value.runDate.date != null && value.runDate.date != undefined) {
							billCycleObj.billGenerationDate = convertDate(value.runDate.date);
						} else {
							billCycleObj.billGenerationDate = '';
						}
						
						if(value.invoiceAmount != null && value.invoiceAmount != undefined && 
							value.invoiceAmount.value != null && value.invoiceAmount.value != undefined) {
							billCycleObj.invoiceAmt = value.invoiceAmount.value;
						} else {
							billCycleObj.invoiceAmt = '';
						}
						
						billCycleObj.billCycleType = billScheduleType(value.billCycleType);
						
						billCycleObj.numberOfEntities =value.entitiesCount;
						billCycleObj.status = billCycleStatus(value.status);
						billCycleObj.action ='';
						
						if($scope.isRenderable('billCycleAssociatedEntity')){
							billCycleObj.action =billCycleObj.action + '<a href="#/system/associated-entities" title="Associated Billing Accounts" ng-click="publishBillCycleDetails(value.externalId)"><span class="icon-view toolTip icon-transferToEntity"></span></a><span class="lineDivider"></span>'; 
						}
						
						
						if($scope.isRenderable('FinancialsInvoices')){
							billCycleObj.action = billCycleObj.action
						+'<a href="#/financials/invoices/groups" title="Invoices" ng-click="publishInvoiceDetails(value.identity)"><span class="icon-view toolTip icon-view-details"></span></a>'; 
						}
							 /*if(billCycleObj.status=="PENDING")	{
									billCycleObj.action='<a href="#/system/associated-entities" title="Associated Entities" ng-click=""><span class="icon-view toolTip icon-entityList"></span></a>'+
									 '<span class="lineDivider"></span>'+'<a href="/rule/add-edit-rule" title="Invoices" ng-click=""><span class="icon-view toolTip icon-view-details"></span></a>' +
									 '<span class="lineDivider"></span>'+'<a href="/rule/add-edit-rule" title="Review" ng-click=""><span class="icon-view toolTip icon-setup"></span></a>';
									} */
						billCycleList.push(billCycleObj);
					});
			
			if(billCycleList != null && billCycleList != undefined && billCycleList.length > 0) {
	 			billCycleList.length = data.totalElements;
	 		} else {
	 			billCycleList = 'No Data';
	 		}
		} else {
     		billCycleList = 'No Data';
     	}
		
		return billCycleList;
	}
	
function billCycleStatus(status){
	var result = ''; 
	if(status != null && status != undefined && status != '') {
		if(status == 'PENDING') {
			result = 'Pending';
		} else if(status == 'CANCELLED' || status == 'CANCELLED_FOR_RERUN' || status == 'CANCELLED_FOR_REJECTION') {
			result = 'Cancelled';
		} else if(status == 'INIT_STARTED' || status == 'INITIATED') {
			result = 'Running';
		} else if(status == 'COMPLETED') {
			result = 'Completed';
		} else if(status == 'FAILED') {
			result = 'Failed';
		} else if(status == 'WAITING') {
			result = 'Waiting';
		}
	}
	return result;
}

	function getSytemAssociatedEntitiesTransformer(data,beType){
		
		var associatedEntitiesList = [];
		angular
		.forEach(
				data.content,
				function(value, key) {
					var associatedEntitiesObj = {};
					var type='';
					associatedEntitiesObj.beIdentity='';
						  if (value.billingAccount != null
								&& value.billingAccount != undefined) {
							if (value.billingAccount.externalId != null
									&& value.billingAccount.externalId != undefined) {
								// associatedEntitiesObj.entityId
								// =value.contract.contractInfo.subscriberExtId;
								associatedEntitiesObj.subscription = value.billingAccount.externalId;
							}
						}
                    if (value.billingAccount != null && value.billingAccount != undefined &&
                        value.billingAccount.owner != null && value.billingAccount.owner != undefined) {
                        if(value.billingAccount.owner.externalId != null && value.billingAccount.owner.externalId != undefined) {
								//associatedEntitiesObj.entityId =value.contract.contractInfo.subscriberExtId;
                        	associatedEntitiesObj.entityId = value.billingAccount.owner.externalId;
                        }
                        
                      
                        if(value.billingAccount.owner.identity != null && value.billingAccount.owner.identity != undefined) {
	                    	associatedEntitiesObj.beIdentity = value.billingAccount.owner.identity;
	                    	type = value.billingAccount.owner.type;
	                    }
                    }
                    
                    if(value.invoiceAmount != null && value.invoiceAmount != undefined && 
						value.invoiceAmount.value != null && value.invoiceAmount.value != undefined) {
							associatedEntitiesObj.invoiceAmt = value.invoiceAmount.value;
					} else {
						associatedEntitiesObj.invoiceAmt = '';
					}

					if(value.billingRunCycle != null && value.billingRunCycle != undefined && 
							value.billingRunCycle.externalId != null && value.billingRunCycle.externalId != undefined ) {
						associatedEntitiesObj.billCycleId=value.billingRunCycle.externalId;
					}
                    
                    if(value.billingRunCycle != null && value.billingRunCycle != undefined && 
							value.billingRunCycle.identity != null && value.billingRunCycle.identity != undefined ) {
						associatedEntitiesObj.billCycleIdentity=value.billingRunCycle.identity;
					}
						
					if(value.billingRunCycle != null && value.billingRunCycle != undefined ) {
						associatedEntitiesObj.billScheduleType=billScheduleType(value.billingRunCycle.billCycleType);
					}
					
					
					associatedEntitiesObj.ruleId= value.billingRunCycle.scheduleConfigExternalId==null? "" : value.billingRunCycle.scheduleConfigExternalId;

                    if (value.billingRunCycle.billingPeriod != null && value.billingRunCycle.billingPeriod != undefined &&
                        value.billingRunCycle.billingPeriod.beginsOn != null && value.billingRunCycle.billingPeriod.beginsOn != undefined &&
                        value.billingRunCycle.billingPeriod.beginsOn.date != null && value.billingRunCycle.billingPeriod.beginsOn.date != undefined &&
                        value.billingRunCycle.billingPeriod.endsOn != null && value.billingRunCycle.billingPeriod.endsOn != undefined &&
                        value.billingRunCycle.billingPeriod.endsOn.date != null && value.billingRunCycle.billingPeriod.endsOn.date != undefined) {
						
								//var beginDate=convertDate(value.billRunContext.billingPeriod.beginsOn.date);
								//var endDate=convertDate(value.billRunContext.billingPeriod.endsOn.date);

                        var beginDate = convertDate(value.billingRunCycle.billingPeriod.beginsOn.date);
                        var endDate = convertDate(value.billingRunCycle.billingPeriod.endsOn.date);
						
								associatedEntitiesObj.billPeriod = beginDate+"-"+endDate;
					}
					associatedEntitiesObj.billGenerationDate = convertDate(value.runDate == null? value.billingRunCycle.runDate.date : value.runDate.date);
					
					associatedEntitiesObj.billDueDate = convertDate(value.billingRunCycle.dueDate.date);
                    associatedEntitiesObj.value = value;
                    var page = '';
					if(type == 'Individual'){
						page = 'individuals';
					}else if(type == 'Group'){
						page = 'groups';
					}else if(type == 'HealthPlanProvider'){
						page = 'partners';
					}
					associatedEntitiesObj.action ='<a href="#/financials/financials-transactions-report" title="Associated Financial Transactions" ng-click="publishTransactionDetails(value.billCycleId, value.beIdentity,\''+  associatedEntitiesObj.entityId+'\', value.subscription)"><span class="icon-view toolTip icon-entityList"></span></a>'+
                        '<span class="lineDivider"></span>' + '<a href="#/financials/invoices/'+page+'" title="Invoices" ng-click="publishInvoiceDetails(value.billCycleIdentity, value.beIdentity ,value.subscription)"><span class="icon-view toolTip icon-view-details"></span></a>';
                    if (value.status == "PENDING") {
                        associatedEntitiesObj.action = associatedEntitiesObj.action + '<span class="lineDivider"></span><a class="viewProfile js-icon-editgrpbillcycles" href="javascript:void(0);" title="Off Schedule" data-ng-click="offScheduleDialog(value.value.identity)"><span class="icon-view toolTip icon-edit"></span></a></td>';
                    }
					associatedEntitiesList.push(associatedEntitiesObj);
					
						
				});
		
		return associatedEntitiesList;
	}
	
function billScheduleType(billCycleType){
	var type = '';
	if(billCycleType != null && billCycleType != undefined && billCycleType != '') {
		if(billCycleType == 'MANUAL_REBILL') {
			type = 'Manual Rebill';
		} else if(billCycleType == 'REGULAR') {
			type = 'Regular';
		} else if(billCycleType == 'AUTO_REBILL') {
			type = 'Auto Rebill';
		} else if(billCycleType == 'OFF_SCHEDULE') {
			type = 'Off Schedule';
		} else if(billCycleType == 'REJECT') {
			type = 'Reject';
		} else if(billCycleType == 'REGENERATE') {
			type = 'Regenerate';
		}else if(billCycleType == 'AUTO_REGENERATE') {
			type = 'Auto Regenerate';
		}
	}
	return type;
}

function getFinancialRemitAdviceTransformer(data){
	
		var remitAdviceList = [];
		angular
		.forEach(
				data,
				function(value, key) {
					var remitAdviceObj = {};
					
					remitAdviceObj.identity =value.identity;
					remitAdviceObj.entityId=value.summary.generatedFor.owner.externalId;					
					remitAdviceObj.entityType=value.summary.generatedFor.owner.type;
					
					var profileType= value.summary.generatedFor.owner.profile.profile_type;
					if(profileType=="PersonalProfile"){
						remitAdviceObj.entityName=value.summary.generatedFor.owner.profile.firstName+
						" "+ value.summary.generatedFor.owner.profile.middleName +" "+
						value.summary.generatedFor.owner.profile.lastName;
					}
					else
						remitAdviceObj.entityName=value.summary.generatedFor.owner.profile.name;
					
					remitAdviceObj.date = convertDate(value.summary.generationDate.date);
					remitAdviceObj.amount = value.summary.netDueAmount.value;
					
					remitAdviceObj.action ='<a href="" title="View Remit" ng-click=""><span class="icon-view toolTip icon-pdf"></span></a>';;					 
					 remitAdviceList.push(remitAdviceObj);		
				});
		
		return remitAdviceList;
	}

	function removeTimeStamp(data) {
		if(data != null)
		{
			var date = data.split(" ")[0];
			return date;
		}
		return null;
	}
	
	function getPolicyRulesDataTransformer(data){
		
		var policyRulesList = [];
		angular
		.forEach(
				data.payload.policyConfigs,
				function(value, key) {
					var policyRulesObj = {};
					
					policyRulesObj.ruleName =value.name;
					policyRulesObj.ruleType=value.configType;					
					policyRulesObj.description=value.description;
	
					policyRulesObj.action ='<a href="" title="Remove" ng-click=""><span class="btn btn-red-delete tableBtn"></span>Remove</a>';
						
					 policyRulesList.push(policyRulesObj);
					
						
				});
		
		return policyRulesList;
	}

	function getAssociatedEntitesTransformer(data){
		
		var policyRulesList = [];
		angular
		.forEach(
				data.payload,
				function(value, key) {
					var policyRulesObj = {};
					
					policyRulesObj.entityId =value.businessEntity.externalId;
					policyRulesObj.entityType=value.businessEntity.type;					
					policyRulesObj.entityName=value.businessEntity.profile.displayName;
	
					policyRulesObj.action ='<a href="" title="Remove" ng-click=""><span class="btn btn-red-delete tableBtn"></span>Remove</a>';
						
					 policyRulesList.push(policyRulesObj);
					
						
				});
		
		return policyRulesList;
	}
	
	function getFinancialAccountsTransformer(data){
		
		var financialAccountsList = [];
		angular
		.forEach(
				data.content,
				function(value, key) {
					var financialAccountsObj = {};
					financialAccountsObj.accountId = value.accountId;
					financialAccountsObj.accountName =value.accountName;
					financialAccountsObj.creditDebit=value.accountType;		
					financialAccountsObj.accountBalance=value.totalSum;
					financialAccountsObj.value = value;
					financialAccountsObj.action ='<a href="#/financials/account-details?accountName='+financialAccountsObj.accountName+'" title="View Details" ng-click=""><span class="icon-view toolTip icon-view-details"></span></a>'+
					 '<span class="lineDivider"></span>'+'<a href="#/financials/financials-transactions-report" title="View Transactions" ng-click="publishFTEntries(value.value.ftEntries,value.accountName)"><span class="icon-view toolTip icon-entityList"></span></a>';;
					 
					financialAccountsList.push(financialAccountsObj);					
				});
		
		return financialAccountsList;
	}
	
	function getFinancialAccountDetailsTransformer(data){
		
		var financialAccountsList = [];
		angular
		.forEach(
				data.content,
				function(value, key) {
					var financialAccountsObj = {};
					
					financialAccountsObj.entityName=value.name;
					financialAccountsObj.accountName=value.accountName;
					financialAccountsObj.entity =value.externalId;
					financialAccountsObj.entityType=value.typeVal;
					financialAccountsObj.subscription=value.subscription;
					
					if(financialAccountsObj.entityType == 'SubsidyProvider'){
						financialAccountsObj.entityType = 'Subsidy Provider';
					}else if(financialAccountsObj.entityType == 'HealthPlanProvider'){
						financialAccountsObj.entityType = 'Health Plan Provider';
					}else if(financialAccountsObj.entityType == 'SuspenseEntity'){
						financialAccountsObj.entityType = 'Suspense Entity';
					}
					
					financialAccountsObj.accountBalance=value.totalSum;
					financialAccountsObj.action ='<a href="#/financials/financials-transactions-report" title="View Transactions" ng-click="publishFTEntries(value.entity,value.accountName)"><span class="icon-view toolTip icon-entityList"></span></a>';
					
					financialAccountsList.push(financialAccountsObj);					
				});
		
		return financialAccountsList;
	}
	function convertTime(date){
		
		var tempDt=new Date(date);
		var hh = tempDt.getHours(); 
		var mm = tempDt.getMinutes(); 
		var zz;
		if(hh<10){hh='0'+hh} ;
		if(mm<10){mm='0'+mm} ;
		
		if(hh>=12){zz="PM"}
		else{zz="AM"}
		return hh+":"+mm+" "+zz;

	}
	function convertDate(date){
		if(date == null)
			return "--";
        var now = new Date(date);
        var now_utc = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
        var dd = now_utc.getDate();
        var mm = now_utc.getMonth() + 1;//January is 0!
		if(mm < 10){
        	mm = '0'+mm;
        }
		if(dd<10){
			dd= '0'+dd;
		}
        var yyyy = now_utc.getFullYear();
		return mm+"/"+dd+"/"+yyyy;
	}

	function convertFormattedDate(date){
		var calender=[];
		calender[1]='Jan';
		calender[2]='Feb';
		calender[3]='Mar';
		calender[4]='Apr';
		calender[5]='May';
		calender[6]='Jun';
		calender[7]='July';
		calender[8]='Aug';
		calender[9]='Sep';
		calender[10]='Oct';
		calender[11]='Nov';
		calender[12]='Dec';
		
		if(date == null)
			return "--";
        var now = new Date(date);
        var now_utc = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
        var dd = now_utc.getDate();
        var mm = now_utc.getMonth() + 1;//January is 0!
        var yyyy = now_utc.getFullYear();
        
		return calender[mm]+" "+dd+","+yyyy;
	}
	
	
	
	// Dec 1, 2014
	//Added by HIMANSH
	function billingSummaryTransformer(data){
		var billingSummaryList = [];
		angular
		.forEach(
				data,
				function(value, key) {
					var billSummObj = {};
					billSummObj.date = value.date.date;
					billSummObj.type = value.type;
					billSummObj.description = value.description;
					billSummObj.amount  = value.amount.value;
					billSummObj.balance = value.balance.value;
					billingSummaryList.push(billSummObj);
				});
		return billingSummaryList;
	}
	//
	
	function unAssociatedPoliciesTransformer(data){
		var unAssociatedPoliicesList = [];
		angular
		.forEach(
				data,
				function(value, key) {
					var policyObj = {};
					policyObj.identity = value.identity;
					policyObj.identityCheckBox = '<input type="radio" name="unAssociatedPoliChk" id="unAssociatedPoliChk" ng-click="setUnAssociatedPolicy(value.identity,value.name)"/>';;
					policyObj.name = value.name;
					policyObj.description= value.description;
					policyObj.effectiveDate = convertDate(value.period.beginsOn.date);
					policyObj.terminationDate = convertDate(value.period.endsOn.date);
					unAssociatedPoliicesList.push(policyObj);
				});
		return unAssociatedPoliicesList;
	}
	
	function convertDateToTime(input){
		if(input != undefined && input != ''){
			var monthfield = input.split("/")[0]-1;
			var dayfield = input.split("/")[1];
			var yearfield = input.split("/")[2];
			var date = new Date(yearfield,monthfield,dayfield,0,0,0,0);
			return date.getTime();
		}else{
			return;
		}
	}
	