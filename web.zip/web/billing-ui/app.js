var hcentive = hcentive || {};
hcentive.WFM = {};
hcentive.WFM.configData = {};
hcentive.WFM.operator = "ngWFMOperator";
hcentive.WFM.customer = "ngWFMCustomer";
hcentive.WFM.broker = "ngWFMBroker";
hcentive.WFM.XPG_No_Login = "wfmXPG"
hcentive.WFM.beTypes = {
    "1": "individual",
    "2": "group",
    "3": "csr",
    "4": "broker",
    "5": "operator",
    "6": "wfm-admin"
};
hcentive.WFM.applicationContext = {
    "headers": {},
    "loggedInUser": {},
    "configuration": [],
    "beType": {},
    "contracts": [],
    "contextualContract": {}
};
hcentive.WFM.unSecured = {};
hcentive.WFM.unSecured[hcentive.WFM.XPG_No_Login] = "true";
hcentive.WFM.portals = {
    "1": "Individual",
    "2": "Group",
    "3": "Csr",
    "4": "Broker",
    "5": "Operator",
    "6": "wfm-admin"
};
//hcentive.WFM.clientDomains = {"individual.auth.wfm.com" : "Individual","operator.auth.wfm.com" : "Operator" , "broker.auth.wfm.com" : "Broker" , "group.auth.wfm.com" : "Group"};

////////////////////////////////////////////////////////////////////////////////////
// Set and get the cookie values
////////////////////////////////////////////////////////////////////////////////////    
function setStorage(c_name, value, expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value);
}

function getStorage(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=")
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1
            c_end = document.cookie.indexOf(";", c_start)
            if (c_end == -1) c_end = document.cookie.length
            return unescape(document.cookie.substring(c_start, c_end))
        }
    }
    return "";
}

function deleteStorage(name) {
    document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
};
jQuery.browser = {};
(function() {
    jQuery.browser.msie = false;
    jQuery.browser.version = 0;
    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
        jQuery.browser.msie = true;
        jQuery.browser.version = RegExp.$1;
    }
})();
$(function() {
    jQuery.event.handle = jQuery.event.dispatch
});

var console = console || {};
console.log = console.log || function(){};
console.debug = console.debug || console.log;
console.error = console.error || console.log;
console.info = console.info || console.log;
console.trace = console.trace || console.log;