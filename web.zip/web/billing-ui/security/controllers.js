//controllers available on bootstrap
hcentive.WFM.MainCtrl = [
    '$scope',
    '$routeParams',
    '$http',
     '$location', 'WFMAppContext', '$window' ,
    function ($scope, $routeParams, $http, $location, WFMAppContext , $window) {
    	
    	//$window.location.href = data;
        // $location.url($location.path());
        // application context set and available to application
        $scope.wfmAppContext = WFMAppContext;
		$scope.imagesLink = hcentive.WFM.clientConfigurations[0].imagesLink;
		$scope.passwordPattern = hcentive.WFM.clientConfigurations[0].passwordPattern;
		var genericEror = $('#genericError').val();
		var accessDenied = $('#accessDenied').val();
		if(genericEror){
			$location.path('/login/error');
			$location.replace();
			return;
		}
		else if(accessDenied == 'true'){
			$location.path('/login/accessDenied');
			$location.replace();
			return;
		}
		if($scope.wfmAppContext.refId != null && $scope.wfmAppContext.refId != undefined && $scope.wfmAppContext.refId != ''){
			$location.path('/login/associate');
			$location.replace();
		}else if(($scope.wfmAppContext.clientId != null && $scope.wfmAppContext.clientId != undefined && $scope.wfmAppContext.clientId != '')
		|| ($scope.wfmAppContext.responseType != null && $scope.wfmAppContext.responseType != undefined && $scope.wfmAppContext.responseType != '')
		){
			$location.path(hcentive.WFM.PortalLoginURL[$scope.wfmAppContext.clientId]);
			$location.replace();
		}
		

        // Variables for Left Navigation Menus
       
    } ];