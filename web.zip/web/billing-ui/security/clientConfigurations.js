hcentive.WFM.clientConfigurations = [
	{
		"loginUrl" :  "/userCredentialBasedAuth/login?client_id=",
		"imagesLink" : hcentive.WFM.securityImages + "/web/security/images",
		"customDomainURL" :  "/security/{enterpriseName}/oAuth2/initiate",
		"passwordPattern" : /^(?=[A-z0-9!@#$%^&*()]{8,20}$)(?=.*?[A-z])(?=.*?[!@#$%^&*()])(?=.*?\d).*$/ ,
		"userIdPattern" : /^[[0-9A-Za-z-@_\.]{8,20}$/
	}

];	

hcentive.WFM.PortalLoginURL = {
                                          
						  "ebill":"/login/login",
						  "customer":"/login/login",
						  "broker":"/login/login",
						  "billing":"/login/login",
						  "EbillMobile" : "/login/mobilelogin",
						  "individual" : "/login/login",
						  "group" : "/login/login",
						  "system" : "/login/login",
                         }       
 ;