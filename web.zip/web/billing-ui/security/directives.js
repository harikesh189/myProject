var getTemplateUrl = function(attr, defaultTemplateUrl) {
	if (attr.templateurl === undefined || attr.templateurl.length == 0) {
		return defaultTemplateUrl;
	}
	return attr.templateurl;
}

// calendar
hcentive.WFM.CalendarDir = [ function() {
	return {
		restrict : 'A',
		require : 'ngModel',
		link : function(scope, element, attrs, ngModelCtrl) {
			element.datepicker({
				dateFormat : 'mm/dd/yy',
				changeMonth : true,
				changeYear : true,
				showOn : "both",
				buttonImageOnly : true,
				buttonImage : "images/calender.png",
				onSelect : function(date) {
					scope[attrs.ngModel] = date;
					scope.$apply();
				}
			});
		}
	};
} ];

// cancel button
hcentive.WFM.CancelButtonDir = [ function() {
	var templateHTML = '<a href="{{url}}" class="btn btn-secondary ">Cancel </a>';
	return {
		restrict : 'EA',
		scope : {
			url : '@'
		},
		template : templateHTML

	};
} ];

// Next button
hcentive.WFM.NextButtonDir = [ function() {
	var templateHTML = '<a href="{{url}}" class="btn btn-primary ">Next </a>';

	return {
		restrict : 'EA',
		scope : {
			url : '@'
		},
		template : templateHTML
	};
} ];

/*
This directive allows us to pass a function in on an enter key to do what we want.
 */
hcentive.WFM.enterdir = [ function () {
	return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if(event.which === 13) {
                scope.$apply(function (){
                    scope.$eval(attrs.enterdir);
                });
 
                event.preventDefault();
            }
        });
    };
}];
