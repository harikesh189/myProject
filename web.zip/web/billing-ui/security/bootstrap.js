
//broker configuration
hcentive.WFM.configData[hcentive.WFM.security] = {
	"providers" : [ /*
					 * { "name" : "Media", "id" : hcentive.WFM.MediaProvider }
					 */],
	"services" : [ {
		"name" : "RESTSrvc",
		id : hcentive.WFM.RESTSrvc
	}],
	"directives" : [ 
	{
		"name": "enterdir",
		"id": hcentive.WFM.enterdir
	}
	],
	"filters" : [  ],
	"controllers" : [ {
		"name" : "MainCtrl",
		"id" : hcentive.WFM.MainCtrl
	} ],
	"includes" : [  ]
};

