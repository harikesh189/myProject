//services available on bootstrap
var genereateRequestConfig = function(_resourceKey, _params) {
	var paramsJson = {};
	var url = hcentive.WFM.serviceURL[_resourceKey];
	angular.forEach(_params, function(value, key) {
		if (url.search(":" + key) != -1) {
			url = url.replace(":" + key, value);
		} else {
			paramsJson[key] = value;
		}
	});
	var returnJson = {
		"url" : url,
		"paramsJson" : paramsJson
	};
	return returnJson;
};

var addTenantAndApp = function(_url,_tenant,_appKey){
	_url = _url.replace(":tenantId",_tenant);
	_url = _url + "?client_Id="+_appKey;
	return _url;
}

hcentive.WFM.RESTSrvc = [
		'$http',
		function($http) {						
			var getForData = function(_resourceKey, _params, transformer,
					_success, _error) {
					
			var currentTime = new Date().getTime();
			var requestConfig = genereateRequestConfig(_resourceKey,
						_params);
				$http({
					method : 'GET',
					url : requestConfig.url,
					params : requestConfig.paramsJson
				}).success(function(data) {
					if (transformer != undefined)
						_success(transformer(data));
					else
						_success(data);
				}).error(function(data) {
					_error(data);
				});
			};

			var postForData = function(_resourceKey, _params, _data,
					transformer, _success, _error) {
					
				var requestConfig = genereateRequestConfig(_resourceKey,
						_params);
				$http({
					method : 'POST',
					url : requestConfig.url,
					params : requestConfig.paramsJson,
					data : _data
				}).success(function(data) {
					if (transformer != undefined)
						_success(transformer(data));
					else
						_success(data);
				}).error(function(data) {
					_error(data);
				});

			};
			// rest interface
			return {
				getForData : getForData,
				postForData : postForData
			};
		} ];

// data sharing service
hcentive.WFM.EventBusSrvc = [
		'$rootScope',
		function($rootScope) {
			var cache = {};
			// publish edit data notification
			var publish = function(topic, payload) {
				// alert("published :: event " + topic);
				$rootScope.$emit(topic, payload);
				/*
				 * (cache[topic] && angular.forEach(cache[topic], function() {
				 * this.apply(null, payload || []); });
				 */
			};
			// register to edit data notification
			var register = function($scope, topic) {
				// alert("registered :: event " + topic);
				$scope.$onRootScope(topic, function(event, args) {
					if (!cache[topic] || cache[topic].length > 0) {
						cache[topic] = [];
					}
					cache[topic].push(args);
				});
			};
			// register to edit data
			var subscribeOnce = function(topic) {
				// alert("subscribed :: event " + topic);
				if (cache[topic] == null || cache[topic] == 'undefined'
						|| cache[topic][0] == null
						|| cache[topic][0] == 'undefined') {
					return null;
				}
				return cache[topic][0];
			};
			
			var subscribe  = function(topic, _scope, _callback) {
				if(angular.isDefined(_scope) && angular.isDefined(_callback)){
					_scope.$watch(function(){return subscribeOnce(topic);}, function(newVal,oldVal){
						_callback(newVal,oldVal);
					});
				}else{
					//alert("subscribed :: event 2 " + topic);
					return subscribeOnce(topic);
				}
			};
			return {
				publish : publish,
				register : register,
				subscribe : subscribe
			};
		} ];
