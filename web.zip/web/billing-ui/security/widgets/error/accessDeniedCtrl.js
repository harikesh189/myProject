hcentive.WFM.AccessDeniedCtrl = [
		'$scope',
		function($scope) {
			$scope.errorMessage = $('#errorMessage').val();
			var baseUrl  = window.location.href; 
			var baseUrl = baseUrl.substring(0, baseUrl.lastIndexOf('/error'));
			var logoutUrl = hcentive.WFM.serviceURL['logoutServiceUrl'];
			logoutUrl = baseUrl + logoutUrl+"?client_id="+$scope.wfmAppContext.clientId+"&response_type="+$scope.wfmAppContext.responseType;
			$scope.logoutUrl  = logoutUrl;
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.security].controllers.push({
	"name" : "accessDeniedCtrl",
	"id" : hcentive.WFM.AccessDeniedCtrl
});