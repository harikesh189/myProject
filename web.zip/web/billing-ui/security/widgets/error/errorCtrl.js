hcentive.WFM.ErrorCtrl = [
		'$scope',
		function($scope) {			
			$scope.errorCode = $('#errorCode').val();
			$scope.errorMessage = $('#errorMessage').val();
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.security].controllers.push({
	"name" : "errorCtrl",
	"id" : hcentive.WFM.ErrorCtrl
});