hcentive.WFM.ReRenderDiv = [function() {
	
	return {
		restrict : 'A',
		link : function(scope, iElement, iAttrs, ctrl) {
			var divId = iAttrs.renderdivid;
			$('#'+divId).trigger('refresh');
		}
	};
} ];

 hcentive.WFM.configData[hcentive.WFM.security].directives.push({
		"name" : "rerender",
		"id" : hcentive.WFM.ReRenderDiv
	});
