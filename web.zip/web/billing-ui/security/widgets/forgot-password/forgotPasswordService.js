hcentive.WFM.forgotPasswordSrvc = ['$http', 'RESTSrvc',function($http, RESTSrvc) {
	
	var verifyUser = function(data,successCallback, errorCallback) {
		var resourceUriKey = 'forgotPasswordVerifyUser';
		
		RESTSrvc.postForData(resourceUriKey,"",data,null,successCallback,errorCallback);
	}
		
	var provideSecurityInfo = function(data,successCallback, errorCallback) {
		var resourceUriKey = 'forgotPasswordSecurityInfo';
		
		RESTSrvc.postForData(resourceUriKey,"",data,null,successCallback,errorCallback);
	}
	
	var changePassword = function(data,successCallback, errorCallback){
		var resourceUriKey = 'forgotPasswordUpdate';
		RESTSrvc.postForData(resourceUriKey,"",data,null,successCallback,errorCallback);
	}
	return {
		verifyUser : verifyUser,
		provideSecurityInfo : provideSecurityInfo,
		changePassword : changePassword
	};
}];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.security].services.push({
	"name" : "forgotPasswordSrvc",
	"id" : hcentive.WFM.forgotPasswordSrvc
});
