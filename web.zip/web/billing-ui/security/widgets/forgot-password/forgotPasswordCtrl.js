hcentive.WFM.ForgotPasswordCtrl = [
		'$scope', 'forgotPasswordSrvc', '$location', 'NotifySrvc',
		function($scope ,forgotPasswordSrvc,$location, NotifySrvc) {
			
			$scope.successRedirectURL = '/login/login';
		
			$scope.userType = $scope.wfmAppContext.clientId;
			$scope.provideSecurityInfoData = {};
			
			var verifyUserSuccess = function(data){
				if (null == data || "" == data || data.identity==undefined) {
						$scope.succErrDialog('Invalid UserID','Please enter the correct User ID');
						} else {
							$('#forgotPssword').hide();
							$('#secAns').fadeIn("slow");
							$('#changePassword').hide();
							$scope.provideSecurityInfoData.identity = data.identity;
							$scope.provideSecurityInfoData.question1 = data.question1;
							$scope.provideSecurityInfoData.question2 = data.question2;
							$scope.provideSecurityInfoData.question3 = data.question3;							
						}
			}
			
			var verifyUserError = function(data){
				$scope.succErrDialog('Invalid UserID','Please enter the correct User ID');
			}
			$scope.verifyUserData = {};
			$scope.verifyUserFormSubmitted=false;
			$scope.verifyUser = function(isValid){
				$scope.verifyUserFormSubmitted=true;
				if(!isValid){return;}
				//var userName=$('#userID').val();
				//var data = "{\"userName\":\"" + userName + "\"}";
				forgotPasswordSrvc.verifyUser($scope.verifyUserData,verifyUserSuccess,verifyUserError);
			}
			
			var provideSecurityInfoSuccess = function(data){
				if(data=='true'){
					$('#form').hide();
					$('#secAns').hide();
					$('#changePassword').fadeIn("slow");
					}
					else{
						$scope.succErrDialog('Incorrect Answers','The answers were incorrect. Please try again !!');
					}
			}
			
			var provideSecurityInfoError = function(data){
				$scope.succErrDialog('Incorrect Answers','The answers were incorrect. Please try again !!');
			}
			$scope.provideSecurityInfoFormSubmitted=false;
			$scope.provideSecurityInfo = function(isValid){
				$scope.provideSecurityInfoFormSubmitted=true;
				if(!isValid){return;}
				forgotPasswordSrvc.provideSecurityInfo($scope.provideSecurityInfoData,provideSecurityInfoSuccess,provideSecurityInfoError);
			}
			
			var changePasswordSuccess = function(data){
				if(data=='SUCCESS'){
						$scope.succErrDialog('Password Changed','Password changed successfully !');
						$location.path($scope.successRedirectURL);
						$location.replace();
					}
					else{
						$scope.succErrDialog('Error','Error Occurred while changing password. Contact Administrator.');
					}
			}
			
			var changePasswordError = function(data){
				$scope.succErrDialog('Error','Error Occurred while changing password. Contact Administrator.');
			}
			$scope.changePasswordData = {};
			$scope.changePasswordFormSubmitted = false;
			$scope.isPasswordMatched = true;
			$scope.changePassword = function(isValid,successRedirectURL){
				if(successRedirectURL != undefined && successRedirectURL != ''){
					$scope.successRedirectURL = successRedirectURL;
				}
				$scope.changePasswordFormSubmitted = true;
				if(!isValid){return;}
				if($scope.changePasswordData.password != $scope.changePasswordData.confirmPassword ){
					$scope.isPasswordMatched = false;
					return;
				}
				$scope.provideSecurityInfoData.password = $scope.changePasswordData.password;
				forgotPasswordSrvc.changePassword($scope.provideSecurityInfoData,changePasswordSuccess,changePasswordError);
			}
			
			$scope.succErrDialog = function (title, msg) {
	            NotifySrvc({
	                id: 'simpleDialog',
	                template: '<div class="row-fluid">' + ' <p>' + msg
	                    + '</p>' + '</div>',
	                title: title,
	                backdrop: true,
	                success: {
	                    label: 'Ok',
	                    fn: function () {
	                    }
	                }
	            });
	        };
			
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.security].controllers.push({
	"name" : "forgotPasswordCtrl",
	"id" : hcentive.WFM.ForgotPasswordCtrl
});
