hcentive.WFM.activateBroker = [ function() {
	return {
		restrict : 'A',
		templateUrl : function(elem,attr){ alert("hi");return getTemplateUrl(attr,"activateBroker.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.security].directives.push({
	"name" : "activateBroker",
	"id" : hcentive.WFM.activateBroker
});