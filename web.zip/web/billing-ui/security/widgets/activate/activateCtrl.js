hcentive.WFM.ActivateCtrl = [
		'$scope', 'ActivateSrvc', '$location',
		function($scope ,ActivateSrvc,$location) {
			$scope.activateUser = {};
			$scope.activateUser.question1 = "Where were you when you first heard about 9/11?";
			$scope.activateUser.question2 = "What is your oldest sibling's birthday month and year?";
			$scope.activateUser.question3 = "In what city does your nearest sibling live?";
			$scope.userIdPattern = hcentive.WFM.clientConfigurations[0].userIdPattern;
			if($scope.wfmAppContext.refId != null && $scope.wfmAppContext.refId != undefined && $scope.wfmAppContext.refId != ''){
				$('#regForm1').hide();
				$('#regForm2').show();
				$scope.activateUser.userSearchDto = {};
				$scope.activateUser.userSearchDto.beIdentity = $scope.wfmAppContext.refId;
			}
			$scope.userType = $scope.wfmAppContext.clientAlias;
			$scope.associateUser = {};
			$scope.associateUserFormSubmitted = false;
			
			var associateSuccess = function(data){
				if (null == data || "" == data || data.identity==undefined) {
							showAssociateError();
						} else {
								$('#regForm1').hide();
								$('#regForm2').show();
								$scope.activateUser.identity = data.identity;
						}
			}
			
			var associateError = function(data){
				showAssociateError();
			}
			
			var showAssociateError = function(){
				if($scope.wfmAppContext.clientAlias == 'Operator'){
					alert("Invalid Activation Code");
				}else if($scope.wfmAppContext.clientAlias == 'Broker'){
					alert("Invalid Broker ID or NPN");
				}else if($scope.wfmAppContext.clientAlias == 'Individual'){
					alert("Invalid Subscriber ID or Date of Birth");
				}else if($scope.wfmAppContext.clientAlias == 'Group'){
					alert("Invalid Group ID or Group Name");
				}
			}
			
			$scope.associate = function(isValid){
				$scope.associateUserFormSubmitted = true;
				if(!isValid){return;}
				var data = JSON.stringify(getSearchCriteria($scope.userType));
				ActivateSrvc.associateUser(data,associateSuccess,associateError);
			}
			
			$scope.backToLogin = function(){
				$location.path('login/login');
				$location.replace();
			}
			function getSearchCriteria(userType) {
				var criteria = {};
				var data = {};
				var externalId="";
				if (userType == 'Individual') {
					externalId = $scope.associateUser.subscriberId;
					var dob=$('#dobM').val()+"/"+$('#dobD').val()+"/"+$('#dobY').val();
					data = createBESearchCriteria_Individual(userType,externalId,dob);
				} else if (userType == 'Broker') {
					externalId = $scope.associateUser.brokerId;
					var npn =$scope.associateUser.npn;
					data = createBESearchCriteria_Broker(userType,externalId,npn);
				} else if (userType == 'Group') {
					externalId = $scope.associateUser.groupId;
					var groupName=$scope.associateUser.groupName;
					data = createBESearchCriteria_Group(userType,externalId,groupName);
				} else if (userType == 'Operator') {
					var activationCode = $scope.associateUser.activationCode;
					data = createOperatorCriteria(userType,activationCode);

				}
				return data;
			}
			
			function createOperatorCriteria(userType,activationCode){
			var data ={};
			data.activationCode=activationCode;
			data.userType=userType;
			return data;
			}
			function createBESearchCriteria_Group(userType,externalId,groupName){
				var searchFilters = createExternalIdFilter(externalId,userType);
				searchFilters=addFilter(searchFilters,"profile.name","'"+groupName+"'","=",false);
				var searchCriteria= getSearchCriteriaJson(searchFilters,'','');
				return getBECriteria(searchCriteria,userType);
			}
			function createBESearchCriteria_Broker(userType,externalId,npn){
				var searchFilters = createExternalIdFilter(externalId,userType);
				var searchCriteria= getSearchCriteriaJson(searchFilters,'',npn);
				return getBECriteria(searchCriteria,userType);
			
			}
			function createBESearchCriteria_Individual(userType,externalId,dob){
				var searchFilters = createExternalIdFilter(externalId,userType);
				//searchFilters=addFilter(searchFilters,"profile.dateOfBirth","'"+dob+"'",'=',true);
				var searchCriteria= getSearchCriteriaJson(searchFilters,'','');
				return getBECriteria(searchCriteria,userType);
			
			}
			
			function createExternalIdFilter(externalId,userType){
			externalId=externalId.trim();
			userType=userType.trim();
			return addFilter(addFilter('', 'externalId', "'"+externalId+"'",'=', false),"type","'"+userType+"'","=",false);
			}
			function getBECriteria(criteria,userType){
			var data ={};
			data.searchCriteria=criteria;
			data.userType=userType;
			return data;
			}
			
			var activateSuccess = function(data){
				if(data == 'success'){
					alert("Account has been activated. Please login to proceed.");
					$location.path('/login/login');
					$location.replace();
				}else{
					alert('Unable to Activate');
				}
			}
			var activateError = function(data){
				alert('Unable to Activate');
			}
			$scope.activateUserSubmitted = false;
			$scope.isPasswordMatched = true;
			$scope.registerUser = function(isValid){
				$scope.activateUserSubmitted = true;
				if(!isValid){return ;}
				if($scope.activateUser.password != $scope.confirmPassword ){
					$scope.isPasswordMatched = false;
					return;
				}else{
					$scope.isPasswordMatched = true;
				}
				ActivateSrvc.registerUser($scope.activateUser,activateSuccess,activateError);
			}
			
			$scope.backToPreviousForm = function(){
				$('#regForm2').hide();
				$('#regForm1').show();
			}
			
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.security].controllers.push({
	"name" : "ActivateCtrl",
	"id" : hcentive.WFM.ActivateCtrl
});
