hcentive.WFM.ActivateSrvc = ['$http', 'RESTSrvc',function($http, RESTSrvc) {
	
	var associateUser = function(data,successCallback, errorCallback) {
		var resourceUriKey = 'associateUser';
		
		RESTSrvc.postForData(resourceUriKey,"",data,null,successCallback,errorCallback);
	}
	
	var registerUser = function(data,successCallback, errorCallback) {
		var resourceUriKey = 'registerUser';
		
		RESTSrvc.postForData(resourceUriKey,"",data,null,successCallback,errorCallback);
	}
			
	return {
		associateUser : associateUser,
		registerUser : registerUser
	};
}];

// wireup the service to application
hcentive.WFM.configData[hcentive.WFM.security].services.push({
	"name" : "ActivateSrvc",
	"id" : hcentive.WFM.ActivateSrvc
});
