hcentive.WFM.IndexDir = [ function() {
	return {
		restrict : 'A',
		templateUrl : function(elem,attr){return getTemplateUrl(attr,"../templates/header.html")}
	};
} ];

//wireup the directive to application
 hcentive.WFM.configData[hcentive.WFM.security].directives.push({
	"name" : "index",
	"id" : hcentive.WFM.IndexDir
});

