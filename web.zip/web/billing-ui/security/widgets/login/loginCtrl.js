hcentive.WFM.LoginCtrl = [
		'$scope', '$window','NotifySrvc',
		function($scope , $window , NotifySrvc) {
			
			$scope.availableIdps = angular.fromJson($('#availableIdps').val());
			$scope.userCredentialPrompt = $('#userCredentialPrompt').val();
			$scope.currentIdpKey = $('#currentIdpKey').val();
			$scope.errorCode = $('#errorCode').val();
			$scope.sessionTimedOutErrorMessage = $('#errorMessage').val();
			if($scope.sessionTimedOutErrorMessage == "null"){
				$scope.sessionTimedOutErrorMessage = "Your session has timed out!";
			}
			$scope.usingDefaultEnterprise = $('#usingDefaultEnterprise').val();
			$scope.customDomainProvided = false;
			$scope.loginUsingCustomDomain = function(){
				$scope.customDomainProvided = true;
			}
			
			$scope.checkValidateCustomDomain = function(){
				var customDomain = $('#customDomain').val();
				$scope.isInvalidUserMessage = false;
				$scope.showUserIdError = false;
				$scope.showPasswordError = false;
				$scope.showCustomDomainError = false;
				if (customDomain == "") {
					$scope.showCustomDomainError = true;
					return false;
				}
				var urlWithCustomDomain = createURLWithCustomDomain(customDomain);
				$("#loginForm").attr("action", urlWithCustomDomain);
				$("#loginForm").submit();
			}
			
			var createURLWithCustomDomain = function(customDomain){
				var domainName = window.location.hostname;
				var customDomainUrl = hcentive.WFM.clientConfigurations[0].customDomainURL;
				customDomainUrl = customDomainUrl.replace("{enterpriseName}",customDomain);
				return "https://" +domainName + "" + customDomainUrl + "?client_id="+$scope.wfmAppContext.clientId+"&response_type="+$scope.wfmAppContext.responseType;
			}
			
			$scope.submitToIdp = function(idpKey){
				$('#idpKey').val(idpKey);
				$( "#loginForm" ).submit();
			}
			
			$scope.callBackUrl = $('#callBackUrl').val();
			$scope.state = $('#state').val();
			$scope.invalidUserMessage = $('#invalidUserMessage').val();
			$scope.isInvalidUserMessage = false;
			if($scope.invalidUserMessage != '' && $scope.invalidUserMessage != null && $scope.invalidUserMessage != undefined && $scope.invalidUserMessage != 'null') {
				$scope.isInvalidUserMessage = true;
			}
			$('#invalidUserMessage').val('');
			
			$scope.constructLoginUrl = function(){
				var url  = window.location.href; 
				if(url.indexOf('/userCredentialBasedAuth') != -1){
					return url;
				}else if(url.indexOf('/error') != -1){
					url = url.substring(0, url.lastIndexOf('/error'));
				}else{
					url = url.substring(0, url.lastIndexOf('/oAuth2'));
				}
				
				var loginUrl = url+ hcentive.WFM.clientConfigurations[0].loginUrl;
				loginUrl = loginUrl+""+$scope.wfmAppContext.clientId+"&response_type="+$scope.wfmAppContext.responseType;
				return loginUrl;
			}
			
			$scope.userType = $scope.wfmAppContext.clientId;
			
			
			$scope.checkValidate = function(idpKey) {
				$scope.isInvalidUserMessage = false;
				$scope.showUserIdError = false;
				$scope.showPasswordError = false;
				$scope.showCustomDomainError = false;
				var username = $('#username').val();
				var password = $('#password').val();
				if (username == "" && password == "") {
					$scope.showUserIdError = true;
					$scope.showPasswordError = true;
					//$scope.succErrDialog('Credentials Required !','Please enter your User ID and Password to Login.');
					return false;
				}else if(username == "" ){
					$scope.showUserIdError = true;
					$scope.showPasswordError = false;
					return false;
				}else if(password == "" ){
					$scope.showUserIdError = false;
					$scope.showPasswordError = true;
					return false;
				} 
				$scope.loginUrl = $scope.constructLoginUrl();
				$("#loginForm").attr("action", $scope.loginUrl);
				$('#idpKey').val(idpKey);
				$('#submitLink').click(function(e) {
					e.preventDefault();
					$("#loginForm").submit();
				});
				$("#loginForm").submit();
				return true;
			};
			
			 $scope.succErrDialog = function (title, msg) {
		            NotifySrvc({
		                id: 'simpleDialog',
		                template: '<div class="row-fluid">' + ' <p>' + msg
		                    + '</p>' + '</div>',
		                title: title,
		                backdrop: true,
		                success: {
		                    label: 'Ok',
		                    fn: function () {
		                    }
		                }
		            });
		        };
			
		} ];

// wireup the controller to application
hcentive.WFM.configData[hcentive.WFM.security].controllers.push({
	"name" : "loginCtrl",
	"id" : hcentive.WFM.LoginCtrl
});
