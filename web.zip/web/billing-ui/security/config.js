hcentive.WFM.angularRoutingPath = '';
hcentive.WFMApp = function () {
    var appName = "";
    var domain = "";
    function getParameterByName(name) {
        var match = RegExp('[?&]' + name + '=([^&]*)').exec(
            window.location.href);
        return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
    }

    // start 'em up
    var start = function (application) {
    	domain = window.location.hostname;
    	hcentive.WFM.angularRoutingPath  = "https://"+domain+"/web/security/views";
        appName = application;
		var defaultAppContext = hcentive.WFM.applicationContext;
		var module = init(application, defaultAppContext);
		// startup Angular
		console.log("bootstrapping angular in unsafe mode!");
		loadApplicationContext(appName, getParameterByName('client_id'), getParameterByName('response_type'),getParameterByName('ref_id'),getParameterByName('client_alias'));
		angular.bootstrap(document, [ appName ]);
		return module;
		// load configuration and initialize the app
       
    };

    // if not already present, load configuration and initialize the app
    var loadApplicationContext = function (appName, clientId, responseType , refId, clientAlias) {
        hcentive.WFM.applicationContext.clientId = clientId;
		hcentive.WFM.applicationContext.responseType = responseType;
		hcentive.WFM.applicationContext.refId = refId;
		hcentive.WFM.applicationContext.clientAlias = clientAlias;
    };

    var init = function (appName, applicationContext) {
        console.log("wfmAppContext set!");
        // create the module
     // create the module
        var WFMApp = angular.module(appName, [ 'ngResource', 'ngRoute' ]).config(function($sceDelegateProvider) {
 $sceDelegateProvider.resourceUrlWhitelist([
   // Allow same origin resource loads.
   'self',
   // Allow loading from our assets domain.  Notice the difference between * and **.
   'http://localhost:8080/**',]);
   
 });

		WFMApp.constant("WFMAppContext", applicationContext);

        var routeView = function (params) {
            var view = hcentive.WFM.angularRoutingPath;
            var suffix = '.html';
            angular.forEach(params, function (value, param) {
                view += '/' + value;
            });
           return view += suffix;
             
        };

        // configure routes
        WFMApp
            .config([
                '$routeProvider',
                '$provide',
                function ($routeProvider, $provide) {
                    // routing
                    $routeProvider
                        .when('/:module', {
                            templateUrl: function (params) {
                                var routeParams = {};
                                routeParams['module'] = params.module;
                                var url = routeView(routeParams);
                                return url;
                            }
                        })
                        .when(
                        '/:module/:page',
                        {

                            templateUrl: function (params) {
                                var routeParams = {};
                                routeParams['module'] = params.module;
                                routeParams['page'] = params.page;
                                var url = routeView(routeParams);
                                return url;
                            }
                        })
                        .when(
                        '/:module/:submodule/:page',
                        {
                            templateUrl: function (params) {
                                var url = routeView(params);
                                return url;
                            }
                        }).otherwise({
                            redirectTo: hcentive.WFM.landingPage
                        });
                    // eventing clean-up
                    $provide
                        .decorator(
                        '$rootScope',
                        [
                            '$delegate',
                            function ($delegate) {
                                Object
                                    .defineProperty(
                                    $delegate.constructor.prototype,
                                    '$onRootScope',
                                    {
                                        value: function (name, listener) {
                                            var unsubscribe = $delegate
                                                .$on(
                                                name,
                                                listener);
                                            this
                                                .$on(
                                                '$destroy',
                                                unsubscribe);
                                        },
                                        enumerable: false
                                    });
                                return $delegate;
                            } ]);
                } ]);

        // bootstrap configuration
		if(typeof hcentive.WFM.configData[appName] !== "undefined"){
			angular.forEach(hcentive.WFM.configData[appName].providers, function (provider) {
				// wireup providers
				WFMApp.provider(provider.name, provider.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].services, function (service) {
				// wireup services
				WFMApp.factory(service.name, service.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].directives, function (directive) {
				// wireup directives
				WFMApp.directive(directive.name, directive.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].filters, function (filter) {
				// wireup filters
				WFMApp.filter(filter.name, filter.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].controllers, function (controller) {
				// wireup controllers
				WFMApp.controller(controller.name, controller.id);
			});
		}
        return WFMApp;
    };
    return {
        start: start
    };
}();