var genereateRequestURLConfig = function (_resourceKey, _params) {
    var paramsJson = {};
    var url = hcentive.WFM.serviceURL[_resourceKey];
    if (null != _params) {
        $.each(_params, function (key, value) {
            if (url.search(":" + key) != -1) {
                url = url.replace(":" + key, value);
            } else {
                paramsJson[key] = value;
            }
        });
    }
    var returnJson = {
        "url": url,
        "paramsJson": paramsJson
    };
    return returnJson;
}
/**
 * @ngdoc service
 * @name wfmSecurity.factory:wfmSecuritySrvc
 * @description $http REST interface
 */
var wfmRESTSrvc = function () {

    var getForData = function (_resourceKey, headers, _params, _success, _error) {

        var requestConfig = genereateRequestURLConfig(_resourceKey,
            _params);

        var setHeader = function (xhr) {
            if (null != headers) {
                $.each(headers, function (key, value) {
                    if (key == 'passKey' && value != "") {
                        xhr.setRequestHeader('securityKey', value);
                    } else if (key != 'securityKey') {
                        xhr.setRequestHeader(key, value);
                    }
                });
            }
        };

        $.ajax({
            url: requestConfig.url,
            type: "GET",
            contentType: "application/json",
            success: function (result) {
                _success(result);
            },
            error: function (xhr, ajaxOptions, thrownError) {
                _error(thrownError);
            },
            beforeSend: setHeader
        });
    };
    
    var postForData = function (_resourceKey, headers, _params, _data, _success, _error) {

        var requestConfig = genereateRequestURLConfig(_resourceKey,
            _params);
        
        var url = requestConfig.url;
        
        var setHeader = function (xhr) {
            if (null != headers) {
                $.each(headers, function (key, value) {
                    if (key == 'passKey' && value != "") {
                        xhr.setRequestHeader('securityKey', value);
                    } else if (key != 'securityKey') {
                        xhr.setRequestHeader(key, value);
                    }
                });
            }
        };

        $.ajax({
            url: url,
            type: "POST",
            data: JSON.stringify(_data),
			xhrFields: {
                withCredentials: true
			},
			crossDomain: true,
            contentType: "application/json",
            success: function (result) {
                _success(result);
            },
            error: function (xhr, ajaxOptions, thrownError) {
                _error(thrownError);
            },
            beforeSend: setHeader
        });
    };
    // rest interface
    return {
        getForData: getForData,
        postForData: postForData
    }
}();


/**
 * @ngdoc service
 * @name wfmSecurity.factory:wfmSecuritySrvc
 * @description Security Service manager for wfm
 */
var wfmSecuritySrvc = function () {
    var getSecurityHeaders = function (params, data, success, error) {
        var resourceUriKey = 'securityService';
        wfmRESTSrvc.postForData(resourceUriKey, null, params, data, success, error);
    };

    var getAppUser = function (headers, success, error) {
        var resourceUriKey = 'securityUserService';
        wfmRESTSrvc.getForData(resourceUriKey, headers, null, success, error);
    };

    return {
        getSecurityHeaders: getSecurityHeaders,
        getAppUser: getAppUser
    };
}();

/**
 * @ngdoc service
 * @name wfmSecurity.factory:wfmConfigSrvc
 * @description Configuration Service manager for wfm
 */
var wfmConfigSrvc = function () {
    var getViewContext = function (headers, params, success, error) {
        var resourceUriKey = 'configService';
        wfmRESTSrvc.postForData(resourceUriKey, headers, params, null, success, error);
    };

    return {
        getViewContext: getViewContext
    };
}();