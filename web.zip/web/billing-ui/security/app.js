var hcentive = hcentive || {};
hcentive.WFM = {};
hcentive.WFM.configData = {};
hcentive.WFM.security = "ngWFMSecurity";
hcentive.WFM.beTypes = {"1": "individual", "2": "group", "3": "csr", "4": "broker", "5": "admin", "6": "WfmOperator"};
hcentive.WFM.applicationContext = {"clientId": "", "responseType": ""  , "refId" : "" , "clientAlias" : ""};

////////////////////////////////////////////////////////////////////////////////////
// Set and get the cookie values
////////////////////////////////////////////////////////////////////////////////////    
function setStorage(c_name, value, expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value);
}

function getStorage(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=")
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1
            c_end = document.cookie.indexOf(";", c_start)
            if (c_end == -1) c_end = document.cookie.length
            return unescape(document.cookie.substring(c_start, c_end))
        }
    }
    return "";
}

function deleteStorage(name) {
    document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
};