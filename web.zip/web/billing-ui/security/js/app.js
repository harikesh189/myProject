
function noCarrier(){
	alert("No carrier authentication server provisioned. Please contact system adminstrator.");
	return false;
}
		
function getUserType(){
	var userType = $('select#userType').val();
	if( userType == '' || userType == undefined || userType == 'none'){
		userType = getParameterByName('client_id');
	}
	return userType;
}

 function getParameterByName(name) {
		var match = RegExp('[?&]' + name + '=([^&]*)').exec(
			window.location.href);
		return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
	}

 function takeToLogin(){
	 var userType = getUserType();
	 var clientAlias = $( "#userType option:selected" ).text();
	 var action = $('#showAppsForm').attr('action');
	 if(userType == "" || userType == undefined || userType == 'none'){
			return false;
		}
	var responseType = getParameterByName('response_type');
	if( responseType == null || responseType == undefined || responseType == '' || invalidUserMessage != '' ){
		var action = action + "?client_id="+userType+"&response_type=token&client_alias="+clientAlias;
		$('#showAppsForm').attr('action',action);
	}
	$('#showAppsForm').submit();
 }
