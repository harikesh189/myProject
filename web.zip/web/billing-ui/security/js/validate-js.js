$(document)
		.ready(
				function(e) {

					$("#regForm1").validate({
						onfocusout : function(element) {
							$(element).valid();
						},
						validClass : "success",
						rules : {
							groupID : {
								required : true,
								minlength : 3, // will count space
								maxlength : 200
							},
							gName : {
								required : true,
								minlength : 3, // will count space
								maxlength : 200
							},
							subscriberId : {
								required : true,
								minlength : 3, // will count space
								maxlength : 200
							},
							dobM : {
								required : true
							},
							dobD : {
								required : true
							},
							dobY : {
								required : true
							},
							brokerId : {
								required : true
							},
							NPN : {
								required : true
							},
							activationCode : {
								required : true
							}
						},
						messages : {
							groupID : {
								required : "Please enter GroupId"
							},
							gName : {
								required : "Please enter Group Name"
							},
							subscriberId : {
								required : "Please enter SubscriberId"
							},
							dobM : {
								required : "Month can not be Empty"
							},
							dobD : {
								required : "Date can not be Empty"
							},
							dobY : {
								required : "Year can not be Empty"
							},
							brokerId : {
								required : "Please enter Broker Id"
							},
							NPN : {
								required : "Please Enter NPN"
							},
							activationCode : {
								required : "Please Enter ActivationCode"
							}
						}

					});
					$("#regForm2")
							.validate(
									{
										onfocusout : function(element) {
											$(element).valid();
										},
										validClass : "success",
										submitHandler : function(form) {
											form.submit();
											alert('Successfully registered. Please wait for registration approval.');
										},
										rules : {
											answer1 : {
												required : true,
												minlength : 3, // will count
																// space
												maxlength : 200
											},
											answer2 : {
												required : true,
												minlength : 3, // will count
																// space
												maxlength : 200
											},
											answer3 : {
												required : true,
												minlength : 3, // will count
																// space
												maxlength : 200
											},
											userName : {
												required : true,
												// digits: true,
												// number: true, // as space is
												// not a number it will return
												// an error
												minlength : 10, // will count
																// space
												maxlength : 50

											},
											password : {
												required : true,
												minlength : 8, // will count space 
												maxlength : 20
											},
											confirm_new_password : {
												required : true,
												minlength : 8, // will count space 
												maxlength : 20,
												equalTo : "#new_password"
											}
										},
										messages : {
											answer1 : {
												required : "Please enter security answer 1"
											},
											answer2 : {
												required : "Please enter security answer 2"
											},
											answer3 : {
												required : "Please enter security answer 3"
											}
										}

									});
				});