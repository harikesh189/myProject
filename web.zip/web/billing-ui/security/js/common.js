
/*=======================OPerator Search=======================*/
$(function(){
	
	// Rules home table - delete and assign & unassign functionality
$('table tr td .icon-remove').bind({
  click: function() {
	  //alert("This will remove the selected notification");
	$(this).parents("tr").addClass("currentRow");
		$.msgBox({
		title: "Are You Sure?",
		content: "This will remove the record.",
		type: "confirm",
		buttons: [{ value: "Yes" },{ value: "Cancel"}],
		success: function (result) {
			if (result == "Yes") {
				$("tr.currentRow").hide();
				}else if(result == "Cancel"){
					$("tr.currentRow").removeClass("currentRow");
				}
			}
		});
  },
});
		
		var leftHeight = $('.leftBox').height();
		var rightHeight = $('.rightBox').height();
		if(rightHeight > leftHeight){
			$('.leftBox > .whiteBox').css('min-height',rightHeight - 37 );
		}


	$('#logout-link').bind({
		 click: function() {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Are You Sure?",
			content: "You want to Logout.",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					window.location.href = "../../index.html";
					}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   });
	 }
	});
	
	$('.btnLink').on('click', function(e){
		//e.preventDefault;
		/*var dueDate ;
		var suspense = $(this).closest("tr").find('.suspense').text();
		var outstanding = $(this).closest("tr").find('.total-outstanding').text();
		
		dueDate = 7;
		
		$('.billingDetail > li:first-child > .value').html(outstanding);
		$('.billingDetail > li:nth-child(2) > .value').html(suspense);
		$('.billingDetail > li:nth-child(3) > .value').html(dueDate);*/
		// To Store
    	/*$.session.set("sessOutstanding", outstanding);
		$.session.set("sessSuspense", suspense);
		$.session.set("sessDueDate", dueDate);*/
		
	})
	/*$('.billingDetail > li:first-child > .value').html($.session.get("sessOutstanding"));
		$('.billingDetail > li:nth-child(2) > .value').html($.session.get("sessSuspense"));
		$('.billingDetail > li:nth-child(3) > .value').html($.session.get("sessDueDate"));
	
	
		var storedValue = $.session.get("sessOutstanding")
		var payableAmount = storedValue.replace('$', '') - 10;
		
		var amountToPay = $.session.get("sessOutstanding")
		$('.amountToPay').html(amountToPay);
		$('.payableAmount').html('$' + payableAmount + '.00');*/

	
	//Make a quick payment
	$('.js-quick-pay').on({
		 click: function() {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Are You Sure?",
			content: "There are currently no preferred payment methods saved for your account.<a href='payment-methods.html'> CLICK HERE</a> to save a new payment method for making faster payments in the future.",
			type: "confirm",
			buttons: [{ value: "OK" }],
			success: function (result) {
				if (result == "Yes") {
					window.location.href = "#";
					}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   });
	 }
	});
	
	
	 $('.mainArticle .table-striped tbody tr:odd td, .mainArticle .table-striped tbody tr td tr:odd td').css('backgroundColor', '#ffffff');
	$('.mainArticle .table-striped tbody tr:even td, .mainArticle .table-striped tbody tr td tr:even td').css('backgroundColor', '#f8f8f8');

	$('#js-sideBarBtn').on('click', function(){
		var self, sideBar, content;
		
		self = $(this);
		sideBar = $('.mainSidebar');
		content = $('.contentContainer');
		
		if(self.hasClass('collapseBtn')) {
			sideBar.animate({
				width: 200
			},function() {
				sideBar.find('.text').show();
			});
			
			content.animate({
				'margin-left': 200
			});
			
			self.removeClass('collapseBtn').addClass('expandBtn');
		}
		
		 else if(self.hasClass('expandBtn')) {
			sideBar.find('.text').hide();
			$('.searchOperator').hide();
			$('.js-searchBtn-operator').show();
			sideBar.animate({
				width: 70
			});
			
			self.removeClass('expandBtn').addClass('collapseBtn');
			
			content.animate({
				'margin-left': 70
			});
		}
	});
	
	  if($('#js-sideBarBtn').hasClass('expandBtn')) {
		  sideBar = $('.mainSidebar');
		  content = $('.contentContainer');
		 sideBar.animate({
				width: 200
			},function() {
				sideBar.find('.text').show();
			});
			
			content.animate({
				'margin-left': 200
			});
			
		}
	 
});
$(document).on('click', '.js-searchBtn-operator', function(){
	var className = $(this).parent().parent().prev().attr('class');
	if(className == 'expandBtn'){
		$(this).hide();
		$('.searchOperator').show();
	}
});
//end
$(document).ready(function () {
	//$('.profile').on('click',function(){
	//	$('.profileAccountBox').slideToggle('2000', "jswing", function () { });
	//});
	
	$('.profile').click(function(e){ // <----you missed the '.' here in your selector.
    e.stopPropagation();
    $('.profileAccountBox').slideToggle();
	});
	$('.profileAccountBox').click(function(e){
		e.stopPropagation();
	});
	$(document).click(function(){
		 $('.profileAccountBox').slideUp();
	});
	
	// Notification page
	$('.js-notificationSetting').on('click', function(){
		$('.js-changePasswordBox').hide();
		$(this).hide();
		$('.js-changePassword').show();
		$('.js-notificationBox').show();
	});
	$('.js-changePassword').on('click', function(){
		$('.js-notificationBox').hide();
		$(this).hide();
		$('.js-changePasswordBox').show();
		$('.js-notificationSetting').show();
	});
	
	
	// For Notify
	$('.billMe').on('click', function(){
		$('.cnfArea').slideDown();
	});
	$('.payBtnClk').on('click', function(){
		$('.jumptothanks').hide();
		$('.paidPage').show();
		 
	});
	
	//to delete row
	$('.detLnk').on('click', function(){
		$(this).parents(".cardRow").hide();
	});
	
	
$('table.tableNotification tr td img').hide();
	$('table.tableNotification tr').bind({
		mouseenter: function() {
		$(this).find("img").show();
 	},
		mouseleave: function() {
		$(this).find("img").hide();
 	}
});
	
	
$('table.tableNotification tr td img').bind({
  click: function() {
	  //alert("This will remove the selected notification");
    $(this).parents("tr").addClass("currentRow");
		$.msgBox({
		title: "Are You Sure?",
		content: "This will remove the selected notification",
		type: "confirm",
		buttons: [{ value: "Yes" },{ value: "Cancel"}],
		success: function (result) {
			if (result == "Yes") {
				$("tr.currentRow").hide();
				}else if(result == "Cancel"){
					$("tr.currentRow").removeClass("currentRow");
				}
			}
		});
  },
  mouseenter: function() {
    $(this).attr('src','../images/delRowIcnClk.png');
  },
   mouseleave: function() {
    $(this).attr('src','../images/delRowIcn.png');
  }
});


$('li.notify1').bind({
  mouseenter: function() {
    $(this).find(".topNote").show();
  },
   mouseleave: function() {
   $(this).find(".topNote").hide();
  }
});
	
	
	
	$(".slideArea p").slideUp();
	$(".slideArea h3").click(function() {
	  $(this).next("p").slideToggle('fast', function() {});
	  $(this).find("span").toggleClass("active");
	});
	
	//Search Button
	$('.js-search').on('click', function(){
		$(this).hide();
		$('.searchInput').slideDown();
	});
	
	//Keep Track
	/*------------For Table*/
	
	$('#acAct').dataTable(
	 {
		"aaSorting": [[ 1, "desc" ]],
		"bFilter": false,
		"sPaginationType": "full_numbers",
		"sDom": "t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": false
		},
		"aoColumnDefs": [
		   { 'bSortable': true, 'aTargets': [ 0,0 ] },	
		  
		   { "aTargets" : ["uk-date-column"] , "sType" : "uk_date"},
		   { "aTargets" : ["uk-currency-column"] , "sType" : "currency"}
       		],
		} 
	);
	$('#brokertbl').dataTable(
	  {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       		]
		} 
	);
	
	var myTable1=$('#brokertbl').dataTable();
	$('#brokertbl_filter input').attr('placeholder','Broker Id');
	
	
	var oTable =  $('#sortTable').dataTable(
	 {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6,0 ] }
       		]
		} 
	);
	var myTable1 = $('#sortTable').dataTable();
	$('#sortTable_filter input').attr('placeholder','Type');
	
	
	
	
	var oTable =  $('#paymentHistory').dataTable(
	 {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6] }
       		]
		} 
	);
	var myTable2 = $('#paymentHistory').dataTable();
	$('#paymentHistory_filter input').attr('placeholder','Transaction ID');
	
	
	

	var oTable = $('#sortTableNoSearch').dataTable(
	 {
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 5 ] }
       		]
		} 
	);
	
	 
	$('.dataTables_filter input').after('<a href="#" class="search-box"><span class="icon-search-submit"></span> Search</a>');
	
	
	
	$('#egar').dataTable(
	 {
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": []
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       		]
		} 
	);
	$('#sortTable1').dataTable(
	 {
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 7 ] }
       		]
		} 
	);
	$('#sortTable2').dataTable(
	 {
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       		]
		} 
	);
	$('#sortTable3').dataTable(
	 {
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 4 ] }
       		]
		} 
	);
	
	$('#sortTable4').dataTable(
	 {
		"sPaginationType": "full_numbers",
		"bAutoWidth": false,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,8 ] }
       		]
		} 
	);
	$('#sortTable5').dataTable(
	 {
		"sPaginationType": "full_numbers",
		"bAutoWidth": false,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,6 ] }
       		]
		} 
	);
	
		$('#keepTrackInd').dataTable(
	 {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
		   { 'bSortable': false, 'aTargets': [ 0,6 ] },	
		  
		   { "aTargets" : ["uk-date-column"] , "sType" : "uk_date"},
		   { "aTargets" : ["uk-currency-column"] , "sType" : "currency"}
       		],
			
			
		} 
	);
	
	// add multiple select / deselect functionality
	$("#selectall").click(function () {
		 if ($(this).prop('checked')==true){ 
		  $('.case').prop('checked', true);
		 }
		 if ($(this).prop('checked')==false){ 
		   $('.case').prop('checked', false);
		 }
		  
	})
	$(".case").click(function(){
		if($(".case").length == $(".case:checked").length) {
			$("#selectall").attr("checked", "checked");
		} else {
			$("#selectall").removeAttr("checked");
		}
	});
 
 
    // if all checkbox are selected, check the selectall checkbox
    // and viceversa
    
	$("#addEmail").click(function () {
		 if ($(this).prop('checked')==true){ 
		  $('.addEmail').slideDown();
		 }
		 if ($(this).prop('checked')==false){ 
		    $('.addEmail').slideUp();
		 }
		  
	})
		
		

});
/*=============Tipsy=================*/
$('.replaceInvoice, .deleteInvoice, .showTitle').tipsy({gravity: 'n',});
$('.graphtips').tipsy({gravity: 'w',});
$('.invoiceDetailsBtn').tipsy({gravity: 'w',});
/*$('#setting-tips, #search-tips, #reports-tips, #add-customer-tips, #groups-tips, #individuals-tips, #invoice-tips, #payment-tips, #batchqueue-tips, #announcement-tips, #track-user-tips, #manage-user-tips, #profile-info-tips, #preferences-tips, #message-tips, #rules-tips').tipsy({gravity: 'w',});
*/

// for checkbox and radio button
/*;(function(){
$.fn.customRadioCheck = function() {
  return this.each(function() {
 
    var $this = $(this);
    var $span = $('<span/>');
 
    $span.addClass('custom-'+ ($this.is(':checkbox') ? 'check' : 'radio'));
    $this.is(':checked') && $span.addClass('checked'); // init
    $span.insertAfter($this);
 
    $this.parent('label').addClass('custom-label')
      .attr('onclick', ''); // Fix clicking label in iOS
    // hide by shifting left
    $this.css({ position: 'absolute', left: '-9999px' });
 
    // Events
    $this.on({
      change: function() {
        if ($this.is(':radio')) {
          $this.parent().siblings('label')
            .find('.custom-radio').removeClass('checked');
        }
        $span.toggleClass('checked', $this.is(':checked'));
      },
      focus: function() { $span.addClass('focus'); },
      blur: function() { $span.removeClass('focus'); }
    });
  });
};
	
}());*/
// UK Date Sorting 
jQuery.fn.dataTableExt.oSort['uk_date-asc']  = function(a,b) { 

    var ukDatea = a.split('-'); 
    var ukDateb = b.split('-'); 
     
    var x = (ukDatea[2] + ukDatea[0] + ukDatea[1]) * 1; 
    var y = (ukDateb[2] + ukDateb[0] + ukDateb[1]) * 1; 
    return ((x < y) ? -1 : ((x > y) ?  1 : 0)); 
}; 
 
jQuery.fn.dataTableExt.oSort['uk_date-desc'] = function(a,b) { 
    var ukDatea = a.split('-');
    var ukDateb = b.split('-'); 
     
    var x = (ukDatea[2] + ukDatea[0] + ukDatea[1]) * 1; 
    var y = (ukDateb[2] + ukDateb[0] + ukDateb[1]) * 1; 
     
    return ((x < y) ? 1 : ((x > y) ?  -1 : 0)); 
}

jQuery.fn.dataTableExt.oSort['currency-asc'] = function(a,b) {
     /* Remove any commas (assumes that if present all strings will have a fixed number of d.p) */
      var x = a == "-" ? 0 : a.replace( /,/g, "" );
      var y = b == "-" ? 0 : b.replace( /,/g, "" );

      /* Remove the currency sign */
      x = x.substring( 1 );
      y = y.substring( 1 );

      /* Parse and return */
      x = parseFloat( x );
      y = parseFloat( y );
      return x - y;
};

jQuery.fn.dataTableExt.oSort['currency-desc'] = function(a,b) {
      /* Remove any commas (assumes that if present all strings will have a fixed number of d.p) */
      var x = a == "-" ? 0 : a.replace( /,/g, "" );
      var y = b == "-" ? 0 : b.replace( /,/g, "" );

      /* Remove the currency sign */
      x = x.substring( 1 );
      y = y.substring( 1 );

      /* Parse and return */
      x = parseFloat( x );
      y = parseFloat( y );
      return y - x;
};

$('#sortTableFull').dataTable(
	 {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
		   { 'bSortable': false, 'aTargets': [ 0,8 ] },	
		  
		   { "aTargets" : ["uk-date-column"] , "sType" : "uk_date"},
		   { "aTargets" : ["uk-currency-column"] , "sType" : "currency"}
       		],
			
			
	} 
);

$('#sortTableFullGrp').dataTable(
	 {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
		   { 'bSortable': false, 'aTargets': [ 0,7 ] },	
		  
		   { "aTargets" : ["uk-date-column"] , "sType" : "uk_date"},
		   { "aTargets" : ["uk-currency-column"] , "sType" : "currency"}
       		],
			
			
	} 
);
$('#sortTableFullInd').dataTable(
	 {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"copy",
				"print",
				"csv",
				 "xls",
				  "pdf"
				
			]
		},
		"aoColumnDefs": [
		   { 'bSortable': false, 'aTargets': [ 0,7,8 ] },	
		  
		   { "aTargets" : ["uk-date-column"] , "sType" : "uk_date"},
		   { "aTargets" : ["uk-currency-column"] , "sType" : "currency"}
       		],
			
			
	} 
);



$('.dropArrow').on('click',function(){
	$(this).toggleClass('dropArrow-active');
	$('.more-option').toggleClass('openMoreOption');
});
$('.cancel, .moreOptionsSave').on('click',function(){
	$('.more-option').removeClass('openMoreOption');	
	$('.dropArrow').toggleClass('dropArrow-active');
});

$('.uploadButton').on('click',function(){
	$('.upload-option').toggleClass('openUploadOption');
	$(this).toggleClass('uploadButton-active');
		
});
$('.cancel, .uploadOptionsSave').on('click',function(){
	$('.upload-option').removeClass('openUploadOption');	
	$('.uploadButton').toggleClass('uploadButton-active');
});


// RMHP Reports
$('#sortTableNoSearchNoIcons').dataTable(
	 {
		
		"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": false
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 3 ] }
       		]
		}
		
	);
	// Broker - Homepage
	$('#sortTableNoBrokerHome').dataTable(
	 {
		
		"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": false
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 7 ] }
       		]
		}
		
	);
	
	$('#sortTableNoSearchClients').dataTable(
	 {
		
		"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": false
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       		]
		}
		
	);
		$('#sortTableNoSearchClientsgrp').dataTable(
	 {
		
		"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": false
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 7 ] }
       		]
		}
		
	);


//Tooltips
$('.toolTip').tipsy({gravity: 'w',});

$('.toolTip1').tipsy({gravity: 'e'});
$('.toolTipDelete').tipsy({gravity: 'n'});



// Individual Home Page

	$( "#startDate" ).datepicker({
			 showOn: "both",
            buttonImage: "../images/calender.png",
            buttonImageOnly: true,
			buttonText: "Calender",
			defaultDate: "+1w",
      		changeMonth: true,
      		changeYear: true,
      		onClose: function( selectedDate ) {
        		$( "#endDate" ).datepicker( "option", "minDate", selectedDate );
				var fromDateVal = $("#startDate").val();
				$("#startDate").attr('value',fromDateVal);
				
     		 }
		});

		
		$( "#endDate" ).datepicker({
			 showOn: "both",
            buttonImage: "../images/calender.png",
            buttonImageOnly: true,
			buttonText: "Calender",
     	 	defaultDate: "+1w",
     	 	changeMonth: true,
			changeYear: true,
     	 	onClose: function( selectedDate ) {
      	  		$( "#startDate" ).datepicker( "option", "maxDate", selectedDate );
				var toDateVal = $("#endDate").val();
				$("#endDate").attr('value',toDateVal);
	
      		}
   	 });
	 
	 

// View Bills

var oTable =  $('#viewBIlls').dataTable(
	 {   
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"oLanguage": { "sSearch": "" } ,
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 7,0 ] }
       		]
		} 
	);
	
	
	$('.dataTables_filter input').unbind();
	
	$('.dataTables_filter input').bind('keyup', function(e) {
       if(e.keyCode == 13) {
        oTable.fnFilter(this.value);   
    }
   });  
   
	var myTable = $('#viewBIlls').dataTable();
	$('#viewBIlls_wrapper .dataTables_filter input').attr('placeholder','Invoice Id');
	//$('#viewBIlls_wrapper .dataTables_filter input').after('<a href="#" class="search-box"><span class="icon-search-submit"></span> Search</a>');
	
	 

	$('#viewBIlls > tbody > tr.dataRow1').after('<tr class="dataRow1Data" style="display:none; padding: 10px 0;"><td></td><td colspan="8" style="background: #e0dddd !important; padding: 7px;"><table class="table innerTable"><tr class="odd"><td>Premiums for Coverage Period</td><td class="text-right"> $5343.75</td></tr><tr class="even"><td>Amount Due from Prior</td><td class="text-right">$0.00</td></tr><tr class="odd"><td>Payments Applied</td><td  class="text-right">$0.00</td></tr><tr  class="even"><td>Adjustments Applied</td><td class="text-right">$0.00</td></tr></table></td></tr>');
	
	$('#viewBIlls > tbody > tr.dataRow3').after('<tr class="dataRow3Data" style="display:none; padding: 10px 0;"><td></td><td colspan="8" style="background: #e0dddd !important; padding: 10px 7px;"><table class="table innerTable"><tr class="odd"><td>Premiums for Coverage Period</td><td> $1,750.00</td></tr><tr class="even"><td>Amount Due from Prior</td><td>$0.00</td></tr><tr class="odd"><td>Payments Applied</td><td>$1,750.00</td></tr><tr class="even"><td>Adjustments Applied</td><td>$0.00</td></tr></table></td></tr>');
	
	$('#viewBIlls > tbody > tr.dataRow5').after('<tr class="dataRow5Data" style="display:none; padding: 10px 0;"><td></td><td colspan="8" style="background: #e0dddd !important; padding: 10px 7px;"><table class="table innerTable"><tr class="odd"><td>Premiums for Coverage Period</td><td> $1,750.00</td></tr><tr class="even"><td>Amount Due from Prior</td><td>$0.00</td></tr><tr class="odd"><td>Payments Applied</td><td>$1,750.00</td></tr><tr class="even"><td>Adjustments Applied</td><td>$0.00</td></tr></table></td></tr>');
	
	$('#viewBIlls > tbody > tr.dataRow8').after('<tr class="dataRow8Data" style="display:none; padding: 10px 0;"><td></td><td colspan="8" style="background: #e0dddd !important; padding: 7px;"><table class="table innerTable"><tr class="odd"><td>Premiums for Coverage Period</td><td> $1,750.00</td></tr><tr class="even"><td>Amount Due from Prior</td><td>$0.00</td></tr><tr class="odd"><td>Payments Applied</td><td>$1,100.00</td></tr><tr class="even"><td>Adjustments Applied</td><td>$0.00</td></tr></table></td></tr>');
	
	$('#viewBIlls > tbody > tr.dataRow10').after('<tr class="dataRow10Data" style="display:none; padding: 10px 0;"><td></td><td colspan="8" style="background: #e0dddd !important; padding: 7px;"><table class="table innerTable"><tr class="odd"><td>Premiums for Coverage Period</td><td> $1,750.00</td></tr><tr class="even"><td>Amount Due from Prior</td><td>$0.00</td></tr><tr class="odd"><td>Payments Applied</td><td>$1,100.00</td></tr><tr class="even"><td>Adjustments Applied</td><td>$0.00</td></tr></table></td></tr>');
	$('#viewBIlls > tbody > tr.dataRow1 td a.slide-plus').click(function(){
		$(".dataRow1Data").toggle();
		$(this).toggleClass("slide-minus");
	});
	$('#viewBIlls > tbody > tr.dataRow3 td a.slide-plus').click(function(){
		$(".dataRow3Data").toggle();
		$(this).toggleClass("slide-minus");
	});
	$('#viewBIlls > tbody > tr.dataRow5 td a.slide-plus').click(function(){
		$(".dataRow5Data").toggle();
		$(this).toggleClass("slide-minus");
	});
	$('#viewBIlls > tbody > tr.dataRow8 td a.slide-plus').click(function(){
		$(".dataRow8Data").toggle();
		$(this).toggleClass("slide-minus");
	});
	$('#viewBIlls > tbody > tr.dataRow10 td a.slide-plus').click(function(){
		$(".dataRow10Data").toggle();
		$(this).toggleClass("slide-minus");
	});
	

// Payment Option Method for Individual and Group

	
		$(document).on('click', '.cardDelete', function(event) {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Are You Sure?",
			content: "You want to remove this Saved Card permanently.",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					$('#selectCard').hide();
				}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   		});
		});
		
		$(document).on('click', '.accountDelete', function(event) {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Are You Sure?",
			content: "You want to remove this Saved Bank Account permanently.",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					$('#bankAccount').hide();
				}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   		});
		});
	
		$('.js-editCard').on('click', function(){
			$this = $(this);
			$this.parent().slideUp(500);
			$this.parent().next().slideDown(1000);
		});
		$('.js-showInfo').on('click', function(){
			$this = $(this);
			$this.parents('.editAccountPremission').slideUp(500);
			$this.parent().parent().prev().slideDown(1000);
		});	



// add-account.html

		
		
		$(document).ready(function() {
			
			$("#cr_dr_account").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormAcrdAccount();
				},
				rules: {
					account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					name_on_card:{
						required:true	
					},
					cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 9, // will count space 
            			maxlength: 9
					},
					year:{
						required:true,
						selectcheck:true,
						creditcardexpiry:true
						 
					},
					month:{
						required:true,
						selectcheck:true
						//creditcardexpiry: true
					},
					Add1_Eft:{
						required: true
					},
					city_Eft:{
						required: true
					},
					state_Eft:{
						required: true,
						selectcheck:true
					},
					zip_Eft:{
						required: true
					},
					county_Eft:{
						required: true
					}
				},
				 messages: {
    				
    				account_no: {
     					required: "Please enter Account Number."
    				},
					name_on_card: {
     					required: "Please enter First Name."
    				},
					cvv_no: {
     					required: "Please enter Routing Number."
    				},
					Add1_Eft:{
						required: "Please enter Addres Line 1."
					},
					city_Eft:{
						required: "Please enter City."
					},
					state_Eft:{
						required: "Please select State."
					},
					zip_Eft:{
						required: "Please enter Zip."
					},
					county_Eft:{
						required: "Please enter Country."
					}
				 },
				
    
			
			});
			$.validator.addMethod('selectcheck', function (value) {
       				 return (value !== 'select');
    				}, "Please select an Option");
			
			$.validator
				.addMethod('creditcardexpiry', function(value, element) {
					var form = element.form,
					expiry = form['year'].value + form['month'].value,
					date = new Date(),
					monthCheck = date.getMonth() + 1,
					now = '' + date.getFullYear() + (monthCheck < 10 ? '0' + monthCheck : monthCheck);
			
					return expiry > now;
				}, "Expiration date can not be prior to today");		
			
			
});

		
		
// add-card.html

		$(document).ready(function() {
			
			$("#cr_dr_card").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormAcrdAccount();
				},
				rules: {
					account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					account_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 15, // will count space 
           				maxlength: 15
						 
					},
					card_type:{
						required:true	
					},
					name_on_card:{
						required:true	
					},
					cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					},
					cvv_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 4, // will count space 
            			maxlength: 4
					},
					year:{
						required:true,
						selectcheck:true,
						creditcardexpiry:true
						 
					},
					month:{
						required:true,
						selectcheck:true
						//creditcardexpiry: true
					},
					Add1_Eft:{
						required: true
					},
					city_Eft:{
						required: true
					},
					state_Eft:{
						required: true,
						selectcheck:true
					},
					zip_Eft:{
						required: true
					},
					county_Eft:{
						required: true
					}
				},
				 messages: {
    				
    				card_type: {
     					required: "Please select type of Card."
    				},account_no: {
     					required: "Please enter Card Number."
    				},
					account_no_amex: {
     					required: "Please enter Card Number."
    				},
					name_on_card: {
     					required: "Please enter Name as appears on Card."
    				},
					cvv_no: {
     					required: "Please enter CVV."
    				},
					cvv_no_amex: {
     					required: "Please enter CVV."
    				},
					Add1_Eft:{
						required: "Please enter Addres Line 1."
					},
					city_Eft:{
						required: "Please enter City."
					},
					state_Eft:{
						required: "Please select State."
					},
					zip_Eft:{
						required: "Please enter Zip."
					},
					county_Eft:{
						required: "Please enter Country."
					}
				 },
				
    
			
			});
			$.validator.addMethod('selectcheck', function (value) {
       				 return (value !== 'select');
    				}, "Please select an Option");
			
			$.validator
				.addMethod('creditcardexpiry', function(value, element) {
					var form = element.form,
					expiry = form['year'].value + form['month'].value,
					date = new Date(),
					monthCheck = date.getMonth() + 1,
					now = '' + date.getFullYear() + (monthCheck < 10 ? '0' + monthCheck : monthCheck);
			
					return expiry > now;
				}, "Expiration date can not be prior to today");		
			
			
});

// For add-account.html and add-card.html
	
	SubmittingFormAcrdAccount=function() {
				window.location = 'auto-recurring-eft-3.html';
		}
		
	function copy_address_option_Eft(check_value)
		{
			if(check_value==true)
			{
				document.getElementById('Add1_Eft').value="2775 Crossroads Boulevard";
				document.getElementById('Add2_Eft').value="5th Avenue";
				document.getElementById('city_Eft').value="Grand Junction";
				document.getElementById('state_Eft').value="CO";
				document.getElementById('county_Eft').value="US";
				document.getElementById('zip_Eft').value="10600";
							}
			else
			{
				document.getElementById('Add1_Eft').value='';
				document.getElementById('Add2_Eft').value='';
				document.getElementById('city_Eft').value='';
				document.getElementById('state_Eft').value='';
				document.getElementById('county_Eft').value='';
				document.getElementById('zip_Eft').value='';
			}
		}
		

// auto-recurring-2.html

		SubmittingFormChooseCard=function() {
				window.location = 'auto-recurring-3.html';
		}
		SubmittingFormETF=function() {
			
				window.location = 'auto-recurring-eft-3.html';
			
		}
		$("#cr_dr_Choose_Card").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormChooseCard();
				},
				rules: {
					account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					name_on_card:{
						required:true	
					},
					cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					},
					inner_cvv_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 4, // will count space 
            			maxlength: 4
					},
					inner_account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
					},
					inner_account_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 15, // will count space 
           				maxlength: 15
					},
					inner_name_on_card:{
						required:true
					},
					inner_cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					},
					Add1:{
						required: true
					},
					city:{
						required: true
					},
					state:{
						required: true
					},
					zip:{
						required: true
					},
					country:{
						required: true
					}
				},
				 messages: {
    				
    				account_no: {
     					required: "Please enter Card Number."
    				},
					name_on_card: {
     					required: "Please enter the Name as appears on Card."
    				},
					cvv_no: {
     					required: "Please enter CVV."
    				},
					inner_account_no:{
						required: "Please enter Card Number."
					},
					inner_account_no_amex:{
						required: "Please enter Card Number."
					},
					inner_name_on_card:{
						required: "Please enter the Name as appears on Card."
					},
					inner_cvv_no:{
						required: "Please enter CVV."
					},
					inner_cvv_no_amex:{
						required: "Please enter 4-digit Security Code."
					},
					Add1:{
						required: "Please enter the Addres Line 1."
					},
					city:{
						required: "Please enter City."
					},
					state:{
						required: "Please select State."
					},
					zip:{
						required: "Please enter Zip."
					},
					country:{
						required: "Please enter Country."
					}
				 }
			
			});
			
			$("#option_eft").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormETF();
				},
				rules: {
					accountType:{
						required:true,
						selectcheck:true
					},
					acName:{
						required:true				 
					},
					acNum:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					RouNum:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 9, // will count space 
            			maxlength: 9
					},
					
					Add1_Eft:{
						required: true
					},
					city_Eft:{
						required: true
					},
					state_Eft:{
						required: true,
						selectcheck:true
					},
					zip_Eft:{
						required: true
					},
					country_Eft:{
						required: true
					}
				},
				 messages: {
    				
    				acNum: {
     					required: "Please enter Account Number."
    				},acName: {
     					required: "Please enter First Name."
    				},
					RouNum: {
     					required: "Please enter Routing Number."
    				},
					Add1_Eft:{
						required: "Please enter Addres Line 1."
					},
					city_Eft:{
						required: "Please enter City."
					},
					state_Eft:{
						required: "Please select State."
					},
					zip_Eft:{
						required: "Please enter Zip."
					},
					country_Eft:{
						required: "Please enter Country."
					}
				 }
				
			});
			
		$.validator.addMethod('selectcheck', function (value) {
       				 return (value !== 'select');
    	}, "Please select an option");
			
		function copy_address_option(check_value)
		{
			if(check_value==true)
			{
				document.getElementById('Add1').value="2775 Crossroads Boulevard";
				document.getElementById('Add2').value="5th Avenue";
				document.getElementById('city').value="Grand Junction";
				document.getElementById('state').value="CO";
				document.getElementById('county').value="US";
				document.getElementById('zip').value="10600";
							}
			else
			{
				document.getElementById('Add1').value='';
				document.getElementById('Add2').value='';
				document.getElementById('city').value='';
				document.getElementById('state').value='';
				document.getElementById('county').value='';
				document.getElementById('zip').value='';
			}
		}
		
		$('.removeCard1').on('click', function(){
			 $.msgBox({
			title: "Are You Sure?",
			content: "You want to remove this Card.",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
				 $(".cardOne").hide();
					}else if(result == "Cancel"){
						//do nothing
					}
			}		
		});
		});
		$('.removeCard2').on('click', function(){
			 $.msgBox({
				title: "Are You Sure?",
				content: "You want to remove this Card.",
				type: "confirm",
				buttons: [{ value: "Yes" },{ value: "Cancel"}],
				success: function (result) {
					if (result == "Yes") {
					 $(".cardTwo").hide();
						}else if(result == "Cancel"){
							//do nothing
						}
				}		
			});
		});
		
			$('.removeAccount1').on('click', function(){
				 $.msgBox({
					title: "Are You Sure?",
					content: "You want to remove this Account.",
					type: "confirm",
					buttons: [{ value: "Yes" },{ value: "Cancel"}],
					success: function (result) {
						if (result == "Yes") {
						 $(".accountOne").hide();
							}else if(result == "Cancel"){
								//do nothing
							}
					}		
				});
			});
			
		$('.removeAccount2').on('click', function(){
			 $.msgBox({
				title: "Are You Sure?",
				content: "You want to remove this Account.",
				type: "confirm",
				buttons: [{ value: "Yes" },{ value: "Cancel"}],
				success: function (result) {
					if (result == "Yes") {
					 $(".accountTwo").hide();
						}else if(result == "Cancel"){
							//do nothing
						}
				}		
			});
		});
		
		$("input[name='chooseCard']").bind('click', function(){
			if ($("input[name='chooseCard']:checked").val() == 'newCard') {
					 $('.cardBox').slideDown();   	
			}else if ($("input[name='chooseCard']:checked").val() == 'card1') {
				$('.cardBox').slideUp();
			}else if ($("input[name='chooseCard']:checked").val() == 'card2') {
			 $('.cardBox').slideUp();
			}
			
		});
		
		$("#save_card1").click(function () {
				 if ($(this).prop('checked')==true){ 
		 		 $('#save_card_mesg1').show();
				 }
		 		if ($(this).prop('checked')==false){ 
		   		 $('#save_card_mesg1').hide();
				 }
		  
			});
			$("#save_card2").click(function () {
				 if ($(this).prop('checked')==true){ 
		 		 $('#save_card_mesg2').show();
				 }
		 		if ($(this).prop('checked')==false){ 
		   		 $('#save_card_mesg2').hide();
				 }
		  
			});
			$('.notice').hide();
	$("input[name='paymentOptions']").bind('click', function(){
		if ($("input[name='paymentOptions']:checked").val() == 'card') {
		   $.msgBox({
			title: "Pay less using EFT",
			content: "Using EFT makes you eligible for a discount of 5% on your total payment. Would you still like to change your payment method ?",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
				 $('.js-cardBox').show();
		   $('.js-eftbox').hide();
		    $('.notice').hide();
			 $('#buttons').hide();
			  $('.paymentwithlogin1').hide();
			   $('.paymentwithlogin2').hide();
			 $('.paymentwithlogin3').show();
			   $('.paymentwithlogin4').show();
					}else if(result == "Cancel"){
						$("#eft").prop("checked", true)	
						//do nothing
					}
				  }
	   });
	
		   	
		}else if ($("input[name='paymentOptions']:checked").val() == 'echeck') {
			$('.js-cardBox').hide();
			 $('.js-eftbox').hide();
			 $('.notice').show();
			  $('#buttons').show();
		}else if ($("input[name='paymentOptions']:checked").val() == 'eft') {
		   $('.js-cardBox').hide();
		   $('.js-eftbox').show();
		    $('.notice').hide();
			 $('#buttons').hide();
			 $('.paymentwithlogin1').show();
			   $('.paymentwithlogin2').show();
			    $('.paymentwithlogin3').hide();
			   $('.paymentwithlogin4').hide();
		}
		
	});
		$("input[name='cardOptionFloat']").on('click', function(){

			if ($("input[name='cardOptionFloat']:checked").val() == 'visacard') {
		   			$('#master').hide();
					$('#amex').hide();
					$('#discover').hide();
		   			$('#card').show();
		   	
			}else if ($("input[name='cardOptionFloat']:checked").val() == 'mastercard'){
					$('#card').hide();
					$('#amex').hide();
					$('#discover').hide();
		   			$('#master').show();
			}
			
			else if ($("input[name='cardOptionFloat']:checked").val() == 'amexcard'){
					$('#master').hide();
					$('#card').hide();
					$('#discover').hide();
		   			$('#amex').show();
			}
			
			else if ($("input[name='cardOptionFloat']:checked").val() == 'discovercard'){
					$('#master').hide();
					$('#card').hide();
		   			$('#amex').hide();
					$('#discover').show();
			}
		});
		
		 $("input[name='chooseAccount']").bind('click', function(){
			if ($("input[name='chooseAccount']:checked").val() == 'newAccount') {
					 $('.accountBox').slideDown();   	
			}else if ($("input[name='chooseAccount']:checked").val() == 'account1') {
				$('.accountBox').slideUp();
			}else if ($("input[name='chooseAccount']:checked").val() == 'account2') {
			 $('.accountBox').slideUp();
			}
			});
			
			
			
// ============== auto-recurring.html : individual  ==========================
		SubmittingFormAutoRecurring=function() {
			var flat_amt = $('#flat_amt').val();
			if(flat_amt > 0){
				window.location = 'auto-recurring-2.html';
			}
		}
		if ($("input[name='autoRecurringPaymentOptions']:checked").val() == 'card') {
				$('a.form-submit').attr('href', 'auto-recurring-2.html');
		 	};
			//
			
	     $("input[name='autoRecurringPaymentOptions']").bind('click', function(){
		   if ($("input[name='autoRecurringPaymentOptions']:checked").val() == 'flatAmt') {
			   		 $('a.form-submit').removeAttr('href');
					 $('a.form-submit').click(function(e) {
				e.preventDefault();
				$("#payment").submit();
			});
					$("#payment").validate({
				onfocusout: function(element) { 
					$(element).valid();
					
					var price = document.getElementById('flat_amt').value;
    				 if (price % 1 == 0){
						Number.prototype.format = function() {
							 return this.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1");	 
						}
						price = parseInt(price);
						price = price ? price : "";
						$("#flat_amt").val(price.format());
					}
					
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormAutoRecurring();
				},
				rules: {
					flat_amt:{
						required:true,
						greaterThanZero: true
					}
				},
				 messages: {
    				
    				flat_amt: {
     					required: "Please enter Amount.",
						number: "Please enter Amount."
    						}
				 }
			
			});
					 jQuery.validator.addMethod("greaterThanZero", function(value, element) {
    return this.optional(element) || (parseFloat(value) > 0);
}, "Minimum payable amount is : $0.01");

 // Validate for 2 decimal for money
			jQuery.validator.addMethod("money", function(value, element) {
				 return this.optional(element) || /^(\d{1,8})$/.test(value) || /^(\d{1,8})(\.\d{1,2})$/.test(value) || /^(\d{1,8})(\.\d{1,1})$/.test(value) || /^(\d{1,8})(\.\d{0,1})$/.test(value) || /^(\.\d{0,2})$/.test(value) || /^(\.\d{0,1})$/.test(value);
			 }, "Please enter Amount in correct format: xxx.xx");	
		   } else if ($("input[name='autoRecurringPaymentOptions']:checked").val() == 'card') {
			  $('a.btn-primary').attr('href', 'auto-recurring-2.html');
		   }
		});

// ================ my-save-card.html, payment-info.html, saved-cards.html =========================

$('input[name=paymentOptions]:radio').on('click', function(){
		var value = $(this).val();
		if(value == 'card'){
			$('.js-link').attr('href','payment-info.html');
		}
		else if(value == 'echeck') {
	  	 alert("We are working on Echeck payment option. Please try other payment option for now.");
		}
		else if(value == 'eft') {
			$('.js-link').attr('href','payment-info-eft.html');
		}

	});
	$('.js-link').on('click', function(){
		if (!$("input[name='paymentOptions']:checked").val()) {
		   alert('Please Select Payment Option.');
		}
	});
	

// ================================ reports.html ===================================
jQuery(".linkOne").click(function(){ 
        jQuery(".linkdata").hide(); 
        jQuery(".linkOneData").show(); 
        jQuery(".dataLinks li a").removeClass("active"); 
        jQuery(".linkOne").addClass("active");  
 }); 
  jQuery(".linkTwo").click(function(){ 
        jQuery(".linkdata").hide(); 
        jQuery(".linkTwoeData").show(); 
        jQuery(".dataLinks li a").removeClass("active"); 
        jQuery(".linkTwo").addClass("active");  
 }); 


		
		
		jQuery(".chartEx li").click(function(){
			var x= jQuery(this).find("span").attr('class');
			//alert(x);
			jQuery(this).parents(".showItems").find("#SelectCharts span ").attr('class', '').addClass(x);
			$(".dropItems").hide();
			
		});
		
        jQuery("#cp-bar").click(function(){
			//alert("hu");
			jQuery("#imgCp").attr('src',"../images/ind1-bar.jpg");
		});
		 jQuery("#cp-pie").click(function(){
			jQuery("#imgCp").attr('src',"../images/ind1-pie.jpg");
		});
		 jQuery("#cp-table").click(function(){
			jQuery("#imgCp").attr('src',"../images/ind1-table.jpg")
		});
 		jQuery("#cp-line").click(function(){
			jQuery("#imgCp").attr('src',"../images/ind1-line.jpg")
		});


	     jQuery("#dcd-bar").click(function(){
			jQuery("#imgDcd").attr('src',"../images/opt2-bar.jpg");
		});
		 jQuery("#dcd-pie").click(function(){
			jQuery("#imgDcd").attr('src',"../images/opt2.jpg");
		});
		 jQuery("#dcd-table").click(function(){
			jQuery("#imgDcd").attr('src',"../images/opt2-table.jpg")
		});
		
		jQuery("#sbp-bar").click(function(){
			jQuery("#imgSbp").attr('src',"../images/opt3.jpg");
		});
		 jQuery("#sbp-pie").click(function(){
			jQuery("#imgSbp").attr('src',"../images/opt3-pie.jpg");
		});
		 jQuery("#sbp-table").click(function(){
			jQuery("#imgSbp").attr('src',"../images/opt3-table.jpg")
		});
		
		
		jQuery("#rbh-bar").click(function(){
			jQuery("#imgRbh").attr('src',"../images/opt4-bar.jpg");
		});
		 jQuery("#rbh-pie").click(function(){
			jQuery("#imgRbh").attr('src',"../images/opt4.jpg");
		});
		 jQuery("#rbh-table").click(function(){
			jQuery("#imgRbh").attr('src',"../images/opt4-table.jpg")
		});
		
		
// ============================ quick-pay.html ======================

	SubmittingFormQuickPay=function() {
				window.location = 'payment-status-eft.html';
		}
		
			$("#quick-pay").validate({
				onfocusout: function(element) { 
					$(element).valid();
					var price = document.getElementById('paymentAmountQuickPay').value;
    				 if (price % 1 == 0){
						Number.prototype.format = function() {
							 return this.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1");	 
						}
						price = parseInt(price);
						price = price ? price : "";
						$("#paymentAmountQuickPay").val(price.format());
					}
					
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormQuickPay();
				},
				rules: {
					cardNumber:{
						required:true,
						selectcheck:true	
					},
					paymentAmountQuickPay:{
						required:true,
						 greaterThanZero: true,
						money:true
					},
					inputEmail1:{
						required:true
					}
				},
				 messages: {
    				
    				paymentAmountQuickPay: {
     					required: "Please enter the amount"
    				},
					inputEmail1:{
						required: "Please enter Email ID."
					}
				 }
			
			});
					 jQuery.validator.addMethod("greaterThanZero", function(value, element) {
    return this.optional(element) || (parseFloat(value) > 0);
}, "Minimum payable amount is : $0.01");
		
		 
		 // Validate for 2 decimal for money
			 jQuery.validator.addMethod("money", function(value, element) {
				 return this.optional(element) || /^(\d{1,8})$/.test(value) || /^(\d{1,8})(\.\d{1,2})$/.test(value) || /^(\d{1,8})(\.\d{1,1})$/.test(value) || /^(\d{1,8})(\.\d{0,1})$/.test(value) || /^(\.\d{0,2})$/.test(value) || /^(\.\d{0,1})$/.test(value);
			 }, "Please enter the amount in correct format: xxx.xx");
			$.validator.addMethod('selectcheck', function (value) {
       				 return (value !== 'select');
    				}, "Please select an option");
					


// ================ auto-recurring-eft.html ======================
		


// ======= bill-perferences ========================
function selectBillMedia(check_value)
		{
			if(check_value==true)
			{
				document.getElementById("billMediaType").disabled=false;			
			}
			else
			{
				document.getElementById("billMediaType").disabled=true;
			}
		}
		
		$(document).on('click', '.confirmButton', function(event) {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Bill Preference Confirmation",
			content: "Are You Sure? you want change your Billing Preferences.",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					$(".confirmButton").attr("href","index.html");
					window.location = "index.html";
					
					}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   });
	});	

// ===================== pay-online.html =====================
		
		SubmittingFormPaymentOnline=function() {
			//alert("The form has been validated.");
			var paymentAmount = $('#paymentAmount').val();
			if(paymentAmount > 0){
				window.location = 'set-payment-option.html';
			}
		}
		$(document).ready(function() {
			$("#paymentOnline").validate({
				onfocusout: function(element) { 
					$(element).valid();
					
					var price = document.getElementById('paymentAmount').value;
    				 if (price % 1 == 0){
						Number.prototype.format = function() {
							 return this.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1");	 
						}
						price = parseInt(price);
						price = price ? price : "";
						$("#paymentAmount").val(price.format());
					}
					
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormPaymentOnline();
				},
				rules: {
					paymentAmount:{
						required:true,
						greaterThanZero: true,
						//number:true,
						money:true
					}
				},
				 messages: {
    				
    				paymentAmount: {
     					required: "Please enter Amount.",
						number: "Please enter Amount."
    						}
				 }
			
			});
			
					 jQuery.validator.addMethod("greaterThanZero", function(value, element) {
    return this.optional(element) || (parseFloat(value) > 0);
}, "Minimum payable amount is : $0.01");
		
		   });
		 // Validate for 2 decimal for money
			 jQuery.validator.addMethod("money", function(value, element) {
				 return this.optional(element) || /^(\d{1,8})$/.test(value) || /^(\d{1,8})(\.\d{1,2})$/.test(value) || /^(\d{1,8})(\.\d{1,1})$/.test(value) || /^(\d{1,8})(\.\d{0,1})$/.test(value) || /^(\.\d{0,2})$/.test(value) || /^(\.\d{0,1})$/.test(value);
			 }, "Please enter Amount in correct format: xxx.xx");
			

// set-payment-option.html

	SubmittingFormSetPaymentOption=function() {
				window.location = 'paymentsummary.html';
		}
		
			
			$("#card_setPaymentOption").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormSetPaymentOption();
				},
				rules: {
					account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					name_on_card:{
						required:true	
					},
					cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					},
					inner_cvv_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 4, // will count space 
            			maxlength: 4
					},
					inner_account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
					},
					inner_account_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 15, // will count space 
           				maxlength: 15
					},
					inner_name_on_card:{
						required:true
					},
					inner_cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					},
					Add1:{
						required: true
					},
					city:{
						required: true
					},
					state:{
						required: true
					},
					zip:{
						required: true
					},
					country:{
						required: true
					}
				},
				 messages: {
    				
    				account_no: {
     					required: "Please enter Card Number."
    				},
					name_on_card: {
     					required: "Please enter Name as appears on Card."
    				},
					cvv_no: {
     					required: "Please enter CVV."
    				},
					inner_account_no:{
						required: "Please enter Card Number."
					},
					inner_account_no_amex:{
						required: "Please enter Card Number."
					},
					inner_name_on_card:{
						required: "Please enter Name as appears on Card."
					},
					inner_cvv_no:{
						required: "Please enter CVV."
					},
					inner_cvv_no_amex:{
						required: "Please enter 4-digit Security Code."
					},
					Add1:{
						required: "Please enter Addres Line 1."
					},
					city:{
						required: "Please enter City."
					},
					state:{
						required: "Please select State."
					},
					zip:{
						required: "Please enter Zip."
					},
					country:{
						required: "Please enter Country."
					}
				 }
			
			});
			
			
			
			
			SubmittingFormETFSetPaymentOption=function() {
				window.location = 'paymentsummary-eft.html';
			
		}
			$("#option_eft_SetPaymentOption").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormETFSetPaymentOption();
				},
				rules: {
					accountType:{
						required:true,
						selectcheck:true
					},
					acName:{
						required:true				 
					},
					acNum:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					RouNum:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 9, // will count space 
            			maxlength: 9
					},
					
					Add1_Eft:{
						required: true
					},
					city_Eft:{
						required: true
					},
					state_Eft:{
						required: true,
						selectcheck:true
					},
					zip_Eft:{
						required: true
					},
					country_Eft:{
						required: true
					}
				},
				 messages: {
    				
    				acNum: {
     					required: "Please enter Account Number."
    				},acName: {
     					required: "Please enter First Name."
    				},
					RouNum: {
     					required: "Please enter Routing Number."
    				},
					Add1_Eft:{
						required: "Please enter Addres Line 1."
					},
					city_Eft:{
						required: "Please enter City."
					},
					state_Eft:{
						required: "Please select State."
					},
					zip_Eft:{
						required: "Please enter Zip."
					},
					country_Eft:{
						required: "Please enter Country."
					}
				 }
			
			});
			
// ==================== paymentsummary.html ======================	
		
	SubmittingFormPaymentSummaryValidation=function() {
			
				window.location = 'paymentProcessingPayment-status.html';
			
		}
			$("#paymentSummaryValidation").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormPaymentSummaryValidation();
				},
				rules: {
					inputEmail1:{
						required:true
					}
				},
				 messages: {
					inputEmail1:{
						required: "Please enter Email ID."
					}
				 }
			
			});
		

		

// ======================= paymentsummary-eft.html ================== //

	
SubmittingFormPaymentSummaryEFT=function() {
				window.location = 'paymentProcessingPayment-status-eft.html';
		}
		
			$("#paymentSummaryEFT").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormPaymentSummaryEFT();
				},
				rules: {
					inputEmail1:{
						required:true,
           				email: true	
					}
				},
				 messages: {
					inputEmail1: {
     					required: "Please enter Email ID."
    				}
				 }
			});	


// ====================== auto-recurring-eft-4.html =======================//
SubmittingFormAutoRecurringEFT=function() {
					$('#popupView').dialog('open');
					return false;
		}
		
			$("#paymentAutoRecurringEFT").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormAutoRecurringEFT();
				},
				rules: {
					inputEmail1:{
						required:true,
           				email: true	
					}
				},
				 messages: {
					inputEmail1: {
     					required: "Please enter Email ID."
    				}
				 }
			});	
			

			
			
			$('.expandButton').removeClass('closeSection');
			$('.expandButton').addClass('openSection');
			$(".customerBrief").css({"margin-left":"-210px"});
			$(".rightSection").css({"margin-left":"10px"});
			// Rules home table - delete and assign & unassign functionality
			$( "#popupView" ).dialog({ 
					title: 'Recurring Confirmation',
					autoOpen: false,
					width: '500',
					modal: true,
					position : ['center', 150]
			});
		
				
			$(".closePopUp" ).click(function() {
				$( ".popupBox" ).dialog('close');
			})
			

//====================== auto-recurring-3.html ======================== //
			$(".option1 input, .option1 select").prop('disabled', true);
			$(".option2 input, .option2 select").prop('disabled', true);
			
			$("input[name='paydate']").bind('click', function(){
			if ($("input[name='paydate']:checked").val() == 'option1') {
					$(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', true);
					$(".option1 input, .option1 select").prop('disabled', false);
		   			$("img.ui-datepicker-trigger").hide();
			}else if ($("input[name='paydate']:checked").val() == 'option2'){
					$(".option1 input, .option1 select").prop('disabled', true);
					$(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', false);
					$("img.ui-datepicker-trigger").show();
			}
			else if ($("input[name='paydate']:checked").val() == 'option3'){
					$(".option1 input, .option1 select").prop('disabled', true);
					$(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', true);
					$("img.ui-datepicker-trigger").hide();
			}
		
			});
		
	
		
	$("#setPaymentAutoRecurringEFT img.ui-datepicker-trigger, #RecuPaymentSchedule img.ui-datepicker-trigger, #setPayment img.ui-datepicker-trigger").hide();
	
	
	// For Validation
	
	SubmittingForm=function() {
			
				window.location = 'auto-recurring-4.html';
		}
			$("#setPayment").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingForm();
				},
				rules: {
					from:{
						required:true,
					},
					endDate:{
						required:true,
					}
				},
				 messages: {
    				
    				from: {
     					required: "Please select Date."
    				},
					endDate: {
     					required: "Please select Date."
    				}
				 }
			
			});
		

// ==================== plan-details.html =================== //
$('#plandetails1').dataTable(
	 {
		//"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bAutoWidth": false,
		"bFilter": true,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       		]
		} 
	);
	var myTable=$('#plandetails1').dataTable();
	$('#plandetails1_wrapper .dataTables_filter input').attr('placeholder','Plan Id');

/*$('#plandetails2').dataTable(
	 {
		"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bAutoWidth": false,
		"bFilter": true,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 2,7 ] }
       		]
		} 
	);
	var myTable=$('#plandetails2').dataTable();
$('.dataTables_filter input').attr('placeholder','Plan Id');*/


// =================== payment-info.html ==================== //
		SubmittingFormPaymentInfo=function() {
				window.location = 'modify-recurring-payment-schedule.html';
		}
		
			
			$("#cardPaymentInfo").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormPaymentInfo();
				},
				rules: {
					account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					name_on_card:{
						required:true	
					},
					cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					}
				},
				 messages: {
    				
    				account_no: {
     					required: "Please enter Account Number."
    				},
					name_on_card: {
     					required: "Please enter Name on Card."
    				},
					cvv_no: {
     					required: "Please enter CVV."
    				}
				 }
			
			});
			
// ======================= my-preferences.html ============================//
$(function() {
$('input[type=checkbox]').change(function() {
	$('.toSave, .toCancel').show();
});

$('.toSave').bind({
  click: function() {
		$.msgBox({
		title: "Are You Sure?",
		content: "You want to change your notification settings.",
		type: "confirm",
		buttons: [{ value: "Update" },{ value: "Cancel"}],
		success: function (result) {
			if (result == "Update") {
				//$( this ).parents("form").find(".control-group label input").toggleClass( "disable" );
				$('.toSave').hide();
				$('.toCancel').hide();
				}else if(result == "Cancel"){
							$('.checkbox input').prop('disabled',false);
							$( this ).parents("form").find(".control-group label input").toggleClass( "disable" );
							$('.toSave').hide();
							$('.toCancel').hide();
				}
			}
		});
	  },
	});
});
	
//========================== modify-recurring-payment-summary.html ============================= //
$(document).on('click', '.save-icon', function(event) {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Recurring Confirmation",
			content: "Once your agreement has been set up, payments will automatically be collected according to the type of agreement. The agreement may be set up to take an immediate or a delayed payment.",
			type: "confirm",
			buttons: [{ value: "Yes"}, { value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					$(".save-icon").attr("href","index.html");
					window.location = "index.html";
					
					}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   });
	});
	

//========================== cancel recrring =============================non //
$(document).on('click', '.cancelRecr', function(event) {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Are You Sure?",
		    content: "You want to cancel Recurring Setup!",
			type: "confirm",
			buttons: [{ value: "Yes"}, { value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					$(".cancelRecr").attr("href","auto-recurring-cancelled.html");
					window.location = "auto-recurring-cancelled.html";
					
					}else if(result == "Cancel"){
						//alert("no");
					}
				  }
	   });
	});
	
//============================ modify-recurring-payment-schedule.html ========================//
// For Validation
	
	SubmittingFormRecuPaymentSchedule=function() {
			//alert("The form has been validated.");
			
				window.location = 'modify-recurring-payment-summary.html';
		}
		$(document).ready(function() {
			$("#RecuPaymentSchedule").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormRecuPaymentSchedule();
				},
				rules: {
					from:{
						required:true,
					},
					endDate:{
						required:true,
					}
				},
				 messages: {
    				
    				from: {
     					required: "Please select Date."
    				},
					endDate: {
     					required: "Please select Date."
    				}
				 }
			
			});
			
		
		});


//============================== modify-cancel-recurring-setup.html ============================= //
	
	$(document).on('click', '#modifyRecurringBtn', function(event) {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Are You Sure?",
			content: "You want to Modify Recurring Setup.",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					window.location.href = "modify-recurring-payment-amount.html";
					}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   });
	});
	
function goBack()
  {
  window.history.back()
  }
  

//============================= auto-recurring-eft-3.html =============================//
  
// For Validation
	SubmittingForm=function() {
				window.location = 'auto-recurring-eft-4.html';
		}
		$(document).ready(function() {
			$("#setPayment").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingForm();
				},
				rules: {
					from:{
						required:true,
					},
					endDate:{
						required:true,
					}
				},
				 messages: {
    				
    				from: {
     					required: "Please select Date."
    				},
					endDate: {
     					required: "Please select Date."
    				}
				 }
			
			});
			$(".option1 input, .option1 select").prop('disabled', true);
			$(".option2 input, .option2 select").prop('disabled', true);
			
			$("input[name='paydate']").bind('click', function(){
			if ($("input[name='paydate']:checked").val() == 'option1') {
					$(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', true);
					$(".option1 input, .option1 select").prop('disabled', false);
		   			$("img.ui-datepicker-trigger").hide();
			}else if ($("input[name='paydate']:checked").val() == 'option2'){
					$(".option1 input, .option1 select").prop('disabled', true);
					$(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', false);
					$("img.ui-datepicker-trigger").show();
			}
			else if ($("input[name='paydate']:checked").val() == 'option3'){
					$(".option1 input, .option1 select").prop('disabled', true);
					$(".option2 input, .option2 select, .option2 .hasDatepicker").prop('disabled', true);
					$("img.ui-datepicker-trigger").hide();
			}
		
			});
		
		});
		
		
	$(document).on('click', '#logout-link', function(event) {
		  //alert("This will remove the selected notification");
			$.msgBox({
			title: "Are You Sure?",
			content: "You want to Logout.",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {
					window.location.href = "../login.html";
					}else if(result == "Cancel"){
						//do nothing
					}
				  }
	   });
	});
	
//=============================== auto-recurring-eft-3.html ===========================//
	// For Validation
	SubmittingFormSetPaymentAutoRecurringEFT=function() {
				window.location = 'auto-recurring-eft-4.html';
		}
		$(document).ready(function() {
			$("#setPaymentAutoRecurringEFT").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormSetPaymentAutoRecurringEFT();
				},
				rules: {
					from:{
						required:true,
					},
					endDate:{
						required:true,
					}
				},
				 messages: {
    				
    				from: {
     					required: "Please select Date."
    				},
					endDate: {
     					required: "Please select Date."
    				}
				 }
			
			});
		});
		


// ================== current-invoice.html =========================== //

$('.acc_container').hide(); //Hide/close all containers
$('.acc_trigger:first').addClass('active').next().show(); 
//On Click
$('.acc_trigger').click(function(){
    if( $(this).next().is(':hidden') ) {
        $('.acc_trigger').removeClass('active').next().slideUp(); 
        $(this).toggleClass('active').next().slideDown(); 
    }
    else if( $(this).hasClass("active") ) {
        $('.acc_trigger').removeClass('active').next().slideUp();
    }
    return false; //Prevent the browser jump to the link anchor
});


$('.js-details1').on('click', function(){
     $('html, body').animate({
           'scrollTop':   $('#anchorName1').offset().top
         }, 2000);
    $('.invoiceDetailsBtn').removeClass('active');
    $(this).addClass('active');
    $('.acc_trigger').removeClass('active');
    $('.acc_container').slideUp();
    $('.acc_container').eq(0).slideDown();
    $('#anchorName1').addClass('active');
});

$('.js-details2').on('click', function(){
     $('html, body').animate({
           'scrollTop':   $('#anchorName2').offset().top
         }, 2000);
    $('.invoiceDetailsBtn').removeClass('active');
    $(this).addClass('active');
    $('.acc_trigger').removeClass('active');
    $('.acc_container').slideUp();
    $('.acc_container').eq(1).slideDown();
    $('#anchorName2').addClass('active');
});

$('.js-details3').on('click', function(){
     $('html, body').animate({
           'scrollTop':   $('#anchorName3').offset().top
         }, 2000);
    $('.invoiceDetailsBtn').removeClass('active');
    $(this).addClass('active');
    $('.acc_trigger').removeClass('active');
    $('.acc_container').slideUp();
    $('.acc_container').eq(2).slideDown();
    $('#anchorName3').addClass('active');
});

$('.js-details4').on('click', function(){
     $('html, body').animate({
           'scrollTop':   $('#anchorName4').offset().top
         }, 2000);
    $('.invoiceDetailsBtn').removeClass('active');
    $(this).addClass('active');
    $('.acc_trigger').removeClass('active');
    $('.acc_container').slideUp();
    $('.acc_container').eq(3).slideDown();
    $('#anchorName4').addClass('active');
});

$('.js-details5').on('click', function(){
     $('html, body').animate({
           'scrollTop':   $('#anchorName5').offset().top
         }, 2000);
    
    $('.invoiceDetailsBtn').removeClass('active');
    $(this).addClass('active');
    $('.acc_trigger').removeClass('active');
    $('.acc_container').slideUp();
    $('.acc_container').eq(4).slideDown();
    $('#anchorName5').addClass('active');
});


$('.js-details6').on('click', function(){
     $('html, body').animate({
           'scrollTop':   $('#anchorName6').offset().top
         }, 2000);
    $('.invoiceDetailsBtn').removeClass('active');
    $(this).addClass('active');
    $('.acc_trigger').removeClass('active');
    $('.acc_container').slideUp();
    $('.acc_container').eq(5).slideDown();
    $('#anchorName6').addClass('active');
});



//============================== help-support.html ==========================//
	SubmittingFormContactUs=function() {
				window.location = 'thank-you.html';
		}
		$(document).ready(function() {
			$("#contact-us").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormContactUs();
				},
				rules: {
					inputName:{
						required:true						 
					},
					CustomerID:{
						required:true
					},
					phone:{
						required:true,
						customphone:true
					},
					subject:{
						required:true
					},
					message:{
						required:true
					}
				},
				 messages: {
    				
    				inputName: {
     					required: "Please enter Name."
    				},
					CustomerID: {
     					required: "Please enter Customer ID."
    				},
					phone: {
     					required: "Please provide Contact Number."
    				},
					subject: {
     					required: "Please enter Subject."
    				},
					message: {
     					required: "Please write something."
    				}
				 }
			
			});
			$.validator.addMethod('customphone', function (value, element) {
    			return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value);
			}, "Please follow the patern, e.g. 123-456-7890");
});



// =========================== my-profile-info.html =======================//
SubmittingFormChangePassword=function() {
    window.location = 'my-profile-info.html';
  }
  $(document).ready(function() {
	
	 $('.js-submit').on('click', function(){
		$('.js-changePasswordBox').hide();
		$(this).hide();
		$('.message').show();
	});
	  
   $("#changePassword").validate({
    onfocusout: function(element) { 
     $(element).valid();
     },
     validClass: "success",
    submitHandler:function(form) {
     SubmittingFormChangePassword();
    },
    rules: {
     current_password:{
      required:true,
      //passwordCheck: true
      pass: true
       
     },
     new_password:{
      required:true,
               minlength: 8,
      pass:true
     },
     confirm_new_password:{
      required:true,
               minlength: 8,
      equalTo: "#new_password"
     }
    },
     messages: {
        
        current_password: {
          required: "Please enter your current Password."
        },
     new_password: {
          required: "Please enter new Password."
        },
     confirm_new_password: {
          required: "Please confirm Password."
        }
     }
   
   }); 
   // Validate password for speacial character
    jQuery.validator.addMethod("pass", function(value, element) {
     return this.optional(element) || /[^\w\s]/.test(value);
    }, "Password should have atleast one speacial character.");
	
	
	$( "#popup" ).dialog({ 
			title: 'Change Password',
			autoOpen: false,
			width: '500',
			modal: true,
			position : ['center', 150]
		});
		$('.js-popup').click(function(){
			$('#popup').dialog('open');
			return false;
		});	
		$(".closePopUp" ).click(function() {
			$( "#popup" ).dialog('close');
		});	
});


SubmittingFormProfileInfoSave=function() {
				window.location = 'my-profile-info.html';
		}
		$(document).ready(function() {
			$("#profileInfoSave").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormProfileInfoSave();
				},
				rules: {
					contact:{
						required:true,
						customphone:true
					},
					operEmail:{
						required:true,
           				email: true	
					},
					OperAltEmail:{
						required:true,
           				email: true
					}
				},
				 messages: {
    				
    				contact: {
     					required: "Please enter Contact Number."
    				},
					operEmail: {
     					required: "Please enter Email ID."
    				},
					OperAltEmail: {
     					required: "Please enter Alternate Email ID."
    				}
				 }
			
			});		
			$.validator.addMethod('customphone', function (value, element) {
    			return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value);
			}, "Please follow the patern, e.g. 123-456-7890");
});
	

// =========================== member-details.html ======================== //

$('#memberDependent').dataTable(
	 {
		"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bAutoWidth": false,
		"bFilter": true,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 2,7 ] }
       		]
		} 
	);
	var myTable=$('#memberDependent').dataTable();
	$('#memberDependent_wrapper .dataTables_filter input').attr('placeholder','Member ID');


// ========================== payment-history.html ========================= //

$('#paymentHistory').dataTable(
	  {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "<''<''T><''f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       		]
		} 
	);
	
// ============================= auto-recurring-4.html =============================//
SubmittingFormPaymentAutoRecurring=function() {
					$('#popupView').dialog('open');
					return false;
		}
			$("#paymentAutoRecurring").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormPaymentAutoRecurring();
				},
				rules: {
					inputEmail1:{
						required:true,
           				email: true	
					}
				},
				 messages: {
					inputEmail1: {
     					required: "Please enter Email ID."
    				}
				 }
			});
$('.expandButton').removeClass('closeSection');
		$('.expandButton').addClass('openSection');
  		$(".customerBrief").css({"margin-left":"-210px"});
		$(".rightSection").css({"margin-left":"10px"});
	// Rules home table - delete and assign & unassign functionality
	$( "#popupView" ).dialog({ 
			title: 'Recurring Confirmation',
			autoOpen: false,
			width: '500',
			modal: true,
			position : ['center', 150]
	});
	
			
	$(".closePopUp" ).click(function() {
		$( ".popupBox" ).dialog('close');
	})



// ========================= go-paper-less.html  ====================== //

		SubmittingFormGopaperless=function() {
					$('#popupViewPaperless').dialog('open');
					return false;		
					}
			$("#paperLess").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormGopaperless();
				}
				 
			});
			$( "#popupViewPaperless" ).dialog({ 
						title: 'Thank you!!!',
						autoOpen: false,
						width: '300',
						modal: true,
						position : ['center', 150]
			});
			
// ========================= modify-recurring-payment-amount.html =================================== //

	SubmittingFormModifyRecurring=function() {
			//alert("The form has been validated.");
			var paymentAmount = $('#paymentAmount').val();
			if(paymentAmount > 0){
				window.location = 'modify-recurring-payment-option.html';
			}
		}
		$(document).ready(function() {
			$("#modifyRecurringPaymentAmount").validate({
				onfocusout: function(element) { 
					$(element).valid();
					
					var price = document.getElementById('paymentAmount').value;
    				 if (price % 1 == 0){
						Number.prototype.format = function() {
							 return this.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1");	 
						}
						price = parseInt(price);
						price = price ? price : "";
						$("#paymentAmount").val(price.format());
					}
					
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormModifyRecurring();
				},
				rules: {
					paymentAmount:{
						required:true,
						greaterThanZero: true,
						//number:true,
						money:true
					}
				},
				 messages: {
    				
    				paymentAmount: {
     					required: "Please enter Amount.",
						number: "Please enter Amount."
    						}
				 }
			
			});
		
   });
		
// =================== modify-recurring-payment-option.html : individual  ========================== //

	SubmittingFormModifyRecurringPayment=function() {
				window.location = 'modify-recurring-payment-schedule.html';
		}
		
			
			$("#ModifyRecurringPayment").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormModifyRecurringPayment();
				},
				rules: {
					account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					name_on_card:{
						required:true	
					},
					cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					},
					inner_cvv_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 4, // will count space 
            			maxlength: 4
					},
					inner_account_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
					},
					inner_account_no_amex:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 15, // will count space 
           				maxlength: 15
					},
					inner_name_on_card:{
						required:true
					},
					inner_cvv_no:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 3, // will count space 
            			maxlength: 3
					},
					Add1:{
						required: true
					},
					city:{
						required: true
					},
					state:{
						required: true
					},
					zip:{
						required: true
					},
					country:{
						required: true
					}
				},
				 messages: {
    				
    				account_no: {
     					required: "Please enter Card Number."
    				},
					name_on_card: {
     					required: "Please enter Name as appears on Card."
    				},
					cvv_no: {
     					required: "Please enter CVV."
    				},
					inner_account_no:{
						required: "Please enter Card Number."
					},
					inner_account_no_amex:{
						required: "Please enter Card Number."
					},
					inner_name_on_card:{
						required: "Please enter Name as appears on Card."
					},
					inner_cvv_no:{
						required: "Please enter CVV."
					},
					inner_cvv_no_amex:{
						required: "Please enter 4-digit Security Code."
					},
					Add1:{
						required: "Please enter Addres Line 1."
					},
					city:{
						required: "Please enter City."
					},
					state:{
						required: "Please select State."
					},
					zip:{
						required: "Please enter Zip."
					},
					country:{
						required: "Please enter Country."
					}
				 }
			
			});
			
			
			
			
			SubmittingFormModifyRecurringPaymentEFT=function() {
				window.location = 'modify-recurring-payment-schedule.html';
			
		}
			$("#ModifyRecurringPaymentEFT").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormModifyRecurringPaymentEFT();
				},
				rules: {
					accountType:{
						required:true,
						selectcheck:true
					},
					acName:{
						required:true				 
					},
					acNum:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
           				minlength: 4, // will count space 
           				maxlength: 17
						 
					},
					RouNum:{
						required:true,
						//digits: true,
						number: true, // as space is not a number it will return an error
            			minlength: 9, // will count space 
            			maxlength: 9
					},
					
					Add1_Eft:{
						required: true
					},
					city_Eft:{
						required: true
					},
					state_Eft:{
						required: true,
						selectcheck:true
					},
					zip_Eft:{
						required: true
					},
					country_Eft:{
						required: true
					}
				},
				 messages: {
    				
    				acNum: {
     					required: "Please enter Account Number."
    				},acName: {
     					required: "Please enter First Name."
    				},
					RouNum: {
     					required: "Please enter Routing Number."
    				},
					Add1_Eft:{
						required: "Please enter Addres Line 1."
					},
					city_Eft:{
						required: "Please enter City."
					},
					state_Eft:{
						required: "Please enter State."
					},
					zip_Eft:{
						required: "Please enter Zip."
					},
					country_Eft:{
						required: "Please enter Country."
					}
				 }
			
});

$.validator.addMethod('selectcheck', function (value) {
       				 return (value !== 'select');
    				}, "Please select an option");


// =====================Modify Recurring payment amount =====================
		
		SubmittingFormModifyRecurringPaymentAmount=function() {
			//alert("The form has been validated.");
			var paymentAmount = $('#paymentAmount').val();
			if(paymentAmount > 0){
				window.location = 'modify-recurring-payment-option.html';
			}
		}
			$("#modifyRecurringPaymentAmount").validate({
				onfocusout: function(element) { 
					$(element).valid();
					
					var price = document.getElementById('paymentAmount').value;
    				 if (price % 1 == 0){
						Number.prototype.format = function() {
							 return this.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1");	 
						}
						price = parseInt(price);
						price = price ? price : "";
						$("#paymentAmount").val(price.format());
					}
					
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormModifyRecurringPaymentAmount();
				},
				rules: {
					paymentAmount:{
						required:true,
						greaterThanZero: true,
						//number:true,
						money:true
					}
				},
				 messages: {
    				
    				paymentAmount: {
     					required: "Please enter Amount.",
						number: "Please enter Amount."
    						}
				 }
			
			});
			
					 jQuery.validator.addMethod("greaterThanZero", function(value, element) {
    return this.optional(element) || (parseFloat(value) > 0);
}, "Minimum payable amount is : $0.01");
		
		  
		 


// ==================== modify-recurring-payment-summary.html ======================== //
SubmittingFormEmailValidation=function() {
					$('#popupView').dialog('open');
					return false;		
					}
			$("#emailValidation").validate({
				onfocusout: function(element) { 
					$(element).valid();
				 },
				 validClass: "success",
				submitHandler:function(form) {
					SubmittingFormEmailValidation();
				},
				rules: {
					inputEmail1:{
						required:true,
           				email: true	
					}
				},
				 messages: {
					inputEmail1: {
     					required: "Please enter Email ID."
    				}
				 }
			});			



/*===========Payment Methods=======*/


$(".showInfo input[type='checkbox']").change(function() {
    $(".showInfo").find("input[type='checkbox']").not(this).prop("checked", false);
    $(this).prop("checked", true);
	$.msgBox({
			title: "Are You Sure?",
			content: "You want to change your Preferred Payment Method ?",
			type: "confirm",
			buttons: [{ value: "Yes" },{ value: "Cancel"}],
			success: function (result) {
				if (result == "Yes") {;
				}else if(result == "Cancel"){
						$(".showInfo").find("input[type='checkbox']").not(this).prop("checked", false);
					}
				  }
	   		});
});




	var oTable =  $('#plandetailsTbl').dataTable(
	 {
		//"aaSorting": [[ 0, "asc" ]],
		"sPaginationType": "full_numbers",
		"bAutoWidth": false,
		"bFilter": true,
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [  ] }
       		]
		} 
	);
	var myTable3 = $('#plandetailsTbl').dataTable();
	$('#plandetailsTbl_filter input').attr('placeholder','Plan Id');
	
	
	var xps = 1;
	$('#sortEmp > tbody > tr td a.slide-plus').click(function(){
		if( xps > 0 ){
			xps = -1;
		$('#sortEmp > tbody > tr.dataRow1').after('<tr class="dataRow1Data hide"><td colspan="7" style="background: #e0dddd !important;"><table cellpadding="0" cellspacing="0" class="table table-striped" style="width:100%;" align="center"><thead><tr><th nowrap style="width:85px;">Member ID</th><th nowrap>Member Name</th><th nowrap>Relationship</th><th nowrap>Plan Name</th><th nowrap>Eff. Date</th><th nowrap>Term. Date</th><th nowrap>Status</th><th nowrap>Amount</th></tr></thead><tbody><tr><td>12345</td><td>James Smith</td><td>Self</td><td>Blue Cross of Idaho Bronze Plan</td><td>01/01/2015</td><td>12/31/2015</td><td>Active</td><td class="text-right">$125.00</td></tr><tr><td>12346</td><td>Susan Smith</td><td>Spouse</td><td>Blue Cross of Idaho Bronze Plan</td><td>01/01/2015</td><td>12/31/2015</td><td>Active</td><td class="text-right">$125.00</td></tr>');
		}
		$(this).parents("tr").next(".dataRow1Data").toggle();
		$(this).toggleClass("slide-minus");
	});
   
   
   var oTable =  $('#sortEmp').dataTable(
 	{
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"sDom": "<'row-fluid'<'span7'T><'span5'f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				"print",
				 "xls"
				
			]
		},
		"aoColumnDefs": [
		   { 'bSortable': false, 'aTargets': [ 0 ] },	
		  
		   { "aTargets" : ["uk-date-column"] , "sType" : "uk_date"},
		   { "aTargets" : ["uk-currency-column"] , "sType" : "currency"}
       		],
			
			
		} 
	);
	
	var myTable4 = $('#sortEmp').dataTable();
	$('#sortEmp_filter input').attr('placeholder','Subscriber ID');

	


$(function(){
	$('#paymentHistory').dataTable(
	  {
		"aaSorting": [[ 1, "desc" ]],
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"sDom": "<''<''T><''f>r>t<'row-fluid'<'span5'i><'span7'p>>",
		"oTableTools": {
			"sSwfPath": "../images/copy_csv_xls_pdf.swf",
			"aButtons": [
				
				
			]
		},
		"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       		]
		} 
	);
});

/*  JS to print contents */
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
}