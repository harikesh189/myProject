function addFilter(_filterList, _filterColumnName, _filterValue,
		_filterOperand, _filterValueCaseSensitive) {

	if (isValueNullOrNotDefinedOrBlank(_filterValue)
			|| isValueNullOrNotDefinedOrBlank(_filterOperand)) {
		return _filterList;
	}

	if (isValueNullOrNotDefinedOrBlank(_filterList)) {
		_filterList = [];
	}

	if (isValueNullOrNotDefinedOrBlank(_filterValueCaseSensitive)) {
		_filterValueCaseSensitive = false;
	}

	var filter = {};
	filter.columnName = _filterColumnName;
	filter.filterValue = _filterValue;
	filter.filterOperand = _filterOperand;
	filter.filterCaseSensitive = _filterValueCaseSensitive;
	_filterList.push(filter);

	return _filterList;
}

function isValueNullOrNotDefinedOrBlank(_value) {
	if (_value == undefined || _value == '' || _value == null) {
		return true;
	}
	return false;
}

function getSearchCriteriaJson(_filterList, _paginationJson, _refrenceId) {

	var criteria = " {";
	var filterListSize = _filterList.length;

	for ( var index in _filterList) {
		var filterObj = _filterList[index];
		criteria = criteria + "\"" + filterObj.columnName
				+ "\" : { \"operator\" : \"" + filterObj.filterOperand
				+ "\", \"columnValue\" : \"" + filterObj.filterValue
				+ "\",\"caseSensitiveSearch\" : \""
				+ filterObj.filterCaseSensitive + "\"}";
		if (index != (filterListSize - 1)) {
			criteria = criteria + ",";
		}
	}

	criteria = criteria + " } ";

	if (isValueNullOrNotDefinedOrBlank(_paginationJson)) {
		_paginationJson = "{}";
	}

	if (!isValueNullOrNotDefinedOrBlank(_refrenceId)) {
  _refrenceId = ", \"referenceId\" :\"" + _refrenceId+"\"";
 }
 else{_refrenceId="";
 }
 var searchCriteria = "{\"criteria\" : " + criteria
   + " , \"pageRequestCriteria\" : " + _paginationJson
   + _refrenceId+"}";
 return searchCriteria;
}