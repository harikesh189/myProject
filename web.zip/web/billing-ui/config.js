			
hcentive.WFMApp = function () {
    var appName = "";
    var serializer = new ONEGEEK.GSerializer();

    function getParameterByName(name) {
        var match = RegExp('[?&]' + name + '=([^&]*)').exec(
            window.location.href);
        return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
    }
    function getServerDomain(){
    	return document.location.hostname;
    }

    // start 'em up
    var start = function (application) {
        appName = application;
		if(hcentive.WFM.unSecured[application]){
			var defaultAppContext = hcentive.WFM.applicationContext;
			var module = init(application, defaultAppContext);
            // startup Angular
            console.log("bootstrapping angular in unsafe mode!!");
	    console.log("bootstrapping: "+appName);
            angular.bootstrap(document, [ appName ]);
			return module;
		}
//		 console.log("bootstrapping: "+module);
        // load configuration and initialize the app
        return loadApplicationContext(appName);
    };

    // get configuration basis tenantId
    var setConfiguration = function (headers, tenantId) {

        var configSuccess = function (data) {
            hcentive.WFM.applicationContext.configuration = data;
            var module = init(appName, hcentive.WFM.applicationContext);
            // startup Angular
            console.log("bootstrapping angular!");
            angular.bootstrap(document, [ appName ]);
            return module;
        };
        var configError = function (data) {
          // alert("Error in loading config");
        };
        var currentTime = new Date().getTime();
        var message = headers['securityKey'] + currentTime;
        // set nonce
        headers['nonce'] = currentTime;
        headers['passKey'] = CryptoJS.MD5(message);
        wfmConfigSrvc.getViewContext(headers,null,configSuccess, configError);
    };
 
	var setBeType = function(){
		var client_id = hcentive.WFM.client_id;
		if(client_id == 'Customer'){
			if(hcentive.WFM.applicationContext.loggedInUser.managesBEofTypes!= undefined){
				var be = hcentive.WFM.applicationContext.loggedInUser.managesBEofTypes[0].toLowerCase();
				Object.keys(hcentive.WFM.beTypes).map(function (key) {
					if(be == hcentive.WFM.beTypes[key]){
						beType = key;
					}
				});
				hcentive.WFM.applicationContext.beType = beType;
			}
		}else{
			angular.forEach(hcentive.WFM.beTypes, function (value, key) {
                if(value == hcentive.WFM.client_id.toLowerCase() ){
					hcentive.WFM.applicationContext.beType = key;
				}
            });
		}
	}
	
    // set application user
    var setAppUser = function (headers) {

        var appUserSuccess = function (data) {
            hcentive.WFM.applicationContext.loggedInUser = data;
			setBeType();
			
            // set application configuration basis tenantId
            setConfiguration(hcentive.WFM.applicationContext.headers,
                data.tenantId);
        };
        var appUserError = function (data) {
            //alert("Error in loading current user");
        };
        wfmSecuritySrvc.getAppUser(headers, appUserSuccess, appUserError);
    };

    var loadApplicationContextRemotely = function (appName) {
        console.log("getting context from server.");
        // set up security context
        var securitySuccess = function (data) {
            angular.forEach(data, function (value, key) {
                // set application wide security headers
                if (key == 'securityKey' || key == 'identity') {
                    hcentive.WFM.applicationContext.headers[key] = value;
                }
            });
            var currentTime = new Date().getTime();
            var message = hcentive.WFM.applicationContext.headers['securityKey']
                + currentTime;
            // set nonce
            hcentive.WFM.applicationContext.headers['nonce'] = currentTime;
            hcentive.WFM.applicationContext.headers['passKey'] = CryptoJS
                .MD5(message);
            hcentive.WFM.applicationContext.headers['Authorization'] = "BASIC "+hcentive.WFM.applicationContext.headers['identity'];
            // set application context
            setAppUser(hcentive.WFM.applicationContext.headers);
        };
        var securityError = function (data) {
        		window.location.href = hcentive.WFM.domainName + "/security/oAuth2/accessDenied?client_id="+hcentive.WFM.client_id+"&response_type=token";
        };
        // set security headers basis tokenId
        wfmSecuritySrvc.getSecurityHeaders('', {"clientId" : hcentive.WFM.client_id}, securitySuccess, securityError);
    };

    // if not already present, load configuration and initialize the app
    var loadApplicationContext = function (appName) {
        //hcentive.WFM.applicationContext.beType = beType;
        loadApplicationContextRemotely(appName);
        return;
    };

    var init = function (appName, applicationContext) {
        console.log("wfmAppContext set!");
        // create the module
        var WFMApp = angular.module(appName, [ 'ngResource', 'ngRoute' , 'wfm-http-error-handling','angularSpinner', 'pascalprecht.translate','filterWidget','truncate','ng-context-menu' ]);

        WFMApp.constant("WFMAppContext", applicationContext);
		
		//spinner configuration START
		
		WFMApp.config(['$httpProvider', function($httpProvider) {
			$httpProvider.interceptors.push(function($q,usSpinnerService){
				var requestsCount = 0;			
				return {
				     request: function(config) {
				    	 requestsCount ++;
						 var setHeight = $(document).height();
				    	 $(".Bg-Fader").css("height", setHeight);
				    	 $(".Bg-Fader").show();
				    	 usSpinnerService.spin('spinner-1');
				    	 return config;
					 },
					 response:function(config){
						 requestsCount --;
						 if(requestsCount == 0){
							 $(".Bg-Fader").hide();
							 usSpinnerService.stop('spinner-1');
						 	}
						 return config;
					 },
					 responseError:function(config){
						 requestsCount --;
						 if(requestsCount == 0){
							 $(".Bg-Fader").hide();
							 usSpinnerService.stop('spinner-1');
						 	}
						return $q.reject(config);;
					 }
				};
			});
		}]);
		//spinner configuration END

        var routeView = function (params) {
            var view = 'views';
            var suffix = '.html';
            angular.forEach(params, function (value, param) {
                view += '/' + value;
            });
            return view += suffix;
        };

        // configure routes
        WFMApp
            .config([
                '$routeProvider',
                '$provide',
                function ($routeProvider, $provide) {
                    // routing
                    $routeProvider
                        .when('/:module/', {
                            templateUrl: function (params) {
                                var routeParams = {};
                                routeParams['module'] = params.module;
                                var url = routeView(routeParams);
                                var path = params.module
                                    + "Path";
                                params.breadCrumb = {
                                    'moduleDesc': hcentive.WFM.clientConfigurations[0].breadCrumb[params.module],
                                    'modulePath': hcentive.WFM.clientConfigurations[0].breadCrumb[path]
                                };
                                params.selectedModule = hcentive.WFM.clientConfigurations[0].breadCrumb[params.module];
                                return url;
                            }
                        })
                        .when(
                        '/:module/:page/',
                        {

                            templateUrl: function (params) {
                                var routeParams = {};
                                routeParams['module'] = params.module;
                                routeParams['page'] = params.page;
                                var url = routeView(routeParams);
                                var path = params.module
                                    + "Path";
                                params.breadCrumb = {
                                    'moduleDesc': hcentive.WFM.clientConfigurations[0].breadCrumb[params.module],
                                    'modulePath': hcentive.WFM.clientConfigurations[0].breadCrumb[path],
                                    'subModuleDesc': hcentive.WFM.clientConfigurations[0].breadCrumb[params.page]
                                };
                                params.selectedModule = hcentive.WFM.clientConfigurations[0].breadCrumb[params.module];
                                return url;
                            }
                        })
                        .when(
                        '/:module/:submodule/:page/',
                        {
                            templateUrl: function (params) {
                                var url = routeView(params);
                                var path = params.module
                                    + "Path";
                                params.breadCrumb = {
                                    'moduleDesc': hcentive.WFM.clientConfigurations[0].breadCrumb[params.module],
                                    'modulePath': hcentive.WFM.clientConfigurations[0].breadCrumb[path],
                                    'subModuleDesc': hcentive.WFM.clientConfigurations[0].breadCrumb[params.submodule],
                                    'innerSubModule': hcentive.WFM.clientConfigurations[0].breadCrumb[params.page]
                                };
                                params.selectedModule = hcentive.WFM.clientConfigurations[0].breadCrumb[params.module];
                                return url;
                            }
                        }).otherwise({
                            redirectTo: hcentive.WFM.landingPage
                        });
                    // eventing clean-up
                    $provide
                        .decorator(
                        '$rootScope',
                        [
                            '$delegate',
                            function ($delegate) {
                                Object
                                    .defineProperty(
                                    $delegate.constructor.prototype,
                                    '$onRootScope',
                                    {
                                        value: function (name, listener) {
                                            var unsubscribe = $delegate
                                                .$on(
                                                name,
                                                listener);
                                            this
                                                .$on(
                                                '$destroy',
                                                unsubscribe);
                                        },
                                        enumerable: false
                                    });
                                return $delegate;
                            } ]);
                } ]).config(['$translateProvider', function ($translateProvider) {
                $translateProvider.translations('en', translations_en);

                $translateProvider.translations('de', {
                    'TITLE': 'Hallo',
                    'FOO': 'Dies ist ein Paragraph'
                });

                $translateProvider.preferredLanguage('en');
            }]);

        // bootstrap configuration
		if(typeof hcentive.WFM.configData[appName] !== "undefined"){
			angular.forEach(hcentive.WFM.configData[appName].providers, function (provider) {
				// wireup providers
				WFMApp.provider(provider.name, provider.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].services, function (service) {
				// wireup services
				WFMApp.factory(service.name, service.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].directives, function (directive) {
				// wireup directives
				WFMApp.directive(directive.name, directive.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].filters, function (filter) {
				// wireup filters
				WFMApp.filter(filter.name, filter.id);
			});
			angular.forEach(hcentive.WFM.configData[appName].controllers, function (controller) {
				// wireup controllers
				WFMApp.controller(controller.name, controller.id);
			});
		}
        return WFMApp;
    };
    return {
        start: start
    };
}();
