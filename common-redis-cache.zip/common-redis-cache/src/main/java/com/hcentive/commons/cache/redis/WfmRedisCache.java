package com.hcentive.commons.cache.redis;

import org.springframework.data.redis.cache.RedisCache;
import org.springframework.data.redis.core.RedisTemplate;

public class WfmRedisCache extends RedisCache {

	public WfmRedisCache(String name, byte[] prefix, RedisTemplate<? extends Object, ? extends Object> template, long expiration) {
		super(name, prefix, template, expiration);
	}

}
