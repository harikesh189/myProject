package com.hcentive.commons.cache.redis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.hcentive.commons.configuration.cache.redis.RedisConfiguration;

@Configuration
@Import({ RedisConfiguration.class })
@ConditionalOnProperty(name = "cache.impl", havingValue = "redis")
public class RedisCacheConfiguration {

	@Autowired
	private RedisTemplate redisTemplate;

	@Bean
	public RedisCacheManager redisCacheManager() {
		RedisSerializer<String> stringSerializer = new StringRedisSerializer();
		redisTemplate.setKeySerializer(stringSerializer);
		redisTemplate.setHashKeySerializer(stringSerializer);
		return new RedisCacheManager(redisTemplate);
	}


	@Bean
	public RedisCacheClient redisCacheClient() {
		RedisCacheClient redisCache = new RedisCacheClient();
		return redisCache;
	}
}
