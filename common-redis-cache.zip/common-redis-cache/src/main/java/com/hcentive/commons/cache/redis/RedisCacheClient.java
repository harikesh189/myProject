package com.hcentive.commons.cache.redis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache.ValueWrapper;
import org.springframework.data.redis.cache.RedisCache;
import org.springframework.data.redis.cache.RedisCacheElement;
import org.springframework.data.redis.cache.RedisCacheKey;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.core.RedisTemplate;

import com.hcentive.billing.core.commons.cache.CacheClient;

@SuppressWarnings("rawtypes")
public class RedisCacheClient implements CacheClient<String, Object> {

	private static final String CACHE_NAME = "WFM_CACHE";
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(RedisCacheClient.class);

	@Autowired
	private RedisCacheManager cacheManager;

	@Autowired
	private RedisTemplate redisTemplate;

	@Override
	public void clear() {
		LOGGER.debug("Clearing Cache {}", CACHE_NAME);
		cacheManager.getCache(CACHE_NAME).clear();
	}

	@Override
	public Object get(String key) {
		RedisCache cache = (RedisCache) cacheManager.getCache(CACHE_NAME);
		ValueWrapper valueWrapper = cache.get(getRedisCacheKey(key));
		return valueWrapper != null ? valueWrapper.get() : null;
	}

	@Override
	public Object put(String key, Object value) {
		return this.put(key, value, 0);
	}

	@Override
	public Object put(String key, Object value, int expiryInSec) {
		RedisCache cache = (RedisCache) cacheManager.getCache(CACHE_NAME);
		RedisCacheElement redisCacheElement = getRedisCacheElement(key, value, expiryInSec);
		cache.put(redisCacheElement);
		return value;

	}

	@Override
	public Object remove(String key) {
		RedisCache cache = (RedisCache) cacheManager.getCache(CACHE_NAME);
		LOGGER.debug("Removing from redis cache for key {}", key);
		cache.evict(getRedisCacheElement(key, null));
		return true;
	}

	private RedisCacheElement getRedisCacheElement(String key, Object value) {
		return new RedisCacheElement(getRedisCacheKey(key), value);
	}

	private RedisCacheElement getRedisCacheElement(String key, Object value, int expiryInSec) {
		return new RedisCacheElement(getRedisCacheKey(key), value).expireAfter(expiryInSec);
	}

	private RedisCacheKey getRedisCacheKey(String key) {
		return new RedisCacheKey(key).withKeySerializer(redisTemplate.getKeySerializer());
	}

}